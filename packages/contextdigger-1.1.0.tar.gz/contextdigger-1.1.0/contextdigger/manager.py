"""
Focus Manager Library

Provides core functionality for focus area management, session tracking,
and bookmark management. This library is language-agnostic and works with
any codebase structure.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
import fnmatch


@dataclass
class FocusArea:
    """Represents a logical area of the codebase to focus on."""

    id: str
    name: str
    description: str
    type: str  # "auto-detected" or "manual"
    patterns: Dict[str, List[str]]  # include/exclude patterns
    metadata: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)
    quickAccess: Dict[str, List[str]] = field(default_factory=dict)
    created: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")
    lastFocused: Optional[str] = None
    focusCount: int = 0

    @property
    def path(self) -> str:
        """Extract representative path from include patterns."""
        if not self.patterns or "include" not in self.patterns:
            return ""

        includes = self.patterns["include"]
        if not includes:
            return ""

        # Get first include pattern and extract base path
        first_pattern = includes[0]

        # If pattern starts with **, it's a root-level glob
        if first_pattern.startswith("**"):
            return "."

        # Remove glob patterns like /**/*.py or /**
        path = first_pattern.split("/**")[0] if "/**" in first_pattern else first_pattern
        path = path.rstrip("/*")
        return path if path else "."


@dataclass
class Session:
    """Represents a focus session with activity tracking."""

    sessionId: str
    areaId: str
    startedAt: str
    endedAt: Optional[str] = None
    duration: Optional[int] = None  # seconds
    summary: str = ""
    description: str = ""
    activity: Dict[str, List[str]] = field(default_factory=lambda: {
        "filesViewed": [],
        "filesModified": [],
        "filesCreated": [],
        "filesDeleted": [],
        "commandsRun": []
    })
    tags: List[str] = field(default_factory=list)


@dataclass
class Bookmark:
    """Represents a bookmarked file location."""

    id: str
    name: str
    path: str
    line: Optional[int] = None
    column: Optional[int] = None
    context: str = ""
    focusArea: Optional[str] = None
    created: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")
    lastAccessed: Optional[str] = None
    accessCount: int = 0
    tags: List[str] = field(default_factory=list)
    notes: str = ""


@dataclass
class DigHistoryEntry:
    """Represents an entry in the dig navigation history."""

    areaId: str
    areaName: str
    enteredAt: str
    exitedAt: Optional[str] = None
    duration: Optional[int] = None  # seconds
    actions: List[str] = field(default_factory=list)  # ["marked 2 spots", "viewed 8 files"]
    breadcrumb: str = ""  # Human-readable path


@dataclass
class ContextSnapshot:
    """Represents a saved context snapshot."""

    name: str
    description: str
    savedAt: str
    currentArea: Optional[str] = None
    currentAreaName: Optional[str] = None
    markedSpots: List[Dict[str, Any]] = field(default_factory=list)
    digHistory: List[Dict[str, Any]] = field(default_factory=list)
    historyIndex: int = -1
    sessionNotes: str = ""
    tags: List[str] = field(default_factory=list)


@dataclass
class AreaSuggestion:
    """Represents a suggested area to explore."""

    areaId: str
    areaName: str
    reason: str  # Why this is suggested
    score: float  # Relevance score 0-1
    relationType: str  # "imports", "naming", "dependency", "frequent"


@dataclass
class TeamActivity:
    """Represents a team member's current activity."""

    userId: str  # User identifier (email or username)
    userName: str  # Display name
    currentArea: Optional[str] = None  # Current dig area ID
    currentAreaName: Optional[str] = None  # Current dig area name
    lastActive: str = ""  # Last activity timestamp
    sessionStart: Optional[str] = None  # When they started current session
    recentMarks: List[str] = field(default_factory=list)  # Recent bookmarks
    recentAreas: List[str] = field(default_factory=list)  # Recent areas visited


@dataclass
class AreaNote:
    """Represents a knowledge note attached to an area."""

    id: str  # Unique note ID
    author: str  # Who wrote the note
    authorName: str  # Display name
    timestamp: str  # When note was created
    note: str  # The note content
    tags: List[str] = field(default_factory=list)  # Optional tags
    updatedAt: Optional[str] = None  # Last update time
    updatedBy: Optional[str] = None  # Who last updated it


@dataclass
class DependencyInfo:
    """Represents a dependency relationship between areas."""

    targetAreaId: str  # Area being depended on
    targetAreaName: str  # Display name
    dependencyType: str  # "imports", "calls", "references", "config"
    strength: float  # Dependency strength 0-1
    references: List[str] = field(default_factory=list)  # Specific import/call examples


@dataclass
class ImpactAnalysis:
    """Represents the impact of changing an area."""

    areaId: str  # Area being analyzed
    areaName: str  # Display name
    directDependents: List[str] = field(default_factory=list)  # Areas that directly depend on this
    indirectDependents: List[str] = field(default_factory=list)  # Areas indirectly affected
    impactScore: float = 0.0  # Overall impact score 0-1
    riskLevel: str = "low"  # "low", "medium", "high"


@dataclass
class HotSpot:
    """Represents a code hotspot based on git activity and complexity."""

    areaId: str  # Area identifier
    areaName: str  # Display name
    commitCount: int = 0  # Number of commits in time period
    authorCount: int = 0  # Number of unique authors
    linesChanged: int = 0  # Total lines added + deleted
    churnRate: float = 0.0  # Commits per day
    complexity: float = 0.0  # Basic complexity metric 0-1
    temperature: str = "cool"  # "cool", "warm", "hot", "critical"
    recentCommits: List[str] = field(default_factory=list)  # Recent commit messages


@dataclass
class TestCoverage:
    """Represents test coverage information for an area."""

    areaId: str  # Area identifier
    areaName: str  # Display name
    coveragePercent: float = 0.0  # Overall coverage percentage
    linesCovered: int = 0  # Number of lines covered
    linesTotal: int = 0  # Total number of lines
    testFiles: List[str] = field(default_factory=list)  # Test files for this area
    untestedFiles: List[str] = field(default_factory=list)  # Files without tests
    testToCodeRatio: float = 0.0  # Ratio of test lines to code lines


@dataclass
class PerformanceProfile:
    """Represents performance metrics for an area."""

    id: str  # Unique profile ID
    areaId: str  # Area identifier
    areaName: str  # Display name
    timestamp: str  # When recorded
    benchmarkName: str  # Name of benchmark/test
    executionTimeMs: float = 0.0  # Execution time in milliseconds
    memoryUsageMb: float = 0.0  # Memory usage in MB
    cpuPercent: float = 0.0  # CPU usage percentage
    iterations: int = 1  # Number of iterations run
    metadata: Dict[str, Any] = field(default_factory=dict)  # Additional metrics
    gitCommit: Optional[str] = None  # Git commit hash when recorded
    environment: Dict[str, str] = field(default_factory=dict)  # Environment info


@dataclass
class AutomationRule:
    """Represents an automation rule triggered by context changes."""

    id: str  # Unique rule ID
    name: str  # Rule name
    description: str  # What this rule does
    trigger: str  # "on_enter", "on_exit", "on_mark", "on_commit"
    areaPattern: str = "*"  # Area ID pattern (glob), "*" for all
    action: str = "notify"  # "notify", "run_command", "suggest", "warn"
    actionData: Dict[str, Any] = field(default_factory=dict)  # Action-specific data
    conditions: Dict[str, Any] = field(default_factory=dict)  # Optional conditions
    enabled: bool = True  # Whether rule is active
    createdAt: str = ""  # Creation timestamp
    lastTriggered: Optional[str] = None  # Last execution timestamp
    triggerCount: int = 0  # Number of times triggered


@dataclass
class SearchResult:
    """Represents a search result from any data type."""

    type: str  # "area", "note", "bookmark", "snapshot", "automation"
    id: str  # Item ID
    title: str  # Display title
    content: str  # Matched content or description
    areaId: Optional[str] = None  # Associated area (if applicable)
    areaName: Optional[str] = None  # Associated area name
    timestamp: Optional[str] = None  # When created/modified
    score: float = 1.0  # Relevance score (0-1)
    metadata: Dict[str, Any] = field(default_factory=dict)  # Additional info


@dataclass
class WorkAnalytics:
    """Represents analytics and insights about work patterns."""

    totalAreas: int = 0  # Total number of areas
    totalSessions: int = 0  # Total work sessions
    totalBookmarks: int = 0  # Total bookmarks created
    totalNotes: int = 0  # Total notes written
    totalSnapshots: int = 0  # Total context snapshots
    mostVisitedAreas: List[Dict[str, Any]] = field(default_factory=list)  # Top areas by visits
    recentActivity: List[Dict[str, Any]] = field(default_factory=list)  # Recent work history
    areasByTag: Dict[str, int] = field(default_factory=dict)  # Area count by tag
    averageSessionLength: float = 0.0  # Average session duration in minutes
    productivityScore: float = 0.0  # Overall productivity score (0-100)
    insights: List[str] = field(default_factory=list)  # Textual insights


class FocusManager:
    """Manages focus areas, sessions, and bookmarks for a project."""

    def __init__(self, project_root: Path):
        """
        Initialize FocusManager for a project.

        Args:
            project_root: Root directory of the project
        """
        self.project_root = Path(project_root).resolve()
        self.focus_root = self.project_root / ".cdg"
        self.cdg_dir = self.focus_root  # Alias for backwards compatibility
        self.config_file = self.focus_root / "config.json"

    def get_history(self) -> List[DigHistoryEntry]:
        """Alias for get_dig_history for backwards compatibility."""
        return self.get_dig_history()

    def is_initialized(self) -> bool:
        """Check if focus manager is initialized."""
        return self.config_file.exists()

    def initialize(self) -> None:
        """Initialize focus manager directory structure and config."""
        # Create directories
        (self.focus_root / "areas").mkdir(parents=True, exist_ok=True)
        (self.focus_root / "sessions").mkdir(parents=True, exist_ok=True)
        (self.focus_root / "bookmarks").mkdir(parents=True, exist_ok=True)
        (self.focus_root / "history").mkdir(parents=True, exist_ok=True)
        (self.focus_root / "snapshots").mkdir(parents=True, exist_ok=True)
        (self.focus_root / "team").mkdir(parents=True, exist_ok=True)
        (self.focus_root / "testing").mkdir(parents=True, exist_ok=True)
        (self.focus_root / "dependencies").mkdir(parents=True, exist_ok=True)

        # Create initial config
        config = {
            "version": "1.0.4",
            "projectRoot": str(self.project_root),
            "projectName": self.project_root.name,
            "initialized": datetime.utcnow().isoformat() + "Z",
            "currentFocus": None,
            "defaultArea": "main",
            "history": {
                "currentIndex": -1,  # -1 means no history yet
                "maxSize": 50  # Keep last 50 history entries
            },
            "settings": {
                "autoSave": True,
                "sessionTimeout": 7200,
                "excludePatterns": [
                    "**/__pycache__/**",
                    "**/*.pyc",
                    "**/node_modules/**",
                    "**/.git/**",
                    "**/dist/**",
                    "**/build/**",
                    "**/.venv/**",
                    "**/.cdg/**"
                ]
            },
            "budgets": {
                "max_files": 15,
                "max_lines": 3000,
                "max_areas": 2,
                "warn_threshold": 0.8
            }
        }

        self._write_json(self.config_file, config)

        # Initialize empty indices
        self._write_json(self.focus_root / "areas" / "index.json", {
            "areas": [],
            "totalAreas": 0,
            "lastUpdated": datetime.utcnow().isoformat() + "Z"
        })

        self._write_json(self.focus_root / "sessions" / "index.json", {
            "sessions": [],
            "totalSessions": 0,
            "lastUpdated": datetime.utcnow().isoformat() + "Z"
        })

        self._write_json(self.focus_root / "bookmarks" / "bookmarks.json", {
            "bookmarks": [],
            "totalBookmarks": 0,
            "lastUpdated": datetime.utcnow().isoformat() + "Z"
        })

        self._write_json(self.focus_root / "history" / "history.json", {
            "entries": [],
            "totalEntries": 0,
            "lastUpdated": datetime.utcnow().isoformat() + "Z"
        })

        self._write_json(self.focus_root / "snapshots" / "index.json", {
            "snapshots": [],
            "totalSnapshots": 0,
            "lastUpdated": datetime.utcnow().isoformat() + "Z"
        })

    # Config Operations

    def load_config(self) -> Dict[str, Any]:
        """Load configuration."""
        return self._read_json(self.config_file)

    def save_config(self, config: Dict[str, Any]) -> None:
        """Save configuration."""
        self._write_json(self.config_file, config)

    def get_current_focus(self) -> Optional[str]:
        """Get current focus area ID."""
        config = self.load_config()
        return config.get("currentFocus")

    def set_current_focus(self, area_id: Optional[str], skip_history: bool = False) -> None:
        """
        Set current focus area.

        Args:
            area_id: Area ID to focus on (None to clear focus)
            skip_history: If True, don't add to history (used for back/forward navigation)
        """
        config = self.load_config()
        previous_focus = config.get("currentFocus")

        # Trigger on_exit automations for previous area
        if previous_focus and previous_focus != area_id:
            try:
                self.trigger_automations("on_exit", previous_focus)
            except Exception:
                pass  # Silently fail if automation fails

        config["currentFocus"] = area_id
        self.save_config(config)

        # Add to history if changing to a new area
        if area_id and not skip_history:
            self.add_to_history(area_id)

        # Trigger on_enter automations for new area
        if area_id and area_id != previous_focus:
            try:
                self.trigger_automations("on_enter", area_id)
            except Exception:
                pass  # Silently fail if automation fails

        # Broadcast activity to team
        try:
            self.broadcast_activity()
        except Exception:
            pass  # Silently fail if team broadcast fails

    # Area Operations

    def get_area(self, area_id: str) -> Optional[FocusArea]:
        """Load a focus area by ID."""
        area_file = self.focus_root / "areas" / f"{area_id}.json"
        if not area_file.exists():
            return None
        data = self._read_json(area_file)
        return FocusArea(**data)

    def save_area(self, area: FocusArea) -> None:
        """Save a focus area."""
        area_file = self.focus_root / "areas" / f"{area.id}.json"
        self._write_json(area_file, asdict(area))

        # Update index
        self._update_area_index(area)

    def list_areas(self) -> List[FocusArea]:
        """List all focus areas."""
        areas_dir = self.focus_root / "areas"
        if not areas_dir.exists():
            return []

        areas = []
        for area_file in areas_dir.glob("*.json"):
            if area_file.name == "index.json":
                continue
            data = self._read_json(area_file)
            areas.append(FocusArea(**data))

        # Sort by focus count (most used first), then by name
        areas.sort(key=lambda a: (-a.focusCount, a.name))
        return areas

    def find_areas(self, query: str) -> List[FocusArea]:
        """
        Find areas matching a query (fuzzy match on ID or name).

        Args:
            query: Search string

        Returns:
            List of matching areas, sorted by relevance
        """
        all_areas = self.list_areas()
        query_lower = query.lower()

        matches = []
        for area in all_areas:
            # Exact match on ID
            if area.id == query or area.id.lower() == query_lower:
                matches.append((area, 100))
            # Exact match on name
            elif area.name.lower() == query_lower:
                matches.append((area, 90))
            # ID contains query
            elif query_lower in area.id.lower():
                matches.append((area, 70))
            # Name contains query
            elif query_lower in area.name.lower():
                matches.append((area, 60))
            # Description contains query
            elif query_lower in area.description.lower():
                matches.append((area, 40))
            # Tags contain query
            elif any(query_lower in tag.lower() for tag in area.metadata.get("tags", [])):
                matches.append((area, 50))

        # Sort by relevance score (highest first)
        matches.sort(key=lambda x: -x[1])
        return [area for area, score in matches]

    def delete_area(self, area_id: str) -> bool:
        """Delete a focus area."""
        area_file = self.focus_root / "areas" / f"{area_id}.json"
        if not area_file.exists():
            return False

        area_file.unlink()

        # Update index
        index = self._read_json(self.focus_root / "areas" / "index.json")
        index["areas"] = [a for a in index["areas"] if a["id"] != area_id]
        index["totalAreas"] = len(index["areas"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self._write_json(self.focus_root / "areas" / "index.json", index)

        return True

    # Session Operations

    def get_current_session(self) -> Optional[Session]:
        """Get current active session."""
        session_file = self.focus_root / "sessions" / "current.json"
        if not session_file.exists():
            return None
        data = self._read_json(session_file)
        return Session(**data)

    def start_session(self, area_id: str) -> Session:
        """Start a new session for an area."""
        # End current session if exists
        current = self.get_current_session()
        if current:
            self.end_session()

        # Create new session
        session_id = datetime.utcnow().isoformat() + "Z"
        session = Session(
            sessionId=session_id,
            areaId=area_id,
            startedAt=session_id
        )

        # Save as current
        self._write_json(self.focus_root / "sessions" / "current.json", asdict(session))

        # Update area's focus count and last focused
        area = self.get_area(area_id)
        if area:
            area.focusCount += 1
            area.lastFocused = session_id
            self.save_area(area)

        # Set as current focus
        self.set_current_focus(area_id)

        return session

    def end_session(self, summary: str = "") -> Optional[Session]:
        """End the current session."""
        session_file = self.focus_root / "sessions" / "current.json"
        if not session_file.exists():
            return None

        # Load current session
        session = self.get_current_session()
        if not session:
            return None

        # Update session
        session.endedAt = datetime.utcnow().isoformat() + "Z"
        start = datetime.fromisoformat(session.startedAt.replace("Z", "+00:00"))
        end = datetime.fromisoformat(session.endedAt.replace("Z", "+00:00"))
        session.duration = int((end - start).total_seconds())

        if summary:
            session.summary = summary

        # Archive session
        archive_file = self.focus_root / "sessions" / f"{session.sessionId.replace(':', '-')}.json"
        self._write_json(archive_file, asdict(session))

        # Update index
        self._update_session_index(session)

        # Remove current session file
        session_file.unlink()

        # Clear current focus
        self.set_current_focus(None)

        return session

    def get_session_history(self, limit: int = 10) -> List[Session]:
        """Get recent session history."""
        sessions_dir = self.focus_root / "sessions"
        if not sessions_dir.exists():
            return []

        sessions = []
        for session_file in sessions_dir.glob("*.json"):
            if session_file.name in ("index.json", "current.json"):
                continue
            data = self._read_json(session_file)
            sessions.append(Session(**data))

        # Sort by start time (most recent first)
        sessions.sort(key=lambda s: s.startedAt, reverse=True)
        return sessions[:limit]

    # Bookmark Operations

    def add_bookmark(self, bookmark: Bookmark) -> None:
        """Add a bookmark."""
        bookmarks = self._read_json(self.focus_root / "bookmarks" / "bookmarks.json")

        # Check for duplicate ID
        existing_ids = {b["id"] for b in bookmarks["bookmarks"]}
        if bookmark.id in existing_ids:
            # Generate unique ID
            counter = 1
            base_id = bookmark.id
            while bookmark.id in existing_ids:
                bookmark.id = f"{base_id}_{counter}"
                counter += 1

        bookmarks["bookmarks"].append(asdict(bookmark))
        bookmarks["totalBookmarks"] = len(bookmarks["bookmarks"])
        bookmarks["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self._write_json(self.focus_root / "bookmarks" / "bookmarks.json", bookmarks)

    def get_bookmark(self, bookmark_id: str) -> Optional[Bookmark]:
        """Get a bookmark by ID."""
        bookmarks = self._read_json(self.focus_root / "bookmarks" / "bookmarks.json")
        for b_data in bookmarks["bookmarks"]:
            if b_data["id"] == bookmark_id:
                return Bookmark(**b_data)
        return None

    def find_bookmarks(self, query: str) -> List[Bookmark]:
        """Find bookmarks matching a query."""
        bookmarks_data = self._read_json(self.focus_root / "bookmarks" / "bookmarks.json")
        query_lower = query.lower()

        matches = []
        for b_data in bookmarks_data["bookmarks"]:
            bookmark = Bookmark(**b_data)

            # Exact match on ID
            if bookmark.id == query or bookmark.id.lower() == query_lower:
                matches.append((bookmark, 100))
            # Exact match on name
            elif bookmark.name.lower() == query_lower:
                matches.append((bookmark, 90))
            # ID contains query
            elif query_lower in bookmark.id.lower():
                matches.append((bookmark, 70))
            # Name contains query
            elif query_lower in bookmark.name.lower():
                matches.append((bookmark, 60))
            # Path contains query
            elif query_lower in bookmark.path.lower():
                matches.append((bookmark, 50))

        # Sort by relevance score (highest first)
        matches.sort(key=lambda x: -x[1])
        return [bookmark for bookmark, score in matches]

    def list_bookmarks(self, focus_area: Optional[str] = None) -> List[Bookmark]:
        """List all bookmarks, optionally filtered by focus area."""
        bookmarks_data = self._read_json(self.focus_root / "bookmarks" / "bookmarks.json")
        bookmarks = [Bookmark(**b) for b in bookmarks_data["bookmarks"]]

        if focus_area:
            bookmarks = [b for b in bookmarks if b.focusArea == focus_area]

        # Sort by access count (most accessed first), then by created date
        bookmarks.sort(key=lambda b: (-b.accessCount, b.created), reverse=False)
        return bookmarks

    def update_bookmark_access(self, bookmark_id: str) -> None:
        """Update bookmark access count and timestamp."""
        bookmarks = self._read_json(self.focus_root / "bookmarks" / "bookmarks.json")

        for b in bookmarks["bookmarks"]:
            if b["id"] == bookmark_id:
                b["accessCount"] = b.get("accessCount", 0) + 1
                b["lastAccessed"] = datetime.utcnow().isoformat() + "Z"
                break

        bookmarks["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self._write_json(self.focus_root / "bookmarks" / "bookmarks.json", bookmarks)

    def delete_bookmark(self, bookmark_id: str) -> bool:
        """Delete a bookmark."""
        bookmarks = self._read_json(self.focus_root / "bookmarks" / "bookmarks.json")

        initial_count = len(bookmarks["bookmarks"])
        bookmarks["bookmarks"] = [b for b in bookmarks["bookmarks"] if b["id"] != bookmark_id]

        if len(bookmarks["bookmarks"]) == initial_count:
            return False

        bookmarks["totalBookmarks"] = len(bookmarks["bookmarks"])
        bookmarks["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self._write_json(self.focus_root / "bookmarks" / "bookmarks.json", bookmarks)
        return True

    # Utility Methods

    def matches_pattern(self, file_path: str, area: FocusArea) -> bool:
        """
        Check if a file matches an area's patterns.

        Args:
            file_path: Path to check (relative to project root)
            area: Focus area with include/exclude patterns

        Returns:
            True if file matches
        """
        # Check exclude patterns first
        for pattern in area.patterns.get("exclude", []):
            if fnmatch.fnmatch(file_path, pattern) or fnmatch.fnmatch(str(Path(file_path)), pattern):
                return False

        # Check include patterns
        for pattern in area.patterns.get("include", []):
            if fnmatch.fnmatch(file_path, pattern) or fnmatch.fnmatch(str(Path(file_path)), pattern):
                return True

        return False

    def get_files_in_area(self, area: FocusArea, max_files: int = 1000) -> List[Path]:
        """
        Get all files matching an area's patterns.

        Args:
            area: Focus area
            max_files: Maximum files to return

        Returns:
            List of file paths
        """
        files = []
        exclude_patterns = area.patterns.get("exclude", [])

        for include_pattern in area.patterns.get("include", []):
            # Use glob to find matching files
            for file_path in self.project_root.glob(include_pattern):
                if not file_path.is_file():
                    continue

                # Get relative path
                try:
                    rel_path = file_path.relative_to(self.project_root)
                except ValueError:
                    continue

                # Check exclude patterns
                excluded = False
                for exclude_pattern in exclude_patterns:
                    if fnmatch.fnmatch(str(rel_path), exclude_pattern):
                        excluded = True
                        break

                if not excluded:
                    files.append(rel_path)
                    if len(files) >= max_files:
                        return files

        return files

    # Private Helper Methods

    def _read_json(self, file_path: Path) -> Dict[str, Any]:
        """Read JSON file."""
        with open(file_path, 'r') as f:
            return json.load(f)

    def _write_json(self, file_path: Path, data: Dict[str, Any]) -> None:
        """Write JSON file."""
        file_path.parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)

    def _update_area_index(self, area: FocusArea) -> None:
        """Update area index with area info."""
        index_file = self.focus_root / "areas" / "index.json"
        index = self._read_json(index_file)

        # Remove existing entry
        index["areas"] = [a for a in index["areas"] if a["id"] != area.id]

        # Add updated entry
        index["areas"].append({
            "id": area.id,
            "name": area.name,
            "type": area.type,
            "created": area.created,
            "lastFocused": area.lastFocused,
            "focusCount": area.focusCount,
            "tags": area.metadata.get("tags", [])
        })

        index["totalAreas"] = len(index["areas"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self._write_json(index_file, index)

    def _update_session_index(self, session: Session) -> None:
        """Update session index with session info."""
        index_file = self.focus_root / "sessions" / "index.json"
        index = self._read_json(index_file)

        # Remove existing entry
        index["sessions"] = [s for s in index["sessions"] if s["sessionId"] != session.sessionId]

        # Add updated entry
        index["sessions"].append({
            "sessionId": session.sessionId,
            "areaId": session.areaId,
            "startedAt": session.startedAt,
            "endedAt": session.endedAt,
            "duration": session.duration,
            "summary": session.summary,
            "filesModified": len(session.activity.get("filesModified", [])),
            "tags": session.tags
        })

        # Keep only last 100 sessions in index
        index["sessions"].sort(key=lambda s: s["startedAt"], reverse=True)
        index["sessions"] = index["sessions"][:100]

        index["totalSessions"] = len(index["sessions"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self._write_json(index_file, index)

    # Dig History Operations

    def get_dig_history(self, limit: Optional[int] = None) -> List[DigHistoryEntry]:
        """
        Get dig navigation history.

        Args:
            limit: Maximum number of entries to return (None for all)

        Returns:
            List of history entries, newest first
        """
        history_file = self.focus_root / "history" / "history.json"
        if not history_file.exists():
            return []

        history_data = self._read_json(history_file)
        entries = [DigHistoryEntry(**entry) for entry in history_data.get("entries", [])]

        # Return newest first
        entries.reverse()

        if limit:
            entries = entries[:limit]

        return entries

    def add_to_history(self, area_id: str) -> None:
        """
        Add current area transition to history.

        Args:
            area_id: Area ID being navigated to
        """
        # Get area info
        area = self.get_area(area_id)
        if not area:
            return

        # Close previous history entry if exists
        self._close_current_history_entry()

        # Get current history
        history_file = self.focus_root / "history" / "history.json"
        history_data = self._read_json(history_file)
        entries = history_data.get("entries", [])

        # Get config for max size
        config = self.load_config()
        max_size = config.get("history", {}).get("maxSize", 50)
        current_index = config.get("history", {}).get("currentIndex", -1)

        # If navigating from middle of history, truncate future entries
        if current_index >= 0 and current_index < len(entries) - 1:
            entries = entries[:current_index + 1]

        # Create new history entry
        new_entry = DigHistoryEntry(
            areaId=area_id,
            areaName=area.name,
            enteredAt=datetime.utcnow().isoformat() + "Z"
        )

        # Add to entries
        entries.append(asdict(new_entry))

        # Trim to max size (keep most recent)
        if len(entries) > max_size:
            entries = entries[-max_size:]

        # Update history file
        history_data["entries"] = entries
        history_data["totalEntries"] = len(entries)
        history_data["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self._write_json(history_file, history_data)

        # Update current index in config
        config["history"]["currentIndex"] = len(entries) - 1
        self.save_config(config)

    def navigate_back(self) -> Optional[str]:
        """
        Navigate to previous area in history.

        Returns:
            Area ID to navigate to, or None if can't go back
        """
        config = self.load_config()
        current_index = config.get("history", {}).get("currentIndex", -1)

        # Can't go back if at start or no history
        if current_index <= 0:
            return None

        # Get history
        history_file = self.focus_root / "history" / "history.json"
        history_data = self._read_json(history_file)
        entries = history_data.get("entries", [])

        if current_index >= len(entries):
            return None

        # Go back one
        new_index = current_index - 1
        prev_entry = entries[new_index]

        # Update config
        config["history"]["currentIndex"] = new_index
        self.save_config(config)

        return prev_entry["areaId"]

    def navigate_forward(self) -> Optional[str]:
        """
        Navigate to next area in history.

        Returns:
            Area ID to navigate to, or None if can't go forward
        """
        config = self.load_config()
        current_index = config.get("history", {}).get("currentIndex", -1)

        # Get history
        history_file = self.focus_root / "history" / "history.json"
        history_data = self._read_json(history_file)
        entries = history_data.get("entries", [])

        # Can't go forward if at end or no history
        if current_index < 0 or current_index >= len(entries) - 1:
            return None

        # Go forward one
        new_index = current_index + 1
        next_entry = entries[new_index]

        # Update config
        config["history"]["currentIndex"] = new_index
        self.save_config(config)

        return next_entry["areaId"]

    def get_breadcrumb_trail(self, max_items: int = 5) -> str:
        """
        Get breadcrumb trail showing recent navigation path.

        Args:
            max_items: Maximum number of items to show

        Returns:
            Breadcrumb string like "auth → api → database"
        """
        config = self.load_config()
        current_index = config.get("history", {}).get("currentIndex", -1)

        if current_index < 0:
            return ""

        # Get history
        history_file = self.focus_root / "history" / "history.json"
        history_data = self._read_json(history_file)
        entries = history_data.get("entries", [])

        if not entries:
            return ""

        # Get recent entries leading to current
        start_index = max(0, current_index - max_items + 1)
        trail_entries = entries[start_index:current_index + 1]

        # Build breadcrumb
        breadcrumbs = [entry["areaId"] for entry in trail_entries]

        if len(breadcrumbs) > max_items:
            breadcrumbs = ["..."] + breadcrumbs[-(max_items-1):]

        return " → ".join(breadcrumbs)

    def _close_current_history_entry(self) -> None:
        """Close the current history entry by setting exit time and duration."""
        config = self.load_config()
        current_index = config.get("history", {}).get("currentIndex", -1)

        if current_index < 0:
            return

        history_file = self.focus_root / "history" / "history.json"
        history_data = self._read_json(history_file)
        entries = history_data.get("entries", [])

        if current_index >= len(entries):
            return

        current_entry = entries[current_index]

        # Only close if not already closed
        if current_entry.get("exitedAt"):
            return

        # Set exit time
        now = datetime.utcnow().isoformat() + "Z"
        current_entry["exitedAt"] = now

        # Calculate duration
        entered_at = datetime.fromisoformat(current_entry["enteredAt"].replace("Z", "+00:00"))
        exited_at = datetime.fromisoformat(now.replace("Z", "+00:00"))
        duration = int((exited_at - entered_at).total_seconds())
        current_entry["duration"] = duration

        # Update
        entries[current_index] = current_entry
        history_data["entries"] = entries
        history_data["lastUpdated"] = now
        self._write_json(history_file, history_data)

    # Context Snapshot Operations

    def save_context(self, name: str, description: str = "", tags: List[str] = None) -> ContextSnapshot:
        """
        Save current context as a snapshot.

        Args:
            name: Snapshot name (unique identifier)
            description: Optional description
            tags: Optional tags for organization

        Returns:
            Created snapshot
        """
        # Get current state
        current_area_id = self.get_current_focus()
        current_area = self.get_area(current_area_id) if current_area_id else None

        # Get all bookmarks
        bookmarks_file = self.focus_root / "bookmarks" / "bookmarks.json"
        bookmarks_data = self._read_json(bookmarks_file) if bookmarks_file.exists() else {"bookmarks": []}
        
        # Get history
        history = self.get_dig_history()
        config = self.load_config()
        history_index = config.get("history", {}).get("currentIndex", -1)

        # Create snapshot
        snapshot = ContextSnapshot(
            name=name,
            description=description,
            savedAt=datetime.utcnow().isoformat() + "Z",
            currentArea=current_area_id,
            currentAreaName=current_area.name if current_area else None,
            markedSpots=bookmarks_data.get("bookmarks", []),
            digHistory=[asdict(entry) for entry in history],
            historyIndex=history_index,
            tags=tags or []
        )

        # Save snapshot
        snapshot_file = self.focus_root / "snapshots" / f"{name}.json"
        self._write_json(snapshot_file, asdict(snapshot))

        # Update index
        self._update_snapshot_index(snapshot)

        return snapshot

    def load_context(self, name: str) -> Optional[ContextSnapshot]:
        """
        Load and restore a context snapshot.

        Args:
            name: Snapshot name to load

        Returns:
            Loaded snapshot, or None if not found
        """
        snapshot_file = self.focus_root / "snapshots" / f"{name}.json"
        if not snapshot_file.exists():
            return None

        # Load snapshot
        snapshot_data = self._read_json(snapshot_file)
        snapshot = ContextSnapshot(**snapshot_data)

        # Restore current area
        if snapshot.currentArea:
            self.set_current_focus(snapshot.currentArea, skip_history=True)

        # Restore history
        history_file = self.focus_root / "history" / "history.json"
        history_data = {
            "entries": snapshot.digHistory,
            "totalEntries": len(snapshot.digHistory),
            "lastUpdated": datetime.utcnow().isoformat() + "Z"
        }
        self._write_json(history_file, history_data)

        # Restore history index
        config = self.load_config()
        config["history"]["currentIndex"] = snapshot.historyIndex
        self.save_config(config)

        # Restore bookmarks
        bookmarks_file = self.focus_root / "bookmarks" / "bookmarks.json"
        bookmarks_data = {
            "bookmarks": snapshot.markedSpots,
            "totalBookmarks": len(snapshot.markedSpots),
            "lastUpdated": datetime.utcnow().isoformat() + "Z"
        }
        self._write_json(bookmarks_file, bookmarks_data)

        return snapshot

    def list_contexts(self) -> List[ContextSnapshot]:
        """
        List all saved context snapshots.

        Returns:
            List of snapshots, newest first
        """
        snapshots_dir = self.focus_root / "snapshots"
        if not snapshots_dir.exists():
            return []

        snapshots = []
        for snapshot_file in snapshots_dir.glob("*.json"):
            if snapshot_file.name == "index.json":
                continue
            data = self._read_json(snapshot_file)
            snapshots.append(ContextSnapshot(**data))

        # Sort by saved time (newest first)
        snapshots.sort(key=lambda s: s.savedAt, reverse=True)
        return snapshots

    def delete_context(self, name: str) -> bool:
        """
        Delete a context snapshot.

        Args:
            name: Snapshot name to delete

        Returns:
            True if deleted, False if not found
        """
        snapshot_file = self.focus_root / "snapshots" / f"{name}.json"
        if not snapshot_file.exists():
            return False

        snapshot_file.unlink()

        # Update index
        index_file = self.focus_root / "snapshots" / "index.json"
        index = self._read_json(index_file)
        index["snapshots"] = [s for s in index["snapshots"] if s["name"] != name]
        index["totalSnapshots"] = len(index["snapshots"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"
        self._write_json(index_file, index)

        return True

    def _update_snapshot_index(self, snapshot: ContextSnapshot) -> None:
        """Update snapshot index."""
        index_file = self.focus_root / "snapshots" / "index.json"
        index = self._read_json(index_file)

        # Remove existing entry
        index["snapshots"] = [s for s in index["snapshots"] if s["name"] != snapshot.name]

        # Add updated entry
        index["snapshots"].append({
            "name": snapshot.name,
            "description": snapshot.description,
            "savedAt": snapshot.savedAt,
            "currentArea": snapshot.currentArea,
            "currentAreaName": snapshot.currentAreaName,
            "tags": snapshot.tags
        })

        # Sort by saved time (newest first)
        index["snapshots"].sort(key=lambda s: s["savedAt"], reverse=True)

        index["totalSnapshots"] = len(index["snapshots"])
        index["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self._write_json(index_file, index)

    # Smart Suggestions Operations

    def get_area_suggestions(self, area_id: Optional[str] = None, limit: int = 5) -> List[AreaSuggestion]:
        """
        Get smart suggestions for areas to explore next.

        Args:
            area_id: Area to get suggestions for (uses current if None)
            limit: Maximum number of suggestions to return

        Returns:
            List of suggested areas, sorted by relevance
        """
        if not area_id:
            area_id = self.get_current_focus()

        if not area_id:
            return []

        area = self.get_area(area_id)
        if not area:
            return []

        suggestions = []
        all_areas = self.list_areas()

        # 1. Import-based suggestions
        import_suggestions = self._get_import_suggestions(area, all_areas)
        suggestions.extend(import_suggestions)

        # 2. Naming pattern suggestions
        naming_suggestions = self._get_naming_suggestions(area, all_areas)
        suggestions.extend(naming_suggestions)

        # 3. Frequent co-navigation suggestions
        history_suggestions = self._get_history_suggestions(area, all_areas)
        suggestions.extend(history_suggestions)

        # Remove duplicates and current area
        seen = set()
        unique_suggestions = []
        for suggestion in suggestions:
            if suggestion.areaId != area_id and suggestion.areaId not in seen:
                seen.add(suggestion.areaId)
                unique_suggestions.append(suggestion)

        # Sort by score (highest first)
        unique_suggestions.sort(key=lambda s: s.score, reverse=True)

        return unique_suggestions[:limit]

    def _get_import_suggestions(self, area: FocusArea, all_areas: List[FocusArea]) -> List[AreaSuggestion]:
        """Find areas based on import relationships."""
        suggestions = []

        try:
            # Analyze imports in the current area
            area_imports = self._analyze_imports(area.path)

            # Find areas that match import patterns
            for other_area in all_areas:
                if other_area.id == area.id:
                    continue

                # Check if other area's path appears in imports
                other_path = Path(other_area.path)
                for import_path in area_imports:
                    if str(other_path.name) in import_path or other_area.id.replace("-", "_") in import_path:
                        suggestions.append(AreaSuggestion(
                            areaId=other_area.id,
                            areaName=other_area.name,
                            reason=f"Imported by {area.name}",
                            score=0.9,
                            relationType="imports"
                        ))
                        break

        except Exception:
            pass  # Silently fail on import analysis errors

        return suggestions

    def _get_naming_suggestions(self, area: FocusArea, all_areas: List[FocusArea]) -> List[AreaSuggestion]:
        """Find areas with similar naming patterns."""
        suggestions = []

        # Extract keywords from current area name
        keywords = set(area.name.lower().split())
        area_id_parts = set(area.id.split("-"))

        for other_area in all_areas:
            if other_area.id == area.id:
                continue

            # Check name similarity
            other_keywords = set(other_area.name.lower().split())
            other_id_parts = set(other_area.id.split("-"))

            # Calculate similarity score
            name_overlap = len(keywords & other_keywords)
            id_overlap = len(area_id_parts & other_id_parts)

            if name_overlap > 0 or id_overlap > 0:
                score = (name_overlap * 0.6 + id_overlap * 0.4) / max(len(keywords), len(area_id_parts))
                score = min(score, 0.7)  # Cap at 0.7 for naming matches

                if score > 0.3:
                    suggestions.append(AreaSuggestion(
                        areaId=other_area.id,
                        areaName=other_area.name,
                        reason=f"Similar to {area.name}",
                        score=score,
                        relationType="naming"
                    ))

        return suggestions

    def _get_history_suggestions(self, area: FocusArea, all_areas: List[FocusArea]) -> List[AreaSuggestion]:
        """Find areas frequently visited together."""
        suggestions = []

        try:
            # Get dig history
            history = self.get_dig_history(limit=50)

            # Count co-occurrences (areas visited near current area)
            co_occurrences = {}
            for i, entry in enumerate(history):
                if entry.areaId == area.id:
                    # Look at areas before and after
                    for offset in [-2, -1, 1, 2]:
                        idx = i + offset
                        if 0 <= idx < len(history):
                            other_id = history[idx].areaId
                            if other_id != area.id:
                                co_occurrences[other_id] = co_occurrences.get(other_id, 0) + 1

            # Create suggestions from frequent co-occurrences
            for other_area in all_areas:
                if other_area.id in co_occurrences:
                    count = co_occurrences[other_area.id]
                    if count >= 2:  # Visited together at least twice
                        score = min(0.5 + (count * 0.1), 0.8)  # Score 0.5-0.8
                        suggestions.append(AreaSuggestion(
                            areaId=other_area.id,
                            areaName=other_area.name,
                            reason=f"Frequently visited together",
                            score=score,
                            relationType="frequent"
                        ))

        except Exception:
            pass  # Silently fail on history analysis errors

        return suggestions

    def _analyze_imports(self, area_path: str) -> List[str]:
        """
        Analyze import statements in an area's files.

        Returns:
            List of imported module/file names
        """
        imports = []
        area_dir = Path(area_path)

        if not area_dir.exists():
            return imports

        try:
            # Get language from directory
            python_files = list(area_dir.glob("**/*.py"))
            js_files = list(area_dir.glob("**/*.js")) + list(area_dir.glob("**/*.jsx"))
            ts_files = list(area_dir.glob("**/*.ts")) + list(area_dir.glob("**/*.tsx"))

            # Analyze Python imports
            for py_file in python_files[:10]:  # Limit to first 10 files
                try:
                    content = py_file.read_text()
                    # Simple regex for Python imports
                    import re
                    matches = re.findall(r'(?:from|import)\s+([\w.]+)', content)
                    imports.extend(matches)
                except Exception:
                    continue

            # Analyze JS/TS imports
            for js_file in (js_files + ts_files)[:10]:  # Limit to first 10 files
                try:
                    content = js_file.read_text()
                    # Simple regex for JS/TS imports
                    import re
                    matches = re.findall(r'from\s+[\'"](.+?)[\'"]', content)
                    imports.extend(matches)
                except Exception:
                    continue

        except Exception:
            pass

        return imports

    # Team Awareness Operations

    def _get_user_id(self) -> tuple[str, str]:
        """
        Get user identifier for team activity.

        Returns:
            Tuple of (userId, userName)
        """
        import os
        import subprocess

        # Try to get from git config
        try:
            user_email = subprocess.check_output(
                ["git", "config", "user.email"],
                cwd=self.project_root,
                stderr=subprocess.DEVNULL
            ).decode().strip()
            user_name = subprocess.check_output(
                ["git", "config", "user.name"],
                cwd=self.project_root,
                stderr=subprocess.DEVNULL
            ).decode().strip()
            return (user_email, user_name)
        except Exception:
            pass

        # Fall back to environment variables
        user = os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"
        hostname = os.environ.get("HOSTNAME") or "localhost"
        return (f"{user}@{hostname}", user)

    def broadcast_activity(self) -> None:
        """
        Broadcast current activity to team.

        Writes current dig state to team/ directory so teammates can see
        what you're working on.
        """
        user_id, user_name = self._get_user_id()

        # Get current state
        current_area_id = self.get_current_focus()
        current_area = self.get_area(current_area_id) if current_area_id else None
        current_session = self.get_current_session()

        # Get recent bookmarks
        bookmarks_file = self.focus_root / "bookmarks" / "bookmarks.json"
        bookmarks_data = self._read_json(bookmarks_file) if bookmarks_file.exists() else {"bookmarks": []}
        recent_marks = [b["name"] for b in bookmarks_data.get("bookmarks", [])[-5:]]

        # Get recent areas from history
        history = self.get_dig_history(limit=5)
        recent_areas = [entry.areaName for entry in history]

        # Create activity object
        activity = TeamActivity(
            userId=user_id,
            userName=user_name,
            currentArea=current_area_id,
            currentAreaName=current_area.name if current_area else None,
            lastActive=datetime.utcnow().isoformat() + "Z",
            sessionStart=current_session.startedAt if current_session else None,
            recentMarks=recent_marks,
            recentAreas=recent_areas
        )

        # Write to team directory
        # Use sanitized user ID as filename
        safe_user_id = user_id.replace("@", "_at_").replace(".", "_")
        activity_file = self.focus_root / "team" / f"{safe_user_id}.json"
        self._write_json(activity_file, asdict(activity))

    def get_team_activity(self, max_age_hours: int = 24) -> List[TeamActivity]:
        """
        Get recent team activity.

        Args:
            max_age_hours: Only include activity from last N hours

        Returns:
            List of team members' activity, sorted by most recent
        """
        team_dir = self.focus_root / "team"
        if not team_dir.exists():
            return []

        activities = []
        cutoff_time = datetime.utcnow() - timedelta(hours=max_age_hours)

        for activity_file in team_dir.glob("*.json"):
            try:
                data = self._read_json(activity_file)
                activity = TeamActivity(**data)

                # Check if recent enough
                last_active = datetime.fromisoformat(activity.lastActive.replace('Z', '+00:00'))
                if last_active.replace(tzinfo=None) > cutoff_time:
                    activities.append(activity)
            except Exception:
                continue  # Skip invalid activity files

        # Sort by most recent first
        activities.sort(key=lambda a: a.lastActive, reverse=True)
        return activities

    def get_teammates_in_area(self, area_id: Optional[str] = None) -> List[TeamActivity]:
        """
        Get teammates currently digging in the same area.

        Args:
            area_id: Area to check (uses current if None)

        Returns:
            List of teammates in the area
        """
        if not area_id:
            area_id = self.get_current_focus()

        if not area_id:
            return []

        all_activity = self.get_team_activity(max_age_hours=8)  # Active in last 8 hours
        my_user_id, _ = self._get_user_id()

        # Filter to same area, excluding self
        teammates = [
            activity for activity in all_activity
            if activity.currentArea == area_id and activity.userId != my_user_id
        ]

        return teammates

    # Knowledge Capture Operations

    def add_note(self, area_id: str, note: str, tags: List[str] = None) -> AreaNote:
        """
        Add a knowledge note to an area.

        Args:
            area_id: Area to add note to
            note: The note content
            tags: Optional tags for categorization

        Returns:
            Created note
        """
        import uuid

        # Get user identity
        user_id, user_name = self._get_user_id()

        # Create note
        note_id = str(uuid.uuid4())[:8]  # Short UUID
        timestamp = datetime.utcnow().isoformat() + "Z"

        area_note = AreaNote(
            id=note_id,
            author=user_id,
            authorName=user_name,
            timestamp=timestamp,
            note=note,
            tags=tags or []
        )

        # Load area
        area = self.get_area(area_id)
        if not area:
            raise ValueError(f"Area '{area_id}' not found")

        # Load existing notes
        notes_file = self.focus_root / "areas" / f"{area_id}.notes.json"
        if notes_file.exists():
            notes_data = self._read_json(notes_file)
        else:
            notes_data = {"areaId": area_id, "notes": []}

        # Add note
        notes_data["notes"].append(asdict(area_note))
        notes_data["totalNotes"] = len(notes_data["notes"])
        notes_data["lastUpdated"] = timestamp

        # Save
        self._write_json(notes_file, notes_data)

        return area_note

    def get_notes(self, area_id: str) -> List[AreaNote]:
        """
        Get all notes for an area.

        Args:
            area_id: Area to get notes for

        Returns:
            List of notes, sorted by newest first
        """
        notes_file = self.focus_root / "areas" / f"{area_id}.notes.json"
        if not notes_file.exists():
            return []

        notes_data = self._read_json(notes_file)
        notes = [AreaNote(**n) for n in notes_data.get("notes", [])]

        # Sort by timestamp (newest first)
        notes.sort(key=lambda n: n.timestamp, reverse=True)
        return notes

    def delete_note(self, area_id: str, note_id: str) -> bool:
        """
        Delete a note from an area.

        Args:
            area_id: Area the note belongs to
            note_id: ID of note to delete

        Returns:
            True if deleted, False if not found
        """
        notes_file = self.focus_root / "areas" / f"{area_id}.notes.json"
        if not notes_file.exists():
            return False

        notes_data = self._read_json(notes_file)
        notes = notes_data.get("notes", [])

        # Filter out the note to delete
        original_count = len(notes)
        notes_data["notes"] = [n for n in notes if n["id"] != note_id]

        if len(notes_data["notes"]) == original_count:
            return False  # Note not found

        notes_data["totalNotes"] = len(notes_data["notes"])
        notes_data["lastUpdated"] = datetime.utcnow().isoformat() + "Z"

        self._write_json(notes_file, notes_data)
        return True

    def generate_wiki(self, output_file: Optional[Path] = None) -> str:
        """
        Generate a markdown wiki from all areas and notes.

        Args:
            output_file: Optional file path to write wiki to

        Returns:
            Wiki markdown content
        """
        wiki_lines = []

        # Header
        wiki_lines.append("# ContextDigger Knowledge Wiki")
        wiki_lines.append("")
        wiki_lines.append(f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
        wiki_lines.append("")
        wiki_lines.append("---")
        wiki_lines.append("")

        # Table of contents
        areas = self.list_areas()
        wiki_lines.append("## Table of Contents")
        wiki_lines.append("")
        for area in areas:
            # Sanitize area name for markdown link
            link = area.id.lower().replace(" ", "-")
            wiki_lines.append(f"- [{area.name}](#{link})")
        wiki_lines.append("")
        wiki_lines.append("---")
        wiki_lines.append("")

        # Area sections
        for area in areas:
            wiki_lines.append(f"## {area.name}")
            wiki_lines.append("")
            wiki_lines.append(f"**ID:** `{area.id}`")
            wiki_lines.append("")
            wiki_lines.append(f"**Description:** {area.description}")
            wiki_lines.append("")

            # Metadata
            if area.metadata:
                lang = area.metadata.get("language", area.metadata.get("type"))
                if lang:
                    wiki_lines.append(f"**Language:** {lang}")
                if area.metadata.get("framework"):
                    wiki_lines.append(f"**Framework:** {area.metadata['framework']}")
                if area.metadata.get("fileCount"):
                    wiki_lines.append(f"**Files:** ~{area.metadata['fileCount']}")
                wiki_lines.append("")

            # Path
            wiki_lines.append(f"**Path:** `{area.path}`")
            wiki_lines.append("")

            # Dependencies
            if area.dependencies:
                wiki_lines.append(f"**Dependencies:** {', '.join(area.dependencies)}")
                wiki_lines.append("")

            # Notes
            notes = self.get_notes(area.id)
            if notes:
                wiki_lines.append("### Knowledge Notes")
                wiki_lines.append("")
                for note in notes:
                    timestamp = datetime.fromisoformat(note.timestamp.replace('Z', '+00:00'))
                    date_str = timestamp.strftime("%Y-%m-%d")

                    wiki_lines.append(f"**Note by {note.authorName}** ({date_str})")
                    if note.tags:
                        tags_str = ", ".join(f"`{tag}`" for tag in note.tags)
                        wiki_lines.append(f"*Tags: {tags_str}*")
                    wiki_lines.append("")
                    wiki_lines.append(note.note)
                    wiki_lines.append("")

            # Stats
            wiki_lines.append(f"**Focus Count:** {area.focusCount} times")
            if area.lastFocused:
                last = datetime.fromisoformat(area.lastFocused.replace('Z', '+00:00'))
                wiki_lines.append(f"**Last Focused:** {last.strftime('%Y-%m-%d %H:%M')}")
            wiki_lines.append("")

            wiki_lines.append("---")
            wiki_lines.append("")

        # Join and optionally write
        wiki_content = "\n".join(wiki_lines)

        if output_file:
            output_path = Path(output_file)
            output_path.write_text(wiki_content)

        return wiki_content

    # Dependency Mapping Operations

    def build_dependency_graph(self) -> Dict[str, Dict[str, Any]]:
        """
        Build complete dependency graph for all areas.

        Returns:
            Dictionary mapping area IDs to their dependency information
        """
        all_areas = self.list_areas()
        dep_graph = {}

        # Analyze each area
        for area in all_areas:
            area_deps = {
                "areaId": area.id,
                "areaName": area.name,
                "dependencies": [],
                "dependents": []
            }

            # Get imports for this area
            imports = self._analyze_imports(area.path)

            # Find which other areas are imported
            for other_area in all_areas:
                if other_area.id == area.id:
                    continue

                # Check if this area imports the other area
                other_path_parts = Path(other_area.path).parts
                other_id_normalized = other_area.id.replace("-", "_")

                matching_imports = []
                for imp in imports:
                    # Check if import matches this area
                    if other_id_normalized in imp or any(part in imp for part in other_path_parts[-2:]):
                        matching_imports.append(imp)

                if matching_imports:
                    # Calculate strength based on number of imports
                    strength = min(0.5 + (len(matching_imports) * 0.1), 1.0)

                    dep_info = {
                        "targetAreaId": other_area.id,
                        "targetAreaName": other_area.name,
                        "dependencyType": "imports",
                        "strength": strength,
                        "references": matching_imports[:5]  # Limit to 5 examples
                    }
                    area_deps["dependencies"].append(dep_info)

            dep_graph[area.id] = area_deps

        # Now calculate dependents (reverse dependencies)
        for area_id, area_data in dep_graph.items():
            for dep in area_data["dependencies"]:
                target_id = dep["targetAreaId"]
                if target_id in dep_graph:
                    # Add this area as a dependent of the target
                    dependent_info = {
                        "targetAreaId": area_id,
                        "targetAreaName": area_data["areaName"],
                        "dependencyType": dep["dependencyType"],
                        "strength": dep["strength"],
                        "references": dep["references"]
                    }
                    dep_graph[target_id]["dependents"].append(dependent_info)

        # Save the graph
        graph_file = self.focus_root / "dependencies" / "graph.json"
        graph_file.parent.mkdir(parents=True, exist_ok=True)
        self._write_json(graph_file, {
            "graph": dep_graph,
            "generatedAt": datetime.utcnow().isoformat() + "Z",
            "totalAreas": len(dep_graph)
        })

        return dep_graph

    def get_dependencies(self, area_id: str, use_cache: bool = True) -> List[DependencyInfo]:
        """
        Get what an area depends on.

        Args:
            area_id: Area to analyze
            use_cache: Use cached graph if available

        Returns:
            List of dependencies
        """
        # Load or build graph
        graph_file = self.focus_root / "dependencies" / "graph.json"
        if use_cache and graph_file.exists():
            graph_data = self._read_json(graph_file)
            dep_graph = graph_data.get("graph", {})
        else:
            dep_graph = self.build_dependency_graph()

        if area_id not in dep_graph:
            return []

        # Convert to DependencyInfo objects
        deps = []
        for dep_data in dep_graph[area_id].get("dependencies", []):
            deps.append(DependencyInfo(**dep_data))

        # Sort by strength (strongest first)
        deps.sort(key=lambda d: d.strength, reverse=True)
        return deps

    def get_dependents(self, area_id: str, use_cache: bool = True) -> List[DependencyInfo]:
        """
        Get what depends on an area.

        Args:
            area_id: Area to analyze
            use_cache: Use cached graph if available

        Returns:
            List of dependents
        """
        # Load or build graph
        graph_file = self.focus_root / "dependencies" / "graph.json"
        if use_cache and graph_file.exists():
            graph_data = self._read_json(graph_file)
            dep_graph = graph_data.get("graph", {})
        else:
            dep_graph = self.build_dependency_graph()

        if area_id not in dep_graph:
            return []

        # Convert to DependencyInfo objects
        dependents = []
        for dep_data in dep_graph[area_id].get("dependents", []):
            dependents.append(DependencyInfo(**dep_data))

        # Sort by strength (strongest first)
        dependents.sort(key=lambda d: d.strength, reverse=True)
        return dependents

    def calculate_impact(self, area_id: str) -> ImpactAnalysis:
        """
        Calculate the impact of changing an area.

        Args:
            area_id: Area to analyze

        Returns:
            Impact analysis with affected areas
        """
        area = self.get_area(area_id)
        if not area:
            raise ValueError(f"Area '{area_id}' not found")

        # Get direct dependents
        direct_deps = self.get_dependents(area_id)
        direct_ids = [d.targetAreaId for d in direct_deps]

        # Get indirect dependents (things that depend on things that depend on this)
        indirect_ids = set()
        for direct_id in direct_ids:
            indirect_deps = self.get_dependents(direct_id)
            for indirect_dep in indirect_deps:
                if indirect_dep.targetAreaId != area_id and indirect_dep.targetAreaId not in direct_ids:
                    indirect_ids.add(indirect_dep.targetAreaId)

        # Calculate impact score
        # Based on number of direct + indirect dependents and their strengths
        total_dependents = len(direct_ids) + len(indirect_ids)
        avg_strength = sum(d.strength for d in direct_deps) / len(direct_deps) if direct_deps else 0

        impact_score = min((total_dependents * 0.1) + (avg_strength * 0.5), 1.0)

        # Determine risk level
        if impact_score > 0.7 or total_dependents > 5:
            risk_level = "high"
        elif impact_score > 0.4 or total_dependents > 2:
            risk_level = "medium"
        else:
            risk_level = "low"

        return ImpactAnalysis(
            areaId=area_id,
            areaName=area.name,
            directDependents=direct_ids,
            indirectDependents=list(indirect_ids),
            impactScore=impact_score,
            riskLevel=risk_level
        )

    def visualize_dependencies(self, focus_area: Optional[str] = None, max_depth: int = 2) -> str:
        """
        Create ASCII visualization of dependency graph.

        Args:
            focus_area: Optional area to focus visualization on
            max_depth: Maximum depth for traversal

        Returns:
            ASCII art dependency graph
        """
        # Build graph
        dep_graph = self.build_dependency_graph()

        if not dep_graph:
            return "No dependencies found"

        lines = []
        lines.append("Dependency Map")
        lines.append("="*60)
        lines.append("")

        if focus_area:
            # Focused view - show specific area and its connections
            if focus_area not in dep_graph:
                return f"Area '{focus_area}' not found"

            area_data = dep_graph[focus_area]
            lines.append(f"Focus: {area_data['areaName']}")
            lines.append("")

            # Show dependencies
            if area_data["dependencies"]:
                lines.append("Dependencies (what this needs):")
                for dep in area_data["dependencies"][:10]:
                    strength_bar = "█" * int(dep["strength"] * 5)
                    lines.append(f"  └─→ {dep['targetAreaName']} {strength_bar}")
                lines.append("")

            # Show dependents
            if area_data["dependents"]:
                lines.append("Dependents (what needs this):")
                for dep in area_data["dependents"][:10]:
                    strength_bar = "█" * int(dep["strength"] * 5)
                    lines.append(f"  ←─┘ {dep['targetAreaName']} {strength_bar}")
                lines.append("")

        else:
            # Overview - show all areas and their connection counts
            lines.append("Overview (all areas):")
            lines.append("")

            for area_id, area_data in sorted(dep_graph.items(), key=lambda x: len(x[1]["dependents"]), reverse=True):
                dep_count = len(area_data["dependencies"])
                dependent_count = len(area_data["dependents"])

                # Visual indicator based on connectivity
                if dependent_count > 5:
                    indicator = "🔴"  # High impact
                elif dependent_count > 2:
                    indicator = "🟡"  # Medium impact
                else:
                    indicator = "🟢"  # Low impact

                lines.append(f"{indicator} {area_data['areaName']}")
                lines.append(f"   Depends on: {dep_count} areas")
                lines.append(f"   Depended by: {dependent_count} areas")
                lines.append("")

        lines.append("="*60)
        lines.append("")
        lines.append("Legend:")
        lines.append("  🔴 High impact (many dependents)")
        lines.append("  🟡 Medium impact")
        lines.append("  🟢 Low impact")
        lines.append("  █ Dependency strength")

        return "\n".join(lines)

    # Hot Spots Detection Operations

    def analyze_git_activity(self, days: int = 30) -> Dict[str, Dict[str, Any]]:
        """
        Analyze git activity for all areas.

        Args:
            days: Number of days to analyze

        Returns:
            Dictionary mapping area IDs to activity data
        """
        import subprocess
        from collections import defaultdict

        activity = {}
        all_areas = self.list_areas()

        # Get git log for the time period
        since_date = f"{days} days ago"

        try:
            # Get all commits in time period with stats
            result = subprocess.run(
                ["git", "log", f"--since={since_date}", "--numstat", "--pretty=format:%H|%an|%s"],
                cwd=self.project_root,
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                return {}

            # Parse git log output
            current_commit = None
            current_author = None
            current_message = None

            for line in result.stdout.split('\n'):
                if '|' in line and not line.startswith('\t'):
                    # Commit line: hash|author|subject
                    parts = line.split('|', 2)
                    if len(parts) == 3:
                        current_commit = parts[0]
                        current_author = parts[1]
                        current_message = parts[2]
                elif line.strip() and current_commit:
                    # Stats line: added  deleted  filename
                    parts = line.split('\t')
                    if len(parts) >= 3:
                        try:
                            added = int(parts[0]) if parts[0] != '-' else 0
                            deleted = int(parts[1]) if parts[1] != '-' else 0
                            filename = parts[2]

                            # Find which area this file belongs to
                            file_path = Path(filename)
                            for area in all_areas:
                                area_path = Path(area.path)
                                try:
                                    file_path.relative_to(area_path)
                                    # File is in this area
                                    if area.id not in activity:
                                        activity[area.id] = {
                                            "commits": set(),
                                            "authors": set(),
                                            "linesAdded": 0,
                                            "linesDeleted": 0,
                                            "recentCommits": []
                                        }

                                    activity[area.id]["commits"].add(current_commit)
                                    activity[area.id]["authors"].add(current_author)
                                    activity[area.id]["linesAdded"] += added
                                    activity[area.id]["linesDeleted"] += deleted

                                    # Store recent commit messages (limit to 5)
                                    if current_message and current_message not in activity[area.id]["recentCommits"]:
                                        if len(activity[area.id]["recentCommits"]) < 5:
                                            activity[area.id]["recentCommits"].append(current_message)

                                    break
                                except ValueError:
                                    # File not in this area
                                    continue
                        except (ValueError, IndexError):
                            continue

        except Exception:
            return {}

        # Convert sets to counts
        for area_id in activity:
            activity[area_id]["commits"] = len(activity[area_id]["commits"])
            activity[area_id]["authors"] = len(activity[area_id]["authors"])

        return activity

    def get_area_complexity(self, area_id: str) -> float:
        """
        Calculate basic complexity metric for an area.

        Args:
            area_id: Area to analyze

        Returns:
            Complexity score 0-1
        """
        area = self.get_area(area_id)
        if not area:
            return 0.0

        area_path = Path(area.path)
        if not area_path.exists():
            return 0.0

        # Basic complexity based on:
        # - Number of files
        # - Total lines of code
        # - Number of imports

        file_count = 0
        total_lines = 0
        total_imports = 0

        for file_path in area_path.glob("**/*"):
            if file_path.is_file() and file_path.suffix in ['.py', '.js', '.ts', '.jsx', '.tsx']:
                file_count += 1
                try:
                    content = file_path.read_text()
                    lines = content.split('\n')
                    total_lines += len([l for l in lines if l.strip() and not l.strip().startswith('#')])

                    # Count imports
                    import_lines = [l for l in lines if l.strip().startswith(('import ', 'from '))]
                    total_imports += len(import_lines)
                except Exception:
                    continue

        # Normalize to 0-1 scale
        # High complexity = many files, many lines, many imports
        file_score = min(file_count / 50, 1.0)  # 50+ files = max
        lines_score = min(total_lines / 5000, 1.0)  # 5000+ lines = max
        imports_score = min(total_imports / 100, 1.0)  # 100+ imports = max

        complexity = (file_score + lines_score + imports_score) / 3
        return complexity

    def get_hotspots(self, days: int = 30, min_commits: int = 2) -> List[HotSpot]:
        """
        Get code hotspots based on git activity and complexity.

        Args:
            days: Number of days to analyze
            min_commits: Minimum commits to be considered a hotspot

        Returns:
            List of hotspots, sorted by temperature
        """
        # Analyze git activity
        activity = self.analyze_git_activity(days)

        hotspots = []
        all_areas = self.list_areas()

        for area in all_areas:
            area_activity = activity.get(area.id, {
                "commits": 0,
                "authors": 0,
                "linesAdded": 0,
                "linesDeleted": 0,
                "recentCommits": []
            })

            commit_count = area_activity.get("commits", 0)

            # Skip areas with low activity
            if commit_count < min_commits:
                continue

            # Calculate churn rate (commits per day)
            churn_rate = commit_count / days

            # Get complexity
            complexity = self.get_area_complexity(area.id)

            # Calculate temperature based on:
            # - Churn rate (high activity)
            # - Complexity (hard to understand)
            # - Author count (many people touching it)

            author_count = area_activity.get("authors", 0)
            lines_changed = area_activity.get("linesAdded", 0) + area_activity.get("linesDeleted", 0)

            # Temperature score
            activity_score = min(churn_rate / 2, 1.0)  # 2+ commits/day = max
            complexity_score = complexity
            collaboration_score = min(author_count / 5, 1.0)  # 5+ authors = max

            temp_score = (activity_score * 0.5) + (complexity_score * 0.3) + (collaboration_score * 0.2)

            # Determine temperature category
            if temp_score > 0.7:
                temperature = "critical"
            elif temp_score > 0.5:
                temperature = "hot"
            elif temp_score > 0.3:
                temperature = "warm"
            else:
                temperature = "cool"

            hotspot = HotSpot(
                areaId=area.id,
                areaName=area.name,
                commitCount=commit_count,
                authorCount=author_count,
                linesChanged=lines_changed,
                churnRate=round(churn_rate, 2),
                complexity=round(complexity, 2),
                temperature=temperature,
                recentCommits=area_activity.get("recentCommits", [])
            )

            hotspots.append(hotspot)

        # Sort by temperature (hottest first)
        temp_order = {"critical": 4, "hot": 3, "warm": 2, "cool": 1}
        hotspots.sort(key=lambda h: (temp_order.get(h.temperature, 0), h.commitCount), reverse=True)

        return hotspots

    # Test Coverage Operations

    def map_tests_to_areas(self) -> Dict[str, List[str]]:
        """
        Map test files to areas using naming conventions.

        Returns:
            Dictionary mapping area IDs to list of test file paths
        """
        test_mapping = {}
        all_areas = self.list_areas()

        # Common test patterns
        test_patterns = [
            "**/test_*.py",  # Python pytest
            "**/*_test.py",  # Python alternative
            "**/*.test.js",  # Jest
            "**/*.test.ts",  # Jest TypeScript
            "**/*.test.tsx", # Jest React
            "**/*.spec.js",  # Jasmine
            "**/*.spec.ts",  # Jasmine TypeScript
        ]

        for area in all_areas:
            area_path = Path(area.path)
            if not area_path.exists():
                continue

            test_files = []

            # Find test files in area
            for pattern in test_patterns:
                test_files.extend(area_path.glob(pattern))

            # Also check for test directories
            test_dirs = ["tests", "test", "__tests__", "spec"]
            for test_dir_name in test_dirs:
                test_dir = area_path / test_dir_name
                if test_dir.exists():
                    for pattern in test_patterns:
                        test_files.extend(test_dir.glob(pattern))

            # Convert to relative paths
            test_file_paths = [str(f.relative_to(self.project_root)) for f in set(test_files)]
            test_mapping[area.id] = test_file_paths

        return test_mapping

    def get_area_coverage(self, area_id: str) -> TestCoverage:
        """
        Get test coverage information for an area.

        Args:
            area_id: Area to analyze

        Returns:
            Test coverage data
        """
        area = self.get_area(area_id)
        if not area:
            raise ValueError(f"Area '{area_id}' not found")

        area_path = Path(area.path)
        if not area_path.exists():
            return TestCoverage(
                areaId=area_id,
                areaName=area.name
            )

        # Get test files for this area
        test_mapping = self.map_tests_to_areas()
        test_files = test_mapping.get(area_id, [])

        # Get all source files (non-test)
        source_extensions = ['.py', '.js', '.ts', '.jsx', '.tsx']
        source_files = []

        for ext in source_extensions:
            for file_path in area_path.glob(f"**/*{ext}"):
                # Skip test files
                if any(pattern in str(file_path) for pattern in ['test_', '_test.', '.test.', '.spec.', '/tests/', '/test/', '/__tests__/']):
                    continue
                source_files.append(file_path)

        # Count lines
        total_code_lines = 0
        total_test_lines = 0
        files_with_tests = set()
        untested_files = []

        for source_file in source_files:
            try:
                content = source_file.read_text()
                code_lines = len([l for l in content.split('\n') if l.strip() and not l.strip().startswith('#')])
                total_code_lines += code_lines

                # Check if this file has a corresponding test
                has_test = False
                source_name = source_file.stem

                for test_file in test_files:
                    if source_name in test_file or source_file.name in test_file:
                        has_test = True
                        files_with_tests.add(source_name)
                        break

                if not has_test:
                    untested_files.append(str(source_file.relative_to(self.project_root)))

            except Exception:
                continue

        # Count test lines
        for test_file_rel in test_files:
            try:
                test_path = self.project_root / test_file_rel
                content = test_path.read_text()
                test_lines = len([l for l in content.split('\n') if l.strip() and not l.strip().startswith('#')])
                total_test_lines += test_lines
            except Exception:
                continue

        # Calculate coverage (estimated based on test file existence)
        if len(source_files) > 0:
            coverage_percent = (len(files_with_tests) / len(source_files)) * 100
        else:
            coverage_percent = 0.0

        # Calculate test-to-code ratio
        if total_code_lines > 0:
            test_ratio = total_test_lines / total_code_lines
        else:
            test_ratio = 0.0

        return TestCoverage(
            areaId=area_id,
            areaName=area.name,
            coveragePercent=round(coverage_percent, 1),
            linesCovered=len(files_with_tests),
            linesTotal=len(source_files),
            testFiles=test_files,
            untestedFiles=untested_files,
            testToCodeRatio=round(test_ratio, 2)
        )

    def find_coverage_gaps(self, min_coverage: float = 70.0) -> List[TestCoverage]:
        """
        Find areas with insufficient test coverage.

        Args:
            min_coverage: Minimum acceptable coverage percentage

        Returns:
            List of areas with coverage below threshold, sorted by coverage
        """
        gaps = []
        all_areas = self.list_areas()

        for area in all_areas:
            try:
                coverage = self.get_area_coverage(area.id)

                # Only include areas with some code
                if coverage.linesTotal > 0:
                    if coverage.coveragePercent < min_coverage:
                        gaps.append(coverage)
            except Exception:
                continue

        # Sort by coverage (lowest first)
        gaps.sort(key=lambda c: c.coveragePercent)

        return gaps

    # Performance Profiling Operations

    def record_performance(
        self,
        area_id: str,
        benchmark_name: str,
        execution_time_ms: float,
        memory_usage_mb: float = 0.0,
        cpu_percent: float = 0.0,
        iterations: int = 1,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> PerformanceProfile:
        """
        Record a performance profile for an area.

        Args:
            area_id: Area identifier
            benchmark_name: Name of the benchmark or test
            execution_time_ms: Execution time in milliseconds
            memory_usage_mb: Memory usage in MB
            cpu_percent: CPU usage percentage
            iterations: Number of iterations run
            metadata: Additional custom metrics

        Returns:
            The created performance profile
        """
        area = self.get_area(area_id)
        if not area:
            raise ValueError(f"Area '{area_id}' not found")

        # Generate profile ID
        profile_id = str(uuid.uuid4())[:8]

        # Get current git commit
        git_commit = None
        try:
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                git_commit = result.stdout.strip()[:8]
        except Exception:
            pass

        # Get environment info
        environment = {
            "python": sys.version.split()[0],
            "platform": sys.platform,
            "hostname": os.uname().nodename if hasattr(os, "uname") else "unknown",
        }

        profile = PerformanceProfile(
            id=profile_id,
            areaId=area_id,
            areaName=area.name,
            timestamp=datetime.now().isoformat(),
            benchmarkName=benchmark_name,
            executionTimeMs=execution_time_ms,
            memoryUsageMb=memory_usage_mb,
            cpuPercent=cpu_percent,
            iterations=iterations,
            metadata=metadata or {},
            gitCommit=git_commit,
            environment=environment,
        )

        # Save to performance directory
        perf_dir = self.cdg_dir / "performance" / area_id
        perf_dir.mkdir(parents=True, exist_ok=True)

        # Filename: timestamp_benchmark_id.json
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_benchmark = benchmark_name.replace(" ", "_").replace("/", "_")
        filename = f"{timestamp_str}_{safe_benchmark}_{profile_id}.json"

        profile_file = perf_dir / filename
        profile_file.write_text(json.dumps(asdict(profile), indent=2))

        return profile

    def get_performance_history(
        self,
        area_id: Optional[str] = None,
        benchmark_name: Optional[str] = None,
        limit: int = 50,
    ) -> List[PerformanceProfile]:
        """
        Get performance history for an area and/or benchmark.

        Args:
            area_id: Filter by area (None for all areas)
            benchmark_name: Filter by benchmark name (None for all)
            limit: Maximum number of profiles to return

        Returns:
            List of performance profiles, newest first
        """
        profiles = []

        perf_base = self.cdg_dir / "performance"
        if not perf_base.exists():
            return profiles

        # Determine which directories to search
        if area_id:
            search_dirs = [perf_base / area_id] if (perf_base / area_id).exists() else []
        else:
            search_dirs = [d for d in perf_base.iterdir() if d.is_dir()]

        # Load all matching profiles
        for perf_dir in search_dirs:
            for profile_file in perf_dir.glob("*.json"):
                try:
                    data = json.loads(profile_file.read_text())
                    profile = PerformanceProfile(**data)

                    # Filter by benchmark name if specified
                    if benchmark_name and profile.benchmarkName != benchmark_name:
                        continue

                    profiles.append(profile)
                except Exception:
                    continue

        # Sort by timestamp (newest first)
        profiles.sort(key=lambda p: p.timestamp, reverse=True)

        return profiles[:limit]

    def compare_performance(
        self, profile_id1: str, profile_id2: str
    ) -> Dict[str, Any]:
        """
        Compare two performance profiles.

        Args:
            profile_id1: First profile ID
            profile_id2: Second profile ID

        Returns:
            Comparison data with deltas and percentages
        """
        # Find both profiles
        profile1 = None
        profile2 = None

        perf_base = self.cdg_dir / "performance"
        if not perf_base.exists():
            raise ValueError("No performance profiles found")

        for perf_dir in perf_base.iterdir():
            if not perf_dir.is_dir():
                continue

            for profile_file in perf_dir.glob("*.json"):
                try:
                    data = json.loads(profile_file.read_text())
                    if data["id"] == profile_id1:
                        profile1 = PerformanceProfile(**data)
                    elif data["id"] == profile_id2:
                        profile2 = PerformanceProfile(**data)

                    if profile1 and profile2:
                        break
                except Exception:
                    continue

            if profile1 and profile2:
                break

        if not profile1:
            raise ValueError(f"Profile '{profile_id1}' not found")
        if not profile2:
            raise ValueError(f"Profile '{profile_id2}' not found")

        # Calculate deltas
        time_delta = profile2.executionTimeMs - profile1.executionTimeMs
        time_pct = (time_delta / profile1.executionTimeMs * 100) if profile1.executionTimeMs > 0 else 0

        memory_delta = profile2.memoryUsageMb - profile1.memoryUsageMb
        memory_pct = (memory_delta / profile1.memoryUsageMb * 100) if profile1.memoryUsageMb > 0 else 0

        cpu_delta = profile2.cpuPercent - profile1.cpuPercent
        cpu_pct = (cpu_delta / profile1.cpuPercent * 100) if profile1.cpuPercent > 0 else 0

        return {
            "profile1": asdict(profile1),
            "profile2": asdict(profile2),
            "deltas": {
                "executionTimeMs": {
                    "absolute": time_delta,
                    "percent": time_pct,
                    "improved": time_delta < 0,
                },
                "memoryUsageMb": {
                    "absolute": memory_delta,
                    "percent": memory_pct,
                    "improved": memory_delta < 0,
                },
                "cpuPercent": {
                    "absolute": cpu_delta,
                    "percent": cpu_pct,
                    "improved": cpu_delta < 0,
                },
            },
        }

    def get_performance_trends(
        self, area_id: str, benchmark_name: str, days: int = 30
    ) -> Dict[str, Any]:
        """
        Analyze performance trends over time.

        Args:
            area_id: Area to analyze
            benchmark_name: Benchmark to track
            days: Number of days to analyze

        Returns:
            Trend analysis with statistics and direction
        """
        # Get historical data
        all_profiles = self.get_performance_history(
            area_id=area_id, benchmark_name=benchmark_name, limit=1000
        )

        # Filter by date range
        cutoff = datetime.now() - timedelta(days=days)
        profiles = [
            p for p in all_profiles
            if datetime.fromisoformat(p.timestamp) >= cutoff
        ]

        if not profiles:
            return {
                "areaId": area_id,
                "benchmarkName": benchmark_name,
                "dataPoints": 0,
                "trend": "unknown",
            }

        # Sort by timestamp (oldest first for trend analysis)
        profiles.sort(key=lambda p: p.timestamp)

        # Calculate statistics
        exec_times = [p.executionTimeMs for p in profiles]
        memory_usage = [p.memoryUsageMb for p in profiles if p.memoryUsageMb > 0]
        cpu_usage = [p.cpuPercent for p in profiles if p.cpuPercent > 0]

        # Simple trend detection (compare first third vs last third)
        if len(exec_times) >= 6:
            third = len(exec_times) // 3
            early_avg = sum(exec_times[:third]) / third
            late_avg = sum(exec_times[-third:]) / third

            change_pct = ((late_avg - early_avg) / early_avg * 100) if early_avg > 0 else 0

            if change_pct < -10:
                trend = "improving"  # Getting faster
            elif change_pct > 10:
                trend = "degrading"  # Getting slower
            else:
                trend = "stable"
        else:
            trend = "insufficient_data"

        return {
            "areaId": area_id,
            "benchmarkName": benchmark_name,
            "dataPoints": len(profiles),
            "dateRange": {
                "start": profiles[0].timestamp,
                "end": profiles[-1].timestamp,
            },
            "executionTime": {
                "min": min(exec_times),
                "max": max(exec_times),
                "avg": sum(exec_times) / len(exec_times),
                "latest": exec_times[-1],
            },
            "memoryUsage": {
                "min": min(memory_usage) if memory_usage else 0,
                "max": max(memory_usage) if memory_usage else 0,
                "avg": sum(memory_usage) / len(memory_usage) if memory_usage else 0,
            } if memory_usage else None,
            "cpuUsage": {
                "min": min(cpu_usage) if cpu_usage else 0,
                "max": max(cpu_usage) if cpu_usage else 0,
                "avg": sum(cpu_usage) / len(cpu_usage) if cpu_usage else 0,
            } if cpu_usage else None,
            "trend": trend,
        }

    # Context-Aware Automation Operations

    def add_automation_rule(
        self,
        name: str,
        description: str,
        trigger: str,
        action: str,
        area_pattern: str = "*",
        action_data: Optional[Dict[str, Any]] = None,
        conditions: Optional[Dict[str, Any]] = None,
    ) -> AutomationRule:
        """
        Create a new automation rule.

        Args:
            name: Rule name
            description: What this rule does
            trigger: Trigger type (on_enter, on_exit, on_mark, on_commit)
            action: Action type (notify, run_command, suggest, warn)
            area_pattern: Area ID pattern (glob), "*" for all areas
            action_data: Action-specific configuration
            conditions: Optional conditions for filtering

        Returns:
            The created automation rule
        """
        # Validate trigger
        valid_triggers = ["on_enter", "on_exit", "on_mark", "on_commit"]
        if trigger not in valid_triggers:
            raise ValueError(f"Invalid trigger: {trigger}. Must be one of {valid_triggers}")

        # Validate action
        valid_actions = ["notify", "run_command", "suggest", "warn"]
        if action not in valid_actions:
            raise ValueError(f"Invalid action: {action}. Must be one of {valid_actions}")

        # Generate rule ID
        rule_id = str(uuid.uuid4())[:8]

        rule = AutomationRule(
            id=rule_id,
            name=name,
            description=description,
            trigger=trigger,
            areaPattern=area_pattern,
            action=action,
            actionData=action_data or {},
            conditions=conditions or {},
            enabled=True,
            createdAt=datetime.now().isoformat(),
            lastTriggered=None,
            triggerCount=0,
        )

        # Save to automation directory
        auto_dir = self.cdg_dir / "automation"
        auto_dir.mkdir(parents=True, exist_ok=True)

        rule_file = auto_dir / f"{rule_id}.json"
        rule_file.write_text(json.dumps(asdict(rule), indent=2))

        return rule

    def get_automation_rules(
        self,
        trigger: Optional[str] = None,
        enabled_only: bool = False,
    ) -> List[AutomationRule]:
        """
        Get automation rules with optional filtering.

        Args:
            trigger: Filter by trigger type
            enabled_only: Only return enabled rules

        Returns:
            List of automation rules
        """
        rules = []

        auto_dir = self.cdg_dir / "automation"
        if not auto_dir.exists():
            return rules

        # Load all rules
        for rule_file in auto_dir.glob("*.json"):
            try:
                data = json.loads(rule_file.read_text())
                rule = AutomationRule(**data)

                # Apply filters
                if trigger and rule.trigger != trigger:
                    continue
                if enabled_only and not rule.enabled:
                    continue

                rules.append(rule)
            except Exception:
                continue

        # Sort by creation date (newest first)
        rules.sort(key=lambda r: r.createdAt, reverse=True)

        return rules

    def remove_automation_rule(self, rule_id: str) -> bool:
        """
        Remove an automation rule.

        Args:
            rule_id: Rule ID to remove

        Returns:
            True if removed, False if not found
        """
        auto_dir = self.cdg_dir / "automation"
        if not auto_dir.exists():
            return False

        rule_file = auto_dir / f"{rule_id}.json"
        if rule_file.exists():
            rule_file.unlink()
            return True

        return False

    def toggle_automation_rule(self, rule_id: str, enabled: Optional[bool] = None) -> AutomationRule:
        """
        Enable or disable an automation rule.

        Args:
            rule_id: Rule ID to toggle
            enabled: Set to True/False, or None to toggle

        Returns:
            Updated automation rule
        """
        auto_dir = self.cdg_dir / "automation"
        rule_file = auto_dir / f"{rule_id}.json"

        if not rule_file.exists():
            raise ValueError(f"Rule '{rule_id}' not found")

        data = json.loads(rule_file.read_text())
        rule = AutomationRule(**data)

        # Toggle or set enabled state
        if enabled is None:
            rule.enabled = not rule.enabled
        else:
            rule.enabled = enabled

        # Save updated rule
        rule_file.write_text(json.dumps(asdict(rule), indent=2))

        return rule

    def execute_automation(
        self, rule: AutomationRule, context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute an automation rule's action.

        Args:
            rule: The rule to execute
            context: Context data (area, user, etc.)

        Returns:
            Execution result with status and output
        """
        result = {
            "ruleId": rule.id,
            "ruleName": rule.name,
            "success": False,
            "output": "",
            "timestamp": datetime.now().isoformat(),
        }

        try:
            if rule.action == "notify":
                # Show notification message
                message = rule.actionData.get("message", rule.description)
                result["output"] = f"📢 {message}"
                result["success"] = True

            elif rule.action == "warn":
                # Show warning message
                message = rule.actionData.get("message", rule.description)
                result["output"] = f"⚠️  WARNING: {message}"
                result["success"] = True

            elif rule.action == "suggest":
                # Show suggestion
                suggestion = rule.actionData.get("suggestion", rule.description)
                result["output"] = f"💡 {suggestion}"
                result["success"] = True

            elif rule.action == "run_command":
                # Execute command
                command = rule.actionData.get("command", "")
                if not command:
                    result["output"] = "No command specified"
                    return result

                # Run command with timeout
                cmd_result = subprocess.run(
                    command,
                    shell=True,
                    cwd=self.project_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )

                result["output"] = cmd_result.stdout or cmd_result.stderr
                result["success"] = cmd_result.returncode == 0

            # Update rule statistics
            auto_dir = self.cdg_dir / "automation"
            rule_file = auto_dir / f"{rule.id}.json"

            if rule_file.exists():
                rule.lastTriggered = datetime.now().isoformat()
                rule.triggerCount += 1
                rule_file.write_text(json.dumps(asdict(rule), indent=2))

        except Exception as e:
            result["output"] = f"Error: {str(e)}"
            result["success"] = False

        return result

    def trigger_automations(
        self, trigger_type: str, area_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Trigger all matching automation rules.

        Args:
            trigger_type: Type of trigger (on_enter, on_exit, etc.)
            area_id: Area that triggered the automation

        Returns:
            List of execution results
        """
        results = []

        # Get matching rules
        rules = self.get_automation_rules(trigger=trigger_type, enabled_only=True)

        for rule in rules:
            # Check if area matches pattern
            if area_id and rule.areaPattern != "*":
                # Simple glob pattern matching
                import fnmatch
                if not fnmatch.fnmatch(area_id, rule.areaPattern):
                    continue

            # Check conditions
            if rule.conditions:
                # Check coverage condition
                if "min_coverage" in rule.conditions and area_id:
                    try:
                        coverage = self.get_area_coverage(area_id)
                        min_cov = rule.conditions["min_coverage"]
                        if coverage.coveragePercent >= min_cov:
                            continue  # Don't trigger if coverage is good
                    except Exception:
                        pass

                # Check complexity condition
                if "is_hotspot" in rule.conditions and area_id:
                    try:
                        hotspots = self.get_hotspots(days=30)
                        hotspot_ids = [h.areaId for h in hotspots if h.temperature in ["hot", "critical"]]
                        if area_id not in hotspot_ids:
                            continue  # Don't trigger if not a hotspot
                    except Exception:
                        pass

            # Execute the rule
            context = {
                "trigger": trigger_type,
                "area_id": area_id,
                "area_name": self.get_area(area_id).name if area_id else None,
            }

            result = self.execute_automation(rule, context)
            results.append(result)

        return results

    # Advanced Search & Query Operations

    def search_areas(self, query: str, limit: int = 20) -> List[SearchResult]:
        """
        Search across all areas by name, path, description, or tags.

        Args:
            query: Search query string
            limit: Maximum results to return

        Returns:
            List of matching search results
        """
        results = []
        query_lower = query.lower()
        all_areas = self.list_areas()

        for area in all_areas:
            score = 0.0
            matched_content = []

            # Check name (highest weight)
            if query_lower in area.name.lower():
                score += 0.5
                matched_content.append(f"Name: {area.name}")

            # Check area ID
            if query_lower in area.id.lower():
                score += 0.3
                matched_content.append(f"ID: {area.id}")

            # Check path
            if query_lower in area.path.lower():
                score += 0.2
                matched_content.append(f"Path: {area.path}")

            # Check description
            if area.description and query_lower in area.description.lower():
                score += 0.3
                matched_content.append(f"Description: {area.description}")

            # Check tags
            for tag in area.tags:
                if query_lower in tag.lower():
                    score += 0.2
                    matched_content.append(f"Tag: {tag}")
                    break

            if score > 0:
                result = SearchResult(
                    type="area",
                    id=area.id,
                    title=area.name,
                    content="; ".join(matched_content),
                    areaId=area.id,
                    areaName=area.name,
                    timestamp=area.createdAt,
                    score=min(score, 1.0),
                    metadata={
                        "path": area.path,
                        "tags": area.tags,
                    },
                )
                results.append(result)

        # Sort by score (highest first)
        results.sort(key=lambda r: r.score, reverse=True)

        return results[:limit]

    def search_notes(self, query: str, area_id: Optional[str] = None, limit: int = 20) -> List[SearchResult]:
        """
        Search across knowledge notes.

        Args:
            query: Search query string
            area_id: Filter by area (None for all)
            limit: Maximum results to return

        Returns:
            List of matching search results
        """
        results = []
        query_lower = query.lower()

        # Determine which areas to search
        if area_id:
            areas_to_search = [self.get_area(area_id)] if self.get_area(area_id) else []
        else:
            areas_to_search = self.list_areas()

        for area in areas_to_search:
            notes = self.get_notes(area.id)

            for note in notes:
                score = 0.0
                matched_content = []

                # Check note content
                if query_lower in note.note.lower():
                    score += 0.6
                    # Extract context around match
                    idx = note.note.lower().find(query_lower)
                    start = max(0, idx - 40)
                    end = min(len(note.note), idx + len(query) + 40)
                    snippet = "..." + note.note[start:end] + "..."
                    matched_content.append(snippet)

                # Check tags
                for tag in note.tags:
                    if query_lower in tag.lower():
                        score += 0.3
                        matched_content.append(f"Tag: {tag}")
                        break

                # Check author
                if query_lower in note.authorName.lower():
                    score += 0.1
                    matched_content.append(f"Author: {note.authorName}")

                if score > 0:
                    result = SearchResult(
                        type="note",
                        id=note.id,
                        title=f"Note in {area.name}",
                        content="; ".join(matched_content),
                        areaId=area.id,
                        areaName=area.name,
                        timestamp=note.timestamp,
                        score=min(score, 1.0),
                        metadata={
                            "author": note.authorName,
                            "tags": note.tags,
                        },
                    )
                    results.append(result)

        # Sort by score (highest first)
        results.sort(key=lambda r: r.score, reverse=True)

        return results[:limit]

    def search_bookmarks(self, query: str, area_id: Optional[str] = None, limit: int = 20) -> List[SearchResult]:
        """
        Search across bookmarks.

        Args:
            query: Search query string
            area_id: Filter by area (None for all)
            limit: Maximum results to return

        Returns:
            List of matching search results
        """
        results = []
        query_lower = query.lower()

        # Determine which areas to search
        if area_id:
            areas_to_search = [self.get_area(area_id)] if self.get_area(area_id) else []
        else:
            areas_to_search = self.list_areas()

        for area in areas_to_search:
            marks = self.list_bookmarks(area.id)

            for mark in marks:
                score = 0.0
                matched_content = []

                # Check label
                if mark.label and query_lower in mark.label.lower():
                    score += 0.5
                    matched_content.append(f"Label: {mark.label}")

                # Check file path
                if query_lower in mark.filePath.lower():
                    score += 0.3
                    matched_content.append(f"File: {mark.filePath}")

                # Check context
                if mark.context and query_lower in mark.context.lower():
                    score += 0.2
                    matched_content.append(f"Context: {mark.context[:100]}...")

                if score > 0:
                    location = f"{mark.filePath}"
                    if mark.lineNumber:
                        location += f":{mark.lineNumber}"

                    result = SearchResult(
                        type="bookmark",
                        id=mark.id,
                        title=mark.label or location,
                        content="; ".join(matched_content),
                        areaId=area.id,
                        areaName=area.name,
                        timestamp=mark.createdAt,
                        score=min(score, 1.0),
                        metadata={
                            "file": mark.filePath,
                            "line": mark.lineNumber,
                        },
                    )
                    results.append(result)

        # Sort by score (highest first)
        results.sort(key=lambda r: r.score, reverse=True)

        return results[:limit]

    def advanced_search(
        self,
        query: str,
        types: Optional[List[str]] = None,
        area_id: Optional[str] = None,
        limit: int = 50,
    ) -> List[SearchResult]:
        """
        Search across all data types with unified results.

        Args:
            query: Search query string
            types: Filter by types (area, note, bookmark, snapshot, automation)
            area_id: Filter by area (None for all)
            limit: Maximum results to return

        Returns:
            Combined and sorted search results
        """
        all_results = []

        # Default to all types if not specified
        if types is None:
            types = ["area", "note", "bookmark", "snapshot", "automation"]

        # Search each type
        if "area" in types:
            all_results.extend(self.search_areas(query, limit=limit))

        if "note" in types:
            all_results.extend(self.search_notes(query, area_id=area_id, limit=limit))

        if "bookmark" in types:
            all_results.extend(self.search_bookmarks(query, area_id=area_id, limit=limit))

        if "snapshot" in types:
            # Search snapshots
            snapshots_dir = self.cdg_dir / "snapshots"
            if snapshots_dir.exists():
                query_lower = query.lower()

                for snapshot_file in snapshots_dir.glob("*.json"):
                    try:
                        data = json.loads(snapshot_file.read_text())
                        score = 0.0
                        matched_content = []

                        # Check name
                        if query_lower in data.get("name", "").lower():
                            score += 0.5
                            matched_content.append(f"Name: {data['name']}")

                        # Check description
                        if data.get("description") and query_lower in data["description"].lower():
                            score += 0.3
                            matched_content.append(f"Description: {data['description']}")

                        # Check tags
                        for tag in data.get("tags", []):
                            if query_lower in tag.lower():
                                score += 0.2
                                matched_content.append(f"Tag: {tag}")
                                break

                        if score > 0:
                            result = SearchResult(
                                type="snapshot",
                                id=data["id"],
                                title=data.get("name", f"Snapshot {data['id']}"),
                                content="; ".join(matched_content),
                                areaId=data.get("areaId"),
                                areaName=data.get("areaName"),
                                timestamp=data.get("timestamp"),
                                score=min(score, 1.0),
                                metadata={
                                    "description": data.get("description"),
                                    "tags": data.get("tags", []),
                                },
                            )
                            all_results.append(result)
                    except Exception:
                        continue

        if "automation" in types:
            # Search automation rules
            rules = self.get_automation_rules()
            query_lower = query.lower()

            for rule in rules:
                score = 0.0
                matched_content = []

                # Check name
                if query_lower in rule.name.lower():
                    score += 0.5
                    matched_content.append(f"Name: {rule.name}")

                # Check description
                if query_lower in rule.description.lower():
                    score += 0.3
                    matched_content.append(f"Description: {rule.description}")

                # Check trigger/action
                if query_lower in rule.trigger or query_lower in rule.action:
                    score += 0.2
                    matched_content.append(f"Trigger: {rule.trigger}, Action: {rule.action}")

                if score > 0:
                    result = SearchResult(
                        type="automation",
                        id=rule.id,
                        title=rule.name,
                        content="; ".join(matched_content),
                        timestamp=rule.createdAt,
                        score=min(score, 1.0),
                        metadata={
                            "trigger": rule.trigger,
                            "action": rule.action,
                            "enabled": rule.enabled,
                        },
                    )
                    all_results.append(result)

        # Sort by score (highest first)
        all_results.sort(key=lambda r: r.score, reverse=True)

        return all_results[:limit]

    # Analytics & Insights Operations

    def get_work_analytics(self, days: int = 30) -> WorkAnalytics:
        """
        Generate comprehensive work analytics and insights.

        Args:
            days: Number of days to analyze

        Returns:
            Work analytics data
        """
        analytics = WorkAnalytics()

        # Count totals
        all_areas = self.list_areas()
        analytics.totalAreas = len(all_areas)

        # Count bookmarks and notes
        for area in all_areas:
            analytics.totalBookmarks += len(self.list_bookmarks(area.id))
            analytics.totalNotes += len(self.get_notes(area.id))

        # Count snapshots
        snapshots_dir = self.cdg_dir / "snapshots"
        if snapshots_dir.exists():
            analytics.totalSnapshots = len(list(snapshots_dir.glob("*.json")))

        # Analyze history for visit counts
        history = self.get_history()
        visit_counts = {}

        for entry in history:
            area_id = entry.get("areaId")
            if area_id:
                visit_counts[area_id] = visit_counts.get(area_id, 0) + 1

        # Get most visited areas
        sorted_areas = sorted(visit_counts.items(), key=lambda x: x[1], reverse=True)
        for area_id, count in sorted_areas[:10]:
            area = self.get_area(area_id)
            if area:
                analytics.mostVisitedAreas.append({
                    "areaId": area_id,
                    "areaName": area.name,
                    "visits": count,
                })

        # Recent activity
        for entry in history[-20:]:
            area_id = entry.get("areaId")
            if area_id:
                area = self.get_area(area_id)
                if area:
                    analytics.recentActivity.append({
                        "areaId": area_id,
                        "areaName": area.name,
                        "timestamp": entry.get("timestamp", ""),
                    })

        # Areas by tag
        for area in all_areas:
            for tag in area.tags:
                analytics.areasByTag[tag] = analytics.areasByTag.get(tag, 0) + 1

        # Calculate productivity score (0-100)
        # Based on: areas created, notes written, bookmarks made, coverage
        score = 0.0

        # Areas contribute up to 30 points
        score += min(analytics.totalAreas * 3, 30)

        # Notes contribute up to 30 points
        score += min(analytics.totalNotes * 2, 30)

        # Bookmarks contribute up to 20 points
        score += min(analytics.totalBookmarks * 1, 20)

        # Snapshots contribute up to 20 points
        score += min(analytics.totalSnapshots * 2, 20)

        analytics.productivityScore = min(score, 100.0)

        # Generate insights
        insights = []

        if analytics.totalAreas == 0:
            insights.append("No areas created yet. Start by digging into a code area!")
        elif analytics.totalAreas < 5:
            insights.append(f"You have {analytics.totalAreas} areas. Consider creating more to organize your work.")
        elif analytics.totalAreas > 20:
            insights.append(f"You have {analytics.totalAreas} areas! Consider archiving inactive ones.")

        if analytics.totalNotes == 0:
            insights.append("No knowledge notes yet. Capture insights with /dig-note.")
        elif analytics.totalNotes > 10:
            insights.append(f"Great job documenting! {analytics.totalNotes} notes captured.")

        if analytics.totalBookmarks == 0:
            insights.append("No bookmarks saved. Use /dig-mark to save important locations.")
        elif analytics.totalBookmarks > 50:
            insights.append(f"Excellent bookmarking! {analytics.totalBookmarks} locations saved.")

        if analytics.mostVisitedAreas:
            top_area = analytics.mostVisitedAreas[0]
            insights.append(f"Your most visited area is '{top_area['areaName']}' with {top_area['visits']} visits.")

        if len(analytics.areasByTag) > 0:
            top_tag = max(analytics.areasByTag.items(), key=lambda x: x[1])
            insights.append(f"Most common tag: '{top_tag[0]}' ({top_tag[1]} areas)")

        analytics.insights = insights

        return analytics

    def get_time_distribution(self, days: int = 30) -> Dict[str, Any]:
        """
        Analyze time distribution across areas and activities.

        Args:
            days: Number of days to analyze

        Returns:
            Time distribution data
        """
        # Get history entries
        history = self.get_history()

        # Filter by date range
        cutoff = datetime.now() - timedelta(days=days)
        recent_history = []

        for entry in history:
            if "timestamp" in entry:
                try:
                    entry_time = datetime.fromisoformat(entry["timestamp"])
                    if entry_time >= cutoff:
                        recent_history.append(entry)
                except Exception:
                    continue

        # Calculate time per area (estimate based on session switches)
        area_time = {}
        last_area = None
        last_time = None

        for entry in recent_history:
            area_id = entry.get("areaId")
            timestamp = entry.get("timestamp")

            if not area_id or not timestamp:
                continue

            try:
                current_time = datetime.fromisoformat(timestamp)

                # If switching areas, calculate time spent
                if last_area and last_time and last_area != area_id:
                    time_diff = (current_time - last_time).total_seconds() / 60  # minutes

                    # Cap session length at 2 hours (assume breaks)
                    if time_diff < 120:
                        area_time[last_area] = area_time.get(last_area, 0) + time_diff

                last_area = area_id
                last_time = current_time
            except Exception:
                continue

        # Build distribution
        distribution = {
            "totalTime": sum(area_time.values()),
            "areaBreakdown": [],
            "period": f"{days} days",
        }

        # Sort by time spent
        sorted_areas = sorted(area_time.items(), key=lambda x: x[1], reverse=True)

        for area_id, minutes in sorted_areas:
            area = self.get_area(area_id)
            if area:
                percentage = (minutes / distribution["totalTime"] * 100) if distribution["totalTime"] > 0 else 0
                distribution["areaBreakdown"].append({
                    "areaId": area_id,
                    "areaName": area.name,
                    "minutes": round(minutes, 1),
                    "percentage": round(percentage, 1),
                })

        return distribution

    def get_productivity_insights(self) -> List[str]:
        """
        Generate actionable productivity insights.

        Returns:
            List of insight messages
        """
        insights = []

        # Check for hotspots
        try:
            hotspots = self.get_hotspots(days=30)
            if hotspots:
                critical = [h for h in hotspots if h.temperature == "critical"]
                if critical:
                    insights.append(f"⚠️  {len(critical)} critical hotspot(s) need attention. Run /dig-hotspots")
        except Exception:
            pass

        # Check for coverage gaps
        try:
            gaps = self.find_coverage_gaps(min_coverage=70)
            if gaps:
                low_coverage = [g for g in gaps if g.coveragePercent < 40]
                if low_coverage:
                    insights.append(f"📊 {len(low_coverage)} area(s) with <40% test coverage. Run /dig-gaps")
        except Exception:
            pass

        # Check for automation
        try:
            rules = self.get_automation_rules(enabled_only=True)
            if len(rules) == 0:
                insights.append("🤖 No automation rules enabled. Consider adding some with /dig-auto")
            else:
                insights.append(f"✅ {len(rules)} automation rule(s) active")
        except Exception:
            pass

        # Check for knowledge capture
        areas = self.list_areas()
        areas_without_notes = []

        for area in areas:
            notes = self.get_notes(area.id)
            if len(notes) == 0:
                areas_without_notes.append(area)

        if len(areas_without_notes) > 5:
            insights.append(f"📝 {len(areas_without_notes)} areas have no notes. Document your knowledge!")

        # Check for recent activity
        history = self.get_history()
        if len(history) > 0:
            last_entry = history[-1]
            if "timestamp" in last_entry:
                try:
                    last_time = datetime.fromisoformat(last_entry["timestamp"])
                    days_since = (datetime.now() - last_time).days

                    if days_since > 7:
                        insights.append(f"⏰ No activity in {days_since} days. Time to dig back in!")
                except Exception:
                    pass

        return insights

    def generate_report(self, output_file: Optional[Path] = None) -> str:
        """
        Generate a comprehensive analytics report in markdown format.

        Args:
            output_file: Optional file path to save report

        Returns:
            The report content as markdown
        """
        # Get analytics
        analytics = self.get_work_analytics(days=30)
        time_dist = self.get_time_distribution(days=30)
        insights = self.get_productivity_insights()

        # Build report
        report_lines = []

        report_lines.append("# ContextDigger Analytics Report")
        report_lines.append("")
        report_lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append("")

        # Overview
        report_lines.append("## Overview")
        report_lines.append("")
        report_lines.append(f"- **Total Areas**: {analytics.totalAreas}")
        report_lines.append(f"- **Total Notes**: {analytics.totalNotes}")
        report_lines.append(f"- **Total Bookmarks**: {analytics.totalBookmarks}")
        report_lines.append(f"- **Total Snapshots**: {analytics.totalSnapshots}")
        report_lines.append(f"- **Productivity Score**: {analytics.productivityScore:.0f}/100")
        report_lines.append("")

        # Most visited areas
        if analytics.mostVisitedAreas:
            report_lines.append("## Most Visited Areas")
            report_lines.append("")
            for i, area_data in enumerate(analytics.mostVisitedAreas[:10], 1):
                report_lines.append(f"{i}. **{area_data['areaName']}** - {area_data['visits']} visits")
            report_lines.append("")

        # Time distribution
        if time_dist["areaBreakdown"]:
            report_lines.append("## Time Distribution (Last 30 Days)")
            report_lines.append("")
            report_lines.append(f"Total time: {time_dist['totalTime']:.0f} minutes ({time_dist['totalTime']/60:.1f} hours)")
            report_lines.append("")

            for area_data in time_dist["areaBreakdown"][:10]:
                bar_length = int(area_data["percentage"] / 5)
                bar = "█" * bar_length
                report_lines.append(f"- **{area_data['areaName']}**: {area_data['minutes']:.0f}m ({area_data['percentage']:.0f}%) {bar}")
            report_lines.append("")

        # Areas by tag
        if analytics.areasByTag:
            report_lines.append("## Areas by Tag")
            report_lines.append("")
            sorted_tags = sorted(analytics.areasByTag.items(), key=lambda x: x[1], reverse=True)
            for tag, count in sorted_tags[:10]:
                report_lines.append(f"- **{tag}**: {count} areas")
            report_lines.append("")

        # Insights
        report_lines.append("## Insights & Recommendations")
        report_lines.append("")

        all_insights = analytics.insights + insights
        for insight in all_insights:
            report_lines.append(f"- {insight}")
        report_lines.append("")

        # Recent activity
        if analytics.recentActivity:
            report_lines.append("## Recent Activity")
            report_lines.append("")
            for activity in analytics.recentActivity[-10:]:
                timestamp = activity.get("timestamp", "")[:19].replace("T", " ")
                report_lines.append(f"- {timestamp} - {activity.get('areaName', 'Unknown')}")
            report_lines.append("")

        report_lines.append("---")
        report_lines.append("Generated with [ContextDigger](https://github.com/ialameh/contextdigger)")

        report = "\n".join(report_lines)

        # Save to file if specified
        if output_file:
            output_file.write_text(report)

        return report

    # Export & Integration Operations

    def export_to_json(
        self,
        output_file: Path,
        include_areas: bool = True,
        include_notes: bool = True,
        include_bookmarks: bool = True,
        include_snapshots: bool = True,
    ) -> Dict[str, Any]:
        """
        Export all data to JSON format.

        Args:
            output_file: Path to save JSON file
            include_areas: Include areas data
            include_notes: Include notes data
            include_bookmarks: Include bookmarks data
            include_snapshots: Include snapshots data

        Returns:
            The exported data dictionary
        """
        export_data = {
            "version": "1.0",
            "exported_at": datetime.now().isoformat(),
            "project_root": str(self.project_root),
        }

        if include_areas:
            areas_data = []
            for area in self.list_areas():
                area_dict = asdict(area)
                areas_data.append(area_dict)
            export_data["areas"] = areas_data

        if include_notes:
            notes_data = {}
            for area in self.list_areas():
                notes = self.get_notes(area.id)
                if notes:
                    notes_data[area.id] = [asdict(note) for note in notes]
            export_data["notes"] = notes_data

        if include_bookmarks:
            bookmarks_data = {}
            for area in self.list_areas():
                bookmarks = self.list_bookmarks(area.id)
                if bookmarks:
                    bookmarks_data[area.id] = [asdict(mark) for mark in bookmarks]
            export_data["bookmarks"] = bookmarks_data

        if include_snapshots:
            snapshots_dir = self.cdg_dir / "snapshots"
            if snapshots_dir.exists():
                snapshots_data = []
                for snapshot_file in snapshots_dir.glob("*.json"):
                    try:
                        data = json.loads(snapshot_file.read_text())
                        snapshots_data.append(data)
                    except Exception:
                        continue
                export_data["snapshots"] = snapshots_data

        # Save to file
        output_file.write_text(json.dumps(export_data, indent=2))

        return export_data

    def export_to_csv(self, output_dir: Path, data_type: str = "all") -> List[Path]:
        """
        Export data to CSV format.

        Args:
            output_dir: Directory to save CSV files
            data_type: Type to export (all, areas, notes, bookmarks)

        Returns:
            List of created file paths
        """
        import csv

        output_dir.mkdir(parents=True, exist_ok=True)
        created_files = []

        if data_type in ["all", "areas"]:
            # Export areas
            areas_file = output_dir / "areas.csv"
            with areas_file.open("w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["ID", "Name", "Path", "Description", "Tags", "Created"])

                for area in self.list_areas():
                    writer.writerow([
                        area.id,
                        area.name,
                        area.path,
                        area.description or "",
                        "|".join(area.tags),
                        area.createdAt,
                    ])
            created_files.append(areas_file)

        if data_type in ["all", "notes"]:
            # Export notes
            notes_file = output_dir / "notes.csv"
            with notes_file.open("w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["ID", "Area ID", "Area Name", "Author", "Timestamp", "Note", "Tags"])

                for area in self.list_areas():
                    for note in self.get_notes(area.id):
                        writer.writerow([
                            note.id,
                            area.id,
                            area.name,
                            note.authorName,
                            note.timestamp,
                            note.note,
                            "|".join(note.tags),
                        ])
            created_files.append(notes_file)

        if data_type in ["all", "bookmarks"]:
            # Export bookmarks
            bookmarks_file = output_dir / "bookmarks.csv"
            with bookmarks_file.open("w", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["ID", "Area ID", "Area Name", "Label", "File", "Line", "Created"])

                for area in self.list_areas():
                    for mark in self.list_bookmarks(area.id):
                        writer.writerow([
                            mark.id,
                            area.id,
                            area.name,
                            mark.label or "",
                            mark.filePath,
                            mark.lineNumber or "",
                            mark.createdAt,
                        ])
            created_files.append(bookmarks_file)

        return created_files

    def export_to_html(self, output_file: Path) -> str:
        """
        Export all data to HTML format for viewing in browser.

        Args:
            output_file: Path to save HTML file

        Returns:
            The HTML content
        """
        html_lines = []

        html_lines.append("<!DOCTYPE html>")
        html_lines.append("<html>")
        html_lines.append("<head>")
        html_lines.append("  <meta charset=\"UTF-8\">")
        html_lines.append("  <title>ContextDigger Export</title>")
        html_lines.append("  <style>")
        html_lines.append("    body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }")
        html_lines.append("    .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }")
        html_lines.append("    h1 { color: #333; border-bottom: 2px solid #4CAF50; padding-bottom: 10px; }")
        html_lines.append("    h2 { color: #555; margin-top: 30px; }")
        html_lines.append("    .area { margin: 20px 0; padding: 15px; background: #f9f9f9; border-left: 4px solid #4CAF50; }")
        html_lines.append("    .note { margin: 10px 0; padding: 10px; background: #fff3cd; border-left: 3px solid #ffc107; }")
        html_lines.append("    .bookmark { margin: 10px 0; padding: 10px; background: #d1ecf1; border-left: 3px solid #17a2b8; }")
        html_lines.append("    .meta { color: #666; font-size: 0.9em; }")
        html_lines.append("    .tag { display: inline-block; background: #e9ecef; padding: 2px 8px; margin: 2px; border-radius: 3px; font-size: 0.85em; }")
        html_lines.append("  </style>")
        html_lines.append("</head>")
        html_lines.append("<body>")
        html_lines.append("  <div class=\"container\">")
        html_lines.append("    <h1>ContextDigger Export</h1>")
        html_lines.append(f"    <p class=\"meta\">Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>")

        # Areas
        html_lines.append("    <h2>Areas</h2>")
        for area in self.list_areas():
            html_lines.append("    <div class=\"area\">")
            html_lines.append(f"      <h3>{area.name}</h3>")
            html_lines.append(f"      <p><strong>Path:</strong> {area.path}</p>")
            if area.description:
                html_lines.append(f"      <p>{area.description}</p>")
            if area.tags:
                html_lines.append("      <div>")
                for tag in area.tags:
                    html_lines.append(f"        <span class=\"tag\">{tag}</span>")
                html_lines.append("      </div>")

            # Notes for this area
            notes = self.get_notes(area.id)
            if notes:
                html_lines.append("      <h4>Notes:</h4>")
                for note in notes:
                    html_lines.append("      <div class=\"note\">")
                    html_lines.append(f"        <p>{note.note}</p>")
                    html_lines.append(f"        <p class=\"meta\">By {note.authorName} on {note.timestamp[:10]}</p>")
                    html_lines.append("      </div>")

            # Bookmarks for this area
            bookmarks = self.list_bookmarks(area.id)
            if bookmarks:
                html_lines.append("      <h4>Bookmarks:</h4>")
                for mark in bookmarks:
                    html_lines.append("      <div class=\"bookmark\">")
                    if mark.label:
                        html_lines.append(f"        <p><strong>{mark.label}</strong></p>")
                    location = f"{mark.filePath}"
                    if mark.lineNumber:
                        location += f":{mark.lineNumber}"
                    html_lines.append(f"        <p>{location}</p>")
                    html_lines.append("      </div>")

            html_lines.append("    </div>")

        html_lines.append("  </div>")
        html_lines.append("</body>")
        html_lines.append("</html>")

        html_content = "\n".join(html_lines)
        output_file.write_text(html_content)

        return html_content

    def backup_all(self, backup_dir: Path) -> Path:
        """
        Create a complete backup of all ContextDigger data.

        Args:
            backup_dir: Directory to create backup in

        Returns:
            Path to the backup archive
        """
        import shutil
        import tarfile

        # Create backup directory
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"contextdigger_backup_{timestamp}"
        temp_backup = backup_dir / backup_name

        temp_backup.mkdir(parents=True, exist_ok=True)

        # Copy .cdg directory
        if self.cdg_dir.exists():
            shutil.copytree(self.cdg_dir, temp_backup / ".cdg", dirs_exist_ok=True)

        # Create tarball
        archive_path = backup_dir / f"{backup_name}.tar.gz"

        with tarfile.open(archive_path, "w:gz") as tar:
            tar.add(temp_backup, arcname=backup_name)

        # Cleanup temp directory
        shutil.rmtree(temp_backup)

        return archive_path

    def restore_from_backup(self, backup_file: Path, confirm: bool = False) -> bool:
        """
        Restore ContextDigger data from a backup.

        Args:
            backup_file: Path to backup tar.gz file
            confirm: Must be True to proceed (safety check)

        Returns:
            True if restored successfully
        """
        if not confirm:
            raise ValueError("Must set confirm=True to restore from backup. This will overwrite existing data!")

        import shutil
        import tarfile

        if not backup_file.exists():
            raise FileNotFoundError(f"Backup file not found: {backup_file}")

        # Create backup of current state first
        current_backup = self.cdg_dir.parent / f"pre_restore_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        if self.cdg_dir.exists():
            shutil.copytree(self.cdg_dir, current_backup)

        try:
            # Extract backup
            temp_extract = self.cdg_dir.parent / "temp_restore"
            temp_extract.mkdir(exist_ok=True)

            with tarfile.open(backup_file, "r:gz") as tar:
                tar.extractall(temp_extract)

            # Find .cdg directory in extracted files
            cdg_found = None
            for item in temp_extract.rglob(".cdg"):
                if item.is_dir():
                    cdg_found = item
                    break

            if not cdg_found:
                raise ValueError("No .cdg directory found in backup")

            # Remove current .cdg and replace with backup
            if self.cdg_dir.exists():
                shutil.rmtree(self.cdg_dir)

            shutil.copytree(cdg_found, self.cdg_dir)

            # Cleanup
            shutil.rmtree(temp_extract)
            shutil.rmtree(current_backup)  # Restore successful, remove pre-restore backup

            return True

        except Exception as e:
            # Restore failed, try to recover
            if current_backup.exists() and not self.cdg_dir.exists():
                shutil.copytree(current_backup, self.cdg_dir)

            raise e

    # Dashboard & Utilities Operations

    def get_dashboard(self) -> Dict[str, Any]:
        """
        Get comprehensive dashboard overview of all data.

        Returns:
            Dashboard data with key metrics and insights
        """
        dashboard = {
            "overview": {},
            "recent": {},
            "alerts": [],
            "suggestions": [],
        }

        # Overview metrics
        all_areas = self.list_areas()
        dashboard["overview"]["areas"] = len(all_areas)

        total_notes = sum(len(self.get_notes(area.id)) for area in all_areas)
        dashboard["overview"]["notes"] = total_notes

        total_bookmarks = sum(len(self.list_bookmarks(area.id)) for area in all_areas)
        dashboard["overview"]["bookmarks"] = total_bookmarks

        snapshots_dir = self.cdg_dir / "snapshots"
        if snapshots_dir.exists():
            dashboard["overview"]["snapshots"] = len(list(snapshots_dir.glob("*.json")))
        else:
            dashboard["overview"]["snapshots"] = 0

        # Current focus
        current = self.get_current_focus()
        if current:
            area = self.get_area(current)
            if area:
                dashboard["overview"]["currentFocus"] = {
                    "id": area.id,
                    "name": area.name,
                    "path": area.path,
                }

        # Recent activity
        history = self.get_history()
        if history:
            recent_areas = []
            seen = set()
            for entry in reversed(history[-10:]):
                area_id = entry.areaId
                if area_id and area_id not in seen:
                    area = self.get_area(area_id)
                    if area:
                        recent_areas.append({
                            "id": area.id,
                            "name": area.name,
                            "timestamp": entry.enteredAt,
                        })
                        seen.add(area_id)

            dashboard["recent"]["areas"] = recent_areas[:5]

        # Alerts (issues needing attention)
        try:
            # Check for hotspots
            hotspots = self.get_hotspots(days=30)
            critical = [h for h in hotspots if h.temperature == "critical"]
            if critical:
                dashboard["alerts"].append({
                    "type": "hotspot",
                    "severity": "high",
                    "message": f"{len(critical)} critical hotspot(s) detected",
                    "action": "/dig-hotspots",
                })
        except Exception:
            pass

        try:
            # Check for coverage gaps
            gaps = self.find_coverage_gaps(min_coverage=70)
            low = [g for g in gaps if g.coveragePercent < 40]
            if low:
                dashboard["alerts"].append({
                    "type": "coverage",
                    "severity": "medium",
                    "message": f"{len(low)} area(s) with <40% test coverage",
                    "action": "/dig-gaps",
                })
        except Exception:
            pass

        # Suggestions
        if dashboard["overview"]["areas"] < 5:
            dashboard["suggestions"].append("Create more areas to organize your work")

        if total_notes == 0:
            dashboard["suggestions"].append("Start capturing knowledge with /dig-note")

        if total_bookmarks < 10:
            dashboard["suggestions"].append("Save important locations with /dig-mark")

        return dashboard

    def get_health_check(self) -> Dict[str, Any]:
        """
        Perform health check on ContextDigger data.

        Returns:
            Health check results with status and issues
        """
        health = {
            "status": "healthy",
            "checks": [],
            "issues": [],
        }

        # Check data directory exists
        if not self.cdg_dir.exists():
            health["status"] = "error"
            health["issues"].append({
                "severity": "critical",
                "message": "ContextDigger not initialized",
                "fix": "Run /init-dig",
            })
            return health

        # Check areas
        all_areas = self.list_areas()
        health["checks"].append({
            "name": "Areas",
            "status": "ok",
            "count": len(all_areas),
        })

        # Check for orphaned data
        notes_dir = self.cdg_dir / "notes"
        if notes_dir.exists():
            valid_area_ids = {area.id for area in all_areas}
            for note_file in notes_dir.glob("*.json"):
                area_id = note_file.stem
                if area_id not in valid_area_ids:
                    health["issues"].append({
                        "severity": "warning",
                        "message": f"Orphaned notes for deleted area: {area_id}",
                        "fix": "Manual cleanup required",
                    })

        # Check for missing paths
        missing_paths = []
        for area in all_areas:
            area_path = Path(area.path)
            if not area_path.exists():
                missing_paths.append(area.name)

        if missing_paths:
            health["status"] = "warning"
            health["issues"].append({
                "severity": "warning",
                "message": f"{len(missing_paths)} area(s) have missing paths",
                "fix": "Update paths or remove old areas",
            })

        # Check disk usage
        if self.cdg_dir.exists():
            total_size = sum(
                f.stat().st_size for f in self.cdg_dir.rglob("*") if f.is_file()
            )
            size_mb = total_size / (1024 * 1024)

            health["checks"].append({
                "name": "Disk Usage",
                "status": "ok" if size_mb < 100 else "warning",
                "size_mb": round(size_mb, 2),
            })

            if size_mb > 100:
                health["status"] = "warning"
                health["issues"].append({
                    "severity": "info",
                    "message": f"Large data size: {size_mb:.1f} MB",
                    "fix": "Consider archiving old data",
                })

        # Overall status
        if not health["issues"]:
            health["status"] = "healthy"
        elif any(i["severity"] == "critical" for i in health["issues"]):
            health["status"] = "error"
        elif any(i["severity"] in ["warning", "medium"] for i in health["issues"]):
            health["status"] = "warning"

        return health

    def cleanup_old_data(self, days: int = 90, dry_run: bool = True) -> Dict[str, Any]:
        """
        Clean up old unused data.

        Args:
            days: Remove data older than this many days
            dry_run: If True, only report what would be deleted

        Returns:
            Cleanup report
        """
        cutoff = datetime.now() - timedelta(days=days)
        report = {
            "dry_run": dry_run,
            "cutoff_date": cutoff.isoformat(),
            "snapshots_removed": 0,
            "old_snapshots": [],
        }

        # Find old snapshots
        snapshots_dir = self.cdg_dir / "snapshots"
        if snapshots_dir.exists():
            for snapshot_file in snapshots_dir.glob("*.json"):
                try:
                    data = json.loads(snapshot_file.read_text())
                    snapshot_time = datetime.fromisoformat(data.get("timestamp", ""))

                    if snapshot_time < cutoff:
                        report["old_snapshots"].append({
                            "id": data.get("id"),
                            "name": data.get("name"),
                            "date": snapshot_time.isoformat(),
                        })

                        if not dry_run:
                            snapshot_file.unlink()
                            report["snapshots_removed"] += 1

                except Exception:
                    continue

        return report

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get comprehensive statistics about the project.

        Returns:
            Detailed statistics
        """
        stats = {}

        # Basic counts
        all_areas = self.list_areas()
        stats["total_areas"] = len(all_areas)

        # Notes stats
        notes_by_area = {}
        total_notes = 0
        for area in all_areas:
            notes = self.get_notes(area.id)
            notes_by_area[area.id] = len(notes)
            total_notes += len(notes)

        stats["total_notes"] = total_notes
        stats["avg_notes_per_area"] = round(total_notes / len(all_areas), 1) if all_areas else 0

        # Bookmarks stats
        total_bookmarks = 0
        for area in all_areas:
            total_bookmarks += len(self.list_bookmarks(area.id))

        stats["total_bookmarks"] = total_bookmarks
        stats["avg_bookmarks_per_area"] = round(total_bookmarks / len(all_areas), 1) if all_areas else 0

        # Tags stats
        all_tags = set()
        for area in all_areas:
            all_tags.update(area.tags)

        stats["unique_tags"] = len(all_tags)
        stats["most_common_tags"] = []

        tag_counts = {}
        for area in all_areas:
            for tag in area.tags:
                tag_counts[tag] = tag_counts.get(tag, 0) + 1

        if tag_counts:
            sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)
            stats["most_common_tags"] = [
                {"tag": tag, "count": count} for tag, count in sorted_tags[:5]
            ]

        # History stats
        history = self.get_history()
        stats["total_visits"] = len(history)

        # Automation stats
        try:
            rules = self.get_automation_rules()
            stats["automation_rules"] = len(rules)
            stats["enabled_rules"] = len([r for r in rules if r.enabled])
        except Exception:
            stats["automation_rules"] = 0
            stats["enabled_rules"] = 0

        # Snapshots stats
        snapshots_dir = self.cdg_dir / "snapshots"
        if snapshots_dir.exists():
            stats["total_snapshots"] = len(list(snapshots_dir.glob("*.json")))
        else:
            stats["total_snapshots"] = 0

        return stats
