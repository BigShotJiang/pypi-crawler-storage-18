# ContextDigger Product Roadmap & Vision
**Comprehensive Strategy Document**

**Version**: 2.0
**Last Updated**: 2025-12-21
**Author**: Sam Alameh
**Status**: Strategic Planning Document

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Product Vision](#product-vision)
3. [Current State (v1.0)](#current-state-v10)
4. [Version History & Roadmap](#version-history--roadmap)
5. [Technical Architecture](#technical-architecture)
6. [Monetization Strategy](#monetization-strategy)
7. [Feature Specifications](#feature-specifications)
8. [Implementation Phases](#implementation-phases)
9. [Revenue Projections](#revenue-projections)
10. [Risk Analysis](#risk-analysis)
11. [Success Metrics](#success-metrics)

---

## Executive Summary

ContextDigger is evolving from a **context management tool** into a **context-independent code intelligence platform** that enables developers using AI coding assistants (Claude Code, Cursor, etc.) to navigate and understand codebases of any size without context window limitations.

**The Core Innovation**: By combining AST-based symbol indexing with vector database semantic search, ContextDigger eliminates the context window bottleneck while maintaining zero token costs for most operations.

**Market Opportunity**:
- Total Addressable Market (TAM): 5M+ developers using AI coding assistants
- Serviceable Addressable Market (SAM): 500k developers at companies using Claude Code/Cursor
- Target: $2-5M ARR within 24 months

**Key Milestones**:
- **v1.0** (Current): Focus area discovery, navigation, bookmarks - FREE
- **v1.1** (Month 1-2): Bug fixes, multi-language discovery - FREE
- **v2.0** (Month 3-6): AST symbol indexing (Python, TS, Dart, Apex) - FREE
- **v2.5** (Month 6-9): Team tier launch with cross-project search - PAID
- **v3.0** (Month 9-12): Vector DB semantic search - PAID (Team/Enterprise)
- **v3.5** (Month 12-18): Enterprise features (compliance, security scanning) - PAID

---

## Product Vision

### The Problem We Solve

**Current Pain Points:**
1. **Context Window Limits**: AI assistants can't handle large codebases (>200k tokens)
2. **Lost Context**: Developers lose track when switching between code areas
3. **Slow Navigation**: Finding symbols/functions requires grep + manual search
4. **Team Inefficiency**: No shared understanding of codebase structure
5. **Enterprise Blockers**: No compliance scanning, security pattern detection

**What Makes It Worse:**
- Large monorepos (1M+ lines) are becoming standard
- Microservices architectures span dozens of repos
- AI assistants exhaust context on a single service
- Teams waste hours re-discovering code structure

### Our Solution

**ContextDigger transforms AI-assisted coding by:**

1. **Eliminating Context Limits**
   - Index symbols locally (classes, functions, methods)
   - Query index instead of loading files into context
   - Support codebases of 10M+ lines with instant queries

2. **Intelligent Navigation**
   - Go-to-definition across any file/project
   - Find all references to any symbol
   - Call hierarchy visualization
   - Dependency graph mapping

3. **Semantic Understanding**
   - Vector DB for "find code similar to this pattern"
   - Natural language queries: "show me authentication code"
   - Code similarity detection (find duplicates)

4. **Team Collaboration**
   - Shared symbol indexes across teams
   - Bookmark sharing
   - Team-wide code intelligence

5. **Enterprise Compliance**
   - Security pattern detection
   - Compliance scanning (GDPR, HIPAA, PII)
   - Custom query engine for audits

### Vision Statement

> "ContextDigger makes AI coding assistants infinitely scalable by eliminating context window constraints through intelligent local indexing, enabling developers to navigate codebases of any size with zero latency and zero token costs."

### Core Principles

1. **Local-First**: All indexing runs locally, no data leaves the machine (free tier)
2. **Context-Free**: Symbol queries never use AI context windows
3. **Zero Tokens**: Most operations cost $0 in API calls
4. **Language-Agnostic**: Support any language via Tree-sitter
5. **Freemium Model**: Core features free forever, team/enterprise features paid
6. **Open Core**: Core remains open source, premium features are paid

---

## Current State (v1.0)

### What We Built (Released)

**Discovery & Navigation**:
- ✅ Auto-discovery of code areas (Python, JS/TS, Salesforce, Astro)
- ✅ Monorepo detection (multi-project support)
- ✅ Focus area switching (`/dig`, `/redig`)
- ✅ Bookmark management (`/bookmark`, `/goto`)
- ✅ Navigation history tracking
- ✅ Dashboard visualization (`/dig-dashboard`)
- ✅ Statistics and analytics (`/stats`)

**Language Support**:
- ✅ Python (pytest projects)
- ✅ JavaScript/TypeScript (Node, React, Next.js)
- ✅ Salesforce (Apex, LWC)
- ✅ Astro (pages, components)

**Team Features** (Basic):
- ✅ Shared focus areas (via git)
- ✅ Team directory structure

**Deployment**:
- ✅ PyPI package (`pip install contextdigger`)
- ✅ CLI tool (`contextdigger` command)
- ✅ Claude Code skills integration
- ✅ Documentation website (contextdigger.com)

### Known Issues (Fixed in v1.1)

**Critical Bugs Identified (2025-12-21)**:
1. ❌ **Hardcoded Package Name**: Discovery only looked for `flowmason_core`, not generic Python packages
2. ❌ **`.mypy_cache` Pollution**: Indexed cache directories instead of source code
3. ❌ **Shallow Discovery**: Only searched depth 1-2, missed nested projects (e.g., `flowmason/studio/frontend`)

**Impact**:
- FlowMason project: Discovered only 36 areas instead of 139
- Studio frontend: Not discovered at all
- User frustration: "Why can't I dig into studio?"

**Resolution** (Implemented 2025-12-21):
- ✅ Fixed: Generic `__init__.py` search instead of hardcoded names
- ✅ Fixed: Proper exclusion of cache directories (`.mypy_cache`, `__pycache__`, etc.)
- ✅ Fixed: Extended search depth to 1-3 levels for nested projects
- ✅ Result: FlowMason now discovers 139 areas including studio frontend

### Current Limitations

**Context Window Dependency**:
- Symbol searches use Grep (loads content into context)
- Large codebases (>100k lines) can exhaust context
- No go-to-definition (must grep + read file)
- No call hierarchy or reference finding

**Scalability**:
- Slow on large monorepos (>500k lines)
- Can't handle multi-repo workspaces efficiently
- No semantic search capabilities

**Team Collaboration**:
- Limited to git-based sharing
- No real-time sync
- No shared indexes
- No team analytics

**Enterprise Features**:
- No compliance scanning
- No security pattern detection
- No API access
- No SSO/SAML integration

---

## Version History & Roadmap

### v1.0 - Initial Release (December 2024)
**Status**: ✅ RELEASED

**Features**:
- Auto-discovery of code areas
- Focus area navigation
- Bookmarks and history
- Multi-language support (Python, JS/TS, Salesforce, Astro)
- Claude Code skills integration
- Documentation website

**Target Users**: Solo developers using Claude Code
**Pricing**: FREE (open source)
**Effort**: ~120 hours
**Impact**: Launched product, initial user base

---

### v1.1 - Bug Fixes & Discovery Improvements (January 2025)
**Status**: ✅ COMPLETED (2025-12-21)

**Critical Fixes**:
- ✅ Remove hardcoded `flowmason_core` package name
- ✅ Fix `.mypy_cache` pollution in discovery
- ✅ Extend discovery depth to 1-3 levels
- ✅ Add proper cache directory exclusions

**Improvements**:
- ✅ Generic Python package discovery via `__init__.py`
- ✅ Better monorepo detection (depth 1-3)
- ✅ Improved area naming (less redundant)

**Testing**:
- ✅ Tested on FlowMason (139 areas discovered, up from 36)
- ✅ Verified studio frontend discovery
- ✅ Verified no cache directory pollution

**Target Users**: Solo developers
**Pricing**: FREE
**Effort**: ~8 hours
**Impact**: Fixed critical discovery issues, improved user experience

---

### v2.0 - AST Symbol Indexing (Month 3-6)
**Status**: 🎯 PLANNED (Q1-Q2 2025)

**Goal**: Eliminate context window limits with local symbol indexing

**Core Features**:
1. **AST Parser Integration**
   - Integrate Tree-sitter for multi-language parsing
   - Support Python, TypeScript, Dart, Apex initially
   - Extensible architecture for future languages

2. **Symbol Extraction**
   - Extract classes, functions, methods, variables
   - Parse imports and dependencies
   - Build call graphs (who calls what)
   - Track file locations (line numbers)

3. **Index Storage**
   - SQLite database for symbols
   - Fast queries (<100ms for 10M lines)
   - Incremental updates (only re-index changed files)
   - Compressed storage (<50MB for 1M lines)

4. **Query Commands**
   - `/find-symbol <name>` - Find where symbol is defined
   - `/find-references <symbol>` - Find all usages
   - `/show-callers <function>` - Call hierarchy
   - `/show-dependencies <module>` - Dependency graph
   - `/rebuild-index` - Re-index all files

**Technical Specifications**:

**Tree-sitter Language Support**:
```python
SUPPORTED_LANGUAGES = {
    'python': 'tree-sitter-python',
    'typescript': 'tree-sitter-typescript',
    'javascript': 'tree-sitter-javascript',
    'dart': 'tree-sitter-dart',
    'apex': 'tree-sitter-apex',
    'go': 'tree-sitter-go',
    'rust': 'tree-sitter-rust',
}
```

**Index Schema** (SQLite):
```sql
-- Symbols table
CREATE TABLE symbols (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,  -- 'class', 'function', 'method', 'variable'
    file_path TEXT NOT NULL,
    line_number INTEGER NOT NULL,
    language TEXT NOT NULL,
    area_id TEXT,
    signature TEXT,      -- Function signature
    docstring TEXT,
    created_at TIMESTAMP,
    UNIQUE(name, file_path, line_number)
);

-- Call graph table
CREATE TABLE calls (
    id INTEGER PRIMARY KEY,
    caller_id INTEGER REFERENCES symbols(id),
    callee_id INTEGER REFERENCES symbols(id),
    call_location TEXT,  -- file:line
    UNIQUE(caller_id, callee_id, call_location)
);

-- Imports table
CREATE TABLE imports (
    id INTEGER PRIMARY KEY,
    from_file TEXT NOT NULL,
    import_name TEXT NOT NULL,
    import_type TEXT,  -- 'module', 'function', 'class'
    to_file TEXT
);

-- Index metadata
CREATE TABLE index_metadata (
    file_path TEXT PRIMARY KEY,
    last_indexed TIMESTAMP,
    file_hash TEXT,
    symbol_count INTEGER
);
```

**Performance Targets**:
- Index 100k lines: <30 seconds
- Query symbol: <50ms
- Incremental update: <5 seconds for 10 changed files
- Index size: <50MB for 1M lines of code

**User Experience**:
```bash
# Initialize discovery + indexing
$ contextdigger init
⛏️  Digging through codebase...
✓ Discovered 139 code areas
🔍 Indexing symbols...
   Python: 47,284 symbols
   TypeScript: 12,893 symbols
   Dart: 3,421 symbols
✓ Indexed 63,598 symbols in 23.4s

# Find a symbol instantly (no context used!)
$ contextdigger find-symbol UserAuthService
📍 Found: flowmason/core/auth/user_service.py:47
   class UserAuthService:
       """Handles user authentication and session management"""

# Find all references (no context used!)
$ contextdigger find-references authenticate
📍 Found 23 references:
   1. flowmason/api/auth.py:89 - login()
   2. flowmason/middleware/auth.py:34 - verify_token()
   3. flowmason/tests/auth_test.py:56 - test_authentication()
   ... (20 more)

# Show call hierarchy
$ contextdigger show-callers authenticate
📞 authenticate() is called by:
   ├─ login() (api/auth.py:89)
   │  ├─ handle_login_request() (api/routes.py:45)
   │  └─ process_oauth() (api/oauth.py:23)
   ├─ verify_token() (middleware/auth.py:34)
   │  └─ auth_middleware() (middleware/auth.py:12)
   └─ ... (20 more callers)
```

**Target Users**: Solo developers + early teams
**Pricing**: FREE (validates feature, builds adoption)
**Effort**: 60-80 hours
**Languages**: Python, TypeScript, Dart, Apex
**Impact**: Eliminates context limits, enables large codebases

**Success Metrics**:
- 5,000+ users adopt v2.0
- Index 50+ large codebases (>500k lines)
- Query speed <100ms average
- User feedback: "This is a game-changer"

---

### v2.5 - Team Tier Launch (Month 6-9)
**Status**: 🎯 PLANNED (Q2-Q3 2025)

**Goal**: Monetize teams with cross-project features and collaboration

**Tier Structure**:

#### **Free Tier** (Unchanged)
- All AST symbol indexing features
- Local-only indexes
- Single user
- Community support (GitHub)

#### **Team Tier** ($15/user/month)
**NEW Premium Features**:

1. **Cross-Project Symbol Search**
   - Search symbols across all team repos
   - Unified index for entire codebase
   - "Where is UserService used across our 12 microservices?"

2. **Call Hierarchy Across Projects**
   - See call chains spanning multiple repos
   - Understand cross-service dependencies
   - Visualize impact of changes

3. **Shared Team Index**
   - Team members share the same symbol index
   - Real-time sync (WebSocket or polling)
   - See what teammates are exploring

4. **Team Analytics Dashboard**
   - Most-searched symbols
   - Code hotspots (most-edited areas)
   - Team productivity metrics
   - Time saved per developer

5. **Priority Support**
   - Email support (24-hour response)
   - Slack/Discord channel
   - Feature requests prioritized

6. **SSO Integration**
   - Google, GitHub, Okta login
   - Team member management
   - Role-based permissions

**Technical Implementation**:

**Backend** (FastAPI):
```python
# Team sync service
@app.post("/api/team/{team_id}/index/sync")
async def sync_team_index(team_id: str, symbols: List[Symbol]):
    """Sync local symbols to team index"""
    # Merge with existing team index
    # Notify team members via WebSocket
    pass

@app.get("/api/team/{team_id}/index/symbols/{name}")
async def search_team_symbols(team_id: str, name: str):
    """Search across team's entire codebase"""
    # Query unified team index
    pass

@app.get("/api/team/{team_id}/analytics")
async def get_team_analytics(team_id: str):
    """Get team usage analytics"""
    # Return metrics (searches, time saved, etc.)
    pass
```

**Database** (PostgreSQL):
```sql
-- Team symbols (aggregated from all members)
CREATE TABLE team_symbols (
    id SERIAL PRIMARY KEY,
    team_id UUID NOT NULL,
    symbol_name TEXT NOT NULL,
    symbol_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    repo_name TEXT NOT NULL,
    line_number INTEGER,
    indexed_by_user_id UUID,
    last_updated TIMESTAMP
);

-- Team analytics
CREATE TABLE team_analytics (
    id SERIAL PRIMARY KEY,
    team_id UUID NOT NULL,
    user_id UUID NOT NULL,
    action TEXT NOT NULL,  -- 'search', 'navigate', 'dig'
    target TEXT,
    timestamp TIMESTAMP,
    time_saved_seconds INTEGER
);
```

**Pricing Calculator** (on website):
```
Team Size: [____5____] developers

Time saved per developer: 2 hours/day
Hourly rate: $120/hour

Value per month:
5 developers × 2 hours/day × 20 days × $120/hour = $24,000/month

ContextDigger Team cost:
5 developers × $15/month = $75/month

ROI: 320x return on investment
Payback period: 2.3 hours of use
```

**Target Users**: Teams of 5-50 developers
**Pricing**: $15/user/month or $150/user/year
**Effort**: 80-120 hours (backend, billing, team features)
**Impact**: First revenue, validates willingness to pay

**Success Metrics**:
- 50-100 paying teams by Month 9
- $9k-18k MRR
- <5% churn rate
- NPS >40

---

### v3.0 - Vector DB Semantic Search (Month 9-12)
**Status**: 🎯 PLANNED (Q3-Q4 2025)

**Goal**: Add AI-powered semantic search for "find similar code" queries

**Core Features**:

1. **Code Embeddings**
   - Chunk code into meaningful segments (functions, classes)
   - Generate embeddings using sentence-transformers (local model)
   - Store in FAISS or ChromaDB vector database
   - Update incrementally on file changes

2. **Semantic Search**
   - Natural language queries: "show me authentication code"
   - Find code by intent, not just keywords
   - "Find code similar to this pattern"
   - Ranked results by similarity score

3. **Code Similarity Detection**
   - Find duplicate or near-duplicate code
   - Suggest refactoring opportunities
   - "These 5 functions are 87% similar"

4. **Smart Documentation**
   - "Find examples of how to use this API"
   - "Show me tests for similar functionality"
   - Generate usage examples automatically

**Technical Specifications**:

**Embedding Model** (Local):
```python
from sentence_transformers import SentenceTransformer

# Use CodeBERT or similar code-specific model
model = SentenceTransformer('microsoft/codebert-base')

# Generate embeddings for code chunks
def embed_code(code: str, language: str) -> np.ndarray:
    # Add language context
    prompt = f"[{language}] {code}"
    embedding = model.encode(prompt)
    return embedding
```

**Vector Storage** (FAISS):
```python
import faiss

# Create index
dimension = 768  # CodeBERT embedding size
index = faiss.IndexFlatL2(dimension)

# Add embeddings
index.add(embeddings)

# Search
distances, indices = index.search(query_embedding, k=10)
```

**Query Interface**:
```bash
# Semantic search
$ contextdigger find-similar "authentication with JWT tokens"
🔍 Found 8 similar code blocks:

1. flowmason/auth/jwt_handler.py:23 (similarity: 0.94)
   def verify_jwt_token(token: str) -> Dict:
       """Verify and decode JWT authentication token"""
       ...

2. flowmason/middleware/auth.py:45 (similarity: 0.89)
   def authenticate_request(request: Request):
       """Authenticate incoming request using JWT"""
       ...

3. flowmason/api/oauth.py:67 (similarity: 0.82)
   def exchange_oauth_for_jwt(oauth_token: str):
       """Exchange OAuth token for internal JWT"""
       ...
```

**Free vs Team vs Enterprise**:

| Feature | Free | Team ($15/mo) | Enterprise ($40/mo) |
|---------|------|---------------|---------------------|
| Semantic searches/day | 5 | 100 | Unlimited |
| Cross-project semantic search | ❌ | ✅ | ✅ |
| Code similarity detection | ❌ | ✅ | ✅ |
| Custom embeddings | ❌ | ❌ | ✅ |
| Private embedding models | ❌ | ❌ | ✅ |
| Security pattern detection | ❌ | ❌ | ✅ |

**Target Users**: Teams + early enterprise
**Pricing**: Enhances Team tier, unlocks Enterprise tier
**Effort**: 60-80 hours (embedding pipeline, vector DB, queries)
**Impact**: Major differentiation, justifies higher pricing

**Success Metrics**:
- 70% of Team tier users use semantic search
- Average 20 semantic searches per user per week
- "Find similar code" rated most valuable feature
- Enables first Enterprise customers

---

### v3.5 - Enterprise Features (Month 12-18)
**Status**: 🎯 PLANNED (2026)

**Goal**: Build enterprise-grade compliance, security, and governance features

**Enterprise Tier** ($40/user/month):

1. **Security Pattern Detection**
   - Scan for known vulnerability patterns
   - "Find code similar to this CVE"
   - SQL injection detection
   - XSS vulnerability scanning
   - Hardcoded secrets detection

2. **Compliance Scanning**
   - GDPR: Find all PII data access
   - HIPAA: Find all PHI handling code
   - SOC 2: Generate audit trails
   - Custom compliance rules

3. **Custom Query Engine**
   - Write custom AST queries
   - Combine AST + semantic search
   - Export results to CSV/JSON
   - API access for automation

4. **Advanced Analytics**
   - Code complexity metrics (cyclomatic complexity)
   - Dead code detection (unused functions)
   - Dependency analysis (what breaks if I change this?)
   - Architecture insights (semantic clustering)

5. **Enterprise Infrastructure**
   - Self-hosted option (Docker/Kubernetes)
   - Audit logs for all operations
   - Data residency (deploy in customer VPC)
   - SSO/SAML (Okta, Azure AD, OneLogin)
   - SLA guarantees (99.9% uptime)

6. **Dedicated Support**
   - Dedicated CSM (Customer Success Manager)
   - Slack/Teams channel
   - Onboarding & training sessions
   - Custom feature development

**Technical Implementation**:

**Security Pattern Detection**:
```python
# Example: Find SQL injection vulnerabilities
SECURITY_PATTERNS = {
    'sql_injection': {
        'description': 'Potential SQL injection vulnerability',
        'pattern': r'execute\(.*\+.*\)',  # String concatenation in SQL
        'severity': 'high',
        'fix': 'Use parameterized queries instead',
    },
    'hardcoded_secrets': {
        'description': 'Hardcoded API key or password',
        'pattern': r'(api_key|password)\s*=\s*["\'][^"\']+["\']',
        'severity': 'critical',
        'fix': 'Use environment variables',
    },
}

# Scan codebase
def scan_security_patterns():
    vulnerabilities = []
    for symbol in index.all_symbols():
        for pattern_name, pattern in SECURITY_PATTERNS.items():
            if re.search(pattern['pattern'], symbol.code):
                vulnerabilities.append({
                    'type': pattern_name,
                    'location': f"{symbol.file}:{symbol.line}",
                    'severity': pattern['severity'],
                    'fix': pattern['fix'],
                })
    return vulnerabilities
```

**Compliance Queries**:
```python
# Find all GDPR-sensitive code
def find_pii_access():
    """Find all code that accesses PII (emails, SSN, etc.)"""
    pii_fields = ['email', 'ssn', 'phone', 'address']

    results = []
    for field in pii_fields:
        # AST query: Find all accesses to these fields
        accesses = index.find_field_access(field)
        results.extend(accesses)

    return generate_compliance_report(results)
```

**Self-Hosted Deployment** (Docker):
```yaml
# docker-compose.yml
version: '3.8'
services:
  contextdigger-api:
    image: contextdigger/enterprise:latest
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/contextdigger
      - REDIS_URL=redis://redis:6379
      - SAML_SSO_URL=${CUSTOMER_SSO_URL}
    volumes:
      - ./data:/app/data
    ports:
      - "8000:8000"

  postgres:
    image: postgres:15
    volumes:
      - postgres-data:/var/lib/postgresql/data

  redis:
    image: redis:7
```

**Target Users**: Large companies (50+ developers)
**Pricing**: $40/user/month or $400/user/year
**Effort**: 120-160 hours (compliance, self-hosted, SSO)
**Impact**: Unlock enterprise market, $500k+ ARR potential

**Success Metrics**:
- 10-25 enterprise customers by Month 18
- Average contract: $40k-120k/year
- SOC 2 Type II certified
- <3% churn

---

### v4.0 - Platform Expansion (Month 18-24)
**Status**: 🎯 PLANNED (2026)

**Goal**: Multi-platform support (Cursor, VS Code) + ecosystem

**Features**:

1. **Cursor Support** (CRITICAL)
   - Port all features to Cursor
   - Cursor has 10x more users than Claude Code
   - TAM expansion: 50k → 500k developers

2. **VS Code Extension** (Optional)
   - Largest market (5M+ developers)
   - Less AI-focused but huge reach

3. **API Platform**
   - Public API for integrations
   - Webhooks for CI/CD pipelines
   - Zapier/Make integration

4. **Plugin Marketplace**
   - Let developers build ContextDigger plugins
   - Revenue share model (30% to ContextDigger)
   - Example plugins: Jira integration, Linear sync

5. **AI Code Insights**
   - "This function hasn't been touched in 6 months"
   - "This module is becoming a hotspot (edited 47 times this week)"
   - Automated refactoring suggestions

**Target Users**: Expand to Cursor/VS Code users
**Pricing**: Same tier structure
**Effort**: 100-150 hours (Cursor/VS Code ports)
**Impact**: 10x TAM, path to $5M+ ARR

---

## Technical Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────┐
│                  ContextDigger Client                    │
│                  (Local CLI + Skills)                    │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                    Discovery Layer                       │
│  - Language detection (Python, TS, Dart, Apex, etc.)   │
│  - Monorepo detection                                    │
│  - Area creation (project structure analysis)           │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                   Indexing Layer (v2.0+)                │
│  ┌──────────────────┐    ┌─────────────────────────┐   │
│  │   AST Indexer    │    │  Vector DB Indexer      │   │
│  │  (Tree-sitter)   │    │  (Embeddings + FAISS)   │   │
│  └──────────────────┘    └─────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                   Storage Layer                          │
│  ┌──────────────┐  ┌───────────┐  ┌──────────────────┐ │
│  │ Local SQLite │  │   FAISS   │  │  PostgreSQL      │ │
│  │  (Symbols)   │  │ (Vectors) │  │ (Team/Enterprise)│ │
│  └──────────────┘  └───────────┘  └──────────────────┘ │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│                   Query Layer                            │
│  - Symbol lookup (AST index)                            │
│  - Semantic search (Vector DB)                          │
│  - Call hierarchy (Call graph)                          │
│  - Cross-project search (Team tier)                     │
└─────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────┐
│               Team Sync Service (v2.5+)                 │
│  - WebSocket sync                                        │
│  - Team analytics                                        │
│  - Shared indexes                                        │
└─────────────────────────────────────────────────────────┘
```

### Directory Structure

```
contextdigger/
├── contextdigger/
│   ├── __init__.py
│   ├── discover.py           # v1.0 - Area discovery
│   ├── manager.py            # v1.0 - Focus management
│   ├── commands.py           # v1.0 - CLI commands
│   ├── indexer/              # v2.0 - Symbol indexing
│   │   ├── __init__.py
│   │   ├── ast_parser.py     # Tree-sitter integration
│   │   ├── python_indexer.py # Python-specific indexing
│   │   ├── typescript_indexer.py
│   │   ├── dart_indexer.py
│   │   ├── apex_indexer.py
│   │   └── index_builder.py  # Orchestrates indexing
│   ├── vector/               # v3.0 - Vector DB
│   │   ├── __init__.py
│   │   ├── embedder.py       # Generate embeddings
│   │   ├── vector_store.py   # FAISS/ChromaDB interface
│   │   └── semantic_search.py
│   ├── query/                # v2.0+ - Query engine
│   │   ├── __init__.py
│   │   ├── symbol_query.py   # AST queries
│   │   ├── semantic_query.py # Vector queries
│   │   └── call_graph.py     # Call hierarchy
│   └── team/                 # v2.5+ - Team features
│       ├── __init__.py
│       ├── sync_client.py    # Sync with team server
│       └── analytics.py      # Team analytics
├── server/                   # v2.5+ - Team backend
│   ├── app.py                # FastAPI app
│   ├── routes/
│   │   ├── team.py
│   │   ├── index.py
│   │   └── analytics.py
│   ├── models/
│   │   ├── team.py
│   │   ├── symbol.py
│   │   └── user.py
│   └── services/
│       ├── auth.py           # SSO/SAML
│       ├── billing.py        # Stripe integration
│       └── sync.py           # Real-time sync
├── skills/                   # Claude Code skills
│   ├── init-focus.md
│   ├── dig.md
│   ├── find-symbol.md        # v2.0
│   └── find-similar.md       # v3.0
├── tests/
├── docs/
├── README.md
├── CHANGELOG.md
├── PRODUCT_ROADMAP.md        # This file
└── setup.py
```

### Data Storage Schema

#### Local Storage (.cdg/)

```
project-root/
└── .cdg/
    ├── config.json           # Configuration
    ├── areas/                # Discovered areas (v1.0)
    │   ├── area1.json
    │   └── area2.json
    ├── bookmarks/            # User bookmarks (v1.0)
    │   └── bookmarks.json
    ├── history/              # Navigation history (v1.0)
    │   └── history.json
    ├── index/                # Symbol index (v2.0)
    │   ├── symbols.db        # SQLite - All symbols
    │   ├── call_graph.db     # SQLite - Call relationships
    │   └── metadata.json     # Indexing metadata
    ├── vectors/              # Vector embeddings (v3.0)
    │   ├── embeddings.faiss  # FAISS index
    │   └── chunks.json       # Code chunk metadata
    └── team/                 # Team sync (v2.5)
        ├── team_id.txt       # Team identifier
        └── sync_state.json   # Last sync timestamp
```

#### SQLite Schema (symbols.db)

```sql
-- Symbols table (v2.0)
CREATE TABLE symbols (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,        -- 'class', 'function', 'method', 'variable'
    file_path TEXT NOT NULL,
    line_number INTEGER NOT NULL,
    language TEXT NOT NULL,
    area_id TEXT,
    signature TEXT,            -- Full function signature
    docstring TEXT,
    parent_symbol_id INTEGER,  -- For methods (parent class)
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_symbol_id) REFERENCES symbols(id)
);
CREATE INDEX idx_symbols_name ON symbols(name);
CREATE INDEX idx_symbols_file ON symbols(file_path);
CREATE INDEX idx_symbols_type ON symbols(type);

-- Call graph (v2.0)
CREATE TABLE calls (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    caller_id INTEGER NOT NULL,
    callee_id INTEGER NOT NULL,
    call_file TEXT NOT NULL,
    call_line INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (caller_id) REFERENCES symbols(id),
    FOREIGN KEY (callee_id) REFERENCES symbols(id),
    UNIQUE(caller_id, callee_id, call_file, call_line)
);
CREATE INDEX idx_calls_caller ON calls(caller_id);
CREATE INDEX idx_calls_callee ON calls(callee_id);

-- Imports (v2.0)
CREATE TABLE imports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_file TEXT NOT NULL,
    import_name TEXT NOT NULL,
    import_type TEXT,          -- 'module', 'function', 'class', 'variable'
    to_file TEXT,
    line_number INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_imports_from ON imports(from_file);
CREATE INDEX idx_imports_name ON imports(import_name);

-- File metadata (v2.0)
CREATE TABLE file_metadata (
    file_path TEXT PRIMARY KEY,
    last_indexed TIMESTAMP,
    file_hash TEXT,            -- SHA256 hash for change detection
    symbol_count INTEGER DEFAULT 0,
    language TEXT,
    area_id TEXT
);

-- Index stats (v2.0)
CREATE TABLE index_stats (
    key TEXT PRIMARY KEY,
    value TEXT
);
INSERT INTO index_stats VALUES ('version', '2.0');
INSERT INTO index_stats VALUES ('last_full_index', NULL);
INSERT INTO index_stats VALUES ('total_symbols', 0);
```

#### PostgreSQL Schema (Team/Enterprise)

```sql
-- Teams (v2.5)
CREATE TABLE teams (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    tier TEXT NOT NULL,       -- 'team', 'enterprise'
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Users (v2.5)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    name TEXT,
    team_id UUID REFERENCES teams(id),
    role TEXT DEFAULT 'member',  -- 'admin', 'member'
    created_at TIMESTAMP DEFAULT NOW()
);

-- Team symbols (v2.5)
CREATE TABLE team_symbols (
    id BIGSERIAL PRIMARY KEY,
    team_id UUID NOT NULL REFERENCES teams(id),
    symbol_name TEXT NOT NULL,
    symbol_type TEXT NOT NULL,
    file_path TEXT NOT NULL,
    repo_name TEXT NOT NULL,
    line_number INTEGER,
    signature TEXT,
    indexed_by_user_id UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_team_symbols_team ON team_symbols(team_id);
CREATE INDEX idx_team_symbols_name ON team_symbols(symbol_name);

-- Team analytics (v2.5)
CREATE TABLE team_analytics (
    id BIGSERIAL PRIMARY KEY,
    team_id UUID NOT NULL REFERENCES teams(id),
    user_id UUID NOT NULL REFERENCES users(id),
    action TEXT NOT NULL,     -- 'search', 'navigate', 'dig', 'find_symbol'
    target TEXT,
    query TEXT,
    time_saved_seconds INTEGER,
    timestamp TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_analytics_team ON team_analytics(team_id);
CREATE INDEX idx_analytics_user ON team_analytics(user_id);
CREATE INDEX idx_analytics_timestamp ON team_analytics(timestamp);

-- Subscriptions (v2.5)
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    team_id UUID NOT NULL REFERENCES teams(id),
    stripe_subscription_id TEXT UNIQUE,
    status TEXT NOT NULL,     -- 'active', 'cancelled', 'past_due'
    seats INTEGER NOT NULL,
    amount_cents INTEGER NOT NULL,
    interval TEXT NOT NULL,   -- 'month', 'year'
    current_period_end TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Audit logs (v3.5 Enterprise)
CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    team_id UUID NOT NULL REFERENCES teams(id),
    user_id UUID REFERENCES users(id),
    action TEXT NOT NULL,
    resource_type TEXT,
    resource_id TEXT,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_audit_team ON audit_logs(team_id);
CREATE INDEX idx_audit_timestamp ON audit_logs(timestamp);
```

### Language Support Matrix

| Language | Tree-sitter Grammar | AST Indexing | Vector Embeddings | Status |
|----------|-------------------|--------------|-------------------|--------|
| Python | ✅ Built-in | ✅ v2.0 | ✅ v3.0 | Priority |
| JavaScript | ✅ Available | ✅ v2.0 | ✅ v3.0 | Priority |
| TypeScript | ✅ Available | ✅ v2.0 | ✅ v3.0 | Priority |
| Dart | ✅ Available | ✅ v2.0 | ✅ v3.0 | Priority |
| Apex | ✅ Available | ✅ v2.0 | ✅ v3.0 | Priority |
| Go | ✅ Available | ⏳ v2.1 | ⏳ v3.0 | Medium |
| Rust | ✅ Available | ⏳ v2.1 | ⏳ v3.0 | Medium |
| Java | ✅ Available | ⏳ v2.2 | ⏳ v3.0 | Low |
| C/C++ | ✅ Available | ⏳ v2.2 | ⏳ v3.0 | Low |
| Ruby | ✅ Available | ⏳ v2.2 | ⏳ v3.0 | Low |
| PHP | ✅ Available | ⏳ v2.2 | ⏳ v3.0 | Low |

---

## Monetization Strategy

### Freemium Model

**Core Principle**: Core features free forever, team collaboration and advanced features are paid.

### Tier Structure

#### Free Tier (Individual Developers)

**Price**: $0 (forever)

**Features**:
- ✅ Full area discovery and navigation
- ✅ Bookmarks and history
- ✅ AST symbol indexing (all languages)
- ✅ Local symbol search and queries
- ✅ Go-to-definition, find references
- ✅ Call hierarchy (within project)
- ✅ 5 semantic searches per day (v3.0+)
- ✅ Local-only storage
- ✅ Community support (GitHub)

**Storage Limits**:
- Up to 50 bookmarks per project
- Index up to 1M lines of code per project
- Local storage only (no cloud sync)

**Strategic Purpose**:
- Build large user base
- Word-of-mouth growth
- Demonstrate value before asking for payment
- Create upgrade funnel to Team tier

---

#### Team Tier ($15/user/month)

**Price**:
- $15/user/month (billed monthly)
- $150/user/year (17% discount, billed annually)
- Minimum 5 users

**Target**: Teams of 5-50 developers at startups, scaleups, agencies

**All Free Tier Features, PLUS**:

**Cross-Project Intelligence**:
- ✅ Unlimited bookmarks
- ✅ Cross-project symbol search ("Where is UserService across all repos?")
- ✅ Cross-project call hierarchy
- ✅ Cross-project dependency graphs

**Semantic Search**:
- ✅ 100 semantic searches per day (vs 5 in Free)
- ✅ Code similarity detection ("Find duplicates")
- ✅ Smart documentation ("Show me examples")

**Team Collaboration**:
- ✅ Shared symbol indexes (team members see same indexed code)
- ✅ Shared bookmarks
- ✅ Real-time sync (see what teammates are exploring)
- ✅ Team activity feed

**Analytics & Insights**:
- ✅ Team analytics dashboard
- ✅ Most-searched symbols
- ✅ Code hotspots (most-edited areas)
- ✅ Productivity metrics (time saved per developer)
- ✅ Custom reports (CSV/JSON export)

**Support**:
- ✅ Priority email support (24-hour response SLA)
- ✅ Slack/Discord support channel
- ✅ Feature requests prioritized

**Authentication**:
- ✅ SSO integration (Google, GitHub, Okta)
- ✅ Team member management
- ✅ Role-based permissions (admin/member)

**Value Proposition**:
```
5-person team value calculation:
- Time saved: 2 hours/developer/day
- Hourly rate: $120/hour
- Value per month: 5 × 2 × 20 × $120 = $24,000

Team tier cost:
- 5 users × $15/month = $75/month

ROI: 320x return on investment
Payback period: 2.3 hours of use
```

---

#### Enterprise Tier ($40/user/month)

**Price**:
- $40/user/month (billed monthly)
- $400/user/year (17% discount, billed annually)
- Minimum 50 users
- Volume discounts available (200+ users)

**Target**: Large companies (50-1000+ developers), Fortune 500, regulated industries

**All Team Tier Features, PLUS**:

**Unlimited Everything**:
- ✅ Unlimited semantic searches
- ✅ Unlimited projects/repos
- ✅ Unlimited storage

**Advanced Security**:
- ✅ Security pattern detection (SQL injection, XSS, etc.)
- ✅ Vulnerability scanning ("Find code similar to CVE-2024-1234")
- ✅ Hardcoded secrets detection
- ✅ Custom security rules

**Compliance & Governance**:
- ✅ GDPR compliance scanning (find PII access)
- ✅ HIPAA compliance scanning (find PHI handling)
- ✅ SOC 2 Type II certified infrastructure
- ✅ Custom compliance rules
- ✅ Audit logs (all operations tracked)

**Custom Query Engine**:
- ✅ Custom AST queries (write your own)
- ✅ API access (REST + GraphQL)
- ✅ Webhooks (integrate with CI/CD)
- ✅ Advanced analytics (code complexity, dead code detection)

**Enterprise Infrastructure**:
- ✅ Self-hosted option (Docker/Kubernetes deployment)
- ✅ Data residency (deploy in your VPC/region)
- ✅ Private embedding models (models never leave your network)
- ✅ SSO/SAML (Okta, Azure AD, OneLogin, custom)
- ✅ SLA guarantees (99.9% uptime, 4-hour response)

**Dedicated Support**:
- ✅ Dedicated Customer Success Manager (CSM)
- ✅ Slack/Teams channel with engineering team
- ✅ Onboarding & training sessions (live)
- ✅ Custom feature development (for large contracts)
- ✅ Architecture review sessions

**Value Proposition**:
```
100-person team value calculation:
- Time saved: 2 hours/developer/day
- Hourly rate: $160/hour
- Value per month: 100 × 2 × 20 × $160 = $640,000

Enterprise tier cost:
- 100 users × $40/month = $4,000/month

ROI: 160x return on investment
Annual savings: $7.68M - $48k = $7.63M
```

---

### Pricing Comparison Table

| Feature | Free | Team ($15/mo) | Enterprise ($40/mo) |
|---------|------|---------------|---------------------|
| **Discovery & Navigation** |
| Area discovery | ✅ | ✅ | ✅ |
| Focus switching | ✅ | ✅ | ✅ |
| Bookmarks | 50 | Unlimited | Unlimited |
| History tracking | ✅ | ✅ | ✅ |
| **Symbol Indexing (v2.0)** |
| AST symbol indexing | ✅ | ✅ | ✅ |
| Go-to-definition | ✅ (local) | ✅ (cross-project) | ✅ (cross-project) |
| Find references | ✅ (local) | ✅ (cross-project) | ✅ (cross-project) |
| Call hierarchy | ✅ (local) | ✅ (cross-project) | ✅ (cross-project) |
| Dependency graphs | ✅ (local) | ✅ (cross-project) | ✅ (cross-project) |
| **Semantic Search (v3.0)** |
| Semantic searches/day | 5 | 100 | Unlimited |
| Code similarity detection | ❌ | ✅ | ✅ |
| Smart documentation | ❌ | ✅ | ✅ |
| **Team Collaboration** |
| Shared indexes | ❌ | ✅ | ✅ |
| Shared bookmarks | ❌ | ✅ | ✅ |
| Real-time sync | ❌ | ✅ | ✅ |
| Team analytics | ❌ | ✅ | ✅ |
| **Security & Compliance** |
| Security pattern detection | ❌ | ❌ | ✅ |
| Vulnerability scanning | ❌ | ❌ | ✅ |
| GDPR/HIPAA scanning | ❌ | ❌ | ✅ |
| Audit logs | ❌ | ❌ | ✅ |
| **Infrastructure** |
| Self-hosted option | ❌ | ❌ | ✅ |
| Private embeddings | ❌ | ❌ | ✅ |
| Data residency | ❌ | ❌ | ✅ |
| SLA guarantees | ❌ | ❌ | 99.9% |
| **Support** |
| Community (GitHub) | ✅ | ✅ | ✅ |
| Email support | ❌ | 24hr SLA | 4hr SLA |
| Dedicated CSM | ❌ | ❌ | ✅ |
| Training sessions | ❌ | ❌ | ✅ |
| **API & Integrations** |
| API access | ❌ | ❌ | ✅ |
| Webhooks | ❌ | ❌ | ✅ |
| Custom queries | ❌ | ❌ | ✅ |

---

### Revenue Projections

#### Conservative Scenario (24 months)

**Free Users**: 5,000
- GitHub stars, word-of-mouth
- Free tier attracts individual developers
- Conversion to paid: 5-10%

**Team Tier**:
- 30 teams × 8 avg users = 240 users
- $15/user/month × 240 users = $3,600/month
- **Annual: $43,200**

**Enterprise Tier**:
- 3 companies × 60 avg users = 180 users
- $40/user/month × 180 users = $7,200/month
- **Annual: $86,400**

**GitHub Sponsors**: $500/month = $6,000/year

**Total ARR: $135,600**

---

#### Moderate Scenario (24 months)

**Free Users**: 15,000
- Stronger word-of-mouth, blog posts, Product Hunt launch
- Conversion to paid: 8-12%

**Team Tier**:
- 100 teams × 10 avg users = 1,000 users
- $15/user/month × 1,000 users = $15,000/month
- **Annual: $180,000**

**Enterprise Tier**:
- 10 companies × 80 avg users = 800 users
- $40/user/month × 800 users = $32,000/month
- **Annual: $384,000**

**GitHub Sponsors**: $2,000/month = $24,000/year

**Total ARR: $588,000**

---

#### Optimistic Scenario (24 months)

**Free Users**: 50,000
- Viral growth, Hacker News, conferences, partnerships
- Conversion to paid: 10-15%

**Team Tier**:
- 250 teams × 12 avg users = 3,000 users
- $15/user/month × 3,000 users = $45,000/month
- **Annual: $540,000**

**Enterprise Tier**:
- 25 companies × 100 avg users = 2,500 users
- $40/user/month × 2,500 users = $100,000/month
- **Annual: $1,200,000**

**GitHub Sponsors**: $5,000/month = $60,000/year

**Total ARR: $1,800,000**

---

### Long-Term Projections (Year 3-5)

**Year 3**: $3-5M ARR
- 500+ team customers
- 50+ enterprise customers
- Platform expansion (Cursor, VS Code)
- API marketplace revenue

**Year 5**: $10-15M ARR
- 2,000+ team customers
- 150+ enterprise customers
- Enterprise dominance (80% of revenue)
- Potential acquisition target ($100M+ valuation)

---

## Feature Specifications

### v1.0 Features (Shipped)

#### 1. Area Discovery

**Purpose**: Automatically detect logical code areas in a project.

**How It Works**:
1. Detect languages (Python, JS/TS, Salesforce, Astro)
2. Detect monorepo vs single project
3. Find package/project config files
4. Create areas for major modules/packages
5. Save to `.cdg/areas/`

**Commands**:
- `contextdigger init` - Initialize discovery
- `contextdigger init -f` - Force re-discovery
- `contextdigger list` - List all areas

**Example Output**:
```bash
$ contextdigger init
✓ Initialized .cdg/ directory
⛏️  Digging through codebase...
🔍 Discovering focus areas...
   Found languages: python, javascript, salesforce
   Detected monorepo with 7 sub-projects
✓ Discovered 139 focus areas
```

---

#### 2. Focus Switching

**Purpose**: Switch context between different code areas.

**How It Works**:
1. User runs `/dig <area-name>`
2. ContextDigger loads area definition from `.cdg/areas/`
3. Updates current focus in `.cdg/config.json`
4. Shows area details (files, language, common tasks)

**Commands**:
- `/dig <area>` - Switch to area
- `/redig` - Show all areas for selection
- `/dig-dashboard` - Visual dashboard

**Example**:
```bash
$ contextdigger dig flowmason-studio-frontend-src
⛏️  Digging into: flowmason/studio/frontend Source
   Source code

   Language: typescript
   Files: ~47 TypeScript files

   Common tasks:
   - npm run dev
   - npm run build
   - npm run test
```

---

#### 3. Bookmarks

**Purpose**: Save important code locations for quick access.

**How It Works**:
1. User runs `/bookmark <name>` at a location
2. ContextDigger saves current file/line to `.cdg/bookmarks/`
3. User can jump back with `/goto <bookmark>`

**Commands**:
- `/bookmark <name>` - Save current location
- `/goto <bookmark>` - Jump to bookmark
- `/list-bookmarks` - Show all bookmarks

**Example**:
```bash
$ contextdigger bookmark auth-handler
✓ Bookmarked: auth-handler
  Location: flowmason/core/auth/handler.py:47

$ contextdigger goto auth-handler
⛏️  Jumping to: auth-handler
   flowmason/core/auth/handler.py:47
```

---

### v2.0 Features (Planned)

#### 1. AST Symbol Indexing

**Purpose**: Build a local index of all code symbols (classes, functions, methods).

**How It Works**:
1. Use Tree-sitter to parse source files into AST
2. Extract symbols (classes, functions, methods, imports)
3. Store in SQLite database (`.cdg/index/symbols.db`)
4. Build call graph (track function calls)
5. Enable instant symbol lookups (no context needed)

**Implementation**:

```python
# Example: Index Python file
from tree_sitter import Language, Parser

class PythonIndexer:
    def __init__(self):
        self.parser = Parser()
        self.parser.set_language(Language('build/languages.so', 'python'))

    def index_file(self, file_path: str) -> List[Symbol]:
        """Extract all symbols from a Python file"""
        with open(file_path, 'rb') as f:
            tree = self.parser.parse(f.read())

        symbols = []

        # Query for classes
        class_query = """
            (class_definition
                name: (identifier) @class_name
                body: (block) @class_body)
        """

        # Query for functions
        function_query = """
            (function_definition
                name: (identifier) @function_name
                parameters: (parameters) @params
                body: (block) @body)
        """

        # Extract symbols using queries
        for match in run_query(tree, class_query):
            symbols.append(Symbol(
                name=match['class_name'],
                type='class',
                file=file_path,
                line=match['line'],
            ))

        return symbols
```

**Commands**:
- `/find-symbol <name>` - Find where symbol is defined
- `/find-references <symbol>` - Find all usages
- `/show-callers <function>` - Show call hierarchy
- `/show-callees <function>` - Show what this function calls
- `/show-dependencies <module>` - Show imports/dependencies
- `/rebuild-index` - Re-index all files

**Example Usage**:
```bash
$ contextdigger find-symbol UserAuthService
📍 Found: flowmason/core/auth/user_service.py:47

   class UserAuthService:
       """Handles user authentication and session management"""

       def __init__(self, db: Database):
           self.db = db

$ contextdigger find-references authenticate
📍 Found 23 references:

   1. flowmason/api/auth.py:89
      result = auth_service.authenticate(username, password)

   2. flowmason/middleware/auth.py:34
      if not self.auth_service.authenticate(token):

   3. flowmason/tests/auth_test.py:56
      assert service.authenticate("user", "pass") is not None

   ... (20 more)

$ contextdigger show-callers authenticate
📞 authenticate() is called by:

   ├─ login() (api/auth.py:89)
   │  ├─ handle_login_request() (api/routes.py:45)
   │  └─ process_oauth() (api/oauth.py:23)
   │
   ├─ verify_token() (middleware/auth.py:34)
   │  └─ auth_middleware() (middleware/auth.py:12)
   │      └─ app() (main.py:23)
   │
   └─ test_authenticate() (tests/auth_test.py:56)
```

**Performance Targets**:
- Index 100k lines in <30 seconds
- Query response <50ms
- Incremental update <5 seconds for 10 files

---

#### 2. Call Graph Visualization

**Purpose**: Understand code dependencies and call relationships.

**How It Works**:
1. During indexing, track all function calls
2. Build directed graph (caller → callee)
3. Store in `call_graph.db`
4. Generate ASCII or visual graph

**Example**:
```bash
$ contextdigger call-graph authenticate --depth 2

authenticate() (auth/user_service.py:89)
   │
   ├─ Called by:
   │  ├─ login() (api/auth.py:45)
   │  ├─ verify_token() (middleware/auth.py:23)
   │  └─ refresh_session() (api/session.py:67)
   │
   └─ Calls:
      ├─ hash_password() (utils/crypto.py:34)
      ├─ db.query() (database/client.py:89)
      └─ log_attempt() (logging/auth_logger.py:12)
```

---

### v3.0 Features (Planned)

#### 1. Semantic Code Search

**Purpose**: Find code by meaning, not just keywords.

**How It Works**:
1. Chunk code into semantic units (functions, classes)
2. Generate embeddings using CodeBERT or similar
3. Store in FAISS vector database
4. Enable natural language queries

**Implementation**:
```python
from sentence_transformers import SentenceTransformer
import faiss

class SemanticIndexer:
    def __init__(self):
        # Use code-specific embedding model
        self.model = SentenceTransformer('microsoft/codebert-base')
        self.index = faiss.IndexFlatL2(768)  # 768-dim embeddings
        self.chunks = []  # Store code chunks

    def index_code_chunk(self, code: str, metadata: dict):
        """Generate embedding and add to index"""
        # Add language context
        prompt = f"[{metadata['language']}] {code}"

        # Generate embedding
        embedding = self.model.encode(prompt)

        # Add to FAISS index
        self.index.add(embedding.reshape(1, -1))
        self.chunks.append({
            'code': code,
            'file': metadata['file'],
            'line': metadata['line'],
            'type': metadata['type'],  # 'function', 'class', etc.
        })

    def search(self, query: str, k: int = 10):
        """Search for similar code"""
        query_embedding = self.model.encode(query)

        # Search FAISS index
        distances, indices = self.index.search(
            query_embedding.reshape(1, -1),
            k
        )

        # Return ranked results
        results = []
        for i, idx in enumerate(indices[0]):
            chunk = self.chunks[idx]
            results.append({
                **chunk,
                'similarity': 1 - distances[0][i],  # Convert distance to similarity
            })

        return results
```

**Commands**:
- `/find-similar <query>` - Semantic search
- `/find-duplicates` - Find duplicate/similar code
- `/find-examples <api>` - Find usage examples

**Example Usage**:
```bash
$ contextdigger find-similar "code that handles JWT authentication"
🔍 Found 8 similar code blocks:

1. flowmason/auth/jwt_handler.py:23 (similarity: 0.94)

   def verify_jwt_token(token: str) -> Dict:
       """Verify and decode JWT authentication token"""
       try:
           payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
           return payload
       except jwt.ExpiredSignatureError:
           raise AuthenticationError("Token expired")

2. flowmason/middleware/auth.py:45 (similarity: 0.89)

   def authenticate_request(request: Request):
       """Authenticate incoming request using JWT"""
       token = request.headers.get('Authorization', '').replace('Bearer ', '')
       return verify_jwt_token(token)

3. flowmason/api/oauth.py:67 (similarity: 0.82)

   def exchange_oauth_for_jwt(oauth_token: str):
       """Exchange OAuth token for internal JWT"""
       user = validate_oauth_token(oauth_token)
       return generate_jwt(user.id)

$ contextdigger find-duplicates --threshold 0.9
🔍 Found 3 sets of duplicate/similar code:

1. Database connection handling (similarity: 0.95)
   - flowmason/api/db.py:23
   - flowmason/services/db_client.py:45
   - flowmason/workers/db_connection.py:67

   Suggestion: Extract to shared module

2. Error logging (similarity: 0.92)
   - flowmason/api/errors.py:12
   - flowmason/services/error_handler.py:34

   Suggestion: Consolidate error handling
```

**Free vs Paid**:
- Free: 5 semantic searches per day
- Team: 100 semantic searches per day
- Enterprise: Unlimited

---

#### 2. Code Similarity Detection

**Purpose**: Find duplicate or near-duplicate code for refactoring.

**How It Works**:
1. Use semantic embeddings to compare code chunks
2. Calculate cosine similarity between all chunks
3. Identify clusters of similar code (threshold > 0.85)
4. Suggest refactoring opportunities

**Example Output**:
```bash
$ contextdigger find-duplicates --threshold 0.85

🔍 Found 12 sets of similar code:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set 1: API endpoint error handling (5 occurrences)
Similarity: 0.94 | Refactoring potential: HIGH
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. flowmason/api/auth.py:34-45
   try:
       result = authenticate_user(data)
       return JSONResponse(result)
   except ValidationError as e:
       return JSONResponse({"error": str(e)}, status_code=400)

2. flowmason/api/users.py:67-78 (similarity: 0.96)
3. flowmason/api/projects.py:23-34 (similarity: 0.94)
4. flowmason/api/teams.py:89-100 (similarity: 0.93)
5. flowmason/api/billing.py:45-56 (similarity: 0.91)

💡 Suggestion: Extract to @handle_errors decorator

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Set 2: Database query patterns (7 occurrences)
Similarity: 0.89 | Refactoring potential: MEDIUM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. flowmason/services/user_service.py:45
2. flowmason/services/project_service.py:67
... (5 more)

💡 Suggestion: Create BaseService class with shared methods
```

---

### v3.5 Features (Enterprise)

#### 1. Security Pattern Detection

**Purpose**: Scan for known security vulnerabilities and bad patterns.

**How It Works**:
1. Define security patterns (SQL injection, XSS, hardcoded secrets)
2. Use AST + regex to detect patterns
3. Use semantic search to find "code similar to CVE-XXXX"
4. Generate security report

**Example Patterns**:
```python
SECURITY_PATTERNS = {
    'sql_injection': {
        'name': 'SQL Injection Vulnerability',
        'severity': 'HIGH',
        'description': 'String concatenation in SQL query',
        'pattern': r'execute\(.*\+.*\)|query\(.*\+.*\)',
        'example': 'cursor.execute("SELECT * FROM users WHERE id=" + user_id)',
        'fix': 'Use parameterized queries: cursor.execute("SELECT * FROM users WHERE id=%s", (user_id,))',
    },
    'hardcoded_secrets': {
        'name': 'Hardcoded Secrets',
        'severity': 'CRITICAL',
        'description': 'API keys or passwords in source code',
        'pattern': r'(api_key|password|secret|token)\s*=\s*["\'][^"\']{16,}["\']',
        'example': 'API_KEY = "sk-1234567890abcdef"',
        'fix': 'Use environment variables: API_KEY = os.getenv("API_KEY")',
    },
    'xss': {
        'name': 'Cross-Site Scripting (XSS)',
        'severity': 'HIGH',
        'description': 'Unescaped user input in HTML',
        'pattern': r'innerHTML\s*=|dangerouslySetInnerHTML',
        'example': 'element.innerHTML = user_input',
        'fix': 'Use textContent or sanitize input',
    },
}
```

**Commands**:
- `/scan-security` - Scan entire codebase
- `/scan-security --file <path>` - Scan specific file
- `/scan-security --pattern sql_injection` - Scan for specific pattern

**Example Output**:
```bash
$ contextdigger scan-security

🔍 Security Scan Results
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔴 CRITICAL (3 issues)
  ├─ Hardcoded API key (api/config.py:12)
  ├─ Hardcoded database password (services/db.py:34)
  └─ Private key in repository (certs/private_key.pem)

🟠 HIGH (12 issues)
  ├─ SQL Injection (api/users.py:67)
  ├─ SQL Injection (api/projects.py:89)
  ├─ XSS vulnerability (frontend/components/Profile.tsx:45)
  ... (9 more)

🟡 MEDIUM (27 issues)
  ├─ Weak cryptographic hash (utils/crypto.py:23)
  ├─ Insecure random number (services/token.py:56)
  ... (25 more)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Details:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔴 CRITICAL: Hardcoded API key
File: flowmason/api/config.py:12

Code:
   10 | # Stripe configuration
   11 | STRIPE_PUBLISHABLE_KEY = "pk_test_123..."
>> 12 | STRIPE_SECRET_KEY = "sk_live_1234567890abcdef"
   13 |

Issue: API secret key is hardcoded in source code. This is a
       critical security vulnerability. Anyone with access to the
       repository can use this key.

Fix: Use environment variables:
     STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY")

Reference: OWASP A02:2021 – Cryptographic Failures
```

---

#### 2. Compliance Scanning

**Purpose**: Find code that handles sensitive data (PII, PHI) for compliance (GDPR, HIPAA).

**Example**:
```bash
$ contextdigger scan-compliance gdpr

🔍 GDPR Compliance Scan
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Found 47 locations accessing Personally Identifiable Information (PII)

📧 Email Address Access (23 locations)
  ├─ flowmason/api/users.py:45 - User.email (CREATE)
  ├─ flowmason/api/users.py:67 - User.email (READ)
  ├─ flowmason/services/email.py:23 - send_email(user.email)
  ... (20 more)

📱 Phone Number Access (12 locations)
  ├─ flowmason/models/user.py:34 - User.phone (STORE)
  ├─ flowmason/api/profile.py:56 - User.phone (READ)
  ... (10 more)

🏠 Address Information (8 locations)
  ├─ flowmason/api/billing.py:45 - BillingAddress (CREATE)
  ... (7 more)

💳 Payment Information (4 locations)
  ├─ flowmason/services/stripe.py:67 - process_payment()
  ... (3 more)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
GDPR Compliance Checklist:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ Data encryption at rest
✅ Data encryption in transit (HTTPS)
⚠️  Missing data retention policy
⚠️  Missing "right to erasure" implementation
❌ No audit logs for PII access
❌ Missing consent tracking

Recommendations:
1. Implement audit logging for all PII access
2. Add data retention cleanup job
3. Implement user data export feature
4. Add consent management system
```

---

## Implementation Phases

### Phase 1: v1.1 Bug Fixes (Week 1-2, COMPLETED)

**Goal**: Fix critical discovery bugs

**Tasks**:
- [x] Remove hardcoded `flowmason_core` package name
- [x] Fix `.mypy_cache` pollution
- [x] Extend discovery depth to 1-3 levels
- [x] Add proper exclusion patterns
- [x] Test on FlowMason project
- [x] Release v1.1

**Effort**: 8 hours
**Status**: ✅ COMPLETED (2025-12-21)

---

### Phase 2: v2.0 AST Indexing (Month 3-6)

**Goal**: Build core symbol indexing infrastructure

#### Week 1-4: Foundation
- [ ] Research Tree-sitter integration
- [ ] Design index schema (SQLite)
- [ ] Implement base `Indexer` class
- [ ] Implement `PythonIndexer`
- [ ] Test on small Python project

#### Week 5-8: Multi-Language Support
- [ ] Implement `TypeScriptIndexer`
- [ ] Implement `DartIndexer`
- [ ] Implement `ApexIndexer`
- [ ] Build unified indexing pipeline
- [ ] Incremental update logic

#### Week 9-12: Query Interface
- [ ] Implement symbol lookup queries
- [ ] Implement reference finding
- [ ] Build call graph
- [ ] Implement dependency tracking
- [ ] CLI commands (`/find-symbol`, etc.)

#### Week 13-16: Polish & Release
- [ ] Performance optimization (<100ms queries)
- [ ] Index compression
- [ ] Error handling
- [ ] Documentation
- [ ] Release v2.0

**Effort**: 60-80 hours
**Status**: 🎯 PLANNED

---

### Phase 3: v2.5 Team Tier (Month 6-9)

**Goal**: Build team collaboration backend and launch paid tier

#### Week 1-4: Backend Infrastructure
- [ ] Set up FastAPI server
- [ ] PostgreSQL database schema
- [ ] User authentication (email/password)
- [ ] Team management (create, invite, roles)

#### Week 5-8: Team Features
- [ ] Cross-project symbol search
- [ ] Team index sync (WebSocket)
- [ ] Shared bookmarks
- [ ] Team analytics tracking

#### Week 9-10: Billing
- [ ] Stripe integration
- [ ] Subscription management
- [ ] Usage tracking
- [ ] Invoicing

#### Week 11-12: SSO & Security
- [ ] SSO integration (Google, GitHub)
- [ ] Okta SAML support
- [ ] Security audit
- [ ] Penetration testing

#### Week 13-16: Launch
- [ ] Beta program (10-15 teams)
- [ ] Marketing website updates
- [ ] Pricing page
- [ ] Product Hunt launch
- [ ] Hacker News post

**Effort**: 80-120 hours
**Status**: 🎯 PLANNED

---

### Phase 4: v3.0 Vector DB (Month 9-12)

**Goal**: Add semantic search capabilities

#### Week 1-4: Embedding Infrastructure
- [ ] Research embedding models (CodeBERT, etc.)
- [ ] Set up local embedding pipeline
- [ ] FAISS vector database integration
- [ ] Code chunking strategy

#### Week 5-8: Semantic Search
- [ ] Implement embedding generation
- [ ] Build vector index
- [ ] Implement semantic search queries
- [ ] Incremental vector updates

#### Week 9-12: Advanced Features
- [ ] Code similarity detection
- [ ] Duplicate code finder
- [ ] Smart documentation
- [ ] Usage example finder

#### Week 13-16: Integration & Launch
- [ ] Integrate with Team tier
- [ ] Usage limits (Free: 5/day, Team: 100/day)
- [ ] Performance optimization
- [ ] Release v3.0

**Effort**: 60-80 hours
**Status**: 🎯 PLANNED

---

### Phase 5: v3.5 Enterprise (Month 12-18)

**Goal**: Build enterprise features for large customers

#### Month 12-13: Security Scanning
- [ ] Define security patterns
- [ ] Implement pattern detection
- [ ] Vulnerability database integration
- [ ] Security report generation

#### Month 14-15: Compliance
- [ ] GDPR compliance scanning
- [ ] HIPAA compliance scanning
- [ ] Audit log system
- [ ] Compliance report generation

#### Month 16-17: Enterprise Infrastructure
- [ ] Self-hosted deployment (Docker)
- [ ] Kubernetes helm charts
- [ ] Private embedding models
- [ ] SLA monitoring

#### Month 18: Certification & Launch
- [ ] SOC 2 Type II certification
- [ ] Security audit
- [ ] Enterprise sales enablement
- [ ] Launch v3.5

**Effort**: 120-160 hours
**Status**: 🎯 PLANNED

---

## Risk Analysis

### Technical Risks

#### Risk 1: Tree-sitter Integration Complexity
**Likelihood**: MEDIUM
**Impact**: HIGH
**Mitigation**:
- Start with Python (simplest)
- Prototype on small codebase first
- Budget 20% extra time for edge cases
- Use existing Tree-sitter bindings (well-tested)

#### Risk 2: Index Performance on Large Codebases
**Likelihood**: MEDIUM
**Impact**: MEDIUM
**Mitigation**:
- Set performance targets early (<100ms queries)
- Profile and optimize continuously
- Use incremental indexing (only re-index changed files)
- Add index compression if needed
- Consider sharding for 10M+ line codebases

#### Risk 3: Vector DB Storage/Performance
**Likelihood**: LOW
**Impact**: MEDIUM
**Mitigation**:
- Use proven vector DBs (FAISS, ChromaDB)
- Start with smaller embedding dimensions (384 vs 768)
- Implement lazy loading
- Cache frequently-used embeddings

#### Risk 4: Multi-Language AST Parsing Accuracy
**Likelihood**: MEDIUM
**Impact**: MEDIUM
**Mitigation**:
- Comprehensive test suite per language
- Handle parse errors gracefully (skip unparseable files)
- Allow manual symbol annotations
- Community feedback loop for edge cases

---

### Business Risks

#### Risk 1: Claude Code Dependency
**Likelihood**: HIGH
**Impact**: HIGH
**Description**: ContextDigger currently depends on Claude Code. If Anthropic changes API or blocks extensions, product breaks.

**Mitigation**:
- **Diversify platforms** - Add Cursor support in v4.0 (Month 18-24)
- **Open architecture** - Design to work with any AI assistant
- **Relationship building** - Build relationship with Anthropic team
- **Backup plan** - VS Code extension as fallback

#### Risk 2: Low Willingness to Pay
**Likelihood**: MEDIUM
**Impact**: HIGH
**Description**: Developers might not pay $15/user/month for team features.

**Mitigation**:
- **Generous free tier** - Validate value before asking for payment
- **Clear ROI** - Quantify time savings (2+ hours/day)
- **Pricing calculator** - Show $24k/month value for $75/month cost
- **Beta discounts** - 50% off for first 6 months
- **GitHub Sponsors** - Start monetizing early

#### Risk 3: Competitor Launches Similar Product
**Likelihood**: MEDIUM
**Impact**: MEDIUM
**Description**: Someone else builds AST/vector indexing for AI assistants.

**Mitigation**:
- **Move fast** - Launch v2.0 in 6 months (first-mover advantage)
- **Build moat** - Hybrid AST + vector is hard to replicate
- **Enterprise features** - Compliance/security are defensible
- **Execution quality** - Be the best, not just the first

#### Risk 4: Can't Hire Fast Enough
**Likelihood**: MEDIUM
**Impact**: MEDIUM
**Description**: Building all features requires hiring engineers but competition for talent is high.

**Mitigation**:
- **Bootstrap first** - Validate PMF before hiring
- **Contractors** - Use specialists for specific features
- **Keep scope tight** - Focus on high-impact features only
- **Dogfood product** - Use ContextDigger to build ContextDigger (increase productivity)

#### Risk 5: Enterprise Sales Too Slow
**Likelihood**: HIGH
**Impact**: LOW
**Description**: Enterprise sales cycles are 6-12 months, might delay revenue.

**Mitigation**:
- **Focus on Team tier first** - Faster sales cycles (14 days)
- **Build enterprise features in parallel** - Ready when first enterprise prospect appears
- **Target startups/scaleups first** - Faster decision-making
- **Have 12-18 months runway** - Don't depend on Enterprise revenue early

---

### Market Risks

#### Risk 1: AI Coding Assistant Market Too Small
**Likelihood**: LOW
**Impact**: HIGH
**Description**: Not enough developers use Claude Code/Cursor to support a business.

**Mitigation**:
- **Market is growing rapidly** - Claude Code, Cursor, Copilot, Cody all launched 2023-2024
- **Monitor adoption** - Track Claude Code/Cursor user growth
- **Expand to VS Code** - Largest market (5M+ developers) as backup
- **Pivot to general IDE** - If AI assistants don't grow, pivot to VS Code/JetBrains

#### Risk 2: Context Windows Get So Large Indexing Isn't Needed
**Likelihood**: LOW
**Impact**: HIGH
**Description**: If Claude supports 10M token context, maybe indexing isn't valuable.

**Mitigation**:
- **Cost advantage** - Even with 10M context, queries cost $$$ per API call. Local index is free.
- **Speed advantage** - API calls take seconds, local queries take milliseconds
- **Privacy advantage** - Enterprise customers prefer local-only (no data sent to Anthropic)
- **Context still limited** - 10M tokens still can't fit entire Google/Meta codebase

---

## Success Metrics

### v1.0 Metrics (Current)

**Product Metrics**:
- ✅ GitHub stars: 50+ (current)
- ✅ PyPI downloads: 500+ (current)
- ✅ Active users: 100+ (estimated)

**Technical Metrics**:
- ✅ Discovery success rate: 95%+ (after v1.1 fixes)
- ✅ Area discovery time: <10 seconds for 100k lines
- ✅ Supported languages: 4 (Python, JS/TS, Salesforce, Astro)

---

### v2.0 Metrics (6 months)

**Product Metrics**:
- 5,000+ users adopt v2.0
- 10,000+ GitHub stars
- 50+ large codebases indexed (>500k lines)
- 30-day retention: 40%+

**Technical Metrics**:
- Index 100k lines in <30 seconds
- Query speed: <100ms average
- Index size: <50MB for 1M lines
- Incremental update: <5 seconds for 10 files
- Supported languages: 6+ (Python, TS, JS, Dart, Apex, Go)

**User Feedback**:
- NPS score: >40
- "This is a game-changer" sentiment in 50%+ of feedback

---

### v2.5 Metrics (9 months)

**Revenue Metrics**:
- 50-100 paying teams
- $9k-18k MRR ($108k-216k ARR)
- <5% monthly churn
- Trial-to-paid conversion: >25%

**Product Metrics**:
- 10,000+ free users
- 20,000+ GitHub stars
- 500+ team users
- Team tier usage: 80%+ DAU

**Sales Metrics**:
- Sales cycle (Team): <14 days average
- Demo-to-close rate: >40%
- Customer Acquisition Cost (CAC): <$500

---

### v3.0 Metrics (12 months)

**Revenue Metrics**:
- $30k-50k MRR ($360k-600k ARR)
- 70% of Team tier users use semantic search
- Average 20 semantic searches per user per week

**Product Metrics**:
- 20,000+ free users
- 1,000+ team users
- 50+ enterprise prospects in pipeline

**Technical Metrics**:
- Vector index: 95%+ query accuracy
- Semantic search: <500ms response time
- Duplicate detection: 90%+ accuracy

---

### v3.5 Metrics (18 months)

**Revenue Metrics**:
- 10-25 enterprise customers
- Average contract value: $40k-120k/year
- $500k+ ARR from Enterprise tier

**Compliance Metrics**:
- SOC 2 Type II certified
- GDPR compliance scanning: 95%+ accuracy
- Security pattern detection: <5% false positives

**Enterprise Metrics**:
- Sales cycle (Enterprise): <90 days
- <3% annual churn
- Net Revenue Retention: >100%

---

### Long-Term Metrics (24 months)

**Revenue Metrics**:
- $1.5M-2M ARR
- 250+ team customers
- 25+ enterprise customers

**Product Metrics**:
- 50,000+ free users
- 3,000+ paying users
- Platform expansion: Cursor support launched

**Market Metrics**:
- Top 3 code intelligence tools for AI assistants
- Recognized brand in developer tools space
- Path to $5M ARR within 3 years

---

## Appendix

### Competitive Landscape

**Direct Competitors**:
- None currently (first-mover advantage in AI assistant + indexing space)

**Adjacent Competitors**:
1. **Traditional IDEs** (VS Code, JetBrains)
   - Have symbol indexing but not optimized for AI workflows
   - Missing semantic search
   - Missing team collaboration
   - Not AI-native

2. **Code Search Tools** (Sourcegraph, OpenGrok)
   - Enterprise-focused
   - Expensive ($99-199/user/month)
   - Not designed for AI assistants
   - Missing semantic search

3. **AI Coding Assistants** (GitHub Copilot, Tabnine, Cody)
   - Compete on code generation, not navigation
   - Missing deep code intelligence
   - Context window limited

**Our Advantage**:
- Purpose-built for AI coding assistants (Claude Code, Cursor)
- Hybrid AST + vector DB (unique combination)
- Free tier (competitors are expensive)
- Context-window independence (solves real pain)

---

### Technology Stack

**Client (CLI)**:
- Python 3.9+
- Tree-sitter (AST parsing)
- SQLite (symbol index)
- FAISS or ChromaDB (vector DB)
- Click (CLI framework)

**Server (Team/Enterprise)**:
- FastAPI (Python backend)
- PostgreSQL (team data)
- Redis (caching, real-time sync)
- WebSockets (real-time updates)
- Stripe (billing)

**Deployment**:
- PyPI (Python package)
- Docker (self-hosted option)
- DigitalOcean/Railway (hosted service)
- Kubernetes (enterprise)

**Monitoring**:
- Sentry (error tracking)
- Plausible Analytics (privacy-focused)
- PostHog (product analytics)

---

### Team Structure (Future)

**Year 1 (Bootstrap)**:
- Founder/CEO (product, engineering, sales)

**Year 2 (Post-Seed Funding)**:
- Founder/CEO
- Senior Backend Engineer (team features, indexing)
- Senior Frontend Engineer (dashboard, analytics)
- Sales/Customer Success (Team tier sales)

**Year 3 (Scale)**:
- Founder/CEO
- CTO (technical leadership)
- 2-3 Backend Engineers
- 1 Frontend Engineer
- Enterprise Account Executive
- Customer Success Manager
- Developer Advocate (community, content)

---

### Resources & References

**Documentation**:
- Tree-sitter: https://tree-sitter.github.io/
- FAISS: https://github.com/facebookresearch/faiss
- ChromaDB: https://www.trychroma.com/
- CodeBERT: https://huggingface.co/microsoft/codebert-base

**Inspiration**:
- Sourcegraph: Code intelligence at scale
- Cursor: AI-first code editor
- GitHub Copilot: AI code generation
- Anthropic Claude: Long context AI assistant

**Market Research**:
- Stack Overflow Developer Survey 2024
- GitHub Octoverse Report 2024
- State of AI Coding Assistants 2024

---

## Conclusion

ContextDigger is positioned to become the **essential code intelligence platform** for the AI coding assistant era. By combining AST indexing with vector database semantic search, we eliminate context window constraints and enable developers to work with codebases of any size.

**Key Takeaways**:

1. **Clear Product Vision**: Context-free code intelligence for AI assistants
2. **Strong Monetization**: Freemium model with clear value ladder (Free → $15 → $40)
3. **Technical Moat**: Hybrid AST + Vector DB is hard to replicate
4. **Market Timing**: AI coding assistants are exploding in 2024-2025
5. **Execution Plan**: Phased rollout (v1.1 → v2.0 → v2.5 → v3.0 → v3.5)

**Next Steps**:

1. ✅ Complete v1.1 bug fixes (DONE)
2. 🎯 Start v2.0 AST indexing (Python + TypeScript)
3. 🎯 Launch GitHub Sponsors (immediate revenue)
4. 🎯 Build v2.0 prototype on FlowMason codebase
5. 🎯 Validate product-market fit with beta users

**The Opportunity**:
- $2-5M ARR within 24 months
- Potential $100M+ valuation at scale
- Transform how developers use AI coding assistants

---

**Document Version History**:
- v1.0 (2025-12-21): Initial comprehensive roadmap
- v2.0 (2025-12-21): Added monetization, technical specs, implementation phases

**Maintained By**: Sam Alameh
**Last Review**: 2025-12-21
**Next Review**: 2026-01-21
