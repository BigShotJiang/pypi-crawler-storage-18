---
name: Bug Report
about: Report a bug or issue with ContextDigger
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description

A clear and concise description of the bug.

## Steps to Reproduce

1. Go to '...'
2. Run command '...'
3. See error

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened.

## Error Messages

```
Paste full error messages and stack traces here
```

## Environment

- **OS**: [e.g., macOS 13.0, Ubuntu 22.04, Windows 11]
- **Python Version**: [e.g., 3.11.5]
- **ContextDigger Version**: [run `contextdigger --version`]
- **Claude Code Version**: [if applicable]

## Project Context

- **Project Type**: [e.g., Python, JavaScript, monorepo]
- **Project Size**: [e.g., small <100 files, medium 100-1000, large >1000]
- **Number of Areas**: [if initialized]

## Additional Context

Add any other context about the problem here. Screenshots, logs, or configuration files can be helpful.

## Possible Solution

If you have ideas about what might be causing the issue or how to fix it, please share them here.
