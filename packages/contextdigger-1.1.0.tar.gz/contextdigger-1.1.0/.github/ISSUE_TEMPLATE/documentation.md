---
name: Documentation Issue
about: Report missing, unclear, or incorrect documentation
title: '[DOCS] '
labels: documentation
assignees: ''
---

## Documentation Issue

Describe what's missing, unclear, or incorrect in the documentation.

## Location

Where did you encounter this issue?

- [ ] README.md
- [ ] QUICKSTART.md
- [ ] CHANGELOG.md
- [ ] CONTRIBUTING.md
- [ ] Specific skill file: _____
- [ ] Code comments/docstrings
- [ ] Other: _____

## What's Wrong

What specifically is missing, unclear, or incorrect?

## Suggested Improvement

How would you improve or clarify this documentation?

## Context

What were you trying to do when you encountered this issue?

## Additional Information

Any other details that might be helpful.
