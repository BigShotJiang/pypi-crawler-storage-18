"""Sphinx application layer tests."""
