#!/usr/bin/env python3
import sys
import os

sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/..'))

from asyncdbus.service import ServiceInterface, method, signal, dbus_property
from asyncdbus.message_bus import MessageBus
from asyncdbus import Variant

import anyio


class ExampleInterface(ServiceInterface):
    def __init__(self, name):
        super().__init__(name)
        self._string_prop = 'kevin'

    @method()
    async def Echo(self, what: 's') -> 'ss':
        return ["This is the echo", what]

    @method()
    def EchoMultiple(self, what1: 's', what2: 's') -> 'ss':
        return [what1, what2]

    @method()
    def GetVariantDict(self) -> 'a{sv}':
        return {
            'foo': Variant('s', 'bar'),
            'bat': Variant('x', -55),
            'a_list': Variant('as', ['hello', 'world'])
        }

    @dbus_property(name='StringProp')
    def string_prop(self) -> 's':
        return self._string_prop

    @string_prop.setter
    def string_prop_setter(self, val: 's'):
        self._string_prop = val

    @signal()
    def signal_simple(self) -> 's':
        return 'hello'

    @signal()
    def signal_multiple(self) -> 'ss':
        return ['hello', 'world']


async def main():
    name = 'dbus.next.example.service'
    path = '/example/path'
    interface_name = 'example.interface'

    async with MessageBus().connect() as bus:
        interface = ExampleInterface(interface_name)
        await bus.export('/example/path', interface)
        await bus.request_name(name)
        print(f'service up on name: "{name}", path: "{path}", interface: "{interface_name}"')
        await anyio.sleep(99999)


anyio.run(main)
