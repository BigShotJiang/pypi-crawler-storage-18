"""Table view module for displaying tabular data in the terminal."""

from typing import Any, Dict, Optional, Sequence, Union

from pydantic import BaseModel
from rich.console import Console
from rich.table import Table

from vcp.view.table.model import (
    Column,
    ColumnViewConfigModel,
    OverflowEnum,
    TableViewConfigModel,
)

# ColumnData can be either a dictionary or a Pydantic model
ColumnData = Union[Dict[str, Any], BaseModel]

console = Console()


def _table_config_factory(data: Sequence[ColumnData]) -> TableViewConfigModel:
    return TableViewConfigModel()


def _get_keys(data: ColumnData) -> list[str]:
    """Extract keys from either dict or Pydantic model.

    Args:
        data: Dictionary or Pydantic model instance

    Returns:
        List of field/key names
    """
    if isinstance(data, dict):
        return list(data.keys())
    else:  # BaseModel
        return list(data.model_fields.keys())


def _get(data: ColumnData, key: str) -> str:
    """Get value from dict or Pydantic model.

    Args:
        data: Dictionary or Pydantic model instance
        key: Field/key name

    Returns:
        String representation of value
    """
    if isinstance(data, dict):
        return str(data[key]) if key in data and data[key] else ""
    else:  # BaseModel
        return str(getattr(data, key, ""))


def _get_min_characters(data: list[str]) -> int:
    return max(len(item) for item in data) + 1


def _is_empty_value(value: str) -> bool:
    """Check if a value is considered empty.

    Empty means: empty string, None, or whitespace-only.

    Args:
        value: String value to check

    Returns:
        True if value is empty
    """
    return value is None or value.strip() == ""


def _calculate_width_needed(columns: list[Column], padding: int) -> int:
    """Calculate total width needed for columns including padding and separators.

    Args:
        columns: List of Column objects
        padding: Padding on each side of column content

    Returns:
        Total width needed in characters
    """
    if not columns:
        return 0

    # Sum column widths + padding on both sides + vertical separators between columns
    total_width = sum(col.width for col in columns)
    padding_width = padding * 2 * len(columns)
    separator_width = len(columns) - 1  # One separator between each column

    return total_width + padding_width + separator_width


def _identify_overflowing_columns(columns: list[Column]) -> list[Column]:
    """Identify columns that are overflowing with visible truncation.

    A column is considered overflowing if:
    1. Its overflow behavior is visible (ellipses or fold), AND
    2. Its content exceeds the current column width

    Args:
        columns: List of Column objects to check

    Returns:
        List of columns that are overflowing and would benefit from extra width
    """
    overflowing = []
    for col in columns:
        # Check if overflow behavior is one that shows visible truncation
        has_visible_overflow = col.overflow in (
            OverflowEnum.ellipses,
            OverflowEnum.fold,
        )

        # Check if any content exceeds current column width
        max_content_length = (
            max(len(content) for content in col.contents) if col.contents else 0
        )
        content_overflows = max_content_length >= col.width

        if has_visible_overflow and content_overflows:
            overflowing.append(col)

    return overflowing


def _distribute_remaining_width(
    columns: list[Column], terminal_width: int, padding: int
) -> list[Column]:
    """Distribute unused terminal width equally among overflowing columns.

    After filtering columns to fit, there may be unused terminal width. This function
    distributes that extra width equally among columns that are showing ellipses or
    wrapping content. Column widths are capped at their maximum content length to
    prevent excessive whitespace.

    Args:
        columns: Filtered list of columns that fit within terminal width
        terminal_width: Total available terminal width
        padding: Padding on each side of column content

    Returns:
        List of columns with updated widths (modifies in place and returns)
    """
    if not columns:
        return columns

    # Calculate how much width is currently unused
    width_used = _calculate_width_needed(columns, padding)
    remaining_width = terminal_width - width_used

    # No extra width to distribute
    if remaining_width <= 0:
        return columns

    # Find columns that are overflowing
    overflowing_cols = _identify_overflowing_columns(columns)

    # No columns benefit from extra width
    if not overflowing_cols:
        return columns

    # Calculate max possible width for each overflowing column (based on content)
    max_widths = {}
    for col in overflowing_cols:
        # Maximum needed is the longest content in that column
        max_content_length = (
            max(len(content) for content in col.contents) if col.contents else col.width
        )
        # Also consider title width (already factored into initial width for dynamic columns)
        max_needed = max(max_content_length, len(col.title))
        max_widths[col.id] = max_needed

    # Distribute width iteratively (some columns may hit their max)
    width_to_distribute = remaining_width
    active_cols = overflowing_cols.copy()

    while width_to_distribute > 0 and active_cols:
        # Calculate equal distribution
        width_per_col = width_to_distribute // len(active_cols)

        # If we can't give at least 1 char to each, stop
        if width_per_col < 1:
            # Give remaining width to first active column
            if active_cols:
                first_col = active_cols[0]
                space_available = max_widths[first_col.id] - first_col.width
                width_to_add = min(width_to_distribute, space_available)
                first_col.width += width_to_add
            break

        # Distribute to each active column (up to their max)
        cols_to_remove = []
        total_distributed = 0

        for col in active_cols:
            space_available = max_widths[col.id] - col.width
            width_to_add = min(width_per_col, space_available)
            col.width += width_to_add
            total_distributed += width_to_add

            # If column reached its max, remove from active list
            if col.width >= max_widths[col.id]:
                cols_to_remove.append(col)

        # Remove columns that reached their max
        for col in cols_to_remove:
            active_cols.remove(col)

        # Update remaining width
        width_to_distribute -= total_distributed

        # Safety check: if we didn't distribute anything, break to avoid infinite loop
        if total_distributed == 0:
            break

    return columns


def _filter_columns_by_width(
    columns: list[Column],
    terminal_width: int,
    column_keep_order: Optional[list[str]],
    padding: int,
    strict_priority: bool = False,
) -> list[Column]:
    """Filter columns to fit within terminal width based on priority.

    Args:
        columns: All available columns
        terminal_width: Available terminal width
        column_keep_order: Priority order for keeping columns (highest priority first)
        padding: Column padding

    Returns:
        Filtered list of columns that fit within terminal width
    """
    if not columns:
        return []

    # Check if all columns fit
    if _calculate_width_needed(columns, padding) <= terminal_width:
        return columns

    # If no priority order specified, keep columns in original order
    if not column_keep_order:
        # Drop columns from the end until they fit
        result = columns.copy()
        while result and _calculate_width_needed(result, padding) > terminal_width:
            result.pop()
        return result

    # Create priority map (lower index = higher priority)
    priority_map = {col_name: idx for idx, col_name in enumerate(column_keep_order)}

    # Sort columns by priority (columns not in keep_order get lowest priority)
    # Use col.id to match against column_keep_order which contains IDs, not titles
    sorted_columns = sorted(
        columns, key=lambda col: priority_map.get(col.id, len(column_keep_order))
    )

    # Keep highest priority columns that fit
    result = []
    for col in sorted_columns:
        test_columns = result + [col]
        if _calculate_width_needed(test_columns, padding) <= terminal_width:
            result.append(col)
        elif strict_priority:
            # In strict priority mode, stop trying lower-priority columns
            # if a higher-priority column doesn't fit
            break

    # Check if terminal is too narrow for even the highest priority column
    if not result and sorted_columns:
        # Calculate width needed for highest priority column
        highest_priority_col = sorted_columns[0]
        min_width_needed = _calculate_width_needed([highest_priority_col], padding)

        if min_width_needed > terminal_width:
            console.print(
                f"[red]Error:[/red] Terminal too narrow to display table. "
                f"Minimum width needed: {min_width_needed} characters, "
                f"current width: {terminal_width} characters. "
                f"Please widen your terminal."
            )
            return result  # Return empty list

    # Restore original order for display (based on ID, not title)
    original_order = {col.id: idx for idx, col in enumerate(columns)}
    result.sort(key=lambda col: original_order.get(col.id, 0))

    return result


# filter columns based on terminal width and individual table/column preferences
def _column_factory(
    data: Sequence[ColumnData],
    table_config: TableViewConfigModel,
) -> list[Column]:
    """Create columns from data and filter based on terminal width.

    Args:
        data: List of data dictionaries
        configs: Column configurations
        table_config: Table configuration with padding and keep_order
        keys: Optional list of keys to use

    Returns:
        List of Column objects that fit within terminal width
    """
    if not data:
        return []

    # terminal width
    terminal_width = console.size.width

    # column configs
    if table_config.columns:
        column_configs = table_config.columns
    elif table_config.column_order:
        column_configs = [
            ColumnViewConfigModel(id=id) for id in table_config.column_order
        ]
    elif table_config.column_keep_order:
        column_configs = [
            ColumnViewConfigModel(id=id) for id in table_config.column_keep_order
        ]
    else:
        column_configs = [ColumnViewConfigModel(id=id) for id in _get_keys(data[0])]

    columns = []
    for config in column_configs:
        # extract contents
        contents = [str(_get(row, config.id)) for row in data]

        # Check if column should be dropped due to empty values
        if config.drop_if_empty and all(_is_empty_value(val) for val in contents):
            continue  # Skip this column

        # compute dynamic size if not fixed
        if config.dynamic:
            content_width = _get_min_characters(contents)
            # title is always populated by validator, but type checker doesn't know that
            assert config.title is not None
            title_width = len(config.title) + 1
            width = max(content_width, title_width)
        else:
            width = config.min_width or 10

        columns.append(Column(width=width, contents=contents, **config.model_dump()))

    # Filter columns to fit terminal width
    filtered_columns = _filter_columns_by_width(
        columns,
        terminal_width,
        table_config.column_keep_order,
        table_config.column_padding or 1,
        table_config.strict_priority or False,
    )

    # Distribute remaining width if enabled
    if table_config.distribute_width:
        filtered_columns = _distribute_remaining_width(
            filtered_columns,
            terminal_width,
            table_config.column_padding or 1,
        )

    return filtered_columns


def render_column_header(tbl: Table, column: Column) -> Table:
    """Add column header to Rich Table.

    Args:
        tbl: Rich Table object
        column: Column configuration

    Returns:
        Modified Rich Table
    """
    tbl.add_column(
        column.title,
        width=column.width,
        justify=column.align.value,
        no_wrap=not column.wrap,
    )
    return tbl


def render_row_data(tbl: Table, data: ColumnData, columns: list[Column]) -> Table:
    """Add a data row to Rich Table.

    Args:
        tbl: Rich Table object
        data: Row data (dict or Pydantic model)
        columns: List of columns to render

    Returns:
        Modified Rich Table
    """
    row_values = [_get(data, column.id) for column in columns]
    tbl.add_row(*row_values)
    return tbl


def render_table(
    data: Sequence[ColumnData],
    title: str,
    table_config: Optional[TableViewConfigModel] = None,
) -> None:
    """Render tabular data to the terminal.

    Args:
        data: List of dictionaries containing column data to display
        title: Title for the table
        table_config: Optional configuration for overall table display
    """
    if not data:
        return

    # Use provided configs or generate defaults
    table_config = table_config or _table_config_factory(data)

    # Create columns and filter based on terminal width
    columns = _column_factory(data, table_config)

    # Create Rich table
    tbl = Table(
        show_header=True, header_style="bold magenta", title=title, expand=False
    )

    # Add column headers
    for column in columns:
        tbl = render_column_header(tbl, column)

    # Add data rows
    for rowdata in data:
        tbl = render_row_data(tbl, rowdata, columns)

    # Print to console
    console.print(tbl)
