from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, model_validator


def _format_column_title(id_value: str) -> str:
    """Convert column id to smart title case.

    Examples:
        'user_id' -> 'User ID'
        'dataset_name' -> 'Dataset Name'
        'api_key' -> 'API Key'
        'url_path' -> 'URL Path'
    """
    # Common acronyms to keep uppercase
    acronyms = {"id", "api", "url", "uri", "http", "https", "sql", "csv", "json", "xml"}

    # Replace underscores and hyphens with spaces
    words = id_value.replace("_", " ").replace("-", " ").split()

    # Apply title case, preserving acronyms
    formatted_words = []
    for word in words:
        if word.lower() in acronyms:
            formatted_words.append(word.upper())
        else:
            formatted_words.append(word.capitalize())

    return " ".join(formatted_words)


class TableViewConfigModel(BaseModel):
    min_width: Optional[int] = Field(
        default=30, description="minimum width of the table"
    )
    columns: Optional[list["ColumnViewConfigModel"]] = Field(
        description="Column Confgurations", default_factory=lambda: []
    )
    column_order: Optional[list[str]] = Field(
        default=None, description="column render order"
    )
    column_keep_order: Optional[list[str]] = Field(
        default=None,
        description="ranking of columns to draw when insufficient width is available",
    )
    column_padding: Optional[int] = Field(
        default=1,
        description="padding to apply to column contents relative to vertical seperator",
    )
    strict_priority: Optional[bool] = Field(
        default=False,
        description="If True, stop adding columns when a higher-priority column doesn't fit. "
        "If False (default), skip columns that don't fit and continue trying lower-priority ones.",
    )
    distribute_width: Optional[bool] = Field(
        default=True,
        description="Distribute unused terminal width among overflowing columns",
    )


class OverflowEnum(Enum):
    ignore = "ignore"
    ellipses = "ellipses"
    fold = "fold"
    drop = "drop"  # remove if you can't fit it


class AlignEnum(Enum):
    left = "left"
    right = "right"
    center = "center"


class ColumnViewConfigModel(BaseModel):
    id: str = Field(description="The column id (data key)")
    title: Optional[str] = Field(
        default=None,
        description="Display name for column header (auto-generated from id if not provided)",
    )
    wrap: Optional[bool] = Field(
        default=False,
        description="wrap contents across multiple lines when width constrained",
    )
    min_width: Optional[int] = Field(default=10, description="minimum width of column")
    overflow: Optional[OverflowEnum] = Field(
        default=OverflowEnum.ellipses,
        description="overflow behavior when content exceeds available width",
    )
    dynamic: Optional[bool] = Field(
        default=False, description="compute width required to fully view contents"
    )
    align: Optional[AlignEnum] = Field(
        default=AlignEnum.left, description="text alignment of column within "
    )
    drop_if_empty: Optional[bool] = Field(
        default=False,
        description="Drop this column from display if all values are empty (empty string, None, or whitespace)",
    )

    @model_validator(mode="after")
    def auto_populate_title(self) -> "ColumnViewConfigModel":
        """Auto-populate title from id if not provided."""
        if self.title is None:
            self.title = _format_column_title(self.id)
        return self


class Column(ColumnViewConfigModel):
    title: str = Field(description="Column title (always set by validator)")
    contents: list[str]
    width: int
