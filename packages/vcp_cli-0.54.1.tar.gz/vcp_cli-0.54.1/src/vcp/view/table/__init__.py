"""Table view module for displaying tabular data in the terminal."""

from vcp.view.table.table import render_table

__all__ = ["render_table"]
