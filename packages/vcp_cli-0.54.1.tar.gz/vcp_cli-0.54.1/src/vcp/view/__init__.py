"""View module for managing console/terminal output display."""
