"""Type definitions for path normalization."""

from pathlib import Path
from typing import NewType

# User-supplied path (from CLI, config, metadata) - may be relative, absolute, or contain ~
UserPath = NewType("UserPath", str)

# Normalized absolute path - used internally throughout the codebase
NormalizedPath = NewType("NormalizedPath", Path)

# Work directory - always absolute, determined at entry point
WorkDir = NewType("WorkDir", Path)
