"""Path normalization and resolution utilities with security validation."""

from pathlib import Path

import click

from .path_types import NormalizedPath, UserPath, WorkDir


def _resolve_path(path: Path, context: str = "path") -> Path:
    """Resolve path with clear error handling."""
    try:
        return path.resolve()
    except OSError as e:
        raise OSError(f"Failed to resolve {context} '{path}': {e}") from e


def _validate_path_within_directory(
    path: Path, allowed_dir: Path, context: str = ""
) -> None:
    """Validate path stays within allowed directory (security check)."""
    try:
        path.relative_to(allowed_dir)
    except ValueError:
        context_msg = f" {context}" if context else ""
        raise ValueError(
            f"Security violation: Path '{path}'{context_msg} escapes restricted "
            f"directory '{allowed_dir}'. This may indicate a malicious path."
        ) from None


def get_work_dir(work_dir: Path | None, prompt_if_missing: bool = False) -> WorkDir:
    """Get work directory, checking current dir for .model-metadata if not provided."""
    if work_dir is not None:
        # Click already resolved this (resolve_path=True)
        return WorkDir(work_dir)

    current_dir = _resolve_path(Path.cwd(), "current directory")

    if (current_dir / ".model-metadata").exists():
        return WorkDir(current_dir)

    if prompt_if_missing:
        work_dir_input = click.prompt(
            "Enter work directory",
            type=click.Path(
                exists=True,
                file_okay=False,
                dir_okay=True,
                resolve_path=True,
                path_type=Path,
            ),
        )
        # Click already resolved this (resolve_path=True)
        return WorkDir(work_dir_input)

    return WorkDir(current_dir)


def resolve_metadata_path(path_str: UserPath, work_dir: WorkDir) -> NormalizedPath:
    """Resolve metadata path relative to work_dir with security validation.

    Raises ValueError if path is empty or escapes work_dir.
    """
    if not path_str or not path_str.strip():
        raise ValueError("Path cannot be empty or whitespace-only")

    path = Path(path_str).expanduser()
    if path.is_absolute():
        resolved = _resolve_path(path, f"path '{path_str}'")
    else:
        resolved = _resolve_path(work_dir / path, f"path '{path_str}'")

    _validate_path_within_directory(resolved, work_dir, "work directory")
    return NormalizedPath(resolved)


def restrict_path_to_directory(
    path: Path, allowed_dir: WorkDir, context: str = ""
) -> NormalizedPath:
    """Validate CLI path stays within allowed_dir (prevents path traversal).

    Raises ValueError if path escapes allowed_dir.
    Note: path is already resolved by Click (resolve_path=True).
    """
    # Click already resolved this (resolve_path=True), trust it
    _validate_path_within_directory(path, allowed_dir, context)
    return NormalizedPath(path)
