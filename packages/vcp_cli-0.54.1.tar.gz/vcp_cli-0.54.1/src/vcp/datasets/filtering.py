"""Location filtering utilities for dataset downloads."""

from dataclasses import dataclass
from typing import List, Optional, Union
from urllib.parse import urlparse

from ..utils.size import parse_content_size
from .api import CroissantFileObject, CroissantLiteModel, DatasetRecord


@dataclass
class LocationInfo:
    """
    Parsed location information extracted from Croissant distribution files.
    """

    url: str
    scheme: str
    path: str
    extension: Optional[str]
    size: Optional[int]


def extract_location_from_croissant_file(
    asset: Union[CroissantFileObject, dict],
) -> LocationInfo:
    """
    Extract location information from a CroissantFileObject or dict.

    Args:
        asset: A CroissantFileObject or dict with croissant file metadata

    Returns:
        LocationInfo with parsed url, scheme, path, extension, and size
    """
    # Handle both CroissantFileObject and dict types
    if isinstance(asset, dict):
        content_url = str(asset.get("contentUrl", ""))
        content_size_str = asset.get("contentSize")
    else:
        content_url = str(asset.content_url)
        content_size_str = asset.content_size

    # Parse URL components
    parsed = urlparse(content_url)
    scheme = parsed.scheme
    path = parsed.path

    # Extract extension from path
    # Extension is None if there's no .ext after the last '/'
    path_parts = path.split("/")
    if path_parts:
        filename = path_parts[-1]
        if "." in filename:
            extension = "." + filename.split(".")[-1]
        else:
            extension = None
    else:
        extension = None

    # Parse size from string format (e.g., "1.5 GB" -> bytes)
    size = None
    if content_size_str:
        try:
            size = parse_content_size(content_size_str)
        except (ValueError, TypeError):
            pass

    return LocationInfo(
        url=content_url,
        scheme=scheme,
        path=path,
        extension=extension,
        size=size,
    )


def extract_locations_from_croissant(
    croissant: CroissantLiteModel,
) -> List[LocationInfo]:
    """
    Extract location information from a CroissantLiteModel's distribution field.

    Args:
        croissant: CroissantLiteModel with distribution list

    Returns:
        List of LocationInfo objects, one per file in the distribution
    """
    locations = []
    for asset in croissant.distribution:
        location_info = extract_location_from_croissant_file(asset)
        locations.append(location_info)
    return locations


def extract_locations_from_dataset_record(record: DatasetRecord) -> List[LocationInfo]:
    """
    Extract location information from a DatasetRecord's Croissant metadata.

    Args:
        record: DatasetRecord with md (Croissant metadata)

    Returns:
        List of LocationInfo objects from the record's distribution, or empty list if no metadata
    """
    if record.md and record.md.distribution:
        return extract_locations_from_croissant(record.md)
    return []


def location_info_from_url(url: str) -> LocationInfo:
    """
    Create a LocationInfo object from a plain URL string.

    This is a best-effort conversion that extracts scheme, path, and extension
    from the URL. Size information is not available and will be None.

    Args:
        url: A URL string (e.g., "s3://bucket/file.h5ad", "https://example.com/data.csv")

    Returns:
        LocationInfo with parsed metadata (size will be None)
    """
    # Handle bare S3 paths without scheme
    if not url.startswith(("http://", "https://", "s3://", "gs://")):
        # Assume S3 for bare paths
        url = f"s3://{url}" if not url.startswith("/") else url

    # Parse URL components
    parsed = urlparse(url)
    scheme = parsed.scheme if parsed.scheme else "s3"
    path = parsed.path

    # Extract extension from path
    # Extension is None if there's no .ext after the last '/'
    path_parts = path.split("/")
    if path_parts:
        filename = path_parts[-1]
        if "." in filename:
            extension = "." + filename.split(".")[-1]
        else:
            extension = None
    else:
        extension = None

    # Reconstruct full URL if scheme was added
    full_url = f"{scheme}://{parsed.netloc}{path}" if parsed.netloc else url

    return LocationInfo(
        url=full_url,
        scheme=scheme,
        path=path,
        extension=extension,
        size=None,  # Not available from URL alone
    )


def filter_locations(
    locations: List[LocationInfo],
    include_ext: Optional[List[str]] = None,
    exclude_ext: Optional[List[str]] = None,
) -> List[LocationInfo]:
    """
    Filter LocationInfo objects by file extension.

    Args:
        locations: List of LocationInfo objects to filter
        include_ext: Extensions to include (e.g., ['h5ad', 'csv']). If specified, only these extensions are kept.
        exclude_ext: Extensions to exclude (e.g., ['txt', 'log']). Applied after include filter.

    Returns:
        Filtered list of LocationInfo objects

    Notes:
        - Extension matching is case-insensitive
        - Extensions can be specified with or without leading dot ('h5ad' or '.h5ad')
        - Files without extensions (extension=None) are excluded when include_ext is specified
        - If both include_ext and exclude_ext are None, returns all locations
    """
    filtered = locations

    # Apply include filter
    if include_ext:
        # Normalize: add dot, lowercase
        normalized_include = {
            (ext if ext.startswith(".") else f".{ext}").lower() for ext in include_ext
        }
        filtered = [
            loc
            for loc in filtered
            if loc.extension and loc.extension.lower() in normalized_include
        ]

    # Apply exclude filter
    if exclude_ext:
        normalized_exclude = {
            (ext if ext.startswith(".") else f".{ext}").lower() for ext in exclude_ext
        }
        filtered = [
            loc
            for loc in filtered
            if not loc.extension or loc.extension.lower() not in normalized_exclude
        ]

    return filtered
