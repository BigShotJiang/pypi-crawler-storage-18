"""
Registry Stack Python SDK

A production-quality Python SDK for the Registry Stack, providing seamless
integration with Operator Registry, Pipeline Registry, Executor, and Recorder services.
"""

__version__ = "1.0.6"
__author__ = "Registry Stack Team"
__email__ = "team@sw-registry-stack.com"

# Core service classes
from .modules.operator_registry import OperatorRegistry
from .modules.pipeline_registry import PipelineRegistry
from .modules.executor import Executor
from .modules.recorder import Recorder

# Exception classes
from .exceptions import (
    SdkError,
    ValidationError,
    FfiBridgeError,
    ConfigurationError,
    CliExecutionError,
)

# Common types and utilities
from .shared.dto import (
    BaseConfig,
    CliResponse,
    ErrorDetails,
    PaginationOptions,
    OperationOptions,
    Platform,
    VersionInfo,
)

# Re-export Operator Registry option DTOs used by consumers
from .modules.operator_registry.dto.options import (
    OperatorListOptions,
    OperatorInstallOptions,
    OperatorUninstallOptions,
    OperatorInfoOptions,
)

# Re-export Pipeline Registry option DTOs
from .modules.pipeline_registry.dto.options import (
    PipelineListOptions,
    PipelinePullOptions,
    PipelineRemoveOptions,
    PipelineInfoOptions,
)

# Recorder option DTOs are not available in this build

# Re-export Executor option DTOs (best-effort)
try:
    from .modules.executor.dto.options import (  # type: ignore
        ExecutorCreateOptions,
        ExecutorStartOptions,
        ExecutorStopOptions,
        ExecutorInfoOptions,
        ExecutorListOptions,
    )
except Exception:
    # Optional: executor DTOs may not exist in all builds
    ExecutorCreateOptions = None  # type: ignore
    ExecutorStartOptions = None  # type: ignore
    ExecutorStopOptions = None  # type: ignore
    ExecutorInfoOptions = None  # type: ignore
    ExecutorListOptions = None  # type: ignore

# Version information
__all__ = [
    # Core services
    "OperatorRegistry",
    "PipelineRegistry", 
    "Executor",
    "Recorder",
    # Exceptions
    "SdkError",
    "ValidationError",
    "FfiBridgeError",
    "ConfigurationError",
    "CliExecutionError",
    # Types
    "BaseConfig",
    "CliResponse",
    "ErrorDetails",
    "PaginationOptions",
    "OperationOptions",
    "Platform",
    "VersionInfo",
    # Operator options
    "OperatorListOptions",
    "OperatorInstallOptions",
    "OperatorUninstallOptions",
    "OperatorInfoOptions",
    # Pipeline options
    "PipelineListOptions",
    "PipelineInstallOptions",
    "PipelinePullOptions",
    "PipelineRemoveOptions",
    "PipelineInfoOptions",
    # Recorder options (not available in this build)
    # Executor options (if available)
    "ExecutorCreateOptions",
    "ExecutorStartOptions",
    "ExecutorStopOptions",
    "ExecutorInfoOptions",
    "ExecutorListOptions",
    # Metadata
    "__version__",
    "__author__",
    "__email__",
]
