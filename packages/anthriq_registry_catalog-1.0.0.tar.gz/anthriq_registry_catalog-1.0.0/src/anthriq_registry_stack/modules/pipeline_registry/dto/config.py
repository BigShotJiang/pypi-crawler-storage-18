"""
Configuration DTOs for Pipeline Registry operations.

This module defines the configuration classes used for Pipeline Registry operations.
"""

from typing import Optional
import os
from pydantic import BaseModel, Field
from shared.dto.common import BaseConfig
from utils.platform import resolve_library_paths, resolve_library_path, get_library_extension

# Get platform-specific paths
platform_paths = resolve_library_paths()


class PipelineRegistryConfig(BaseConfig):
    """Configuration for Pipeline Registry operations."""
    
    base_path: str = Field(
        default=os.getenv("REGISTRY_PIPELINES_PATH", platform_paths['base_path'].replace('operators', 'pipelines')),
        description="Base path for pipeline operations"
    )
    # Build a robust default for the bridge lib that avoids double extensions on Windows
    def _default_bridge_path() -> str:
        ext = get_library_extension()
        default_bridge = platform_paths['bridge_lib_path']
        needle = f"libexecutor_bridge{ext}"
        if default_bridge.endswith(needle):
            return default_bridge[: -len(needle)] + f"libpipeline_registry_bridge{ext}"
        return default_bridge.replace('libexecutor_bridge', 'libpipeline_registry_bridge')

    bridge_lib_path: str = Field(
        default=os.getenv("BRIDGE_LIB_PATH", _default_bridge_path()),
        description="Path to the pipeline registry bridge library"
    )
    debug: bool = Field(
        default=False,
        description="Enable debug mode"
    )
    timeout: int = Field(
        default=5000,
        description="Timeout for operations in milliseconds"
    )
    registry_url: Optional[str] = Field(
        default=None,
        description="Remote registry URL"
    )
    registry_token: Optional[str] = Field(
        default=None,
        description="Registry authentication token"
    )
    max_concurrent_operations: int = Field(
        default=10,
        description="Maximum number of concurrent operations"
    )
    cache_size: int = Field(
        default=1000,
        description="Cache size for operations"
    )
    cache_ttl: int = Field(
        default=3600,
        description="Cache TTL in seconds"
    )
