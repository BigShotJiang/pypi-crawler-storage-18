"""
Signal service implementation for Executor.

This module provides the signal service for sending signals to pipeline instances.
"""

import asyncio
import json
import logging
from typing import Optional, Dict, Any
from pathlib import Path
import sys

# Add the src directory to the path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from modules.executor.dto import ExecutorSignalOptions, PipelineSignalResponse, PipelineSignalData
from modules.executor.bridge import ExecutorBridge
from shared.dto.common import ResponseStatus

logger = logging.getLogger(__name__)


class SignalService:
    """Service for sending signals to pipeline instances."""
    
    def __init__(self, bridge_lib_path: str):
        """Initialize the signal service.
        
        Args:
            bridge_lib_path: Path to the executor bridge library
        """
        self.bridge = ExecutorBridge(bridge_lib_path)
        self._is_initialized = False
    
    async def initialize(self) -> None:
        """Initialize the signal service."""
        if not self._is_initialized:
            self.bridge.load()
            self._is_initialized = True
    
    async def signal_pipeline(
        self,
        base_path: str,
        run_id: str,
        signal: str,
        options: ExecutorSignalOptions
    ) -> PipelineSignalResponse:
        """Send a signal to a pipeline instance.
        
        Args:
            base_path: Base path for the executor
            run_id: Pipeline run ID
            signal: Signal to send
            options: Signal options
            
        Returns:
            PipelineSignalResponse: Signal response
        """
        # Validate that reserved signals are not sent through signal command (failsafe)
        reserved_signals = ['START', 'STOP', 'DESTROY', 'SHUTDOWN']
        signal_upper = signal.upper() if signal else ''
        if signal_upper in reserved_signals:
            logger.warning("SignalService.signal_pipeline: reserved signal detected", {
                "signal": signal,
                "signal_upper": signal_upper,
                "run_id": run_id
            })
            
            return PipelineSignalResponse(
                status=ResponseStatus.ERROR,
                message=f"Signal '{signal}' is reserved and cannot be sent through the signal command. Use the dedicated {signal_upper.lower()} command instead.",
                data=None,
                error={"message": f"Reserved signal: {signal}", "type": "validation_error"}
            )
        
        try:
            logger.debug("SignalService.signal_pipeline: starting operation", {
                "base_path": base_path,
                "run_id": run_id,
                "signal": signal,
                "options": options.model_dump() if options else None
            })
            
            # Extract nodes and args from options
            nodes_str = None
            if options and options.node_ids:
                # Convert list to comma-separated string
                nodes_str = ','.join(options.node_ids)
            
            signal_args = None
            if options and options.signal_args:
                signal_args = options.signal_args
            
            # Call the bridge to send the signal
            json_response = await self.bridge.signal(
                base_path=base_path,
                run_id=run_id,
                signal=signal,
                nodes=nodes_str,
                args=signal_args
            )
            
            logger.debug("SignalService.signal_pipeline: bridge response received", {
                "result": json_response
            })
            
            # Parse the response
            response_data = json_response
            
            if response_data.get("status") == "success":
                pipeline_data = response_data.get("data", {})
                
                # Create response data
                signal_data = PipelineSignalData(
                    run_id=pipeline_data.get('run_id', run_id),
                    signal=pipeline_data.get('signal', signal),
                    node_ids=pipeline_data.get('node_ids') if pipeline_data.get('node_ids') else None,
                    signal_args=pipeline_data.get('signal_args') if pipeline_data.get('signal_args') else None,
                    zmq_status=pipeline_data.get('zmq_status', 'UNKNOWN')
                )
                
                return PipelineSignalResponse(
                    status=ResponseStatus.SUCCESS,
                    message=response_data.get("message", "Signal sent successfully"),
                    data=signal_data
                )
            else:
                error_data = response_data.get("error", {})
                return PipelineSignalResponse(
                    status=ResponseStatus.ERROR,
                    message=response_data.get("message", "Failed to send signal"),
                    data=None,
                    error=error_data
                )
        except Exception as e:
            logger.error(f"SignalService.signal_pipeline: error", {
                "base_path": base_path,
                "run_id": run_id,
                "signal": signal,
                "options": options.model_dump() if options else None,
                "error": str(e)
            })
            return PipelineSignalResponse(
                status=ResponseStatus.ERROR,
                message="Failed to send signal to pipeline",
                data=None,
                error={"message": str(e), "type": "execution_error"}
            )
    
    async def close(self) -> None:
        """Close the signal service."""
        if self._is_initialized:
            self.bridge.unload()
            self._is_initialized = False
