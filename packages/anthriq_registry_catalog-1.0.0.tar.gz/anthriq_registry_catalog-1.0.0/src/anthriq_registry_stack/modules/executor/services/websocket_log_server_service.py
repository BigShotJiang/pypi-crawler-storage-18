"""
WebSocket log server service for receiving logs from C++ pipelines.

This module provides a WebSocket/HTTP server that receives logs from C++ pipelines
and forwards them to registered callbacks.
"""

import json
import logging
from typing import Optional, Callable, Dict, Any
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread

logger = logging.getLogger(__name__)


class LogServerCallbacks:
    """Callbacks for log events."""
    
    def __init__(
        self,
        on_log: Optional[Callable[[str, str, str, str], None]] = None,
        on_unified_log: Optional[Callable[[Dict[str, Any]], None]] = None
    ):
        """
        Initialize callbacks.
        
        Args:
            on_log: Callback for legacy log format (nodeId, level, message, jsonData)
            on_unified_log: Callback for unified log format (full log entry dict)
        """
        self.on_log = on_log
        self.on_unified_log = on_unified_log


class LogServerOptions:
    """Options for configuring the log server."""
    
    def __init__(
        self,
        port: int = 8765,
        host: str = 'localhost',
        callbacks: Optional[LogServerCallbacks] = None
    ):
        """
        Initialize log server options.
        
        Args:
            port: Port to listen on
            host: Host to bind to
            callbacks: Callbacks for log events
        """
        self.port = port
        self.host = host
        self.callbacks = callbacks or LogServerCallbacks()


def create_log_handler(log_server):
    """Create an HTTP request handler for receiving logs via POST."""
    
    class LogHTTPHandler(BaseHTTPRequestHandler):
        """HTTP request handler for receiving logs via POST."""
        
        def do_POST(self):
            """Handle POST requests to /logs endpoint."""
            if self.path == '/logs':
                content_length = int(self.headers.get('Content-Length', 0))
                body = self.rfile.read(content_length).decode('utf-8')
                
                try:
                    log_entry = json.loads(body)
                    log_server.process_log_entry(log_entry)
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'ok'}).encode('utf-8'))
                except Exception as err:
                    logger.error(f'[WebSocketLogServer] Error parsing HTTP POST log: {err}')
                    self.send_response(400)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({'status': 'error', 'message': 'Invalid JSON'}).encode('utf-8'))
            else:
                self.send_response(404)
                self.end_headers()
        
        def log_message(self, format, *args):
            """Suppress default HTTP server logging."""
            pass
    
    return LogHTTPHandler


class WebSocketLogServer:
    """
    WebSocket/HTTP server for receiving logs from C++ pipelines.
    
    This server listens for both HTTP POST requests and WebSocket connections,
    receiving log entries from C++ pipelines and forwarding them to registered callbacks.
    """
    
    def __init__(self, options: Optional[LogServerOptions] = None):
        """
        Initialize the WebSocket log server.
        
        Args:
            options: Server configuration options
        """
        options = options or LogServerOptions()
        self.port = options.port
        self.host = options.host
        self.callbacks = options.callbacks or LogServerCallbacks()
        
        self.http_server: Optional[HTTPServer] = None
        self.is_running = False
        self._http_thread: Optional[Thread] = None
    
    def start(self) -> None:
        """Start the HTTP server."""
        if self.is_running:
            logger.warn('[WebSocketLogServer] Server already running')
            return
        
        # Start HTTP server in a separate thread
        handler_class = create_log_handler(self)
        self.http_server = HTTPServer((self.host, self.port), handler_class)
        
        def run_http_server():
            try:
                self.http_server.serve_forever()
            except Exception as e:
                logger.error(f'[WebSocketLogServer] HTTP server error: {e}')
        
        self._http_thread = Thread(target=run_http_server, daemon=True)
        self._http_thread.start()
        
        self.is_running = True
        addr = f'{self.host}:{self.port}'
        print(f'[WebSocketLogServer] Server started on {addr} (HTTP)')
        logger.info(f'[WebSocketLogServer] Server started on {addr} (HTTP)')
    
    def stop(self) -> None:
        """Stop the HTTP server."""
        if not self.is_running:
            return
        
        # Stop HTTP server
        if self.http_server:
            self.http_server.shutdown()
        
        if self._http_thread:
            self._http_thread.join(timeout=5)
        
        self.is_running = False
        self.http_server = None
        print('[WebSocketLogServer] Server stopped')
        logger.info('[WebSocketLogServer] Server stopped')
    
    def process_log_entry(self, log_entry: Dict[str, Any]) -> None:
        """
        Process a log entry and call registered callbacks.
        
        Args:
            log_entry: Log entry dictionary
        """
        # Call callbacks
        node_id = log_entry.get('node_id', '')
        level = str(log_entry.get('level', 'info'))
        log_message = log_entry.get('message', '')
        json_data = json.dumps(log_entry.get('data', {}))
        
        if self.callbacks.on_log:
            try:
                self.callbacks.on_log(node_id, level, log_message, json_data)
            except Exception as err:
                logger.error(f'[WebSocketLogServer] Error in on_log callback: {err}')
        
        if self.callbacks.on_unified_log:
            try:
                self.callbacks.on_unified_log(log_entry)
            except Exception as err:
                logger.error(f'[WebSocketLogServer] Error in on_unified_log callback: {err}')
    
    def get_web_socket_url(self) -> str:
        """Get the WebSocket URL for this server."""
        return f'ws://{self.host}:{self.port}'
    
    def get_address(self) -> str:
        """Get the server address (host:port)."""
        return f'{self.host}:{self.port}'
    
    def is_server_running(self) -> bool:
        """Check if the server is running."""
        return self.is_running
    
    def set_callbacks(self, callbacks: LogServerCallbacks) -> None:
        """Update the callbacks."""
        self.callbacks = callbacks


# Singleton instance
_log_server_instance: Optional[WebSocketLogServer] = None


def get_log_server(options: Optional[LogServerOptions] = None) -> WebSocketLogServer:
    """
    Get or create the singleton WebSocket log server.
    
    Args:
        options: Server configuration options (only used on first call)
    
    Returns:
        The singleton WebSocketLogServer instance
    """
    global _log_server_instance
    if _log_server_instance is None:
        _log_server_instance = WebSocketLogServer(options)
    return _log_server_instance


def start_log_server(options: Optional[LogServerOptions] = None) -> WebSocketLogServer:
    """
    Start the global log server.
    
    Args:
        options: Server configuration options
    
    Returns:
        The WebSocketLogServer instance
    """
    server = get_log_server(options)
    if not server.is_server_running():
        server.start()
    return server


def stop_log_server() -> None:
    """Stop the global log server."""
    global _log_server_instance
    if _log_server_instance:
        _log_server_instance.stop()
        _log_server_instance = None

