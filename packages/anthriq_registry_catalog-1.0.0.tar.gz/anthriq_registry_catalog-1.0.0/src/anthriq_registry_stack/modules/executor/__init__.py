"""
Executor module.

This module provides the main Executor class and all related types
for managing pipeline execution in the Registry Stack.
"""

from .executor import Executor
from .dto import (
    ExecutorConfig,
    ExecutorCreateOptions,
    ExecutorListOptions,
    ExecutorHistoryOptions,
    ExecutorInfoOptions,
    ExecutorStartOptions,
    ExecutorStopOptions,
    ExecutorDestroyOptions,
    ExecutorSignalOptions,
    # ExecutorVersionOptions,
    PipelineCreateResponse,
    PipelineCreateData,
    PipelineListResponse,
    PipelineListData,
    PipelineHistoryResponse,
    PipelineHistoryData,
    PipelineInfoResponse,
    PipelineStateTransitionResponse,
    PipelineStateTransitionData,
    PipelineSignalResponse
    # ExecutorVersionResponse,
    # ExecutorVersionData
)
from .services import (
    start_log_server,
    stop_log_server,
    get_log_server,
    WebSocketLogServer,
    LogServerCallbacks,
    LogServerOptions
)

__all__ = [
    'Executor',
    'ExecutorConfig',
    'ExecutorCreateOptions',
    'ExecutorListOptions',
    'ExecutorHistoryOptions',
    'ExecutorInfoOptions',
    'ExecutorStartOptions',
    'ExecutorStopOptions',
    'ExecutorDestroyOptions',
    'ExecutorSignalOptions',
    # 'ExecutorVersionOptions',
    'PipelineCreateResponse',
    'PipelineCreateData',
    'PipelineListResponse',
    'PipelineListData',
    'PipelineHistoryResponse',
    'PipelineHistoryData',
    'PipelineInfoResponse',
    'PipelineStateTransitionResponse',
    'PipelineStateTransitionData',
    'PipelineSignalResponse',
    'start_log_server',
    'stop_log_server',
    'get_log_server',
    'WebSocketLogServer',
    'LogServerCallbacks',
    'LogServerOptions'
    # 'ExecutorVersionResponse',
    # 'ExecutorVersionData'
]