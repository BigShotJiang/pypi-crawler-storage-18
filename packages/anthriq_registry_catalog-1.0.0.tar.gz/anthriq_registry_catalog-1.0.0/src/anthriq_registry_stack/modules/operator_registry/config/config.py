"""
Operator Registry configuration implementation.

This module provides the configuration class for the Operator Registry service,
following the same structure as the Node.js SDK.
"""

import os
from typing import Optional
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from shared.dto.common import BaseConfig
from utils.platform import resolve_library_paths, resolve_library_path, get_library_extension

# Get platform-specific paths
platform_paths = resolve_library_paths()


class OperatorRegistryConfiguration(BaseConfig):
    """Configuration class for Operator Registry."""
    
    def __init__(
        self,
        base_path: Optional[str] = None,
        bridge_lib_path: Optional[str] = None,
        timeout: Optional[int] = None,
        debug: Optional[bool] = None,
    ) -> None:
        """
        Initialize operator registry configuration.
        
        Args:
            base_path: Base path for local operations
            bridge_lib_path: Path to the native bridge library
            timeout: Request timeout in milliseconds
            debug: Enable debug mode
        """
        # Resolve library path if not provided
        if not bridge_lib_path:
            bridge_lib_path = resolve_library_path('operator_registry_bridge')
            if not bridge_lib_path:
                # Fallback to platform-specific default, avoid double extension
                lib_ext = get_library_extension()
                default_bridge = platform_paths['bridge_lib_path']
                needle = f'libexecutor_bridge{lib_ext}'
                if default_bridge.endswith(needle):
                    bridge_lib_path = default_bridge[: -len(needle)] + f'liboperator_registry_bridge{lib_ext}'
                else:
                    bridge_lib_path = default_bridge.replace('libexecutor_bridge', f'liboperator_registry_bridge')
        
        # Set defaults from environment variables or platform-specific defaults
        super().__init__(
            base_path=base_path or os.getenv("REGISTRY_BASE_PATH", platform_paths['base_path']),
            bridge_lib_path=bridge_lib_path or os.getenv(
                "BRIDGE_LIB_PATH",
                (lambda: (
                    (platform_paths['bridge_lib_path'][: -len(f'libexecutor_bridge{get_library_extension()}')] + f'liboperator_registry_bridge{get_library_extension()}')
                    if platform_paths['bridge_lib_path'].endswith(f'libexecutor_bridge{get_library_extension()}')
                    else platform_paths['bridge_lib_path'].replace('libexecutor_bridge', 'liboperator_registry_bridge')
                ))()
            ),
            timeout=timeout or int(os.getenv("REGISTRY_TIMEOUT", "30000")),
            debug=debug if debug is not None else os.getenv("REGISTRY_DEBUG", "false").lower() == "true",
        )
