"""
List operators service implementation.

This module provides the service function for listing operators,
following the same structure as the Node.js SDK.
"""

import json
import logging
from typing import Optional
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from ..bridge.operator_registry_bridge import OperatorRegistryBridge
from ..dto.options import OperatorListOptions
from ..dto.responses import (
    LocalOperatorListResponse,
    RemoteOperatorListResponse, 
    RemoteOperatorVersionsResponse,
    OperatorListResponse,
    LocalOperatorListData,
    RemoteOperatorListData,
    RemoteOperatorVersionsData
)
from shared.dto.common import ResponseStatus, ErrorDetails

logger = logging.getLogger(__name__)


async def list_operators(
    base_path: str,
    bridge: OperatorRegistryBridge,
    options: Optional[OperatorListOptions] = None,
    logger_instance = None
) -> OperatorListResponse:
    """
    List operators service function.
    
    Args:
        base_path: Base path for operations
        bridge: Operator registry bridge instance
        options: List options
        
    Returns:
        Operator list response
    """
    if options is None:
        options = OperatorListOptions()
    
    try:
        if logger_instance:
            logger_instance.debug(f"Listing operators with options: {options.dict()}")
        
        # Use the bridge to get the JSON response
        if options.remote or options.operator or options.versions or options.page or options.page_size:
            # Use the full options function
            json_response = bridge.list_operators_with_options(base_path, options)
        else:
            # Use the simple list function
            json_response = bridge.list_operators(base_path)
        
        # Parse the JSON response
        response_data = json.loads(json_response)
        
        # Convert to our response type
        if response_data.get("status") == "success":
            # Handle different response formats
            data_dict = response_data["data"]
            
            # Determine response type based on options
            if options.remote and options.versions:
                # Remote operator versions
                data = RemoteOperatorVersionsData(**data_dict)
                return RemoteOperatorVersionsResponse(
                    status=ResponseStatus.SUCCESS,
                    message=response_data.get("message", "Operator versions listed successfully"),
                    data=data
                )
            elif options.remote:
                # Remote operator list
                data = RemoteOperatorListData(**data_dict)
                return RemoteOperatorListResponse(
                    status=ResponseStatus.SUCCESS,
                    message=response_data.get("message", "Remote operators listed successfully"),
                    data=data
                )
            else:
                # Local operator list
                data = LocalOperatorListData(**data_dict)
                return LocalOperatorListResponse(
                    status=ResponseStatus.SUCCESS,
                    message=response_data.get("message", "Local operators listed successfully"),
                    data=data
                )
        else:
            # Return appropriate error response based on options
            if options.remote and options.versions:
                data = RemoteOperatorVersionsData(count=0, versions=[])
                return RemoteOperatorVersionsResponse(
                    status=ResponseStatus.ERROR,
                    message=response_data.get("message", "Failed to list operator versions"),
                    data=data,
                    error=ErrorDetails(
                        message=response_data.get("message", "Unknown error"),
                        type="bridge_error"
                    )
                )
            elif options.remote:
                data = RemoteOperatorListData(count=0, operators=[])
                return RemoteOperatorListResponse(
                    status=ResponseStatus.ERROR,
                    message=response_data.get("message", "Failed to list remote operators"),
                    data=data,
                    error=ErrorDetails(
                        message=response_data.get("message", "Unknown error"),
                        type="bridge_error"
                    )
                )
            else:
                data = LocalOperatorListData(count=0, operators=[])
                return LocalOperatorListResponse(
                    status=ResponseStatus.ERROR,
                    message=response_data.get("message", "Failed to list local operators"),
                    data=data,
                    error=ErrorDetails(
                        message=response_data.get("message", "Unknown error"),
                        type="bridge_error"
                    )
                )
            
    except json.JSONDecodeError as e:
        if logger_instance:
            logger_instance.error(f"Failed to parse JSON response: {e}")
        
        # Return appropriate error response based on options
        if options.remote and options.versions:
            data = RemoteOperatorVersionsData(count=0, versions=[])
            return RemoteOperatorVersionsResponse(
                status=ResponseStatus.ERROR,
                message="Failed to parse response from operator registry",
                data=data,
                error=ErrorDetails(
                    message=str(e),
                    type="json_parse_error"
                )
            )
        elif options.remote:
            data = RemoteOperatorListData(count=0, operators=[])
            return RemoteOperatorListResponse(
                status=ResponseStatus.ERROR,
                message="Failed to parse response from operator registry",
                data=data,
                error=ErrorDetails(
                    message=str(e),
                    type="json_parse_error"
                )
            )
        else:
            data = LocalOperatorListData(count=0, operators=[])
            return LocalOperatorListResponse(
                status=ResponseStatus.ERROR,
                message="Failed to parse response from operator registry",
                data=data,
                error=ErrorDetails(
                    message=str(e),
                    type="json_parse_error"
                )
            )
    except Exception as e:
        if logger_instance:
            logger_instance.error(f"List operation failed: {e}")
        
        # Return appropriate error response based on options
        if options.remote and options.versions:
            data = RemoteOperatorVersionsData(count=0, versions=[])
            return RemoteOperatorVersionsResponse(
                status=ResponseStatus.ERROR,
                message="Failed to list operator versions",
                data=data,
                error=ErrorDetails(
                    message=str(e),
                    type="bridge_error"
                )
            )
        elif options.remote:
            data = RemoteOperatorListData(count=0, operators=[])
            return RemoteOperatorListResponse(
                status=ResponseStatus.ERROR,
                message="Failed to list remote operators",
                data=data,
                error=ErrorDetails(
                    message=str(e),
                    type="bridge_error"
                )
            )
        else:
            data = LocalOperatorListData(count=0, operators=[])
            return LocalOperatorListResponse(
                status=ResponseStatus.ERROR,
                message="Failed to list local operators",
                data=data,
                error=ErrorDetails(
                    message=str(e),
                    type="bridge_error"
                )
            )
