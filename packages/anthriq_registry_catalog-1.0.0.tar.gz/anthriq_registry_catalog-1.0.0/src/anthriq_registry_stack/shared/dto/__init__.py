"""
Shared DTOs for the Registry Stack Python SDK.

This module provides common data transfer objects used across all services.
"""

from .common import (
    BaseConfig,
    CliResponse,
    ErrorDetails,
    PaginationOptions,
    OperationOptions,
    Platform,
    VersionInfo,
)

__all__ = [
    "BaseConfig",
    "CliResponse",
    "ErrorDetails",
    "PaginationOptions",
    "OperationOptions",
    "Platform",
    "VersionInfo",
]
