# anthriq-registry-stack Examples

This directory contains example usage of the published `anthriq-registry-stack` Python package. These examples demonstrate how to use the SDK in real applications.

## 📦 Package Information

- **Package**: `anthriq-registry-stack`
- **Registry**: PyPI (https://pypi.org/project/anthriq-registry-stack/)
- **Installation**: `pip install anthriq-registry-stack`

## 🚀 Quick Start

### 1. Install Dependencies

```bash
cd examples
pip install -r requirements.txt
```

### 2. Run All Examples

```bash
# Run all examples (recommended)
python src/index.py

# Or run individual examples
python src/executor/index.py
python src/operator_registry/index.py
python src/pipeline_registry/index.py
python src/recorder/index.py
```

## 📁 Example Structure

```
examples/
├── src/
│   ├── index.py                    # Main runner - tests all components
│   ├── executor/
│   │   └── index.py               # Executor example
│   ├── operator_registry/
│   │   └── index.py               # Operator Registry example
│   ├── pipeline_registry/
│   │   └── index.py               # Pipeline Registry example
│   └── recorder/
│       └── index.py               # Recorder example
├── requirements.txt               # Python dependencies
├── pyproject.toml                 # Project configuration
└── README.md                     # This file
```

## 🎯 What Each Example Demonstrates

### `src/index.py` - Main Test Runner
Comprehensive test that verifies:
- ✅ Package import functionality
- ✅ Class instantiation
- ✅ Method availability
- ✅ Type definitions
- ✅ Package information
- ✅ Individual example execution

### `src/executor/index.py` - Executor Example
Demonstrates Executor usage:
- Pipeline creation and management
- Start/stop operations
- Logging and monitoring
- Pipeline lifecycle management

### `src/operator_registry/index.py` - Operator Registry Example
Demonstrates Operator Registry usage:
- Operator installation and management
- Registry operations
- Operator lifecycle

### `src/pipeline_registry/index.py` - Pipeline Registry Example
Demonstrates Pipeline Registry usage:
- Pipeline storage and retrieval
- Registry operations
- Pipeline management

### `src/recorder/index.py` - Recorder Example
Demonstrates Recorder usage:
- Recording creation and management
- Start/stop recording
- Download and metadata operations

## 🔧 Usage Examples

### Basic Import

```python
from anthriq_registry_stack import Executor, OperatorRegistry, PipelineRegistry, Recorder
```

### Executor Usage

```python
import asyncio
from anthriq_registry_stack import Executor

async def main():
    executor = Executor(
        base_path="/tmp/executor",
        bridge_lib_path="/path/to/libexecutor_bridge.dylib",
        debug=True
    )
    
    await executor.initialize()
    
    result = await executor.create(
        config={"json_file": "/path/to/pipeline.json"},
        device_id="my-device-001",
        enable_logging=True
    )

asyncio.run(main())
```

### Operator Registry Usage

```python
import asyncio
from anthriq_registry_stack import OperatorRegistry

async def main():
    operator_registry = OperatorRegistry(
        base_path="/tmp/operator-registry",
        bridge_lib_path="/path/to/liboperator_registry_bridge.dylib",
        debug=True
    )
    
    await operator_registry.initialize()
    
    operators = await operator_registry.list()

asyncio.run(main())
```

## 🧪 Testing the Published Package

### What the Tests Verify

1. **Package Installation**: Confirms the package can be imported
2. **Class Instantiation**: Verifies all classes can be created
3. **Method Availability**: Checks all expected methods exist
4. **Type Definitions**: Ensures Python type hints work
5. **Error Handling**: Tests graceful failure without native libraries
6. **Individual Examples**: Runs each component example

### Expected Behavior

- ✅ **Success**: All imports and instantiations work
- ⚠️ **Warnings**: Native bridge operations fail (expected without actual libraries)
- ❌ **Errors**: Only if package installation or import fails

## 🛠️ Development Setup

### Prerequisites

- Python >= 3.8
- pip >= 20.0.0
- Published `anthriq-registry-stack` package

### Local Development

```bash
# Install the published package
pip install anthriq-registry-stack

# Or install from local build
pip install ../dist/anthriq_registry_stack-1.0.0-py3-none-any.whl

# Run examples
python src/index.py
```

## 🔍 Troubleshooting

### Common Issues

1. **"Module not found"**
   - Ensure package is installed: `pip install anthriq-registry-stack`
   - Check requirements.txt dependencies

2. **"Native bridge not found"**
   - This is expected in example environment
   - Install actual bridge libraries for real usage

3. **"Type definitions not found"**
   - Check installed package for type hints
   - Ensure Python is properly configured

4. **"asyncio not found"**
   - Ensure Python 3.8+ is being used
   - Check that asyncio is available

### Debug Mode

All examples run with `debug=True` to show detailed logging:

```python
executor = Executor(
    debug=True  # Enables detailed logging
)
```

## 📚 Next Steps

1. **Install Bridge Libraries**: Get the actual native libraries
2. **Configure Paths**: Update bridge library paths in examples
3. **Create Real Data**: Use actual pipeline/operator files
4. **Deploy**: Use in production environment

## 🔗 Related Documentation

- [Main SDK Documentation](../README.md)
- [Publishing Guide](../../PUBLISHING.md)
- [API Reference](../docs/)

## 📞 Support

- **Email**: vignesh.sambari@nexstem.ai
- **Issues**: [GitHub Issues](https://github.com/sw-registry-stack/sdk/issues)
- **Package**: [PyPI Package](https://pypi.org/project/anthriq-registry-stack/)

