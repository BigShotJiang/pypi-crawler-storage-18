#!/usr/bin/env python3
"""
Recorder Example - Demonstrates how to use the Recorder from anthriq-registry-stack
This example shows how to manage recordings
"""

import asyncio
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent / "src"))

from modules.recorder import Recorder

print("📹 Recorder Example - anthriq-registry-stack")
print("=" * 50)

async def recorder_example():
    """Test Recorder methods like in Node.js SDK"""
    print("🧪 Testing Recorder Methods - anthriq-registry-stack")
    print("=" * 60)
    
    try:
        # Initialize Recorder (like Node.js SDK)
        print("\n1️⃣ Initializing Recorder...")
        recorder = Recorder({})
        print("✅ Recorder created successfully")
        
        # Initialize bridge
        print("\n2️⃣ Initializing native bridge...")
        await recorder.initialize()
        print("✅ Recorder initialized successfully")
        
        # Test list method
        print("\n3️⃣ Testing list() method...")
        list_result = await recorder.list()
        print(f"✅ List result: {list_result}")
        
        # Test create method (will fail without native libraries, but we can test the call)
        print("\n4️⃣ Testing create() method...")
        try:
            create_result = await recorder.create(
                name="test-recording",
                tags=["test", "example"]
            )
            print(f"✅ Create result: {create_result}")
        except Exception as e:
            print(f"⚠️  Create method test (expected to fail without native libraries): {e}")
        
        # Test info method (with recordingId like Node.js)
        print("\n5️⃣ Testing info() method...")
        try:
            info_result = await recorder.info("test-recording-123")
            print(f"✅ Info result: {info_result}")
        except Exception as e:
            print(f"⚠️  Info method test (expected to fail without real recording): {e}")
        
        # Test totalDuration method (like Node.js)
        print("\n6️⃣ Testing totalDuration() method...")
        try:
            duration_result = await recorder.totalDuration()
            print(f"✅ Total duration: {duration_result}")
        except Exception as e:
            print(f"⚠️  Total duration test (expected to fail without real recordings): {e}")
        
        # Test start method (will fail without native libraries, but we can test the call)
        print("\n7️⃣ Testing start() method...")
        try:
            start_result = await recorder.start("test-recording-123")
            print(f"✅ Start result: {start_result}")
        except Exception as e:
            print(f"⚠️  Start method test (expected to fail without native libraries): {e}")
        
        print("\n🎉 Recorder methods are working correctly!")
        
    except Exception as error:
        print(f"❌ Recorder example failed: {error}")
        print("   This is expected if native bridge libraries are not available")
        print("   In a real environment, ensure the bridge libraries are properly installed")

# Run the example
if __name__ == "__main__":
    asyncio.run(recorder_example())
    print("\n🎉 Recorder example completed!")
    print("\n📚 Next steps:")
    print("   1. Install the actual bridge libraries")
    print("   2. Provide correct paths to bridge libraries")
    print("   3. Create real recording files")
    print("   4. Run with actual hardware/device")