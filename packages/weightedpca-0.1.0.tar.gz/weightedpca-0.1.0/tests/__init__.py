"""Tests for weightedpca package."""

