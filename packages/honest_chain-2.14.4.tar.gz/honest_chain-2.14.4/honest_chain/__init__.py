"""
HONEST CHAIN SDK v2.0 - Quantum-Ready
=====================================

Make AI Honest to God.

The logical foundation for AI transparency: inner == outer.
Bitcoin-anchored, formally verified, quantum-safe.

Features:
    - Quantum-safe cryptographic identity (SHA3-256)
    - DID-style agent identifiers (did:hc:...)
    - Digital signatures on all decisions
    - Bitcoin anchoring for permanence

Usage:
    from honest_chain import HonestChain, RiskLevel

    hc = HonestChain(agent_id="my-agent")

    # Get agent DID
    print(hc.did)  # did:hc:abc123...

    # Log decisions (automatically signed)
    hc.decide(
        action="Approved request",
        reasoning="All criteria met",
        risk_level=RiskLevel.LOW
    )
    assert hc.verify()

Copyright (c) 2025 Stellanium Ltd. All rights reserved.
Licensed under MIT License. See LICENSE file.
AOAI™ and HONEST CHAIN™ are trademarks of Stellanium Ltd.
"""

__version__ = "2.14.4"
__author__ = "Stellanium Ltd"
__email__ = "admin@stellanium.io"
__license__ = "MIT"

# Minimum secure version - versions below this are deprecated
_MIN_SECURE_VERSION = "2.14.0"


def _check_version():
    """Check for updates and warn about outdated versions."""
    import warnings
    from packaging.version import Version

    current = Version(__version__)
    min_secure = Version(_MIN_SECURE_VERSION)

    # Block outdated versions
    if current < min_secure:
        warnings.warn(
            f"SECURITY WARNING: honest-chain {__version__} is outdated and insecure. "
            f"Upgrade immediately: pip install --upgrade honest-chain",
            DeprecationWarning,
            stacklevel=3
        )
        return

    # Check PyPI for newer version (non-blocking, cached)
    try:
        import urllib.request
        import json
        import os
        from pathlib import Path
        import time

        # Cache check - only check once per hour
        cache_file = Path.home() / ".honest_chain" / ".version_cache"
        cache_file.parent.mkdir(parents=True, exist_ok=True)

        if cache_file.exists():
            cache_age = time.time() - cache_file.stat().st_mtime
            if cache_age < 3600:  # 1 hour
                cached = cache_file.read_text().strip()
                if cached and Version(cached) > current:
                    warnings.warn(
                        f"honest-chain {cached} available (you have {__version__}). "
                        f"Upgrade: pip install --upgrade honest-chain",
                        UserWarning,
                        stacklevel=3
                    )
                return

        # Fetch latest version from PyPI (timeout 2s)
        req = urllib.request.Request(
            "https://pypi.org/pypi/honest-chain/json",
            headers={"Accept": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            data = json.loads(resp.read().decode())
            latest = data["info"]["version"]
            cache_file.write_text(latest)

            if Version(latest) > current:
                warnings.warn(
                    f"honest-chain {latest} available (you have {__version__}). "
                    f"Upgrade: pip install --upgrade honest-chain",
                    UserWarning,
                    stacklevel=3
                )
    except Exception:
        pass  # Non-blocking - don't break import


# Run version check on import
_check_version()

# Core
from honest_chain.core import (
    HonestChain,
    DecisionRecord,
    Actor,
    ActorType,
    RiskLevel,
    log_decision,
)

# Quantum-ready identity
from honest_chain.identity import (
    AgentIdentity,
    Signature,
    HashCommitment,
    KeyMaterial,
    SignatureAlgorithm,
)

# Bitcoin anchoring
from honest_chain.bitcoin import (
    BitcoinAnchorService,
    BitcoinAnchor,
    AnchorMethod,
    AOAIGroundTruth,
    create_bitcoin_anchor_callback,
)

# P2P network
from honest_chain.p2p import (
    AOAINode,
    MessageType,
    Message,
    Peer,
    create_anchor_callback,
)

__all__ = [
    # Core
    "HonestChain",
    "DecisionRecord",
    "Actor",
    "ActorType",
    "RiskLevel",
    "log_decision",
    # Identity (NEW)
    "AgentIdentity",
    "Signature",
    "HashCommitment",
    "KeyMaterial",
    "SignatureAlgorithm",
    # Bitcoin
    "BitcoinAnchorService",
    "BitcoinAnchor",
    "AnchorMethod",
    "AOAIGroundTruth",
    "create_bitcoin_anchor_callback",
    # P2P
    "AOAINode",
    "MessageType",
    "Message",
    "Peer",
    "create_anchor_callback",
    # Meta
    "__version__",
]
