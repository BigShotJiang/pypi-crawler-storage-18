"""Tests for snakesee."""
