"""Version for charmarr-core package."""

__version__ = "0.4.2"  # x-release-please-version
