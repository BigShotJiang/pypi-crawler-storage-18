"""AWS components for Stelvio."""
