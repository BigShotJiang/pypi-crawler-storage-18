from .oyun import MangalaTurkOyunu
