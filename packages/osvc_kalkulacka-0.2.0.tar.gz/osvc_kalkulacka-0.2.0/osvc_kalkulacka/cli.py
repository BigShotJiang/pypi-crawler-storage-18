from __future__ import annotations

import json
import os
from importlib import resources
import tomllib

import click

from osvc_kalkulacka.core import (
    D,
    Inputs,
    USER_DEFAULTS,
    ceil_czk,
    compute,
    round_czk_half_up,
)


def fmt(n: int) -> str:
    return f"{n:,}".replace(",", " ")


def print_row(label: str, value: int | str, *, suffix: str = "Kč", label_width: int = 40) -> None:
    """
    Print a row with aligned value column. Integers are formatted with thousands separators
    and optional suffix (default Kč); strings are printed as-is.
    """
    if isinstance(value, int):
        value_str = f"{fmt(value)} {suffix}" if suffix else fmt(value)
    else:
        value_str = value
    print(f"{label:<{label_width}}{value_str}")


def print_row_text(label: str, value: str, *, label_width: int = 40) -> None:
    """Print a row where value is already formatted text (no suffix)."""
    print_row(label, value, suffix="", label_width=label_width)


def get_user_dir() -> str:
    env_path = os.getenv("OSVC_USER_PATH")
    if env_path:
        return env_path
    return click.get_app_dir("cz.janfertek.osvc-kalkulacka")


def _load_toml(path: str) -> dict[str, object]:
    with open(path, "rb") as f:
        return tomllib.load(f)


def _load_package_toml(filename: str) -> dict[str, object]:
    try:
        with resources.files("osvc_kalkulacka.data").joinpath(filename).open("rb") as f:
            return tomllib.load(f)
    except FileNotFoundError as exc:
        raise SystemExit(
            f"Chybí defaultní {filename}. Zadej --defaults nebo nastav OSVC_DEFAULTS_PATH."
        ) from exc


def load_year_presets(path: str | None, user_dir: str) -> dict[int, dict[str, object]]:
    """
    Načte roční presety z TOML. Priorita:
    1) explicitní cesta (CLI), 2) OSVC_PRESETS_PATH, 3) {user_dir}/year_presets.toml
    """
    if path:
        data = _load_toml(path)
    else:
        env_path = os.getenv("OSVC_PRESETS_PATH")
        if env_path:
            data = _load_toml(env_path)
        else:
            preset_path = os.path.join(user_dir, "year_presets.toml")
            if not os.path.exists(preset_path):
                raise SystemExit(
                    f"Chybí preset soubor: {preset_path}. Spusť `osvc init` nebo zadej --presets."
                )
            data = _load_toml(preset_path)

    out: dict[int, dict[str, object]] = {}
    for key, value in data.items():
        try:
            year_key = int(key)
        except (TypeError, ValueError):
            continue
        if isinstance(value, dict):
            out[year_key] = value
    return out


def _ensure_int(value: object, *, name: str, year: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise SystemExit(f"Rok {year}: {name} musí být celé číslo.")
    if value < 0:
        raise SystemExit(f"Rok {year}: {name} nesmí být záporné.")
    return value


def _ensure_decimal_0_1(value: object, *, name: str, year: int) -> D:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise SystemExit(f"Rok {year}: {name} musí být číslo (0.0–1.0).")
    dec = D(str(value))
    if not (D("0") <= dec <= D("1")):
        raise SystemExit(f"Rok {year}: {name} musí být v intervalu 0.0–1.0.")
    return dec


def load_year_defaults(path: str | None, user_dir: str) -> dict[int, dict[str, object]]:
    """
    Načte roční tabulky z TOML. Priorita:
    1) explicitní cesta (CLI), 2) OSVC_DEFAULTS_PATH, 3) {user_dir}/year_defaults.override.toml (pokud existuje),
    4) default v balíčku.
    """
    if path:
        data = _load_toml(path)
    else:
        env_path = os.getenv("OSVC_DEFAULTS_PATH")
        if env_path:
            data = _load_toml(env_path)
        else:
            override_path = os.path.join(user_dir, "year_defaults.override.toml")
            if os.path.exists(override_path):
                data = _load_toml(override_path)
            else:
                data = _load_package_toml("year_defaults.toml")

    required_keys = {
        "avg_wage_czk",
        "min_wage_czk",
        "taxpayer_credit",
        "child_bonus_annual_tiers",
        "spouse_allowance",
        "sp_vym_base_share",
        "sp_min_base_share",
    }

    out: dict[int, dict[str, object]] = {}
    for key, value in data.items():
        try:
            year_key = int(key)
        except (TypeError, ValueError):
            raise SystemExit(f"Neplatný klíč roku: {key!r}")
        if not isinstance(value, dict):
            raise SystemExit(f"Rok {year_key}: očekávám tabulku s hodnotami.")

        unknown_keys = set(value.keys()) - required_keys
        if unknown_keys:
            unknown_list = ", ".join(sorted(unknown_keys))
            raise SystemExit(f"Rok {year_key}: neznámé klíče: {unknown_list}")

        missing_keys = required_keys - set(value.keys())
        if missing_keys:
            missing_list = ", ".join(sorted(missing_keys))
            raise SystemExit(f"Rok {year_key}: chybí klíče: {missing_list}")

        avg_wage_czk = _ensure_int(value["avg_wage_czk"], name="avg_wage_czk", year=year_key)
        min_wage_czk = _ensure_int(value["min_wage_czk"], name="min_wage_czk", year=year_key)
        taxpayer_credit = _ensure_int(value["taxpayer_credit"], name="taxpayer_credit", year=year_key)
        spouse_allowance = _ensure_int(value["spouse_allowance"], name="spouse_allowance", year=year_key)

        tiers = value["child_bonus_annual_tiers"]
        if not isinstance(tiers, list) or len(tiers) != 3:
            raise SystemExit(f"Rok {year_key}: child_bonus_annual_tiers musí být pole se 3 čísly.")
        child_tiers = tuple(_ensure_int(item, name="child_bonus_annual_tiers", year=year_key) for item in tiers)

        sp_vym_base_share = _ensure_decimal_0_1(value["sp_vym_base_share"], name="sp_vym_base_share", year=year_key)
        sp_min_base_share = _ensure_decimal_0_1(value["sp_min_base_share"], name="sp_min_base_share", year=year_key)

        out[year_key] = {
            "avg_wage_czk": avg_wage_czk,
            "min_wage_czk": min_wage_czk,
            "taxpayer_credit": taxpayer_credit,
            "spouse_allowance": spouse_allowance,
            "child_bonus_annual_tiers": child_tiers,
            "sp_vym_base_share": sp_vym_base_share,
            "sp_min_base_share": sp_min_base_share,
        }

    return out


def _parse_child_months(raw: str) -> tuple[int, ...]:
    return tuple(int(item.strip()) for item in raw.split(",") if item.strip())


def _json_dump(payload: object) -> None:
    click.echo(json.dumps(payload, ensure_ascii=True, separators=(",", ":"), default=str))


def _results_as_dict(inp: Inputs, res) -> dict[str, object]:
    return {
        "inputs": {
            "income_czk": inp.income_czk,
            "child_months_by_order": list(inp.child_months_by_order),
            "min_wage_czk": inp.min_wage_czk,
            "expense_rate": str(inp.expense_rate),
            "mortgage_interest_paid_czk": inp.mortgage_interest_paid_czk,
            "mortgage_interest_limit_czk": inp.mortgage_interest_limit_czk,
            "donations_paid_czk": inp.donations_paid_czk,
            "donation_max_pct": str(inp.donation_max_pct),
            "donation_min_pct": str(inp.donation_min_pct),
            "donation_min_czk": inp.donation_min_czk,
            "tax_rate": str(inp.tax_rate),
            "taxpayer_credit_czk": inp.taxpayer_credit_czk,
            "spouse_allowance_czk": inp.spouse_allowance_czk,
            "child_bonus_annual_tiers_czk": list(inp.child_bonus_annual_tiers_czk),
            "avg_wage_czk": inp.avg_wage_czk,
            "zp_rate": str(inp.zp_rate),
            "sp_rate": str(inp.sp_rate),
            "zp_vym_base_share": str(inp.zp_vym_base_share),
            "sp_vym_base_share": str(inp.sp_vym_base_share),
            "zp_min_base_share": str(inp.zp_min_base_share),
            "sp_min_base_share": str(inp.sp_min_base_share),
            "min_zp_monthly_czk": inp.min_zp_monthly_czk,
            "min_sp_monthly_czk": inp.min_sp_monthly_czk,
        },
        "tax": {
            "expenses_czk": res.tax.expenses_czk,
            "base_profit_czk": res.tax.base_profit_czk,
            "deductible_interest_czk": res.tax.deductible_interest_czk,
            "donations_paid_czk": res.tax.donations_paid_czk,
            "donations_deductible_czk": res.tax.donations_deductible_czk,
            "base_after_deductions_czk": res.tax.base_after_deductions_czk,
            "base_rounded_czk": res.tax.base_rounded_czk,
            "tax_before_credits_czk": res.tax.tax_before_credits_czk,
            "tax_after_taxpayer_credit_czk": res.tax.tax_after_taxpayer_credit_czk,
            "tax_after_spouse_credit_czk": res.tax.tax_after_spouse_credit_czk,
            "spouse_credit_applied_czk": res.tax.spouse_credit_applied_czk,
            "child_bonus_czk": res.tax.child_bonus_czk,
            "child_bonus_eligible": res.tax.child_bonus_eligible,
            "child_bonus_min_income_czk": res.tax.child_bonus_min_income_czk,
            "tax_final_czk": res.tax.tax_final_czk,
            "bonus_to_pay_czk": res.tax.bonus_to_pay_czk,
        },
        "insurance": {
            "vym_base_czk": res.ins.vym_base_czk,
            "min_zp_monthly_czk": res.ins.min_zp_monthly_czk,
            "min_sp_monthly_czk": res.ins.min_sp_monthly_czk,
            "zp_annual_czk": res.ins.zp_annual_czk,
            "zp_monthly_calc_czk": res.ins.zp_monthly_calc_czk,
            "zp_monthly_payable_czk": res.ins.zp_monthly_payable_czk,
            "zp_annual_payable_czk": res.ins.zp_annual_payable_czk,
            "sp_annual_czk": res.ins.sp_annual_czk,
            "sp_monthly_calc_czk": res.ins.sp_monthly_calc_czk,
            "sp_monthly_payable_czk": res.ins.sp_monthly_payable_czk,
            "sp_annual_payable_czk": res.ins.sp_annual_payable_czk,
        },
    }


class DefaultGroup(click.Group):
    def __init__(self, *args: object, default_command: str | None = None, **kwargs: object) -> None:
        super().__init__(*args, **kwargs)
        self.default_command = default_command

    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if self.default_command and (not args or args[0] not in self.commands):
            args.insert(0, self.default_command)
        return super().parse_args(ctx, args)


@click.group(cls=DefaultGroup, default_command="calc")
@click.version_option(package_name="osvc-kalkulacka")
def cli() -> None:
    """OSVČ kalkulačka (DPFO + ZP/SP), zjednodušený výpočet."""


@cli.command()
@click.option("--year", type=int, required=True, help="Rok, pro který se používají minima záloh.")
@click.option("--income", type=int, default=None, help="Příjmy (§7) v Kč za rok.")
@click.option(
    "--presets",
    type=str,
    default=None,
    help="Cesta k TOML s ročními presety. Alternativně lze použít OSVC_PRESETS_PATH.",
)
@click.option(
    "--defaults",
    type=str,
    default=None,
    help="Cesta k TOML s ročními tabulkami. Alternativně lze použít OSVC_DEFAULTS_PATH.",
)
@click.option(
    "--mortgage-interest-paid",
    type=int,
    default=None,
    help="Zaplacené úroky z hypotéky za rok (§15) v Kč (pro smlouvy sjednané od 1. 1. 2021 platí limit 150 000 Kč ročně).",
)
@click.option(
    "--donations",
    type=int,
    default=None,
    help="Součet darů za rok (§15) v Kč (uplatní se jen pokud součet >= max(2 % základu, 1 000 Kč)).",
)
@click.option(
    "--child-months-by-order",
    type=str,
    default=None,
    help="Měsíce nároku podle pořadí dětí (např. 6,6,12 pro 1., 2., 3. dítě).",
)
@click.option(
    "--spouse-allowance/--no-spouse-allowance",
    default=None,
    help="Uplatnit/neuplnit slevu na manžela/ku (přepíše preset).",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    show_default=True,
    help="Výstupní formát.",
)
def calc(
    year: int,
    income: int | None,
    presets: str | None,
    defaults: str | None,
    mortgage_interest_paid: int | None,
    donations: int | None,
    child_months_by_order: str | None,
    spouse_allowance: bool | None,
    output_format: str,
) -> None:
    user_dir = get_user_dir()

    year_defaults = load_year_defaults(defaults, user_dir)
    year_cfg = year_defaults.get(year)
    if year_cfg is None:
        known_years = ", ".join(str(y) for y in sorted(year_defaults))
        raise SystemExit(f"Neznám daňové parametry pro rok {year}. Známé roky: {known_years}")
    if year_cfg["min_wage_czk"] <= 0:
        raise SystemExit(f"Chybí min_wage_czk pro rok {year}. Doplň year_defaults.toml.")

    year_presets = load_year_presets(presets, user_dir)
    preset = year_presets.get(year, {})
    income_czk = income if income is not None else preset.get("income_czk")
    if income_czk is None:
        raise SystemExit("Chybí příjmy. Zadej --income nebo doplň preset pro daný rok.")

    mortgage_interest_paid_czk = (
        mortgage_interest_paid
        if mortgage_interest_paid is not None
        else preset.get("mortgage_interest_paid_czk", 0)
    )
    donations_paid_czk = (
        donations
        if donations is not None
        else preset.get("donations_paid_czk", 0)
    )
    child_months_by_order_tuple = None
    if child_months_by_order:
        child_months_by_order_tuple = _parse_child_months(child_months_by_order)
    elif "child_months_by_order" in preset:
        preset_months = preset.get("child_months_by_order") or []
        if not isinstance(preset_months, list):
            raise SystemExit("Preset: child_months_by_order musí být seznam čísel.")
        child_months_by_order_tuple = tuple(int(item) for item in preset_months)

    if child_months_by_order_tuple is None:
        raise SystemExit("Chybí child_months_by_order. Zadej --child-months-by-order nebo nastav preset.")
    if spouse_allowance is True:
        spouse_allowance = True
    elif spouse_allowance is False:
        spouse_allowance = False
    else:
        spouse_allowance = preset.get("spouse_allowance", False)

    # Vypočet minimální měsíční zálohy z ročního minima (ceiling na roční, měsíční zaokrouhleno matematicky).
    zp_annual_min_default = ceil_czk(D(year_cfg["avg_wage_czk"]) * D("0.50") * D("0.135") * D("12"))
    sp_annual_min_default = ceil_czk(
        D(year_cfg["avg_wage_czk"]) * year_cfg["sp_min_base_share"] * D("0.292") * D("12")
    )
    min_zp_monthly_default = round_czk_half_up(D(zp_annual_min_default) / D("12"))
    min_sp_monthly_default = round_czk_half_up(D(sp_annual_min_default) / D("12"))

    inp = Inputs(
        income_czk=income_czk,
        child_months_by_order=child_months_by_order_tuple,
        min_wage_czk=year_cfg["min_wage_czk"],
        expense_rate=USER_DEFAULTS["expense_rate"],
        mortgage_interest_paid_czk=mortgage_interest_paid_czk,
        mortgage_interest_limit_czk=USER_DEFAULTS["mortgage_interest_limit"],
        donations_paid_czk=donations_paid_czk,
        donation_max_pct=USER_DEFAULTS["donation_max_pct"],
        donation_min_pct=USER_DEFAULTS["donation_min_pct"],
        donation_min_czk=USER_DEFAULTS["donation_min_czk"],
        tax_rate=USER_DEFAULTS["tax_rate"],
        taxpayer_credit_czk=year_cfg["taxpayer_credit"],
        spouse_allowance_czk=year_cfg["spouse_allowance"] if spouse_allowance else 0,
        child_bonus_annual_tiers_czk=year_cfg["child_bonus_annual_tiers"],
        avg_wage_czk=year_cfg["avg_wage_czk"],
        min_zp_monthly_czk=min_zp_monthly_default,
        min_sp_monthly_czk=min_sp_monthly_default,
        zp_min_base_share=D("0.50"),
        sp_min_base_share=year_cfg["sp_min_base_share"],
        sp_vym_base_share=year_cfg["sp_vym_base_share"],
    )

    res = compute(inp)

    if output_format == "json":
        _json_dump(_results_as_dict(inp, res))
        return

    print("OSVČ kalkulačka – DPFO + pojistné (zjednodušený výpočet)")
    print("-" * 70)

    print("DPFO (daň z příjmů)")
    print_row("Příjmy (§7):", inp.income_czk)
    print_row(f"Výdaje paušálem ({(inp.expense_rate * 100)}%):", res.tax.expenses_czk)
    print_row("Zisk / základ (§7):", res.tax.base_profit_czk)
    print()
    print_row_text(
        "Úroky zaplacené / limit:",
        f"{fmt(inp.mortgage_interest_paid_czk)} / {fmt(inp.mortgage_interest_limit_czk)} Kč",
    )
    print_row("Úroky uplatněno:", res.tax.deductible_interest_czk)
    print_row_text(
        "Dary zaplacené / uplatněno:",
        f"{fmt(res.tax.donations_paid_czk)} / {fmt(res.tax.donations_deductible_czk)} Kč",
    )
    print_row("Základ po odpočtu úroků a darů:", res.tax.base_after_deductions_czk)
    print_row("Základ daně zaokrouhlený:", res.tax.base_rounded_czk)
    print()
    print_row("Daň z příjmů před odečtením slev:", res.tax.tax_before_credits_czk)
    print_row("Sleva na poplatníka:", inp.taxpayer_credit_czk)
    print_row("Sleva na manžela/ku (nárok):", inp.spouse_allowance_czk)
    print_row("Sleva na manžela/ku (uplatněno):", res.tax.spouse_credit_applied_czk)
    total_credits_claimed = inp.taxpayer_credit_czk + inp.spouse_allowance_czk
    total_credits_applied = inp.taxpayer_credit_czk + res.tax.spouse_credit_applied_czk
    print_row("Slevy celkem (nárok):", total_credits_claimed)
    print_row("Slevy celkem (uplatněno):", total_credits_applied)
    print_row("Daň po slevách na poplatníka a manžela/ku:", res.tax.tax_after_spouse_credit_czk)
    print()
    if not res.tax.child_bonus_eligible:
        min_income = fmt(res.tax.child_bonus_min_income_czk)
        print(f"VAROVÁNÍ: Daňové zvýhodnění na děti neuplatněno (příjmy < {min_income} Kč).")
    child_used_for_tax = min(res.tax.child_bonus_czk, res.tax.tax_after_spouse_credit_czk)
    print_row("Zvýhodnění na děti (uplatněno):", res.tax.child_bonus_czk)
    print_row("  Z toho použito na snížení daně:", child_used_for_tax)
    print_row("Daňový bonus vyplacený (-):", res.tax.bonus_to_pay_czk)
    print_row("Daň k úhradě po dětech:", res.tax.tax_final_czk)

    print("-" * 70)

    print("Pojistné (ZP/SP) – odhad z ročního zisku")
    print("(Pozn.: pokud výpočet vychází pod minimem, platí se minimální zálohy.)")
    print_row("Vyměřovací základ (50 % zisku):", res.ins.vym_base_czk)
    print()

    print("Zdravotní pojištění (ZP)")
    print_row("  Ročně (13,5 % z VZ):", res.ins.zp_annual_czk)
    print_row("  Měsíčně vypočteno (roční/12):", res.ins.zp_monthly_calc_czk)
    print_row(f"  Minimální záloha ({year}):", res.ins.min_zp_monthly_czk)
    print_row("  Měsíční záloha k placení:", res.ins.zp_monthly_payable_czk)
    print_row("  Ročně zaplaceno na zálohách:", res.ins.zp_annual_payable_czk)
    print()

    print("Sociální pojištění (SP)")
    print_row("  Ročně (29,2 % z VZ):", res.ins.sp_annual_czk)
    print_row("  Měsíčně vypočteno (roční/12):", res.ins.sp_monthly_calc_czk)
    print_row(f"  Minimální záloha ({year}):", res.ins.min_sp_monthly_czk)
    print_row("  Měsíční záloha k placení:", res.ins.sp_monthly_payable_czk)
    print_row("  Ročně zaplaceno na zálohách:", res.ins.sp_annual_payable_czk)

    print("-" * 70)

    total_out = res.tax.tax_final_czk + res.ins.zp_annual_payable_czk + res.ins.sp_annual_payable_czk
    total_net = total_out - res.tax.bonus_to_pay_czk

    print("Souhrn (ročně)")
    print_row("Daň k úhradě:", res.tax.tax_final_czk)
    print_row("ZP – zálohy zaplacené za rok:", res.ins.zp_annual_payable_czk)
    print_row("SP – zálohy zaplacené za rok:", res.ins.sp_annual_payable_czk)
    print_row("Celkem k platbě:", total_out)
    print_row("Bonus k výplatě (odečteno):", res.tax.bonus_to_pay_czk)
    print_row("Čisté zatížení (odvody - bonus):", total_net)

@cli.command()
@click.option("--force", is_flag=True, help="Přepsat existující preset soubor.")
def init(force: bool) -> None:
    """Vytvoří year_presets.toml v uživatelském adresáři ze šablony."""
    user_dir = get_user_dir()
    os.makedirs(user_dir, exist_ok=True)
    target_path = os.path.join(user_dir, "year_presets.toml")
    if os.path.exists(target_path) and not force:
        raise SystemExit(f"Soubor už existuje: {target_path}. Použij --force.")
    data = resources.files("osvc_kalkulacka.data").joinpath("year_presets.example.toml").read_bytes()
    with open(target_path, "wb") as f:
        f.write(data)
    click.echo(f"Vytvořeno: {target_path}")


@cli.group()
def config() -> None:
    """Konfigurace a cesty."""


@config.command("path")
def config_path() -> None:
    """Vypíše user dir a očekávané cesty."""
    user_dir = get_user_dir()
    preset_path = os.path.join(user_dir, "year_presets.toml")
    defaults_override = os.path.join(user_dir, "year_defaults.override.toml")
    click.echo(f"user_dir: {user_dir}")
    click.echo(f"presets: {preset_path}")
    click.echo(f"defaults_override: {defaults_override}")
    if os.getenv("OSVC_USER_PATH"):
        click.echo(f"OSVC_USER_PATH: {os.getenv('OSVC_USER_PATH')}")
    if os.getenv("OSVC_PRESETS_PATH"):
        click.echo(f"OSVC_PRESETS_PATH: {os.getenv('OSVC_PRESETS_PATH')}")
    if os.getenv("OSVC_DEFAULTS_PATH"):
        click.echo(f"OSVC_DEFAULTS_PATH: {os.getenv('OSVC_DEFAULTS_PATH')}")


@cli.group()
def defaults() -> None:
    """Práce s vestavěnými defaults."""


@defaults.command("dump")
@click.option("--output", type=click.Path(dir_okay=False, writable=True), default=None)
def defaults_dump(output: str | None) -> None:
    """Vyexportuje vestavěné year_defaults.toml."""
    data = resources.files("osvc_kalkulacka.data").joinpath("year_defaults.toml").read_bytes()
    if output:
        with open(output, "wb") as f:
            f.write(data)
        click.echo(f"Zapsáno: {output}")
    else:
        click.echo(data.decode("utf-8"), nl=True)


if __name__ == "__main__":
    cli()
