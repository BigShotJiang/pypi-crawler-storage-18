"""Lindr Python SDK - LLM Personality Evaluation API.

Lindr helps you validate fine-tuned models by measuring behavioral personality
across 10 dimensions. Compare base vs. fine-tuned models and catch personality
drift before deploying to production.

Basic usage:
    ```python
    import lindr

    client = lindr.Client(api_key="lnd_...")

    # Create a persona
    persona = client.personas.create(
        name="Support Agent",
        dimensions=lindr.PersonalityDimensions(
            openness=70,
            conscientiousness=85,
            extraversion=60,
            agreeableness=90,
            neuroticism=20,
            assertiveness=65,
            ambition=70,
            resilience=80,
            integrity=95,
            curiosity=75,
        ),
    )

    # Run batch evaluation
    eval_run, summary = client.evals.batch(
        name="Baseline v1",
        persona_id=persona.id,
        samples=[
            {"id": "1", "content": "Response from model..."},
        ],
    )

    print(f"Avg drift: {summary.avg_drift:.1f}%")
    ```
"""

from ._exceptions import (
    APIError,
    AuthenticationError,
    ConnectionError,
    LindrError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from ._version import __version__
from .client import AsyncClient, Client
from .types.checkpoints import Checkpoint, CheckpointCreate
from .types.common import (
    DriftDirection,
    EvalStatus,
    Message,
    PaginatedResponse,
    PersonalityDimensions,
    Recommendation,
    Tolerances,
    TrainingMethod,
)
from .types.comparisons import Comparison, ComparisonCreate, DimensionDiff
from .types.datasets import Dataset, DatasetCreate, DatasetPrompt
from .types.evals import BatchEvalSummary, EvalResult, EvalRun, EvalRunCreate, EvalSample
from .types.personas import Persona, PersonaCreate

__all__ = [
    # Version
    "__version__",
    # Clients
    "Client",
    "AsyncClient",
    # Exceptions
    "LindrError",
    "AuthenticationError",
    "ConnectionError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "APIError",
    # Common types
    "PersonalityDimensions",
    "Tolerances",
    "Message",
    "EvalStatus",
    "TrainingMethod",
    "Recommendation",
    "DriftDirection",
    "PaginatedResponse",
    # Datasets
    "Dataset",
    "DatasetCreate",
    "DatasetPrompt",
    # Personas
    "Persona",
    "PersonaCreate",
    # Evals
    "EvalRun",
    "EvalRunCreate",
    "EvalResult",
    "EvalSample",
    "BatchEvalSummary",
    # Comparisons
    "Comparison",
    "ComparisonCreate",
    "DimensionDiff",
    # Checkpoints
    "Checkpoint",
    "CheckpointCreate",
]
