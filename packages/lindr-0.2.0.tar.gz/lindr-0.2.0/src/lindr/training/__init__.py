"""
Lindr personality classifier training module.

This module provides tools for training, exporting, and managing
personality classifier models that map text embeddings to personality scores.

Usage:
    pip install lindr[training]

    # Export training data from Lindr API
    lindr-train export-data -o data.json

    # Train classifier
    lindr-train train -d data.json -o model.onnx

    # Push to HuggingFace Hub
    lindr-train push -m model.onnx -v v1.0.0
"""

from .model import PersonalityClassifier
from .dataset import PersonalityDataset
from .trainer import PersonalityTrainer, TrainingConfig
from .exporter import export_to_onnx, verify_onnx_model
from .hub import push_to_hub, download_model

__all__ = [
    "PersonalityClassifier",
    "PersonalityDataset",
    "PersonalityTrainer",
    "TrainingConfig",
    "export_to_onnx",
    "verify_onnx_model",
    "push_to_hub",
    "download_model",
]
