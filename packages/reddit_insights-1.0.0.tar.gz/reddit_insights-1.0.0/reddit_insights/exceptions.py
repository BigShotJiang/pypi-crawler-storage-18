"""
Reddit Insights SDK Exceptions
"""


class RedditInsightsError(Exception):
    """Base exception for Reddit Insights SDK."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response


class AuthenticationError(RedditInsightsError):
    """Raised when authentication fails."""
    pass


class RateLimitError(RedditInsightsError):
    """Raised when rate limit is exceeded."""
    pass


class ValidationError(RedditInsightsError):
    """Raised when request validation fails."""
    pass


class APIError(RedditInsightsError):
    """Raised when API returns an error."""
    pass

