"""
Reddit Insights Python SDK

A Python client library for the Reddit Insights API.
"""

from .client import RedditInsightsClient
from .exceptions import (
    RedditInsightsError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
    APIError,
)

__version__ = "1.0.0"
__all__ = [
    "RedditInsightsClient",
    "RedditInsightsError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "APIError",
]

