# Tests for Plato SDK
