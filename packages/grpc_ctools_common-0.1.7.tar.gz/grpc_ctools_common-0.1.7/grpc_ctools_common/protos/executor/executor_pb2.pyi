from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class CodeEnum(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FAILURE: _ClassVar[CodeEnum]
    SUCCESS: _ClassVar[CodeEnum]
FAILURE: CodeEnum
SUCCESS: CodeEnum

class ExecuteTestPlan(_message.Message):
    __slots__ = ("user_id", "plan_id")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    PLAN_ID_FIELD_NUMBER: _ClassVar[int]
    user_id: int
    plan_id: int
    def __init__(self, user_id: _Optional[int] = ..., plan_id: _Optional[int] = ...) -> None: ...

class StopExecuteTestPlan(_message.Message):
    __slots__ = ("user_id", "plan_id")
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    PLAN_ID_FIELD_NUMBER: _ClassVar[int]
    user_id: int
    plan_id: int
    def __init__(self, user_id: _Optional[int] = ..., plan_id: _Optional[int] = ...) -> None: ...

class ExecuteResult(_message.Message):
    __slots__ = ("code", "msg")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MSG_FIELD_NUMBER: _ClassVar[int]
    code: int
    msg: str
    def __init__(self, code: _Optional[int] = ..., msg: _Optional[str] = ...) -> None: ...
