## 如何使用

### 安装poetry

   ```shell
   pip install poetry
   ```

### 使用Poetry安装依赖

   ```
   poetry install
   ```

### 使用Poetry构建项目

   ```
   poetry build
   ```

## 如何通过Protobuf文件生成Python代码

   ```
   python -m grpc_tools.protoc -I. --python_out=grpc_ctools_common --pyi_out=grpc_ctools_common --grpc_python_out=grpc_ctools_common .\protos\executor\executor.proto
   ```