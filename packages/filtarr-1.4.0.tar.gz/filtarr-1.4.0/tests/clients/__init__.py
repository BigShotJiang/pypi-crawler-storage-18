"""Tests for client modules."""
