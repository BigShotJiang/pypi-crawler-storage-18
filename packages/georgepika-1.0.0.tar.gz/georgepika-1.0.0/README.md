# Georgepika Math Library

Простая библиотека математических операций на Python.

## Установка

```bash
pip install georgepika