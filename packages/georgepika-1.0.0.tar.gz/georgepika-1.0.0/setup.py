# Файл: georgeinn/setup.py
from setuptools import setup, find_packages

setup(
    name="georgepika",
    version="1.0.0",
    author="Georgepika",
    description="Простая математическая библиотека",
    long_description="Библиотека для базовых и продвинутых математических операций",
    packages=find_packages(),  # АВТОМАТИЧЕСКИ найдет папки с __init__.py
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    keywords="math, mathematics, operations",
)