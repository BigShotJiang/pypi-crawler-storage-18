# Файл: georgeinn/georgeinn/advanced.py
"""Продвинутые математические операции"""
import math

def power(base, exponent):
    """Возведение в степень"""
    return base ** exponent

def sqrt(number):
    """Квадратный корень"""
    if number < 0:
        raise ValueError("Корень из отрицательного числа")
    return math.sqrt(number)

def factorial(n):
    """Факториал числа"""
    if n < 0:
        raise ValueError("Факториал только для положительных чисел")
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result