# Файл: georgeinn/georgeinn/basic.py
"""Базовые математические операции"""

def add(a, b):
    """Сложение двух чисел"""
    return a + b

def subtract(a, b):
    """Вычитание"""
    return a - b

def multiply(a, b):
    """Умножение"""
    return a * b

def divide(a, b):
    """Деление с проверкой"""
    if b == 0:
        raise ValueError("Деление на ноль невозможно")
    return a / b