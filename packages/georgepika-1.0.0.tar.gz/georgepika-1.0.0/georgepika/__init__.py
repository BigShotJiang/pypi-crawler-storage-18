
"""
Georgepika - математическая библиотека
"""

__version__ = "1.0.0"
__author__ = "Georgepika"

# Импортируем функции из модулей
from .basic_math import add, subtract, multiply, divide
from .advanced_math import power, sqrt, factorial


__all__ = [
    'add', 'subtract', 'multiply', 'divide',
    'power', 'sqrt', 'factorial'
]