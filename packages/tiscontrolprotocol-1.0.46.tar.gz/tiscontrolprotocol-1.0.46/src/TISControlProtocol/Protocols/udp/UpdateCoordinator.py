class UpdateCoordinator:
    pass