# removebg-cli

智能图片背景移除命令行工具，基于 [remove.bg](https://www.remove.bg) API。

## 安装

```bash
pipx install removebg-cli
```

或使用 pip:
```bash
pip install removebg-cli
```

## 配置

设置环境变量（必须）:
```bash
export REMOVE_BG_API_KEY='你的API密钥'
# 添加到 ~/.zshrc 或 ~/.bashrc 以持久化
```

获取 API Key: https://www.remove.bg/dashboard#api-key

## 使用

```bash
# 处理本地图片
removebg photo.jpg

# 处理网络图片 (自动识别URL)
removebg https://example.com/image.jpg

# 指定输出文件
removebg photo.jpg -o result.png

# 高清输出
removebg photo.jpg -s full

# 白色背景
removebg photo.jpg -b white

# 裁剪空白区域
removebg photo.jpg -c

# 查看账户余额
removebg --account
```

## 参数说明

| 参数 | 说明 |
|------|------|
| `-o, --output` | 输出文件路径 |
| `-s, --size` | 尺寸: auto/preview/full/50MP |
| `-f, --format` | 格式: auto/png/jpg/webp/zip |
| `-b, --bg` | 背景色: white/ff0000 |
| `-c, --crop` | 裁剪空白区域 |
| `--shadow` | 添加阴影 |
| `--account` | 查看余额 |

## 特性

- 自动识别本地文件/URL
- 默认透明PNG输出
- 低额度警告 (≤10次)
- 请求限流自动重试
- 美化日志输出

## License

MIT
