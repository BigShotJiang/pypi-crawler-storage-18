use pyo3::prelude::*;
use pyo3::types::{PyFloat, PyInt, PyString};

// The actual parsing logic
#[pyfunction]
fn parse(py: Python, input: &Bound<'_, PyAny>) -> PyResult<Option<PyObject>> {
    // 1. FAST EXIT
    if input.is_instance_of::<PyInt>() || input.is_instance_of::<PyFloat>() {
        return Ok(Some(input.to_object(py)));
    }

    // 2. BORROW STRING
    let pystr = match input.downcast::<PyString>() {
        Ok(s) => s,
        Err(_) => return Ok(None),
    };
    let text = pystr.to_str()?;

    if text.is_empty() { return Ok(None); }

    // 3. MULTIPLIER SCAN
    let mut multiplier = 1.0;
    if text.contains(['k', 'K']) { multiplier = 1_000.0; }
    else if text.contains(['m', 'M']) { multiplier = 1_000_000.0; }
    else if text.contains(['b', 'B']) { multiplier = 1_000_000_000.0; }

    // 4. MANUAL DIGIT SCAN (Zero-Copy)
    let mut num_buf = String::with_capacity(text.len());
    let mut found_digit = false;

    for c in text.chars() {
        match c {
            '0'..='9' | '.' => {
                found_digit = true;
                num_buf.push(c);
            }
            ',' => continue,
            _ => {
                if found_digit { break; }
            }
        }
    }

    if num_buf.is_empty() { return Ok(None); }

    // 5. PARSE
    if let Ok(val) = num_buf.parse::<f64>() {
        let result = val * multiplier;
        if result.fract() == 0.0 {
            return Ok(Some((result as i64).to_object(py)));
        } else {
            return Ok(Some(result.to_object(py)));
        }
    }

    Ok(None)
}

// THIS IS THE MODULE DEFINITION
#[pymodule]
fn kidexa(py: Python, m: &Bound<'_, PyModule>) -> PyResult<()> {
    // 1. Add parse() directly to kidexa
    m.add_function(wrap_pyfunction!(parse, m)?)?;

    // 2. Create a fake "sloppy_number" submodule so your old imports work
    // This allows: from kidexa import sloppy_number
    let submodule = PyModule::new_bound(py, "sloppy_number")?;
    submodule.add_function(wrap_pyfunction!(parse, &submodule)?)?;
    m.add("sloppy_number", submodule)?;

    Ok(())
}