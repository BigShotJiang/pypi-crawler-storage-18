from __future__ import annotations

from functools import partial
from typing import Optional, Type, TypeVar

from pipeline.handlers.base_handler.base_handler import BaseHandler
from pipeline.handlers.base_handler.resources.constants import HandlerMode

T = TypeVar('T', bound=BaseHandler)


def Context(handler: Type[T]):
    return partial(handler, _mode=HandlerMode.CONTEXT)


def Item(
    handler: Type[T] | partial[T],
    use_key: Optional[bool] = False,
    only_consider: Optional[type] = None
):
    return partial(
        handler,
        _mode=HandlerMode.ITEM,
        _item_use_key=use_key,
        _preferred_value_type=only_consider
    )
