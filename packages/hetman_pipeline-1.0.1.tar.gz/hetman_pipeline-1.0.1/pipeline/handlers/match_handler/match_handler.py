import re
from typing import Optional

from pipeline.handlers.base_handler.base_handler import A, V
from pipeline.handlers.condition_handler.condition_handler import \
    ConditionHandler


class MatchHandler(ConditionHandler[V, A]):
    def search(
        self,
        pattern: str | re.Pattern,
        flag: Optional[re.RegexFlag] = None
    ) -> bool:
        return re.search(pattern, str(self.value), flag or 0) is not None

    def fullmatch(
        self,
        pattern: str | re.Pattern,
        flag: Optional[re.RegexFlag] = None
    ) -> bool:
        return re.fullmatch(pattern, str(self.value), flag or 0) is not None
