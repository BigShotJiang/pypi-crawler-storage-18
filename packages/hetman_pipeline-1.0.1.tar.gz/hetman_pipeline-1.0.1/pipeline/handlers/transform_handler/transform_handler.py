from __future__ import annotations

from abc import abstractmethod
from typing import cast

from pipeline.handlers.base_handler.base_handler import A, BaseHandler, V
from pipeline.handlers.base_handler.resources.exceptions import \
    HandlerModeException


class TransformHandler(BaseHandler[V, A]):
    @abstractmethod
    def operation(self) -> V:
        ...

    def _handle(self) -> V:
        return self.operation()

    def _handle_item_mode(self) -> V:
        if isinstance(self.input_value, list):
            items = enumerate(self.input_value)
        elif isinstance(self.input_value, dict):
            items = self.input_value.items()
        else:
            raise HandlerModeException(
                "The transform handler input value is not of type list or dict."
            )

        for key, value in items:
            if self._item_use_key:
                value = key

            if not self._is_valid_type(value, self._expected_value_type):
                continue

            # NOTE: We use can cast() here because we checked if the value type is valid but linter does not know that.
            self.value = cast(V, value)

            self.input_value[key] = self.operation()

        return self.input_value
