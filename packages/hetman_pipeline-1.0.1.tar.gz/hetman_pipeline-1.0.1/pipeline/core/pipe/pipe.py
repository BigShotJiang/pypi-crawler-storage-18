from typing import ClassVar, Generic, Optional, Type, TypeVar

from pipeline.core.pipe.resources.constants import PipeResult
from pipeline.core.pipe.resources.types import (
    PipeConditions, PipeContext, PipeMatches, PipeMetadata, PipeTransform
)
from pipeline.handlers.condition_handler.condition import Condition
from pipeline.handlers.condition_handler.resources.constants import \
    ConditionFlag
from pipeline.handlers.condition_handler.resources.types import ConditionErrors
from pipeline.handlers.match_handler.match import Match
from pipeline.handlers.transform_handler.transform import Transform

V = TypeVar("V")
T = TypeVar("T", bound=type)


class Pipe(Generic[V, T]):
    Condition: ClassVar[Type[Condition]] = Condition
    Match: ClassVar[Type[Match]] = Match
    Transform: ClassVar[Type[Transform]] = Transform

    def __init__(
        self,
        value: V,
        type: T,
        conditions: Optional[PipeConditions] = None,
        matches: Optional[PipeMatches] = None,
        transform: Optional[PipeTransform] = None,
        optional: Optional[bool] = None,
        context: Optional[PipeContext] = None,
        metadata: Optional[PipeMetadata] = None
    ) -> None:
        self.value: V = value

        self.type: T = type

        self.conditions: Optional[PipeConditions] = conditions
        self.matches: Optional[PipeMatches] = matches
        self.transform: Optional[PipeTransform] = transform

        self.optional: Optional[bool] = optional

        self.context: Optional[PipeContext] = context
        self.metadata: Optional[PipeMetadata] = metadata

        self._condition_errors: ConditionErrors = []
        self._match_errors: ConditionErrors = []

    def run(self) -> PipeResult[V]:
        if self.optional and (bool(self.value) is False):
            return PipeResult(
                value=self.value, condition_errors=[], match_errors=[]
            )

        if (error := self.Condition.ValueType(self.value, self.type).handle()):
            return PipeResult(
                value=self.value, condition_errors=[error], match_errors=[]
            )

        if self.conditions:
            for handler, argument in self.conditions.items():
                handler = handler(
                    value=self.value, argument=argument, context=self.context
                )

                if (error := handler.handle()):
                    self._condition_errors.append(error)

                    if ConditionFlag.BREAK_PIPE_LOOP_ON_ERROR in handler.FLAGS:
                        break

        if len(self._condition_errors) == 0:
            if self.matches:
                for handler, argument in self.matches.items():
                    handler = handler(
                        value=self.value,
                        argument=argument,
                        context=self.context
                    )

                    if (error := handler.handle()):
                        self._match_errors.append(error)

                        break

            if self.transform and len(self._match_errors) == 0:
                for handler, argument in self.transform.items():
                    self.value = handler(
                        value=self.value,
                        argument=argument,
                        context=self.context
                    ).handle()

        return PipeResult(
            value=self.value,
            condition_errors=self._condition_errors,
            match_errors=self._match_errors
        )
