from functools import wraps
from typing import Any, Callable, Optional

from pipeline.core.pipeline.resources.constants import PipelineHook
from pipeline.core.pipeline.resources.exceptions import PipelineException
from pipeline.core.pipeline.resources.types import (
    PipelineHookFunc, PipelinePipeConfig
)
from pipeline.handlers.condition_handler.resources.types import ConditionErrors


class Pipeline:
    pre_hook: Optional[PipelineHookFunc] = None
    post_hook: Optional[PipelineHookFunc] = None

    handle_errors: Optional[Callable[[dict[str, ConditionErrors]], None]] = None

    def __init__(self, **pipes_config: PipelinePipeConfig) -> None:
        self.pipes_config: dict[str, PipelinePipeConfig] = pipes_config

        self._errors: dict[str, ConditionErrors] = {}

    def run(self, data: dict) -> Optional[dict[str, ConditionErrors]]:
        from pipeline.core.pipe.pipe import Pipe

        context: dict = data

        for field, pipe_config in self.pipes_config.items():
            value = data.get(field, None)

            def hook_set_value(new_value):
                nonlocal value

                value = new_value

                return new_value

            if self.pre_hook:
                self.pre_hook(
                    PipelineHook(
                        field=field,
                        value=value,
                        set_value=hook_set_value,
                        pipe_config=pipe_config
                    )
                )

            if isinstance(value, dict):
                context = value

            pipe: Pipe = Pipe(value=value, **pipe_config, context=context)

            value, condition_errors, match_errors = pipe.run()

            if self.post_hook:
                self.post_hook(
                    PipelineHook(
                        field=field,
                        value=value,
                        set_value=hook_set_value,
                        pipe_config=pipe_config
                    )
                )

            data[field] = value

            if condition_errors or match_errors:
                self._errors[field] = [*condition_errors, *match_errors]

        if self.handle_errors:
            self.handle_errors(self._errors)

        return self._errors or None

    def __call__(self, func: Any) -> Any:
        @wraps(func)
        def wrapper(*args, **kwargs):
            errors = self.run(data=kwargs)

            if errors and not self.handle_errors:
                raise PipelineException(errors)

            return func(*args, **kwargs)

        return wrapper
