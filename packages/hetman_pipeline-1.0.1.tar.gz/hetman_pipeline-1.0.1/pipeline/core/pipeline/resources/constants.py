from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from pipeline.core.pipeline.resources.types import PipelinePipeConfig


@dataclass
class PipelineHook:
    field: Any

    value: Any
    set_value: Callable[[Any], Any]

    pipe_config: PipelinePipeConfig
