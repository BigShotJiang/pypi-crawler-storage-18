from typing import Callable, NotRequired, TypedDict

from pipeline.core.pipe.resources.types import (
    PipeConditions, PipeMatches, PipeMetadata, PipeTransform
)
from pipeline.core.pipeline.resources.constants import PipelineHook


class PipelinePipeConfig(TypedDict):
    type: type

    conditions: NotRequired[PipeConditions]
    matches: NotRequired[PipeMatches]
    transform: NotRequired[PipeTransform]

    optional: NotRequired[bool]

    metadata: NotRequired[PipeMetadata]


PipelineHookFunc = Callable[[PipelineHook], None]
