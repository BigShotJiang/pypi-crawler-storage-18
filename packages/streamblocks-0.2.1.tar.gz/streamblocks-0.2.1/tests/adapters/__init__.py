"""Tests for stream adapters."""
