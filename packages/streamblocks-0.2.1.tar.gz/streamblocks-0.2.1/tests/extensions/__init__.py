"""Tests for extensions."""
