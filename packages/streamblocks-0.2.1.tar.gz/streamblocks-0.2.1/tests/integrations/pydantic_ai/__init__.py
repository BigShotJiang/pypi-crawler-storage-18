"""Tests for PydanticAI integration."""
