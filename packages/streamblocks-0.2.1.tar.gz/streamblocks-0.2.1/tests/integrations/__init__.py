"""Tests for integrations."""
