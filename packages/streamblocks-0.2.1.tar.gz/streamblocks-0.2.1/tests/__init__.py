"""Tests for StreamBlocks."""
