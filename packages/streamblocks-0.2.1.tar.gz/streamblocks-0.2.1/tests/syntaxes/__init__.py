"""Tests for syntaxes module."""
