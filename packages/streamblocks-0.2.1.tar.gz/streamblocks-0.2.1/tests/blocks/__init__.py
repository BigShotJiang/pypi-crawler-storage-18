"""Tests for block types."""
