"""StreamBlocks examples package."""
