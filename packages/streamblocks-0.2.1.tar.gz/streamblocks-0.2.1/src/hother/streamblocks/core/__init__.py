"""Core components for StreamBlocks."""
