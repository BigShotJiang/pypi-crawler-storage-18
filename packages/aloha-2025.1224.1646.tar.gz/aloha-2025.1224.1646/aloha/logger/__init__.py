__all__ = ("LOG", "get_logger")

from .logger import get_logger
from ..settings import SETTINGS

LOG = get_logger(
    level=SETTINGS.config.get('deploy', {}).get('log_level', 10),  # 10 = logging.DEBUG
    # logger_name='default',
)
