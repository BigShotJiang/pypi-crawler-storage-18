def calculation(x, y):
    """计算两个数的和

    Args:
        x (int | float): 第一个数字
        y (int | float): 第二个数字

    Returns:
        int | float: 两数之和
    """
    return x + y
