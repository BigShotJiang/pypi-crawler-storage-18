"""Version information for OpenDraft."""

__version__ = "1.4.1"
__version_info__ = tuple(int(i) for i in __version__.split(".") if i.isdigit())
