"""Public exports for pythehagueparking."""

from importlib.metadata import PackageNotFoundError, version

from .api import ParkerenDenHaagAPI
from .auth import Auth
from .exceptions import (
    AuthError,
    ParkingConnectionError,
    ParseError,
    PyTheHagueParkingError,
    RateLimitError,
)
from .models import Account, Favorite, Reservation, Zone

__all__ = [
    "Auth",
    "ParkerenDenHaagAPI",
    "Account",
    "Favorite",
    "Reservation",
    "Zone",
    "AuthError",
    "ParkingConnectionError",
    "PyTheHagueParkingError",
    "ParseError",
    "RateLimitError",
    "__version__",
]

try:
    __version__ = version("pythehagueparking")
except PackageNotFoundError:
    __version__ = "0.0.0"
