"""Raw data models for the Parkeren Den Haag API."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, cast

from aiohttp import ClientResponse

from .exceptions import ParseError

if TYPE_CHECKING:
    from .auth import Auth


class BaseModel:
    """Base model storing raw API data."""

    def __init__(self, raw_data: Mapping[str, Any], auth: Auth) -> None:
        self.raw_data = raw_data
        self.auth = auth


class Zone(BaseModel):
    """Parking zone information."""

    @property
    def id(self) -> str | int | None:
        """Return the zone identifier."""
        return cast(str | int | None, self.raw_data["id"])

    @property
    def name(self) -> str | None:
        """Return the zone name."""
        return cast(str | None, self.raw_data["name"])

    @property
    def start_time(self) -> str | None:
        """Return the zone start time."""
        return cast(str | None, self.raw_data["start_time"])

    @property
    def end_time(self) -> str | None:
        """Return the zone end time."""
        return cast(str | None, self.raw_data["end_time"])


class Account(BaseModel):
    """Account information."""

    @property
    def debit_minutes(self) -> int | str | None:
        """Return the account debit minutes."""
        return cast(int | str | None, self.raw_data["debit_minutes"])

    @property
    def reservation_count(self) -> int | str | None:
        """Return the account reservation count."""
        return cast(int | str | None, self.raw_data["reservation_count"])

    @property
    def zone(self) -> Zone | None:
        """Return the zone object when available."""
        zone_data = self.raw_data["zone"]
        if isinstance(zone_data, Mapping):
            return Zone(zone_data, self.auth)
        return None


class Reservation(BaseModel):
    """Reservation information."""

    @property
    def id(self) -> int | str | None:
        """Return the reservation identifier."""
        return cast(int | str | None, self.raw_data["id"])

    @property
    def license_plate(self) -> str | None:
        """Return the reservation license plate."""
        return cast(str | None, self.raw_data["license_plate"])

    @property
    def name(self) -> str | None:
        """Return the reservation name."""
        return cast(str | None, self.raw_data["name"])

    @property
    def start_time(self) -> str | None:
        """Return the reservation start time."""
        return cast(str | None, self.raw_data["start_time"])

    @property
    def end_time(self) -> str | None:
        """Return the reservation end time."""
        return cast(str | None, self.raw_data["end_time"])

    async def async_update(self, *, end_time: str) -> Reservation:
        """Update this reservation."""
        reservation_id = self.id
        if reservation_id is None:
            raise ParseError("Reservation id is missing")
        payload = {"end_time": end_time}
        response = await self.auth.request(
            "PATCH", f"/api/reservation/{reservation_id}", json=payload
        )
        try:
            data = await _json_from_response(response)
            self.raw_data = _ensure_mapping(data, "reservation")
        finally:
            response.release()
        return self

    async def async_delete(self) -> None:
        """Delete this reservation."""
        reservation_id = self.id
        if reservation_id is None:
            raise ParseError("Reservation id is missing")
        response = await self.auth.request(
            "DELETE", f"/api/reservation/{reservation_id}"
        )
        try:
            response.raise_for_status()
        finally:
            response.release()


class Favorite(BaseModel):
    """Favorite vehicle information."""

    @property
    def id(self) -> int | str | None:
        """Return the favorite identifier."""
        return cast(int | str | None, self.raw_data["id"])

    @property
    def license_plate(self) -> str | None:
        """Return the favorite license plate."""
        return cast(str | None, self.raw_data["license_plate"])

    @property
    def name(self) -> str | None:
        """Return the favorite name."""
        return cast(str | None, self.raw_data["name"])

    async def async_update(self, *, name: str, license_plate: str) -> Favorite:
        """Update this favorite."""
        favorite_id = self.id
        if favorite_id is None:
            raise ParseError("Favorite id is missing")
        payload = {"name": name, "license_plate": license_plate}
        response = await self.auth.request(
            "PATCH", f"/api/favorite/{favorite_id}", json=payload
        )
        try:
            if response.status == 405:
                response.release()
                response = await self.auth.request(
                    "PUT", f"/api/favorite/{favorite_id}", json=payload
                )
            data = await _json_from_response(response)
            self.raw_data = _ensure_mapping(data, "favorite")
        finally:
            response.release()
        return self

    async def async_delete(self) -> None:
        """Delete this favorite."""
        favorite_id = self.id
        if favorite_id is None:
            raise ParseError("Favorite id is missing")
        response = await self.auth.request("DELETE", f"/api/favorite/{favorite_id}")
        try:
            response.raise_for_status()
        finally:
            response.release()


async def _json_from_response(response: ClientResponse) -> Any:
    response.raise_for_status()
    try:
        return await response.json(content_type=None)
    except json.JSONDecodeError as err:
        raise ParseError("Response body is not valid JSON") from err


def _ensure_mapping(data: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(data, Mapping):
        raise ParseError(f"Expected {label} object")
    return data
