"""API entrypoints for the Parkeren Den Haag service."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from aiohttp import ClientResponse

from .auth import Auth
from .exceptions import ParseError
from .models import Account, Favorite, Reservation


class ParkerenDenHaagAPI:
    """Root API wrapper for Parkeren Den Haag."""

    def __init__(self, auth: Auth) -> None:
        self._auth = auth

    @property
    def auth(self) -> Auth:
        """Return the authentication helper."""
        return self._auth

    async def async_get_account(self) -> Account:
        """Fetch account details."""
        response = await self._auth.request("GET", "/api/account/0")
        try:
            data = await _async_json(response)
        finally:
            response.release()
        return Account(_ensure_mapping(data, "account"), self._auth)

    async def async_get_balance_minutes(self) -> int | str | None:
        """Return account debit minutes."""
        account = await self.async_get_account()
        return account.debit_minutes

    async def async_list_reservations(self) -> list[Reservation]:
        """List active reservations."""
        response = await self._auth.request("GET", "/api/reservation")
        try:
            data = await _async_json(response)
        finally:
            response.release()
        items = _ensure_list(data, "reservations")
        return [
            Reservation(_ensure_mapping(item, "reservation"), self._auth)
            for item in items
        ]

    async def async_create_reservation(
        self,
        *,
        name: str | None,
        license_plate: str,
        start_time: str,
        end_time: str,
    ) -> Reservation:
        """Create a reservation."""
        payload = {
            "id": None,
            "name": name,
            "license_plate": license_plate,
            "start_time": start_time,
            "end_time": end_time,
        }
        response = await self._auth.request("POST", "/api/reservation", json=payload)
        try:
            data = await _async_json(response)
        finally:
            response.release()
        return Reservation(_ensure_mapping(data, "reservation"), self._auth)

    async def async_list_favorites(self) -> list[Favorite]:
        """List favorites."""
        response = await self._auth.request(
            "GET",
            "/api/favorite",
            headers={"x-data-limit": "100", "x-data-offset": "0"},
        )
        try:
            data = await _async_json(response)
        finally:
            response.release()
        items = _ensure_list(data, "favorites")
        return [
            Favorite(_ensure_mapping(item, "favorite"), self._auth) for item in items
        ]

    async def async_create_favorite(self, *, name: str, license_plate: str) -> Favorite:
        """Create a favorite."""
        payload = {"name": name, "license_plate": license_plate}
        response = await self._auth.request("POST", "/api/favorite", json=payload)
        try:
            data = await _async_json(response)
        finally:
            response.release()
        return Favorite(_ensure_mapping(data, "favorite"), self._auth)


def _ensure_mapping(data: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(data, Mapping):
        raise ParseError(f"Expected {label} object")
    return data


def _ensure_list(data: Any, label: str) -> list[Any]:
    if not isinstance(data, list):
        raise ParseError(f"Expected {label} list")
    return data


async def _async_json(response: ClientResponse) -> Any:
    response.raise_for_status()
    text = await response.text()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError as err:
        raise ParseError("Response body is not valid JSON") from err
