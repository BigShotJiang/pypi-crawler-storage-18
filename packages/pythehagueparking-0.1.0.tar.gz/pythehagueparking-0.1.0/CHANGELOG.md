# Changelog

This project follows Keep a Changelog and Semantic Versioning.

## Unreleased

- Added `RateLimitError` with `Retry-After` support
- Added Auth + API layers with async-prefixed methods
- Added raw models with action methods
- Added `ParseError` for unexpected payloads
- Added User-Agent header with caching
- Added `__version__` export
- Added CI `twine check`, Issues link, and wheel metadata files
- Removed client-owned sessions and input validation
- Removed `ResponseError` in favor of `ClientResponseError`
- Removed API delete methods in favor of model actions

## 0.1.0

- Initial async client with account, reservation, and favorite endpoints
- Cookie-based login with retry on authentication errors
- Dataclass models and typed exceptions

Release checklist

- Update version and changelog
- Run `pytest`, `ruff check .`, and `mypy`
- Run `python -m build`
- Run `python -m twine check dist/*`
- Publish to PyPI
