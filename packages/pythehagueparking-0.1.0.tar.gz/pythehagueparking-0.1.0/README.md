# pythehagueparking

[![CI](https://github.com/sir-Unknown/pythehagueparking/actions/workflows/ci.yml/badge.svg)](https://github.com/sir-Unknown/pythehagueparking/actions/workflows/ci.yml)
[![PyPI](https://badge.fury.io/py/pythehagueparking.svg)](https://badge.fury.io/py/pythehagueparking)
[![Python versions](https://img.shields.io/pypi/pyversions/pythehagueparking.svg)](https://pypi.org/project/pythehagueparking/)
[![Issues](https://img.shields.io/github/issues/sir-Unknown/pythehagueparking.svg)](https://github.com/sir-Unknown/pythehagueparking/issues)
[![Security policy](https://img.shields.io/badge/security-policy-blue.svg)](https://github.com/sir-Unknown/pythehagueparking/security/policy)

Async client library for the Parkeren Den Haag API, designed for Home Assistant
custom integrations but usable in any asyncio project.

## Features

- Async-only HTTP calls via aiohttp
- Auth helper with automatic re-login on 401/403
- Raw models with properties and action methods
- Caller-owned aiohttp session (no session management in the library)

## Installation

```bash
python -m pip install pythehagueparking
```

## Quick start

```python
from aiohttp import ClientSession

from pythehagueparking import Auth, ParkerenDenHaagAPI

async def main() -> None:
    async with ClientSession() as session:
        auth = Auth(session, username="user", password="pass")
        api = ParkerenDenHaagAPI(auth)
        account = await api.async_get_account()
        reservations = await api.async_list_reservations()
        favorites = await api.async_list_favorites()
        print(account, reservations, favorites)
```

## API reference

API methods:

- `async_get_account() -> Account`: Fetch account details including `zone`.
- `async_get_balance_minutes() -> Any`: Return `Account.debit_minutes`.
- `async_list_reservations() -> list[Reservation]`: List active reservations.
- `async_create_reservation(name, license_plate, start_time, end_time) -> Reservation`: Create a reservation.
- `async_list_favorites() -> list[Favorite]`: List favorites.
- `async_create_favorite(name, license_plate) -> Favorite`: Create a favorite.

Model actions:

- `Reservation.async_update(end_time) -> Reservation`
- `Reservation.async_delete() -> None`
- `Favorite.async_update(name, license_plate) -> Favorite`
- `Favorite.async_delete() -> None`

Example usage:

```python
from aiohttp import ClientSession

from pythehagueparking import Auth, ParkerenDenHaagAPI

async with ClientSession() as session:
    auth = Auth(session, username="user", password="pass")
    api = ParkerenDenHaagAPI(auth)
    account = await api.async_get_account()
    balance = await api.async_get_balance_minutes()
    print(account.zone, balance)
```


```python
from pythehagueparking import __version__

print("pythehagueparking", __version__)
```

```python
from aiohttp import ClientSession

from pythehagueparking import Auth, ParkerenDenHaagAPI

async with ClientSession() as session:
    api = ParkerenDenHaagAPI(Auth(session, "user", "pass"))
    reservations = await api.async_list_reservations()
    created = await api.async_create_reservation(
        name="My Car",
        license_plate="12-AB-34",
        start_time="2025-01-01T10:00:00Z",
        end_time="2025-01-01T12:00:00Z",
    )
    updated = await created.async_update(end_time="2025-01-01T13:00:00Z")
    await updated.async_delete()
```

```python
from aiohttp import ClientSession

from pythehagueparking import Auth, ParkerenDenHaagAPI

async with ClientSession() as session:
    api = ParkerenDenHaagAPI(Auth(session, "user", "pass"))
    favorites = await api.async_list_favorites()
    created = await api.async_create_favorite("My Car", "12-AB-34")
    updated = await created.async_update("My Car", "12-AB-34")
    await updated.async_delete()
```

```python
from aiohttp import ClientSession

from pythehagueparking import Auth, ParkerenDenHaagAPI, RateLimitError

async with ClientSession() as session:
    api = ParkerenDenHaagAPI(Auth(session, "user", "pass"))
    try:
        await api.async_list_reservations()
    except RateLimitError as err:
        print("Retry after:", err.retry_after)
```

## API notes

- Start and end times should be ISO 8601 UTC strings ending with `Z`.
- The library does not normalize or validate time values.
- Favorites listing always requests `x-data-limit=100` and `x-data-offset=0`.

## Session ownership

- You always pass your own `aiohttp.ClientSession`.
- The library never creates or closes sessions.

## Model return types

- Public methods return models that wrap raw API payloads.
- Each model exposes a `raw_data` mapping plus property accessors.
- No automatic type conversions are applied.

Model fields exposed:

- `Account`: `debit_minutes`, `reservation_count`, `zone`
- `Zone`: `id`, `name`, `start_time`, `end_time`
- `Reservation`: `id`, `license_plate`, `name`, `start_time`, `end_time`
- `Favorite`: `id`, `license_plate`, `name`

## Compatibility notes

- Python 3.13.2+ is required, matching Home Assistant 2025.12.
- Async-only (`aiohttp`); no synchronous wrapper is provided.

## Error handling

- `AuthError` for authentication failures or expired sessions
- `ParkingConnectionError` for network errors and timeouts
- `RateLimitError` for HTTP 429 responses (see `retry_after`)
- `ParseError` for unexpected response payloads
- `aiohttp.ClientResponseError` for HTTP status errors (`raise_for_status`)

## Development

```bash
python -m pip install -e '.[test,dev]'
pytest
ruff check .
mypy
```

## License

MIT License. See `LICENSE` and `NOTICE`.

## Support

For questions or issues, open a GitHub issue:
https://github.com/sir-Unknown/pythehagueparking/issues
