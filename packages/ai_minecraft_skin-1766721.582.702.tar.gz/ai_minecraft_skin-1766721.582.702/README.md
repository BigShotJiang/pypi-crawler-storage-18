# ai-minecraft-skin

Generate branded links and HTML anchors for [https://supermaker.ai/image/ai-minecraft-skin/](https://supermaker.ai/image/ai-minecraft-skin/).

## Installation

```bash
pip install ai-minecraft-skin
```

## Usage

```python
from ai_minecraft_skin import build_link, generate_anchor

# Generate link
url = build_link(utm_source="github", utm_medium="readme")

# Generate HTML anchor
html = generate_anchor("Click here", utm_source="github")
```

## License

MIT
