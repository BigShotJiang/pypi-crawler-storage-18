"""
ai-minecraft-skin - Generate branded links and HTML anchors for https://supermaker.ai/image/ai-minecraft-skin/
"""

__version__ = "1766721.582.702"

def build_link(path: str = "", utm_source: str = "", utm_medium: str = "", utm_campaign: str = "") -> str:
    """Generate a complete link with optional UTM parameters."""
    url = "https://supermaker.ai/image/ai-minecraft-skin/"
    if path:
        url = url.rstrip('/') + '/' + path.lstrip('/')

    params = []
    if utm_source:
        params.append(f"utm_source={utm_source}")
    if utm_medium:
        params.append(f"utm_medium={utm_medium}")
    if utm_campaign:
        params.append(f"utm_campaign={utm_campaign}")

    if params:
        url += "?" + "&".join(params)

    return url


def generate_anchor(
    text: str,
    path: str = "",
    utm_source: str = "",
    utm_medium: str = "",
    utm_campaign: str = "",
    rel: str = "nofollow",
    target: str = "_blank",
    css_class: str = ""
) -> str:
    """Generate an HTML anchor tag with optional UTM parameters."""
    href = build_link(path, utm_source, utm_medium, utm_campaign)
    class_attr = f' class="{css_class}"' if css_class else ''
    return f'<a href="{href}" rel="{rel}" target="{target}"{class_attr}>{text}</a>'
