from abc import abstractmethod

from litestar import Response

from evidently.errors import EvidentlyError


class EvidentlyServiceError(EvidentlyError):
    @abstractmethod
    def to_response(self) -> Response:
        raise NotImplementedError


class EntityNotFound(EvidentlyServiceError):
    entity_name: str = ""

    def to_response(self) -> Response:
        return Response(
            status_code=404,
            content={"detail": f"{self.entity_name} not found"},
        )


class ProjectNotFound(EntityNotFound):
    entity_name = "Project"


class OrgNotFound(EntityNotFound):
    entity_name = "Org"


class TeamNotFound(EntityNotFound):
    entity_name = "Team"


class UserNotFound(EntityNotFound):
    entity_name = "User"


class RoleNotFound(EntityNotFound):
    entity_name = "Role"


class SnapshotNotFound(EntityNotFound):
    entity_name = "Snapshot"


class DatasetNotFound(EntityNotFound):
    entity_name = "Dataset"


class ArtifactNotFound(EntityNotFound):
    entity_name = "Artifact"


class ArtifactVersionNotFound(EntityNotFound):
    entity_name = "Artifact version"


class NotEnoughPermissions(EvidentlyServiceError):
    def to_response(self) -> Response:
        return Response(
            status_code=403,
            content={"detail": "Not enough permissions"},
        )


class NotAuthorized(EvidentlyServiceError):
    def to_response(self) -> Response:
        return Response(
            status_code=401,
            content={"detail": "Not authorized"},
        )
