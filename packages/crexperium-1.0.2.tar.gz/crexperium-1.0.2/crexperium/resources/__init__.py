"""Resource modules for Crexperium SDK."""

from .base import BaseResource
from .contacts import ContactsResource
from .deals import DealsResource
from .activities import ActivitiesResource

__all__ = [
    "BaseResource",
    "ContactsResource",
    "DealsResource",
    "ActivitiesResource",
]
