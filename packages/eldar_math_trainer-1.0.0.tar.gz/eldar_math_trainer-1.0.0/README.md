# Eldar Math Trainer

CLI əsaslı riyaziyyat məşq oyunu.

## Quraşdırma
pip install eldar-math-trainer

## İstifadə

```python
from eldar_math_trainer import MathTrainer

game = MathTrainer(level="easy", rounds=5)
game.play()
