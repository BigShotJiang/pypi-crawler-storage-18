from setuptools import setup, find_packages

setup(
    name="eldar-math-trainer",
    version="1.0.0",
    packages=find_packages(),
)
