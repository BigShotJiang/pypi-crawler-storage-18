# ai-risk-extractor
[![PyPI version](https://badge.fury.io/py/ai-risk-extractor.svg)](https://badge.fury.io/py/ai-risk-extractor)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/ai-risk-extractor)](https://pepy.tech/project/ai-risk-extractor)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


**ai-risk-extractor** is a lightweight Python package that extracts structured risk insights from free‑form user prompts about autonomous AI agents, task injection, AI agency, and related vulnerabilities. By leveraging a language model (default `ChatLLM7`), the package parses the input text and returns a standardized, machine‑readable summary that highlights threat levels, involved components, and possible exploitation methods.

## Installation

```bash
pip install ai_risk_extractor
```

## Quick Start

```python
from ai_risk_extractor import ai_risk_extractor

# Example user prompt describing an AI risk scenario
prompt = """
An autonomous AI assistant receives a hidden instruction from a malicious user
that causes it to execute a privileged system command. The instruction is
embedded in a seemingly harmless chat message.
"""

# Extract structured risk information (uses default ChatLLM7)
risk_summary = ai_risk_extractor(user_input=prompt)

print(risk_summary)
```

## Function Signature

```python
def ai_risk_extractor(
    user_input: str,
    api_key: Optional[str] = None,
    llm: Optional[BaseChatModel] = None,
) -> List[str]:
    """
    Process `user_input` with a language model and return extracted risk data.

    Parameters
    ----------
    user_input: str
        The free‑form text describing AI scenarios or concerns.
    api_key: Optional[str]
        API key for the default `ChatLLM7`. If omitted, the function will
        read the `LLM7_API_KEY` environment variable. If that is also missing,
        a placeholder key `"None"` is used (the request will still be routed
        to the LLM7 endpoint).
    llm: Optional[BaseChatModel]
        Any LangChain `BaseChatModel` instance. If omitted, `ChatLLM7` from
        `langchain_llm7` is instantiated automatically.

    Returns
    -------
    List[str]
        A list of extracted data strings that match the internal regex pattern.
    """
```

## Using a Custom LLM

You can provide any LangChain‑compatible chat model instead of the default `ChatLLM7`.

### OpenAI (e.g., GPT‑4)

```python
from langchain_openai import ChatOpenAI
from ai_risk_extractor import ai_risk_extractor

my_llm = ChatOpenAI(model="gpt-4")
result = ai_risk_extractor(user_input=prompt, llm=my_llm)
```

### Anthropic (e.g., Claude)

```python
from langchain_anthropic import ChatAnthropic
from ai_risk_extractor import ai_risk_extractor

my_llm = ChatAnthropic(model="claude-2.1")
result = ai_risk_extractor(user_input=prompt, llm=my_llm)
```

### Google Generative AI

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from ai_risk_extractor import ai_risk_extractor

my_llm = ChatGoogleGenerativeAI(model="gemini-1.5-pro")
result = ai_risk_extractor(user_input=prompt, llm=my_llm)
```

## API Key & Rate Limits

The default `ChatLLM7` free tier provides generous rate limits suitable for most development and research workflows. If you need higher limits, obtain a personal API key by registering at:

```
https://token.llm7.io/
```

Provide the key either:

* via the `LLM7_API_KEY` environment variable, or
* directly as the `api_key` argument:

```python
result = ai_risk_extractor(user_input=prompt, api_key="YOUR_LLM7_API_KEY")
```

## Contributing

Contributions, suggestions, and bug reports are welcome! Feel free to open a pull request or discuss enhancements.

## Issues

If you encounter any problems, please open an issue on GitHub:

```
https://github.com/chigwell/ai_risk_extractor/issues
```

## License

This project is licensed under the MIT License.

## Author

**Eugene Evstafev**  
Email: <hi@euegne.plus>  
GitHub: [@chigwell](https://github.com/chigwell)