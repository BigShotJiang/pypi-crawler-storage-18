# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ResizeEngineInstanceRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'engine': 'str',
        'body': 'ResizeEngineInstanceReq'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'engine': 'engine',
        'body': 'body'
    }

    def __init__(self, instance_id=None, engine=None, body=None):
        r"""ResizeEngineInstanceRequest

        The model defined in huaweicloud sdk

        :param instance_id: 实例ID。
        :type instance_id: str
        :param engine: 消息引擎的类型。支持的类型为rabbitmq。
        :type engine: str
        :param body: Body of the ResizeEngineInstanceRequest
        :type body: :class:`huaweicloudsdkrabbitmq.v2.ResizeEngineInstanceReq`
        """
        
        

        self._instance_id = None
        self._engine = None
        self._body = None
        self.discriminator = None

        self.instance_id = instance_id
        self.engine = engine
        if body is not None:
            self.body = body

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ResizeEngineInstanceRequest.

        实例ID。

        :return: The instance_id of this ResizeEngineInstanceRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ResizeEngineInstanceRequest.

        实例ID。

        :param instance_id: The instance_id of this ResizeEngineInstanceRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def engine(self):
        r"""Gets the engine of this ResizeEngineInstanceRequest.

        消息引擎的类型。支持的类型为rabbitmq。

        :return: The engine of this ResizeEngineInstanceRequest.
        :rtype: str
        """
        return self._engine

    @engine.setter
    def engine(self, engine):
        r"""Sets the engine of this ResizeEngineInstanceRequest.

        消息引擎的类型。支持的类型为rabbitmq。

        :param engine: The engine of this ResizeEngineInstanceRequest.
        :type engine: str
        """
        self._engine = engine

    @property
    def body(self):
        r"""Gets the body of this ResizeEngineInstanceRequest.

        :return: The body of this ResizeEngineInstanceRequest.
        :rtype: :class:`huaweicloudsdkrabbitmq.v2.ResizeEngineInstanceReq`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ResizeEngineInstanceRequest.

        :param body: The body of this ResizeEngineInstanceRequest.
        :type body: :class:`huaweicloudsdkrabbitmq.v2.ResizeEngineInstanceReq`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ResizeEngineInstanceRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
