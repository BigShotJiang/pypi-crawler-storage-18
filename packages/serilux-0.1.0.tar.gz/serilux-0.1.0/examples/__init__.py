"""
Serilux examples
"""
