"""Logust benchmarks."""
