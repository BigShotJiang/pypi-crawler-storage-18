"""Logust test suite."""
