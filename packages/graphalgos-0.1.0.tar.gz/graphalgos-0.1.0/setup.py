# setup.py - простой и рабочий

from setuptools import setup, find_packages

setup(
    name="graphalgos",
    version="0.1.0",
    author="Student",
    author_email="student@example.com",
    description="Graph algorithms library",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.7",
    install_requires=["numpy>=1.19.0"],
)
