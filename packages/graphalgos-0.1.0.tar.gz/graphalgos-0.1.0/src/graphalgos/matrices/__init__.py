"""
Модуль матричных операций
"""

from .operations import MatrixOperations

__all__ = ['MatrixOperations']