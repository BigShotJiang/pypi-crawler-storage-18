"""
Модуль матричных операций для графов
"""

import numpy as np
from typing import Tuple

class MatrixOperations:
    """Класс для операций с матрицами"""
    
    @staticmethod
    def identity_matrix(n: int) -> np.ndarray:
        """
        Единичная матрица
        
        Args:
            n: Размер матрицы
            
        Returns:
            Единичная матрица n x n
        """
        return np.eye(n, dtype=float)
    
    @staticmethod
    def zero_matrix(n: int) -> np.ndarray:
        """
        Нулевая матрица
        
        Args:
            n: Размер матрицы
            
        Returns:
            Нулевая матрица n x n
        """
        return np.zeros((n, n), dtype=float)
    
    @staticmethod
    def matrix_power(A: np.ndarray, k: int) -> np.ndarray:
        """
        Возведение матрицы в степень
        
        Args:
            A: Матрица
            k: Степень
            
        Returns:
            A^k
        """
        if k < 0:
            raise ValueError("Степень должна быть неотрицательной")
        elif k == 0:
            return np.eye(A.shape[0])
        elif k == 1:
            return A.copy()
        
        result = np.eye(A.shape[0])
        temp = A.copy()
        
        while k > 0:
            if k % 2 == 1:
                result = result @ temp
            temp = temp @ temp
            k //= 2
        
        return result
    
    @staticmethod
    def count_walks(adj_matrix: np.ndarray, length: int) -> np.ndarray:
        """
        Количество путей заданной длины
        
        Args:
            adj_matrix: Матрица смежности
            length: Длина пути
            
        Returns:
            Матрица количеств путей
        """
        return MatrixOperations.matrix_power(adj_matrix, length)
    
    @staticmethod
    def graph_spectrum(adj_matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Спектр графа (собственные значения и векторы)
        
        Args:
            adj_matrix: Матрица смежности
            
        Returns:
            (собственные значения, собственные векторы)
        """
        eigenvalues, eigenvectors = np.linalg.eig(adj_matrix)
        
        # Сортируем по убыванию модуля
        idx = np.argsort(np.abs(eigenvalues))[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]
        
        return eigenvalues, eigenvectors
    
    @staticmethod
    def laplacian_spectrum(adj_matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Спектр лапласиана
        
        Args:
            adj_matrix: Матрица смежности
            
        Returns:
            (собственные значения, собственные векторы лапласиана)
        """
        n = adj_matrix.shape[0]
        D = np.diag(np.sum(adj_matrix, axis=1))
        L = D - adj_matrix
        
        eigenvalues, eigenvectors = np.linalg.eig(L)
        
        # Сортируем по возрастанию
        idx = np.argsort(eigenvalues)
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]
        
        return eigenvalues, eigenvectors
    
    @staticmethod
    def algebraic_connectivity(adj_matrix: np.ndarray) -> float:
        """
        Алгебраическая связность графа
        
        Args:
            adj_matrix: Матрица смежности
            
        Returns:
            Второе наименьшее собственное значение лапласиана
        """
        eigenvalues, _ = MatrixOperations.laplacian_spectrum(adj_matrix)
        if len(eigenvalues) > 1:
            return eigenvalues[1].real
        return 0.0
    
    @staticmethod
    def is_strongly_connected(adj_matrix: np.ndarray) -> bool:
        """
        Проверка сильной связности
        
        Args:
            adj_matrix: Матрица смежности
            
        Returns:
            True если граф сильно связен
        """
        n = adj_matrix.shape[0]
        
        # Используем транзитивное замыкание
        from ..algorithms.floyd_warshall import FloydWarshall
        closure = FloydWarshall.transitive_closure(adj_matrix)
        
        # Граф сильно связен, если все вершины достижимы из всех
        return np.all(closure == 1)