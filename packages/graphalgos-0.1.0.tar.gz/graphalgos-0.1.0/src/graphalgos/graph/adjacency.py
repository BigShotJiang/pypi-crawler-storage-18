"""
Модуль для работы с матрицами смежности графов
"""

import numpy as np
from typing import List, Tuple, Dict, Optional, Union

class AdjacencyMatrix:
    """Класс для работы с матрицами смежности"""
    
    def __init__(self, matrix: Optional[np.ndarray] = None, 
                 n_vertices: Optional[int] = None):
        """
        Инициализация матрицы смежности
        
        Args:
            matrix: Готовая матрица смежности (n x n)
            n_vertices: Количество вершин для создания нулевой матрицы
        """
        if matrix is not None:
            if matrix.shape[0] != matrix.shape[1]:
                raise ValueError("Матрица должна быть квадратной")
            self.matrix = matrix.astype(float)
            self.n = matrix.shape[0]
        elif n_vertices is not None:
            if n_vertices <= 0:
                raise ValueError("Количество вершин должно быть положительным")
            self.n = n_vertices
            self.matrix = np.zeros((n_vertices, n_vertices), dtype=float)
        else:
            raise ValueError("Укажите матрицу или количество вершин")
    
    @classmethod
    def from_edges(cls, n: int, edges: List[Tuple[int, int, float]], 
                   directed: bool = False):
        """
        Создание матрицы смежности из списка рёбер
        
        Args:
            n: Количество вершин
            edges: Список рёбер [(u, v, weight), ...]
            directed: Ориентированный ли граф
            
        Returns:
            Объект AdjacencyMatrix
        """
        matrix = np.zeros((n, n), dtype=float)
        for u, v, weight in edges:
            if u >= n or v >= n or u < 0 or v < 0:
                raise ValueError(f"Вершины должны быть в диапазоне [0, {n-1}]")
            matrix[u, v] = weight
            if not directed:
                matrix[v, u] = weight
        return cls(matrix)
    
    @classmethod
    def from_dict(cls, graph_dict: Dict[int, List[Tuple[int, float]]]):
        """
        Создание матрицы смежности из словаря смежности
        
        Args:
            graph_dict: {вершина: [(смежная_вершина, вес), ...]}
            
        Returns:
            Объект AdjacencyMatrix
        """
        if not graph_dict:
            raise ValueError("Словарь не может быть пустым")
        
        n = len(graph_dict)
        matrix = np.zeros((n, n), dtype=float)
        
        for u in graph_dict:
            for v, weight in graph_dict[u]:
                if v >= n or v < 0:
                    raise ValueError(f"Вершина {v} вне диапазона [0, {n-1}]")
                matrix[u, v] = weight
        
        return cls(matrix)
    
    def add_edge(self, u: int, v: int, weight: float = 1.0, 
                 directed: bool = False):
        """
        Добавление ребра
        
        Args:
            u: Начальная вершина (0 <= u < n)
            v: Конечная вершина (0 <= v < n)
            weight: Вес ребра
            directed: Ориентированное ли ребро
        """
        if u >= self.n or v >= self.n or u < 0 or v < 0:
            raise ValueError(f"Вершины должны быть в диапазоне [0, {self.n-1}]")
        
        self.matrix[u, v] = weight
        if not directed:
            self.matrix[v, u] = weight
    
    def remove_edge(self, u: int, v: int, directed: bool = False):
        """
        Удаление ребра
        
        Args:
            u: Начальная вершина
            v: Конечная вершина
            directed: Ориентированное ли ребро
        """
        if u >= self.n or v >= self.n:
            raise ValueError(f"Вершины должны быть в диапазоне [0, {self.n-1}]")
        
        self.matrix[u, v] = 0
        if not directed:
            self.matrix[v, u] = 0
    
    def get_neighbors(self, vertex: int) -> List[Tuple[int, float]]:
        """
        Получение списка смежных вершин
        
        Args:
            vertex: Вершина
            
        Returns:
            Список [(смежная_вершина, вес), ...]
        """
        if vertex >= self.n or vertex < 0:
            raise ValueError(f"Вершина должна быть в диапазоне [0, {self.n-1}]")
        
        neighbors = []
        for v in range(self.n):
            weight = self.matrix[vertex, v]
            if weight != 0:
                neighbors.append((v, weight))
        return neighbors
    
    def get_degree(self, vertex: int, directed: bool = False) -> int:
        """
        Степень вершины
        
        Args:
            vertex: Вершина
            directed: Для ориентированного графа
            
        Returns:
            Степень вершины
        """
        if vertex >= self.n or vertex < 0:
            raise ValueError(f"Вершина должна быть в диапазоне [0, {self.n-1}]")
        
        if directed:
            # Для ориентированного: полустепень исхода + полустепень захода
            out_degree = np.count_nonzero(self.matrix[vertex])
            in_degree = np.count_nonzero(self.matrix[:, vertex])
            return out_degree + in_degree
        else:
            return np.count_nonzero(self.matrix[vertex])
    
    def is_connected(self, u: int, v: int) -> bool:
        """
        Проверка наличия ребра между вершинами
        
        Args:
            u: Первая вершина
            v: Вторая вершина
            
        Returns:
            True если есть ребро, иначе False
        """
        if u >= self.n or v >= self.n or u < 0 or v < 0:
            return False
        return self.matrix[u, v] != 0
    
    def to_incidence_matrix(self) -> np.ndarray:
        """
        Преобразование в матрицу инцидентности
        
        Returns:
            Матрица инцидентности (n x m)
        """
        edges = []
        for i in range(self.n):
            for j in range(i, self.n):  # Верхний треугольник для неориентированного
                if self.matrix[i, j] != 0:
                    edges.append((i, j, self.matrix[i, j]))
        
        m = len(edges)
        incidence = np.zeros((self.n, m), dtype=float)
        
        for idx, (u, v, weight) in enumerate(edges):
            incidence[u, idx] = weight
            if u != v:  # Если не петля
                incidence[v, idx] = weight
        
        return incidence
    
    def to_laplacian_matrix(self) -> np.ndarray:
        """
        Лапласиан графа L = D - A
        
        Returns:
            Лапласиан
        """
        D = np.diag(np.sum(self.matrix, axis=1))
        return D - self.matrix
    
    def is_symmetric(self) -> bool:
        """
        Проверка симметричности матрицы
        
        Returns:
            True если матрица симметрична
        """
        return np.allclose(self.matrix, self.matrix.T)
    
    def is_weighted(self) -> bool:
        """
        Проверка, является ли граф взвешенным
        
        Returns:
            True если есть рёбра с весом не равным 1
        """
        non_zero = self.matrix[self.matrix != 0]
        return not np.allclose(non_zero, 1.0)
    
    def copy(self) -> 'AdjacencyMatrix':
        """
        Создание копии матрицы
        
        Returns:
            Копия AdjacencyMatrix
        """
        return AdjacencyMatrix(self.matrix.copy())
    
    def __str__(self) -> str:
        """Строковое представление"""
        return f"AdjacencyMatrix(n={self.n}):\n{self.matrix}"
    
    def __repr__(self) -> str:
        """Представление для отладки"""
        return f"AdjacencyMatrix(n={self.n})"