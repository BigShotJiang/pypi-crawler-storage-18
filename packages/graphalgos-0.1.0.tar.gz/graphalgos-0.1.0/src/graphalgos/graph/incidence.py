"""
Модуль для работы с матрицами инцидентности
"""

import numpy as np
from typing import List, Tuple

class IncidenceMatrix:
    """Класс для работы с матрицами инцидентности"""
    
    def __init__(self, matrix: np.ndarray):
        """
        Инициализация матрицы инцидентности
        
        Args:
            matrix: Матрица инцидентности (вершины x рёбра)
        """
        self.matrix = matrix.astype(float)
        self.n_vertices = matrix.shape[0]
        self.n_edges = matrix.shape[1]
    
    @classmethod
    def from_adjacency(cls, adj_matrix: np.ndarray):
        """
        Создание матрицы инцидентности из матрицы смежности
        
        Args:
            adj_matrix: Матрица смежности
            
        Returns:
            Объект IncidenceMatrix
        """
        n = adj_matrix.shape[0]
        edges = []
        
        # Собираем рёбра (только верхний треугольник для неориентированного)
        for i in range(n):
            for j in range(i, n):
                if adj_matrix[i, j] != 0:
                    edges.append((i, j, adj_matrix[i, j]))
        
        m = len(edges)
        incidence = np.zeros((n, m), dtype=float)
        
        for idx, (u, v, weight) in enumerate(edges):
            incidence[u, idx] = weight
            if u != v:  # Если не петля
                incidence[v, idx] = weight
        
        return cls(incidence)
    
    def to_adjacency_matrix(self) -> np.ndarray:
        """
        Преобразование в матрицу смежности
        
        Returns:
            Матрица смежности
        """
        n = self.n_vertices
        adj = np.zeros((n, n), dtype=float)
        
        for edge_idx in range(self.n_edges):
            edge_column = self.matrix[:, edge_idx]
            vertices = np.where(edge_column != 0)[0]
            
            if len(vertices) == 1:  # Петля
                v = vertices[0]
                adj[v, v] = edge_column[v]
            elif len(vertices) == 2:  # Обычное ребро
                u, v = vertices[0], vertices[1]
                weight = edge_column[u]
                adj[u, v] = weight
                adj[v, u] = weight
        
        return adj
    
    def get_incident_edges(self, vertex: int) -> List[int]:
        """
        Получение списка инцидентных рёбер для вершины
        
        Args:
            vertex: Вершина
            
        Returns:
            Список индексов рёбер
        """
        if vertex >= self.n_vertices or vertex < 0:
            raise ValueError(f"Вершина должна быть в диапазоне [0, {self.n_vertices-1}]")
        
        incident = []
        for edge_idx in range(self.n_edges):
            if self.matrix[vertex, edge_idx] != 0:
                incident.append(edge_idx)
        return incident
    
    def __str__(self) -> str:
        """Строковое представление"""
        return f"IncidenceMatrix(вершины={self.n_vertices}, рёбра={self.n_edges}):\n{self.matrix}"