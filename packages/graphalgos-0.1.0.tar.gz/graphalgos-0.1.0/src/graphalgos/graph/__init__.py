"""
Модуль для работы с графами
"""

from .adjacency import AdjacencyMatrix
from .incidence import IncidenceMatrix

__all__ = ['AdjacencyMatrix', 'IncidenceMatrix']