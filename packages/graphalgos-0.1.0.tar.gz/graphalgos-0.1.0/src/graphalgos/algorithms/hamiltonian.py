"""
Модуль для поиска Гамильтонова цикла и пути
"""

import numpy as np
from typing import List, Optional, Tuple
import itertools

class HamiltonianSolver:
    """Класс для решения Гамильтоновых задач"""
    
    @staticmethod
    def backtracking_hamiltonian(adj_matrix: np.ndarray, 
                                start: int = 0) -> Optional[List[int]]:
        """
        Поиск Гамильтонова цикла методом обратного отслеживания
        
        Args:
            adj_matrix: Матрица смежности
            start: Стартовая вершина
            
        Returns:
            Гамильтонов цикл или None
        """
        n = adj_matrix.shape[0]
        if n == 0:
            return None
        
        # Проверка корректности start
        if start < 0 or start >= n:
            start = 0
        
        path = [-1] * n
        path[0] = start
        
        def is_safe(v: int, pos: int) -> bool:
            """Можно ли добавить вершину v на позицию pos"""
            # Проверяем ребро
            if adj_matrix[path[pos-1], v] == 0:
                return False
            
            # Проверяем, не использована ли вершина
            return v not in path[:pos]
        
        def hamiltonian_util(pos: int) -> bool:
            """Рекурсивный поиск"""
            if pos == n:
                # Проверяем ребро от последней к первой
                return adj_matrix[path[pos-1], path[0]] != 0
            
            for v in range(n):
                if v != start and is_safe(v, pos):
                    path[pos] = v
                    if hamiltonian_util(pos + 1):
                        return True
                    path[pos] = -1
            
            return False
        
        if hamiltonian_util(1):
            # Добавляем стартовую вершину в конец для замыкания цикла
            return path + [path[0]]
        return None
    
    @staticmethod
    def dirac_theorem_check(adj_matrix: np.ndarray) -> bool:
        """
        Проверка теоремы Дирака
        
        Returns:
            True если граф гамильтонов по теореме Дирака
        """
        n = adj_matrix.shape[0]
        if n < 3:
            return False
        
        for i in range(n):
            degree = np.count_nonzero(adj_matrix[i])
            if degree < n / 2:
                return False
        
        return True
    
    @staticmethod
    def ore_theorem_check(adj_matrix: np.ndarray) -> bool:
        """
        Проверка теоремы Оре
        
        Returns:
            True если граф гамильтонов по теореме Оре
        """
        n = adj_matrix.shape[0]
        if n < 3:
            return False
        
        for i in range(n):
            for j in range(i+1, n):
                if adj_matrix[i, j] == 0:  # Не смежные
                    deg_i = np.count_nonzero(adj_matrix[i])
                    deg_j = np.count_nonzero(adj_matrix[j])
                    if deg_i + deg_j < n:
                        return False
        
        return True
    
    @staticmethod
    def find_hamiltonian_path(adj_matrix: np.ndarray) -> Optional[List[int]]:
        """
        Поиск Гамильтонова пути
        
        Returns:
            Гамильтонов путь или None
        """
        n = adj_matrix.shape[0]
        
        for start in range(n):
            visited = [False] * n
            path = []
            
            def dfs(current: int) -> bool:
                visited[current] = True
                path.append(current)
                
                if len(path) == n:
                    return True
                
                for neighbor in range(n):
                    if adj_matrix[current, neighbor] != 0 and not visited[neighbor]:
                        if dfs(neighbor):
                            return True
                
                visited[current] = False
                path.pop()
                return False
            
            if dfs(start):
                return path
        
        return None
    
    @staticmethod
    def tsp_bruteforce(distance_matrix: np.ndarray) -> Tuple[List[int], float]:
        """
        Задача коммивояжера полным перебором
        
        Args:
            distance_matrix: Матрица расстояний
            
        Returns:
            (оптимальный маршрут, минимальное расстояние)
        """
        n = distance_matrix.shape[0]
        if n == 0:
            return [], 0.0
        elif n == 1:
            return [0, 0], 0.0
        
        vertices = list(range(1, n))  # Все вершины кроме стартовой
        min_path = None
        min_distance = float('inf')
        
        for permutation in itertools.permutations(vertices):
            path = [0] + list(permutation) + [0]
            distance = 0
            
            for i in range(len(path) - 1):
                u, v = path[i], path[i+1]
                distance += distance_matrix[u, v]
            
            if distance < min_distance:
                min_distance = distance
                min_path = path
        
        return min_path, min_distance