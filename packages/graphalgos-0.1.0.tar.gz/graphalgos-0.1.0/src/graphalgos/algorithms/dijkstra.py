"""
Модуль алгоритма Дейкстры
"""

import numpy as np
from typing import List, Tuple, Optional
import heapq

class Dijkstra:
    """Класс для алгоритма Дейкстры"""
    
    @staticmethod
    def dijkstra(adj_matrix: np.ndarray, start: int) -> Tuple[List[float], List[Optional[int]]]:
        """
        Алгоритм Дейкстры
        
        Args:
            adj_matrix: Матрица смежности
            start: Стартовая вершина
            
        Returns:
            (расстояния, предшественники)
        """
        n = adj_matrix.shape[0]
        if start < 0 or start >= n:
            raise ValueError(f"Стартовая вершина должна быть в диапазоне [0, {n-1}]")
        
        # Инициализация
        dist = [float('inf')] * n
        prev = [None] * n
        dist[start] = 0
        
        # Приоритетная очередь
        pq = [(0, start)]
        
        while pq:
            current_dist, u = heapq.heappop(pq)
            
            # Если нашли более короткий путь, пропускаем
            if current_dist > dist[u]:
                continue
            
            # Проверяем всех соседей
            for v in range(n):
                weight = adj_matrix[u, v]
                if weight > 0:  # Есть ребро
                    new_dist = dist[u] + weight
                    if new_dist < dist[v]:
                        dist[v] = new_dist
                        prev[v] = u
                        heapq.heappush(pq, (new_dist, v))
        
        return dist, prev
    
    @staticmethod
    def get_shortest_path(prev: List[Optional[int]], target: int) -> Optional[List[int]]:
        """
        Восстановление кратчайшего пути
        
        Args:
            prev: Список предшественников
            target: Целевая вершина
            
        Returns:
            Кратчайший путь или None
        """
        if prev[target] is None and target != 0:  # Если нет пути
            return None
        
        path = []
        current = target
        
        while current is not None:
            path.append(current)
            current = prev[current]
        
        return list(reversed(path))
    
    @staticmethod
    def single_source_all_targets(adj_matrix: np.ndarray, start: int) -> List[Optional[List[int]]]:
        """
        Кратчайшие пути от стартовой вершины ко всем остальным
        
        Args:
            adj_matrix: Матрица смежности
            start: Стартовая вершина
            
        Returns:
            Список кратчайших путей
        """
        dist, prev = Dijkstra.dijkstra(adj_matrix, start)
        n = len(dist)
        
        paths = []
        for target in range(n):
            if dist[target] == float('inf'):
                paths.append(None)
            else:
                paths.append(Dijkstra.get_shortest_path(prev, target))
        
        return paths