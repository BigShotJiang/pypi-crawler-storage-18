"""
Модуль алгоритма Флойда-Уоршелла
"""

import numpy as np
from typing import List, Optional, Tuple

class FloydWarshall:
    """Класс для алгоритма Флойда-Уоршелла"""
    
    @staticmethod
    def floyd_warshall(adj_matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Алгоритм Флойда-Уоршелла
        
        Args:
            adj_matrix: Матрица смежности
            
        Returns:
            (матрица расстояний, матрица предшественников)
        """
        n = adj_matrix.shape[0]
        
        # Инициализация
        dist = adj_matrix.astype(float).copy()
        next_hop = np.full((n, n), -1, dtype=int)
        
        # Заменяем 0 на бесконечность (кроме диагонали)
        for i in range(n):
            for j in range(n):
                if i != j and dist[i, j] == 0:
                    dist[i, j] = float('inf')
                elif dist[i, j] != 0:
                    next_hop[i, j] = j
                elif i == j:
                    next_hop[i, j] = i
        
        # Основной алгоритм
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    if dist[i, j] > dist[i, k] + dist[k, j]:
                        dist[i, j] = dist[i, k] + dist[k, j]
                        next_hop[i, j] = next_hop[i, k]
        
        return dist, next_hop
    
    @staticmethod
    def reconstruct_path(next_hop: np.ndarray, start: int, end: int) -> Optional[List[int]]:
        """
        Восстановление пути
        
        Args:
            next_hop: Матрица предшественников
            start: Начальная вершина
            end: Конечная вершина
            
        Returns:
            Кратчайший путь или None
        """
        if next_hop[start, end] == -1:
            return None
        
        path = [start]
        current = start
        
        while current != end:
            current = next_hop[current, end]
            if current == -1:
                return None
            path.append(current)
        
        return path
    
    @staticmethod
    def transitive_closure(adj_matrix: np.ndarray) -> np.ndarray:
        """
        Транзитивное замыкание графа
        
        Args:
            adj_matrix: Матрица смежности (бинарная)
            
        Returns:
            Матрица достижимости
        """
        n = adj_matrix.shape[0]
        closure = (adj_matrix != 0).astype(int)
        
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    closure[i, j] = closure[i, j] or (closure[i, k] and closure[k, j])
        
        return closure
    
    @staticmethod
    def find_center(dist_matrix: np.ndarray) -> int:
        """
        Центр графа (вершина с минимальным эксцентриситетом)
        
        Args:
            dist_matrix: Матрица расстояний
            
        Returns:
            Индекс центральной вершины
        """
        n = dist_matrix.shape[0]
        eccentricities = []
        
        for i in range(n):
            # Игнорируем бесконечности
            finite_dists = [d for d in dist_matrix[i] if d != float('inf')]
            if finite_dists:
                eccentricities.append(max(finite_dists))
            else:
                eccentricities.append(float('inf'))
        
        if all(e == float('inf') for e in eccentricities):
            return 0
        
        return int(np.argmin(eccentricities))