import numpy as np
from graphalgos.graph.adjacency import AdjacencyMatrix
from graphalgos.algorithms.hamiltonian import HamiltonianSolver
from graphalgos.algorithms.floyd_warshall import FloydWarshall

# Создание графа
adj_matrix = np.array([
    [0, 1, 0, 1, 0],
    [1, 0, 1, 1, 1],
    [0, 1, 0, 0, 1],
    [1, 1, 0, 0, 1],
    [0, 1, 1, 1, 0]
])

# Поиск Гамильтонова цикла
solver = HamiltonianSolver()
cycle = solver.backtracking_hamiltonian(adj_matrix)
print(f"Гамильтонов цикл: {cycle}")

# Поиск кратчайших путей
dist, next_hop = FloydWarshall.floyd_warshall(adj_matrix)
print(f"Матрица расстояний:\n{dist}")