# ojsTerminalBio

**Academic Portfolio CMS** — A pip-installable FastAPI backend for managing academic portfolios, publications, projects, and more.

## Installation

```bash
pip install ojsTerminalBio
```

## Quick Start

### 1. Initialize Database

```bash
ojsterminalbio init-db
```

This creates the SQLite database and a default admin user:
- **Email:** `admin@example.com`
- **Password:** `admin123`

> ⚠️ **Security Warning:** Change these credentials immediately in production!

### 2. Start Server

```bash
ojsterminalbio runserver
```

Server starts at `http://localhost:7777`

## Configuration

Configure via environment variables (prefix: `OJSTB_`):

| Variable | Default | Description |
|----------|---------|-------------|
| `OJSTB_DATABASE_URL` | `sqlite:///./ojsterminalbio.db` | Database connection string |
| `OJSTB_SECRET_KEY` | `CHANGE_THIS_IN_PRODUCTION` | JWT signing key |
| `OJSTB_DEFAULT_ADMIN_EMAIL` | `admin@example.com` | Bootstrap admin email |
| `OJSTB_DEFAULT_ADMIN_PASSWORD` | `admin123` | Bootstrap admin password |

Or use a `.env` file:

```env
OJSTB_DATABASE_URL=postgresql://user:pass@localhost/db
OJSTB_SECRET_KEY=your-secure-random-key
OJSTB_DEFAULT_ADMIN_EMAIL=admin@yoursite.com
OJSTB_DEFAULT_ADMIN_PASSWORD=secure-password-here
```

## Programmatic Usage

```python
from ojsterminalbio.main import app
from ojsterminalbio.database import get_db

# Mount the FastAPI app
# Or import specific routers:
from ojsterminalbio.routers import admin_router, public_router
```

## Features

- 📚 **Publications Management** — Track papers, journals, conferences
- 🔬 **Research Areas** — Showcase research interests
- 👨‍🎓 **Student Supervision** — PhD, MTech tracking
- 📖 **Courses** — Teaching portfolio
- 🏆 **Awards & Experience** — Career timeline
- 📄 **Custom Sections** — Flexible content blocks
- 🎨 **Theming** — Configurable colors, matrix animation

## License

MIT License - see [LICENSE](LICENSE) for details.

## Author

Jimmy Singh <jimmy.lamzing@gmail.com>
