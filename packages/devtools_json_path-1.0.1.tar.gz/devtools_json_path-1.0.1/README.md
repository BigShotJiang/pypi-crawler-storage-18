# Json Path Tester

JSONPath tester

## Online Tool

Use this tool online at **[DevTools.at](https://devtools.at/tools/json-path-tester)** - Free, fast, and no registration required!

## Installation

```bash
pip install devtools_json_path
```

## Usage

```python
from devtools_json_path import process, encode, decode

# Process input
result = process("your input here")

# Encode
encoded = encode("data to encode")

# Decode
decoded = decode("data to decode")
```

## Features

- Simple, clean API
- No external dependencies
- Works with Python 3.8+

## Online Version

For a full-featured version with a beautiful UI, visit:
**[https://devtools.at/tools/json-path-tester](https://devtools.at/tools/json-path-tester)**

## Related Tools

Check out our other developer tools at [DevTools.at](https://devtools.at):
- 100+ free developer tools
- No registration required
- Privacy-focused (client-side processing)

## License

MIT License

---

Made with love by [DevTools.at](https://devtools.at)
