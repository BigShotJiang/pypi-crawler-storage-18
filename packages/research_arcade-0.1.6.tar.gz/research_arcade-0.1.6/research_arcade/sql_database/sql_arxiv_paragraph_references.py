import os
from typing import Optional, List, Tuple
import psycopg2
import psycopg2.extras
import pandas as pd
import json

import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from ..arxiv_utils.utils import get_paragraph_num, arxiv_ids_hashing


class SQLArxivParagraphReference:
    def __init__(self, host: str, dbname: str, user: str, password: str, port: str):
        self.host = host
        self.dbname = dbname
        self.user = user
        self.password = password
        self.port = port
        self.autocommit = True

    def _get_connection(self):
        conn = psycopg2.connect(
            host=self.host,
            port=self.port,
            dbname=self.dbname,
            user=self.user,
            password=self.password,
        )
        conn.autocommit = self.autocommit
        return conn

    # -------------------------
    # DDL
    # -------------------------
    def create_paragraph_references_table(self):
        """
        Creates the paragraph_references table.
        """
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS arxiv_paragraph_references (
                    id SERIAL PRIMARY KEY,
                    paragraph_id VARCHAR(255) NOT NULL,
                    paper_section VARCHAR(255) NOT NULL,
                    paper_arxiv_id VARCHAR(100) NOT NULL,
                    reference_label VARCHAR(255),
                    reference_type VARCHAR(100)
                )
            """)
            cur.close()
        finally:
            conn.close()

    # -------------------------
    # CRUD
    # -------------------------
    def insert_paragraph_reference(self, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type) -> Optional[int]:
        """
        Insert a paragraph reference. Returns generated id.
        """
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO arxiv_paragraph_references
                (paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING id
                """,
                (paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type)
            )
            res = cur.fetchone()
            cur.close()
            return res[0] if res else None
        finally:
            conn.close()

    def delete_paragraph_reference_by_id(self, paragraph_id: int, reference_id: int) -> bool:
        """
        Delete by paragraph_id and reference_id (id). Returns True if deleted.
        """
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM arxiv_paragraph_references WHERE paragraph_id = %s AND id = %s RETURNING id",
                (paragraph_id, reference_id)
            )
            ok = cur.fetchone() is not None
            cur.close()
            return ok
        finally:
            conn.close()

    def delete_paragraph_reference_by_paragraph_id(self, paragraph_id: int) -> int:
        """
        Delete all references for a given paragraph_id.
        Returns count of deleted rows.
        """
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM arxiv_paragraph_references WHERE paragraph_id = %s RETURNING id",
                (str(paragraph_id),)
            )
            rows = cur.fetchall()
            cur.close()
            return len(rows) if rows else 0
        finally:
            conn.close()

    def delete_paragraph_reference_by_reference_id(self, reference_id: int) -> int:
        """
        Delete a reference by its id.
        Returns count of deleted rows (0 or 1).
        """
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "DELETE FROM arxiv_paragraph_references WHERE id = %s RETURNING id",
                (reference_id,)
            )
            rows = cur.fetchall()
            cur.close()
            return len(rows) if rows else 0
        finally:
            conn.close()

    def update_paragraph_reference(self, id: int, paragraph_id=None, paper_section=None, paper_arxiv_id=None, reference_label=None, reference_type=None) -> bool:
        """
        Partial update by id. Only non-None fields are updated.
        Returns True if updated.
        """
        sets, vals = [], []

        if paragraph_id is not None:
            sets.append("paragraph_id = %s")
            vals.append(paragraph_id)
        if paper_section is not None:
            sets.append("paper_section = %s")
            vals.append(paper_section)
        if paper_arxiv_id is not None:
            sets.append("paper_arxiv_id = %s")
            vals.append(paper_arxiv_id)
        if reference_label is not None:
            sets.append("reference_label = %s")
            vals.append(reference_label)
        if reference_type is not None:
            sets.append("reference_type = %s")
            vals.append(reference_type)

        if not sets:
            return False

        sql = f"UPDATE arxiv_paragraph_references SET {', '.join(sets)} WHERE id = %s RETURNING id"
        vals.append(id)

        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(sql, tuple(vals))
            ok = cur.fetchone() is not None
            cur.close()
            return ok
        finally:
            conn.close()

    def get_paragraph_reference_by_id(self, id: int, return_all: bool = False):
        """
        If return_all=False: returns a single tuple
           (id, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type)
        If return_all=True: returns a list of such tuples.
        Returns None if no row found.
        """
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT id, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type "
                "FROM arxiv_paragraph_references WHERE id = %s",
                (id,)
            )
            rows = cur.fetchall() if return_all else cur.fetchone()
            cur.close()
            return rows if rows else None
        finally:
            conn.close()

    def get_paragraph_references_by_paragraph_id(self, paragraph_id: str):
        """
        Returns a list of tuples for a given paragraph_id.
        Each tuple: (id, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type)
        """
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT id, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type "
                "FROM arxiv_paragraph_references WHERE paragraph_id = %s ORDER BY id",
                (paragraph_id,)
            )
            rows = cur.fetchall()
            cur.close()
            return rows if rows else None
        finally:
            conn.close()

    def get_all_paragraph_references(self):
        """Get all paragraph references from the database."""
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "SELECT id, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type "
                "FROM arxiv_paragraph_references"
            )
            rows = cur.fetchall()
            cur.close()
            return rows if rows else None
        finally:
            conn.close()

    def get_paragraph_neighboring_references(self, paragraph_id: int) -> Optional[pd.DataFrame]:
        """Get all references for a given paragraph."""
        conn = self._get_connection()
        try:
            query = """
                SELECT id, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type 
                FROM arxiv_paragraph_references 
                WHERE paragraph_id = %s
            """
            df = pd.read_sql(query, conn, params=(str(paragraph_id),))
            return None if df.empty else df.reset_index(drop=True)
        finally:
            conn.close()

    def get_reference_neighboring_paragraphs(self, reference_id: int) -> Optional[pd.DataFrame]:
        """Get all paragraphs that reference a given reference_id."""
        conn = self._get_connection()
        try:
            query = """
                SELECT id, paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type 
                FROM arxiv_paragraph_references 
                WHERE id = %s
            """
            df = pd.read_sql(query, conn, params=(reference_id,))
            return None if df.empty else df.reset_index(drop=True)
        finally:
            conn.close()

    def check_paragraph_reference_exists(self, id: int) -> bool:
        """Check if a paragraph reference exists by id."""
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1 FROM arxiv_paragraph_references WHERE id = %s LIMIT 1", (id,))
            ok = cur.fetchone() is not None
            cur.close()
            return ok
        finally:
            conn.close()

    # -------------------------
    # Bulk import from CSV
    # -------------------------
    def construct_paragraph_references_table_from_csv(self, csv_file: str) -> bool:
        """
        Imports rows from a CSV with columns:
            ['paragraph_id', 'paper_section', 'paper_arxiv_id', 'reference_label', 'reference_type']
        Ignores any 'id' column; DB assigns SERIAL ids.
        Returns True on success, False on validation error or missing file.
        """
        if not os.path.exists(csv_file):
            print(f"Error: CSV file {csv_file} does not exist.")
            return False

        df = pd.read_csv(csv_file)
        required_cols = ['paragraph_id', 'paper_section', 'paper_arxiv_id', 'reference_label', 'reference_type']
        missing = [c for c in required_cols if c not in df.columns]
        if missing:
            print(f"Error: External CSV is missing required columns: {missing}")
            return False

        rows: List[Tuple] = list(df[required_cols].itertuples(index=False, name=None))
        if not rows:
            print("No rows to import.")
            return True

        conn = self._get_connection()
        try:
            cur = conn.cursor()
            psycopg2.extras.execute_values(
                cur,
                """
                INSERT INTO arxiv_paragraph_references
                (paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type)
                VALUES %s
                """,
                rows,
                page_size=1000
            )
            cur.close()
        finally:
            conn.close()

        print(f"Successfully imported {len(rows)} paragraph references from {csv_file}")
        return True

    def construct_table_from_csv(self, csv_file: str) -> bool:
        """Alias for construct_paragraph_references_table_from_csv for consistency."""
        return self.construct_paragraph_references_table_from_csv(csv_file)

    def construct_table_from_json(self, json_file):
        """
        Construct the paragraph-reference relationships from an external JSON file.
        
        Args:
            json_file: Path to the JSON file
            
        Expected JSON format:
            [
                {
                    "paragraph_id": 1,
                    "paper_section": "introduction",
                    "paper_arxiv_id": "1706.03762v7",
                    "reference_label": "fig:1",
                    "reference_type": "figure"
                },
                ...
            ]
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not os.path.exists(json_file):
            print(f"Error: JSON file {json_file} does not exist.")
            return False

        try:
            # Load JSON data
            with open(json_file, 'r', encoding='utf-8') as f:
                json_data = json.load(f)
            
            # Handle different JSON structures
            if isinstance(json_data, dict):
                if 'paragraph_references' in json_data:
                    relations_list = json_data['paragraph_references']
                else:
                    relations_list = [json_data]
            elif isinstance(json_data, list):
                relations_list = json_data
            else:
                print("Error: JSON file must contain either a list or a dictionary")
                return False
            
            if not relations_list:
                print("Error: No paragraph-reference data found in JSON file")
                return False
            
            # Convert to list of tuples for bulk insert
            rows = []
            for relation in relations_list:
                if 'paragraph_id' not in relation or 'paper_section' not in relation or 'paper_arxiv_id' not in relation or 'reference_label' not in relation or 'reference_type' not in relation:
                    print(f"Warning: Skipping relation missing required fields: {relation}")
                    continue
                    
                rows.append((
                    relation['paragraph_id'],
                    relation['paper_section'],
                    relation['paper_arxiv_id'],
                    relation['reference_label'],
                    relation['reference_type']
                ))

            if not rows:
                print("No valid paragraph-reference records to import")
                return False

            conn = self._get_connection()
            try:
                cur = conn.cursor()
                psycopg2.extras.execute_values(
                    cur,
                    """
                    INSERT INTO arxiv_paragraph_references
                    (paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type)
                    VALUES %s
                    """,
                    rows,
                    page_size=1000
                )
                cur.close()
            finally:
                conn.close()

            print(f"Successfully imported {len(rows)} paragraph-reference relationships from {json_file}")
            return True
            
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON file - {e}")
            return False
        except Exception as e:
            print(f"Error importing paragraph-reference relationships from JSON: {e}")
            return False
        
    def construct_paragraph_references_table_from_api(self, arxiv_ids, dest_dir):
        """
        Construct paragraph references from API-generated paragraph data.
        Uses bulk operations for efficiency.
        """
        # Apply the hashing to get the correct path
        prefix = arxiv_ids_hashing(arxiv_ids=arxiv_ids)
        paragraph_path = f"{dest_dir}/output/paragraphs/{prefix}/text_nodes.jsonl"
        
        if not os.path.exists(paragraph_path):
            print(f"Error: Paragraph file {paragraph_path} does not exist.")
            return False
        
        with open(paragraph_path) as f:
            data = [json.loads(line) for line in f]
        
        section_min_paragraph = {}
        
        # First pass - find minimum paragraph ID for each section
        for paragraph in data:
            paragraph_id = paragraph.get("id")
            paper_arxiv_id = paragraph.get("paper_id")
            paper_section = paragraph.get("section")
            
            if not paragraph_id or not paper_arxiv_id or not paper_section:
                continue
            
            id_number = get_paragraph_num(paragraph_id)
            key = (paper_arxiv_id, paper_section)
            
            if key not in section_min_paragraph:
                section_min_paragraph[key] = int(id_number)
            else:
                section_min_paragraph[key] = min(section_min_paragraph[key], int(id_number))
        
        # Second pass - collect all rows for bulk insert
        rows = []
        for paragraph in data:
            paragraph_id = paragraph.get("id")
            paper_arxiv_id = paragraph.get("paper_id")
            paper_section = paragraph.get("section")
            
            if not paragraph_id or not paper_arxiv_id or not paper_section:
                continue
                
            key = (paper_arxiv_id, paper_section)
            if key not in section_min_paragraph:
                continue
                
            id_number = get_paragraph_num(paragraph_id)
            id_zero_based = id_number - section_min_paragraph[key]
            
            paragraph_ref_labels = paragraph.get('ref_labels') or []
            
            for ref_label in paragraph_ref_labels:
                ref_type = None
                
                # Determine reference type - match CSV version prefixes
                is_figure = ref_label.startswith("fig")
                is_table = ref_label.startswith("tab")
                
                if is_figure:
                    ref_type = 'figure'
                elif is_table:
                    ref_type = 'table'
                
                # Add to bulk insert list
                rows.append((
                    id_zero_based,
                    paper_section,
                    paper_arxiv_id,
                    ref_label,
                    ref_type
                ))
        
        # Bulk insert all rows at once
        if not rows:
            print("No paragraph references to import")
            return True
        
        conn = self._get_connection()
        try:
            cur = conn.cursor()
            psycopg2.extras.execute_values(
                cur,
                """
                INSERT INTO arxiv_paragraph_references 
                    (paragraph_id, paper_section, paper_arxiv_id, reference_label, reference_type)
                VALUES %s
                """,
                rows,
                page_size=1000
            )
            cur.close()
            print(f"Successfully imported {len(rows)} paragraph references from API")
            return True
        finally:
            conn.close()