#
# SPDX-FileCopyrightText: Copyright (c) 2025 Yuncheng (Eric) Yuan
# SPDX-License-Identifier: MIT
"""linear codes decoding."""

