#
# SPDX-FileCopyrightText: Copyright (c) 2025 Yuncheng (Eric) Yuan
# SPDX-License-Identifier: MIT
"""linear codes encoding."""

import torch

class fec_encoders(torch.nn.Module):
    def __init__(self, generator_matrix):
        """
        Use matrix to encode the data.

        Args:
            data: data received from the signal
            generator matrix: generate the parity code

        Input:
          input_data (torch.Tensor): Information bits to encode, shape (..., K).
            - dtype: float
            - values: in {0, 1}
          Generator Matrix:
            - generator_matrix (torch.Tensor): Generator matrix for encoding, shape (N, K).

        Output:
          result_tensor (torch.Tensor): Encoded codewords, shape (..., N).
            - dtype: torch.int64 (after matmul and modulo)
            - values: in {0, 1}
        Note:
          - generator_matrix must have shape (N, K). The computation is:
              result = (input_data @ generator_matrix.T) mod 2
          - All operations are over GF(2); ensure inputs are binary to avoid unexpected results.
          - Batch dimensions are supported via leading dimensions in input_data.

        """
        super(fec_encoders, self).__init__()


    def forward(self, input_data, generator_matrix):
        # Perform matrix multiplication to encode the data
        result_tensor = torch.matmul(input_data, self.generator_matrix()) % 2

        return result_tensor