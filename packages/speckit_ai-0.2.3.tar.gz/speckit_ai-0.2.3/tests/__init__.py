"""Tests for speckit library."""
