"""Test `parstools._trees`."""
import typing as _ty

import parstools._trees as _trs


class Tree(_ty.NamedTuple):
    """Syntax tree."""

    symbol: str
    value: str | list


def test_tree_len():
    # leaf
    tree = make_leaf_tree()
    n = _trs.tree_len(tree, 'value')
    assert n == 1, n
    # nonleaf
    tree = make_nonleaf_tree()
    n = _trs.tree_len(tree, 'value')
    assert n == 5, n
    # branching
    tree = make_branching_tree()
    n = _trs.tree_len(tree, 'value')
    assert n == 3, n


def test_foliage():
    # leaf
    tree = make_leaf_tree()
    foliage = _trs.foliage(tree)
    assert foliage == 'x', foliage
    # nonleaf
    tree = make_nonleaf_tree()
    foliage = _trs.foliage(tree)
    assert foliage == 'f ( x )', foliage
    # branching
    tree = make_branching_tree()
    foliage = _trs.foliage(tree)
    assert foliage == 'a b', foliage


def test_pformat_tree():
    # leaf
    tree = make_leaf_tree()
    text = _trs.pformat_tree(tree)
    text_ = 'NAME\n└── x'
    assert text == text_, text
    # nonleaf tree
    tree = make_nonleaf_tree()
    text = _trs.pformat_tree(tree)
    text_ = (
        'operator_application\n├── NAME\n│   '
        '└── f\n├── LPAREN\n│   └── (\n├── '
        'NAME\n│   └── x\n└── RPAREN\n    └── )')
    assert text == text_
    # nonleaf tree
    tree = make_height_2_tree()
    text = _trs.pformat_tree(tree)
    text_ = (
        'C\n└── B\n    '
        '└── A\n        └── a')
    assert text == text_, text


def make_leaf_tree() -> Tree:
    """Return tree with 1 node."""
    return Tree(
        symbol='NAME',
        value='x')


def make_nonleaf_tree() -> Tree:
    """Return tree with 5 nodes."""
    f = Tree(
        symbol='NAME',
        value='f')
    lparen = Tree(
        symbol='LPAREN',
        value='(')
    x = Tree(
        symbol='NAME',
        value='x')
    rparen = Tree(
        symbol='RPAREN',
        value=')')
    value = [f, lparen, x, rparen]
    return Tree(
        symbol='operator_application',
        value=value)


def make_height_2_tree() -> Tree:
    """Return tree of height 2."""
    a = Tree(
        symbol='A',
        value='a')
    b = Tree(
        symbol='B',
        value=[a])
    return Tree(
        symbol='C',
        value=[b])


def make_branching_tree() -> Tree:
    """Return a tree with a fork."""
    first = Tree(
        symbol='A',
        value='a')
    second = Tree(
        symbol='B',
        value='b')
    return Tree(
        symbol='+',
        value=[first, second])


if __name__ == '__main__':
    test_pformat_tree()
