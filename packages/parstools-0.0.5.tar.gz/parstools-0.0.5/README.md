`parstools` is a package for writing parsers.
Currently, it includes:

- [LR(1)](https://doi.org/10.1016/S0019-9958%2865%2990426-2) parser generation
- [LR(1) with state-merging](https://doi.org/10.1007/BF00290336)
- grammar definition via `p_...` methods
- lexer definition via `t_...` methods
- stateful lexing
- regular language matching [using nondeterministic automata](https://doi.org/10.1145/363347.363387)
- conversions between regular grammars, regexes, NFA
- representing grammars, productions
- plotting LR state-machines
- printing of LR tables
- printing trees

The documentation is in the file `doc.md`.
Examples are in the directory `examples/`.
