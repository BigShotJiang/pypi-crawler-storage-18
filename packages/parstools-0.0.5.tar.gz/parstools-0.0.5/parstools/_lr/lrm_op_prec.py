"""LR(1) with state merging and operator precedence."""
import collections.abc as _abc
import logging
import time
import typing as _ty

import parstools._ff as _ff
import parstools._grammars as _grm
import parstools._lr.lr_merging_opt as _lrm
import parstools._lr.parser as _p
import parstools._lr.utils as _lu


_Grammar = _grm.Grammar
_Kernel = _lrm._Kernel
_Kernels = _lrm._Kernels
_Precedence =_p.Precedence


def make_parser(
        grammar:
            _Grammar,
        precedence:
            _Precedence |
            None=None,
        cache_filename:
            str |
            None=None
        ) -> _p.Parser:
    """Return LR-merged parser.

    If `precedence is not None`,
    use to resolve shift/reduce ambiguities.

    `precedence` contains tuples of
    associativity and token names, where:
    - associativity is `'left'`, `'nonassoc'`,
      or `'right'`.
    - token names are strings

    Example:

    ```python
    precedence = [
        ('left', 'PLUS', 'MINUS'),
        ('left', 'ASTERISK', 'DIV')]
    ```

    If `cache_filename is not None`,
    use to store the parser, attempting to
    load the parser first from file (JSON).
    """
    # NOTE: The parameter `precedence` is
    # not named `operator_precedence` because
    # it can contain any token, as well as
    # nonleaf symbols.
    parser = _p.check_parser_cache(
        grammar, cache_filename, precedence)
    if parser is not None:
        return parser
    if precedence is None:
        precedence = list()
    parser = make_lr_1_tables(grammar, precedence)
    _p.dump_parser_cache(
        grammar, parser, cache_filename, precedence)
    return parser


def make_lr_1_tables(
        grammar:
            _Grammar,
        precedence:
            _Precedence
        ) -> _p.Parser:
    t1 = time.perf_counter()
    grammar = _lu.add_root_equation(grammar)
    first_sets = _ff.compute_first_sets(
        grammar.equations)
    nodes, edges = _lrm._collect_merged_nodes(
        grammar, first_sets)
    all_kernels = all(map(
        _lrm._is_kernel, nodes))
    if not all_kernels:
        raise AssertionError(all_kernels)
    # text = _lu.pformat_states(nodes)
    # print(text)
    actions = _make_lr_1_action_table(
        edges, grammar, first_sets, precedence)
    initial = _lrm._make_init_state(
        grammar.root_symbol)
    t2 = time.perf_counter()
    dt = t2 - t1
    print(f'parser computed in: {dt:1.2f} sec')
    return _p.Parser(
        initial, actions)


def _make_lr_1_action_table(
        edges:
            _abc.MutableMapping[
                _Kernel,
                _Kernels],
        grammar:
            _Grammar,
        first_sets:
            dict,
        precedence:
            _Precedence
        ) -> _lrm._Actions:
    """Return parser-actions table."""
    assoc_cases = {'left', 'right', 'nonassoc'}
    op_to_prec = dict()
    enum = enumerate(precedence)
    for i, items in enum:
        assoc, *operators = items
        if assoc not in assoc_cases:
            raise ValueError(assoc)
        if not operators:
            raise ValueError(items)
        for operator in operators:
            op_to_prec[operator] = (i, assoc)
    # compute actions
    actions: _lrm._Actions = dict()
    for node, succ in edges.items():
        _make_lr_1_actions_at_node(
            node, succ, actions,
            grammar, first_sets,
            op_to_prec)
    # check actions for next-node
    states = {
        node
        for node, _ in actions}
    for key, action in actions.items():
        next_state = action.state
        if next_state is None:
            continue
        if next_state not in states:
            print(_lu.pformat_state(next_state))
            print(f'{edges[next_state] = }')
            raise AssertionError()
    return actions


def _make_lr_1_actions_at_node(
        node:
            _Kernel,
        edge_successors:
            _Kernels,
        actions:
            _lrm._Actions,
        grammar:
            _Grammar,
        first_sets:
            dict,
        op_to_prec:
            dict[
                str,
                tuple[int, str]]
        ) -> None:
    """Add edges from `node`."""
    has_action = (
        bool(edge_successors) or
        bool(set(_lu.final_items(node))))
    if not has_action:
        print(_lu.pformat_state(node))
        raise AssertionError()
    # shifts
    for next_node in edge_successors:
        item = _lu.pick_kernel_item(
            next_node)
        symbol = item.done[-1]
        action = _lu.Action(
            state=next_node)
        _add_lr_action(
            node, symbol, action, actions,
            op_to_prec)
    # reductions
    for item in _lu.final_items(node):
        equation = _lu.production_of_dot(item)
        for symbol in item.lookaheads:
            action = _lu.Action(
                equation=equation)
            _add_lr_action(
                node, symbol, action, actions,
                op_to_prec)
    # print(actions)


def _add_lr_action(
        node:
            _Kernel,
        symbol:
            str,
        action:
            _lu.Action,
        actions:
            _lrm._Actions,
        op_to_prec:
            dict[
                str,
                tuple[int, str]]
        ) -> None:
    """Add action, with error message otherwise."""
    key = (node, symbol)
    other = actions.get(key)
    # no existing action ?
    if other is None:
        actions[key] = action
        return
    # a shift or reduction already exists
    #
    # shift-shift ambiguity ?
    both_shift = (
        action.state is not None and
        other.state is not None)
    if both_shift:
        raise AssertionError(
            'shift-shift ambiguity detected:\n'
            f'{action}\n'
            'or\n'
            f'{other}')
    # reduce-reduce ambiguity ?
    both_reduce = (
        action.equation is not None and
        other.equation is not None)
    if both_reduce:
        raise ValueError(
            'reduce-reduce ambiguity: '
            'reduce using production: '
            f'`{action.equation}`, or '
            'reduce using production: '
            f'`{other.equation}`')
    # shift-reduce ambiguity
    #
    # reductions are added after shifts
    # so `other` is a shift and
    # `action` is a reduction
    if (other.state is None or
            action.equation is None):
        raise AssertionError(action, other)
    # try to resolve ambiguity
    # using operator precedence
    symbol_prec = op_to_prec.get(symbol)
    expansion = action.equation.expansion
    prec_or_none = map(op_to_prec.get, expansion)
    prec = list(filter(None, prec_or_none))
    if symbol_prec is None or not prec:
        raise ValueError(
            'shift-reduce ambiguity: '
            f'shift symbol: `{symbol}`, or '
            'reduce using production: '
            f'`{action.equation}`')
    exp_prec = max(
        prec,
        key=lambda x: x[0])
    # same precedence and not nesting ?
    nonassoc = (
        symbol_prec[0] == exp_prec[0] and
        exp_prec[1] == 'nonassoc')
    if nonassoc:
        raise ValueError(
            'shift-reduce ambiguity (nonassoc): '
            f'shift symbol: `{symbol}`, or '
            'reduce using production: '
            f'`{action.equation}`')
    # use precedence and associativity
    shift = (
        symbol_prec[0] > exp_prec[0] or
        (symbol_prec[0] == exp_prec[0] and
        exp_prec[1] == 'right'))
        # cases: left, nonassoc, right
    # shift instead of reduce ?
    if shift:
        logging.debug(
            'shift-reduce choice resolved '
            f'as shift of symbol: `{symbol}`, '
            'instead of reducing using '
            f'production: `{action.equation}`')
        return
    # reduce, instead of shift
    actions[key] = action
    logging.debug(
        'shift-reduce choice resolved '
        'as reducing using production: '
        f'`{action.equation}`,'
        'instead of shifting '
        f'symbol: `{symbol}`')
