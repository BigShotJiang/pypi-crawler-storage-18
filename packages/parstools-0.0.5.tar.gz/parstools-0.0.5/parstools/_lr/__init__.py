"""LR parser implementations."""
