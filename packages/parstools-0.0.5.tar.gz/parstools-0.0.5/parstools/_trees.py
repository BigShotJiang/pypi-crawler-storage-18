"""Foliage, measuring, pprint trees."""
import collections.abc as _abc
import typing as _ty


class Tree(
        _ty.Protocol):
    """Syntax tree."""

    symbol: str
    value: str | list


def tree_len(
        tree,
        attribute_name:
            str
        ) -> int:
    """Return number of nodes (treelets).

    `attribute_name` is where the successor
    nodes are stored.
    """
    count = 0
    todo = [tree]
    while todo:
        t = todo.pop()
        count += 1
        succ = getattr(t, attribute_name)
        is_leaf = (
            isinstance(succ, str) or
            succ is None)
        if is_leaf:
            continue
        todo.extend(succ)
    return count


def foliage(
        tree:
            Tree
        ) -> str:
    """Return concatenated leafs.

    Maps a syntax tree to a sequence of
    lexemes, with blankspace inserted.
    """
    if isinstance(tree.value, str):
        return tree.value
    return '\x20'.join(map(
        foliage, tree.value))


def pprint_tree(
        tree:
            Tree
        ) -> None:
    """Print tree."""
    text = pformat_tree(tree)
    print(text)


def pformat_tree(
        tree:
            Tree
        ) -> str:
    """Return formatted text for `tree`."""
    lines = _pformat_tree(tree)
    text = '\n'.join(lines)
    return f'{tree.symbol}\n{text}'


def _pformat_tree(
        tree:
            Tree
        ) -> _abc.Iterator[str]:
    """Yield lines showing `tree`."""
    if isinstance(tree, str):
        return
    if isinstance(tree.value, str):
        items = [tree.value]
    else:
        items = tree.value
    for i, u in enumerate(items):
        prefix = '├──' if i < len(items) - 1 else '└──'
        if isinstance(u, str):
            yield f'{prefix} {u}'
            continue
        yield f'{prefix} {u.symbol}'
        prefix = '│' if i < len(items) - 1 else ' '
        for line in _pformat_tree(u):
            yield f'{prefix}   {line}'
