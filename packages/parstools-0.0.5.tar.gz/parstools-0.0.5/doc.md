# `parstools` documentation

The main way of defining lexers and parsers is via classes,
and is similar to the interface of [Python Lex-Yacc](
  https://pypi.org/project/ply/).


## Lexer definition

Lexers are defined by subclassing `StatefulLexer`, for example:

```python
import parstools


class Lexer(
        parstools.StatefulLexer):
    """Grammar for building a lexer."""

    t_NUMBER = r' \d+ '
    t_PLUS = r' \+ '
    t_MINUS = r' \- '
    t_ASTERISK = r' \* '
    t_DIV = r' / '
    t_omit = r' \s* '
```

Each attribute `t_...` is a regular expression.
The attribute `t_omit` is used by the lexer to skip
blankspace or any other characters as defined in its
regular expression. Methods are also possible, for example:

```python
import parstools as _prs


class Lexer(
        _prs.StatefulLexer):
    """A lexer of keywords and identifiers."""

    def __init__(
            self):
        self._keywords = {
            'if':
                'IF',
            'else':
                'ELSE',
            'for':
                'FOR',
            'while':
                'WHILE'}

    def t_NAME(
            self,
            token):
        r"""
        [a-zA-Z]
        [a-zA-Z]*
        """
        symbol = self._keywords.get(
            token.value, 'NAME')
        return _prs.Token(
            symbol=symbol,
            value=token.value)

```

The docstring of the method is used as regex in the grammar.
The regexes are compiled using the module [`re`](
    https://docs.python.org/3/library/re.html), with the
option [`re.VERBOSE`](
    https://docs.python.org/3/library/re.html#re.VERBOSE),
so regexes can include blankspace, and so span multiple lines.

There is also a way to define a parser via a grammar
definition, but the interface is internal and may change.


## Parser definition

Parsers are defined as classes with methods named `p_...`.
Each method takes a parameter `p` and sets `p[0]` with the
result for that grammar production. Example:

```python
import os

import parstools


class Parser:
    """A basic parser."""

    def __init__(
            self):
        self.root_symbol = 'expr'
            # the grammar starts at symbol "expr"
        self._lexer = Lexer()
            # instance of a `StatefulLexer`
        self._parser = None
            # initialized when first parsing

    def parse(
            self,
            text:
                str):
        """Evaluate an expression."""
        self._build()
        tokens = self._lexer.parse(text)
        result = self._parser.parse(tokens)
        return result

    def build(
            self):
        """Create state machine of parser."""
        # already built ?
        if self._parser is not None:
            return
        # JSON filename
        path, _ = os.path.split(__file__)
        filename = 'calculator_parser.json'
        cache_filepath = os.path.join(
            path, filename)
        # generate parser
        self._parser = parstools.make_parser(
            self,
            cache_filepath=cache_filepath)

    def p_plus(
            self, p):
        """expr: expr PLUS expr"""
        p[0] = p[1] + p[3]

    ...
```

The JSON file is here stored in the same directory as
the Python file containing the parser definition. This is
convenient for packaging parsers built using `parstools`.

Also, make sure that `parstools` is installed for building
the `sdist` and wheel of your package, and that the JSON files
are copied to the install location. For example, when using
`setuptools` one way to ensure packaging of the JSON files is:

```python
import setuptools


def run_setup():
    ...
    setuptools.setup(
            name='somepkg',
            ...
            packages=['somepkg'],
            package_dir={'somepkg': 'somepkg'},
            package_data={
                'somepkg': [
                    'calculator_parser.json']},
            include_package_data=True,
            ...
            )
```

In addition, if building parser files from `setup.py`,
then importing the modules from the package being built
may require the following inside `setup.py`:

```python
import os
import sys


dirpath = os.path.dirname(__file__)
sys.path.append(dirpath)
```


### Parser with operator precedence

It is also possible to generate a parser that shifts or
reduces based on a given precedence of tokens, in addition
to the grammar's structure. This precedence is given as
a list of tuples when calling the function `make_parser()`.
For example:

```python
class Parser:

    def __init__(   
            self):
        ...
        # lowest to highest precedence
        self.precedence = [
            ('left', 'PLUS', 'MINUS'),
            ('left', 'ASTERISK', 'DIV')]

    def build(
            self):
        """Create state machine of parser."""
        ...
        # generate parser
        self._parser = parstools.make_parser(
            self,
            precedence=self.precedence,
            cache_filepath=cache_filepath)
```

"left" declares associativity of the tokens in the tuple.
So `ASTERISK` has higher precedence than `PLUS`.
Thus, multiplication `*` will bind tighter than addition `+`.
Therefore, `1 + 2 * 3` is parsed the same as `1 + (2 * 3)`.
This is different than `(1 + 2) * 3`. Placing `PLUS` after
`ASTERISK` in the operator precedence would result in parsing
`1 + 2 * 3` as `(1 + 2) * 3`.


## Additional functionality

Besides what is available by `import parstools`, there are
several functions that can be useful but require importing
them directly from specific modules. Moreover, currently
modules of `parstools` are internal (prefixed with `_`).
So using these functions would require importing them from
internal modules.

Nonetheless, functionality as for example classes and
functions for writing shift-reduce parsers can be used for
writing modified parsers, e.g., for tracking
undelimited expressions when parsing TLA+.
So reading the contents of the package can lead to finding
more functionality to use.

For example, for customizing the shift-reduce parser that
runs the LR(1) state machine, the code of the class
`parstools._lr.parser.Parser` can be a starting point.
