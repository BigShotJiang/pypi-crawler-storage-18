from setuptools import setup, find_packages

setup(
    name="loguru_to_cls_tencent",
    version="0.1.2",
    packages=find_packages(),
    install_requires=[
        "loguru",
        "kafka-python",
    ],
    author="linzeming",
    author_email="linzeming@example.com",
    description="A loguru handler to send logs to Tencent Cloud CLS via Kafka",
    long_description=open("README.md").read() if open("README.md") else "",
    long_description_content_type="text/markdown",
    url="https://gitee.com/linzeming/loguru-to-cls",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
