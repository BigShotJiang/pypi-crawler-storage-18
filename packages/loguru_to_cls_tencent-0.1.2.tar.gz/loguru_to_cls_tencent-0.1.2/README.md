# loguru-to-cls

A simple package to send [loguru](https://github.com/Delgan/loguru) logs to Tencent Cloud CLS (Cloud Log Service) using the Kafka protocol.

## Installation

### From PyPI (Official)
If you just published the package, it might take a few minutes to sync to mirrors. Use the official PyPI server to install immediately:

```bash
pip install loguru-to-cls-tencent -i https://pypi.org/simple
```

### Gitee (Source)

Or install from source:

```bash
pip install .
```

## Usage

```python
from loguru import logger
from loguru_to_cls import setup_cls_logging

# Initialize CLS logging
secret_id = "YOUR_SECRET_ID"
secret_key = "YOUR_SECRET_KEY"
logset_id = "YOUR_LOGSET_ID"
topic_id = "YOUR_TOPIC_ID"

handler = setup_cls_logging(secret_id, secret_key, logset_id, topic_id)

# Now you can use loguru as usual
logger.info("This is a test log message sent to Tencent Cloud CLS!")
logger.error("This is an error message.")

# Ensure all logs are sent before exiting
handler.flush()
```

## Configuration

The `setup_cls_logging` function accepts the following parameters:

- `secret_id`: Tencent Cloud Secret ID.
- `secret_key`: Tencent Cloud Secret Key.
- `logset_id`: CLS Logset ID.
- `topic_id`: CLS Topic ID.
- `level`: Logging level (default: "INFO").
- `bootstrap_servers`: List of Kafka bootstrap servers (default: Tencent Cloud Guangzhou region).
