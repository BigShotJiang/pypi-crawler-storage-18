import json
import time
import atexit

try:
    from loguru import logger
except ImportError:
    logger = None

try:
    from kafka import KafkaProducer
except ImportError:
    KafkaProducer = None


class CLSHandler:
    def __init__(self, secret_id, secret_key, logset_id, topic_id, bootstrap_servers=None):
        self.secret_id = secret_id
        self.secret_key = secret_key
        self.logset_id = logset_id
        self.topic_id = topic_id
        # External port 9096, Internal port 9095
        self.bootstrap_servers = bootstrap_servers or ["gz-producer.cls.tencentcs.com:9096"]

        if KafkaProducer is None:
            print("Warning: kafka-python not found. CLS logging will be disabled.")
            self.producer = None
            return

        try:
            self.producer = KafkaProducer(
                bootstrap_servers=self.bootstrap_servers,
                security_protocol='SASL_PLAINTEXT',
                sasl_mechanism='PLAIN',
                sasl_plain_username=self.logset_id,
                sasl_plain_password=f"{self.secret_id}#{self.secret_key}",
                api_version=(0, 11, 0),
                request_timeout_ms=5000,  # 5 seconds timeout for requests
                retries=1,  # Reduce retries to avoid hanging on exit
                linger_ms=100  # Small delay to batch logs
            )
            # Unregister kafka-python's default atexit handler which uses timeout=0
            # and causes KafkaTimeoutError on exit. We will handle closing ourselves.
            try:
                if hasattr(self.producer, '_atexit_handler'):
                    atexit.unregister(self.producer._atexit_handler)
                else:
                    # Fallback for other versions
                    atexit.unregister(self.producer.close)
            except Exception:
                pass
        except Exception as e:
            print(f"Failed to initialize KafkaProducer: {e}")
            self.producer = None

    def __call__(self, message):
        if self.producer is None:
            return

        try:
            # message is a loguru Message object
            # If serialize=True was used in logger.add, message is already a JSON string
            log_value = str(message).encode('utf-8')

            # Use send() as in the example
            self.producer.send(topic=self.topic_id, value=log_value)
        except Exception as e:
            print(f"Error sending log to CLS: {e}")

    def flush(self):
        if self.producer:
            try:
                # Use a timeout to prevent hanging during exit
                self.producer.flush(timeout=5)
            except Exception as e:
                print(f"Error flushing logs to CLS: {e}")

    def stop(self):
        """
        Explicitly stop the producer and flush remaining logs.
        """
        if self.producer:
            try:
                self.producer.flush(timeout=2)
                self.producer.close(timeout=2)
            except Exception as e:
                print(f"Error closing CLS producer: {e}")
            finally:
                self.producer = None


def setup_cls_logging(secret_id, secret_key, logset_id, topic_id, level="INFO", bootstrap_servers=None):
    """
    Convenience function to setup CLS logging with loguru.
    """
    if logger is None:
        print("Warning: loguru not found. CLS logging setup skipped.")
        return None

    cls_handler = CLSHandler(secret_id, secret_key, logset_id, topic_id, bootstrap_servers)

    # Add CLS handler to loguru
    # serialize=True will make the message a JSON string
    handler_id = logger.add(cls_handler, serialize=True, level=level)

    # Register atexit to ensure clean shutdown
    def cleanup():
        cls_handler.stop()
        try:
            logger.remove(handler_id)
        except Exception:
            pass

    atexit.register(cleanup)

    return cls_handler
