"""Tests for choppa package."""
