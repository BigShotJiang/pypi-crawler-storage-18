class InvalidCredentialsException(Exception):
    pass
