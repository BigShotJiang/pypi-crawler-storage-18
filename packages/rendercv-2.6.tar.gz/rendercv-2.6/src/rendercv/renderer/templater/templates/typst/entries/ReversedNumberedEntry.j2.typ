+ {{entry.reversed_number}}
