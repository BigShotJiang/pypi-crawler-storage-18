# Placeholder
def dummy(): pass