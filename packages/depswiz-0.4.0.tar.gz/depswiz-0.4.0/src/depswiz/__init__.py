"""depswiz - Multi-language dependency wizard."""

__version__ = "0.4.0"
__all__ = ["__version__"]
