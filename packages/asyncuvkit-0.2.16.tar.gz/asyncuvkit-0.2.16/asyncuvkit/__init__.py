
__version__ = "0.2.16"
__author__ = "asyncuvkit"

# 自动安装 import hook
from . import asyncuvkit
from .test import calculation3

__all__ = ['asyncuvkit', "calculation3"]
