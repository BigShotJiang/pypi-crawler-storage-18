################################################################################
# KOPI-DOCKA
#
# @file:        backup_commands.py
# @module:      kopi_docka.commands
# @description: Backup and restore commands
# @author:      Markus F. (TZERO78) & KI-Assistenten
# @repository:  https://github.com/TZERO78/kopi-docka
# @version:     2.0.0
#
# ------------------------------------------------------------------------------
# Copyright (c) 2025 Markus F. (TZERO78)
# MIT-Lizenz: siehe LICENSE oder https://opensource.org/licenses/MIT
################################################################################

"""Backup and restore commands."""

from pathlib import Path
from typing import Optional, List

import typer
from rich.console import Console
from rich.panel import Panel

from ..helpers import Config, get_logger
from ..helpers.constants import (
    BACKUP_SCOPE_MINIMAL,
    BACKUP_SCOPE_STANDARD,
    BACKUP_SCOPE_FULL,
    BACKUP_SCOPES,
)
from ..helpers.ui_utils import (
    print_success,
    print_error,
    print_warning,
    print_error_panel,
)
from ..cores import (
    KopiaRepository,
    DockerDiscovery,
    BackupManager,
    RestoreManager,
    DryRunReport,
)

logger = get_logger(__name__)
console = Console()


def get_config(ctx: typer.Context) -> Optional[Config]:
    """Get config from context."""
    return ctx.obj.get("config")


def ensure_config(ctx: typer.Context) -> Config:
    """Ensure config exists or exit."""
    cfg = get_config(ctx)
    if not cfg:
        print_error_panel(
            "No configuration found\n\n"
            "[dim]Run:[/dim] [cyan]kopi-docka admin config new[/cyan]"
        )
        raise typer.Exit(code=1)
    return cfg


def get_repository(ctx: typer.Context) -> Optional[KopiaRepository]:
    """Get or create repository from context."""
    if "repository" not in ctx.obj:
        cfg = get_config(ctx)
        if cfg:
            ctx.obj["repository"] = KopiaRepository(cfg)
    return ctx.obj.get("repository")


def ensure_repository(ctx: typer.Context) -> KopiaRepository:
    """Ensure repository is connected."""
    repo = get_repository(ctx)
    if not repo:
        print_error_panel("Repository not available")
        raise typer.Exit(code=1)

    try:
        if repo.is_connected():
            return repo
    except Exception:
        pass

    console.print("[cyan]Connecting to Kopia repository...[/cyan]")
    try:
        repo.connect()
    except Exception as e:
        print_error(f"Connect failed: {e}")
        raise typer.Exit(code=1)

    if not repo.is_connected():
        print_error("Still not connected after connect().")
        raise typer.Exit(code=1)

    return repo


def _filter_units(all_units, names: Optional[List[str]]):
    """Filter backup units by name."""
    if not names:
        return all_units
    wanted = set(names)
    return [u for u in all_units if u.name in wanted]


# -------------------------
# Commands
# -------------------------

def cmd_list(
    ctx: typer.Context,
    units: bool = True,
    snapshots: bool = False,
):
    """List backup units or repository snapshots."""
    cfg = ensure_config(ctx)

    if not (units or snapshots):
        units = True

    if units:
        console.print("[cyan]Discovering Docker backup units...[/cyan]")
        try:
            discovery = DockerDiscovery()
            found = discovery.discover_backup_units()
            if not found:
                console.print("[dim]No units found.[/dim]")
            else:
                for u in found:
                    console.print(
                        f"  [cyan]•[/cyan] {u.name} [dim]({u.type})[/dim]: "
                        f"{len(u.containers)} containers, {len(u.volumes)} volumes"
                    )
        except Exception as e:
            print_error(f"Discovery failed: {e}")
            raise typer.Exit(code=1)

    if snapshots:
        console.print("\n[cyan]Listing snapshots...[/cyan]")
        try:
            repo = KopiaRepository(cfg)
            snaps = repo.list_snapshots()
            if not snaps:
                console.print("[dim]No snapshots found.[/dim]")
            else:
                for s in snaps:
                    unit = s.get("tags", {}).get("unit", "-")
                    ts = s.get("timestamp", "-")
                    sid = s.get("id", "")
                    console.print(f"  [cyan]•[/cyan] {sid} | unit={unit} | {ts}")
        except Exception as e:
            print_error(f"Unable to list snapshots: {e}")
            raise typer.Exit(code=1)


def cmd_backup(
    ctx: typer.Context,
    unit: Optional[List[str]] = None,
    dry_run: bool = False,
    update_recovery_bundle: Optional[bool] = None,
    scope: str = BACKUP_SCOPE_STANDARD,
):
    """Run a cold backup for selected units (or all)."""
    cfg = ensure_config(ctx)
    repo = ensure_repository(ctx)

    # Validate scope
    if scope not in BACKUP_SCOPES:
        print_error_panel(
            f"Invalid scope: {scope}\n\n"
            f"[dim]Valid scopes:[/dim] {', '.join(BACKUP_SCOPES.keys())}"
        )
        raise typer.Exit(code=1)

    # Display scope information
    scope_info = BACKUP_SCOPES[scope]
    console.print()
    console.print(Panel.fit(
        f"[bold cyan]Backup Scope: {scope_info['name']}[/bold cyan]\n\n"
        f"{scope_info['description']}\n\n"
        f"[dim]Includes:[/dim] {', '.join(scope_info['includes'])}",
        border_style="cyan"
    ))
    console.print()

    try:
        discovery = DockerDiscovery()
        units = discovery.discover_backup_units()
        selected = _filter_units(units, unit)

        if not selected:
            console.print("[dim]Nothing to back up (no units found).[/dim]")
            return

        if dry_run:
            report = DryRunReport(cfg)
            report.generate(selected, update_recovery_bundle)
            return

        bm = BackupManager(cfg)
        overall_ok = True

        for u in selected:
            console.print(f"[bold cyan]==>[/bold cyan] Backing up unit: [bold]{u.name}[/bold] ({scope})")
            meta = bm.backup_unit(
                u,
                backup_scope=scope,
                update_recovery_bundle=update_recovery_bundle
            )
            if meta.success:
                print_success(f"{u.name} completed in {int(meta.duration_seconds)}s")
                console.print(f"   [dim]Volumes:[/dim] {meta.volumes_backed_up}")
                if meta.networks_backed_up > 0:
                    console.print(f"   [dim]Networks:[/dim] {meta.networks_backed_up}")
                if meta.kopia_snapshot_ids:
                    console.print(f"   [dim]Snapshots:[/dim] {len(meta.kopia_snapshot_ids)}")
            else:
                overall_ok = False
                print_error(f"{u.name} failed in {int(meta.duration_seconds)}s")
                for err in meta.errors or [meta.error_message]:
                    if err:
                        console.print(f"   [red]- {err}[/red]")

        if not overall_ok:
            raise typer.Exit(code=1)

    except Exception as e:
        print_error_panel(f"Backup failed: {e}")
        raise typer.Exit(code=1)


def cmd_restore(ctx: typer.Context, yes: bool = False, advanced: bool = False):
    """Launch the interactive restore wizard.

    Args:
        ctx: Typer context
        yes: Non-interactive mode
        advanced: Enable cross-machine restore (show all machines in repository)
    """
    cfg = ensure_config(ctx)
    repo = ensure_repository(ctx)

    try:
        rm = RestoreManager(cfg, non_interactive=yes)
        if advanced:
            rm.advanced_interactive_restore()
        else:
            rm.interactive_restore()
    except Exception as e:
        print_error_panel(f"Restore failed: {e}")
        raise typer.Exit(code=1)


# -------------------------
# Registration
# -------------------------

def register(app: typer.Typer):
    """Register backup and restore commands (top-level).

    Note: The 'list' command has been moved to 'admin snapshot list'.
    """

    @app.command("backup")
    def _backup_cmd(
        ctx: typer.Context,
        unit: Optional[List[str]] = typer.Option(None, "--unit", help="Backup only these units"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Simulate backup"),
        update_recovery_bundle: Optional[bool] = typer.Option(
            None, "--update-recovery/--no-update-recovery"
        ),
        scope: str = typer.Option(
            BACKUP_SCOPE_STANDARD,
            "--scope",
            help=f"Backup scope: {BACKUP_SCOPE_MINIMAL} (volumes only), {BACKUP_SCOPE_STANDARD} (volumes+recipes+networks), {BACKUP_SCOPE_FULL} (everything)"
        ),
    ):
        """Run a cold backup for selected units (or all)."""
        cmd_backup(ctx, unit, dry_run, update_recovery_bundle, scope)

    @app.command("restore")
    def _restore_cmd(
        ctx: typer.Context,
        yes: bool = typer.Option(
            False,
            "--yes", "-y",
            help="Non-interactive mode: auto-confirm all prompts (for CI/CD and scripts)"
        ),
        advanced: bool = typer.Option(
            False,
            "--advanced",
            help="Cross-machine restore: show backups from ALL machines in repository"
        ),
    ):
        """Launch the interactive restore wizard.

        Use --advanced for cross-machine restore (e.g., restoring from a crashed server).
        """
        cmd_restore(ctx, yes=yes, advanced=advanced)
