#!/usr/bin/env python3
"""
Setup script for NICQS package with C extension support.

This setup.py is needed to properly build the hiper C extension module.
The main package configuration is in pyproject.toml.
"""

from setuptools import setup, Extension

# Define the hiper C extension
# This extension provides high-performance calculations for the solver
hiper_extension = Extension(
    name="hiper",
    sources=["nicqs/lib/hiper/hiper.c"],
)

# Setup will read most configuration from pyproject.toml
# but we need to explicitly define the C extension here
setup(
    ext_modules=[hiper_extension],
)
