#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
from 	matplotlib.animation 	import FuncAnimation
from    matplotlib              import cm
import pandas as pd
import yaml
import pickle
import os
from    mpl_toolkits.axes_grid1 import make_axes_locatable

class plotter_v2:
    # This plotter will only be used to create gifs from the Paraview output files

    # paths
    rpath = ''
    input2 = None
    parameter = None
    time_unit = 'ms'
    current_input = None

    fig = plt.figure(figsize=(6,5)) # plt.figure(figsize=(8,6)) # AMS 14,5
    ax = fig.add_subplot(111)
    plot_every= 1

    # Data
    input_data = None
    limits = None

    colormap = cm.seismic #cm.gist_heat #cm.YlGn

    # no_title = False
    # no_bars = False
    # no_axis = False
    # custom_title = None

    # Grid EUCAS BERNARDO
    # xmin= 0.0
    # xmax= 0.3
    # ymin= -0.5
    # ymax= 0.5
    # nx= 30
    # ny= 60

    # # Grid EUCAS BERNARDO
    # xmin= 0.0
    # xmax= 0.3
    # ymin= -0.4
    # ymax= 0.4
    # nx= 30
    # ny= 60

    # # Grid AMS
    # xmin = 0.0
    # xmax = 8.0
    # ymin = -5
    # ymax = 5
    # nx = 20
    # ny = 40
    # Bmin = 0.0
    # Bmax = 0.8

    # Grid 40T Solenoid
    xmin = 0.0
    xmax = 0.3
    # ymin = -0.4
    # ymax = 0.4
    ymin = -0.5
    ymax = 0.5
    nx = 30
    ny = 60
    # Bmin = 0.0
    # Bmax = 45
    #
    # # Grid tree
    # xmin = 0.0
    # xmax = 0.3
    # ymin = -0.4
    # ymax = 0.4
    # nx = 30
    # ny = 80
    Bmin = 0.0
    Bmax = 20.0

    rotate_90 = False

    custom_title = None

    no_title = False
    no_bars = False
    no_axis = True

    def __init__(self, rpath, parameter='', input2 = None, time_unit = 'ms', current_input='NICQS', rot90 = False, Bmax=20.0):
        self.rpath = rpath
        self.input2 = input2
        self.parameter = parameter
        self.time_unit = time_unit
        self.current_input = current_input
        self.rotate_90 = rot90
        self.Bmax=Bmax

        self.load_yaml()
        self.load_current()
        self.initiate_figure()

        self.make_gif()

    def initiate_figure(self):
        if self.rotate_90:
            self.figsize = (2 + 6 / (2 * self.xmax / (self.ymax - self.ymin)), 6)
        else:
            self.figsize = (8, 6 / (2 * self.xmax / (self.ymax - self.ymin)))
        self.fig = plt.figure(figsize=self.figsize)
        self.ax = self.fig.add_subplot(111)
        self.axb = self.ax.twinx()

    def load_yaml(self):
        # Reads the contents of the yaml file
        if self.current_input == 'NICQS':
            with open(self.rpath + os.sep + 'Paraview' + os.sep + 'python_files_to_load_' + self.parameter + '.yaml') as file:
                data = yaml.load(file, Loader=yaml.FullLoader)
                self.input_data = data['data']
                self.limits = data['limits']

        with open(self.input2 + os.sep + 'geometry.yaml') as file:
            data = yaml.load(file, Loader=yaml.FullLoader)
            self.positions_outer = data['positions_outer']
            grid_information = data['grid_information']
            # Grid tree
            self.xmin = grid_information[0]
            self.xmax = grid_information[1]
            self.ymin = grid_information[2]
            self.ymax = grid_information[3]
            self.nx = grid_information[4]
            self.ny = grid_information[5]


    def load_current(self):
        if self.current_input == 'Xyce':
            self.current_II_values = pd.read_csv(self.rpath + os.sep + 'currents.csv', delimiter=',', on_bad_lines='skip')
            self.len_entries = len(self.current_II_values)
            self.index_values = np.arange(0, self.len_entries, int(np.ceil(self.len_entries / 100)))  # TODO GHETTO FIX
            self.time_steps = self.current_II_values['TIME'].values[self.index_values]
        else:
            self.current_II_values = pd.read_csv(self.rpath + os.sep + 'current.csv')
            self.len_entries = len(self.current_II_values)
            # self.index_values = np.arange(0, self.len_entries, int(np.ceil(self.len_entries/len(list(self.input_data.keys()))))) # TODO GHETTO FIX
            self.index_values = [i for i in takespread(np.arange(self.len_entries), len(list(self.input_data.keys())))]
            self.time_steps = list(self.input_data.keys())

            n = 0
            for i in self.index_values:
                print(self.current_II_values.iloc[i].values[0])
                print(list(self.input_data.keys())[n])
                n+=1

        # Loading fieldmaps
        path = self.input2 + os.sep + 'Bz_full.pkl'
        try:
            with open(path, 'rb') as fin:
                self.Bz_full = pickle.load(fin)
        except OSError:
            print("Loading of %s has failed." % (path))
        else:
            print("Successfully loaded %s" % (path))
        path = self.input2 + os.sep + 'Br_full.pkl'
        try:
            with open(path, 'rb') as fin:
                self.Br_full = pickle.load(fin)
        except OSError:
            print("Loading of %s has failed." % (path))
        else:
            print("Successfully loaded %s" % (path))

        if self.current_input == 'Xyce':
            path = self.rpath + os.sep + 'current.pkl'
            try:
                with open(path, 'rb') as fin:
                    self.I = pickle.load(fin)
            except OSError:
                print("Loading of %s has failed." % (path))
            else:
                print("Successfully loaded %s" % (path))

            n = self.Bz_full.shape[1]
            self.columnlist = ['I(L' + str(i) +')' for i in range(n)]



    def make_gif(self):

        try:
            os.mkdir(self.rpath + os.sep  + 'GIFs')
        except OSError:
            print("Creation of the directory %s failed" % self.rpath + os.sep  + 'GIFs')
        else:
            print("Successfully created the directory %s " % self.rpath + os.sep  + 'GIFs')



        # self.limits['minmax'][1] = 0.5 * self.limits['minmax'][1]

        # Plot the magnetic field:
        if self.current_input == 'NICQS':
            current = self.current_II_values.iloc[0].values[1:]
            self.time_steps = list(self.input_data.keys())
            print(len(self.time_steps), self.time_steps)
            step_data = self.input_data[self.time_steps[4]]
        elif self.current_input == 'Xyce':
            self.current_II_values = self.current_II_values[self.columnlist]
            current = self.current_II_values.iloc[0].values

        Bz = np.dot(self.Bz_full, current)
        Br = np.dot(self.Br_full, current)

        if self.rotate_90:
            self.xv, self.yv = np.meshgrid(np.linspace(self.ymin, self.ymax, self.ny), np.linspace(-self.xmax, self.xmax, 2*self.nx-1))
            CS1 = self.ax.contourf(np.linspace(self.ymin, self.ymax, self.ny), np.linspace(self.xmin, self.xmax, self.nx), np.rot90(((Br**2 + Bz**2) ** 0.5).reshape((self.ny, self.nx))), cmap=cm.coolwarm, levels=np.linspace(0, self.Bmax, 21), vmin=self.Bmin, vmax=self.Bmax)

            if self.current_input == 'Xyce':
                for i in range(len(self.positions_outer)):
                    [self.axb.plot(j[1], -1 * np.array(j[0]), color='black') for j in self.positions_outer[i]]
                    [self.axb.plot(j[1], j[0], color='black') for j in self.positions_outer[i]]
        else:
            self.xv, self.yv = np.meshgrid(np.linspace(-self.xmax, self.xmax, (2 * self.nx) - 1), np.linspace(self.ymin, self.ymax, self.ny))
            CS1 = self.ax.contourf(np.linspace(self.xmin, self.xmax, self.nx), np.linspace(self.ymin, self.ymax, self.ny), ((Br ** 2 + Bz ** 2) ** 0.5).reshape((self.ny, self.nx)), cmap=cm.coolwarm, levels=np.linspace(0, self.Bmax, 21), vmin=self.Bmin, vmax=self.Bmax)
            if self.current_input == 'Xyce':
                for i in range(len(self.positions_outer)):
                    [self.axb.plot(-1 * np.array(j[0]), j[1], color='black') for j in self.positions_outer[i]]
                    [self.axb.plot(j[0], j[1], color='black') for j in self.positions_outer[i]]

        if self.parameter in ['Fz_density', 'Fr_density']:
            self.limits['minmax'][0] *= 1e-9
            self.limits['minmax'][1] *= 1e-9

        if self.current_input == 'NICQS':
            for i in step_data:
                df = pd.read_csv(i)
                if self.parameter in ['Fz_density', 'Fr_density']:
                    # Going from N/m3 to N/mm3, purely because the values were too large (>1e10) and the arrays need to be cast to an int32 array.
                    # Max value of int32 is 2,147,483,647.
                    df['v'] *= 1e-9
                self.ax.tricontourf(df['x'].values, df['y'].values, df['v'].values, vmin=self.limits['minmax'][0], vmax=self.limits['minmax'][1], cmap=self.colormap)
                CS2 = self.ax.tricontourf(-1*df['x'].values, df['y'].values, df['v'].values, levels = np.linspace(self.limits['minmax'][0], self.limits['minmax'][1], 21), vmin=self.limits['minmax'][0], vmax=self.limits['minmax'][1], cmap=self.colormap)

        divider1 = make_axes_locatable(self.ax)
        # cax1 = divider1.append_axes('right', size='10%', pad=0.05)
        # cax2 = divider1.append_axes('right', size='10%', pad=0.05)

        if not self.no_bars:
            cbar = self.fig.colorbar(CS1, orientation='vertical')
            cbar.set_label('Magnetic Field, T')
            if self.current_input == 'NICQS':
                cbar2 = self.fig.colorbar(CS2, orientation='vertical', location='left')
                if self.parameter == 'T':
                    cbar2.set_label('Temperature, K')
                elif self.parameter == 'I_density':
                    cbar2.set_label('Current Density, A/mm$^2$')
                elif self.parameter in ['Fz_density', 'Fr_density']:
                    cbar2.set_label('Force Density, N/mm$^3$')

        if self.rotate_90:
            self.ax.set_ylim((-self.xmax, self.xmax))
            self.ax.set_xlim((self.ymin, self.ymax))
        else:
            self.ax.set_xlim((-self.xmax, self.xmax))
            self.ax.set_ylim((self.ymin, self.ymax))

        if not self.no_axis:
            if self.rotate_90:
                self.ax.set_aspect('equal', 'box')
                self.ax.set_xlabel('Axial position, m')
                self.ax.set_ylabel('Radial position, m')
            else:
                self.ax.set_aspect('equal', 'box')
                self.ax.set_xlabel('Radial position, m')
                self.ax.set_ylabel('Axial position, m')
            # self.fig.tight_layout()
        else:
            self.ax.tick_params(left = False, right = False , labelleft = False ,
                labelbottom = False, bottom = False)

        if self.custom_title is not None:
            self.ax.set_title(self.custom_title)

        print(self.time_steps)
        anim = FuncAnimation(self.fig, self.update_gif, frames=np.arange(0, len(self.time_steps), self.plot_every), interval=100)
        # IF YOU GET AN ERROR IN SAVING THE GIF -> DOWNLOAD IMAGEMAGICK
        # anim.save(fname, dpi=120, writer='imagemagick', fps=20)
        fname = self.rpath + os.sep  + 'GIFs' + os.sep + 'test_' + self.parameter + '.gif'
        anim.save(fname, dpi=100, fps=10)
        plt.close('all')

    def update_gif(self, i):
        # Updates the gif
        self.ax.clear()
        # self.axb.clear()

        print('Frame', i)

        if self.current_input == 'NICQS':
            step_data = self.input_data[self.time_steps[i]]
            current = self.current_II_values.iloc[self.index_values[i]].values[1:]
        elif self.current_input == 'Xyce':
            current = self.current_II_values.iloc[self.index_values[i]].values * self.I #TODO what is this self.I
        Bz = np.dot(self.Bz_full, current)
        Br = np.dot(self.Br_full, current)

        Bz = np.transpose(Bz.reshape((self.nx, self.ny)))
        Br = np.transpose(Br.reshape((self.nx, self.ny)))

        Bz = np.hstack([np.fliplr(Bz[:, 1:]), Bz])
        Br = np.hstack([-1 * np.fliplr(Br[:, 1:]), Br])

        print(np.max(((Br ** 2 + Bz ** 2) ** 0.5)))

        if self.rotate_90:
            self.ax.contourf(np.linspace(self.ymin, self.ymax, self.ny), np.linspace(-self.xmax, self.xmax, (2 * self.nx) - 1),
                             np.rot90((Br ** 2 + Bz ** 2) ** 0.5), cmap=cm.coolwarm,
                             levels=np.linspace(self.Bmin, self.Bmax, 21), vmin=self.Bmin, vmax=self.Bmax)

            self.ax.streamplot(self.xv, self.yv, -1*np.rot90(Bz), np.rot90(Br), density=2.0, linewidth=0.5, color='white')
            # for k in range(len(self.positions_outer)):
            #     [self.axb.plot(j[1], -1 * np.array(j[0]), color='black') for j in self.positions_outer[k]]
            #     [self.axb.plot(j[1], j[0], color='black') for j in self.positions_outer[k]]
        else:
            self.ax.contourf(np.linspace(-self.xmax, self.xmax, (2*self.nx)-1), np.linspace(self.ymin, self.ymax, self.ny),
                             ((Br ** 2 + Bz ** 2) ** 0.5), cmap=cm.coolwarm,
                             levels=np.linspace(self.Bmin, self.Bmax, 21), vmin=self.Bmin, vmax=self.Bmax)

            self.ax.streamplot(self.xv, self.yv, Br, Bz, density=2.0, linewidth=0.5, color='white')

        if self.current_input == 'NICQS':
            if self.rotate_90:
                for j in step_data:
                    df = pd.read_csv(j)
                    if self.parameter in ['Fz_density', 'Fr_density']:
                        # Going from N/m3 to N/mm3, purely because the values were too large (>1e10) and the arrays need to be cast to an int32 array.
                        # Max value of int32 is 2,147,483,647.
                        df['v'] *= 1e-9

                    self.ax.tricontourf(df['y'].values, df['x'].values, df['v'].values, levels = np.linspace(self.limits['minmax'][0], self.limits['minmax'][1], 21), cmap=self.colormap)#vmin=self.limits['minmax'][0], vmax=self.limits['minmax'][1], cmap=cm.gist_heat)
                    self.ax.tricontourf(df['y'].values, -1*df['x'].values, df['v'].values, levels = np.linspace(self.limits['minmax'][0], self.limits['minmax'][1], 21), cmap=self.colormap)#vmin=self.limits['minmax'][0], vmax=self.limits['minmax'][1], cmap=cm.gist_heat)
            else:
                for j in step_data:
                    df = pd.read_csv(j)
                    # print(i, j, np.min(df['v'].values), np.max(df['v'].values))
                    self.ax.tricontourf(df['x'].values, df['y'].values, df['v'].values, levels = np.linspace(self.limits['minmax'][0], self.limits['minmax'][1], 21), cmap=self.colormap)#vmin=self.limits['minmax'][0], vmax=self.limits['minmax'][1], cmap=cm.gist_heat)
                    self.ax.tricontourf(-1*df['x'].values, df['y'].values, df['v'].values, levels = np.linspace(self.limits['minmax'][0], self.limits['minmax'][1], 21), cmap=self.colormap)#vmin=self.limits['minmax'][0], vmax=self.limits['minmax'][1], cmap=cm.gist_heat)

        if not self.no_title:
            if self.time_unit == 'ms':
                self.ax.set_title('t = ' + str(np.round((self.time_steps[i]-self.time_steps[0]) * 1e3)) + ' ms')
            elif self.time_unit == 's':
                self.ax.set_title('t = ' + str(np.round((self.time_steps[i]-self.time_steps[0]))) + ' s')
            elif self.time_unit == 'h':
                t = (self.time_steps[i]-self.time_steps[0]) / 3600
                self.ax.set_title('t = ' + str(int(t)) + 'h' + str(int(t*60)%60) + 'm')

        if self.custom_title is not None:
            self.ax.set_title(self.custom_title)

        if self.rotate_90:
            self.ax.set_ylim((-self.xmax, self.xmax))
            self.ax.set_xlim((self.ymin, self.ymax))
            self.axb.set_ylim((-self.xmax, self.xmax))
            self.axb.set_xlim((self.ymin, self.ymax))
        else:
            self.ax.set_xlim((-self.xmax, self.xmax))
            self.ax.set_ylim((self.ymin, self.ymax))
            self.axb.set_xlim((-self.xmax, self.xmax))
            self.axb.set_ylim((self.ymin, self.ymax))
        # self.ax.set_aspect('equal', 'box')

        self.fig.savefig(self.rpath + os.sep  + 'GIFs' + os.sep + self.parameter + '_' + str(i) + '.png', dpi=300)

def takespread(sequence, num):
    length = float(len(sequence))
    for i in range(num):
        yield sequence[int(np.ceil(i * length / num))]

if __name__ == "__main__":
        print('No input yaml file provided, using the NI_Coil_Quench_2D_input.yaml file.')
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_2_output/results/result - 2023-08-21 - 0.1 - 3'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_2_output'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_4_MT_output/results/result - 2023-09-04 - 0.1 - 1'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_4_MT_output'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_4_MT_output/results/result - 2023-09-08 - 0.1 - 5'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_4_MT_output'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_2_output/results/result - 2023-10-09 - 0.1 - 1'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_2_output'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/AMS_100/results/result - 2023-12-05 - 0.1 - 7/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/AMS_100/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/tree/results/result - 2023-12-05 - 0.1 - 3/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/tree/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_FCS_output/results/result - 2024-03-09 - 0.1 - 3/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_FCS_output/
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_FCS_c_output/results/result - 2024-03-26 - 0.1 - 1/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_FCS_c_output/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_FCS_e_output/results/result - 2024-04-02 - 0.1 - 1/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_23_FCS_e_output/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/Muon Collider Final Cooling/Simulations/6D Cooling - Netlists'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_6D_cooling_B7_output'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_28_FCS/results/result - 2024-05-28 - 0.1 - 4/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_28_FCS/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_29_AMS_100_v2/results/result - 2024-07-03 - 0.1 - 5/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_29_AMS_100_v2/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_29_AMS_100_v3/results/result - 2024-09-23 - 0.1 - 2/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/test_geometry_29_AMS_100_v3/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/FCS_750_Torch_1/results/result - 2025-05-09 - Quench6 - 5/'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/FCS_750_Torch_1/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_v24/results/result - 2025-07-21 - ramp-100 - 9'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_v24/'
        input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_v24_lattice/results/result - 2025-07-21 - 2'
        input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_v24_lattice/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_lattice_copper/results/result - 2025-05-05 - 2'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_lattice_copper/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_lattice_copper2/results/result - 2025-05-07 - 1'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_lattice_copper2/'
        # input1 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_lattice_copper3/results/result - 2025-05-06 - 1'
        # input2 = 'C:/Tim Mulder/CERNBox/Staff - TE-MPE-PE/Projects/ni-coils/geometry/output/muon_6D_demonstrator_lattice_copper3/'

        # ptr = plotter_v2(input1, 'I_density', input2 = input2, time_unit = 's', current_input = 'Xyce', rot90=True, Bmax=15.0)
        # ptr = plotter_v2(input1, 'T', input2 = input2, time_unit = 'ms', rot90=True, Bmax=45.0)
        # ptr = plotter_v2(input1, 'I_density', input2 = input2, time_unit = 's', rot90=True, Bmax=16)
        ptr = plotter_v2(input1, 'Fz_density', input2 = input2, time_unit = 'ms', rot90=True, Bmax=16)