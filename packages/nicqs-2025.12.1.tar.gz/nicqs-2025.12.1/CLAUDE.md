# NICQS: No-Insulation Coil Quench Simulator

## Overview
- Python Thermo-electromagnetic modeling tool to simulate transients in No-Insulation (NI) HTS magnets.
- 2D, homogenized, python ODE solver.

## Development
- Python 3.10+

## Standards
- Use type hints
- Add lots of comments and explain why certain methods are chosen.
- Max line length: 88 chars
- Prefer composition over inheritance

## Context
- Main file for geometry creation: NI_Coil_Geometry.py
- Main solver file: NI_Coil_Solver_Torch.py
- A second solver, mainly for debugging and testing: NI_Coil_Solver_Light.py
- lib/debugging.py is a class for graphs and debugging tools.
- lib/utils.py is a class with small utility functions, e.g. for formatting text.
- lib/materials.py contains a class with functions for material properties. 
- Assume I’m using Windows 11 with Command Prompt, not Linux. Use Windows CLI syntax by default.
- I am not always correct, try to be objective.