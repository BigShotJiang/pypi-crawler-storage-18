#!/usr/bin/env python3
"""
Summary Plotter for NI Coil Simulation Results

This module provides plotting functionality for summary data from NI coil simulations.
The main plotter class has been moved to lib/debugging.py for better organization.

Usage:
    # Using YAML configuration (recommended):
    from lib.debugging import SummaryPlotter
    plotter = SummaryPlotter.from_yaml('config.yaml')
    plotter.create_plot()
    
    # Using direct parameters (legacy):
    from lib.debugging import SummaryPlotter
    plotter = SummaryPlotter(
        input_paths=[...],
        labels=[...],
        parameters=['T', 'Fr_density']
    )
    plotter.create_plot()
"""

import os
import sys

# Add lib directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'lib'))

from lib.debugging import SummaryPlotter, plotter_v3  # plotter_v3 is legacy alias

if __name__ == "__main__":
    """
    Example usage of the SummaryPlotter.
    
    This demonstrates both YAML-based configuration (recommended) 
    and direct parameter usage (legacy support).
    """
    
    # Example 1: Using YAML configuration (recommended approach)
    # Uncomment the following lines to use YAML configuration:
    #
    plotter = SummaryPlotter.from_yaml('utils/gl_plotter_config.yaml')
    plotter.create_plot()
    
    # Example 2: Direct parameter usage (legacy support)
    # This maintains backward compatibility with the old plotter_v3 interface
    
    sweep_str = '2025-07-10 - Sweep_FCS_gianluca_tau_1_sweep'
    base_path = 'C:\\Tim Mulder\\CERNBox\\Staff - TE-MPE-PE\\Projects\\ni-coils\\geometry\\output\\FCS_750_Torch_7\\results\\'
    
    inputs = [
        base_path + 'result - ' + sweep_str + '_0 - 2',
        base_path + 'result - ' + sweep_str + '_1 - 2', 
        base_path + 'result - ' + sweep_str + '_2 - 1',
        base_path + 'result - ' + sweep_str + '_3 - 1',
        base_path + 'result - ' + sweep_str + '_4 - 1',
    ]
    
    labels = ['Config 0', 'Config 1', 'Config 2', 'Config 3', 'Config 4']
    
    # Create plotter with direct parameters
    plotter = SummaryPlotter(
        input_paths=inputs,
        labels=labels,
        parameters=['T', 'Fr_density'],
        tag='Sweep-gianluca-margin-2',
        output_filename='Muon_ASC_Paper.png',
        show_plot=True
    )
    
    # Generate the plot
    plotter.create_plot()
    
    print("Plot generation complete!")
    print("To use YAML configuration instead, create a .yaml file")
    print("following the format in utils/sample_plotter_config.yaml")
