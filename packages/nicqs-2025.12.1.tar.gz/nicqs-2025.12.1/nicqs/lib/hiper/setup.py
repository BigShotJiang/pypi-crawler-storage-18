#!/usr/bin/env python3

from setuptools import setup, Extension

setup(
    name="hiper",
    version="1.0",
    ext_modules=[
        Extension("hiper", ["hiper.c"])
    ]
)