def fit_angle_dependency(fit_name):
    fit_list = [
        'CFUN_HTS_JcFit_Fujikura_v1',
        'CFUN_HTS_JcFit_SUPERPOWER_v1',
        'CFUN_HTS_JcFit_THEVA_v1',
        'CFUN_HTS_JcFit_sunam_v1',
    ]
    return fit_name in fit_list

def fit_Field_dependency(fit_name):
    fit_list = {
        'CFUN_HTS_JcFit_Fujikura_v1',
        'CFUN_HTS_JcFit_SUPERPOWER_v1',
        'CFUN_HTS_JcFit_Succi_v2',
        'CFUN_HTS_JcFit_THEVA_v1',
        'CFUN_HTS_JcFit_sunam_v1',
    }
    return fit_name in fit_list