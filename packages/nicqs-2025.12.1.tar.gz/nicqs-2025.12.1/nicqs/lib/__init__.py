"""
NICQS Library Module

Core utilities and helper functions for NICQS.
"""

from .inductance import (
    loop_mutual_inductance,
    loop_self_inductance,
    inductance_for_paths,
    radial_inductance_numeric
)
from .cli import ProgressBar, var_dump, print_nicqs_logo
from .torch_interp import RegularGridInterpolator
from .soleno import soleno_calculate_field
from .LUT import fit_angle_dependency, fit_Field_dependency

__all__ = [
    "loop_mutual_inductance",
    "loop_self_inductance",
    "inductance_for_paths",
    "radial_inductance_numeric",
    "ProgressBar",
    "var_dump",
    "print_nicqs_logo",
    "RegularGridInterpolator",
    "soleno_calculate_field",
    "fit_angle_dependency",
    "fit_Field_dependency",
]
