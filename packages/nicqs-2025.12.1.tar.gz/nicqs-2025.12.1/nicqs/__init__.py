"""
NICQS: No-Insulation Coil Quench Simulator

A Python-based thermo-electromagnetic modeling tool for simulating transients
in No-Insulation (NI) HTS magnets using a 2D homogenized approach.
"""

try:
    from ._version import version as __version__
except ImportError:
    # Package is not installed, use placeholder
    __version__ = "0.0.0.dev0"

__author__ = "Tim Mulder"
__email__ = "tim.mulder@cern.ch"

# Import commonly used functions from lib for convenience
from .lib import (
    ProgressBar,
    var_dump,
    print_nicqs_logo,
    loop_mutual_inductance,
    loop_self_inductance,
    inductance_for_paths,
    radial_inductance_numeric,
    RegularGridInterpolator,
    soleno_calculate_field,
    fit_angle_dependency,
    fit_Field_dependency,
)

__all__ = [
    "__version__",
    "ProgressBar",
    "var_dump",
    "print_nicqs_logo",
    "loop_mutual_inductance",
    "loop_self_inductance",
    "inductance_for_paths",
    "radial_inductance_numeric",
    "RegularGridInterpolator",
    "soleno_calculate_field",
    "fit_angle_dependency",
    "fit_Field_dependency",
]