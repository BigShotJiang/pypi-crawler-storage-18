#!/usr/bin/env python3
"""
Simple runner script for NICQS simulations.
Uncomment the lines you want to run.
"""
import sys
import subprocess

# Example: Final Cooling Solenoid
subprocess.call([sys.executable, '-m', 'nicqs.geometry', 'input_yaml/Final_Cooling/FCS_750_7_2025.yaml', 'geometry/output/FCS_750_7_2025'])
subprocess.call([sys.executable, '-m', 'nicqs.solver_torch', 'geometry/output/FCS_750_7_2025/solver_input.yaml'])

