# Victor LLM Provider Setup Guide

This guide provides step-by-step instructions for setting up all 26 supported LLM providers in Victor.

## Table of Contents

- [Provider Overview](#provider-overview)
- [Quick Start](#quick-start)
- [Local Providers (FREE - No API Key)](#local-providers)
  - [Ollama](#ollama)
  - [LM Studio](#lm-studio)
  - [vLLM](#vllm)
- [Free-Tier Cloud Providers](#free-tier-cloud-providers)
  - [Groq Cloud](#groq-cloud) - Fastest inference, 14.4K req/day
  - [Cerebras](#cerebras) - Ultra-fast WSE, 14.4K req/day
  - [Google AI Studio](#google-ai-studio) - Gemini free tier
  - [Mistral AI](#mistral-ai) - European, 500K tok/min
  - [Together AI](#together-ai) - $25 free credits
  - [OpenRouter](#openrouter) - Model gateway, 50 req/day
  - [Fireworks AI](#fireworks-ai) - $1 free credits
  - [Hugging Face](#hugging-face) - 300+ open models
- [Premium API Providers](#premium-api-providers)
  - [Anthropic (Claude)](#anthropic-claude)
  - [OpenAI (GPT-4)](#openai-gpt-4)
  - [xAI (Grok)](#xai-grok)
  - [DeepSeek](#deepseek)
  - [Moonshot (Kimi)](#moonshot-kimi)
- [Enterprise Cloud Providers](#enterprise-cloud-providers)
  - [Google Cloud Vertex AI](#google-cloud-vertex-ai)
  - [Azure OpenAI](#azure-openai)
  - [AWS Bedrock](#aws-bedrock)
- [Open Model Platforms](#open-model-platforms)
  - [Replicate](#replicate)
- [Troubleshooting](#troubleshooting)

---

## Provider Overview

![Victor Provider Ecosystem](../assets/provider-comparison.svg)

*Victor supports 26 LLM providers organized by cost. Free options are listed first.*

### Provider Comparison (Updated December 2025)

| Provider | Cost | Daily Limits | Tool Calling | Speed | Best For |
|----------|------|--------------|--------------|-------|----------|
| **Ollama** | 🆓 Free | Unlimited | ✅ | Hardware | Privacy, offline |
| **LM Studio** | 🆓 Free | Unlimited | ✅ | Hardware | Desktop GUI |
| **vLLM** | 🆓 Free | Unlimited | ✅ | Hardware | Production local |
| **Groq Cloud** | 🆓 Free | 14.4K req | ✅ | 300+ tok/s | Fastest inference |
| **Cerebras** | 🆓 Free | 14.4K req | ✅ | 1K tok/s | Ultra-fast WSE |
| **Google AI** | 🆓 Free | 100-250 RPD | ✅ | Fast | Gemini models |
| **Mistral AI** | 🆓 Free | 500K tok/min | ✅ | Fast | EU data residency |
| **Together AI** | 🎁 $25 | Credit-based | ✅ | Fast | Open model variety |
| **OpenRouter** | 🆓 Free | 50-1000 req | ✅ | Varies | Model gateway |
| **Fireworks AI** | 🎁 $1 | Credit-based | ✅ | Fast | Fast inference |
| **Hugging Face** | 🆓 Free | Rate limited | ✅ | Varies | 300+ models |
| **Anthropic** | 💰 Paid | Pay-per-token | ✅ | Fast | Best reasoning |
| **OpenAI** | 💰 Paid | Pay-per-token | ✅ | Fast | GPT-4, DALL-E |
| **xAI** | 💰 Paid | Pay-per-token | ✅ | Fast | Grok models |
| **DeepSeek** | 💰 Paid | Pay-per-token | ✅ | Fast | Reasoning |
| **Moonshot** | 💰 Paid | Pay-per-token | ✅ | Fast | Kimi K2 |
| **Vertex AI** | 💰 Enterprise | Pay-per-token | ✅ | Fast | GCP integration |
| **Azure OpenAI** | 💰 Enterprise | Pay-per-token | ✅ | Fast | Azure integration |
| **AWS Bedrock** | 💰 Enterprise | Pay-per-token | ✅ | Fast | AWS integration |
| **Replicate** | 💰 Pay/sec | Pay-per-second | ❌ | Varies | Custom models |

---

## Quick Start

![Provider Setup in 3 Steps](../assets/provider-quickstart.svg)

### Credential Storage Options

| Priority | Method | Command | Best For |
|----------|--------|---------|----------|
| 1 | **Keyring** (Recommended) | `victor keys --set groq --keyring` | Desktop, security |
| 2 | Environment Variable | `export GROQCLOUD_API_KEY="gsk_..."` | CI/CD, containers |
| 3 | Config File | `victor keys --setup` | Quick testing |

### Quick Commands

```bash
# List available providers
victor providers

# Store API key in system keyring (most secure)
victor keys --set groqcloud --keyring

# Create/edit profile
# Add to ~/.victor/profiles.yaml:
# profiles:
#   default:
#     provider: groqcloud
#     model: llama-3.3-70b-versatile

# Test your setup
victor chat -p groqcloud "Hello, world!"

# Start interactive TUI
victor
```

---

## Local Providers

**🆓 Completely Free - Run AI Models on Your Hardware**

These providers run models locally on your machine - no API keys, no rate limits, no cost. Perfect for privacy-sensitive work, offline development, and air-gapped environments.

---

### Ollama

The easiest way to run LLMs locally. One-command installation, supports 100+ models.

```bash
# Install (macOS/Linux)
curl -fsSL https://ollama.com/install.sh | sh

# Windows: Download from https://ollama.com/download

# Pull a model and start chatting
ollama pull llama3.3
victor chat -p ollama "Hello, world!"
```

**Models:** Llama 3.3 70B, Qwen 2.5, Mistral, Code Llama, Phi-3
**Best For:** Easy setup, hobbyist use, testing

---

### LM Studio

Desktop GUI for running GGUF models. Download, configure, and run with a visual interface.

```bash
# Download from https://lmstudio.ai
# 1. Launch LM Studio
# 2. Download a model from the built-in browser
# 3. Start the local server (settings icon)
# 4. Connect Victor:

victor chat -p lmstudio "Hello, world!"
```

**Models:** Any GGUF model (TheBloke quantizations, etc.)
**Best For:** Desktop users, model experimentation, custom quantizations

---

### vLLM

High-throughput inference server for production workloads. Best performance for concurrent requests.

```bash
# Install
pip install vllm

# Start server
python -m vllm.entrypoints.openai.api_server --model meta-llama/Meta-Llama-3-8B-Instruct

# Use with Victor
victor chat -p vllm "Hello, world!"
```

**Models:** Any HuggingFace model
**Best For:** Production local deployments, high concurrency, GPU utilization

---

## Free-Tier Cloud Providers

**🎁 Generous Free Tiers - No Credit Card Required**

These providers offer substantial free tiers - perfect for experimentation, prototyping, and personal use.

---

### Groq Cloud

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              GROQ CLOUD                                      │
│                     Ultra-Fast LPU Inference                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│  FREE TIER:  14,400 requests/day  •  60K tokens/min  •  No credit card      │
│  SPEED:      300-1000+ tokens/sec (fastest available!)                      │
│  MODELS:     Llama 3.3 70B, Llama 3.1 8B/70B/405B, Mixtral 8x7B, GPT-oss   │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  🌐 Go to: https://console.groq.com                      │  │
│  │  📧 Sign up with email or Google/GitHub                  │  │
│  │  ✅ Verify email (check spam folder)                     │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 2: Get API Key                                           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  1. Go to API Keys section                               │  │
│  │  2. Click "Create API Key"                               │  │
│  │  3. Name it (e.g., "victor")                             │  │
│  │  4. Copy key: gsk_xxxxxxxxxxxxxxxxxxxxxxxx               │  │
│  │  ⚠️  Key shown only once - save it immediately!         │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor (Choose one method)                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  # RECOMMENDED: Store in system keyring (most secure)    │  │
│  │  victor keys --set groqcloud --keyring                   │  │
│  │  # Paste your API key when prompted                      │  │
│  │                                                          │  │
│  │  # OR: Environment variable (good for CI/CD)             │  │
│  │  export GROQCLOUD_API_KEY="gsk_your_key_here"            │  │
│  │                                                          │  │
│  │  # OR: Config file (least secure)                        │  │
│  │  victor keys --setup  # Creates ~/.victor/api_keys.yaml  │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
# ~/.victor/profiles.yaml
profiles:
  groqcloud:
    provider: groqcloud
    model: llama-3.3-70b-versatile
    description: "Fastest 70B inference - 30 req/min free"

  groq-fast:
    provider: groqcloud
    model: llama-3.1-8b-instant
    description: "Ultra-fast 8B - higher rate limits"
```

#### Test Command

```bash
victor chat -p groqcloud "List 3 Python best practices"
```

---

### Cerebras

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                               CEREBRAS                                       │
│                    Wafer-Scale Engine (WSE) Inference                        │
├─────────────────────────────────────────────────────────────────────────────┤
│  FREE TIER:  30 requests/min  •  60-150K tokens/min  •  No credit card      │
│  SPEED:      1000-2000+ tokens/sec (world's fastest!)                       │
│  MODELS:     Llama 3.3 70B, Llama 3.1 8B, Qwen 2.5 32B/Coder                │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  🌐 Go to: https://cloud.cerebras.ai                     │  │
│  │  📧 Sign up with email                                   │  │
│  │  ✅ Verify email and complete profile                    │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 2: Get API Key                                           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  1. Navigate to "API Keys" in dashboard                  │  │
│  │  2. Click "Create new secret key"                        │  │
│  │  3. Copy key: csk-xxxxxxxxxxxxxxxxxxxxxxxx               │  │
│  │  ⚠️  Save immediately - not shown again!                │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  export CEREBRAS_API_KEY="csk_your_key_here"             │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  cerebras:
    provider: cerebras
    model: llama3.3-70b
    description: "World's fastest inference (WSE hardware)"

  cerebras-coder:
    provider: cerebras
    model: qwen-2.5-coder-32b
    description: "Fast code generation"
```

#### Test Command

```bash
victor chat -p cerebras "Write a Python function to reverse a string"
```

---

### Mistral AI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              MISTRAL AI                                      │
│                    European AI - GDPR Compliant                              │
├─────────────────────────────────────────────────────────────────────────────┤
│  FREE TIER:  500K tokens/min  •  No credit card required                    │
│  MODELS:     Mistral Large (128K), Mistral Small, Codestral                 │
│  FEATURE:    European data residency, GDPR compliant                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  🌐 Go to: https://console.mistral.ai                    │  │
│  │  📧 Sign up with email or SSO                            │  │
│  │  ✅ No credit card needed for free tier                  │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 2: Get API Key                                           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  1. Go to "API Keys" tab                                 │  │
│  │  2. Click "Create new key"                               │  │
│  │  3. Copy the key (starts with no prefix)                 │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  export MISTRAL_API_KEY="your_key_here"                  │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  mistral:
    provider: mistral
    model: mistral-large-latest
    description: "Mistral Large - 128K context, best quality"

  codestral:
    provider: mistral
    model: codestral-latest
    description: "Codestral - optimized for code"
```

---

### Together AI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             TOGETHER AI                                      │
│                    Open Model Infrastructure                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│  FREE TIER:  $25 free credits on signup  •  No expiration                   │
│  MODELS:     Llama 3.3 70B, Qwen 2.5 72B, DeepSeek V3, Mixtral              │
│  FEATURE:    Wide model selection, fast inference                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  🌐 Go to: https://api.together.xyz                      │  │
│  │  📧 Sign up with email or GitHub                         │  │
│  │  💰 $25 free credits added automatically!                │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 2: Get API Key                                           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  1. Go to Settings → API Keys                            │  │
│  │  2. Copy your API key                                    │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  export TOGETHER_API_KEY="your_key_here"                 │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  together:
    provider: together
    model: meta-llama/Llama-3.3-70B-Instruct-Turbo
    description: "Together AI Llama 3.3 70B"

  together-deepseek:
    provider: together
    model: deepseek-ai/DeepSeek-V3
    description: "DeepSeek V3 671B MoE"
```

---

### OpenRouter

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                             OPENROUTER                                       │
│                    Unified Gateway to 100+ Models                            │
├─────────────────────────────────────────────────────────────────────────────┤
│  FREE TIER:  20 req/min, 50 req/day  •  Free models available               │
│  MODELS:     Claude, GPT-4, Gemini, Llama, Mistral (100+ models)            │
│  FEATURE:    Single API for all providers, automatic fallback               │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  🌐 Go to: https://openrouter.ai                         │  │
│  │  📧 Sign up with email or OAuth                          │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 2: Get API Key                                           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  1. Go to "Keys" section                                 │  │
│  │  2. Create new key                                       │  │
│  │  3. Key starts with: sk-or-v1-xxxxx                      │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  export OPENROUTER_API_KEY="sk-or-v1-your_key"           │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  openrouter:
    provider: openrouter
    model: google/gemini-2.0-flash-exp:free
    description: "FREE Gemini Flash with tool calling"

  openrouter-free:
    provider: openrouter
    model: mistralai/mistral-7b-instruct:free
    description: "FREE Mistral 7B (no tools)"
```

---

### Fireworks AI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            FIREWORKS AI                                      │
│                    High-Performance Model Serving                            │
├─────────────────────────────────────────────────────────────────────────────┤
│  FREE TIER:  $1 free credits  •  6000 requests/min                          │
│  MODELS:     Llama 3.3 70B, Llama 3.1 405B, Qwen 2.5, DeepSeek V3           │
│  FEATURE:    Very fast inference, wide model selection                       │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                        │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  🌐 Go to: https://fireworks.ai                          │  │
│  │  📧 Sign up and verify email                             │  │
│  │  💰 $1 free credits added automatically                  │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 2: Get API Key                                           │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  1. Go to API Keys in dashboard                          │  │
│  │  2. Create new API key                                   │  │
│  │  3. Key format: fw_xxxxxxxxxxxxx                         │  │
│  └──────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor                                      │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  export FIREWORKS_API_KEY="fw_your_key_here"             │  │
│  └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  fireworks:
    provider: fireworks
    model: accounts/fireworks/models/llama-v3p3-70b-instruct
    description: "Fireworks Llama 3.3 70B"

  fireworks-qwen:
    provider: fireworks
    model: accounts/fireworks/models/qwen2p5-72b-instruct
    description: "Fireworks Qwen 2.5 72B"
```

---

## Enterprise Cloud Providers

These providers are for production workloads requiring enterprise security, compliance, and SLAs.

---

### Google Cloud Vertex AI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         GOOGLE CLOUD VERTEX AI                               │
│                    Enterprise Gemini + Google AI                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  PRICING:   Pay-per-use  •  $300 free trial credits for new accounts        │
│  MODELS:    Gemini 1.5 Pro (2M ctx), Gemini 1.5 Flash, Gemini 2.0           │
│  FEATURES:  VPC-SC, CMEK encryption, SLA guarantees, data residency         │
│  AUTH:      Service Account, ADC, Workload Identity                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         VERTEX AI AUTHENTICATION                             │
│                                                                              │
│  ┌─────────────┐     ┌─────────────┐     ┌─────────────┐                    │
│  │  Service    │     │  Application│     │  Workload   │                    │
│  │  Account    │     │  Default    │     │  Identity   │                    │
│  │  (JSON key) │     │  Credentials│     │  (GKE)      │                    │
│  └──────┬──────┘     └──────┬──────┘     └──────┬──────┘                    │
│         │                   │                   │                            │
│         └───────────────────┼───────────────────┘                            │
│                             ▼                                                │
│                   ┌─────────────────┐                                        │
│                   │  Access Token   │                                        │
│                   └────────┬────────┘                                        │
│                            ▼                                                 │
│    ┌──────────────────────────────────────────────────────────────────┐     │
│    │  https://{region}-aiplatform.googleapis.com/v1/projects/...     │     │
│    └──────────────────────────────────────────────────────────────────┘     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create GCP Project                                                 │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  🌐 Go to: https://console.cloud.google.com                            ││
│  │  1. Click "New Project" (or select existing)                           ││
│  │  2. Note your Project ID (e.g., "my-project-123456")                   ││
│  │  3. Enable billing (required, but $300 free trial available)           ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 2: Enable Vertex AI API                                               │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  1. Go to: APIs & Services → Library                                   ││
│  │  2. Search for "Vertex AI API"                                         ││
│  │  3. Click "Enable"                                                     ││
│  │                                                                        ││
│  │  Or use gcloud CLI:                                                    ││
│  │  $ gcloud services enable aiplatform.googleapis.com                    ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 3: Set Up Authentication (Choose ONE method)                          │
│                                                                              │
│  ┌─ Option A: Application Default Credentials (Recommended) ─────────────┐  │
│  │  # Install gcloud CLI: https://cloud.google.com/sdk/docs/install      │  │
│  │  $ gcloud auth application-default login                              │  │
│  │  $ gcloud config set project YOUR_PROJECT_ID                          │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
│                                                                              │
│  ┌─ Option B: Service Account Key ────────────────────────────────────────┐  │
│  │  1. Go to: IAM & Admin → Service Accounts                              │  │
│  │  2. Create service account with "Vertex AI User" role                  │  │
│  │  3. Create JSON key and download                                       │  │
│  │  4. Set environment variable:                                          │  │
│  │     $ export GOOGLE_APPLICATION_CREDENTIALS="/path/to/key.json"        │  │
│  └────────────────────────────────────────────────────────────────────────┘  │
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 4: Configure Victor                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  export GOOGLE_CLOUD_PROJECT="your-project-id"                         ││
│  │                                                                        ││
│  │  # In ~/.victor/profiles.yaml:                                         ││
│  │  providers:                                                            ││
│  │    vertex:                                                             ││
│  │      project_id: ${GOOGLE_CLOUD_PROJECT}                               ││
│  │      location: us-central1  # or your preferred region                 ││
│  └────────────────────────────────────────────────────────────────────────┘│
└────────────────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  vertex:
    provider: vertex
    model: gemini-1.5-pro
    description: "Vertex AI Gemini 1.5 Pro (2M context)"

  vertex-flash:
    provider: vertex
    model: gemini-1.5-flash
    description: "Vertex AI Gemini Flash (fast)"
```

#### Test Command

```bash
victor chat -p vertex "Summarize the key features of Vertex AI"
```

---

### Azure OpenAI

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           AZURE OPENAI SERVICE                               │
│                    Enterprise OpenAI + Microsoft Phi                         │
├─────────────────────────────────────────────────────────────────────────────┤
│  PRICING:   Pay-per-use  •  Azure credits available                         │
│  MODELS:    GPT-4o, GPT-4 Turbo, o1, Phi-4, Phi-3.5 Mini/MoE                │
│  FEATURES:  Private Link, RBAC, content filtering, regional deployment      │
│  AUTH:      API Key or Azure AD (Entra ID)                                  │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       AZURE OPENAI ARCHITECTURE                              │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                     Azure Portal / CLI                               │    │
│  └──────────────────────────────┬──────────────────────────────────────┘    │
│                                 │                                            │
│                                 ▼                                            │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                   Azure OpenAI Resource                              │    │
│  │  ┌─────────────────────────────────────────────────────────────┐    │    │
│  │  │  Endpoint: https://YOUR-RESOURCE.openai.azure.com           │    │    │
│  │  └─────────────────────────────────────────────────────────────┘    │    │
│  │                                                                     │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │    │
│  │  │  Deployment  │  │  Deployment  │  │  Deployment  │              │    │
│  │  │  "gpt-4o"    │  │  "gpt-4"     │  │  "phi-4"     │              │    │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
│  URL Format:                                                                 │
│  https://{resource}.openai.azure.com/openai/deployments/{deployment}/       │
│          chat/completions?api-version=2024-08-01-preview                     │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Get Azure Subscription                                             │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  🌐 Go to: https://portal.azure.com                                    ││
│  │  📧 Sign in or create Microsoft account                                ││
│  │  💳 Set up Azure subscription (free tier available)                    ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 2: Request Azure OpenAI Access                                        │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  ⚠️  Azure OpenAI requires approval (usually 1-2 business days)       ││
│  │                                                                        ││
│  │  1. Go to: https://aka.ms/oai/access                                   ││
│  │  2. Fill out the request form                                          ││
│  │  3. Wait for approval email                                            ││
│  │                                                                        ││
│  │  Note: Phi models are available immediately via Azure AI               ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 3: Create Azure OpenAI Resource                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  1. In Azure Portal, search "Azure OpenAI"                             ││
│  │  2. Click "Create"                                                     ││
│  │  3. Fill in:                                                           ││
│  │     - Resource group: Create or select                                 ││
│  │     - Region: East US, West Europe, etc.                               ││
│  │     - Name: my-openai-resource (unique)                                ││
│  │     - Pricing tier: Standard S0                                        ││
│  │  4. Review + Create                                                    ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 4: Deploy a Model                                                      │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  1. Go to your Azure OpenAI resource                                   ││
│  │  2. Click "Model deployments" → "Manage Deployments"                   ││
│  │  3. Click "Create new deployment"                                      ││
│  │  4. Select model: gpt-4o, gpt-4-turbo, etc.                            ││
│  │  5. Deployment name: "gpt-4o" (use this in Victor)                     ││
│  │  6. Set tokens-per-minute quota                                        ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 5: Get Endpoint and Key                                                │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  1. Go to "Keys and Endpoint" in your resource                         ││
│  │  2. Copy:                                                              ││
│  │     - Endpoint: https://YOUR-RESOURCE.openai.azure.com                 ││
│  │     - Key 1: xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx                          ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 6: Configure Victor                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  export AZURE_OPENAI_API_KEY="your_key_here"                           ││
│  │  export AZURE_OPENAI_ENDPOINT="https://YOUR-RESOURCE.openai.azure.com" ││
│  │                                                                        ││
│  │  # In ~/.victor/profiles.yaml:                                         ││
│  │  providers:                                                            ││
│  │    azure:                                                              ││
│  │      api_key: ${AZURE_OPENAI_API_KEY}                                  ││
│  │      endpoint: ${AZURE_OPENAI_ENDPOINT}                                ││
│  │      api_version: 2024-08-01-preview                                   ││
│  └────────────────────────────────────────────────────────────────────────┘│
└────────────────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  azure:
    provider: azure
    model: gpt-4o  # Must match your deployment name!
    description: "Azure OpenAI GPT-4o"

  azure-phi:
    provider: azure
    model: Phi-4
    description: "Azure AI Phi-4 (14B SLM)"
```

#### Test Command

```bash
victor chat -p azure "What are the benefits of Azure OpenAI?"
```

---

### AWS Bedrock

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            AWS BEDROCK                                       │
│                    Managed Foundation Models                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│  PRICING:   Pay-per-use  •  AWS Free Tier eligible                          │
│  MODELS:    Claude 3.5, Llama 3.1/3.2, Mistral Large, Amazon Titan          │
│  FEATURES:  VPC, PrivateLink, KMS encryption, model fine-tuning             │
│  AUTH:      IAM (credentials, roles, instance profiles)                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         AWS BEDROCK ARCHITECTURE                             │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────┐     │
│  │                      AWS Account                                    │     │
│  │  ┌────────────────────────────────────────────────────────────────┐│     │
│  │  │                     IAM User/Role                              ││     │
│  │  │  ┌──────────────────────────────────────────────────────────┐  ││     │
│  │  │  │  Permissions:                                            │  ││     │
│  │  │  │  - bedrock:InvokeModel                                   │  ││     │
│  │  │  │  - bedrock:InvokeModelWithResponseStream                 │  ││     │
│  │  │  └──────────────────────────────────────────────────────────┘  ││     │
│  │  └────────────────────────────────────────────────────────────────┘│     │
│  │                              │                                      │     │
│  │                              ▼                                      │     │
│  │  ┌────────────────────────────────────────────────────────────────┐│     │
│  │  │                   Bedrock Runtime                              ││     │
│  │  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       ││     │
│  │  │  │ Claude   │  │ Llama    │  │ Mistral  │  │ Titan    │       ││     │
│  │  │  │ (Anthr.) │  │ (Meta)   │  │ (Mistral)│  │ (Amazon) │       ││     │
│  │  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘       ││     │
│  │  └────────────────────────────────────────────────────────────────┘│     │
│  └────────────────────────────────────────────────────────────────────┘     │
│                                                                              │
│  Model ID Format: {provider}.{model-name}-{version}                          │
│  Example: anthropic.claude-3-5-sonnet-20241022-v2:0                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: AWS Account Setup                                                   │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  🌐 Go to: https://aws.amazon.com                                      ││
│  │  📧 Create or sign into AWS account                                    ││
│  │  💳 Set up billing (Free Tier available for Bedrock)                   ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 2: Enable Bedrock Models                                               │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  1. Go to AWS Console → Bedrock                                        ││
│  │  2. Click "Model access" in left sidebar                               ││
│  │  3. Click "Manage model access"                                        ││
│  │  4. Enable models you want to use:                                     ││
│  │     ✅ Anthropic Claude 3.5 Sonnet                                     ││
│  │     ✅ Meta Llama 3.1 70B                                              ││
│  │     ✅ Mistral Large                                                   ││
│  │  5. Submit request (some models need approval)                         ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 3: Create IAM User/Role                                                │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  Option A: IAM User (for local development)                            ││
│  │  1. Go to IAM → Users → Create user                                    ││
│  │  2. Attach policy: AmazonBedrockFullAccess                             ││
│  │  3. Create access keys (Security credentials tab)                      ││
│  │                                                                        ││
│  │  Option B: IAM Role (for EC2/Lambda/ECS)                               ││
│  │  1. Create role with Bedrock permissions                               ││
│  │  2. Attach to your compute resource                                    ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 4: Install AWS CLI and Configure                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  # Install AWS CLI                                                     ││
│  │  $ pip install awscli boto3                                            ││
│  │                                                                        ││
│  │  # Configure credentials                                               ││
│  │  $ aws configure                                                       ││
│  │  AWS Access Key ID: AKIAIOSFODNN7EXAMPLE                               ││
│  │  AWS Secret Access Key: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY       ││
│  │  Default region name: us-east-1                                        ││
│  │  Default output format: json                                           ││
│  │                                                                        ││
│  │  # Or set environment variables:                                       ││
│  │  export AWS_ACCESS_KEY_ID="your_key"                                   ││
│  │  export AWS_SECRET_ACCESS_KEY="your_secret"                            ││
│  │  export AWS_DEFAULT_REGION="us-east-1"                                 ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 5: Configure Victor                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  # In ~/.victor/profiles.yaml:                                         ││
│  │  providers:                                                            ││
│  │    bedrock:                                                            ││
│  │      region: us-east-1  # or your preferred region                     ││
│  │      # profile_name: my-aws-profile  # optional                        ││
│  └────────────────────────────────────────────────────────────────────────┘│
└────────────────────────────────────────────────────────────────────────────┘
```

#### Available Models

| Model ID | Description |
|----------|-------------|
| `anthropic.claude-3-5-sonnet-20241022-v2:0` | Claude 3.5 Sonnet v2 |
| `anthropic.claude-3-5-haiku-20241022-v1:0` | Claude 3.5 Haiku |
| `meta.llama3-1-70b-instruct-v1:0` | Llama 3.1 70B |
| `meta.llama3-2-90b-instruct-v1:0` | Llama 3.2 90B |
| `mistral.mistral-large-2407-v1:0` | Mistral Large |
| `amazon.titan-text-premier-v1:0` | Amazon Titan Premier |

#### Available Profiles

```yaml
profiles:
  bedrock:
    provider: bedrock
    model: anthropic.claude-3-5-sonnet-20241022-v2:0
    description: "Bedrock Claude 3.5 Sonnet"

  bedrock-llama:
    provider: bedrock
    model: meta.llama3-1-70b-instruct-v1:0
    description: "Bedrock Llama 3.1 70B"
```

#### Test Command

```bash
victor chat -p bedrock "What are the advantages of AWS Bedrock?"
```

---

## Open Model Platforms

Platforms for running open-source models with flexible pricing.

---

### Hugging Face (Free Tier)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           HUGGING FACE                                       │
│                    Inference API for 1000s of Models                         │
├─────────────────────────────────────────────────────────────────────────────┤
│  FREE TIER:  Rate-limited free access  •  No credit card                    │
│  MODELS:     Llama 3.3 70B, Qwen 2.5 72B, Mistral, Phi-3, 1000s more        │
│  FEATURE:    OpenAI-compatible API, largest model hub                       │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Hugging Face Account                                        │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  🌐 Go to: https://huggingface.co/join                                 ││
│  │  📧 Sign up with email or SSO                                          ││
│  │  ✅ Verify email                                                       ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 2: Get Access Token                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  1. Go to: https://huggingface.co/settings/tokens                      ││
│  │  2. Click "New token"                                                  ││
│  │  3. Name: "victor"                                                     ││
│  │  4. Role: "Read" (or "Write" for private models)                       ││
│  │  5. Copy token: hf_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx                    ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  export HF_TOKEN="hf_your_token_here"                                  ││
│  │  # Alternative variable name:                                          ││
│  │  export HUGGINGFACE_API_KEY="hf_your_token_here"                       ││
│  └────────────────────────────────────────────────────────────────────────┘│
└────────────────────────────────────────────────────────────────────────────┘
```

#### Available Models

Use any model from Hugging Face Hub that supports text generation:

```yaml
profiles:
  huggingface:
    provider: huggingface
    model: meta-llama/Llama-3.3-70B-Instruct
    description: "Llama 3.3 70B"

  hf-qwen:
    provider: huggingface
    model: Qwen/Qwen2.5-72B-Instruct
    description: "Qwen 2.5 72B"

  hf-coder:
    provider: huggingface
    model: Qwen/Qwen2.5-Coder-32B-Instruct
    description: "Qwen Coder 32B"
```

---

### Replicate

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              REPLICATE                                       │
│                    Run Any Public Model - Pay Per Second                     │
├─────────────────────────────────────────────────────────────────────────────┤
│  PRICING:   Pay-per-second  •  No minimum spend  •  Free trial credits      │
│  MODELS:    Any model on replicate.com (1000s available)                    │
│  FEATURE:   Model versioning, custom deployments, streaming                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Setup Steps

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                                      │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  🌐 Go to: https://replicate.com                                       ││
│  │  📧 Sign up with GitHub (recommended) or email                         ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 2: Get API Token                                                       │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  1. Go to: https://replicate.com/account/api-tokens                    ││
│  │  2. Copy your API token                                                ││
│  │  3. Token format: r8_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx                  ││
│  └────────────────────────────────────────────────────────────────────────┘│
├────────────────────────────────────────────────────────────────────────────┤
│  STEP 3: Configure Victor                                                    │
│  ┌────────────────────────────────────────────────────────────────────────┐│
│  │  export REPLICATE_API_TOKEN="r8_your_token_here"                       ││
│  └────────────────────────────────────────────────────────────────────────┘│
└────────────────────────────────────────────────────────────────────────────┘
```

#### Available Profiles

```yaml
profiles:
  replicate:
    provider: replicate
    model: meta/llama-3.3-70b-instruct
    description: "Replicate Llama 3.3 70B"

  replicate-deepseek:
    provider: replicate
    model: deepseek-ai/deepseek-v3
    description: "DeepSeek V3 671B MoE"
```

---

## Premium API Providers

Direct API access to leading model providers.

---

### Anthropic (Claude)

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                                     │
│  🌐 Go to: https://console.anthropic.com                                    │
│                                                                              │
│  STEP 2: Get API Key                                                         │
│  1. Go to API Keys section                                                   │
│  2. Create new key: sk-ant-api03-xxxxx                                       │
│                                                                              │
│  STEP 3: Configure                                                           │
│  export ANTHROPIC_API_KEY="sk-ant-api03-your_key"                           │
│  # Or: export VICTOR_ANTHROPIC_KEY="sk-ant-api03-your_key"                  │
└────────────────────────────────────────────────────────────────────────────┘
```

---

### OpenAI (GPT-4)

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                                     │
│  🌐 Go to: https://platform.openai.com                                      │
│                                                                              │
│  STEP 2: Get API Key                                                         │
│  1. Go to API Keys                                                           │
│  2. Create new key: sk-proj-xxxxx                                            │
│                                                                              │
│  STEP 3: Configure                                                           │
│  export OPENAI_API_KEY="sk-proj-your_key"                                   │
└────────────────────────────────────────────────────────────────────────────┘
```

---

### Google AI (Gemini) - Free Tier

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Get API Key                                                         │
│  🌐 Go to: https://aistudio.google.com/apikey                               │
│                                                                              │
│  STEP 2: Create Key                                                          │
│  Click "Create API Key" - instant, no billing required                       │
│                                                                              │
│  STEP 3: Configure                                                           │
│  export GOOGLE_API_KEY="AIzaSy-your_key"                                    │
│  # Or: export VICTOR_GOOGLE_KEY="AIzaSy-your_key"                           │
└────────────────────────────────────────────────────────────────────────────┘
```

---

### xAI (Grok)

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                                     │
│  🌐 Go to: https://console.x.ai                                             │
│                                                                              │
│  STEP 2: Get API Key                                                         │
│  1. Navigate to API Keys                                                     │
│  2. Create key: xai-xxxxx                                                    │
│                                                                              │
│  STEP 3: Configure                                                           │
│  export XAI_API_KEY="xai-your_key"                                          │
└────────────────────────────────────────────────────────────────────────────┘
```

---

### DeepSeek

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                                     │
│  🌐 Go to: https://platform.deepseek.com                                    │
│                                                                              │
│  STEP 2: Get API Key                                                         │
│  1. Go to API Keys section                                                   │
│  2. Create new key                                                           │
│                                                                              │
│  STEP 3: Configure                                                           │
│  export DEEPSEEK_API_KEY="sk-your_key"                                      │
└────────────────────────────────────────────────────────────────────────────┘
```

---

### Moonshot (Kimi)

```
┌────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Create Account                                                     │
│  🌐 Go to: https://platform.moonshot.cn                                     │
│                                                                              │
│  STEP 2: Get API Key                                                         │
│  1. Navigate to API Keys                                                     │
│  2. Create key                                                               │
│                                                                              │
│  STEP 3: Configure                                                           │
│  export MOONSHOT_API_KEY="sk-your_key"                                      │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## Troubleshooting

```mermaid
flowchart TD
    Start[Error Occurred] --> E1{Error Type?}

    E1 -->|Provider not found| P1[Check provider registered]
    P1 --> P1a["victor providers"]

    E1 -->|401 Unauthorized| A1[Check API key]
    A1 --> A1a["victor keys --list"]
    A1a --> A1b[Verify key not expired]

    E1 -->|429 Rate Limited| R1[Wait and retry]
    R1 --> R1a[Switch provider]

    E1 -->|503 Model Loading| M1[Cold start - retry in 30s]

    E1 -->|Connection Refused| C1[Check local server]
    C1 --> C1a["ollama serve / LM Studio"]

    style Start fill:#f87171,stroke:#dc2626
    style P1a fill:#86efac,stroke:#22c55e
    style A1a fill:#86efac,stroke:#22c55e
    style R1a fill:#fde047,stroke:#eab308
```

### Common Issues

| Error | Cause | Solution |
|-------|-------|----------|
| `Provider 'xyz' not found` | Provider not registered | Run `victor providers` to list available |
| `401 Unauthorized` | Invalid/expired API key | Run `victor keys --list` to check, re-add if needed |
| `429 Rate Limited` | Exceeded free tier limits | Wait and retry, or switch to another provider |
| `503 Model Loading` | Cold start (serverless) | Retry in 30 seconds |
| `Connection Refused` | Local server not running | Start `ollama serve` or LM Studio |

### Testing Your Setup

```bash
victor providers                    # List available providers
victor keys --list                  # Check configured API keys
victor chat -p groqcloud "test"     # Quick test
victor chat -p groqcloud --renderer text --log-level DEBUG "test"  # Debug mode
```

---

## Quick Reference

| Category | Provider | Env Variable | Limit |
|----------|----------|--------------|-------|
| **Local (Free)** | ollama | *(none)* | Unlimited |
| | lmstudio | *(none)* | Unlimited |
| **Free Tier** | groqcloud | `GROQCLOUD_API_KEY` | 14.4K req/day |
| | cerebras | `CEREBRAS_API_KEY` | 14.4K req/day |
| | google | `GOOGLE_API_KEY` | 250 req/day |
| | mistral | `MISTRAL_API_KEY` | 500K tok/min |
| | together | `TOGETHER_API_KEY` | $25 credits |
| | openrouter | `OPENROUTER_API_KEY` | 50 req/day |
| **Premium** | anthropic | `ANTHROPIC_API_KEY` | Pay-per-token |
| | openai | `OPENAI_API_KEY` | Pay-per-token |
| | xai | `XAI_API_KEY` | Pay-per-token |
| **Enterprise** | vertex | `GOOGLE_CLOUD_PROJECT` | Pay-per-token |
| | azure | `AZURE_OPENAI_API_KEY` | Pay-per-token |
| | bedrock | AWS credentials | Pay-per-token |

---

*Victor v0.1.0 - December 2025*
