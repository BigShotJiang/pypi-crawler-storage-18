class BitkubError(Exception):
    pass
