# TechDisrupt Analyzer  

[![PyPI version](https:...  
[![License: MIT](https://im...  
[![Downloads](h...  
[![LinkedIn](ht...

TechDisrupt Analyzer is a Python package that helps users analyze and structure their experiences or challenges with technology disruptions. It takes a user's textual description of their experience and uses a Language Model (LLM) to generate a structured summary, including key details like duration, impact, and possible resolutions.  

## Installation  
```bash  
pip install techdisrupt-analyzer  
```  

## Usage  
```python  
from techdisrupt_analyzer import techdisrupt_analyzer  

# Example usage with default LLM7 
response = techdisrupt_analyzer("I spent a WEEK without IPv4")  

# Example usage with custom LLM instance (e.g., OpenAI)  
from langchain_openai import ChatOpenAI  
llm = ChatOpenAI()  
response = techdisrupt_analyzer("My internet was down for 3 hours", llm=llm)  

# Example usage with custom LLM instance (e.g., Anthropic)  
from langchain_anthropic import ChatAnthropic  
llm = ChatAnthropic()  
response = techdisrupt_analyzer("Connection failure lasting 2 days", llm=llm)  

# Example usage with custom LLM instance (e.g., Google Generative AI)  
from langchain_google_genai import ChatGoogleGenerativeAI  
llm = ChatGoogleGenerativeAI()  
response = techdisrupt_analyzer("Network outage last week", llm=llm)  
```  

## Parameters  
- `user_input` (str): The textual description of the user's experience or challenge.  
- `llm` (Optional[BaseChatModel]): The language model instance to use. Defaults to the integrated ChatLLM7. You can pass custom instances like OpenAI, Anthropic, or Google models.  
- `api_key` (Optional[str]): API key for LLM7. If not provided, the function uses the environment variable `LLM7_API_KEY` or defaults.  

## Notes on Custom LLMs  
You can pass your own LLM instances for more control or higher limits. Supported models include, but are not limited to:  
- OpenAI (`ChatOpenAI`)  
- Anthropic (`ChatAnthropic`)  
- Google Generative AI (`ChatGoogleGenAI`)  

For example:  
```python  
from langchain_openai import ChatOpenAI  
llm = ChatOpenAI(api_key='your-api-key')  
response = techdisrupt_analyzer("Sample description", llm=llm)  
```  

## License  
This project is licensed under the MIT License.  

## Author  
Eugene Evstafev (chigwell)  

## Support & Issues  
For issues and support, please visit the GitHub repository: https://github....