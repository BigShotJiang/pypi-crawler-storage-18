"""
Test suite for polerisk
"""

