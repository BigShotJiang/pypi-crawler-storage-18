"""A collection of service."""
