"""Showcase textual-image."""
