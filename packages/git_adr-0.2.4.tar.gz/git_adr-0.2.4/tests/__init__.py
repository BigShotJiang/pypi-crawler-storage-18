"""Tests for git-adr."""
