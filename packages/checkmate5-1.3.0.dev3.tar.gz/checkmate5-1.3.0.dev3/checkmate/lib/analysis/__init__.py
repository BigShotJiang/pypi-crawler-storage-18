"""
Stub analysis package.
"""


