# **Trollmaker**
[![PyPI version](https://badge.fury.io/py/trollmaker.svg)](https://badge.fury.io/py/trollmaker)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/trollmaker)](https://pepy.tech/project/trollmaker)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A fun and structured package that generates light-hearted, humorous roasts based on a public username or handle from social media. The output is formatted consistently with a roast, a playful insult, and a balanced compliment—all while ensuring a non-offensive, entertaining experience.

---

## **Installation**

Install the package via pip:

```bash
pip install trollmaker
```

---

## **Usage**

### **Basic Usage (Default LLM7)**
```python
from trollmaker import trollmaker

response = trollmaker(user_input="username_to_roast")
print(response)
```

### **Custom LLM Integration**
By default, the package uses **`ChatLLM7`** (from [`langchain_llm7`](https://pypi.org/project/langchain-llm7/)). You can easily replace it with other LLMs like OpenAI, Anthropic, or Google Vertex AI.

#### **Example: Using OpenAI**
```python
from langchain_openai import ChatOpenAI
from trollmaker import trollmaker

llm = ChatOpenAI()
response = trollmaker(user_input="username_to_roast", llm=llm)
print(response)
```

#### **Example: Using Anthropic**
```python
from langchain_anthropic import ChatAnthropic
from trollmaker import trollmaker

llm = ChatAnthropic()
response = trollmaker(user_input="username_to_roast", llm=llm)
print(response)
```

#### **Example: Using Google Vertex AI**
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from trollmaker import trollmaker

llm = ChatGoogleGenerativeAI()
response = trollmaker(user_input="username_to_roast", llm=llm)
print(response)
```

---

## **Parameters**

| Parameter | Type | Description |
|-----------|------|-------------|
| `user_input` | `str` | The username or handle to generate a roast for. |
| `api_key` | `Optional[str]` | Optional LLM7 API key (defaults to `LLM7_API_KEY` env var). |
| `llm` | `Optional[BaseChatModel]` | Optional custom LLM (e.g., `ChatOpenAI`, `ChatAnthropic`). If not provided, defaults to `ChatLLM7`. |

---

## **How It Works**
1. Takes a **username/handle** as input.
2. Uses **LLM7** (or a custom LLM) to generate a structured roast.
3. Ensures the output follows a **consistent format** (roast + insult + compliment).
4. Returns a **humorous yet non-offensive** response.

---

## **Rate Limits & API Key**
- **Default LLM7 Free Tier** is sufficient for most use cases.
- For higher rate limits, set `LLM7_API_KEY` via environment variable or pass it directly:
  ```python
  trollmaker(user_input="username", api_key="your_api_key")
  ```
- Get a **free LLM7 API key** at [https://token.llm7.io/](https://token.llm7.io/).

---

## **Contributing & Issues**
For bugs, feature requests, or questions, open an issue here:
🔗 [https://github.com/chigwell/trollmaker/issues](https://github.com/chigwell/trollmaker/issues)

---

## **Author**
👤 **Eugene Evstafev**
📧 [hi@euegne.plus](mailto:hi@euegne.plus)
🔗 [GitHub: chigwell](https://github.com/chigwell)

---