"""Deep Agent Runtime - Bootstrap and runtime context management.

This module provides the core runtime infrastructure for Deep Agent applications:

- RuntimeContext: Immutable runtime context containing all configuration and resources
- RuntimeBootstrap: Helper for loading configuration and creating RuntimeContext
- bootstrap_runtime: Main entry point for initializing the Deep Agent runtime
- Session builders: Declarative session construction from manifests

Example:
    from agentic_ai.config import BaseAppConfig
    from agentic_ai.runtime import bootstrap_runtime, build_session
    from agentic_ai.workspace import create_workspace
    
    # Bootstrap runtime (once at startup)
    ctx = bootstrap_runtime(BaseAppConfig)
    
    # Create session
    workspace = create_workspace(default_root=".ws")
    session = build_session(ctx, "agentic_analyst", workspace)
"""

from .bootstrap import RuntimeBootstrap, bootstrap_runtime
from .context import (
    RuntimeContext,
    get_runtime_context,
    set_runtime_context,
    reset_runtime_context,
)
from .session_builder import (
    build_session,
    create_session_factory,
)

__all__ = [
    # Bootstrap
    "RuntimeBootstrap",
    "bootstrap_runtime",
    # Context
    "RuntimeContext",
    "get_runtime_context",
    "set_runtime_context",
    "reset_runtime_context",
    # Session builders
    "build_session",
    "create_session_factory",
]
