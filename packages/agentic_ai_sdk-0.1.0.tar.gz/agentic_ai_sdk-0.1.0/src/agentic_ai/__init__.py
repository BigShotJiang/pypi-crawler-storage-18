"""Deep Agent Framework - A toolkit for building AI agents.

This package provides a comprehensive framework for building AI agents with:
- Agent session management (DeepAgentSession)
- Configuration management (config/)
- LLM client utilities (llm/)
- Workspace management (workspace/)
- Artifact persistence (artifacts/)
- Observability and tracing (observability/)
- Planning tools (planning/)

Quick Start:
    from agentic_ai import (
        DeepAgentSession,
        build_agent_session,
        BaseAppContext,
        build_app_context,
    )

Subpackages:
    deep_agent.config       - Configuration models and utilities
    deep_agent.llm          - LLM client creation and management
    deep_agent.workspace    - Workspace and artifact storage
    deep_agent.artifacts    - Tool result persistence
    deep_agent.observability - Logging and tracing
    deep_agent.planning     - Agent planning tools

For backwards compatibility, all symbols are also exported from the top level.
"""
from __future__ import annotations

from importlib import util as _import_util
from pathlib import Path as _Path
import sys as _sys

# =============================================================================
# Core Agent Components
# =============================================================================
from .agent import (
    DeepAgentSession,
    build_agent,
    build_agent_with_llm,
    build_agent_from_config,
    build_agent_from_store,
    build_agent_session,
)
from .sub_agent import SubAgentController
from .app_context import BaseAppContext, build_app_context
from .ag_ui import DeepAgentProtocolAdapter, build_ag_ui_agent
from .ag_ui_server import (
    AgUIAppOptions,
    ConcurrencyLimitMiddleware,
    HealthCheckFilter,
    build_ag_ui_arg_parser,
    create_ag_ui_app,
    run_ag_ui_server,
)

# =============================================================================
# Configuration (also available via deep_agent.config)
# =============================================================================
from .config.config_base import (
    AgUiConfig,
    BaseAppConfig,
    ConfigError,
    EmbeddingConfig,
    LoggingConfig,
    ObservabilityConfig,
    load_yaml_config,
)
from .config.tool_config_registry import (
    ToolConfigRegistry,
    get_tool_config_registry,
    register_tool_config,
    register_tool_config_schema,
    register_tool_config_schemas,
)
from .agent_config import AgentConfig, ContextCompactionConfig, ResponseHandling, SubagentConfig
from .agent_config_store import (
    AgentConfigStore,
    create_agent_config_store_from_list,
    create_agent_config_store_from_manifest,
)
from .manifest import AgentManifest, ToolProviderConfig
from .config.manifest_loader import AgentManifestLoader
from .llm.llm_config import LLMConfig

# =============================================================================
# LLM Client (also available via deep_agent.llm)
# =============================================================================
from .llm.llm_client import (
    build_agent_chat_options,
    build_chat_options,
    create_chat_client,
    resolve_temperature,
)
from .llm.llm_config import LLMConfig
from .llm.llm_factory import LLMClientFactory, create_llm_factory_from_list

# =============================================================================
# Workspace & Artifacts (also available via deep_agent.workspace, deep_agent.artifacts)
# =============================================================================
from .workspace.workspace_core import WorkspaceContextProvider, WorkspaceHandle, WorkspaceManager, create_workspace
from .artifacts.artifacts_core import (
    ArtifactStore,
    ToolResult,
    persist_full,
    persist_preview,
    ok,
    error,
    load_artifact,
    try_load_artifact,
)

# =============================================================================
# Observability (also available via deep_agent.observability)
# =============================================================================
from .observability.logging_config import LogLevel, setup_logging, setup_logging_from_config
from .observability.observability_setup import ObservabilityOptions, enable_observability, configure_observability_from_config
from .observability.tracing import trace_http_request, trace_database_query, get_tracer

# =============================================================================
# Planning (also available via deep_agent.planning)
# =============================================================================
from .planning.planning_core import (
    PlanRecord,
    PlanStep,
    PlanStore,
    StepStatus,
    UpdatePlanArgs,
    build_update_plan_tool,
)

# =============================================================================
# Utilities
# =============================================================================
from .contexts import ToolExecutionContext, ToolContextUnavailableError, ctx, try_ctx, tool_context
from .ids import generate_short_id
from .prompt_loader import load_prompt_from_agent_config, load_prompt_from_file
from .middleware import ToolResultPersistenceMiddleware
from .middleware_loader import load_middleware, load_middlewares
from .declarative_builder import DeclarativeAgentBuilder, DeclarativeBuildResult
from .tool_provider import resolve_tool_refs
from .tools_manifest import ToolsManifest, ToolConfig, load_tools_manifest
from .tool_loader import load_tool_from_function, resolve_tool_ref
from .mcp.manifest import MCPManifest, MCPServerConfig
from .mcp.loader import MCPManifestLoader
from .mcp.tools import load_mcp_tools
from .context_compaction import (
    CompactionConfig,
    ContextCompactor,
    HeuristicSummarizer,
    CompactionSummarizer,
    LLMSummarizer,
)
from .embedding import EmbeddingProvider, EmbeddingError
from .session_factory import (
    SessionFactory,
    SessionBuilder,
    ThreadSession,
    DEFAULT_SESSION_TTL_SECONDS,
)

# =============================================================================
# Tool Runtime (per-session resource management)
# =============================================================================
from .tool_runtime import (
    ToolRuntimeRegistry,
    ToolOutputPolicy,
    tool_handler,
    get_output_config,
    normalize_tool_output,
    register_runtime,
    cleanup_session,
    reset_all_runtimes,
    get_current_session_id,
    set_session_context,
    reset_session_context,
    get_current_task,
    set_task_context,
    reset_task_context,
    get_last_artifact_id,
    set_last_artifact_id,
    reset_last_artifact_id,
    # Enhanced injection API
    get_tool_config,
    set_tool_config,
    reset_tool_config,
    get_config_section,
    get_effective_config_section,
    get_effective_tool_config,
    get_client,
    register_client,
    unregister_client,
    get_registered_clients,
)

# =============================================================================
# Runtime (bootstrap and context management)
# =============================================================================
from .runtime import (
    RuntimeBootstrap,
    RuntimeContext,
    bootstrap_runtime,
    get_runtime_context,
    set_runtime_context,
    reset_runtime_context,
    build_session,
    create_session_factory as create_runtime_session_factory,
)

# =============================================================================
# Defaults (centralized path conventions)
# =============================================================================
from . import defaults

# =============================================================================
# Public API
# =============================================================================
__all__ = [
    # Core
    "DeepAgentSession",
    "DeepAgentProtocolAdapter",
    "SubAgentController",
    "BaseAppContext",
    "build_agent",
    "build_agent_from_config",
    "build_agent_from_store",
    "build_agent_session",
    "build_agent_with_llm",
    "build_ag_ui_agent",
    "AgUIAppOptions",
    "ConcurrencyLimitMiddleware",
    "HealthCheckFilter",
    "build_ag_ui_arg_parser",
    "create_ag_ui_app",
    "run_ag_ui_server",
    "build_app_context",
    # Configuration
    "AgentConfig",
    "AgentConfigStore",
    "AgentManifest",
    "AgentManifestLoader",
    "BaseAppConfig",
    "AgUiConfig",
    "ConfigError",
    "ContextCompactionConfig",
    "EmbeddingConfig",
    "LLMConfig",
    "LoggingConfig",
    "ObservabilityConfig",
    "SubagentConfig",
    "create_agent_config_store_from_list",
    "create_agent_config_store_from_manifest",
    "load_yaml_config",
    "ToolConfigRegistry",
    "get_tool_config_registry",
    "register_tool_config",
    "register_tool_config_schema",
    "register_tool_config_schemas",
    # LLM
    "LLMClientFactory",
    "build_agent_chat_options",
    "build_chat_options",
    "create_chat_client",
    "create_llm_factory_from_list",
    "resolve_temperature",
    # Workspace & Artifacts
    "ArtifactStore",
    "ToolResult",
    "WorkspaceContextProvider",
    "WorkspaceHandle",
    "WorkspaceManager",
    "create_workspace",
    "persist_full",
    "persist_preview",
    "ok",
    "error",
    "load_artifact",
    "try_load_artifact",
    # Observability
    "LogLevel",
    "ObservabilityOptions",
    "configure_observability_from_config",
    "enable_observability",
    "get_tracer",
    "setup_logging",
    "setup_logging_from_config",
    "trace_database_query",
    "trace_http_request",
    # Planning
    "PlanRecord",
    "PlanStep",
    "PlanStore",
    "StepStatus",
    "UpdatePlanArgs",
    "build_update_plan_tool",
    # Utilities
    "CompactionConfig",
    "CompactionSummarizer",
    "ContextCompactor",
    "EmbeddingError",
    "EmbeddingProvider",
    "HeuristicSummarizer",
    "LLMSummarizer",
    "ToolExecutionContext",
    "ToolContextUnavailableError",
    "ToolResultPersistenceMiddleware",
    "ctx",
    "try_ctx",
    "generate_short_id",
    "load_prompt_from_agent_config",
    "load_prompt_from_file",
    "tool_context",
    "DeclarativeAgentBuilder",
    "DeclarativeBuildResult",
    "ToolProviderConfig",
    "resolve_tool_refs",
    # Tools manifest (plugin-style tools)
    "ToolsManifest",
    "ToolConfig",
    "load_tools_manifest",
    "load_tool_from_function",
    "resolve_tool_ref",
    "load_middleware",
    "load_middlewares",
    "MCPManifest",
    "MCPServerConfig",
    "MCPManifestLoader",
    "load_mcp_tools",
    # Tool Runtime (per-session resource management)
    "ToolRuntimeRegistry",
    "ToolOutputPolicy",
    "tool_handler",
    "get_output_config",
    "normalize_tool_output",
    "register_runtime",
    "cleanup_session",
    "reset_all_runtimes",
    "get_current_session_id",
    "set_session_context",
    "reset_session_context",
    "get_current_task",
    "set_task_context",
    "reset_task_context",
    "get_last_artifact_id",
    "set_last_artifact_id",
    "reset_last_artifact_id",
    # Enhanced injection API
    "get_tool_config",
    "set_tool_config",
    "reset_tool_config",
    "get_config_section",
    "get_effective_config_section",
    "get_effective_tool_config",
    "get_client",
    "register_client",
    "unregister_client",
    "get_registered_clients",
    # Runtime (bootstrap and context management)
    "RuntimeBootstrap",
    "RuntimeContext",
    "bootstrap_runtime",
    "get_runtime_context",
    "set_runtime_context",
    "reset_runtime_context",
    "build_session",
    "create_runtime_session_factory",
    # Session Factory (multi-tenant)
    "SessionFactory",
    "SessionBuilder",
    "ThreadSession",
    "DEFAULT_SESSION_TTL_SECONDS",
    # Defaults
    "defaults",
]
