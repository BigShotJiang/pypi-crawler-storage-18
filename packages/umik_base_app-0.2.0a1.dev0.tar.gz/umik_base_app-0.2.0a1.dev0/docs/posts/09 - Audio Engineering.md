# 🎧 Beyond Voltage: Why We Moved From RMS to LUFS

In the early stages of building our audio analysis pipeline, we relied on **RMS (Root Mean Square)** to measure loudness. It’s the standard textbook approach: square the amplitude, take the mean, find the root. It’s computationally cheap and mathematically perfect for measuring **electrical power**.

But audio isn't just electricity - it's **perception**.

It has been quickly found that RMS has a critical flaw in real-world applications: it is "ear-blind." To an RMS meter, a low-end rumble at 40Hz and a piercing whistle at 2kHz can have the exact same "loudness" value, even though the human ear perceives the whistle as significantly louder. Relying on RMS meant that the real time meter was measuring the _signal_, not the sound.

## The Shift to LUFS (Psychoacoustics)

To fix this, it has been integrated **LUFS (Loudness Units Full Scale)** into `src/py_umik/processing/audio_metrics.py`.

Unlike RMS, LUFS is designed to model the non-linear way humans hear. It applies **K-weighting** - a filter curve that mimics the human ear’s sensitivity. It rolls off low frequencies (which we are less sensitive to) and boosts the high-mids (where speech intelligibility lives).

This isn't just a volume tweak; it’s an implementation of the **ITU-R BS.1770-4** standard, the same metric used by Netflix, Spotify, and broadcast television to ensure consistent volume levels.

## Engineering the Solution: `pyloudnorm`

It is not just a quick filter; it has been integrated the `pyloudnorm` library directly into the analysis pipeline.

In `src/py_umik/processing/audio_metrics.py`, now it's being perform a gated loudness analysis. This means the meter doesn't just average the noise floor with the signal; it intelligently ignores silence to give a "loudness" reading that reflects the active parts of the audio track.

## The Comparison:

| Feature   | RMS (Root Mean Square)          | LUFS (Loudness Units Full Scale)                    |
| --------- | ------------------------------- | ------------------------- |
| **Measures**  | Physical Signal Power (Voltage) | Perceived Loudness (Psychoacoustics)                |
| **Frequency Bias** | None (Flat response)        | K-Weighted (Models human hearing) |
| **Use Case**  | Protecting equipment (speakers/amps) | Normalizing audio for human listeners |
| **Project Integration** | Legacy / Raw Data    | Active (`src/py_umik/processing/audio_metrics.py`) |

By switching to LUFS, this project doesn't just tell you how much energy is on the wire - it tells you how loud the world actually sounds. It’s a small detail that marks the difference between a code experiment and a piece of audio engineering.
