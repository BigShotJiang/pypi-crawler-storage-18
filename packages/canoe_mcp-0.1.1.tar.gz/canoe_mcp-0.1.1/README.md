# CANoe MCP Server

## Installation

### Using uvx (Recommended)
```bash
uvx canoe-mcp-server
```

### Using pip
```bash
pip install canoe-mcp-server
```

### From source
```bash
git clone https://github.com/MohamedHamed19m/CANoe_MCP.git
cd CANoe_MCP
pip install -e .
```

### UV Managed (Modern Development)
For a robust development environment using `uv`:

```bash
# Clone the repo
git clone https://github.com/MohamedHamed19m/CANoe_MCP.git
cd CANoe_MCP

# Install in editable mode
uv pip install -e .
```

**Configuration for Claude Desktop (UV Run):**
If you want to run the server directly from the source code:

```json
{
  "mcpServers": {
    "canoe": {
      "command": "uv",
      "args": ["run", "canoe-mcp"],
      "cwd": "C:/path/to/CANoe_MCP"
    }
  }
}
```

## Quick Start

1. **Start CANoe** with your configuration
2. **Run the MCP server:**
```bash
   canoe-mcp
```

## Configuration for Claude Desktop

Add to your `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "canoe": {
      "command": "uvx",
      "args": ["canoe-mcp-server"]
    }
  }
}
```

### 🚀 Key Takeaway

*   **For Users:** Use `uvx` — it's the simplest and recommended way to run the server without manual installation.
*   **For Developers:** Clone the repo and use `pip install -e .` (or `uv pip install -e .`) — this gives you the flexibility to modify the code and see changes immediately.

Both are valid best practices for different use cases!

[Rest of your existing README...]