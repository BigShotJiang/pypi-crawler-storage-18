"""Tests for confee package."""
