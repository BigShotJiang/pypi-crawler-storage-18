"""Configuration management for drift."""
