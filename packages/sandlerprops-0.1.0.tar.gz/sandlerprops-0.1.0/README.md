# sandlerprops
> A Python interface to the pure-component properties database that originally accompanied the textbook _Chemical, Biochemical, and Engineering Thermodynamics_ (4th edition) by Stan Sandler (Wiley, USA).

## Installation

```sh
pip install sandlerprops
```

## Usage example

### Command-line interface

```bash
$ sandlerprops find methane
Found exact match: methane (index 116)
$ sandlerprops find methanx
methanx not found.  Here are similars:
methane
methanol
ethane
ethanol
methylal
methyl amine
nitromethane
deutromethane
methyl silane
dimethylamine
$ sandlerprops show methane
Properties for methane (index 116):
  No: 116
  Formula: CH4
  Name: methane
  Molwt: 16.043 g/mol
  Tfp: 90.7 K
  Tb: 111.6 K
  Tc: 190.4 K
  Pc: 46.0 bar
  Vc: 99.2 m3/mol
  Zc: 0.288
  Omega: 0.011
  Dipm: 0.0
  CpA: 19.25 J/mol-K
  CpB: 0.05213 J/mol-K2
  CpC: 1.197e-05 J/mol-K3
  CpD: -1.132e-08 J/mol-K4
  dHf: -74900.0 J/mol
  dGf: -50870.0 J/mol
  Eq: 1
  VpA: -6.00435
  VpB: 1.1185
  VpC: -0.83408
  VpD: -1.22833
  Tmin: 91.0 K
  Tmax: 190.4 K
  Lden: 0.425
  Tden: 112.0
```

### API

```python
>>> from sandlerprops.properties import Properties as P
>>> m = P.get_compound('methane')
>>> m.Molwt
16.043
>>> p.U.Molwt
'g/mol'
>>> m.Tc
190.4
>>> p.U.Tc
'K'
>>> e = P.get_compound('ethanz')
ethanz not found.  Here are similars:
ethane
methane
ethanol
methanol
ethyl amine
ethylene
methylal
methyl amine
ethylbenzene
nitromethane
```

## Release History

* 0.1.0
    * command-line interface
* 0.0.3
    * returns similar names found in database if requested name is not found
* 0.0.2
    * Updated dependencies
* 0.0.1
    * Initial version

## Meta

Cameron F. Abrams – cfa22@drexel.edu

Distributed under the MIT license. See ``LICENSE`` for more information.

[https://github.com/cameronabrams](https://github.com/cameronabrams/)

## Contributing

1. Fork it (<https://github.com/cameronabrams/sandlerprops/fork>)
2. Create your feature branch (`git checkout -b feature/fooBar`)
3. Commit your changes (`git commit -am 'Add some fooBar'`)
4. Push to the branch (`git push origin feature/fooBar`)
5. Create a new Pull Request
