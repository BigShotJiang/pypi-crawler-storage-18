# freellama/__main__.py
from .core import FreeLlama
import argparse
import sys

def main():
    parser = argparse.ArgumentParser(description="FreeLlama - Free Llama-3.3-70B Chatbot")
    parser.add_argument("--limit", type=int, default=None, help="Auto-reset conversation after N messages")
    parser.add_argument("--stream", action="store_true", help="Show response token-by-token (streaming)")
    parser.add_argument("message", nargs="?", default=None, help="Send a single message and exit")

    args = parser.parse_args()

    bot = FreeLlama(limit=args.limit, stream=args.stream)

    if args.message:
        # One-shot mode
        response = bot.ask(args.message)
        # In streaming mode, response is already printed live → don't print again
        if not args.stream:
            print(response)
    else:
        # Interactive mode
        print("FreeLlama — Free Llama-3.3-70B | Type 'exit' to quit\n")
        while True:
            try:
                user_input = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye!")
                sys.exit(0)

            if user_input.lower() in ["exit", "quit", "bye"]:
                print("Goodbye!")
                break

            if user_input:
                response = bot.ask(user_input)

                # Only print full response if NOT in streaming mode
                if not args.stream and response:
                    print("Bot:", response)
                    print()

                # In streaming mode: already printed token-by-token + final newline in core.py
                # So we just add an extra blank line for spacing
                elif args.stream:
                    print()  # extra spacing after streamed response

if __name__ == "__main__":
    main()
