# freellama/core.py
import requests
import json
from datetime import datetime, timezone
from typing import List, Dict, Optional

URL = "https://cachegpt.app/api/v2/unified-chat-stream"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0",
    "Accept": "*/*",
    "Content-Type": "application/json",
    "Origin": "https://cachegpt.app",
    "Referer": "https://cachegpt.app/chat",
}

class FreeLlama:
    """
    Simple client for cachegpt.app

    - When limit is set  → sends full conversation history on every request
    - When limit is None → sends only the current user message (stateless)
    - Respects message limit and auto-resets conversation when reached
    """

    def __init__(self, limit: Optional[int] = None, stream: bool = False):
        """
        limit : int or None
            If set, enables history sending and auto-reset after N user messages
        stream: bool
            If True, prints tokens as they arrive (only affects .chat())
        """
        self.limit = limit
        self.stream = stream

        # Internal conversation state
        self.full_history: List[Dict] = []      # used only when limit is set
        self.user_message_count = 0
        self.conversation_id = 1

    def _now(self):
        return datetime.now(timezone.utc).isoformat(timespec='milliseconds') + "Z"

    def _send(self, messages: List[Dict]) -> str:
        payload = {"messages": messages}

        try:
            with requests.post(URL, headers=HEADERS, json=payload, stream=True, timeout=60) as r:
                if r.status_code != 200:
                    return f"[Error {r.status_code}]"

                full = ""
                for line in r.iter_lines():
                    if not line:
                        continue
                    line = line.decode().strip()
                    if not line.startswith("data: "):
                        continue
                    data = line[6:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                        text = chunk.get("content", "")
                        if self.stream:
                            print(text[len(full):], end="", flush=True)
                        full = text
                        if chunk.get("done"):
                            break
                    except json.JSONDecodeError:
                        pass
                if self.stream:
                    print()
                return full.strip()
        except Exception as e:
            return f"[Error: {e}]"

    def ask(self, message: str) -> str:
        """Send a message and return the assistant's response"""
        if not message.strip():
            return ""

        # Reset conversation if limit reached
        if self.limit and self.user_message_count >= self.limit:
            self.full_history.clear()
            self.user_message_count = 0
            self.conversation_id += 1

        user_msg = {
            "role": "user",
            "content": message,
            "created_at": self._now()
        }

        if self.limit:
            # === MEMORY MODE: send full history ===
            # Append new user message to history first
            self.full_history.append(user_msg)
            self.user_message_count += 1

            # Send the entire history
            response = self._send(self.full_history)

            # If successful, add assistant reply to history
            if response and not response.startswith("[Error"):
                self.full_history.append({
                    "role": "assistant",
                    "content": response,
                    "created_at": self._now()
                })
        else:
            # === STATELESS MODE: send only current message ===
            response = self._send([user_msg])

        return response

    def chat(self):
        """Interactive CLI"""
        print("=== FreeLlama (Free Llama-3.3-70B) ===")
        mode = "WITH MEMORY" if self.limit else "STATELESS"
        limit_info = f" (limit: {self.limit} messages)" if self.limit else ""
        print(f"Mode: {mode}{limit_info}")
        print("Type 'exit' to quit\n")

        print(f"--- Conversation #{self.conversation_id} ---\n")

        while True:
            try:
                user_input = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye!")
                break

            if user_input.lower() in ["exit", "quit", "bye"]:
                print("Goodbye!")
                break

            response = self.ask(user_input)

            print("Bot:", response)
            print()

            if self.limit and self.user_message_count >= self.limit:
                print(f"\nLIMIT REACHED ({self.limit} messages)")
                print("Starting new conversation...\n")

    def reset(self):
        """Manually start a new conversation"""
        self.full_history.clear()
        self.user_message_count = 0
        self.conversation_id += 1
