#!/usr/bin/env python3
"""
NanoBot - Main entry point

Usage:
    python nanobot/main.py                    # Simulation mode
    python nanobot/main.py --server HOST:PORT # Server connection mode
    python nanobot/main.py --test             # Test nodes
    python nanobot/main.py --mode enhanced    # Use enhanced nodes
"""

import argparse
import time
import sys
import os

# Auto-fix path for direct execution
if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from nanobot.core import NodeEngine, SensorData, Action

# Legacy nodes
from nanobot.nodes import SafetyNode, NavigationNode, ExplorerNode

# New nodes (lite version inspired by robot/nodes)
from nanobot.nodes import (
    NavigationMemory,
    CornerTrappedNode,
    WallAheadNode,
    OscillationNode,
    FrictionNode,
    ScanNode,
    LoopNode,
    DeadEndNode,
    HistoryNode,
    CorridorNode,
)


def create_engine_legacy(debug: bool = False) -> NodeEngine:
    """Create engine with legacy nodes."""
    engine = NodeEngine(debug=debug)
    engine.add_node(SafetyNode())
    engine.add_node(NavigationNode())
    engine.add_node(ExplorerNode())
    return engine


def create_engine_enhanced(debug: bool = False) -> NodeEngine:
    """
    Create engine with enhanced nodes.

    Inspired by robot/nodes architecture:
    - Pythagore geometry for turn viability
    - Score-based priority system
    - Memory-based loop/dead-end detection
    - Anti-oscillation mechanisms
    """
    engine = NodeEngine(debug=debug)

    # Shared navigation memory for loop/dead-end tracking
    memory = NavigationMemory()

    # Physical nodes (high priority) - respond to immediate environment
    engine.add_node(CornerTrappedNode())   # Priority 1 - escape corners
    engine.add_node(WallAheadNode())       # Priority 2 - handle wall ahead
    engine.add_node(OscillationNode())     # Priority 3 - break zigzag patterns
    engine.add_node(FrictionNode())        # Priority 4 - wall friction correction
    engine.add_node(ScanNode())            # Priority 5 - intersection scanning

    # Memory nodes (medium priority) - use navigation history
    engine.add_node(LoopNode(memory))      # Priority 6 - loop detection
    engine.add_node(DeadEndNode(memory))   # Priority 8 - dead-end avoidance
    engine.add_node(HistoryNode(memory))   # Priority 9 - favor unexplored

    # Low priority nodes
    engine.add_node(CorridorNode())        # Priority 50 - corridor acceleration

    # Store memory reference for action recording
    engine._memory = memory

    return engine


def create_engine(mode: str = "enhanced", debug: bool = False) -> NodeEngine:
    """
    Create engine with specified mode.

    Args:
        mode: "legacy" or "enhanced"
        debug: Enable debug output
    """
    if mode == "legacy":
        return create_engine_legacy(debug)
    else:
        return create_engine_enhanced(debug)


def run_simulation(engine: NodeEngine):
    """Simulation mode - test with mock data."""
    print("=== NanoBot Simulation ===")
    print(f"Nodes: {engine}")
    print()

    # Test scenarios
    scenarios = [
        ("Clear path", SensorData(front=2.0, left=1.0, right=1.0)),
        ("Wall ahead", SensorData(front=0.2, left=1.0, right=1.0)),
        ("Right angle", SensorData(front=1.5, left=1.0, right=0.2)),
        ("Left angle", SensorData(front=1.5, left=0.2, right=1.0)),
        ("Narrow corridor", SensorData(front=2.0, left=0.3, right=0.3)),
        ("Stuck", SensorData(front=0.2, left=0.2, right=0.2)),
        ("Intersection L", SensorData(front=0.5, left=2.0, right=0.5,
                                       left_front=1.5, right_front=0.4)),
        ("Intersection R", SensorData(front=0.5, left=0.5, right=2.0,
                                       left_front=0.4, right_front=1.5)),
    ]

    for name, sensors in scenarios:
        decision = engine.tick(sensors)
        print(f"{name:15} | {sensors} -> {decision}")

    print()
    print("Simulation complete.")


def run_server_mode(engine: NodeEngine, server: str):
    """Server mode - connect to maze-server."""
    if not HAS_REQUESTS:
        print("ERROR: requests module required. Install with: pip install requests")
        sys.exit(1)

    print(f"=== NanoBot Server Mode ===", flush=True)
    print(f"Connecting to: {server}", flush=True)
    print(f"Nodes: {engine}", flush=True)
    print(flush=True)

    base_url = f"http://{server}"
    tick_interval = 0.05  # 50ms between ticks

    # Session HTTP persistante (reuses TCP connection)
    session = requests.Session()

    # Get memory reference if using enhanced engine
    memory = getattr(engine, '_memory', None)

    while True:
        try:
            # 1. Get sensors
            resp = session.get(f"{base_url}/sensors", timeout=1)
            if resp.status_code != 200:
                print(f"Sensors error: {resp.status_code}", flush=True)
                time.sleep(0.5)
                continue

            data = resp.json()
            sensors = SensorData.from_dict(data)

            # 2. Evaluate with engine
            decision = engine.tick(sensors)

            if decision:
                # 3. Send command
                action_name = decision.action.name.lower()
                cmd = {
                    "action": action_name,
                    "speed": decision.speed
                }

                session.post(f"{base_url}/command", json=cmd, timeout=0.5)

                # 4. Record action in memory for loop/dead-end tracking
                if memory:
                    memory.record_action(action_name, decision.speed)

                if engine.debug:
                    print(f"[{engine.tick_count}] {decision}", flush=True)

            time.sleep(tick_interval)

        except requests.exceptions.Timeout:
            print("Timeout, retrying...")
            time.sleep(0.5)
        except requests.exceptions.ConnectionError:
            print("Connection lost, retrying...")
            time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping...")
            try:
                session.post(f"{base_url}/command",
                    json={"action": "stop", "speed": 0}, timeout=0.5)
            except:
                pass
            session.close()
            break


def run_tests(engine: NodeEngine):
    """Test mode - verify node behavior."""
    print("=== NanoBot Tests ===")
    print()

    tests_passed = 0
    tests_failed = 0

    def test(name: str, sensors: SensorData, expected_action: Action):
        nonlocal tests_passed, tests_failed
        engine.reset()
        decision = engine.tick(sensors)

        if decision and decision.action == expected_action:
            print(f"[PASS] {name}")
            tests_passed += 1
        else:
            actual = decision.action if decision else "None"
            print(f"[FAIL] {name}: expected {expected_action.name}, got {actual}")
            tests_failed += 1

    # Safety tests
    test("Safety: front blocked -> turn",
         SensorData(front=0.2, left=1.0, right=0.5),
         Action.TURN_LEFT)

    test("Safety: front blocked, right has space -> turn right",
         SensorData(front=0.2, left=0.5, right=1.0),
         Action.TURN_RIGHT)

    test("Safety: all blocked -> backward",
         SensorData(front=0.2, left=0.2, right=0.2),
         Action.BACKWARD)

    # Navigation tests
    test("Navigation: angle right -> turn left",
         SensorData(front=1.5, left=1.0, right=0.25),
         Action.TURN_LEFT)

    test("Navigation: angle left -> turn right",
         SensorData(front=1.5, left=0.25, right=1.0),
         Action.TURN_RIGHT)

    # Explorer tests
    test("Explorer: clear path -> forward",
         SensorData(front=3.0, left=1.0, right=1.0),
         Action.FORWARD)

    print()
    print(f"Results: {tests_passed} passed, {tests_failed} failed")

    return tests_failed == 0


def main():
    parser = argparse.ArgumentParser(
        description="NanoBot - Robot navigation framework"
    )
    parser.add_argument(
        "--server", "-s",
        help="Server address (HOST:PORT)"
    )
    parser.add_argument(
        "--test", "-t",
        action="store_true",
        help="Run tests"
    )
    parser.add_argument(
        "--debug", "-d",
        action="store_true",
        help="Enable debug output"
    )
    parser.add_argument(
        "--mode", "-m",
        choices=["legacy", "enhanced"],
        default="enhanced",
        help="Engine mode: legacy (basic) or enhanced (new nodes)"
    )

    args = parser.parse_args()

    engine = create_engine(mode=args.mode, debug=args.debug)

    if args.test:
        success = run_tests(engine)
        sys.exit(0 if success else 1)
    elif args.server:
        run_server_mode(engine, args.server)
    else:
        run_simulation(engine)


if __name__ == "__main__":
    main()
