"""
Scan nodes - Lite version inspired by robot/nodes/stop.py

Predictive intersection scanning:
- ScanNode: Detect and handle intersections
"""

from typing import Optional
from ..core.node import Node, Decision, Action
from ..core.sensors import SensorData
from ..config import RobotConfig, Score
from .base import SensorEvaluator


class ScanNode(Node):
    """
    Predictive intersection scanner.

    Detects intersections and chooses best direction.
    Uses lockout mechanism to protect decisions.

    Priority: 5
    Score: CRITICAL (85-94)
    """

    def __init__(self):
        super().__init__("SCAN", priority=5)
        self.decision_tick = 0
        self.lockout_remaining = 0
        self.last_direction = None

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            # During lockout, maintain last decision
            if self.lockout_remaining > 0 and self.last_direction:
                self.lockout_remaining -= 1
                return Decision(
                    action=self.last_direction,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"SCAN: lockout {self.lockout_remaining}, continuing",
                    score=Score.calculate("CRITICAL", 0.7)
                )
            return None

        # Decrease lockout
        if self.lockout_remaining > 0:
            self.lockout_remaining -= 1
            if self.last_direction:
                return Decision(
                    action=self.last_direction,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"SCAN: lockout {self.lockout_remaining}, continuing",
                    score=Score.calculate("CRITICAL", 0.7)
                )

        analysis = SensorEvaluator.analyze(sensors)

        # In corridor? Don't scan
        if analysis['corridor']:
            self.last_direction = None
            return None

        # No intersection? Don't scan
        if not analysis['intersection']:
            self.last_direction = None
            return None

        front = analysis['front']
        max_left = analysis['max_left']
        max_right = analysis['max_right']

        # Evaluate each direction
        directions = []

        # Forward
        if analysis['can_advance']:
            score_fwd = front / analysis['max_all'] if analysis['max_all'] > 0 else 0.5
            directions.append(('forward', Action.FORWARD, score_fwd, front))

        # Left
        if analysis['can_turn_left']:
            score_left = max_left / analysis['max_all'] if analysis['max_all'] > 0 else 0.5
            directions.append(('left', Action.TURN_LEFT, score_left, max_left))

        # Right
        if analysis['can_turn_right']:
            score_right = max_right / analysis['max_all'] if analysis['max_all'] > 0 else 0.5
            directions.append(('right', Action.TURN_RIGHT, score_right, max_right))

        if not directions:
            return None

        # Sort by score (highest first)
        directions.sort(key=lambda x: x[2], reverse=True)
        best = directions[0]
        name, action, dir_score, space = best

        # Forward priority: only turn if side has 30%+ more space
        if analysis['can_advance'] and action != Action.FORWARD:
            if space < front * 1.3:
                # Not enough advantage to turn
                action = Action.FORWARD
                name = 'forward'
                space = front

        # Set lockout
        if action in [Action.TURN_LEFT, Action.TURN_RIGHT]:
            self.last_direction = action
            self.lockout_remaining = RobotConfig.SCAN_LOCKOUT_TICKS

        score = Score.calculate("CRITICAL", 0.6 + dir_score * 0.3)

        return Decision(
            action=action,
            speed=RobotConfig.SPEED_SLOW if action != Action.FORWARD else RobotConfig.SPEED_NORMAL,
            reason=f"SCAN: intersection, {name} has {space:.2f}m",
            score=score
        )

    def reset(self):
        self.decision_tick = 0
        self.lockout_remaining = 0
        self.last_direction = None
