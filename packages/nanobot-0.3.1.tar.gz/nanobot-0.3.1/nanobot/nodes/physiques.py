"""
Physical navigation nodes - Lite version inspired by robot/nodes/physiques.py

Nodes for physical obstacle detection and avoidance:
- WallAheadNode: Front wall detection
- CornerTrappedNode: Corner trapped state
- OscillationNode: Pattern detection (zigzag)
- CorridorNode: Corridor acceleration
- FrictionNode: Side wall friction correction
"""

from typing import Optional
from ..core.node import Node, Decision, Action
from ..core.sensors import SensorData
from ..config import RobotConfig, Score
from .base import SensorEvaluator


class WallAheadNode(Node):
    """
    Front wall detection - turn when wall ahead.

    Priority: 2 (after safety)
    Score: CRITICAL (85-94)
    """

    def __init__(self):
        super().__init__("WALL_AHEAD", priority=2)

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        analysis = SensorEvaluator.analyze(sensors)

        # Not blocked? Let others decide
        if analysis['can_advance']:
            return None

        front = analysis['front']

        # Calculate score based on distance
        score = Score.from_distance("CRITICAL", front, 0, RobotConfig.DIAG_CHASSIS)

        # Choose direction using Pythagore
        if analysis['can_turn_left'] and analysis['can_turn_right']:
            # Both viable - choose larger space
            if analysis['max_left'] > analysis['max_right']:
                return Decision(
                    action=Action.TURN_LEFT,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"WALL: front={front:.2f}m, left has more space",
                    score=score
                )
            else:
                return Decision(
                    action=Action.TURN_RIGHT,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"WALL: front={front:.2f}m, right has more space",
                    score=score
                )
        elif analysis['can_turn_left']:
            return Decision(
                action=Action.TURN_LEFT,
                speed=RobotConfig.SPEED_SLOW,
                reason=f"WALL: front={front:.2f}m, only left viable",
                score=score
            )
        elif analysis['can_turn_right']:
            return Decision(
                action=Action.TURN_RIGHT,
                speed=RobotConfig.SPEED_SLOW,
                reason=f"WALL: front={front:.2f}m, only right viable",
                score=score
            )
        else:
            # Nothing viable - backward
            return Decision(
                action=Action.BACKWARD,
                speed=RobotConfig.SPEED_VERY_SLOW,
                reason=f"WALL: front={front:.2f}m, backing up",
                score=Score.calculate("URGENT", 0.9)
            )


class CornerTrappedNode(Node):
    """
    Corner trapped state - escape when all directions blocked.

    Priority: 1 (high)
    Score: URGENT (95-100)
    """

    def __init__(self):
        super().__init__("CORNER_TRAPPED", priority=1)
        self.escape_count = 0

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        analysis = SensorEvaluator.analyze(sensors)

        if not analysis['corner_blocked']:
            self.escape_count = 0
            return None

        self.escape_count += 1

        # Cycle: backup(2x) -> turn(2x) -> repeat
        cycle = self.escape_count % 4
        score = Score.calculate("URGENT", 0.8 + min(self.escape_count * 0.02, 0.2))

        if cycle < 2:
            return Decision(
                action=Action.BACKWARD,
                speed=RobotConfig.SPEED_VERY_SLOW,
                reason=f"CORNER: escape {self.escape_count}x, backing up",
                score=score
            )
        else:
            # Turn toward more space
            if analysis['max_left'] > analysis['max_right']:
                return Decision(
                    action=Action.TURN_LEFT,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"CORNER: escape {self.escape_count}x, turning left",
                    score=score
                )
            else:
                return Decision(
                    action=Action.TURN_RIGHT,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"CORNER: escape {self.escape_count}x, turning right",
                    score=score
                )

    def reset(self):
        self.escape_count = 0


class OscillationNode(Node):
    """
    Oscillation/zigzag pattern detection - break repetitive patterns.

    Priority: 3
    Score: NORMAL (50-69)
    """

    def __init__(self):
        super().__init__("OSCILLATION", priority=3)
        self.action_history: list = []
        self.max_history = 8

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        if len(self.action_history) < 4:
            return None

        # Detect zigzag pattern
        recent = self.action_history[-4:]
        is_zigzag = (
            recent == ["turn_left", "turn_right", "turn_left", "turn_right"] or
            recent == ["turn_right", "turn_left", "turn_right", "turn_left"]
        )

        if not is_zigzag:
            return None

        analysis = SensorEvaluator.analyze(sensors)

        # Break pattern - go forward if possible, else turn strongly
        if analysis['can_advance']:
            return Decision(
                action=Action.FORWARD,
                speed=RobotConfig.SPEED_SLOW,
                reason="OSCILLATION: breaking zigzag, forward",
                score=Score.calculate("NORMAL", 0.8)
            )
        else:
            # Turn toward larger space
            if analysis['max_left'] > analysis['max_right']:
                return Decision(
                    action=Action.TURN_LEFT,
                    speed=RobotConfig.SPEED_NORMAL,
                    reason="OSCILLATION: breaking zigzag, strong left",
                    score=Score.calculate("NORMAL", 0.9)
                )
            else:
                return Decision(
                    action=Action.TURN_RIGHT,
                    speed=RobotConfig.SPEED_NORMAL,
                    reason="OSCILLATION: breaking zigzag, strong right",
                    score=Score.calculate("NORMAL", 0.9)
                )

    def record_action(self, action: str):
        """Record action for pattern detection."""
        self.action_history.append(action)
        if len(self.action_history) > self.max_history:
            self.action_history.pop(0)

    def reset(self):
        self.action_history.clear()


class CorridorNode(Node):
    """
    Corridor detection - accelerate when in a clear corridor.

    Priority: 50 (low - only when safe)
    Score: LOW (30-49)
    """

    def __init__(self):
        super().__init__("CORRIDOR", priority=50)

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        analysis = SensorEvaluator.analyze(sensors)

        if not analysis['corridor']:
            return None

        front = analysis['front']

        # Calculate speed based on available space
        if front > RobotConfig.DISTANCE_FAR:
            speed = RobotConfig.SPEED_MAX
            score = Score.calculate("LOW", 0.9)
        elif front > RobotConfig.DISTANCE_COMFORT:
            speed = RobotConfig.SPEED_NORMAL
            score = Score.calculate("LOW", 0.7)
        else:
            speed = RobotConfig.SPEED_SLOW
            score = Score.calculate("LOW", 0.5)

        return Decision(
            action=Action.FORWARD,
            speed=speed,
            reason=f"CORRIDOR: clear {front:.2f}m, accelerating",
            score=score
        )


class FrictionNode(Node):
    """
    Side friction correction - micro-adjust when rubbing against wall.

    Priority: 4
    Score: NORMAL (50-69)
    """

    def __init__(self):
        super().__init__("FRICTION", priority=4)

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        analysis = SensorEvaluator.analyze(sensors)

        # Only apply if can advance (not blocked)
        if not analysis['can_advance']:
            return None

        # Detect friction
        if analysis['friction_left']:
            return Decision(
                action=Action.TURN_RIGHT,
                speed=RobotConfig.SPEED_VERY_SLOW,
                reason=f"FRICTION: left={analysis['min_left']:.2f}m, adjusting right",
                score=Score.calculate("NORMAL", 0.5)
            )
        elif analysis['friction_right']:
            return Decision(
                action=Action.TURN_LEFT,
                speed=RobotConfig.SPEED_VERY_SLOW,
                reason=f"FRICTION: right={analysis['min_right']:.2f}m, adjusting left",
                score=Score.calculate("NORMAL", 0.5)
            )

        return None
