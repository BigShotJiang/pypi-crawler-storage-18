"""
----------------------------------------------------------------------
>>> Author       : Junshan Yin  
>>> Last Updated : 2025-10-28
----------------------------------------------------------------------
"""

import torchvision, torch
import torchvision.transforms as transforms
import pandas as pd
import numpy as np
from torch.utils.data import random_split, Subset
from collections import Counter

from junshan_kit import DataSets, DataProcessor, ParametersHub

def Adult_Income_Prediction(seed=42, print_info = False):

    df = DataSets.adult_income_prediction(print_info=print_info) 
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='income'

    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform


def Credit_Card_Fraud_Detection(seed=42, print_info = False):
    df = DataSets.credit_card_fraud_detection(print_info=print_info)
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='Class'

    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform

def CIFAR100(model_type, print_info=False, class0=0, class1=1, root="./exp_data/CIFAR100"):
    """
    Load the CIFAR-100 dataset and return training set, test set,
    and applied transform.
    """
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.5071, 0.4867, 0.4408],
            std=[0.2675, 0.2565, 0.2761]
        )
    ])

    train_dataset = torchvision.datasets.CIFAR100(
        root=root,
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.CIFAR100(
        root=root,
        train=False,
        download=True,
        transform=transform
    )

    if model_type == "binary":
        DataProcessor.check_binary_classes(train_dataset, class0, class1)
        DataProcessor.check_binary_classes(test_dataset, class0, class1)

        train_dataset = DataProcessor.BinaryDatasetWrapper(train_dataset, class0, class1)
        test_dataset  = DataProcessor.BinaryDatasetWrapper(test_dataset, class0, class1)

    if print_info:
        if model_type == "binary":
            task_type = f"Binary ({class0} -> 0 vs {class1} -> 1)"
        else:
            task_type = "Multiclass (0-99)"

        print("\n" + "=" * 80)
        print(f"{'CIFAR100 - Summary':^60}")
        print("=" * 80)
        print(f"Task Type     : {task_type}")
        print(f"Train Samples : {len(train_dataset):,}")
        print(f"Test Samples  : {len(test_dataset):,}")
        print(f"Image Shape   : 3 x 32 x 32")
        print(f"Transform     : {transform}")
        print("\n" + "=" * 80)

    return train_dataset, test_dataset, transform

def CIFAR10(model_type, print_info=False, class0=0, class1=1, root="./exp_data/CIFAR10"):
    """
    Load the CIFAR-10 dataset and return training set, test set,
    and applied transform.
    """
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.4914, 0.4822, 0.4465],
            std=[0.2023, 0.1994, 0.2010]
        )
    ])

    train_dataset = torchvision.datasets.CIFAR10(
        root=root,
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.CIFAR10(
        root=root,
        train=False,
        download=True,
        transform=transform
    )

    if model_type == "binary":
        DataProcessor.check_binary_classes(train_dataset, class0, class1)
        DataProcessor.check_binary_classes(test_dataset, class0, class1)

        train_dataset = DataProcessor.BinaryDatasetWrapper(train_dataset, class0, class1)
        test_dataset  = DataProcessor.BinaryDatasetWrapper(test_dataset, class0, class1)

    if print_info:
        if model_type == "binary":
            task_type = f"Binary ({class0} -> 0 vs {class1} -> 1)"
        else:
            task_type = "Multiclass (0-9)"

        print("\n" + "=" * 80)
        print(f"{'CIFAR10 - Summary':^60}")
        print("=" * 80)
        print(f"Task Type     : {task_type}")
        print(f"Train Samples : {len(train_dataset):,}")
        print(f"Test Samples  : {len(test_dataset):,}")
        print(f"Image Shape   : 3 x 32 x 32")
        print(f"Transform     : {transform}")
        print("\n" + "=" * 80)

    return train_dataset, test_dataset, transform

def Diabetes_Health_Indicators(seed=42, print_info = False):
    df = DataSets.diabetes_health_indicators(print_info=print_info)
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='diagnosed_diabetes'

    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform

def Electric_Vehicle_Population(seed=42, print_info = False): 
    df = DataSets.electric_vehicle_population(print_info=print_info)
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='Electric Vehicle Type'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform

def Global_House_Purchase(seed=42, print_info = False): 
    df = DataSets.global_house_purchase(print_info=print_info)
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='decision'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform

def Health_Lifestyle(seed=42, print_info = False): 
    df = DataSets.health_lifestyle(print_info=print_info)
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='disease_risk'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform

def Homesite_Quote_Conversion(seed=42, print_info = False): 
    df = DataSets.Homesite_Quote_Conversion(print_info=print_info)
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='QuoteConversion_Flag'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform

def TN_Weather_2020_2025(seed=42, print_info = False): 
    df = DataSets.TamilNadu_weather_2020_2025(print_info=print_info)
    transform = {
        "train_size": 0.7,
        "normalization": True
    }
    label_col='rain_tomorrow'
    train_dataset, test_dataset, transform = DataProcessor.Pandas_TO_Torch(df, label_col).to_torch(transform, seed)

    return train_dataset, test_dataset, transform


def MNIST(model_type, print_info=False, class0=0, class1=1, root="./exp_data/MNIST"):
    """
    Load the MNIST dataset and return training set, test set,
    and applied transform.
    """
    transform = torchvision.transforms.ToTensor()

    train_dataset = torchvision.datasets.MNIST(
        root=root,
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.MNIST(
        root=root,
        train=False,
        download=True,
        transform=transform
    )

    if model_type == "binary":
        DataProcessor.check_binary_classes(train_dataset, class0, class1)
        DataProcessor.check_binary_classes(test_dataset, class0, class1)

        train_dataset = DataProcessor.BinaryDatasetWrapper(train_dataset, class0, class1)
        test_dataset  = DataProcessor.BinaryDatasetWrapper(test_dataset, class0, class1)

    if print_info:
        if model_type == "binary":
            task_type = f"Binary ({class0} -> 0 vs {class1} -> 1)"
        else:
            task_type = "Multiclass (0–9)"

        print("\n" + "=" * 55)
        print(f"{'MNIST - Summary':^60}")
        print("=" * 55)
        print(f"Task Type     : {task_type}")
        print(f"Train Samples : {len(train_dataset):,}")
        print(f"Test Samples  : {len(test_dataset):,}")
        print(f"Image Shape   : 1 x 28 x 28")
        print(f"Transform     : {transform}")
        print("=" * 55 + "\n")

    return train_dataset, test_dataset, transform


def Caltech101_Resize_32(model_type, print_info=False, class0=0, class1=1, train_ratio=0.7, split=True, root="./exp_data/Caltech101"):
    """
    Caltech101 resized to 32x32.
    Supports binary (class0 vs class1) and multiclass.
    """
    transform = transforms.Compose([
        transforms.ToTensor(),
    ])

    full_dataset = torchvision.datasets.Caltech101(
        root=root,
        download=True,
        transform=transform
    )

    class_name = sorted(full_dataset.categories)  # 按字母排序

    # --------- binary classification ---------
    if model_type == "binary":
        full_dataset = DataProcessor.BinaryDatasetWrapper(
            full_dataset, class0, class1, targets=full_dataset.y
        )

    # --------- train / test split ---------
    if split:
        total_size = len(full_dataset)
        train_size = int(train_ratio * total_size)
        test_size = total_size - train_size
        train_dataset, test_dataset = random_split(
            full_dataset, [train_size, test_size]
        )
    else:
        train_dataset = full_dataset
        test_dataset = Subset(full_dataset, [])

    # --------- print_info ---------
    if print_info:
        if model_type == "binary":
            task_type = f"Binary ({class0}:{class_name[class0]}) -> 0 vs ({class1}:{class_name[class1]}) -> 1"
        else:
            task_type = "Multiclass (Caltech101)"
        def get_class_stats(dataset, name="Dataset"):
            try:
                # Both subset and dataset can be accessed using an index
                labels = [dataset[i][1] for i in range(len(dataset))]
            except:
                labels = dataset.y  # fallback
            counter = Counter(labels)
            print(f"{name} classes: {len(counter)}")

            # Calculate the maximum length of the category fro left alignment
            max_name_len = max(len(class_name[k] if model_type != "binary" else f"Class {k}") for k in counter.keys())

            for k in sorted(counter.keys()):
                label_name = class_name[k] if model_type != "binary" else f"Class {k}"
                print(f"  {label_name:<{max_name_len}}  {counter[k]:>3}")
            print("")

        print("\n" + "=" * 60)
        print(f"{'Caltech101 - Summary':^60}")
        print("=" * 60)
        print(f"Task Type     : {task_type}")
        print(f"Train Samples : {len(train_dataset):,}")
        get_class_stats(train_dataset, name="Train Set")
        print(f"Test Samples  : {len(test_dataset):,}")
        get_class_stats(test_dataset, name="Test Set")
        print(f"Image Shape   : 3 x 32 x 32")
        print(f"Transform     : {transform}")
        print("=" * 60 + "\n")

    return train_dataset, test_dataset, transform

def SVHN(binary, class0=0, class1=1, root="./exp_data/SVHN"):
    # Data transformation
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.4377, 0.4438, 0.4728],
            std=[0.1980, 0.2010, 0.1970]
        )
    ])

    # Load dataset
    train_dataset = torchvision.datasets.SVHN(
        root=root,
        split="train",
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.SVHN(
        root=root,
        split="test",
        download=True,
        transform=transform
    )

    # Handle binary classification case
    if binary:
        # Method 1: directly filter the dataset (recommended)
        train_indices = []
        test_indices = []

        # Get training set indices
        for i in range(len(train_dataset)):
            # SVHN label access: train_dataset.labels[i] or train_dataset[i][1]
            label = train_dataset[i][1]
            if label in [class0, class1]:
                train_indices.append(i)

        # Get test set indices
        for i in range(len(test_dataset)):
            label = test_dataset[i][1]
            if label in [class0, class1]:
                test_indices.append(i)

        # Create subsets
        train_dataset = Subset(train_dataset, train_indices)
        test_dataset = Subset(test_dataset, test_indices)

    return train_dataset, test_dataset, transform
