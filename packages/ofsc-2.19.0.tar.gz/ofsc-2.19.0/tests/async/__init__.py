"""Async module tests."""
