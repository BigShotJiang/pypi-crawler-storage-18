#!/usr/bin/env python3
"""
Test audio encoding and decoding with CarLib
"""
import os
import sys
sys.path.insert(0, '/Users/macbook/Desktop/rightsify/rnd/carlib')

from carlib.processors.audio_codecs import EncodecAudioProcessor, AudioConfig
from carlib.decode import decode_car_file
from carlib.loaders import load_single_car

def test_audio_processing():
    """Test audio encoding and decoding pipeline"""
    print("🎵 Testing CarLib Audio Processing")
    print("=" * 50)
    
    # Input file
    input_file = "assets/Afrobeat_3.mp3"
    base_output = "test_output_audio"  # Base path without extension
    output_car = f"{base_output}.car"
    decoded_output = "test_decoded_audio.wav"
    
    if not os.path.exists(input_file):
        print(f"❌ Input file not found: {input_file}")
        return False
    
    try:
        # Step 1: Initialize processor
        print("🔧 Initializing EnCodec processor...")
        config = AudioConfig(
            model_name="facebook/encodec_24khz",
            device="cpu",  # Use CPU for testing
            target_sample_rate=24000
        )
        processor = EncodecAudioProcessor(config)
        print(f"✅ Processor initialized with {config.model_name}")
        
        # Step 2: Process single file (encode to CAR)
        print(f"\n🎵 Encoding: {input_file}")
        result = processor.process_single_file(
            audio_path=input_file,
            output_path=base_output,  # Use base path, not full path
            save_extras=[]  # Only save CAR format
        )
        
        if result['status'] != 'success':
            print(f"❌ Encoding failed: {result.get('error', 'Unknown error')}")
            return False
        
        print(f"✅ Encoding successful!")
        print(f"   Duration: {result['duration']:.2f}s")
        print(f"   Output files: {result.get('output_files', 'None')}")
        
        # Check if CAR file was created
        if 'output_files' not in result or 'car' not in result['output_files']:
            print(f"❌ No CAR file was created. Result: {result}")
            return False
        
        # Step 3: Load CAR file
        print(f"\n📄 Loading CAR file: {result['output_files']['car']}")
        car_data = load_single_car(result['output_files']['car'])
        print(f"✅ CAR file loaded successfully")
        print(f"   Data keys: {list(car_data['data'].keys())}")
        print(f"   Metadata keys: {list(car_data['metadata'].keys())}")
        
        # Step 4: Decode CAR file
        print(f"\n🔊 Decoding CAR file...")
        decode_result = decode_car_file(
            car_path=result['output_files']['car'],
            output_path=decoded_output,
            device=config.device,
            save_decoded=True
        )
        
        print(f"✅ Decoding successful!")
        print(f"   Decoded audio shape: {decode_result['decoded_data'].shape}")
        print(f"   Output file: {decode_result['output_path']}")
        
        # Step 5: Verify files exist
        car_file = result['output_files']['car']
        wav_file = decode_result['output_path']
        
        if os.path.exists(car_file):
            car_size = os.path.getsize(car_file) / 1024 / 1024  # MB
            print(f"✅ CAR file created: {car_file} ({car_size:.2f} MB)")
        
        if os.path.exists(wav_file):
            wav_size = os.path.getsize(wav_file) / 1024 / 1024  # MB
            print(f"✅ Decoded audio created: {wav_file} ({wav_size:.2f} MB)")
        
        print(f"\n🎉 Audio processing test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        # Cleanup
        cleanup_files = [f"{base_output}.car", decoded_output]
        for file in cleanup_files:
            if os.path.exists(file):
                try:
                    os.remove(file)
                    print(f"🧹 Cleaned up: {file}")
                except Exception as e:
                    print(f"⚠️  Could not clean up {file}: {e}")

if __name__ == "__main__":
    success = test_audio_processing()
    sys.exit(0 if success else 1)