from .mamo import AtiaMamo

__version__ = "0.1.0"