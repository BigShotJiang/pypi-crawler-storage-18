"""GTM Wizard test suite."""
