"""Common model package."""
