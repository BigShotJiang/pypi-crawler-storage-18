from typing import List

from bluer_options.terminal import show_usage, xtra


def help_install(
    tokens: List[str],
    mono: bool,
) -> str:
    return show_usage(
        [
            "@audio",
            "install",
        ],
        "install.",
        mono=mono,
    )


def record_options(mono: bool):
    return "".join(
        [
            xtra("filename=<audio.wav>,", mono=mono),
            "play",
            xtra(",upload", mono=mono),
        ]
    )


def help_listen(
    tokens: List[str],
    mono: bool,
) -> str:
    options = record_options(mono=mono)

    return show_usage(
        [
            "@audio",
            "listen",
            f"[{options}]",
            "[-|<object-name>]",
        ],
        "listen and record <object-name>/<audio.wav>.",
        mono=mono,
    )


def help_play(
    tokens: List[str],
    mono: bool,
) -> str:
    options = xtra("download,filename=<audio.wav>", mono=mono)

    return show_usage(
        [
            "@audio",
            "play",
            f"[{options}]",
            "[.|<object-name>]",
        ],
        "play <object-name>/<audio.wav>.",
        mono=mono,
    )


def help_record(
    tokens: List[str],
    mono: bool,
) -> str:
    options = record_options(mono=mono)

    return show_usage(
        [
            "@audio",
            "record",
            f"[{options}]",
            "[-|<object-name>]",
        ],
        "record <object-name>/<audio.wav>.",
        mono=mono,
    )


help_functions = {
    "install": help_install,
    "listen": help_listen,
    "play": help_play,
    "record": help_record,
}
