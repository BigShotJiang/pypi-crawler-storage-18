def main():
    print("Hello from gisglb!")


if __name__ == "__main__":
    main()
