"""
Controller模块测试
测试新的模块化controller
使用方法: python test_controller.py <token>
"""

import sys
import json

# 导入controller模块
from controller import (
    session,
    notebook_manager,
    kernel_manager,
    file_manager,
    code_executor
)


def test_session(url: str, token: str):
    """测试会话管理"""
    print("\n" + "="*60)
    print("测试会话管理")
    print("="*60)
    
    try:
        # 测试连接
        print("\n1. 测试连接...")
        session.connect(url, token)
        print(f"✓ 连接成功: {url}")
        
        # 测试状态
        print("\n2. 测试获取状态...")
        status = session.get_status()
        print(f"✓ 连接状态: {status['connected']}")
        print(f"  URL: {status['url']}")
        print(f"  有Token: {status['has_token']}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        return False


def test_kernel():
    """测试内核管理"""
    print("\n" + "="*60)
    print("测试内核管理")
    print("="*60)
    
    try:
        # 测试列出内核
        print("\n1. 测试列出内核和规格...")
        kernel_info = kernel_manager.list_all()
        print(f"✓ 运行中的内核: {kernel_info['running_count']} 个")
        print(f"  默认内核: {kernel_info['default_kernel']}")
        print(f"  可用内核规格: {list(kernel_info['available_specs'].keys())}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        return False


def test_file():
    """测试文件管理"""
    print("\n" + "="*60)
    print("测试文件管理")
    print("="*60)
    
    try:
        # 测试列出目录
        print("\n1. 测试列出根目录...")
        items = file_manager.list_directory("")
        print(f"✓ 找到 {len(items)} 个项目")
        
        # 显示前5个
        for item in items[:5]:
            print(f"  - {item['name']} ({item['type']})")
        
        # 测试创建目录
        print("\n2. 测试创建目录...")
        test_dir = "test_controller_dir"
        try:
            file_manager.create_directory(test_dir)
            print(f"✓ 目录创建成功: {test_dir}")
        except Exception as e:
            if "already exists" in str(e).lower():
                print(f"✓ 目录已存在: {test_dir}")
            else:
                raise
        
        # 测试写入文件
        print("\n3. 测试写入文件...")
        test_file = f"{test_dir}/test.txt"
        file_manager.write(test_file, "Hello from controller test!")
        print(f"✓ 文件写入成功: {test_file}")
        
        # 测试读取文件
        print("\n4. 测试读取文件...")
        content = file_manager.read(test_file)
        print(f"✓ 文件读取成功")
        print(f"  内容: {content.get('content', '')[:50]}...")
        
        # 测试获取文件信息
        print("\n5. 测试获取文件信息...")
        info = file_manager.get_info(test_file)
        print(f"✓ 文件信息:")
        print(f"  名称: {info['name']}")
        print(f"  大小: {info['size']} 字节")
        print(f"  类型: {info['type']}")
        
        # 测试删除文件
        print("\n6. 测试删除文件...")
        file_manager.delete(test_file)
        print(f"✓ 文件删除成功: {test_file}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_notebook():
    """测试笔记本管理"""
    print("\n" + "="*60)
    print("测试笔记本管理")
    print("="*60)
    
    try:
        # 测试列出笔记本
        print("\n1. 测试列出笔记本...")
        notebooks = notebook_manager.list_all()
        print(f"✓ 找到 {len(notebooks)} 个笔记本")
        
        # 测试创建笔记本（使用默认内核）
        print("\n2. 测试创建笔记本（使用默认内核）...")
        test_nb = "test_controller.ipynb"
        result = notebook_manager.create(test_nb)
        print(f"✓ 笔记本创建成功: {test_nb}")
        if result and result.get('content'):
            kernel = result.get('content', {}).get('metadata', {}).get('kernelspec', {}).get('name', 'unknown')
            print(f"  使用内核: {kernel}")
        else:
            print(f"  笔记本已创建（无返回内容）")
        
        # 测试获取笔记本
        print("\n3. 测试获取笔记本内容...")
        content = notebook_manager.get(test_nb)
        cells_count = len(content.get('content', {}).get('cells', []))
        print(f"✓ 笔记本内容获取成功，包含 {cells_count} 个单元格")
        
        # 测试添加单元格
        print("\n4. 测试添加代码单元格...")
        notebook_manager.add_cell(test_nb, "print('Hello from controller!')", "code")
        print(f"✓ 代码单元格添加成功")
        
        # 测试添加包含转义字符的代码单元格
        print("\n4.5. 测试添加包含转义字符的代码单元格...")
        multiline_code = "# 测试转义字符\nprint('第一行')\nprint('第二行\\t带tab')\nresult = 10 + 20\nprint(f'结果: {result}')"
        notebook_manager.add_cell(test_nb, multiline_code, "code")
        print(f"✓ 包含转义字符的代码单元格添加成功")
        
        # 验证转义字符是否正确保存
        nb_check = notebook_manager.get(test_nb)
        cells_check = nb_check.get('content', {}).get('cells', [])
        if len(cells_check) >= 2:
            last_cell_source = cells_check[-1].get('source', '')
            if isinstance(last_cell_source, list):
                last_cell_source = ''.join(last_cell_source)
            # 检查是否包含真正的换行符
            if '\n' in last_cell_source and 'print' in last_cell_source:
                print(f"✓ 转义字符验证成功：检测到真正的换行符")
                # 显示前50个字符
                print(f"  内容预览: {repr(last_cell_source[:50])}...")
            else:
                print(f"✗ 转义字符验证失败：未检测到换行符")
                print(f"  实际内容: {repr(last_cell_source[:100])}")
        
        # 测试添加markdown单元格
        print("\n5. 测试添加markdown单元格...")
        notebook_manager.add_cell(test_nb, "# Test Notebook", "markdown", position=0)
        print(f"✓ Markdown单元格添加成功")
        
        # 测试更新单元格
        print("\n6. 测试更新单元格...")
        notebook_manager.update_cell(test_nb, 1, "print('Updated code!')")
        print(f"✓ 单元格更新成功")
        
        # 测试获取更新后的内容
        print("\n7. 测试获取更新后的内容...")
        updated = notebook_manager.get(test_nb)
        cells = updated.get('content', {}).get('cells', [])
        print(f"✓ 笔记本现在有 {len(cells)} 个单元格")
        for i, cell in enumerate(cells):
            cell_type = cell.get('cell_type')
            source = ''.join(cell.get('source', []))[:50]
            print(f"  单元格 {i}: [{cell_type}] {source}...")
        
        # 测试删除单元格
        print("\n8. 测试删除单元格...")
        notebook_manager.delete_cell(test_nb, 0)
        print(f"✓ 单元格删除成功")
        
        # 测试执行单元格
        print("\n9. 测试执行单元格...")
        # 先添加一个测试单元格
        notebook_manager.add_cell(test_nb, "result = 10 + 20\nprint(f'Result: {result}')", "code")
        # 执行这个单元格（现在是第0个）
        from controller import code_executor
        nb = notebook_manager.get(test_nb)
        cells = nb.get('content', {}).get('cells', [])
        if cells:
            code = ''.join(cells[0].get('source', []))
            exec_result = code_executor.execute(test_nb, code)
            print(f"✓ 单元格执行成功")
            print(f"  内核ID: {exec_result.get('kernel_id')}")
            print(f"  状态: {exec_result.get('execution_status')}")
        
        # 测试删除笔记本
        print("\n10. 测试删除笔记本...")
        notebook_manager.delete(test_nb)
        print(f"✓ 笔记本删除成功: {test_nb}")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_executor():
    """测试代码执行"""
    print("\n" + "="*60)
    print("测试代码执行")
    print("="*60)
    
    try:
        # 先创建一个测试笔记本
        print("\n1. 创建测试笔记本...")
        test_nb = "test_executor.ipynb"
        notebook_manager.create(test_nb)
        print(f"✓ 笔记本创建成功: {test_nb}")
        
        # 测试执行代码
        print("\n2. 测试执行代码...")
        code = """
import datetime
print(f"Hello from executor test!")
print(f"Current time: {datetime.datetime.now()}")
result = 2 + 2
print(f"2 + 2 = {result}")
"""
        result = code_executor.execute(test_nb, code)
        print(f"✓ 代码已提交执行")
        print(f"  内核ID: {result['kernel_id']}")
        print(f"  状态: {result['execution_status']}")
        print(f"  消息: {result['message']}")
        
        # 清理
        print("\n3. 清理测试笔记本...")
        notebook_manager.delete(test_nb)
        print(f"✓ 笔记本删除成功")
        
        return True
    except Exception as e:
        print(f"✗ 测试失败: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """主测试函数"""
    if len(sys.argv) < 2:
        print("使用方法: python test_controller.py <token>")
        print("示例: python test_controller.py b0fc5c838e90fe1a9354c19598696e056e660fdc8305f39e")
        sys.exit(1)
    
    token = sys.argv[1]
    url = "http://localhost:8888"
    
    print("="*60)
    print("Controller模块测试")
    print("="*60)
    print(f"服务器: {url}")
    print(f"Token: {token[:20]}...")
    
    tests = [
        ("会话管理", lambda: test_session(url, token)),
        ("内核管理", test_kernel),
        ("文件管理", test_file),
        ("笔记本管理", test_notebook),
        ("代码执行", test_executor),
    ]
    
    passed = 0
    total = len(tests)
    
    for name, test_func in tests:
        try:
            if test_func():
                passed += 1
                print(f"\n✅ {name}测试通过")
            else:
                print(f"\n❌ {name}测试失败")
        except Exception as e:
            print(f"\n❌ {name}测试异常: {str(e)}")
    
    # 断开连接
    print("\n" + "="*60)
    print("清理")
    print("="*60)
    session.disconnect()
    print("✓ 已断开连接")
    
    # 总结
    print("\n" + "="*60)
    print(f"测试结果: {passed}/{total} 通过")
    print("="*60)
    
    if passed == total:
        print("🎉 所有测试通过!")
        print("\n✅ 验证的功能:")
        print("   - 会话管理（连接/断开/状态）")
        print("   - 内核管理（列出运行中内核和可用规格）")
        print("   - 文件管理（目录/文件的增删改查）")
        print("   - 笔记本管理（创建/读取/更新/删除/单元格操作）")
        print("   - 代码执行（提交代码到内核）")
    else:
        print("⚠️  部分测试失败")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
