# Jupyter Controller 模块

模块化的Jupyter Lab控制器，提供清晰的API接口。

## 架构设计

```
controller/
├── __init__.py          # 模块导出
├── session.py           # 会话管理（单例模式）
├── base.py              # 基础HTTP客户端
├── notebook.py          # 笔记本操作（CRUD）
├── kernel.py            # 内核管理
├── file.py              # 文件操作（CRUD + 上传下载）
└── executor.py          # 代码执行
```

## 使用示例

### 1. 会话管理

```python
from controller import session

# 连接到Jupyter服务器
session.connect("http://localhost:8888", "your-token")

# 检查连接状态
if session.is_connected():
    print("已连接")

# 断开连接
session.disconnect()
```

### 2. 笔记本操作

```python
from controller import notebook_manager

# 列出所有笔记本
notebooks = notebook_manager.list_all()

# 创建笔记本
notebook_manager.create("test.ipynb")

# 获取笔记本内容
content = notebook_manager.get("test.ipynb")

# 添加单元格
notebook_manager.add_cell("test.ipynb", "print('Hello')", "code")

# 更新单元格
notebook_manager.update_cell("test.ipynb", 0, "print('Updated')")

# 删除单元格
notebook_manager.delete_cell("test.ipynb", 0)

# 删除笔记本
notebook_manager.delete("test.ipynb")
```

### 3. 文件操作

```python
from controller import file_manager

# 列出目录
files = file_manager.list_directory("")

# 获取文件信息
info = file_manager.get_info("test.txt")

# 读取文件
content = file_manager.read("test.txt")

# 写入文件
file_manager.write("test.txt", "Hello World")

# 下载文件
file_manager.download("remote.txt", "local.txt")

# 上传文件
file_manager.upload("local.txt", "remote.txt")

# 重命名文件
file_manager.rename("old.txt", "new.txt")

# 创建目录
file_manager.create_directory("new_folder")

# 删除文件
file_manager.delete("test.txt")
```

### 4. 内核管理

```python
from controller import kernel_manager

# 列出所有内核
kernels = kernel_manager.list_all()

# 获取内核信息
info = kernel_manager.get_info("kernel-id")

# 重启内核
kernel_manager.restart("kernel-id")  # 重启指定内核
kernel_manager.restart()  # 重启所有内核

# 中断内核
kernel_manager.interrupt("kernel-id")

# 关闭内核
kernel_manager.shutdown("kernel-id")
```

### 5. 代码执行

```python
from controller import code_executor

# 执行代码
result = code_executor.execute("test.ipynb", "print('Hello')")
```

## 设计特点

1. **模块化**: 每个功能独立模块，职责清晰
2. **会话管理**: 单例模式管理全局会话，避免重复传递URL和token
3. **统一接口**: 所有模块使用统一的HTTP客户端
4. **易于扩展**: 新增功能只需添加新模块
5. **类型提示**: 完整的类型注解，IDE友好

## MCP工具映射

新的main_new.py提供5个统一的MCP工具：

1. **connect_jupyter** - 连接管理
2. **disconnect_jupyter** - 断开连接
3. **get_connection_status** - 连接状态
4. **manage_notebook** - 笔记本管理（8个操作）
5. **manage_file** - 文件管理（9个操作）
6. **manage_kernel** - 内核管理（5个操作）
7. **execute_code** - 代码执行

每个工具通过`action`参数支持多种操作，简化了工具数量。
