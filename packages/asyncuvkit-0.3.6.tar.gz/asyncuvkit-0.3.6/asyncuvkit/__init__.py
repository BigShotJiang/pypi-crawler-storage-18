
__version__ = "0.3.6"
__author__ = "asyncuvkit"

# 自动安装 import hook
from . import test
from .EasyMinMaxScaler import EasyMinMaxScaler
from . import asyncuvkit2

__all__ = ['asyncuvkit2', "test", "EasyMinMaxScaler"]


