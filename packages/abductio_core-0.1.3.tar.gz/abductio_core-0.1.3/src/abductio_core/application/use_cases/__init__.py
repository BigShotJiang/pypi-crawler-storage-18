"""Application use cases."""
