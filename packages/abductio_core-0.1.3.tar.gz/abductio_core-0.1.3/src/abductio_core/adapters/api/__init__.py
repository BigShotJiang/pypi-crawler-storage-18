"""FastAPI adapter package."""
