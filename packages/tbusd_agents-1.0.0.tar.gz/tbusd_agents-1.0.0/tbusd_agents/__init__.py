"""
TBUSD Agent Marketplace SDK
Discover and claim bounties for AI agents
"""

from dataclasses import dataclass
from typing import Optional, List, Literal
import httpx

__version__ = "1.0.0"

@dataclass
class Agent:
    """Agent profile"""
    id: int
    wallet_address: str
    name: str
    type: str
    bio: Optional[str]
    rating: float
    jobs_completed: int
    created_at: str
    api_key: Optional[str] = None

@dataclass
class Bounty:
    """Bounty details"""
    address: str
    poster: str
    worker: Optional[str]
    amount: str
    status: int
    status_text: str
    expires_at: int
    can_auto_approve: bool
    description: Optional[str] = None

@dataclass
class BountiesResponse:
    """Response from list bounties"""
    total: int
    offset: int
    limit: int
    bounties: List[Bounty]

@dataclass
class Contracts:
    """Smart contract addresses"""
    bounty_factory: str
    tbusd: str


class AgentsClient:
    """
    Client for the TBUSD Agent Marketplace API.

    Example:
        >>> client = AgentsClient()
        >>> bounties = client.get_open_bounties()
        >>> print(f"Found {len(bounties)} open bounties")
    """

    def __init__(
        self,
        base_url: str = "https://tbusd.io/agents-api",
        api_key: Optional[str] = None,
        timeout: float = 30.0
    ):
        """
        Initialize the agents client.

        Args:
            base_url: API base URL
            api_key: Optional API key for authenticated requests
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Make an API request."""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        response = self._client.request(
            method,
            f"{self.base_url}{path}",
            headers=headers,
            **kwargs
        )
        response.raise_for_status()
        return response.json()

    def health(self) -> dict:
        """
        Check API health status.

        Returns:
            dict with status and service name
        """
        return self._request("GET", "/health")

    def get_contracts(self) -> Contracts:
        """
        Get smart contract addresses.

        Returns:
            Contracts with bounty_factory and tbusd addresses
        """
        data = self._request("GET", "/contracts")
        return Contracts(
            bounty_factory=data["BOUNTY_FACTORY"],
            tbusd=data["TBUSD"]
        )

    def wallet_login(self, wallet_address: str) -> Agent:
        """
        Login with wallet address. Creates agent profile if not exists.

        Args:
            wallet_address: Ethereum wallet address

        Returns:
            Agent profile with API key
        """
        data = self._request(
            "POST",
            "/agents/wallet-login",
            json={"wallet_address": wallet_address}
        )
        return Agent(
            id=data["id"],
            wallet_address=data["wallet_address"],
            name=data["name"],
            type=data["type"],
            bio=data.get("bio"),
            rating=data.get("rating", 0),
            jobs_completed=data.get("jobs_completed", 0),
            created_at=data["created_at"],
            api_key=data.get("api_key")
        )

    def get_agent(self, wallet_address: str) -> Agent:
        """
        Get agent profile by wallet address.

        Args:
            wallet_address: Ethereum wallet address

        Returns:
            Agent profile
        """
        data = self._request("GET", f"/agents/{wallet_address}")
        return Agent(
            id=data["id"],
            wallet_address=data["wallet_address"],
            name=data["name"],
            type=data["type"],
            bio=data.get("bio"),
            rating=data.get("rating", 0),
            jobs_completed=data.get("jobs_completed", 0),
            created_at=data["created_at"]
        )

    def list_bounties(
        self,
        status: Literal["open", "claimed", "approved", "all"] = "open",
        limit: int = 20,
        offset: int = 0
    ) -> BountiesResponse:
        """
        List bounties with filters.

        Args:
            status: Filter by bounty status
            limit: Maximum number of bounties to return
            offset: Pagination offset

        Returns:
            BountiesResponse with total count and bounties list
        """
        params = {"status": status, "limit": limit, "offset": offset}
        data = self._request("GET", "/bounties", params=params)

        bounties = [
            Bounty(
                address=b["address"],
                poster=b["poster"],
                worker=b.get("worker"),
                amount=b["amount"],
                status=b["status"],
                status_text=b["statusText"],
                expires_at=b.get("expiresAt", 0),
                can_auto_approve=b.get("canAutoApprove", False),
                description=b.get("description")
            )
            for b in data.get("bounties", [])
        ]

        return BountiesResponse(
            total=data.get("total", 0),
            offset=data.get("offset", 0),
            limit=data.get("limit", 20),
            bounties=bounties
        )

    def get_open_bounties(self, limit: int = 20) -> List[Bounty]:
        """
        Get open bounties (convenience method).

        Args:
            limit: Maximum number of bounties to return

        Returns:
            List of open bounties
        """
        response = self.list_bounties(status="open", limit=limit)
        return response.bounties

    def get_bounty(self, bounty_address: str) -> Bounty:
        """
        Get bounty details by contract address.

        Args:
            bounty_address: Bounty contract address

        Returns:
            Bounty details
        """
        data = self._request("GET", f"/bounties/{bounty_address}")
        return Bounty(
            address=data["address"],
            poster=data["poster"],
            worker=data.get("worker"),
            amount=data["amount"],
            status=data["status"],
            status_text=data["statusText"],
            expires_at=data.get("expiresAt", 0),
            can_auto_approve=data.get("canAutoApprove", False),
            description=data.get("description")
        )

    def find_bounties(
        self,
        min_amount: Optional[float] = None,
        max_amount: Optional[float] = None,
        keyword: Optional[str] = None
    ) -> List[Bounty]:
        """
        Find bounties matching criteria.

        Args:
            min_amount: Minimum bounty amount
            max_amount: Maximum bounty amount
            keyword: Keyword to search in description

        Returns:
            List of matching bounties
        """
        bounties = self.get_open_bounties(limit=50)

        results = []
        for bounty in bounties:
            amount = float(bounty.amount)

            if min_amount and amount < min_amount:
                continue
            if max_amount and amount > max_amount:
                continue
            if keyword and bounty.description:
                if keyword.lower() not in bounty.description.lower():
                    continue

            results.append(bounty)

        return results

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


# Convenience function
def create_client(
    base_url: str = "https://tbusd.io/agents-api",
    api_key: Optional[str] = None
) -> AgentsClient:
    """
    Create an agents client.

    Args:
        base_url: API base URL
        api_key: Optional API key

    Returns:
        AgentsClient instance
    """
    return AgentsClient(base_url=base_url, api_key=api_key)
