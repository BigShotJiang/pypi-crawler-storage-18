# tooling.py
from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Dict, Optional, Protocol

from .context import get_current_session

ToolCall = Callable[..., Any]


class RuntimeLike(Protocol):
    compensations: Dict[str, str]

    def register_tool(self, name: str, func: ToolCall) -> None: ...
    def register_compensation(self, tool_name: str, compensation_tool_name: str) -> None: ...


def tool(
    runtime: RuntimeLike,
    name: Optional[str] = None,
    compensation: Optional[str] = None,
) -> Callable[[ToolCall], ToolCall]:
    def decorator(func: ToolCall) -> ToolCall:
        tool_name = name or func.__name__

        # Register the forward tool
        runtime.register_tool(tool_name, func)

        # Optionally register the compensation mapping
        if compensation:
            runtime.register_compensation(tool_name, compensation)

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            session = get_current_session()

            # If we're not inside a session context, call normally.
            if session is None:
                return func(*args, **kwargs)

            # Guard against using a tool registered on one runtime while another runtime's session is active.
            if hasattr(session, "runtime") and session.runtime is not runtime:
                raise RuntimeError(
                    f'Tool "{tool_name}" was registered on a different runtime instance than the active session.'
                )

            # Only schedule compensations for forward executions, not replay
            compensation_name = (
                runtime.compensations.get(tool_name) if not session.replay else None
            )

            return session.execute_tool_call(
                tool_name=tool_name,
                func=func,
                args=args,
                kwargs=kwargs,
                phase="forward",
                compensation_tool_name=compensation_name,
            )

        return wrapper  # type: ignore[return-value]

    return decorator
