from __future__ import annotations
import hashlib
import os
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import requests

from .context import set_current_session

ToolCall = Callable[..., Any]


@dataclass
class ExecutedStep:
    tool_name: str
    compensation_tool_name: Optional[str]
    args: tuple
    kwargs: dict


@dataclass
class CloudAgentRuntime:
    """Remote Agent runtime that talks to the AgentTrail HTTP API.

    It mirrors the core API of the local runtime:
      - register_tool / register_compensation
      - agent_session(...) context manager
      - replay_run(...)
    """

    base_url: str
    api_key: str
    # Project is a first-class routing key in the commercial backend.
    # Default keeps backward compatibility for local/dev usage.
    project: str = "default"

    tools: Dict[str, ToolCall] = field(default_factory=dict)
    compensations: Dict[str, str] = field(default_factory=dict)
    _http: requests.Session = field(default_factory=requests.Session, repr=False)

    # --------- construction helpers ----------

    @classmethod
    def from_env(cls) -> "CloudAgentRuntime":
        """Convenience constructor that reads:
          - AGENTTRAIL_URL
          - AGENTTRAIL_API_KEY
          - AGENTTRAIL_PROJECT (optional; default "default")
        from the environment.
        """
        base_url = os.environ.get("AGENTTRAIL_URL")
        api_key = os.environ.get("AGENTTRAIL_API_KEY")
        project = os.environ.get("AGENTTRAIL_PROJECT", "default")

        if not base_url or not api_key:
            raise RuntimeError(
                "AGENTTRAIL_URL and AGENTTRAIL_API_KEY must be set in the environment"
            )

        return cls(base_url=base_url.rstrip("/"), api_key=api_key, project=project)

    def _headers(self) -> Dict[str, str]:
        # "X-Project" is how the API routes data into the correct tenant/project partition.
        return {"X-API-Key": self.api_key, "X-Project": self.project}

    # --------- tool registration ----------

    def register_tool(self, name: str, func: ToolCall) -> None:
        self.tools[name] = func

    def register_compensation(self, tool_name: str, compensation_tool_name: str) -> None:
        self.compensations[tool_name] = compensation_tool_name

    def get_tool(self, name: str) -> ToolCall:
        if name not in self.tools:
            raise ValueError(f"Tool '{name}' is not registered.")
        return self.tools[name]

    # --------- sessions ----------

    def agent_session(
        self,
        name: str,
        input_payload: Any | None = None,
        replay: bool = False,
        replay_run_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> "CloudAgentSession":
        return CloudAgentSession(
            runtime=self,
            name=name,
            input_payload=input_payload,
            replay=replay,
            replay_run_id=replay_run_id,
            tags=tags or [],
        )

    def replay_run(
        self,
        name: str,
        run_id: str,
        agent_fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> Any:
        """Deterministically re-run an agent function using recorded tool_calls.

        This is read-only: it does NOT mutate the run on the server.
        """
        with self.agent_session(
            name=name,
            input_payload={"replay_of": run_id},
            replay=True,
            replay_run_id=run_id,
        ) as session:
            result = agent_fn(*args, **kwargs)
            session.set_output(result)
            return result


@dataclass
class CloudAgentSession:
    runtime: CloudAgentRuntime
    name: str
    input_payload: Any | None
    replay: bool = False
    replay_run_id: Optional[str] = None
    tags: List[str] = field(default_factory=list)

    run_id: Optional[str] = None
    status: str = "pending"
    error: Optional[str] = None
    output_payload: Any | None = None

    seq_no: int = 0
    executed_steps: List[ExecutedStep] = field(default_factory=list)
    _replay_calls: List[dict] = field(default_factory=list)
    _replay_index: int = 0

    # ---------- context manager ----------

    def __enter__(self) -> "CloudAgentSession":
        if self.replay:
            if not self.replay_run_id:
                raise ValueError("replay_run_id must be provided for replay sessions")
            self.run_id = self.replay_run_id
            self._load_replay_calls()
            set_current_session(self)
            return self

        # create new run on the API
        url = f"{self.runtime.base_url}/v1/runs"
        payload: Dict[str, Any] = {
            "name": self.name,
            "input": self.input_payload,
            "replay_of": None,
            "tags": self.tags,
            # Include project in the payload as well as headers for robustness.
            "project": self.runtime.project,
        }
        resp = self.runtime._http.post(
            url,
            headers=self.runtime._headers(),
            json=payload,
            timeout=10,
        )
        if resp.status_code != 200:
            raise RuntimeError(f"Failed to create run: {resp.status_code} {resp.text}")
        data = resp.json()
        self.run_id = data["run_id"]
        set_current_session(self)
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        try:
            if exc_type is None:
                self.status = "success"
            else:
                self.status = "error"
                self.error = str(exc_value) if exc_value else "unknown error"
                # only run compensations for non-replay sessions
                if not self.replay:
                    self._run_compensations()

            # only persist back for non-replay sessions
            if not self.replay:
                self._persist_final_status()
        finally:
            set_current_session(None)

    def set_output(self, value: Any) -> None:
        self.output_payload = value

    # ---------- internal helpers ----------

    def _persist_final_status(self) -> None:
        if not self.run_id:
            return
        url = f"{self.runtime.base_url}/v1/runs/{self.run_id}/complete"
        payload: Dict[str, Any] = {
            "status": self.status,
            "output": self.output_payload,
            "error": self.error,
        }
        resp = self.runtime._http.post(
            url,
            headers=self.runtime._headers(),
            json=payload,
            timeout=10,
        )
        if resp.status_code >= 400:
            raise RuntimeError(
                f"Failed to persist final status: {resp.status_code} {resp.text}"
            )

    def _load_replay_calls(self) -> None:
        if not self.run_id:
            raise RuntimeError("Replay session has no run_id")
        url = f"{self.runtime.base_url}/v1/runs/{self.run_id}"
        resp = self.runtime._http.get(
            url,
            headers=self.runtime._headers(),
            timeout=10,
        )
        if resp.status_code != 200:
            raise RuntimeError(
                f"Failed to load replay data: {resp.status_code} {resp.text}"
            )
        data = resp.json()
        calls = data.get("tool_calls", []) or []
        calls.sort(key=lambda c: c.get("seq_no", 0))
        self._replay_calls = calls
        self._replay_index = 0

    def _compute_idempotency_key(
        self, tool_name: str, args: tuple, kwargs: dict, phase: str
    ) -> str:
        import json

        payload = {"tool": tool_name, "phase": phase, "args": args, "kwargs": kwargs}
        json_str = json.dumps(payload, sort_keys=True, default=repr)
        digest = hashlib.sha256(json_str.encode("utf-8")).hexdigest()
        return digest

    def _replay_step(self, tool_name: str, phase: str) -> Any:
        if self._replay_index >= len(self._replay_calls):
            raise RuntimeError("Replay exceeded recorded tool calls")

        record = self._replay_calls[self._replay_index]
        self._replay_index += 1

        if record.get("tool_name") != tool_name or record.get("phase") != phase:
            raise RuntimeError(
                f"Replay mismatch. Expected {tool_name}/{phase}, "
                f"got {record.get('tool_name')}/{record.get('phase')}"
            )

        if record.get("status") != "success":
            raise RuntimeError(
                f"Replayed tool call ended in status {record.get('status')}"
            )

        return record.get("output")

    def _run_compensations(self) -> None:
        # execute compensations in reverse order
        for step in reversed(self.executed_steps):
            comp_name = step.compensation_tool_name
            if not comp_name:
                continue
            comp_func = self.runtime.get_tool(comp_name)
            try:
                self.execute_tool_call(
                    tool_name=comp_name,
                    func=comp_func,
                    args=step.args,
                    kwargs=step.kwargs,
                    phase="compensation",
                    compensation_tool_name=None,
                )
            except Exception:
                # swallow compensation failures for now
                continue

    # ---------- core entrypoint used by @tool decorator ----------

    def execute_tool_call(
        self,
        tool_name: str,
        func: ToolCall,
        args: tuple,
        kwargs: dict,
        phase: str = "forward",
        compensation_tool_name: Optional[str] = None,
    ) -> Any:
        if not self.run_id:
            raise RuntimeError(
                "CloudAgentSession has no run_id; did you use it as a context manager?"
            )

        # Replaying: serve from previously recorded tool_calls
        if self.replay:
            return self._replay_step(tool_name, phase)

        idem_key = self._compute_idempotency_key(tool_name, args, kwargs, phase)
        input_payload = {"args": args, "kwargs": kwargs}

        # Atomic claim: backend should enforce a UNIQUE index on
        # (tenant, project, run_id, tool_name, phase, idempotency_key).
        claim_url = f"{self.runtime.base_url}/v1/runs/{self.run_id}/tool-calls/claim"
        claim_payload = {
            "tool_name": tool_name,
            "phase": phase,
            "idempotency_key": idem_key,
            "input": input_payload,
        }

        def claim_once() -> Dict[str, Any]:
            resp = self.runtime._http.post(
                claim_url,
                headers=self.runtime._headers(),
                json=claim_payload,
                timeout=10,
            )

            # Some servers may return 409 on duplicate claims; accept it if it has JSON.
            if resp.status_code in (200, 409):
                try:
                    return resp.json()
                except Exception as e:  # pragma: no cover
                    raise RuntimeError(
                        f"Claim response was not JSON: {resp.status_code} {resp.text}"
                    ) from e

            raise RuntimeError(f"Claim failed: {resp.status_code} {resp.text}")

        claim = claim_once()

        # If we didn't claim, never execute the tool.
        if not claim.get("claimed", False):
            status = claim.get("status")
            if status == "success":
                return claim.get("output")
            if status == "error":
                raise RuntimeError(f"Prior attempt failed: {claim.get('error')}")

            # pending -> poll briefly
            for _ in range(10):
                time.sleep(0.1)
                claim = claim_once()
                status = claim.get("status")
                if status == "success":
                    return claim.get("output")
                if status == "error":
                    raise RuntimeError(f"Prior attempt failed: {claim.get('error')}")

            raise RuntimeError(
                "Tool call already pending; timed out waiting for completion"
            )

        call_id = claim["call_id"]

        # Prefer server-assigned ordering if provided.
        if "seq_no" in claim:
            try:
                self.seq_no = int(claim["seq_no"])
            except Exception:
                self.seq_no += 1
        else:
            self.seq_no += 1

        # Remember for potential compensation
        if phase == "forward" and compensation_tool_name:
            self.executed_steps.append(
                ExecutedStep(
                    tool_name=tool_name,
                    compensation_tool_name=compensation_tool_name,
                    args=args,
                    kwargs=kwargs,
                )
            )

        complete_url = f"{self.runtime.base_url}/v1/tool-calls/{call_id}/complete"

        try:
            # real execution
            output = func(*args, **kwargs)

            complete_payload = {
                "status": "success",
                "output": output,
                "error": None,
            }
            resp = self.runtime._http.post(
                complete_url,
                headers=self.runtime._headers(),
                json=complete_payload,
                timeout=10,
            )
            if resp.status_code >= 400:
                raise RuntimeError(
                    f"Failed to complete tool call: {resp.status_code} {resp.text}"
                )

            return output

        except Exception as e:
            err_payload = {
                "status": "error",
                "output": None,
                "error": str(e),
            }
            resp = self.runtime._http.post(
                complete_url,
                headers=self.runtime._headers(),
                json=err_payload,
                timeout=10,
            )
            if resp.status_code >= 400:
                raise RuntimeError(
                    f"Failed to mark tool call error: {resp.status_code} {resp.text}"
                )
            raise
