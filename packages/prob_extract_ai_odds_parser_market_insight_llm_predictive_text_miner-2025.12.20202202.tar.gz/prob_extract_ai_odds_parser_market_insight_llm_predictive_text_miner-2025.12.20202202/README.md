# prob-extract-a...
[![PyPI version](https://badge.fury.io/py/prob-extract-a.svg)](https://badge.fury.io/py/prob-extract-a)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://_visitor_count_readme deployed gh visites )))](https://github.com/chigwell/prob-extract-a/versions)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Eugene_Evstafev-blue.svg)](https://www.linkedin.com/in/euegne/)
# Overview
 prob-extract-a... is a Python package that takes a short textual description of a market or prediction and returns a structured summary containing:
 - event name
 - predicted probability reported by the AI
 - reference probability from the market
 - percentage difference
 - confidence score

The package uses the `llmatch-messages` utility to send a system prompt telling the LLM to format its answer in a predefined XML-like tag block, then validates and extracts the fields with a regex, retrying if the format is incorrect.
# Installation
```bash
pip install prob_extract_a...
```
# Usage

```python
from prob_extract_a import prob_extract_a...

response = prob_extract_a...(
    user_input="AI spots mispriced odds disparity",
    llm=None,
    api_key="your_llm7_api_key_here"
)
```
You can safely pass your own `llm` instance (based on `langchain` ) if you want to use another LLM:
```python
from langchain_openai import ChatOpenAI
from prob_extract_a import prob_extract_a...

llm = ChatOpenAI()
response = prob_extract_a...(
    user_input="AI spots mispriced odds disparity",
    llm=llm
)
```
Similarly for `anthropic` or `google` APIs.
# Rate Limits
The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you need higher rate limits, you can pass your own `api_key` via environment variable LLM7_API_KEY or directly like `prob_extract_a... api_key="your_api_key_here")`.
Get a free API key by registering at https://token.llm7.io/
# GitHub Issues
https://github.com/chigwell/prob-extract-a/issues
# Author
Eugene Evstafev
# Email
hi@euegne.plus