#!/usr/bin/env python3
"""
DOT Generator Module

Generates optimized Graphviz DOT code for RTL diagrams with:
- Orthogonal routing (splines=ortho)
- Pipeline stage clustering
- Feedback edge handling
- Compact layout optimization
"""

from enum import Enum
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from .rtl_parser import Module, ModuleInstance


class FlowDirection(Enum):
    """Diagram flow direction."""
    LEFT_TO_RIGHT = "LR"
    TOP_TO_BOTTOM = "TB"


@dataclass
class NodeStyle:
    """Styling for a node type."""
    shape: str
    fillcolor: str
    style: str = "filled"
    width: float = 1.0
    height: float = 0.5
    fontsize: int = 9
    
    def to_dot(self) -> str:
        attrs = [
            f'shape={self.shape}',
            f'style="{self.style}"',
            f'fillcolor="{self.fillcolor}"',
            f'width={self.width}',
            f'height={self.height}',
            f'fontsize={self.fontsize}',
        ]
        # Special handling for MUX (trapezium)
        if self.shape == 'trapezium':
            attrs.append('orientation=90')
            attrs[3] = 'width=0.5'
            attrs[4] = 'height=0.7'
        return ', '.join(attrs)


# Component type styles
COMPONENT_STYLES: Dict[str, NodeStyle] = {
    'alu': NodeStyle('octagon', '#FFECB3', width=1.0, height=0.5),
    'memory': NodeStyle('box3d', '#C8E6C9', width=1.0, height=0.5),
    'register': NodeStyle('box3d', '#B3E5FC', width=0.9, height=0.45),
    'mux': NodeStyle('trapezium', '#FFF9C4'),
    'control': NodeStyle('component', '#F8BBD9', width=1.0, height=0.5),
    'pipeline_reg': NodeStyle('record', '#E8EAF6', width=0.3, height=0.8, fontsize=8),
    'adder': NodeStyle('ellipse', '#E1BEE7', width=0.8, height=0.45),
    'compare': NodeStyle('diamond', '#FFCDD2', width=0.6, height=0.6),
    'logic': NodeStyle('box', '#ECEFF1', width=0.9, height=0.45),
    'transform': NodeStyle('box', '#B2EBF2', width=0.8, height=0.4),
}

# Pipeline stage colors (fill, border)
STAGE_COLORS: Dict[str, Tuple[str, str]] = {
    'IF': ('#E3F2FD', '#1976D2'),
    'IF_ID': ('#E8EAF6', '#5C6BC0'),
    'ID': ('#E8F5E9', '#388E3C'),
    'ID_EX': ('#E8EAF6', '#5C6BC0'),
    'EX': ('#FFF3E0', '#F57C00'),
    'EX_MEM': ('#E8EAF6', '#5C6BC0'),
    'MEM': ('#FCE4EC', '#C2185B'),
    'MEM_WB': ('#E8EAF6', '#5C6BC0'),
    'WB': ('#F3E5F5', '#7B1FA2'),
    'other': ('#ECEFF1', '#607D8B'),
}

STAGE_LABELS: Dict[str, str] = {
    'IF': 'Instruction Fetch',
    'IF_ID': 'IF/ID Latch',
    'ID': 'Instruction Decode',
    'ID_EX': 'ID/EX Latch',
    'EX': 'Execute',
    'EX_MEM': 'EX/MEM Latch',
    'MEM': 'Memory Access',
    'MEM_WB': 'MEM/WB Latch',
    'WB': 'Write Back',
    'other': 'Other',
}

STAGE_ORDER = ['IF', 'IF_ID', 'ID', 'ID_EX', 'EX', 'EX_MEM', 'MEM', 'MEM_WB', 'WB', 'other']


def detect_component_type(module_type: str, instance_name: str) -> str:
    """Detect the semantic component type from module/instance names."""
    name = (module_type + ' ' + instance_name).lower()
    
    if any(x in name for x in ['if_id', 'id_ex', 'ex_mem', 'mem_wb']):
        return 'pipeline_reg'
    if 'alu' in name and 'control' not in name and 'ctrl' not in name:
        return 'alu'
    if any(x in name for x in ['memory', 'mem_', 'instruction_memory', 'data_memory']):
        return 'memory'
    if any(x in name for x in ['register', 'regfile', 'reg_file']):
        return 'register'
    if name == 'pc' or 'program_counter' in name:
        return 'register'
    if 'mux' in name or 'select' in name:
        return 'mux'
    if 'control' in name or 'ctrl' in name:
        return 'control'
    if any(x in name for x in ['forward', 'hazard', 'detect']):
        return 'compare'
    if any(x in name for x in ['add', 'adder', 'increment']):
        return 'adder'
    if any(x in name for x in ['sign', 'extend', 'shift']):
        return 'transform'
    
    return 'logic'


def detect_pipeline_stage(instance_name: str, module_type: str) -> str:
    """Detect which pipeline stage a component belongs to."""
    name = (instance_name + ' ' + module_type).lower()
    
    if any(x in name for x in ['pc', 'instruction_memory', 'pcselect', 'add_pc']):
        return 'IF'
    if 'if_id' in name:
        return 'IF_ID'
    if any(x in name for x in ['control', 'registers', 'sign_extend', 'hazard']) and 'alu' not in name:
        return 'ID'
    if 'id_ex' in name:
        return 'ID_EX'
    if any(x in name for x in ['alu', 'forward']) and 'mem' not in name:
        return 'EX'
    if 'ex_mem' in name:
        return 'EX_MEM'
    if any(x in name for x in ['data_memory', 'datamemory']):
        return 'MEM'
    if 'mem_wb' in name:
        return 'MEM_WB'
    if any(x in name for x in ['memtoreg', 'writeback']):
        return 'WB'
    
    return 'other'


def get_graph_header(
    title: str = "RTL Block Diagram",
    direction: FlowDirection = FlowDirection.LEFT_TO_RIGHT,
    node_sep: float = 0.4,
    rank_sep: float = 0.8,
) -> str:
    """Generate optimized graph header."""
    return f'''digraph "{title}" {{
    // Layout optimized for pipeline diagrams
    layout=dot;
    rankdir={direction.value};
    splines=ortho;
    overlap=false;
    newrank=true;
    compound=true;
    remincross=true;
    ordering=out;
    
    // Spacing
    nodesep={node_sep};
    ranksep={rank_sep};
    margin=0.25;
    pad=0.25;
    
    // Default node style
    node [
        fontname="Arial",
        fontsize=9,
        penwidth=1.0,
        margin="0.1,0.05"
    ];
    
    // Default edge style
    edge [
        fontname="Arial",
        fontsize=7,
        penwidth=0.8,
        arrowsize=0.5
    ];
'''


def get_graph_footer() -> str:
    """Close the graph definition."""
    return '}'


def get_cluster_header(
    cluster_id: str,
    label: str,
    fillcolor: str,
    border_color: str = "#666666",
    rank: Optional[str] = None,
) -> str:
    """Generate a cluster (subgraph) header."""
    lines = [
        f'    subgraph cluster_{cluster_id} {{',
        f'        label="{label}";',
        f'        labeljust=l;',
        f'        style="filled,rounded";',
        f'        fillcolor="{fillcolor}";',
        f'        color="{border_color}";',
        f'        fontname="Arial Bold";',
        f'        fontsize=10;',
        f'        margin=8;',
    ]
    if rank:
        lines.append(f'        rank={rank};')
    lines.append('')
    return '\n'.join(lines)


def get_cluster_footer() -> str:
    """Close a cluster."""
    return '    }\n'


def get_node_def(
    node_id: str,
    label: str,
    component_type: str,
    tooltip: str = "",
) -> str:
    """Generate a node definition with appropriate styling."""
    style = COMPONENT_STYLES.get(component_type, COMPONENT_STYLES['logic'])
    safe_label = label.replace('"', '\\"').replace('\n', '\\n')
    safe_tooltip = tooltip.replace('"', '\\"') if tooltip else safe_label
    return f'        {node_id} [label="{safe_label}", {style.to_dot()}, tooltip="{safe_tooltip}"];'


def get_edge_def(
    source: str,
    target: str,
    is_control: bool = False,
    is_feedback: bool = False,
) -> str:
    """Generate an edge definition."""
    attrs = []
    
    if is_control:
        attrs.append('style=dashed')
        attrs.append('color="#1565C0"')
        attrs.append('penwidth=0.8')
    else:
        attrs.append('penwidth=1.0')
    
    if is_feedback:
        attrs.append('constraint=false')
        attrs.append('weight=0')
    else:
        attrs.append('weight=2')
    
    return f'    {source} -> {target} [{", ".join(attrs)}];'


def get_invisible_edge(source: str, target: str) -> str:
    """Create an invisible edge for layout control."""
    return f'    {source} -> {target} [style=invis, weight=10];'


def generate_dot(
    modules: Dict[str, Module],
    top_module: str,
    title: str = "RTL Block Diagram",
) -> str:
    """
    Generate DOT code from parsed modules.
    
    Args:
        modules: Dict of parsed modules
        top_module: Name of top-level module
        title: Diagram title
        
    Returns:
        Complete DOT code string
    """
    top = modules.get(top_module)
    if not top:
        return f'digraph "{title}" {{ label="Error: Top module {top_module} not found"; }}'
    
    # Analyze instances
    for inst in top.instances:
        inst.semantic_type = detect_component_type(inst.module_type, inst.instance_name)
        inst.pipeline_stage = detect_pipeline_stage(inst.instance_name, inst.module_type)
        inst.description = inst.module_type
    
    # Group by stage
    stages: Dict[str, List[ModuleInstance]] = {}
    for inst in top.instances:
        stage = inst.pipeline_stage
        if stage not in stages:
            stages[stage] = []
        stages[stage].append(inst)
    
    # Build DOT
    lines = [get_graph_header(title, FlowDirection.LEFT_TO_RIGHT, 0.4, 0.8)]
    
    stage_nodes: Dict[str, List[str]] = {}
    stage_order_map = {stage: i for i, stage in enumerate(STAGE_ORDER)}
    
    # Create clusters for each stage
    for stage in STAGE_ORDER:
        if stage not in stages:
            continue
        
        instances = stages[stage]
        fill, border = STAGE_COLORS.get(stage, ('#ECEFF1', '#607D8B'))
        label = STAGE_LABELS.get(stage, stage)
        
        rank = 'min' if stage == 'IF' else ('max' if stage == 'WB' else None)
        lines.append(get_cluster_header(stage, f"{label} ({stage})", fill, border, rank))
        
        stage_nodes[stage] = []
        for inst in instances:
            node_label = f"{inst.description}\\n[{inst.instance_name}]"
            lines.append(get_node_def(inst.instance_name, node_label, inst.semantic_type, inst.description))
            stage_nodes[stage].append(inst.instance_name)
        
        lines.append(get_cluster_footer())
    
    # Same-rank constraints
    lines.append('\n    // Rank constraints')
    for stage in STAGE_ORDER:
        if stage in stage_nodes and len(stage_nodes[stage]) > 1:
            nodes_str = '; '.join(stage_nodes[stage])
            lines.append(f'    {{ rank=same; {nodes_str}; }}')
    
    # Invisible edges for stage ordering
    lines.append('\n    // Stage ordering')
    prev_stage = None
    for stage in STAGE_ORDER:
        if stage in stage_nodes and stage_nodes[stage]:
            if prev_stage and prev_stage in stage_nodes and stage_nodes[prev_stage]:
                lines.append(get_invisible_edge(stage_nodes[prev_stage][0], stage_nodes[stage][0]))
            prev_stage = stage
    
    # Build signal producer map
    signal_producers = {}
    for inst in top.instances:
        for port, signal in inst.connections.items():
            if signal and '_o' in port:
                signal_producers[signal] = inst.instance_name
    
    # Create instance stage map for feedback detection
    inst_stage = {inst.instance_name: stage_order_map.get(inst.pipeline_stage, 99) for inst in top.instances}
    
    # Add edges
    lines.append('\n    // Connections')
    edges_added = set()
    for inst in top.instances:
        for port, signal in inst.connections.items():
            if signal and '_i' in port and signal in signal_producers:
                producer = signal_producers[signal]
                edge_key = (producer, inst.instance_name)
                
                if edge_key not in edges_added:
                    edges_added.add(edge_key)
                    
                    is_control = any(x in signal.lower() for x in [
                        'ctrl', 'select', 'write', 'read', 'regwrite', 
                        'mem', 'aluop', 'alusrc', 'hazard', 'branch'
                    ])
                    
                    prod_stage = inst_stage.get(producer, 99)
                    cons_stage = inst_stage.get(inst.instance_name, 99)
                    is_feedback = prod_stage > cons_stage
                    
                    lines.append(get_edge_def(producer, inst.instance_name, is_control, is_feedback))
    
    lines.append(get_graph_footer())
    return '\n'.join(lines)
