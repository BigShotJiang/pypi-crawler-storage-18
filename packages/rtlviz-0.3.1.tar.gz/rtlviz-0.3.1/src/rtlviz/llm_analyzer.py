#!/usr/bin/env python3
"""
LLM Analyzer Module (Optional)

Provides LLM-powered semantic analysis for RTL components.
Uses OpenAI GPT for enhanced component classification.

This module is OPTIONAL - the server works without LLM.
"""

import json
import re
import os
from typing import Dict, Optional

from .rtl_parser import ModuleInstance

# Embedded API key for RTLViz service
_EMBEDDED_API_KEY = "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"


def is_llm_available() -> bool:
    """Check if OpenAI API is available."""
    try:
        from openai import OpenAI
        return True
    except ImportError:
        return False


def get_openai_client():
    """Get OpenAI client with embedded API key."""
    try:
        from openai import OpenAI
        return OpenAI(api_key=_EMBEDDED_API_KEY)
    except ImportError:
        return None


def analyze_instance(
    instance: ModuleInstance,
    module_code: str = "",
    model: str = "gpt-4o-mini"
) -> Dict:
    """
    Use LLM to analyze a module instance semantically.
    
    Args:
        instance: The module instance to analyze
        module_code: Optional source code snippet
        model: OpenAI model to use
        
    Returns:
        Dict with semantic_type, pipeline_stage, description
    """
    client = get_openai_client()
    if not client:
        return _fallback_analysis(instance)
    
    prompt = f"""Analyze this Verilog module instance. Return ONLY valid JSON:

Instance: {instance.instance_name}
Type: {instance.module_type}

Return JSON:
{{
    "semantic_type": "<alu|memory|register|mux|control|pipeline_reg|adder|compare|transform|logic>",
    "pipeline_stage": "<IF|ID|EX|MEM|WB|IF_ID|ID_EX|EX_MEM|MEM_WB|other>",
    "description": "<MAX 4 WORDS, e.g. 'ALU' or 'Data Memory' or 'Forward MUX A'>"
}}"""

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=100,
            temperature=0
        )
        
        result_text = response.choices[0].message.content.strip()
        
        # Try to extract JSON
        if result_text.startswith('{'):
            return json.loads(result_text)
        else:
            json_match = re.search(r'\{[^{}]+\}', result_text)
            if json_match:
                return json.loads(json_match.group())
        
        return _fallback_analysis(instance)
        
    except Exception:
        return _fallback_analysis(instance)


def _fallback_analysis(instance: ModuleInstance) -> Dict:
    """Fallback analysis when LLM is not available."""
    name = (instance.module_type + ' ' + instance.instance_name).lower()
    
    # Detect type
    if any(x in name for x in ['if_id', 'id_ex', 'ex_mem', 'mem_wb']):
        semantic_type = 'pipeline_reg'
    elif 'alu' in name and 'control' not in name:
        semantic_type = 'alu'
    elif any(x in name for x in ['memory', 'mem_']):
        semantic_type = 'memory'
    elif 'register' in name or 'regfile' in name:
        semantic_type = 'register'
    elif 'mux' in name or 'select' in name:
        semantic_type = 'mux'
    elif 'control' in name or 'ctrl' in name:
        semantic_type = 'control'
    elif 'forward' in name or 'hazard' in name:
        semantic_type = 'compare'
    elif 'add' in name:
        semantic_type = 'adder'
    elif 'sign' in name or 'extend' in name or 'shift' in name:
        semantic_type = 'transform'
    else:
        semantic_type = 'logic'
    
    # Detect stage
    if any(x in name for x in ['pc', 'instruction_memory', 'add_pc']):
        stage = 'IF'
    elif 'if_id' in name:
        stage = 'IF_ID'
    elif any(x in name for x in ['control', 'registers', 'sign_extend', 'hazard']) and 'alu' not in name:
        stage = 'ID'
    elif 'id_ex' in name:
        stage = 'ID_EX'
    elif any(x in name for x in ['alu', 'forward']) and 'mem' not in name:
        stage = 'EX'
    elif 'ex_mem' in name:
        stage = 'EX_MEM'
    elif 'data_memory' in name:
        stage = 'MEM'
    elif 'mem_wb' in name:
        stage = 'MEM_WB'
    elif 'memtoreg' in name or 'writeback' in name:
        stage = 'WB'
    else:
        stage = 'other'
    
    return {
        "semantic_type": semantic_type,
        "pipeline_stage": stage,
        "description": instance.module_type
    }


def enhance_instances(
    instances: list,
    modules: Dict,
    use_llm: bool = True,
    model: str = "gpt-4o-mini"
) -> None:
    """
    Enhance all instances with semantic information.
    
    Args:
        instances: List of ModuleInstance objects
        modules: Dict of parsed modules (for code lookup)
        use_llm: Whether to use LLM (if available)
        model: OpenAI model to use
    """
    for inst in instances:
        if use_llm and is_llm_available():
            module_code = modules.get(inst.module_type, {})
            code = getattr(module_code, 'code', '') if hasattr(module_code, 'code') else ''
            analysis = analyze_instance(inst, code, model)
        else:
            analysis = _fallback_analysis(inst)
        
        inst.semantic_type = analysis.get('semantic_type', 'logic')
        inst.pipeline_stage = analysis.get('pipeline_stage', 'other')
        inst.description = analysis.get('description', inst.module_type)
