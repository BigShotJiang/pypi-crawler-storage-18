"""Elasticsearch MCP tests."""
