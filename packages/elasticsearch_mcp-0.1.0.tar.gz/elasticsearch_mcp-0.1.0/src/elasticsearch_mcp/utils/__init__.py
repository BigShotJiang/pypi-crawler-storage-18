"""Elasticsearch MCP utilities."""
