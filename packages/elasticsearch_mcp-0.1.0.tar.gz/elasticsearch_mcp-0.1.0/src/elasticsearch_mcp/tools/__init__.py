"""Elasticsearch MCP tools."""
