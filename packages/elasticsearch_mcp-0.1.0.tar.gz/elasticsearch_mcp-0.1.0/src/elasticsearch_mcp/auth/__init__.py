"""Elasticsearch MCP authentication."""
