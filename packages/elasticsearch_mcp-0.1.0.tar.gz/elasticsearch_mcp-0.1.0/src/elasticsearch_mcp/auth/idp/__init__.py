"""Elasticsearch MCP IdP adapters."""
