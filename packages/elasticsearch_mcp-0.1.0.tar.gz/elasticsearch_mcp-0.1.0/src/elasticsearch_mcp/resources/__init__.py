"""Elasticsearch MCP resources."""
