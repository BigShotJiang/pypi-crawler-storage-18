"""
NanoBot Robot Configuration

Physical chassis dimensions and safety thresholds in METERS.
"""

import math


class RobotConfig:
    """Physical robot configuration"""

    # Chassis dimensions (meters)
    WIDTH = 0.40   # 40cm wide
    LENGTH = 0.50  # 50cm long

    # Chassis diagonal - minimum space to turn
    DIAG_CHASSIS = math.sqrt(WIDTH**2 + LENGTH**2) / 2  # ~0.32m

    # Distance thresholds (meters)
    DISTANCE_DANGER = 0.30    # < 30cm = imminent collision
    DISTANCE_CLOSE = 0.50     # < 50cm = attention required
    DISTANCE_SAFE = 0.70      # > 70cm = safe
    DISTANCE_COMFORT = 1.00   # > 1m = comfortable
    DISTANCE_FAR = 2.00       # > 2m = clear space

    # Speeds (normalized 0-1)
    SPEED_MAX = 1.0           # Maximum speed
    SPEED_NORMAL = 0.5        # Cruising speed
    SPEED_SLOW = 0.3          # Cautious speed
    SPEED_VERY_SLOW = 0.15    # Very cautious speed

    # Aliases
    DISTANCE_PROCHE = DISTANCE_CLOSE
    DISTANCE_CONFORT = DISTANCE_COMFORT
    DISTANCE_LOIN = DISTANCE_FAR
    VITESSE_MAX = SPEED_MAX
    VITESSE_NORMALE = SPEED_NORMAL
    VITESSE_LENTE = SPEED_SLOW
    VITESSE_TRES_LENTE = SPEED_VERY_SLOW

    @classmethod
    def can_move_forward(cls, front: float) -> bool:
        """Can the robot move forward without collision?"""
        return front > cls.DIAG_CHASSIS

    @classmethod
    def can_turn(cls, lateral: float, diagonal: float) -> bool:
        """Can the robot turn in this direction?"""
        # Need space on the side AND diagonally
        return lateral > cls.DIAG_CHASSIS and diagonal > cls.DIAG_CHASSIS

    @classmethod
    def adapted_speed(cls, distance: float) -> float:
        """Calculate speed adapted to distance"""
        if distance < cls.DISTANCE_DANGER:
            return cls.SPEED_VERY_SLOW
        elif distance < cls.DISTANCE_CLOSE:
            return cls.SPEED_SLOW
        elif distance < cls.DISTANCE_COMFORT:
            return cls.SPEED_NORMAL
        else:
            return cls.SPEED_MAX

    # Aliases for backward compatibility
    peut_avancer = can_move_forward
    peut_tourner = can_turn
    vitesse_adaptee = adapted_speed
