"""
NavigationNode - Priority 10

MISSION: Navigate intelligently through space.

This node handles:
- Angle and turn detection
- Optimal direction choice
- Corridor trajectory maintenance

RULES:
1. If angle detected (one side close, other free) -> turn
2. If corridor (front free, sides close) -> forward
3. Otherwise -> None (let explorer decide)
"""

from typing import Optional
from ..core.node import Node, Decision, Action
from ..core.sensors import SensorData
from ..config import RobotConfig


class NavigationNode(Node):
    """
    Navigation node - Handles turns and corridors.

    Priority 10 = After safety, before exploration.
    """

    def __init__(self):
        super().__init__("NAVIGATION", priority=10)
        self.last_turn: Optional[Action] = None
        self.turn_persistence = 0

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            # Maintain last turn for a few ticks
            if self.last_turn and self.turn_persistence > 0:
                self.turn_persistence -= 1
                return Decision(
                    action=self.last_turn,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"NAV: persisting turn ({self.turn_persistence})"
                )
            return None

        front = sensors.front
        left = sensors.left or float('inf')
        right = sensors.right or float('inf')
        left_front = sensors.left_front or left
        right_front = sensors.right_front or right

        threshold = RobotConfig.DIAG_CHASSIS

        # Calculate space on each side
        min_left = min(left, left_front)
        min_right = min(right, right_front)
        max_left = max(left, left_front)
        max_right = max(right, right_front)

        # RULE 1: Angle detected - one side close, other free
        if min_right < threshold and min_left >= threshold:
            return self._turn(Action.TURN_LEFT,
                f"NAV: angle right={min_right:.2f}m, turning left")

        if min_left < threshold and min_right >= threshold:
            return self._turn(Action.TURN_RIGHT,
                f"NAV: angle left={min_left:.2f}m, turning right")

        # RULE 2: Both sides close -> choose less blocked
        if min_left < threshold and min_right < threshold:
            if max_right > max_left:
                return self._turn(Action.TURN_RIGHT,
                    f"NAV: narrow L={min_left:.2f} R={min_right:.2f}, right has more space")
            else:
                return self._turn(Action.TURN_LEFT,
                    f"NAV: narrow L={min_left:.2f} R={min_right:.2f}, left has more space")

        # RULE 3: Diagonal danger
        if left_front < threshold and right_front >= threshold:
            return self._turn(Action.TURN_RIGHT,
                f"NAV: diagonal left_front={left_front:.2f}m")

        if right_front < threshold and left_front >= threshold:
            return self._turn(Action.TURN_LEFT,
                f"NAV: diagonal right_front={right_front:.2f}m")

        # RULE 4: Front blocked but sides free
        if front < threshold:
            if max_right > max_left:
                return self._turn(Action.TURN_RIGHT,
                    f"NAV: front blocked={front:.2f}m, right has space")
            else:
                return self._turn(Action.TURN_LEFT,
                    f"NAV: front blocked={front:.2f}m, left has space")

        # No turn needed -> reset persistence and let explorer handle
        self.last_turn = None
        self.turn_persistence = 0
        return None

    def _turn(self, action: Action, reason: str) -> Decision:
        """Create a turn decision with persistence."""
        self.last_turn = action
        self.turn_persistence = 3  # Maintain for 3 ticks without sensors
        return Decision(
            action=action,
            speed=RobotConfig.SPEED_SLOW,
            reason=reason
        )

    def reset(self):
        self.last_turn = None
        self.turn_persistence = 0
