"""
SafetyNode - Priority 0 (ABSOLUTE)

MISSION: Prevent collisions. Period.

This node has maximum priority. If it decides, no one can
override it. It's the ultimate safeguard.

RULES:
1. If front < DANGER -> STOP or BACKWARD
2. If completely stuck -> STOP
3. Otherwise -> None (let others decide)
"""

from typing import Optional
from ..core.node import Node, Decision, Action
from ..core.sensors import SensorData
from ..config import RobotConfig


class SafetyNode(Node):
    """
    Safety node - Collision avoidance.

    Priority 0 = Executes first, ALWAYS.
    """

    def __init__(self):
        super().__init__("SAFETY", priority=0)
        self.stuck_count = 0

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        # No sensors -> can't decide
        if not sensors.is_valid():
            return None

        front = sensors.front
        left = sensors.left or float('inf')
        right = sensors.right or float('inf')

        # RULE 1: Imminent frontal collision
        if front < RobotConfig.DISTANCE_DANGER:
            # Try to turn toward larger space
            if left > right and left > RobotConfig.DIAG_CHASSIS:
                return Decision(
                    action=Action.TURN_LEFT,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"SAFETY: front={front:.2f}m, turn left"
                )
            elif right > RobotConfig.DIAG_CHASSIS:
                return Decision(
                    action=Action.TURN_RIGHT,
                    speed=RobotConfig.SPEED_SLOW,
                    reason=f"SAFETY: front={front:.2f}m, turn right"
                )
            else:
                # No viable direction -> back up
                return Decision(
                    action=Action.BACKWARD,
                    speed=RobotConfig.SPEED_VERY_SLOW,
                    reason="SAFETY: blocked, backing up"
                )

        # RULE 2: Completely stuck (all sides blocked)
        if (front < RobotConfig.DISTANCE_CLOSE and
            left < RobotConfig.DISTANCE_CLOSE and
            right < RobotConfig.DISTANCE_CLOSE):

            self.stuck_count += 1

            if self.stuck_count >= 5:
                return Decision(
                    action=Action.STOP,
                    speed=0,
                    reason="SAFETY: trapped, stopping"
                )
            elif self.stuck_count >= 3:
                # After backing up, try turning
                if left > right:
                    return Decision(
                        action=Action.TURN_LEFT,
                        speed=RobotConfig.SPEED_SLOW,
                        reason=f"SAFETY: trapped ({self.stuck_count}x), turning left"
                    )
                else:
                    return Decision(
                        action=Action.TURN_RIGHT,
                        speed=RobotConfig.SPEED_SLOW,
                        reason=f"SAFETY: trapped ({self.stuck_count}x), turning right"
                    )
            else:
                return Decision(
                    action=Action.BACKWARD,
                    speed=RobotConfig.SPEED_VERY_SLOW,
                    reason=f"SAFETY: trapped ({self.stuck_count}x), backing up"
                )
        else:
            # Only reset if not in oscillation (front is really clear)
            if front > RobotConfig.DISTANCE_SAFE:
                self.stuck_count = 0

        # No immediate danger -> let other nodes decide
        return None

    def reset(self):
        self.stuck_count = 0
