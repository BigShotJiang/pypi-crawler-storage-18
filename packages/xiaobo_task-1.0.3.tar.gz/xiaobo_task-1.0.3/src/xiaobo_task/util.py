# -*- coding: utf-8 -*-
"""
通用工具模块
"""
import threading
from typing import List, Optional
from pathlib import Path
import sys

from curl_cffi import BrowserTypeLiteral, Session, AsyncSession
from curl_cffi.requests.impersonate import DEFAULT_CHROME

# 进程内文件锁表，避免多线程写同一文件时竞争
_thread_file_locks: dict[Path, threading.Lock] = {}
_file_locks_guard = threading.Lock()


def _resolve_txt_path(filename: str, create_file: bool = False) -> Path:
    """补全 .txt 后缀并将相对路径定位到脚本目录，缺失时回退到脚本父目录同级 data 目录。"""
    if not filename.lower().endswith('.txt'):
        filename += '.txt'

    path = Path(filename)
    if not path.is_absolute():
        entry_dir = Path(sys.argv[0]).resolve().parent
        primary = entry_dir / path
        if primary.exists():
            path = primary
        else:
            data_dir = entry_dir.parent / 'data'
            candidate = data_dir / path
            if candidate.exists():
                path = candidate
            else:
                if create_file:
                    data_dir.mkdir(parents=True, exist_ok=True)
                    path = candidate
                else:
                    raise FileNotFoundError(
                        f"错误：文件未找到，已尝试 '{primary}' 与 '{candidate}'。"
                    )
    return path


def read_txt_file_lines(filename: str) -> List[str]:
    """
    读取txt文件内容并按行返回一个列表。

    功能:
    - 如果文件名没有 .txt 后缀(不区分大小写)，会自动补全。
    - 优先读取脚本目录下的文件；不存在则读取脚本父目录同级的 data 目录。
    - 按行读取文件，并去除每行两侧的空白字符（包括换行符）。
    - 返回一个包含文件中所有非空行的字符串列表。

    :param filename: 要读取的txt文件名。
    :return: 包含文件所有行的字符串列表。
    :raises FileNotFoundError: 如果文件未找到。
    :raises IOError: 如果发生其他读取错误。
    """
    path = _resolve_txt_path(filename)

    try:
        with open(path, 'r', encoding='utf-8') as f:
            # 使用列表推导式高效读取，并只保留非空行
            lines = [line.strip() for line in f if line.strip()]
        return lines
    except FileNotFoundError:
        raise FileNotFoundError(f"读取文件 '{path}' 时发生错误: 未找到文件")
    except Exception as e:
        raise IOError(f"读取文件 '{path}' 时发生错误: {e}")


def write_txt_file(filename: str, data: str | List[str], append: bool = True, separator: str = "----") -> None:
    """
    写入或追加文本到txt文件。

    功能:
    - 自动补全 .txt 后缀（不区分大小写）。
    - 优先写入/追加脚本目录下的文件；不存在则写入脚本父目录同级的 data 目录。
    - data 支持字符串或字符串列表，列表会用分隔符拼接后写入。
    - append 为 True 时追加写入，否则覆盖写入，默认 True。
    - separator 控制列表拼接时的分隔符，默认 "----"。

    :param filename: 目标文件名。
    :param data: 要写入的内容，字符串或字符串列表。
    :param append: 是否追加写入。
    :param separator: data 为列表时的拼接分隔符。
    """
    path = _resolve_txt_path(filename, create_file=True)
    lock = _get_thread_lock(path)

    text = separator.join(data) if isinstance(data, list) else str(data)
    if text and not text.endswith('\n'):
        text += '\n'

    mode = 'a' if append else 'w'
    with lock:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, mode, encoding='utf-8') as f:
            f.write(text)


def get_session(proxy: str = None, timeout: int = 30, impersonate: Optional[BrowserTypeLiteral] = DEFAULT_CHROME):
    return Session(proxy=proxy, timeout=timeout, impersonate=impersonate)


def get_async_session(proxy: str = None, timeout: int = 30, impersonate: Optional[BrowserTypeLiteral] = DEFAULT_CHROME):
    return AsyncSession(proxy=proxy, timeout=timeout, impersonate=impersonate)


def _get_thread_lock(path: Path) -> threading.Lock:
    """为目标路径获取/创建一个进程内线程锁。"""
    with _file_locks_guard:
        lock = _thread_file_locks.get(path)
        if lock is None:
            lock = threading.Lock()
            _thread_file_locks[path] = lock
        return lock
