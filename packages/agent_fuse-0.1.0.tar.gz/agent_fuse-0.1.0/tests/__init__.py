"""Sentinel Guard Tests."""
