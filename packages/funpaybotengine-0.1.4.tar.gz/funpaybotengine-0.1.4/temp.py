import sys


N = 10_000_000


class MyClassWithSlots:
    __slots__ = ('field_1', 'field_2', 'field_3')

    def __init__(
        self,
        field_1: int,
        field_2: str,
        field_3: bool,
    ):
        self.field_1 = field_1
        self.field_2 = field_2
        self.field_3 = field_3


class MyClassWithoutSlots:
    def __init__(
        self,
        field_1: int,
        field_2: str,
        field_3: bool,
    ):
        self.field_1 = field_1
        self.field_2 = field_2
        self.field_3 = field_3


print('creating with slots')
a = [MyClassWithSlots(1, "2", True) for _ in range(N)]
#print('creating without slots')
#a = [MyClassWithoutSlots(1, "2", True) for _ in range(N)]

print(sys.getsizeof(a[0]) / 1024, 'kB')
print(sys.getsizeof(a[0]) * N / 1024, 'kB')
input()