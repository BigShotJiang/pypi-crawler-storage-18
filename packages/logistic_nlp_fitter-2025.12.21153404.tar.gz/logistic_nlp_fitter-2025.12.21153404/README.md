# Logistic NLP Fitter
[![PyPI version](https://badge.fury.io/py/logistic-nlp-fitter.svg)](https://badge.fury.io/py/logistic-nlp-fitter)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/logistic-nlp-fitter)](https://pepy.tech/project/logistic-nlp-fitter)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A Python package for fitting logistic curves to data using natural language descriptions.

## Overview

The `logistic_nlp_fitter` package allows users to fit logistic curves to their data by interpreting textual descriptions of datasets or growth scenarios. It takes natural language input and returns structured parameters of a logistic model, such as carrying capacity, growth rate, and inflection point. This is useful for researchers, analysts, or students who want quick, automated curve fitting without manually coding or using complex statistical software.

## Installation

```bash
pip install logistic_nlp_fitter
```

## Usage

### Basic Usage

```python
from logistic_nlp_fitter import logistic_nlp_fitter

response = logistic_nlp_fitter("I have data showing population growth that starts slow, speeds up, and then slows down again")
print(response)
```

### Using a Custom LLM

You can use your own LLM instance by passing it to the function:

```python
from langchain_openai import ChatOpenAI
from logistic_nlp_fitter import logistic_nlp_fitter

llm = ChatOpenAI()
response = logistic_nlp_fitter("I have data showing population growth that starts slow, speeds up, and then slows down again", llm=llm)
print(response)
```

### Using LLM7 with API Key

If you want to use LLM7 with your own API key, you can pass it directly or set it as an environment variable:

```python
from logistic_nlp_fitter import logistic_nlp_fitter

# Using environment variable
import os
os.environ["LLM7_API_KEY"] = "your_api_key"
response = logistic_nlp_fitter("I have data showing population growth that starts slow, speeds up, and then slows down again")
print(response)

# Passing API key directly
response = logistic_nlp_fitter("I have data showing population growth that starts slow, speeds up, and then slows down again", api_key="your_api_key")
print(response)
```

## Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the package will use the default or the one set in the environment variable `LLM7_API_KEY`.

## Default LLM

The package uses `ChatLLM7` from `langchain_llm7` by default. You can find more information about `ChatLLM7` [here](https://pypi.org/project/langchain-llm7/).

## Rate Limits

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you want higher rate limits, you can pass your own API key via the environment variable `LLM7_API_KEY` or directly to the function. You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/logistic-nlp-fitter/issues).

## Author

- **Eugene Evstafev**
- **Email**: hi@eugene.plus
- **GitHub**: [chigwell](https://github.com/chigwell)