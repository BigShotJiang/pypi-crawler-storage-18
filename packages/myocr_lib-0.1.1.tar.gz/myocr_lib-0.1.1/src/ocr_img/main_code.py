import cv2
from PIL import Image
import pytesseract


class ImageOCR:
    def __init__(self, image_path):

        # variables section
        self.image_path = image_path

    def _preprocess_image(self, img_path):

        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

        # check if it supported webp
        if img is None:
            # Process for the webp image
            img = Image.open(img_path).convert("RGB")


        else:

            # Light preprocessing (fast)
            img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

        return img
    
    def _apply_ocr(self, img):
        text = pytesseract.image_to_string(
            img,
            lang="eng",
            config="--oem 3 --psm 6"
        )
        return text
    

    def run(self):
        # preprocess the image for better results
        img = self._preprocess_image(self.image_path)

        # apply the ocr 
        text = self._apply_ocr(img)

        print(text)

        # temporary save to file for demo
        # get the extension
        # ext = self.image_path.split('.')[-1]
        # with open(f'{self.image_path.replace(ext,"txt")}', 'w') as file:
        #     file.write(text)

        return text



