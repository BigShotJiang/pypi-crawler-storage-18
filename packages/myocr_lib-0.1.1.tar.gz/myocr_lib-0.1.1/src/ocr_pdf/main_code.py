
import ocrmypdf
import fitz  # PyMuPDF
import subprocess
import os

class OCRDataExtractor:
    def __init__(self, input_pdf_path):

        # variables section
        self.input_pdf_path = input_pdf_path
        self.output_file_path = input_pdf_path.replace('.pdf','_output.pdf')
        self.pages_to_ocr = [] # holds the pages needing ocr 



    def _apply_whole_pdf_ocr(self):
        # Define the Commands
        command = [
            "ocrmypdf",
            f"{self.input_pdf_path}",
            f"{self.output_file_path}",
            # "--force-ocr",
            "--tesseract-timeout", "1000" # increased timeout
        ]

        # run the command
        result = subprocess.run(command, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("PDF Was converted to Selectable Successfully.")
        
            return True
        
        return False
    

    def _is_whole_pdf_ocr(self):
        # read and extract the whole text from the pdf
        THRESHOLD_VALUE = 100 # minimum text
        is_whole_pdf_ocr_applicable = True

        with fitz.open(self.input_pdf_path) as doc:
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                text = page.get_text()
                if len(text.strip()) > THRESHOLD_VALUE:
                    is_whole_pdf_ocr_applicable = False
                else:
                    # append to the page list
                    self.pages_to_ocr.append(page_num)
            
        return is_whole_pdf_ocr_applicable
    
    def _is_page_by_page_ocr(self):
        return len(self.pages_to_ocr) > 0
    

    def _apply_page_by_page_ocr(self):
        # apply the ocr on all the pages needed ocr separately
        pages_str_format = ','.join(str(page+1) for page in self.pages_to_ocr)  # Convert to 1-based indexing

        print("Pages to extract text from...", pages_str_format)

        # Define the Commands
        command = [
            "ocrmypdf",
            f"{self.input_pdf_path}",
            f"{self.output_file_path}",
            # "--force-ocr",
            '--pages',pages_str_format,
            "--tesseract-timeout", "1000" # increased timeout
        ]

        # run the command
        result = subprocess.run(command, capture_output=True, text=True)
        
        if result.returncode == 0:
            print("Ocr was applied on the pages.")
        
            return True
        
        return False
    

    def _extract_text_whole_pdf(self):
        text = {}
        text = ""
        with fitz.open(self.output_file_path) as doc:
            # Iterate through each page
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                # text[page_num] = page.get_text()
                text += f'Page {page_num + 1} Text\n' + '*' * 20 + page.get_text() + '\n\n'

        return text

    def _extract_text_page_by_page(self):
        text = {}

        with fitz.open(self.output_file_path) as doc:
            for page_num in self.pages_to_ocr:
                page = doc.load_page(page_num)
                text[page_num] = page.get_text()

        return text
    

    def get_ocr_results(self):
        # apply the whole pdf ocr if all the pages are extractable
        if self._is_whole_pdf_ocr():
            print("Applying whole Pdf ocr...")

            results = self._apply_whole_pdf_ocr()

            # apply the extraction for the whole pdf through fitz
            text = self._extract_text_whole_pdf() if results else None

            print(text)

            # temporary store the text
            # ext = self.input_pdf_path.split('.')[-1]
            # with open(self.input_pdf_path.replace(ext,'txt'),'w') as file:
            #     file.write(text)

            # delete the output file
            self.delete_file(self.output_file_path)
            print("Done Successfully...")

            return text

        
        elif self._is_page_by_page_ocr():
            print("Applying page by page ocr...")

            # do page by page
            results = self._apply_page_by_page_ocr()

            # do the extraction for specific pages only throug fitz
            text = self._extract_text_page_by_page() if results else None

            print(text)

            # delete the output file
            self.delete_file(self.output_file_path)
            print("Done...")

            return text

        else:
            # do normal extraction
            return None 

            print("No Ocr needed...")
            

        
    def delete_file(self, file):
        if os.path.exists(file):
            os.remove(file)
            

    def get_ocred_pages(self):
        return self.pages_to_ocr
    
    def run(self):

        text = self.get_ocr_results()
        pages_to_ignore = self.get_ocred_pages()

        return text, pages_to_ignore
    
    
    

        