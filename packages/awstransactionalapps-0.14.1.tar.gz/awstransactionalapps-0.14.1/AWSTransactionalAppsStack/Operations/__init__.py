"""Operations module for AWSTransactionalApps."""
