#!/bin/bash
set -euo pipefail

echo "[INFO] Starting application build..."

run_cmd() {
    "$@"
}

if ! command -v docker &> /dev/null; then
    echo "[ERROR] docker is not installed" >&2
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "[ERROR] docker-compose is not installed" >&2
    exit 1
fi

COMPOSE_FILE="docker-compose.yaml"
if [ ! -f "$COMPOSE_FILE" ]; then
    echo "[ERROR] $COMPOSE_FILE not found in the current directory. Checking to see .yml" >&2
    COMPOSE_FILE="docker-compose.yml"
    if [ ! -f "$COMPOSE_FILE" ]; then
        echo "[ERROR] $COMPOSE_FILE not found in the current directory." >&2
        exit 1
    fi
fi

BUILD_PLATFORMS="linux/amd64,linux/arm64"
echo "[INFO] Building multi-arch Docker images..."
run_cmd docker buildx bake -f "$COMPOSE_FILE" --set "*.platform=$BUILD_PLATFORMS"

echo "[INFO] Build complete."
