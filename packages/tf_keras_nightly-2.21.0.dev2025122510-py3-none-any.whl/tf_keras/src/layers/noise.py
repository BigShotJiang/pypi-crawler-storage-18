# Copyright 2015 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Layers that operate regularization via the addition of noise."""


from tf_keras.src.layers.regularization.alpha_dropout import (  # noqa: F401
    AlphaDropout,
)

# Regularization layers imported for backwards namespace compatibility
from tf_keras.src.layers.regularization.gaussian_dropout import (  # noqa: F401,E501
    GaussianDropout,
)
from tf_keras.src.layers.regularization.gaussian_noise import (  # noqa: F401,E501
    GaussianNoise,
)

