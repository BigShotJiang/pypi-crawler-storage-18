# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class StopInstanceReplicationPolicyExecutionRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'execution_id': 'int'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'execution_id': 'execution_id'
    }

    def __init__(self, instance_id=None, execution_id=None):
        r"""StopInstanceReplicationPolicyExecutionRequest

        The model defined in huaweicloud sdk

        :param instance_id: 企业仓库实例ID
        :type instance_id: str
        :param execution_id: 同步策略执行记录ID
        :type execution_id: int
        """
        
        

        self._instance_id = None
        self._execution_id = None
        self.discriminator = None

        self.instance_id = instance_id
        self.execution_id = execution_id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this StopInstanceReplicationPolicyExecutionRequest.

        企业仓库实例ID

        :return: The instance_id of this StopInstanceReplicationPolicyExecutionRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this StopInstanceReplicationPolicyExecutionRequest.

        企业仓库实例ID

        :param instance_id: The instance_id of this StopInstanceReplicationPolicyExecutionRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def execution_id(self):
        r"""Gets the execution_id of this StopInstanceReplicationPolicyExecutionRequest.

        同步策略执行记录ID

        :return: The execution_id of this StopInstanceReplicationPolicyExecutionRequest.
        :rtype: int
        """
        return self._execution_id

    @execution_id.setter
    def execution_id(self, execution_id):
        r"""Sets the execution_id of this StopInstanceReplicationPolicyExecutionRequest.

        同步策略执行记录ID

        :param execution_id: The execution_id of this StopInstanceReplicationPolicyExecutionRequest.
        :type execution_id: int
        """
        self._execution_id = execution_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, StopInstanceReplicationPolicyExecutionRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
