"""CLI module for kubesealpy."""
