# pycessingame

## Deutsch

Processing-Style Coding mit Python & Pygame.

PYCESSINGAME bringt den Geist von Processing in die Python-Welt – leichtgewichtig,
direkt und ohne Umwege. Es richtet sich an Lehrende, Entwickler:innen, 
Künstler:innen und Designer:innen, die visuelles, interaktives Creative Coding
lieben und dabei die Einfachheit von Processing schätzen.

Mit einer bewusst vertrauten API kannst du sofort loslegen:
setup(), draw(), ellipse(), fill(), stroke(), color(), random() – alles 
fühlt sich an wie Processing, nur eben pures Python.

Warum noch eine Implementierung?
- einfach Pyhton, kein Java, kein transpiling
- gleiche Namen, gleiche Konzepte, gleiches Denken
- Schreibstil nach Geschmack: camelCase oder snake_case
- nur von einem anderen python paket (pygame) abhängig
- gleich los zeichnen und nicht um Fenster, Rendering und Events kümmmern
- einfacher Start und die ganze Python-Welt zur Verfügung
- völlig freie Nutzung

Einfache **Installation**:
`pip install pycessingame`

## English

Processing-style coding with Python & Pygame

PYCESSINGAME brings the spirit of Processing to the Python world — lightweight, 
direct, and without detours. It is designed for educators, developers, 
artists, and designers who love visual, interactive creative coding and 
appreciate the simplicity of Processing.

With a deliberately familiar API, you can start right away:
setup(), draw(), ellipse(), fill(), stroke(), color(), random() — everything 
feels like Processing, just pure Python.

Why yet another implementation?
- pure Python — no Java, no transpiling
- same names, same concepts, same way of thinking
- coding style of your choice: camelCase or snake_case
- depends on only one external Python package (pygame)
- start drawing immediately without worrying about windows, rendering, or events
- easy to get started, with the entire Python ecosystem at your disposal 
- completely free to use

Easy **installation**:
`pip install pycessingame`

## Beispiel  / Example

```python
from pycessingame import *

def setup():
    size(640, 480)
    frameRate(60)
    
def draw():
    background(30, 120, 200)
    fill(255, 200, 0)
    noStroke()
    ellipse(width/2, height/2, 150, 150)
    
run()
```

![Screenshot](docs/screenshot.png)

## Referenzen / references

https://processing.org/

https://openprocessing.org/

https://p5js.org/

https://pypi.org/project/p5/

https://py5coding.org/index.html


## Notizen / Gedächtnisstütze

git tag & push => build & pypi upload:

`git tag v0.0.0`

`git push origin v0.0.0`

Realisiert mit einen git pre-push hook (.git/hooks/pre-push)und pypi Zugangsdaten in ~/.pypirc.