import pycessingame

print(frameRate)
print(frame_rate)
