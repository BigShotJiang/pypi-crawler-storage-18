"""Test suite for filtarr."""
