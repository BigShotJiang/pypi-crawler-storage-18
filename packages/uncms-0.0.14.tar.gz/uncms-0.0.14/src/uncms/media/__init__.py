"""Static media management application."""
