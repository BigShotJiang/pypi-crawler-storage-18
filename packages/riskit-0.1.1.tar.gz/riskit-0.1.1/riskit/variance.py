import asyncio
from dataclasses import dataclass

from riskit.types import (
    Costs,
    Risk,
    ArrayLike,
    BatchCostFunction,
    TrajectoriesProvider,
    Uncertainties,
    Sampler,
    Backend,
)


@dataclass(frozen=True)
class MeanVariance[
    TrajectoriesT,
    UncertaintySamplesT,
    CostsT: Costs,
    RiskT: Risk,
    ArrayT: ArrayLike,
]:
    cost: BatchCostFunction[TrajectoriesT, UncertaintySamplesT, CostsT]
    backend: Backend[CostsT, RiskT, ArrayT]
    sampler: Sampler[UncertaintySamplesT]
    gamma: float

    async def compute(
        self,
        *,
        trajectories: TrajectoriesProvider[TrajectoriesT],
        uncertainties: Uncertainties[UncertaintySamplesT],
    ) -> RiskT:
        M = trajectories.trajectory_count

        samples, N = await self.sampler.sample_from(uncertainties)
        costs = self.cost(trajectories=await trajectories.get(), uncertainties=samples)

        assert costs.shape == (M, N), (
            f"Costs shape {costs.shape} does not match expected shape {(M, N)}."
        )

        async with self.backend as op:
            costs = await op.array_of(costs)
            mean, variance = await asyncio.gather(
                op.mean(costs, axis=1), op.var(costs, axis=1)
            )

            return await op.to_risk(await op.axpby(x=mean, b=self.gamma, y=variance))

    def sampled_with(
        self, sampler: Sampler[UncertaintySamplesT]
    ) -> "MeanVariance[TrajectoriesT, UncertaintySamplesT, CostsT, RiskT, ArrayT]":
        return MeanVariance(
            cost=self.cost, backend=self.backend, sampler=sampler, gamma=self.gamma
        )
