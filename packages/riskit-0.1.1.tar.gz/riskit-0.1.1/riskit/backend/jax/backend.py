from typing import Protocol, NamedTuple, Self, Annotated
from types import TracebackType

import jax.numpy as jnp
from jax import Array


class JaxBackend:
    @staticmethod
    def create() -> "JaxBackend":
        return JaxBackend()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        pass

    async def array_of(self, costs: "Costs") -> "Costs":
        return costs

    async def to_risk(self, array: Array) -> "Risk":
        assert array.ndim == 1, "Expected risk array to be one-dimensional."
        return array

    async def mean(self, data: Array, *, axis: int) -> Array:
        return jnp.mean(data, axis=axis)

    async def var(self, data: Array, *, axis: int) -> Array:
        return jnp.var(data, axis=axis)

    async def axpby(
        self, *, a: float = 1.0, x: Array, b: float = 1.0, y: Array
    ) -> Array:
        return a * x + b * y


type Inputs = Array
"""Batch of control inputs. The dimensions are (time steps, control dimensions, trajectories)."""

type States = Array
"""Batch of states. The dimensions are (time steps, state dimensions, trajectories)."""

type UncertaintySamples = Array
"""Batch of uncertainty samples. The dimensions are (...uncertainty dimensions, uncertainty samples)."""

type Costs = Annotated[Array, JaxBackend.create]
"""Batch of costs. The dimensions are (trajectories, uncertainty samples)."""

type Risk = Array
"""Batch of risk values. The dimensions are (trajectories,)."""


class Uncertainty(Protocol):
    async def sample(self, count: int) -> UncertaintySamples:
        """Returns samples from the distribution of the uncertain variable(s)."""
        ...


class BatchCostFunction[TrajectoriesT, UncertaintySamplesT](Protocol):
    def __call__(
        self, *, trajectories: TrajectoriesT, uncertainties: UncertaintySamplesT
    ) -> Costs:
        """Describes the cost function that should be used for evaluating risk."""
        ...


class InputAndState(NamedTuple):
    u: Inputs
    x: States


class InputAndStateProvider(NamedTuple):
    u: Inputs
    x: States

    async def get(self) -> InputAndState:
        return InputAndState(u=self.u, x=self.x)

    @property
    def trajectory_count(self) -> int:
        return self.u.shape[2]
