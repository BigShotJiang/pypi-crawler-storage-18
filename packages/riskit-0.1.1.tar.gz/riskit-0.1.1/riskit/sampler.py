from dataclasses import dataclass

from riskit.types import Uncertainties, SamplingResult


@dataclass(frozen=True)
class MonteCarlo[UncertaintySamplesT]:
    sample_count: int = 5000

    async def sample_from(
        self, uncertainties: Uncertainties[UncertaintySamplesT]
    ) -> SamplingResult[UncertaintySamplesT]:
        return SamplingResult(
            samples=await uncertainties.sample(count=self.sample_count),
            sample_count=self.sample_count,
        )
