# ordinary-fractions

Небольшая библиотека Python для работы с обыкновенными дробями: нормализация, арифметика, сравнения, парсинг строк и вывод в смешанном виде.

## Установка

### Из PyPI
```bash
pip install ordinary-fractions
````

### Локально из исходников

```bash
pip install -e .
```

## Зависимости

* Runtime: нет внешних зависимостей
* Для тестов: `pytest`

Установка зависимостей для разработки:

```bash
pip install -U pip
pip install -U pytest build twine
```

## Использование

```python
from ordinary_fractions import Fraction, parse_fraction, format_mixed

a = Fraction(1, 2)
b = Fraction(1, 3)

print(a + b)
print(a / b)
print(parse_fraction("2 1/3"))
print(format_mixed(Fraction(-7, 3)))
```

## Запуск тестов

```bash
pytest -q
```

