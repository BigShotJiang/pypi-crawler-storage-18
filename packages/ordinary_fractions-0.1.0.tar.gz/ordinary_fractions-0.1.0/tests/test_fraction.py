import pytest

from ordinary_fractions import Fraction


def test_normalization_sign_and_gcd():
    assert Fraction(2, 4) == Fraction(1, 2)
    assert Fraction(-2, 4) == Fraction(-1, 2)
    assert Fraction(2, -4) == Fraction(-1, 2)
    assert Fraction(-2, -4) == Fraction(1, 2)


def test_zero_denominator():
    with pytest.raises(ZeroDivisionError):
        Fraction(1, 0)


def test_add_sub_mul_div():
    a = Fraction(1, 2)
    b = Fraction(1, 3)
    assert a + b == Fraction(5, 6)
    assert a - b == Fraction(1, 6)
    assert a * b == Fraction(1, 6)
    assert a / b == Fraction(3, 2)


def test_int_coercion():
    assert Fraction(1, 2) + 1 == Fraction(3, 2)
    assert 1 + Fraction(1, 2) == Fraction(3, 2)
    assert 2 - Fraction(1, 2) == Fraction(3, 2)
    assert Fraction(1, 2) * 2 == Fraction(1, 1)
    assert 2 * Fraction(1, 2) == Fraction(1, 1)
    assert 1 / Fraction(1, 2) == Fraction(2, 1)


def test_division_by_zero_fraction():
    with pytest.raises(ZeroDivisionError):
        Fraction(1, 2) / Fraction(0, 1)


def test_comparisons():
    assert Fraction(1, 2) < Fraction(2, 3)
    assert Fraction(1, 2) <= Fraction(2, 3)
    assert Fraction(2, 3) > Fraction(1, 2)
    assert Fraction(2, 3) >= Fraction(1, 2)
    assert Fraction(2, 4) == Fraction(1, 2)


def test_pow_and_reciprocal():
    assert Fraction(2, 3) ** 2 == Fraction(4, 9)
    assert Fraction(2, 3) ** 0 == Fraction(1, 1)
    assert Fraction(2, 3) ** -1 == Fraction(3, 2)


def test_to_mixed():
    assert Fraction(7, 3).to_mixed() == (2, Fraction(1, 3))
    assert Fraction(-7, 3).to_mixed() == (-3, Fraction(2, 3))
    assert Fraction(6, 3).to_mixed() == (2, Fraction(0, 1))
