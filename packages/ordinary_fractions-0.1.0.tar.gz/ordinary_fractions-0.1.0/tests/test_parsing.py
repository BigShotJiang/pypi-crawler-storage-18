import pytest

from ordinary_fractions import Fraction, parse_fraction, format_mixed


def test_parse_int():
    assert parse_fraction("10") == Fraction(10, 1)
    assert parse_fraction("-10") == Fraction(-10, 1)
    assert parse_fraction(5) == Fraction(5, 1)


def test_parse_simple_fraction():
    assert parse_fraction(" 2/4 ") == Fraction(1, 2)
    assert parse_fraction("-2/4") == Fraction(-1, 2)
    assert parse_fraction("2/-4") == Fraction(-1, 2)


def test_parse_mixed_fraction():
    assert parse_fraction("2 1/3") == Fraction(7, 3)
    assert parse_fraction("-2 1/3") == Fraction(-7, 3)
    assert parse_fraction("  10   2/5  ") == Fraction(52, 5)


def test_parse_invalid():
    with pytest.raises(ValueError):
        parse_fraction("abc")
    with pytest.raises(ValueError):
        parse_fraction("1 /")
    with pytest.raises(ZeroDivisionError):
        parse_fraction("1/0")
    with pytest.raises(TypeError):
        parse_fraction(1.5)


def test_format_mixed():
    assert format_mixed(Fraction(7, 3)) == "2 1/3"
    assert format_mixed(Fraction(-7, 3)) == "-3 2/3"
    assert format_mixed(Fraction(1, 2)) == "1/2"
    assert format_mixed(Fraction(6, 3)) == "2"
