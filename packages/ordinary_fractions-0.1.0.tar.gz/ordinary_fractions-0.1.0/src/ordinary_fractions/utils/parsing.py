from __future__ import annotations

import re
from typing import Union

from ordinary_fractions.core.fraction import Fraction


_mixed_re = re.compile(r"^\s*([+-]?\d+)\s+(\d+)\s*/\s*(\d+)\s*$")
_frac_re = re.compile(r"^\s*([+-]?\d+)\s*/\s*([+-]?\d+)\s*$")
_int_re = re.compile(r"^\s*([+-]?\d+)\s*$")


def parse_fraction(value: Union[str, int, Fraction]) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value, 1)
    if not isinstance(value, str):
        raise TypeError("value must be str, int, or Fraction")

    s = value.strip()
    m = _mixed_re.match(s)
    if m:
        whole = int(m.group(1))
        n = int(m.group(2))
        d = int(m.group(3))
        if n < 0 or d < 0:
            raise ValueError("Mixed fraction must have non-negative numerator/denominator parts")
        base = Fraction(n, d)
        if whole < 0:
            return Fraction(whole, 1) - base
        return Fraction(whole, 1) + base

    m = _frac_re.match(s)
    if m:
        return Fraction(int(m.group(1)), int(m.group(2)))

    m = _int_re.match(s)
    if m:
        return Fraction(int(m.group(1)), 1)

    raise ValueError(f"Cannot parse fraction from: {value!r}")


def format_mixed(frac: Fraction) -> str:
    f = parse_fraction(frac)
    whole, rem = f.to_mixed()
    if rem.numerator == 0:
        return str(whole)
    if whole == 0:
        return str(rem)
    if whole < 0:
        rem_abs = abs(rem)
        return f"{whole} {rem_abs.numerator}/{rem_abs.denominator}"
    return f"{whole} {rem.numerator}/{rem.denominator}"
