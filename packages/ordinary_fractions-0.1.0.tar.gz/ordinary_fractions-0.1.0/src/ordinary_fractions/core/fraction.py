from __future__ import annotations

from dataclasses import dataclass
from math import gcd
from typing import Any


def _normalize(n: int, d: int) -> tuple[int, int]:
    if d == 0:
        raise ZeroDivisionError("Denominator cannot be zero")
    if d < 0:
        n, d = -n, -d
    g = gcd(n, d)
    return n // g, d // g


@dataclass(frozen=True, slots=True)
class Fraction:
    numerator: int
    denominator: int = 1

    def __post_init__(self) -> None:
        n, d = _normalize(int(self.numerator), int(self.denominator))
        object.__setattr__(self, "numerator", n)
        object.__setattr__(self, "denominator", d)

    @staticmethod
    def from_int(value: int) -> "Fraction":
        return Fraction(int(value), 1)

    def __str__(self) -> str:
        if self.denominator == 1:
            return str(self.numerator)
        return f"{self.numerator}/{self.denominator}"

    def __repr__(self) -> str:
        return f"Fraction({self.numerator}, {self.denominator})"

    def to_float(self) -> float:
        return self.numerator / self.denominator

    def to_tuple(self) -> tuple[int, int]:
        return self.numerator, self.denominator

    def to_mixed(self) -> tuple[int, "Fraction"]:
        n, d = self.numerator, self.denominator
        whole = int(n // d)
        rem = n - whole * d
        if rem == 0:
            return whole, Fraction(0, 1)
        return whole, Fraction(rem, d)

    def reciprocal(self) -> "Fraction":
        if self.numerator == 0:
            raise ZeroDivisionError("Cannot take reciprocal of zero")
        return Fraction(self.denominator, self.numerator)

    def __neg__(self) -> "Fraction":
        return Fraction(-self.numerator, self.denominator)

    def __abs__(self) -> "Fraction":
        return Fraction(abs(self.numerator), self.denominator)

    def _coerce(self, other: Any) -> "Fraction":
        if isinstance(other, Fraction):
            return other
        if isinstance(other, int):
            return Fraction(other, 1)
        return NotImplemented

    def __add__(self, other: Any) -> "Fraction":
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return Fraction(self.numerator * o.denominator + o.numerator * self.denominator, self.denominator * o.denominator)

    def __radd__(self, other: Any) -> "Fraction":
        return self.__add__(other)

    def __sub__(self, other: Any) -> "Fraction":
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return Fraction(self.numerator * o.denominator - o.numerator * self.denominator, self.denominator * o.denominator)

    def __rsub__(self, other: Any) -> "Fraction":
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return o.__sub__(self)

    def __mul__(self, other: Any) -> "Fraction":
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return Fraction(self.numerator * o.numerator, self.denominator * o.denominator)

    def __rmul__(self, other: Any) -> "Fraction":
        return self.__mul__(other)

    def __truediv__(self, other: Any) -> "Fraction":
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        if o.numerator == 0:
            raise ZeroDivisionError("Division by zero")
        return Fraction(self.numerator * o.denominator, self.denominator * o.numerator)

    def __rtruediv__(self, other: Any) -> "Fraction":
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return o.__truediv__(self)

    def __pow__(self, power: int) -> "Fraction":
        p = int(power)
        if p == 0:
            return Fraction(1, 1)
        if p < 0:
            return self.reciprocal().__pow__(-p)
        return Fraction(self.numerator**p, self.denominator**p)

    def __int__(self) -> int:
        return int(self.numerator // self.denominator)

    def __float__(self) -> float:
        return self.to_float()

    def __eq__(self, other: Any) -> bool:
        o = self._coerce(other)
        if o is NotImplemented:
            return False
        return (self.numerator, self.denominator) == (o.numerator, o.denominator)

    def __lt__(self, other: Any) -> bool:
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return self.numerator * o.denominator < o.numerator * self.denominator

    def __le__(self, other: Any) -> bool:
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return self.numerator * o.denominator <= o.numerator * self.denominator

    def __gt__(self, other: Any) -> bool:
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return self.numerator * o.denominator > o.numerator * self.denominator

    def __ge__(self, other: Any) -> bool:
        o = self._coerce(other)
        if o is NotImplemented:
            return NotImplemented
        return self.numerator * o.denominator >= o.numerator * self.denominator
