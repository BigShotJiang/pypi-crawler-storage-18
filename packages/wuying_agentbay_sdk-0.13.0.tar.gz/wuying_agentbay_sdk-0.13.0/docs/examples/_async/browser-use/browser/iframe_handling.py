"""
Browser iFrame Handling Example

This example demonstrates:
1. Detecting iframes on a page
2. Switching to iframe context
3. Interacting with iframe content
4. Switching back to main context
"""

import asyncio
import os
import sys
from pydantic import BaseModel, Field

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

from agentbay import AsyncAgentBay, CreateSessionParams
from agentbay import BrowserOption, ActOptions, ExtractOptions


class TextContent(BaseModel):
    """Simple model to extract text content."""
    content: str = Field(description="The extracted text content")


async def main():
    """Demonstrate browser iframe handling."""
    print("=== Browser iFrame Handling Example ===\n")

    # Initialize AgentBay client
    client = AsyncAgentBay()
    session = None

    try:
        # Create a session with browser enabled
        print("Creating session with browser...")
        session_result = await client.create(
            CreateSessionParams(image_id="browser_latest")
        )
        if not session_result.success or not session_result.session:
            raise Exception(f"Failed to create session: {session_result.error_message}")
        session = session_result.session
        print(f"Session created: {session.session_id}")

        # Initialize browser
        print("Initializing browser...")
        if not await session.browser.initialize(BrowserOption()):
            raise Exception("Failed to initialize browser")
        print("Browser initialized")

        # Create a page with iframes
        print("\n1. Creating test page with iframes...")
        await session.browser.agent.navigate("https://example.com")
        
        # Add iframe via JavaScript
        await session.browser.agent.act(ActOptions(
            action="Execute JavaScript to add an iframe: "
            "var iframe = document.createElement('iframe'); "
            "iframe.src = 'https://httpbin.org/html'; "
            "iframe.style.width = '600px'; "
            "iframe.style.height = '400px'; "
            "iframe.style.border = '2px solid blue'; "
            "document.body.appendChild(iframe)"
        ))
        print("iFrame added to page")

        # Take screenshot
        print("\n2. Taking screenshot with iframe...")
        screenshot_path = await session.browser.agent.screenshot()
        print(f"Screenshot saved: {screenshot_path}")

        # Detect iframes
        print("\n3. Detecting iframes on page...")
        success, iframe_result = await session.browser.agent.extract(ExtractOptions(
            instruction="Are there any iframes on this page? How many?",
            schema=TextContent
        ))
        if success:
            print(f"iFrame detection: {iframe_result.content}")
        else:
            print("Failed to detect iframes")

        # Get iframe information
        print("\n4. Getting iframe information...")
        success, iframe_info = await session.browser.agent.extract(ExtractOptions(
            instruction="What is the source URL of the iframe?",
            schema=TextContent
        ))
        if success:
            print(f"iFrame info: {iframe_info.content}")
        else:
            print("Failed to get iframe information")

        # Switch to iframe context
        print("\n5. Switching to iframe context...")
        await session.browser.agent.act(ActOptions(action="Focus on the iframe content"))
        print("Switched to iframe context")

        # Extract content from iframe
        print("\n6. Extracting content from iframe...")
        success, iframe_content = await session.browser.agent.extract(ExtractOptions(
            instruction="What content is displayed inside the iframe?",
            schema=TextContent
        ))
        if success:
            print(f"iFrame content:\n{iframe_content.content}")
        else:
            print("Failed to extract iframe content")

        # Interact with iframe content
        print("\n7. Interacting with iframe content...")
        await session.browser.agent.act(ActOptions(action="Scroll down within the iframe"))
        print("Scrolled within iframe")

        # Switch back to main context
        print("\n8. Switching back to main context...")
        await session.browser.agent.act(ActOptions(action="Switch focus back to the main page"))
        print("Switched back to main context")

        # Verify we're back in main context
        print("\n9. Verifying main context...")
        success, main_content = await session.browser.agent.extract(ExtractOptions(
            instruction="What is the main page title (not the iframe)?",
            schema=TextContent
        ))
        if success:
            print(f"Main page title: {main_content.content}")
        else:
            print("Failed to get main page title")

        # Test nested iframes
        print("\n10. Testing nested iframes...")
        await session.browser.agent.act(ActOptions(
            action="Execute JavaScript to add a nested iframe: "
            "var iframes = document.getElementsByTagName('iframe'); "
            "if (iframes.length > 0) { "
            "  var nestedIframe = document.createElement('iframe'); "
            "  nestedIframe.src = 'https://httpbin.org/robots.txt'; "
            "  nestedIframe.style.width = '400px'; "
            "  nestedIframe.style.height = '200px'; "
            "  document.body.appendChild(nestedIframe); "
            "}"
        ))
        print("Nested iframe added")

        # Count total iframes
        print("\n11. Counting total iframes...")
        success, total_iframes = await session.browser.agent.extract(ExtractOptions(
            instruction="How many iframes are now on the page?",
            schema=TextContent
        ))
        if success:
            print(f"Total iframes: {total_iframes.content}")
        else:
            print("Failed to count iframes")

        print("\n=== Example completed successfully ===")

    except Exception as e:
        print(f"\nError occurred: {str(e)}")
        raise

    finally:
        # Clean up
        if session:
            print("\nCleaning up session...")
            await client.delete(session)
            print("Session closed")


if __name__ == "__main__":
    asyncio.run(main())

