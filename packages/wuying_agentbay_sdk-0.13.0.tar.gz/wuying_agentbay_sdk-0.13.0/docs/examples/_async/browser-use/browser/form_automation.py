"""
Example demonstrating form automation with AgentBay SDK.

This example shows how to:
- Fill out web forms automatically
- Handle different input types (text, checkbox, radio, select)
- Submit forms
- Validate form submissions
- Handle form errors
"""

import asyncio
import os

from agentbay import AsyncAgentBay
from agentbay import CreateSessionParams
from agentbay import BrowserOption

from playwright.async_api import async_playwright


async def fill_simple_form(page):
    """Fill out a simple form with various input types."""
    print("\n📝 Filling out a simple form...")
    
    # Navigate to a form page (example)
    await page.goto("https://www.example.com/form")  # Replace with actual form URL
    
    # Fill text input
    await page.fill('input[name="username"]', "test_user")
    print("✅ Filled username field")
    
    # Fill email input
    await page.fill('input[type="email"]', "test@example.com")
    print("✅ Filled email field")
    
    # Fill password input
    await page.fill('input[type="password"]', "SecurePassword123")
    print("✅ Filled password field")
    
    # Select from dropdown
    await page.select_option('select[name="country"]', "US")
    print("✅ Selected country")
    
    # Check checkbox
    await page.check('input[type="checkbox"][name="terms"]')
    print("✅ Checked terms checkbox")
    
    # Select radio button
    await page.check('input[type="radio"][value="male"]')
    print("✅ Selected radio button")
    
    # Fill textarea
    await page.fill('textarea[name="comments"]', "This is a test comment")
    print("✅ Filled textarea")


async def submit_and_validate_form(page):
    """Submit a form and validate the result."""
    print("\n🚀 Submitting form...")
    
    # Click submit button
    await page.click('button[type="submit"]')
    
    # Wait for navigation or response
    try:
        await page.wait_for_load_state("networkidle", timeout=10000)
        print("✅ Form submitted successfully")
        
        # Check for success message
        success_selector = ".success-message, .alert-success"
        if await page.query_selector(success_selector):
            message = await page.text_content(success_selector)
            print(f"✅ Success message: {message}")
            return True
        
        # Check for error message
        error_selector = ".error-message, .alert-error"
        if await page.query_selector(error_selector):
            message = await page.text_content(error_selector)
            print(f"❌ Error message: {message}")
            return False
            
    except Exception as e:
        print(f"❌ Form submission failed: {e}")
        return False
    
    return True


async def handle_dynamic_form(page):
    """Handle a form with dynamic fields."""
    print("\n🔄 Handling dynamic form...")
    
    # Wait for form to load
    await page.wait_for_selector('form', timeout=10000)
    
    # Get all input fields dynamically
    inputs = await page.query_selector_all('input[type="text"]')
    print(f"Found {len(inputs)} text input fields")
    
    # Fill each field
    for i, input_field in enumerate(inputs):
        field_name = await input_field.get_attribute("name")
        await input_field.fill(f"value_{i}")
        print(f"✅ Filled field '{field_name}'")


async def main():
    """Main function demonstrating form automation."""
    api_key = os.getenv("AGENTBAY_API_KEY")
    if not api_key:
        print("❌ Error: AGENTBAY_API_KEY environment variable not set")
        return
    
    agent_bay = AsyncAgentBay(api_key=api_key)
    session = None
    
    try:
        print("=" * 60)
        print("Form Automation Example")
        print("=" * 60)
        
        # Create browser session
        print("\nCreating browser session...")
        params = CreateSessionParams(image_id="browser_latest")
        result = await agent_bay.create(params)
        
        if not result.success or not result.session:
            print(f"❌ Failed to create session: {result.error_message}")
            return
        
        session = result.session
        print(f"✅ Session created: {session.session_id}")
        
        # Initialize browser
        browser_option = BrowserOption()
        if not await session.browser.initialize(browser_option):
            print("❌ Failed to initialize browser")
            return
        
        print("✅ Browser initialized")
        
        # Get browser endpoint
        endpoint_url = await session.browser.get_endpoint_url()
        
        async with async_playwright() as p:
            browser = await p.chromium.connect_over_cdp(endpoint_url)
            context = browser.contexts[0]
            page = await context.new_page()
            
            # Example 1: Fill simple form
            # Note: Replace with actual form URL for testing
            print("\n" + "=" * 60)
            print("Example 1: Simple Form Filling")
            print("=" * 60)
            print("⚠️  This example requires a real form URL")
            print("Replace the URL in the code with an actual form for testing")
            
            # Example 2: Form with validation
            print("\n" + "=" * 60)
            print("Example 2: Form Validation")
            print("=" * 60)
            print("⚠️  This example demonstrates form validation handling")
            
            # Example 3: Dynamic form handling
            print("\n" + "=" * 60)
            print("Example 3: Dynamic Form Handling")
            print("=" * 60)
            print("⚠️  This example demonstrates handling dynamically generated forms")
            
            await browser.close()
        
        print("\n✅ Form automation examples completed")
        print("\n💡 Tip: Replace example URLs with real forms to test functionality")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        
    finally:
        if session:
            print("\n🧹 Cleaning up session...")
            await agent_bay.delete(session)
            print("✅ Session deleted")


if __name__ == "__main__":
    asyncio.run(main())

