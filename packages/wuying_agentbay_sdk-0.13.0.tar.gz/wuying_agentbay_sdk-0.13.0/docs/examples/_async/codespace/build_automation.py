"""
Build Automation Example

This example demonstrates:
1. Creating Makefiles
2. Automating build processes
3. Managing build dependencies
4. Running automated tests
"""

import asyncio
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from agentbay import AsyncAgentBay
from agentbay import CreateSessionParams


async def main():
    """Demonstrate build automation."""
    print("=== Build Automation Example ===\n")

    # Initialize AgentBay client
    client = AsyncAgentBay()
    session = None

    try:
        # Create a session
        print("Creating session...")
        session_result = await client.create(
            CreateSessionParams(
                image_id="linux_latest"
            )
        )
        session = session_result.session
        print(f"Session created: {session.session_id}")

        # Create project directory
        print("\n1. Creating project directory...")
        await session.command.execute_command("mkdir -p /tmp/myproject/src")
        await session.command.execute_command("mkdir -p /tmp/myproject/tests")
        await session.command.execute_command("mkdir -p /tmp/myproject/build")
        print("Project structure created")

        # Create source files
        print("\n2. Creating source files...")
        main_c = """#include <stdio.h>
#include "utils.h"

int main() {
    printf("Hello from AgentBay Build System!\\n");
    print_version();
    return 0;
}
"""
        await session.file_system.write_file("/tmp/myproject/src/main.c", main_c)

        utils_h = """#ifndef UTILS_H
#define UTILS_H

void print_version();

#endif
"""
        await session.file_system.write_file("/tmp/myproject/src/utils.h", utils_h)

        utils_c = """#include <stdio.h>
#include "utils.h"

void print_version() {
    printf("Version: 1.0.0\\n");
}
"""
        await session.file_system.write_file("/tmp/myproject/src/utils.c", utils_c)
        print("Source files created")

        # Create a Makefile
        print("\n3. Creating Makefile...")
        makefile = """CC = gcc
CFLAGS = -Wall -Wextra -std=c11
SRC_DIR = src
BUILD_DIR = build
TARGET = $(BUILD_DIR)/myapp

SRCS = $(wildcard $(SRC_DIR)/*.c)
OBJS = $(SRCS:$(SRC_DIR)/%.c=$(BUILD_DIR)/%.o)

.PHONY: all clean test run

all: $(TARGET)

$(BUILD_DIR):
\t@mkdir -p $(BUILD_DIR)

$(BUILD_DIR)/%.o: $(SRC_DIR)/%.c | $(BUILD_DIR)
\t@echo "Compiling $<..."
\t$(CC) $(CFLAGS) -c $< -o $@

$(TARGET): $(OBJS)
\t@echo "Linking $(TARGET)..."
\t$(CC) $(CFLAGS) $(OBJS) -o $(TARGET)
\t@echo "Build complete!"

clean:
\t@echo "Cleaning build artifacts..."
\t@rm -rf $(BUILD_DIR)
\t@echo "Clean complete!"

run: $(TARGET)
\t@echo "Running application..."
\t@./$(TARGET)

test:
\t@echo "Running tests..."
\t@echo "All tests passed!"

help:
\t@echo "Available targets:"
\t@echo "  all   - Build the project (default)"
\t@echo "  clean - Remove build artifacts"
\t@echo "  run   - Build and run the application"
\t@echo "  test  - Run tests"
\t@echo "  help  - Show this help message"
"""
        await session.file_system.write_file("/tmp/myproject/Makefile", makefile)
        print("Makefile created")

        # Check if make is available
        print("\n4. Checking make availability...")
        result = await session.command.execute_command("which make")
        print(f"Make location: {result.output}")

        # Check if gcc is available
        print("\n5. Checking gcc availability...")
        result = await session.command.execute_command("gcc --version | head -1")
        print(f"GCC version: {result.output}")

        # Run make to build the project
        print("\n6. Building project with make...")
        result = await session.command.execute_command("cd /tmp/myproject && make")
        print(f"Build output:\n{result.output}")

        # List build artifacts
        print("\n7. Listing build artifacts...")
        result = await session.command.execute_command("ls -lh /tmp/myproject/build/")
        print(f"Build artifacts:\n{result.output}")

        # Run the built application
        print("\n8. Running the built application...")
        result = await session.command.execute_command("cd /tmp/myproject && make run")
        print(f"Application output:\n{result.output}")

        # Run tests
        print("\n9. Running tests...")
        result = await session.command.execute_command("cd /tmp/myproject && make test")
        print(f"Test output:\n{result.output}")

        # Show Makefile help
        print("\n10. Showing Makefile help...")
        result = await session.command.execute_command("cd /tmp/myproject && make help")
        print(f"Help output:\n{result.output}")

        # Create a build script
        print("\n11. Creating build script...")
        build_script = """#!/bin/bash

set -e

echo "=== Build Script ==="
echo ""

echo "Step 1: Cleaning previous build..."
make clean

echo ""
echo "Step 2: Building project..."
make all

echo ""
echo "Step 3: Running tests..."
make test

echo ""
echo "Step 4: Running application..."
make run

echo ""
echo "=== Build Complete ==="
"""
        await session.file_system.write_file("/tmp/myproject/build.sh", build_script)
        await session.command.execute_command("chmod +x /tmp/myproject/build.sh")
        print("Build script created: /tmp/myproject/build.sh")

        # Clean the build
        print("\n12. Cleaning build...")
        result = await session.command.execute_command("cd /tmp/myproject && make clean")
        print(f"Clean output:\n{result.output}")

        # Verify clean
        print("\n13. Verifying clean...")
        result = await session.command.execute_command("if [ -d /tmp/myproject/build ]; then ls -la /tmp/myproject/build/; else echo 'Build directory successfully removed'; fi")
        print(f"Build directory after clean:\n{result.output}")

        # Rebuild
        print("\n14. Rebuilding project...")
        result = await session.command.execute_command("cd /tmp/myproject && make all")
        print(f"Rebuild output:\n{result.output}")

        # Create a CI/CD configuration example
        print("\n15. Creating CI/CD configuration example...")
        ci_config = """# Example CI/CD Configuration (.gitlab-ci.yml or similar)

stages:
  - build
  - test
  - deploy

build:
  stage: build
  script:
    - make clean
    - make all
  artifacts:
    paths:
      - build/

test:
  stage: test
  script:
    - make test
  dependencies:
    - build

deploy:
  stage: deploy
  script:
    - echo "Deploying application..."
    - cp build/myapp /usr/local/bin/
  only:
    - main
"""
        await session.file_system.write_file("/tmp/myproject/.gitlab-ci.yml", ci_config)
        print("CI/CD configuration created")

        print("\n=== Example completed successfully ===")

    except Exception as e:
        print(f"\nError occurred: {str(e)}")
        raise

    finally:
        # Clean up
        if session:
            print("\nCleaning up session...")
            await client.delete(session)
            print("Session closed")


if __name__ == "__main__":
    asyncio.run(main())

