#!/usr/bin/env python3
"""
AgentBay SDK - Context List and Update Management Example

This example demonstrates basic context management operations:
- Listing contexts with pagination support
- Creating multiple contexts for testing
- Updating context names and properties
- Searching and filtering contexts
- Batch context management operations

Expected Output:
    ======================================================================
    Context List and Update Management Examples
    ======================================================================
    
    Example 1: Basic Context Listing
    ======================================================================
    📋 Listing all contexts (first page)...
    ✅ Found 5 contexts (Total: 12)
     1. my-context-1 (SdkCtx-xxxxx) - Created: 2024-11-29T10:30:00Z
     2. my-context-2 (SdkCtx-xxxxx) - Created: 2024-11-29T10:31:00Z
     3. data-backup (SdkCtx-xxxxx) - Created: 2024-11-29T09:15:00Z
    Has more results available
    
    Example 2: Pagination Demo
    ======================================================================
    📋 Getting next page of results...
    ✅ Found 3 contexts (remaining)
     4. temp-workspace (SdkCtx-xxxxx) - Created: 2024-11-29T08:45:00Z
     5. project-files (SdkCtx-xxxxx) - Created: 2024-11-29T08:00:00Z
    ✅ All contexts listed successfully
    
    Example 3: Context Creation and Management
    ======================================================================
    📦 Creating test contexts...
    ✅ Created context: test-context-1 (SdkCtx-xxxxx)
    ✅ Created context: test-context-2 (SdkCtx-xxxxx)
    ✅ Created context: test-context-3 (SdkCtx-xxxxx)
    
    Example 4: Context Update Operations
    ======================================================================
    📝 Updating context names...
    ✅ Renamed 'test-context-1' → 'updated-context-1'
    ✅ Renamed 'test-context-2' → 'updated-context-2'
    ✅ Context updates completed successfully
    
    Example 5: Context Search and Filter
    ======================================================================
    🔍 Searching for contexts with 'updated' in name...
    ✅ Found 2 matching contexts:
     - updated-context-1 (SdkCtx-xxxxx)
     - updated-context-2 (SdkCtx-xxxxx)
    
    Example 6: Batch Operations and Cleanup
    ======================================================================
    🧹 Cleaning up test contexts...
    ✅ Deleted context: updated-context-1
    ✅ Deleted context: updated-context-2
    ✅ Deleted context: test-context-3
    ✅ Cleanup completed successfully
    
    ======================================================================
    ✅ All context management examples completed successfully!
    ======================================================================
"""

import asyncio
import time
from typing import List, Optional
from agentbay import AsyncAgentBay, ContextListParams


async def example_1_basic_context_listing(agent_bay: AsyncAgentBay):
    """Example 1: Basic context listing with default parameters"""
    print("\n" + "="*70)
    print("Example 1: Basic Context Listing")
    print("="*70)
    
    print("📋 Listing all contexts (first page)...")
    
    # List contexts with default parameters (max 10 results)
    result = await agent_bay.context.list()
    
    if result.success:
        print(f"✅ Found {len(result.contexts)} contexts", end="")
        if result.total_count:
            print(f" (Total: {result.total_count})")
        else:
            print()
            
        for i, ctx in enumerate(result.contexts, 1):
            created_time = ctx.created_at or "Unknown"
            print(f" {i}. {ctx.name} ({ctx.id}) - Created: {created_time}")
        
        if result.next_token:
            print("📄 Has more results available")
            return result.next_token
        else:
            print("📄 All contexts displayed")
            return None
    else:
        print(f"❌ Failed to list contexts: {result.error_message}")
        return None


async def example_2_pagination_demo(agent_bay: AsyncAgentBay, next_token: Optional[str]):
    """Example 2: Demonstrate pagination functionality"""
    print("\n" + "="*70)
    print("Example 2: Pagination Demo")
    print("="*70)
    
    if not next_token:
        print("ℹ️  No more pages to display")
        return
    
    print("📋 Getting next page of results...")
    
    # Get next page using pagination token
    params = ContextListParams(max_results=5, next_token=next_token)
    result = await agent_bay.context.list(params)
    
    if result.success:
        print(f"✅ Found {len(result.contexts)} contexts (page 2)")
        
        for i, ctx in enumerate(result.contexts, 1):
            created_time = ctx.created_at or "Unknown"
            print(f" {i}. {ctx.name} ({ctx.id}) - Created: {created_time}")
        
        if result.next_token:
            print("📄 More pages available")
        else:
            print("📄 Reached end of results")
    else:
        print(f"❌ Failed to get next page: {result.error_message}")


async def example_3_context_creation(agent_bay: AsyncAgentBay):
    """Example 3: Create multiple test contexts"""
    print("\n" + "="*70)
    print("Example 3: Context Creation and Management")
    print("="*70)
    
    print("📦 Creating test contexts...")
    
    # Create test contexts with timestamp to ensure uniqueness
    timestamp = int(time.time())
    context_names = [
        f"test-context-1-{timestamp}",
        f"test-context-2-{timestamp}",
        f"test-context-3-{timestamp}"
    ]
    
    created_contexts = []
    
    for name in context_names:
        result = await agent_bay.context.create(name)
        if result.success:
            print(f"✅ Created context: {name} ({result.context.id})")
            created_contexts.append(result.context)
        else:
            print(f"❌ Failed to create context {name}: {result.error_message}")
    
    print(f"📊 Successfully created {len(created_contexts)}/{len(context_names)} contexts")
    return created_contexts


async def example_4_context_update(agent_bay: AsyncAgentBay, contexts: List):
    """Example 4: Update context names and properties"""
    print("\n" + "="*70)
    print("Example 4: Context Update Operations")
    print("="*70)
    
    if not contexts:
        print("⚠️  No contexts available for update")
        return contexts
    
    print("📝 Updating context names...")
    
    updated_contexts = []
    
    for i, context in enumerate(contexts[:2]):  # Update first 2 contexts
        old_name = context.name
        new_name = context.name.replace("test-context", "updated-context")
        
        # Update the context object
        context.name = new_name
        
        # Call update API
        result = await agent_bay.context.update(context)
        
        if result.success:
            print(f"✅ Renamed '{old_name}' → '{new_name}'")
            updated_contexts.append(context)
        else:
            print(f"❌ Failed to rename '{old_name}': {result.error_message}")
            # Revert the name change
            context.name = old_name
            updated_contexts.append(context)
    
    # Add remaining contexts unchanged
    updated_contexts.extend(contexts[2:])
    
    print("✅ Context updates completed")
    return updated_contexts


async def example_5_context_search(agent_bay: AsyncAgentBay):
    """Example 5: Search and filter contexts"""
    print("\n" + "="*70)
    print("Example 5: Context Search and Filter")
    print("="*70)
    
    print("🔍 Searching for contexts with 'updated' in name...")
    
    # List all contexts and filter locally
    # Note: The API doesn't support server-side filtering, so we filter client-side
    result = await agent_bay.context.list(ContextListParams(max_results=50))
    
    if result.success:
        matching_contexts = [ctx for ctx in result.contexts if "updated" in ctx.name.lower()]
        
        print(f"✅ Found {len(matching_contexts)} matching contexts:")
        for ctx in matching_contexts:
            print(f" - {ctx.name} ({ctx.id})")
        
        if not matching_contexts:
            print("ℹ️  No contexts found with 'updated' in name")
        
        return matching_contexts
    else:
        print(f"❌ Failed to search contexts: {result.error_message}")
        return []


async def example_6_batch_cleanup(agent_bay: AsyncAgentBay, contexts: List):
    """Example 6: Batch delete test contexts"""
    print("\n" + "="*70)
    print("Example 6: Batch Operations and Cleanup")
    print("="*70)
    
    if not contexts:
        print("ℹ️  No contexts to clean up")
        return
    
    print("🧹 Cleaning up test contexts...")
    
    deleted_count = 0
    
    for context in contexts:
        try:
            result = await agent_bay.context.delete(context)
            if result.success:
                print(f"✅ Deleted context: {context.name}")
                deleted_count += 1
            else:
                print(f"❌ Failed to delete {context.name}: {result.error_message}")
        except Exception as e:
            print(f"❌ Error deleting {context.name}: {e}")
    
    print(f"📊 Cleanup completed: {deleted_count}/{len(contexts)} contexts deleted")


async def example_7_error_handling(agent_bay: AsyncAgentBay):
    """Example 7: Error handling and edge cases"""
    print("\n" + "="*70)
    print("Example 7: Error Handling and Edge Cases")
    print("="*70)
    
    print("🧪 Testing error scenarios...")
    
    # Test 1: Invalid pagination token
    print("\n❌ Test 1: Invalid pagination token")
    try:
        params = ContextListParams(next_token="invalid-token-12345")
        result = await agent_bay.context.list(params)
        if not result.success:
            print(f"   ✅ Correctly handled invalid token: {result.error_message[:50]}...")
        else:
            print("   ⚠️  Invalid token was accepted (unexpected)")
    except Exception as e:
        print(f"   ✅ Exception caught for invalid token: {str(e)[:50]}...")
    
    # Test 2: Extremely large max_results
    print("\n❌ Test 2: Large max_results value")
    try:
        params = ContextListParams(max_results=10000)
        result = await agent_bay.context.list(params)
        if result.success:
            print(f"   ✅ Large max_results handled, returned {len(result.contexts)} contexts")
        else:
            print(f"   ✅ Large max_results rejected: {result.error_message[:50]}...")
    except Exception as e:
        print(f"   ✅ Exception for large max_results: {str(e)[:50]}...")
    
    # Test 3: Update non-existent context
    print("\n❌ Test 3: Update non-existent context")
    try:
        from agentbay import Context
        fake_context = Context(id="non-existent-id", name="fake-context")
        result = await agent_bay.context.update(fake_context)
        if not result.success:
            print(f"   ✅ Non-existent context update rejected: {result.error_message[:50]}...")
        else:
            print("   ⚠️  Non-existent context update succeeded (unexpected)")
    except Exception as e:
        print(f"   ✅ Exception for non-existent context: {str(e)[:50]}...")
    
    print("\n✅ Error handling tests completed")


async def main():
    """Main function demonstrating all context management operations"""
    print("\n" + "="*70)
    print("Context List and Update Management Examples")
    print("="*70)
    print("\nThese examples demonstrate comprehensive context management:")
    print("- Basic listing and pagination")
    print("- Context creation and updates")
    print("- Search and filtering")
    print("- Batch operations and cleanup")
    print("- Error handling")
    
    # Initialize AgentBay client
    agent_bay = AsyncAgentBay()
    
    try:
        # Example 1: Basic listing
        next_token = await example_1_basic_context_listing(agent_bay)
        
        # Example 2: Pagination
        await example_2_pagination_demo(agent_bay, next_token)
        
        # Example 3: Context creation
        created_contexts = await example_3_context_creation(agent_bay)
        
        # Example 4: Context updates
        updated_contexts = await example_4_context_update(agent_bay, created_contexts)
        
        # Example 5: Search and filter
        await example_5_context_search(agent_bay)
        
        # Example 6: Cleanup
        await example_6_batch_cleanup(agent_bay, updated_contexts)
        
        # Example 7: Error handling
        await example_7_error_handling(agent_bay)
        
        print("\n" + "="*70)
        print("✅ All context management examples completed successfully!")
        print("="*70)
        
    except Exception as e:
        print(f"\n❌ Example execution failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())