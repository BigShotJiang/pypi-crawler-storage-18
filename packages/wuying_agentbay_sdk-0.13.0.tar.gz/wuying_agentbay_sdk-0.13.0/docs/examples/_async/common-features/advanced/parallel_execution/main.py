"""
Example demonstrating parallel execution with AgentBay SDK.

This example shows how to:
- Execute multiple tasks in parallel
- Use asyncio.gather for concurrent operations
- Handle parallel file operations
- Execute commands concurrently
- Aggregate results from parallel tasks
"""

import asyncio
import os
import time
from typing import List, Dict, Any

from agentbay import AsyncAgentBay
from agentbay import CreateSessionParams


async def parallel_command_execution(session, commands: List[str]) -> List[Dict[str, Any]]:
    """Execute multiple commands in parallel."""
    print(f"\n⚡ Executing {len(commands)} commands in parallel...")
    
    start_time = time.time()
    
    async def execute_single_command(cmd, index):
        result = await session.command.execute_command(cmd)
        return {
            "index": index,
            "command": cmd,
            "success": result.success,
            "output": result.output.strip() if result.success else result.error_message
        }
    
    tasks = [execute_single_command(cmd, i) for i, cmd in enumerate(commands)]
    results = await asyncio.gather(*tasks)
    
    elapsed_time = time.time() - start_time
    
    print(f"✅ Completed in {elapsed_time:.2f} seconds")
    
    for result in results:
        status = "✅" if result["success"] else "❌"
        print(f"  {status} Command {result['index']}: {result['command'][:30]}... -> {result['output'][:50]}")
    
    return results


async def parallel_file_operations(session, file_count: int) -> List[Dict[str, Any]]:
    """Perform multiple file operations in parallel."""
    print(f"\n📁 Performing {file_count} file operations in parallel...")
    
    start_time = time.time()
    
    async def write_and_read_file(index):
        file_path = f"/tmp/parallel_test_{index}.txt"
        content = f"This is test file number {index}"
        
        # Write file
        write_result = await session.file_system.write_file(file_path, content)
        if not write_result.success:
            return {"index": index, "success": False, "error": write_result.error_message}
        
        # Read file
        read_result = await session.file_system.read_file(file_path)
        if not read_result.success:
            return {"index": index, "success": False, "error": read_result.error_message}
        
        # Verify content
        matches = read_result.content == content
        return {
            "index": index,
            "success": True,
            "content_matches": matches
        }
    
    tasks = [write_and_read_file(i) for i in range(file_count)]
    results = await asyncio.gather(*tasks)
    
    elapsed_time = time.time() - start_time
    
    successful = sum(1 for r in results if r.get("success") and r.get("content_matches"))
    print(f"✅ Completed {successful}/{file_count} operations in {elapsed_time:.2f} seconds")
    
    return results


async def parallel_data_processing(session, data_items: List[str]) -> List[Dict[str, Any]]:
    """Process multiple data items in parallel."""
    print(f"\n🔄 Processing {len(data_items)} data items in parallel...")
    
    start_time = time.time()
    
    async def process_single_item(item, index):
        # Simulate processing by writing to a file and reading it back
        file_path = f"/tmp/data_item_{index}.txt"
        
        write_result = await session.file_system.write_file(file_path, item)
        if not write_result.success:
            return {"index": index, "success": False}
        
        # Simulate some processing time
        await asyncio.sleep(0.1)
        
        read_result = await session.file_system.read_file(file_path)
        return {
            "index": index,
            "success": read_result.success,
            "processed_data": read_result.content if read_result.success else None
        }
    
    tasks = [process_single_item(item, i) for i, item in enumerate(data_items)]
    results = await asyncio.gather(*tasks)
    
    elapsed_time = time.time() - start_time
    
    successful = sum(1 for r in results if r.get("success"))
    print(f"✅ Processed {successful}/{len(data_items)} items in {elapsed_time:.2f} seconds")
    
    return results


async def compare_sequential_vs_parallel(session):
    """Compare sequential vs parallel execution performance."""
    print("\n📊 Comparing Sequential vs Parallel Execution...")
    
    commands = [
        "sleep 1 && echo 'Task 1'",
        "sleep 1 && echo 'Task 2'",
        "sleep 1 && echo 'Task 3'",
    ]
    
    # Sequential execution
    print("\n  Running sequentially...")
    start_time = time.time()
    for cmd in commands:
        await session.command.execute_command(cmd)
    sequential_time = time.time() - start_time
    print(f"  Sequential time: {sequential_time:.2f} seconds")
    
    # Parallel execution
    print("\n  Running in parallel...")
    start_time = time.time()
    tasks = [session.command.execute_command(cmd) for cmd in commands]
    await asyncio.gather(*tasks)
    parallel_time = time.time() - start_time
    print(f"  Parallel time: {parallel_time:.2f} seconds")
    
    speedup = sequential_time / parallel_time
    print(f"\n  ⚡ Speedup: {speedup:.2f}x faster with parallel execution")


async def main():
    """Main function demonstrating parallel execution."""
    api_key = os.getenv("AGENTBAY_API_KEY")
    if not api_key:
        print("❌ Error: AGENTBAY_API_KEY environment variable not set")
        return
    
    agent_bay = AsyncAgentBay(api_key=api_key)
    session = None
    
    try:
        print("=" * 60)
        print("Parallel Execution Example")
        print("=" * 60)
        
        # Create session
        print("\nCreating session...")
        params = CreateSessionParams(image_id="linux_latest")
        result = await agent_bay.create(params)
        
        if not result.success or not result.session:
            print(f"❌ Failed to create session: {result.error_message}")
            return
        
        session = result.session
        print(f"✅ Session created: {session.session_id}")
        
        # Example 1: Parallel command execution
        print("\n" + "=" * 60)
        print("Example 1: Parallel Command Execution")
        print("=" * 60)
        
        commands = [
            "hostname",
            "whoami",
            "pwd",
            "date",
            "uname -a"
        ]
        
        await parallel_command_execution(session, commands)
        
        # Example 2: Parallel file operations
        print("\n" + "=" * 60)
        print("Example 2: Parallel File Operations")
        print("=" * 60)
        
        await parallel_file_operations(session, file_count=5)
        
        # Example 3: Parallel data processing
        print("\n" + "=" * 60)
        print("Example 3: Parallel Data Processing")
        print("=" * 60)
        
        data_items = [f"Data item {i}" for i in range(10)]
        await parallel_data_processing(session, data_items)
        
        # Example 4: Sequential vs Parallel comparison
        print("\n" + "=" * 60)
        print("Example 4: Sequential vs Parallel Comparison")
        print("=" * 60)
        
        await compare_sequential_vs_parallel(session)
        
        print("\n✅ Parallel execution examples completed")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        
    finally:
        if session:
            print("\n🧹 Cleaning up session...")
            await agent_bay.delete(session)
            print("✅ Session deleted")


if __name__ == "__main__":
    asyncio.run(main())

