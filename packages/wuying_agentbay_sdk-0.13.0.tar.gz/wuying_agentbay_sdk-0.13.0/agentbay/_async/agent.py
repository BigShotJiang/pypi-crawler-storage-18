import asyncio
import json

from .._common.exceptions import AgentBayError, AgentError
from .._common.logger import get_logger
from .._common.models.agent import (
    ExecutionResult,
    QueryResult,
    InitializationResult,
    AgentOptions,
)
from .base_service import AsyncBaseService

# Initialize logger for this module
_logger = get_logger("agent")


class AsyncAgent(AsyncBaseService):
    """
    An Agent to manipulate applications to complete specific tasks.
    """

    def __init__(self, session):
        self.session = session
        self.browser = self.Browser(session)
        self.computer = self.Computer(session)

    def _handle_error(self, e):
        """
        Convert AgentBayError to AgentError for compatibility.

        Args:
            e (Exception): The exception to convert.

        Returns:
            AgentError: The converted exception.
        """
        if isinstance(e, AgentError):
            return e
        if isinstance(e, AgentBayError):
            return AgentError(str(e))
        return e

    class Computer:
        """
        An Agent to perform tasks on the computer.
        """

        def __init__(self, session):
            self.session = session

        async def execute_task(self, task: str) -> ExecutionResult:
            """
            Execute a task in human language without waiting for completion (non-blocking).

            This is a fire-and-return interface that immediately provides a task ID.
            Call get_task_status to check the task status. You can control the timeout
            of the task execution in your own code by setting the frequency of calling
            get_task_status and the max_try_times.

            Args:
                task: Task description in human language.

            Returns:
                ExecutionResult: Result object containing success status, task ID,
                    task status, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.computer.execute_task("Open Chrome browser")
                print(f"Task ID: {result.task_id}, Status: {result.task_status}")
                status = await session.agent.computer.get_task_status(result.task_id)
                print(f"Task status: {status.task_status}")
                await session.delete()
                ```
            """
            try:
                args = {"task": task}
                result = await self.session.call_mcp_tool("flux_execute_task", args)
                if result.success:
                    content = json.loads(result.data)
                    task_id = content.get("task_id", "")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=True,
                        error_message="",
                        task_id=task_id,
                        task_status="running",
                    )
                else:
                    _logger.error("task execute failed")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message or "Failed to execute task",
                        task_status="failed",
                        task_id="",
                    )
            except AgentError as e:
                return ExecutionResult(
                    request_id="", success=False, error_message=str(e)
                )
            except Exception as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to execute: {e}",
                    task_status="failed",
                    task_id="",
                )

        async def execute_task_and_wait(
            self, task: str, max_try_times: int
        ) -> ExecutionResult:
            """
            Execute a specific task described in human language synchronously.

            This is a synchronous interface that blocks until the task is completed or
            an error occurs, or timeout happens. The default polling interval is 3 seconds,
            so set a proper max_try_times according to your task complexity.

            Args:
                task: Task description in human language.
                max_try_times: Maximum number of retries.

            Returns:
                ExecutionResult: Result object containing success status, task ID,
                    task status, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.computer.execute_task_and_wait("Open Chrome browser", max_try_times=20)
                print(f"Task result: {result.task_result}")
                await session.delete()
                ```
            """
            try:
                args = {"task": task}
                result = await self.session.call_mcp_tool("flux_execute_task", args)
                if result.success:
                    content = json.loads(result.data)
                    task_id = content.get("task_id", "")
                    tried_time: int = 0
                    while tried_time < max_try_times:
                        query = await self.get_task_status(task_id)
                        if query.task_status == "finished":
                            return ExecutionResult(
                                request_id=result.request_id,
                                success=True,
                                error_message="",
                                task_id=task_id,
                                task_status=query.task_status,
                                task_result=query.task_product,
                            )
                        elif query.task_status == "failed":
                            return ExecutionResult(
                                request_id=result.request_id,
                                success=False,
                                error_message="Failed to execute task.",
                                task_id=task_id,
                                task_status=query.task_status,
                            )
                        elif query.task_status == "unsupported":
                            return ExecutionResult(
                                request_id=result.request_id,
                                success=False,
                                error_message="Unsuppported task.",
                                task_id=task_id,
                                task_status=query.task_status,
                            )
                        _logger.info(
                            f"⏳ Task {task_id} running 🚀: {query.task_action}."
                        )
                        # keep waiting unit timeout if the status is running
                        # task_status {running, finished, failed, unsupported}
                        await asyncio.sleep(3)
                        tried_time += 1
                    _logger.warning("⚠️ task execution timeout!")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message="Task timeout.",
                        task_id=task_id,
                        task_status="failed",
                        task_result="Task timeout.",
                    )
                else:
                    _logger.error("❌ Task execution failed")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message or "Failed to execute task",
                        task_status="failed",
                        task_id="",
                        task_result="Task Failed",
                    )
            except AgentError as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=str(e),
                    task_status="failed",
                    task_id="",
                    task_result="Task Failed",
                )
            except Exception as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to execute: {e}",
                    task_status="failed",
                    task_id="",
                    task_result="Task Failed",
                )

        async def get_task_status(self, task_id: str) -> QueryResult:
            """
            Get the status of the task with the given task ID.

            Args:
                task_id: The ID of the task to query.

            Returns:
                QueryResult: Result object containing success status, task status,
                    task action, task product, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.computer.execute_task("Query the weather in Shanghai with Baidu")
                status = await session.agent.computer.get_task_status(result.task_id)
                print(f"Status: {status.task_status}, Action: {status.task_action}")
                await session.delete()
                ```
            """
            try:
                args = {"task_id": task_id}
                result = await self.session.call_mcp_tool("flux_get_task_status", args)
                if result.success:
                    content = json.loads(result.data)
                    return QueryResult(
                        success=True,
                        request_id=result.request_id,
                        error_message="",
                        task_id=content.get("task_id", task_id),
                        task_status=content.get("status", "finised"),
                        task_action=content.get("action", ""),
                        task_product=content.get("product", ""),
                    )
                else:
                    return QueryResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message
                        or "Failed to terminate task",
                        task_id=task_id,
                        task_status="failed",
                    )
            except AgentError as e:
                return QueryResult(
                    request_id="",
                    success=False,
                    error_message=str(e),
                    task_id=task_id,
                    task_status="failed",
                )
            except Exception as e:
                return QueryResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to get task status: {e}",
                    task_id=task_id,
                    task_status="failed",
                )

        async def terminate_task(self, task_id: str) -> ExecutionResult:
            """
            Terminate a task with a specified task ID.

            Args:
                task_id: The ID of the running task to terminate.

            Returns:
                ExecutionResult: Result object containing success status, task ID,
                    task status, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.computer.execute_task("Query the weather in Shanghai with Baidu")
                terminate_result = await session.agent.computer.terminate_task(result.task_id)
                print(f"Terminated: {terminate_result.success}")
                await session.delete()
                ```
            """
            _logger.info("Terminating task")
            try:
                args = {"task_id": task_id}

                result = await self.session.call_mcp_tool("flux_terminate_task", args)
                if result.success:
                    content = json.loads(result.data)
                    task_id = content.get("task_id", task_id)
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=True,
                        error_message="",
                        task_id=task_id,
                        task_status=content.get("status", "finished"),
                    )
                else:
                    content = json.loads(result.data)
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message
                        or "Failed to terminate task",
                        task_id=task_id,
                        task_status="failed",
                    )
            except AgentError as e:
                return ExecutionResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=str(e),
                    task_id=task_id,
                    task_status="failed",
                )
            except Exception as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to terminate: {e}",
                    task_id=task_id,
                    task_status="failed",
                )

    class Browser:
        """
        An Agent(⚠️ Still in BETA) to perform tasks on the browser
        """

        def __init__(self, session):
            self.session = session

        async def initialize(
            self, options: AgentOptions = None
        ) -> InitializationResult:
            """
            Initialize the browser agent with options.

            Args:
                options: options for the agent.

            Returns:
                InitializationResult: Result object containing success status, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                options:AgentOptions = AgentOptions(use_vision=False, output_schema="")
                initialize_result = await session.agent.browser.initialize(options)
                print(f"Initialized: {initialize_result.success}")
                await session.delete()
                ```
            """
            _logger.info("Initialize Browser Use Agent...")
            try:
                args = {"use_vision": False, "output_schema": {}}
                if options is not None:
                    args = {
                        "use_vision": options.use_vision,
                        "output_schema": options.output_schema,
                    }

                result = await self.session.call_mcp_tool(
                    "browser_use_initialize", args
                )
                if result.success:
                    return InitializationResult(
                        request_id=result.request_id, success=True, error_message=""
                    )
                else:
                    return InitializationResult(
                        request_id=result.request_id,
                        success=False,
                        error_message="Failed to initialize browser use agent",
                    )
            except AgentError as e:
                _logger.error(f"Failed to initialize: {e}")
                return InitializationResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=str(e),
                )
            except Exception as e:
                _logger.error(f"Failed to initialize: {e}")
                return InitializationResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to initialize: {e}",
                )

        async def execute_task(self, task: str) -> ExecutionResult:
            """
            Execute a browser task in human language without waiting for completion (non-blocking).

            This is a fire-and-return interface that immediately provides a task ID.
            Call get_task_status to check the task status. You can control the timeout
            of the task execution in your own code by setting the frequency of calling
            get_task_status and the max_try_times.

            Args:
                task: Task description in human language.

            Returns:
                ExecutionResult: Result object containing success status, task ID,
                    task status, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.browser.execute_task("Query the weather in Shanghai with Baidu")
                print(f"Task ID: {result.task_id}, Status: {result.task_status}")
                status = await session.agent.browser.get_task_status(result.task_id)
                print(f"Task status: {status.task_status}")
                await session.delete()
                ```
            """
            try:
                args = {"task": task}
                result = await self.session.call_mcp_tool(
                    "browser_use_execute_task", args
                )
                if result.success:
                    content = json.loads(result.data)
                    task_id = content.get("task_id", "")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=True,
                        error_message="",
                        task_id=task_id,
                        task_status="running",
                    )
                else:
                    _logger.error("task execute failed")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message or "Failed to execute task",
                        task_status="failed",
                        task_id="",
                    )
            except AgentError as e:
                return ExecutionResult(
                    request_id="", success=False, error_message=str(e)
                )
            except Exception as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to execute: {e}",
                    task_status="failed",
                    task_id="",
                )

        async def execute_task_and_wait(self, task: str, max_try_times: int) -> ExecutionResult:
            """
            Execute a specific task described in human language synchronously.

            This is a synchronous interface that blocks until the task is completed or
            an error occurs, or timeout happens. The default polling interval is 3 seconds,
            so set a proper max_try_times according to your task complexity.

            Args:
                task: Task description in human language.
                max_try_times: Maximum number of retries.

            Returns:
                ExecutionResult: Result object containing success status, task ID,
                    task status, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.browser.execute_task_and_wait("Query the weather in Shanghai with Baidu", max_try_times=20)
                print(f"Task result: {result.task_result}")
                await session.delete()
                ```
            """
            try:
                args = {"task": task}
                result = await self.session.call_mcp_tool(
                    "browser_use_execute_task", args
                )
                if result.success:
                    content = json.loads(result.data)
                    task_id = content.get("task_id", "")
                    tried_time: int = 0
                    while tried_time < max_try_times:
                        query = await self.get_task_status(task_id)
                        if query.task_status == "finished":
                            return ExecutionResult(
                                request_id=result.request_id,
                                success=True,
                                error_message="",
                                task_id=task_id,
                                task_status=query.task_status,
                                task_result=query.task_product,
                            )
                        elif query.task_status == "failed":
                            return ExecutionResult(
                                request_id=result.request_id,
                                success=False,
                                error_message="Failed to execute task.",
                                task_id=task_id,
                                task_status=query.task_status,
                            )
                        elif query.task_status == "unsupported":
                            return ExecutionResult(
                                request_id=result.request_id,
                                success=False,
                                error_message="Unsuppported task.",
                                task_id=task_id,
                                task_status=query.task_status,
                            )
                        _logger.info(
                            f"⏳ Task {task_id} running 🚀: {query.task_action}."
                        )
                        # keep waiting unit timeout if the status is running
                        # task_status {running, finished, failed, unsupported}
                        await asyncio.sleep(3)
                        tried_time += 1
                    _logger.warning("⚠️ task execution timeout!")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message="Task timeout.",
                        task_id=task_id,
                        task_status="failed",
                        task_result="Task timeout.",
                    )
                else:
                    _logger.error("❌ Task execution failed")
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message or "Failed to execute task",
                        task_status="failed",
                        task_id="",
                        task_result="Task Failed",
                    )
            except AgentError as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=str(e),
                    task_status="failed",
                    task_id="",
                    task_result="Task Failed",
                )
            except Exception as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to execute: {e}",
                    task_status="failed",
                    task_id="",
                    task_result="Task Failed",
                )

        async def get_task_status(self, task_id: str) -> QueryResult:
            """
            Get the status of the task with the given task ID.

            Args:
                task_id: The ID of the task to query.

            Returns:
                QueryResult: Result object containing success status, task status,
                    task action, task product, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.browser.execute_task("Open Chrome browser")
                status = await session.agent.browser.get_task_status(result.task_id)
                print(f"Status: {status.task_status}, Action: {status.task_action}")
                await session.delete()
                ```
            """
            try:
                args = {"task_id": task_id}
                result = await self.session.call_mcp_tool(
                    "browser_use_get_task_status", args
                )
                if result.success:
                    content = json.loads(result.data)
                    return QueryResult(
                        success=True,
                        request_id=result.request_id,
                        error_message="",
                        task_id=content.get("task_id", task_id),
                        task_status=content.get("status", "finised"),
                        task_action=content.get("action", ""),
                        task_product=content.get("product", ""),
                    )
                else:
                    return QueryResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message
                        or "Failed to terminate task",
                        task_id=task_id,
                        task_status="failed",
                    )
            except AgentError as e:
                return QueryResult(
                    request_id="",
                    success=False,
                    error_message=str(e),
                    task_id=task_id,
                    task_status="failed",
                )
            except Exception as e:
                return QueryResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to get task status: {e}",
                    task_id=task_id,
                    task_status="failed",
                )

        async def terminate_task(self, task_id: str) -> ExecutionResult:
            """
            Terminate a task with a specified task ID.

            Args:
                task_id: The ID of the running task to terminate.

            Returns:
                ExecutionResult: Result object containing success status, task ID,
                    task status, and error message if any.

            Example:
                ```python
                session_result = await agent_bay.create()
                session = session_result.session
                result = await session.agent.browser.execute_task("Open Chrome browser")
                terminate_result = await session.agent.browser.terminate_task(result.task_id)
                print(f"Terminated: {terminate_result.success}")
                await session.delete()
                ```
            """
            _logger.info("Terminating task")
            try:
                args = {"task_id": task_id}

                result = await self.session.call_mcp_tool(
                    "browser_use_terminate_task", args
                )
                if result.success:
                    content = json.loads(result.data)
                    task_id = content.get("task_id", task_id)
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=True,
                        error_message="",
                        task_id=task_id,
                        task_status=content.get("status", "finished"),
                    )
                else:
                    content = json.loads(result.data)
                    return ExecutionResult(
                        request_id=result.request_id,
                        success=False,
                        error_message=result.error_message
                        or "Failed to terminate task",
                        task_id=task_id,
                        task_status="failed",
                    )
            except AgentError as e:
                return ExecutionResult(
                    request_id=result.request_id,
                    success=False,
                    error_message=str(e),
                    task_id=task_id,
                    task_status="failed",
                )
            except Exception as e:
                return ExecutionResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to terminate: {e}",
                    task_id=task_id,
                    task_status="failed",
                )
