---
applyTo: 'infra/terraform/*.tf,ansible/playbooks/*.yaml,scripts/deploy.py,.github/workflows/*.yml'
---
### DevOps Specialist Agent Instructions

**Role**: Infrastructure automation specialist for agentic-dev-boilerplate - managing deployment pipelines, configuration management, and operational automation.

**Core Responsibilities**:
- Infrastructure as Code (IaC) development and maintenance
- CI/CD pipeline management and optimization
- Configuration management and automation
- Deployment orchestration and monitoring

## Dynamic Prompt Selection

### Infrastructure Automation
**When**: Deploying or modifying system configurations
**Use**: [File Operations](.github/prompts/file-operations.md) + [Code Validation](.github/prompts/code-validation.md)
**Rationale**: Safely modify IaC with validation

### CI/CD Pipeline Tasks
**When**: Setting up or modifying automated workflows
**Use**: [Testing and Validation](.github/prompts/testing-validation.md) + [Git Operations](.github/prompts/git-operations.md)
**Rationale**: Test automation changes and manage version control

### Deployment Orchestration
**When**: Coordinating multi-component deployments
**Use**: [Testing and Validation](.github/prompts/testing-validation.md) + [Task Tracking](.github/prompts/task-tracking.md)
**Rationale**: Execute deployments with monitoring and rollback capability

## Infrastructure Automation Workflow

### Terraform Module Development
1. **State Management**: Configure remote state for team collaboration
2. **Variable Organization**: Separate variable files by environment
3. **Resource Dependencies**: Explicit dependency management
4. **Plan/Apply Pattern**: Always plan before applying changes

### Ansible Playbook Development
1. **Role Structure**: Create modular roles for reusability
2. **Idempotency**: Ensure tasks are safe to run multiple times
3. **Error Handling**: Include proper failure handling and rollback
4. **Testing**: Validate with ansible-playbook --check

### CI/CD Pipeline Setup
1. **Phased Testing**: Development → staging → production progression
2. **Artifact Validation**: Hash pinning and verification
3. **Deployment Gates**: Manual approval for production
4. **Rollback Capability**: Automated rollback procedures

## Common Infrastructure Patterns


### Python Application Deployment
```
Context: jinja2 application infrastructure
Components:
- Application servers with python runtime
- Load balancers and reverse proxies
- Database connections and caching layers
- Monitoring and logging infrastructure

Validation:
- Deployment success: Application accessible and functional
- Health checks: All endpoints responding correctly
- Logs: No error patterns in application logs
- Performance: Meets baseline performance requirements
```


### Network Infrastructure
```
Context: Network configuration and security
Components:
- VPC/subnet configuration
- Security groups and firewall rules
- Load balancers and DNS configuration
- VPN and bastion host setup

Validation:
- Connectivity: All required ports accessible
- Security: No unauthorized access possible
- Performance: Network latency within acceptable ranges
- Monitoring: Network metrics being collected
```

### Monitoring and Observability
```
Context: System and application monitoring
Components:
- Metrics collection (Prometheus, CloudWatch)
- Log aggregation (ELK stack, CloudWatch Logs)
- Alerting and notification systems
- Dashboard and visualization tools

Validation:
- Metrics: All critical metrics being collected
- Alerts: Alerting working for defined thresholds
- Dashboards: Monitoring dashboards accessible and functional
- Coverage: >95% of system components monitored
```

## Automation Best Practices

### Idempotency Principles
- **State Checking**: Always check current state before making changes
- **Conditional Tasks**: Use when clauses in Ansible, count in Terraform
- **Resource Existence**: Check for existing resources before creation
- **Error Tolerance**: Handle already-configured scenarios gracefully

### Security Considerations
- **Least Privilege**: Minimal required permissions for deployments
- **Secret Management**: Secure storage and rotation of secrets
- **Network Security**: Proper firewall and access control configuration
- **Audit Logging**: Comprehensive logging for all infrastructure changes

### Reliability Patterns
- **Retries**: Implement retry logic for transient failures
- **Timeouts**: Set appropriate timeouts for operations
- **Health Checks**: Validate service health after changes
- **Rollback Plans**: Always have recovery procedures ready

## Validation and Testing

### Pre-Deployment Checks
```bash
# Terraform validation
terraform validate
terraform plan

# Ansible validation
ansible-playbook --syntax-check playbook.yaml
ansible-playbook --check playbook.yaml

# Configuration validation
python scripts/validate_config.py
```

### Post-Deployment Validation
```bash
# Infrastructure validation
terraform show
ansible-playbook --check playbook.yaml

# Application validation
python scripts/validation_scripts.py

# Integration testing


uv run pytest tests/integration/


```

### CI/CD Validation
```bash
# Pipeline validation
.github/scripts/validate_pipeline.py

# Artifact validation
python scripts/validate_artifacts.py

# Security scanning
python scripts/security_scan.py
```

## Deployment Orchestration

### Blue-Green Deployments
1. **Preparation**: Set up blue and green environments
2. **Deployment**: Deploy to inactive environment
3. **Testing**: Validate deployment in staging
4. **Switchover**: Route traffic to new environment
5. **Rollback**: Quick switch back if issues found

### Canary Deployments
1. **Percentage Rollout**: Deploy to subset of infrastructure
2. **Monitoring**: Watch for performance and error metrics
3. **Gradual Increase**: Slowly increase traffic to new version
4. **Full Rollout**: Complete deployment when confident
5. **Monitoring**: Continue monitoring post-deployment

### Rollback Procedures
1. **Trigger Identification**: Detect deployment issues
2. **Rollback Execution**: Automated rollback to previous version
3. **Validation**: Confirm system stability post-rollback
4. **Investigation**: Analyze root cause of deployment failure
5. **Fix Implementation**: Address issues before next deployment

## Monitoring and Alerting

### Infrastructure Monitoring
```bash
# Resource monitoring
terraform show
ansible-playbook playbooks/monitoring.yml

# Performance monitoring
python scripts/monitor_performance.py

# Cost monitoring
python scripts/monitor_costs.py
```

### Application Monitoring
```bash
# Health checks
curl -f http://application/health

# Metrics collection
python scripts/collect_metrics.py

# Log analysis
python scripts/analyze_logs.py
```

### Alert Configuration
- **Deployment Failures**: Immediate alerts for deployment issues
- **Performance Degradation**: Alerts when performance drops below thresholds
- **Resource Exhaustion**: Alerts for high resource utilization
- **Security Incidents**: Alerts for security-related events

## Escalation and Handoff

### When to Escalate
- **Infrastructure Issues**: Systems Engineer for hardware problems
- **Application Issues**: Development teams for code problems
- **Security Issues**: Security team for vulnerabilities
- **Performance Issues**: Performance engineering team

### Coordination Patterns
- **With Systems Engineer**: Hardware and system optimization
- **With Tester**: Validation suite development and execution
- **With Deployer**: Production deployment coordination
- **With Debugger**: Issue diagnosis and infrastructure fixes

## Success Metrics
- **Deployment Success**: 100% successful automated deployments
- **MTTR**: <15 minutes mean time to recovery
- **Automation Coverage**: >90% of infrastructure changes automated
- **Uptime**: >99.9% infrastructure availability