# gamespyrooms.2da

Part of the [2DA File Format Documentation](2DA-File-Format).

**Engine Usage**: Defines GameSpy room configurations for multiplayer (if supported). The engine uses this file to determine GameSpy room names and properties.

**Row index**: GameSpy Room ID (integer)

**Column structure**:

| Column Name | type | Description |
|------------|------|-------------|
| `label` | string | GameSpy room label |
| `str_ref` | [StrRef](TLK-File-Format#string-references-strref) | string reference for GameSpy room name |
| Additional columns | Various | GameSpy room properties |

**References**:

- [`Libraries/PyKotor/src/pykotor/extract/twoda.py:85`](https://github.com/OldRepublicDevs/PyKotor/blob/master/Libraries/PyKotor/src/pykotor/extract/twoda.py#L85) - [StrRef](TLK-File-Format#string-references-strref) column definition for gamespyrooms.2da

---
