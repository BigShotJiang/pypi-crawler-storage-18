from __future__ import annotations

from typing import TYPE_CHECKING

from qtpy.QtCore import Qt
from qtpy.QtWidgets import QDialog

if TYPE_CHECKING:
    from qtpy.QtWidgets import QWidget

    from pykotor.common.indoorkit import Kit
    from pykotor.common.indoormap import IndoorMap
    from toolset.data.installation import HTInstallation


class IndoorMapSettings(QDialog):
    def __init__(
        self,
        parent: QWidget,
        installation: HTInstallation,
        indoor_map: IndoorMap,
        kits: list[Kit],
    ):
        """Initializes the indoor map editor dialog.

        Args:
        ----
            parent (QWidget): The parent widget.
            installation (HTInstallation): The installation.
            indoor_map (IndoorMap): The indoor map to edit.
            kits (list[Kit]): Available kits.


        Returns:
        -------
            None
        Processing Logic:
        ----------------
            - Initializes UI elements from indoor_map properties
            - Populates skybox selector with options from available kits
            - Sets initial skybox selection.
        """
        super().__init__(parent)
        self.setWindowFlags(
            (Qt.WindowType.Dialog  # pyright: ignore[reportArgumentType]
             | Qt.WindowType.WindowCloseButtonHint)
            & ~Qt.WindowType.WindowContextHelpButtonHint
        )

        from toolset.uic.qtpy.dialogs.indoor_settings import Ui_Dialog
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        
        # Setup scrollbar event filter to prevent scrollbar interaction with controls
        from toolset.gui.common.filters import NoScrollEventFilter
        self._no_scroll_filter = NoScrollEventFilter(self)
        self._no_scroll_filter.setup_filter(parent_widget=self)
        self.ui.nameEdit.set_installation(installation)

        self._indoorMap: IndoorMap = indoor_map
        self._kits: list[Kit] = kits

        self.ui.nameEdit.set_locstring(indoor_map.name)
        self.ui.colorEdit.set_color(indoor_map.lighting)
        self.ui.warpCodeEdit.setText(indoor_map.module_id)

        from toolset.gui.common.localization import translate as tr
        self.ui.skyboxSelect.addItem(tr("[None]"), "")
        for kit in kits:
            for skybox in kit.skyboxes:
                self.ui.skyboxSelect.addItem(skybox, skybox)
        
        # Set current skybox by finding matching data or text
        if indoor_map.skybox:
            # Try to find by text first
            index = self.ui.skyboxSelect.findText(indoor_map.skybox)
            if index == -1:
                # Try to find by data
                index = self.ui.skyboxSelect.findData(indoor_map.skybox)
            if index != -1:
                self.ui.skyboxSelect.setCurrentIndex(index)
            else:
                self.ui.skyboxSelect.setCurrentIndex(0)  # Default to [None]
        else:
            self.ui.skyboxSelect.setCurrentIndex(0)  # Default to [None]
        
        # Populate and set target game type selector
        self.ui.gameTypeSelect.addItem(tr("Use Installation Default"), None)
        self.ui.gameTypeSelect.addItem("Knights of the Old Republic (K1)", False)
        self.ui.gameTypeSelect.addItem("The Sith Lords (TSL/K2)", True)
        
        # Set current selection based on indoor_map.target_game_type
        if indoor_map.target_game_type is None:
            self.ui.gameTypeSelect.setCurrentIndex(0)  # Use Installation Default
        elif indoor_map.target_game_type:
            self.ui.gameTypeSelect.setCurrentIndex(2)  # TSL/K2
        else:
            self.ui.gameTypeSelect.setCurrentIndex(1)  # K1

    def _setup_signals(self): ...

    def accept(self):
        super().accept()

        self._indoorMap.name = self.ui.nameEdit.locstring()
        self._indoorMap.lighting = self.ui.colorEdit.color()
        self._indoorMap.module_id = self.ui.warpCodeEdit.text()
        self._indoorMap.skybox = self.ui.skyboxSelect.currentData()
        # Get target_game_type from combo box (None = use installation default, True = TSL, False = K1)
        self._indoorMap.target_game_type = self.ui.gameTypeSelect.currentData()
