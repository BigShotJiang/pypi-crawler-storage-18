"""Dependency injection context management."""
