import numpy as np
import skfuzzy as fuzz
import skfuzzy.control as ctrl
import pandas as pd
import warnings
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')



def run(path):
    """
    This function does everything in one shot. TODO: Break this function down.
    :return: None
    """
    wen1 = path.split('/')[-1]
    wen2 = wen1.split('.')[0]


    df= pd.read_csv(path, index_col=0)
    df =df.dropna()
    df = df.reset_index()

    df['L_upper'] = (df['High'] - np.maximum(df['Open'], df['Close'])) / df['Open']
    df['L_lower'] = (np.minimum(df['Open'], df['Close']) - df['Low']) / df['Open']
    df['L_body'] = (np.maximum(df['Open'], df['Close']) - np.minimum(df['Open'], df['Close'])) / df['Close']
    # 修正范围（0-100）
    df['L_upper'] = (df['L_upper'] - min(df['L_upper'])) / (max(df['L_upper']) - min(df['L_upper'])) * 100
    df['L_lower'] = (df['L_lower'] - min(df['L_lower'])) / (max(df['L_lower']) - min(df['L_lower'])) * 100
    df['L_body'] = (df['L_body'] - min(df['L_body'])) / (max(df['L_body']) - min(df['L_body'])) * 100

    return df,wen2


def fuzzification(df,wen2):
    # 创建模糊控制变量
    L_upper_range = np.arange(0, 101, 1, np.float64)
    L_lower_range = np.arange(0, 101, 1, np.float64)
    L_body_range = np.arange(0, 101, 1, np.float64)
    R_pos_range = np.arange(0, 101, 1, np.float64)
    R_size_range = np.arange(0, 101, 1, np.float64)
    # 创建模糊控制变量
    L_upper = ctrl.Antecedent(L_upper_range, 'L_upper')
    L_lower = ctrl.Antecedent(L_lower_range, 'L_lower')
    L_body = ctrl.Antecedent(L_body_range, 'L_body')
    R_pos = ctrl.Consequent(R_pos_range, 'R_pos')
    R_size = ctrl.Consequent(R_size_range, 'R_size')

    # 上影线隶属度函数
    L_upper['NULL'] = fuzz.trimf(L_upper_range, [0, 0, 5])

    L_upper['SHORT'] = fuzz.trapmf(L_upper_range, [0, 5, 25, 37.5])

    L_upper['MIDDLE'] = fuzz.trapmf(L_upper_range, [25, 37.5, 62.5, 75])

    L_upper['LONG'] = fuzz.trapmf(L_upper_range, [62.5, 75, 100, 100])

    # 下影线隶属度函数
    L_lower['NULL'] = fuzz.trimf(L_lower_range, [0, 0, 5])

    L_lower['SHORT'] = fuzz.trapmf(L_lower_range, [0, 5, 25, 37.5])

    L_lower['MIDDLE'] = fuzz.trapmf(L_lower_range, [25, 37.5, 62.5, 75])

    L_lower['LONG'] = fuzz.trapmf(L_lower_range, [62.5, 75, 100, 100])

    # 实体隶属度函数
    L_body['NULL'] = fuzz.trimf(L_body_range, [0, 0, 5])

    L_body['SHORT'] = fuzz.trapmf(L_body_range, [0, 5, 25, 37.5])

    L_body['MIDDLE'] = fuzz.trapmf(L_body_range, [25, 37.5, 62.5, 75])

    L_body['LONG'] = fuzz.trapmf(L_body_range, [62.5, 75, 100, 100])

    # R_pos隶属度函数
    R_pos['DOWN'] = fuzz.trimf(R_pos_range, [0, 0, 25])

    R_pos['CENTER_DOWN'] = fuzz.trimf(R_pos_range, [0, 25, 50])

    R_pos['CENTER'] = fuzz.trimf(R_pos_range, [25, 50, 75])

    R_pos['CENTER_UP'] = fuzz.trimf(R_pos_range, [50, 75, 100])

    R_pos['UP'] = fuzz.trimf(R_pos_range, [75, 100, 100])

    # R_size隶属度函数
    R_size['LOW'] = fuzz.trimf(R_size_range, [0, 0, 25])

    R_size['MEDIUM_LOW'] = fuzz.trimf(R_size_range, [0, 25, 50])

    R_size['MEDIUM'] = fuzz.trimf(R_size_range, [25, 50, 75])

    R_size['MEDIUM_EQUAL'] = fuzz.trimf(R_size_range, [50, 75, 100])

    R_size['EQUAL'] = fuzz.trimf(R_size_range, [75, 100, 100])

    # 设定输出powder的解模糊方法——质心解模糊方式

    R_pos.defuzzify_method = 'centroid'
    R_size.defuzzify_method = 'centroid'

    # 建立模糊规则
    rule1 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['LONG'] & L_body['LONG']),
                      consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER']), label='rule 1')
    rule2 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['LONG'] & L_body['MIDDLE']),
                      consequent=(R_size['MEDIUM'], R_pos['CENTER']), label='rule 2')
    rule3 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['LONG'] & L_body['SHORT']),
                      consequent=(R_size['MEDIUM_LOW'], R_pos['CENTER']), label='rule 3')
    rule4 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['LONG'] & L_body['NULL']),
                      consequent=(R_size['LOW'], R_pos['CENTER']), label='rule 4')
    #############################################
    rule5 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['MIDDLE'] & L_body['LONG']),
                      consequent=(R_size['MEDIUM'], R_pos['CENTER_DOWN']), label='rule 5')
    rule6 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['MIDDLE'] & L_body['MIDDLE']),
                      consequent=(R_size['MEDIUM_LOW'], R_pos['CENTER_DOWN']), label='rule 6')
    rule7 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['MIDDLE'] & L_body['SHORT']),
                      consequent=(R_size['LOW'], R_pos['CENTER_DOWN']), label='rule 7')
    rule8 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['MIDDLE'] & L_body['NULL']),
                      consequent=(R_size['LOW'], R_pos['CENTER_DOWN']), label='rule 8')
    ################################################
    rule9 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['SHORT'] & L_body['LONG']),
                      consequent=(R_size['MEDIUM_EQUAL'], R_pos['DOWN']), label='rule 9')
    rule10 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['SHORT'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM'], R_pos['DOWN']), label='rule 10')
    rule11 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['SHORT'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['DOWN']), label='rule 11')
    rule12 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['SHORT'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['DOWN']), label='rule 12')
    ##############################################
    rule13 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['NULL'] & L_body['LONG']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['DOWN']), label='rule 13')
    rule14 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['NULL'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM'], R_pos['DOWN']), label='rule 14')
    rule15 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['NULL'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['DOWN']), label='rule 15')
    rule16 = ctrl.Rule(antecedent=(L_upper['LONG'] & L_lower['NULL'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['DOWN']), label='rule 16')
    #################################################
    rule17 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['LONG'] & L_body['LONG']),
                       consequent=(R_size['MEDIUM'], R_pos['CENTER_UP']), label='rule 17')
    rule18 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['LONG'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['CENTER_UP']), label='rule 18')
    rule19 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['LONG'] & L_body['SHORT']),
                       consequent=(R_size['LOW'], R_pos['CENTER_UP']), label='rule 19')
    rule20 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['LONG'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['CENTER_UP']), label='rule 20')
    #################################################
    rule21 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['MIDDLE'] & L_body['LONG']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER']), label='rule 21')
    rule22 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['MIDDLE'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM'], R_pos['CENTER']), label='rule 22')
    rule23 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['MIDDLE'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['CENTER']), label='rule 23')
    rule24 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['MIDDLE'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['CENTER']), label='rule 24')
    #################################################
    rule25 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['SHORT'] & L_body['LONG']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER_DOWN']), label='rule 25')
    rule26 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['SHORT'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM'], R_pos['CENTER_DOWN']), label='rule 26')
    rule27 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['SHORT'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['CENTER_DOWN']), label='rule 27')
    rule28 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['SHORT'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['CENTER_DOWN']), label='rule 28')
    #################################################
    rule29 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['NULL'] & L_body['LONG']),
                       consequent=(R_size['EQUAL'], R_pos['DOWN']), label='rule 29')
    rule30 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['NULL'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['DOWN']), label='rule 30')
    rule31 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['NULL'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['DOWN']), label='rule 31')
    rule32 = ctrl.Rule(antecedent=(L_upper['MIDDLE'] & L_lower['NULL'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['DOWN']), label='rule 32')
    ###################################################
    rule33 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['LONG'] & L_body['LONG']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['UP']), label='rule 33')
    rule34 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['LONG'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM'], R_pos['UP']), label='rule 34')
    rule35 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['LONG'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['UP']), label='rule 35')
    rule36 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['LONG'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['UP']), label='rule 36')
    #############################################
    rule37 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['MIDDLE'] & L_body['LONG']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER_UP']), label='rule 37')
    rule38 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['MIDDLE'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM'], R_pos['CENTER_UP']), label='rule 38')
    rule39 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['MIDDLE'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['CENTER_UP']), label='rule 39')
    rule40 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['MIDDLE'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['CENTER_UP']), label='rule 40')
    ################################################
    rule41 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['SHORT'] & L_body['LONG']),
                       consequent=(R_size['EQUAL'], R_pos['CENTER']), label='rule 41')
    rule42 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['SHORT'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER']), label='rule 42')
    rule43 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['SHORT'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM'], R_pos['CENTER']), label='rule 43')
    rule44 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['SHORT'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['CENTER']), label='rule 44')
    ##############################################
    rule45 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['NULL'] & L_body['LONG']),
                       consequent=(R_size['EQUAL'], R_pos['CENTER_DOWN']), label='rule 45')
    rule46 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['NULL'] & L_body['MIDDLE']),
                       consequent=(R_size['EQUAL'], R_pos['CENTER_DOWN']), label='rule 46')
    rule47 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['NULL'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER_DOWN']), label='rule 47')
    rule48 = ctrl.Rule(antecedent=(L_upper['SHORT'] & L_lower['NULL'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['CENTER_DOWN']), label='rule 48')
    #################################################
    rule49 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['LONG'] & L_body['LONG']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['UP']), label='rule 49')
    rule50 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['LONG'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM'], R_pos['UP']), label='rule 50')
    rule51 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['LONG'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['UP']), label='rule 51')
    rule52 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['LONG'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['UP']), label='rule 52')
    #################################################
    rule53 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['MIDDLE'] & L_body['LONG']),
                       consequent=(R_size['EQUAL'], R_pos['UP']), label='rule 53')
    rule54 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['MIDDLE'] & L_body['MIDDLE']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['UP']), label='rule 54')
    rule55 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['MIDDLE'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_LOW'], R_pos['UP']), label='rule 55')
    rule56 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['MIDDLE'] & L_body['NULL']),
                       consequent=(R_size['LOW'], R_pos['UP']), label='rule 56')
    #################################################
    rule57 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['SHORT'] & L_body['LONG']),
                       consequent=(R_size['EQUAL'], R_pos['CENTER_UP']), label='rule 57')
    rule58 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['SHORT'] & L_body['MIDDLE']),
                       consequent=(R_size['EQUAL'], R_pos['CENTER_UP']), label='rule 58')
    rule59 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['SHORT'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER_UP']), label='rule 59')
    rule60 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['SHORT'] & L_body['NULL']),
                       consequent=(R_size['MEDIUM'], R_pos['CENTER_UP']), label='rule 60')
    #################################################
    rule61 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['NULL'] & L_body['LONG']),
                       consequent=(R_size['EQUAL'], R_pos['CENTER']), label='rule 61')
    rule62 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['NULL'] & L_body['MIDDLE']),
                       consequent=(R_size['EQUAL'], R_pos['CENTER']), label='rule 62')
    rule63 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['NULL'] & L_body['SHORT']),
                       consequent=(R_size['MEDIUM_EQUAL'], R_pos['CENTER']), label='rule 63')
    rule64 = ctrl.Rule(antecedent=(L_upper['NULL'] & L_lower['NULL'] & L_body['NULL']),
                       consequent=(R_size['MEDIUM'], R_pos['CENTER']), label='rule 64')

    # 隶属度函数可视化

    L_upper.view()
    L_lower.view()
    L_body.view()
    R_pos.view()
    R_size.view()
    plt.show()

    # 系统和运行环境初始化
    system = ctrl.ControlSystem(rules=[rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10,
                                       rule11, rule12, rule13, rule14, rule15, rule16, rule17, rule18, rule19,
                                       rule20,
                                       rule21, rule22, rule23, rule24, rule25, rule26, rule27, rule28, rule29,
                                       rule30,
                                       rule31, rule32, rule33, rule34, rule35, rule36, rule37, rule38, rule39,
                                       rule40,
                                       rule41, rule42, rule43, rule44, rule45, rule46, rule47, rule48, rule49,
                                       rule50,
                                       rule51, rule52, rule53, rule54, rule55, rule56, rule57, rule58, rule59,
                                       rule60,
                                       rule61, rule62, rule63, rule64])

    sim = ctrl.ControlSystemSimulation(system)

    # 得到模糊输出
    df['Rpos'] = np.zeros(shape=(df.shape[0], 1))
    df['Rsize'] = np.zeros(shape=(df.shape[0], 1))
    for i in range(0, df.shape[0]):
        sim.input['L_upper'] = df['L_upper'][i]
        sim.input['L_lower'] = df['L_lower'][i]
        sim.input['L_body'] = df['L_body'][i]
        sim.compute()  # 运行系统
        df['Rpos'][i] = sim.output['R_pos']
        df['Rsize'][i] = sim.output['R_size']
    df.to_csv('C:/Users/Big Data/Desktop/output/{}.csv'.format(wen2))
    return df

if __name__ == '__main__':
    path='C:/Users/Big Data/Desktop/output/原始数据/WTI.csv'
    df,wen2=run(path)
    df=fuzzification(df,wen2)