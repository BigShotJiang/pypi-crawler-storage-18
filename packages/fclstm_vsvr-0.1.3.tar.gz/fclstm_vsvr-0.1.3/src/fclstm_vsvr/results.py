import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
# plotly is an advanced visualization tool
import chart_studio.plotly as py
from plotly.offline import init_notebook_mode, iplot
init_notebook_mode(connected=True)
import plotly.graph_objs as go
import warnings
warnings.filterwarnings("ignore")
from mpl_finance import candlestick_ohlc
import matplotlib.dates as mdates
import numpy as np
import pandas as pd
import xlrd


df=pd.read_excel("G:\\学习课件\\两篇小论文\\中文小论文\\paper2\\实验2\\输出结果\\ADI.xlsx")
print(df)


# 设置输出的图片大小
figsize = 7, 4
figure, ax = plt.subplots(figsize=figsize)

x=df['Date']
# 在同一幅图片上画两条折线
A, = plt.plot(x,df['original price'], 'r^-', label='actual value', linewidth=1.25)#, linewidth=1.25

B, = plt.plot(x,df['GLSTM-vSVR'], 'b.-', label='FCGLSTM-vSVR', linewidth=1.25)
# C, = plt.plot(x,df['GLSTM'], 'c', label='GLSTM', linewidth=1.25)
# D, = plt.plot(x,df['vSVR'], 'y', label='vSVR', linewidth=1.25)
# E, = plt.plot(x,df['BPNN'], 'b', label='BPNN', linewidth=1.25)
# F, = plt.plot(x,df['GLSTM-BPNN'], 'm', label='GLSTM-BPNN', linewidth=1.25)


# 设置图例并且设置图例的字体及大小
font1 = {'family': 'Times New Roman',
         'weight': 'normal',
         'size': 12,
         }
legend = plt.legend(handles=[A,B], prop=font1)

# 设置坐标刻度值的大小以及刻度值的字体
plt.tick_params(labelsize=12)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]

# 设置横纵坐标的名称以及对应字体格式
font2 = {'family': 'Times New Roman',
         'weight': 'normal',
         'size': 12,
         }
plt.xlabel('Time', font2)
plt.ylabel('Price', font2)

# 将文件保存至文件中并且画出图
plt.show()