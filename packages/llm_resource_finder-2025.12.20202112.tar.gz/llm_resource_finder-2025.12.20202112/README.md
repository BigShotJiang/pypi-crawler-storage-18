# LLM Resource Finder

[![PyPI version](https://img.shields.io/pypi/v/llm-resource-finder.svg)](https://pypi.org/project/llm-resource-finder/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/llm-resource-finder)](https://pepy.tech/project/llm-resource-finder)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue)](https://www.linkedin.com/in/eugene-evstafev/)

A Python package that helps users discover and access the latest free LLM (Large Language Model) resources. Input your specific needs or interests, and get a structured list of relevant, up-to-date, and free LLM resources, including datasets, pre-trained models, tutorials, research papers, and community forums.

## Installation

```bash
pip install llm_resource_finder
```

## Usage

### Basic Example

```python
from llm_resource_finder import llm_resource_finder

user_input = "I need free pre-trained language models for text generation."
resources = llm_resource_finder(user_input=user_input)
print(resources)
```

### Using a Custom LLM

You can use any LangChain-compatible chat model by passing it to the `llm` parameter.

#### Using OpenAI

```python
from langchain_openai import ChatOpenAI
from llm_resource_finder import llm_resource_finder

llm = ChatOpenAI()
response = llm_resource_finder(user_input="Find free LLM datasets", llm=llm)
```

#### Using Anthropic

```python
from langchain_anthropic import ChatAnthropic
from llm_resource_finder import llm_resource_finder

llm = ChatAnthropic()
response = llm_resource_finder(user_input="Latest LLM research papers", llm=llm)
```

#### Using Google Generative AI

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from llm_resource_finder import llm_resource_finder

llm = ChatGoogleGenerativeAI()
response = llm_resource_finder(user_input="Free LLM tutorials", llm=llm)
```

### Using a Custom API Key

By default, the package uses the free tier of LLM7. You can provide your own API key for higher rate limits.

#### Via Environment Variable

```bash
export LLM7_API_KEY="your_api_key_here"
```

#### Via Function Parameter

```python
from llm_resource_finder import llm_resource_finder

response = llm_resource_finder(
    user_input="Find LLM resources",
    api_key="your_api_key_here"
)
```

You can get a free API key by registering at [https://token.llm7.io/](https://token.llm7.io/).

## Parameters

- `user_input` (str): The user input text describing the desired LLM resources.
- `llm` (Optional[BaseChatModel]): A LangChain-compatible chat model instance. Defaults to `ChatLLM7`.
- `api_key` (Optional[str]): API key for LLM7. If not provided, the package uses the environment variable `LLM7_API_KEY` or defaults to the free tier.

## Default LLM

The package uses `ChatLLM7` from [langchain_llm7](https://pypi.org/project/langchain-llm7/) by default. The free tier rate limits are sufficient for most use cases.

## Contributing

We welcome contributions! Please report issues or suggest features on [GitHub](https://github.com/chigwell/llm-resource-finder/issues).

## Author

**Eugene Evstafev**  
Email: hi@euegne.plus  
GitHub: [chigwell](https://github.com/chigwell)

## License

This project is licensed under the MIT License. See the LICENSE file for details.