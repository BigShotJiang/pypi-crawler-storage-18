"""
Corpus data module for Afaan Oromoo NLP.
Provides access to built-in corpus data like stopwords and common words.
"""

import os
from typing import List, Set, Dict
import json

# Get the directory where this module is located
_CORPUS_DIR = os.path.dirname(__file__)


def _load_corpus_file(filename: str) -> List[str]:
    """
    Load corpus file as list of lines.
    
    Args:
        filename: Name of corpus file
        
    Returns:
        List of lines from file
    """
    filepath = os.path.join(_CORPUS_DIR, filename)
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = [line.strip() for line in f if line.strip()]
    return lines


def _save_corpus_file(filename: str, data: List[str]) -> None:
    """
    Save data to corpus file.
    
    Args:
        filename: Name of corpus file
        data: List of strings to save
    """
    filepath = os.path.join(_CORPUS_DIR, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(f"{item}\n")


def load_stopwords() -> Set[str]:
    """
    Load Afaan Oromoo stopwords.
    
    Returns:
        Set of stopwords
    """
    stopwords = _load_corpus_file('stopwords.txt')
    return set(stopwords)


def load_common_words(limit: int = 1000) -> List[str]:
    """
    Load common Afaan Oromoo words.
    
    Args:
        limit: Maximum number of words to return
        
    Returns:
        List of common words
    """
    words = _load_corpus_file('common_words.txt')
    return words[:limit]


def get_stopwords() -> Set[str]:
    """
    Get Afaan Oromoo stopwords (cached).
    
    Returns:
        Set of stopwords
    """
    if not hasattr(get_stopwords, '_cache'):
        get_stopwords._cache = load_stopwords()
    return get_stopwords._cache


def get_common_words(limit: int = 1000) -> List[str]:
    """
    Get common Afaan Oromoo words (cached).
    
    Args:
        limit: Maximum number of words
        
    Returns:
        List of common words
    """
    cache_key = f'common_words_{limit}'
    if not hasattr(get_common_words, '_cache'):
        get_common_words._cache = {}
    
    if cache_key not in get_common_words._cache:
        get_common_words._cache[cache_key] = load_common_words(limit)
    
    return get_common_words._cache[cache_key]


def add_stopword(word: str) -> None:
    """
    Add a word to stopwords list.
    
    Args:
        word: Word to add as stopword
    """
    stopwords = list(load_stopwords())
    if word not in stopwords:
        stopwords.append(word)
        _save_corpus_file('stopwords.txt', sorted(stopwords))
        # Clear cache
        if hasattr(get_stopwords, '_cache'):
            delattr(get_stopwords, '_cache')


def remove_stopword(word: str) -> None:
    """
    Remove a word from stopwords list.
    
    Args:
        word: Word to remove from stopwords
    """
    stopwords = list(load_stopwords())
    if word in stopwords:
        stopwords.remove(word)
        _save_corpus_file('stopwords.txt', sorted(stopwords))
        # Clear cache
        if hasattr(get_stopwords, '_cache'):
            delattr(get_stopwords, '_cache')


def create_custom_corpus(name: str, words: List[str]) -> None:
    """
    Create a custom corpus file.
    
    Args:
        name: Name of corpus file (without .txt)
        words: List of words to save
    """
    filename = f"{name}.txt"
    _save_corpus_file(filename, words)


def get_corpus_names() -> List[str]:
    """
    Get list of available corpus files.
    
    Returns:
        List of corpus file names
    """
    files = os.listdir(_CORPUS_DIR)
    return [f for f in files if f.endswith('.txt')]


# Export commonly used functions
__all__ = [
    'load_stopwords',
    'load_common_words',
    'get_stopwords',
    'get_common_words',
    'add_stopword',
    'remove_stopword',
    'create_custom_corpus',
    'get_corpus_names',
]