import pandas as pd
import numpy as np
import pydicom

def convert_multivalue_and_sequence_to_string(value):
    if isinstance(value, (pydicom.multival.MultiValue, pydicom.sequence.Sequence)):
        return str(value)
    return value

def extract_first_if_array(x):
    if isinstance(x, np.ndarray):
        return x[0] if x.size > 0 else None
    elif pd.isna(x):
        return None
    else:
        return x


def aggregate_series_level(df_dcm, df_file_list=None):

    df = df_dcm.copy()

    if 'Batch' not in df.columns and df_file_list is not None and 'Batch' in df_file_list.columns:
        df = pd.merge(df, df_file_list[['Dcm_Path', 'Batch']], on='Dcm_Path', how='left')

    batch_map = None
    if "Batch" in df.columns:
        batch_map = df.groupby("SeriesInstanceUID")["Batch"].first().reset_index()

    folder_to_series = (
        df[df["SeriesInstanceUID"].notna()]
        .groupby("Dcm_Path_Series")["SeriesInstanceUID"]
        .first()
        .reset_index()
    )

    df_folder_filecount = (
        df.groupby("Dcm_Path_Series")["Dcm_Path"]
        .count()
        .reset_index(name="FileCount")
    )

    df_filecount = (
        df_folder_filecount
        .merge(folder_to_series, on="Dcm_Path_Series", how="left")
        .groupby("SeriesInstanceUID")["FileCount"]
        .sum()
        .reset_index()
    )

    if "__error__" in df.columns:
        df_readable = df[df["__error__"].isna()].copy()
    else:
        df_readable = df.copy()

    df_slicecount = (
        df_readable.groupby("SeriesInstanceUID")["SeriesInstanceUID"]
        .count()
        .reset_index(name="ReadableDicomSliceCount")
    )

    df_slt = df.copy()

    for col in df_slt.columns:
        df_slt[col] = df_slt[col].apply(convert_multivalue_and_sequence_to_string)

    unique_cols = [c for c in df_slt.columns if c not in ['SeriesInstanceUID', 'Batch']]
    df_slt_series = df_slt.groupby('SeriesInstanceUID')[unique_cols].agg(['unique']).reset_index()

    df_slt_series.columns = df_slt_series.columns.get_level_values(0)

    df_slt_series = pd.merge(df_slt_series, df_slicecount, on="SeriesInstanceUID", how="left")

    df_slt_series = pd.merge(df_slt_series, df_filecount, on="SeriesInstanceUID", how="left")

    if batch_map is not None:
        df_slt_series = pd.merge(df_slt_series, batch_map, on="SeriesInstanceUID", how="left")

    columns_to_clean = ["PatientID", "AccessionNumber", "StudyInstanceUID",
                        "SeriesInstanceUID", "Batch", "Dcm_Path_Series"]
    for col in columns_to_clean:
        if col in df_slt_series.columns:
            df_slt_series[col] = df_slt_series[col].apply(extract_first_if_array)

    df_slt_series.rename(columns={"SliceCount": "ReadableDicomSliceCount"}, inplace=True)

    df_slt_series["FileCount"] = df_slt_series["FileCount"].fillna(0).astype(int)
    df_slt_series["ReadableDicomSliceCount"] = df_slt_series["ReadableDicomSliceCount"].fillna(0).astype(int)

    def make_status(row):
        diff = row["FileCount"] - row["ReadableDicomSliceCount"]
        if diff == 0:
            return "All_DICOM_Readable"
        else:
            return f"{diff}_DICOM_Unreadable"

    df_slt_series["Series_DICOM_Readability_Status"] = df_slt_series.apply(make_status, axis=1)

    columns_to_front = [
        "PatientID", "AccessionNumber", "StudyInstanceUID",
        "SeriesInstanceUID", "SOPInstanceUID", "Batch", "Dcm_Path_Series",
        "FileCount",
        "ReadableDicomSliceCount",
        "Series_DICOM_Readability_Status",
        "Dcm_Path"
    ]

    df_slt_series = df_slt_series[
        [c for c in columns_to_front if c in df_slt_series.columns] +
        [c for c in df_slt_series.columns if c not in columns_to_front]
    ]

    return df_slt_series