"""PUREFN: Pure, stateless game operations.

A library for deterministic, replay-able game state management with no
database. Every operation is a pure function:
``(public_token, private_inputs, op) -> (new_public_token, private_outputs, views)``.
"""

__version__ = "v0.0.0dev0"
