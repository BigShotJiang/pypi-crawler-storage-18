"""ctopo - tools for analyzing the chemical space of coordination-complex ligands.

The package centers around graph-based representations of ligands and complexes
derived from RDKit molecules and converted to NetworkX graphs.
"""

__version__ = '0.1.0'


from ctopo.core.atom_types import AtomType  # noqa: E402
from ctopo.core.graph import mol_to_nx
from ctopo.core.ligand import (
    SmilesSettings,
    SvgSettings,
    Ligand,
    ligand_from_mol,
)
from ctopo.core.complex import Complex, complex_from_mol

from ctopo.io import ligand_from_smiles, complex_from_smiles

from ctopo.descriptors import (
    ALLOWED_PROPERTIES,
    DEFAULT_PROPERTIES,
    MorganSpec,
    AtomPairsSpec,
    Fingerprinter,
    make_fingerprinter,
    fingerprint_from_structure,
)

from ctopo.distances import (
    tanimoto_similarity_bits,
    tanimoto_distance_bits,
    tanimoto_similarity_counts,
    tanimoto_distance_counts,
)

from ctopo.topology import get_ligands_skeleton, get_ligands_topology

from ctopo.fragments import ligands_from_complex

from ctopo.trees.build import build_ligand_tree
from ctopo.trees.html import tree_to_html


__all__ = [
    
    'AtomType',
    'mol_to_nx',
    'SmilesSettings',
    'SvgSettings',
    'Ligand',
    'ligand_from_mol',
    'Complex',
    'complex_from_mol',

    'ligand_from_smiles',
    'complex_from_smiles',

    'ALLOWED_PROPERTIES',
    'DEFAULT_PROPERTIES',
    'MorganSpec',
    'AtomPairsSpec',
    'Fingerprinter',
    'make_fingerprinter',
    'fingerprint_from_structure',

    'tanimoto_similarity_bits',
    'tanimoto_distance_bits',
    'tanimoto_similarity_counts',
    'tanimoto_distance_counts',

    'get_ligands_skeleton',
    'get_ligands_topology',

    'ligands_from_complex',

]


