"""Distance and similarity functions for cTopo fingerprints.

ctopo fingerprints can be represented in a few common formats:

Bits (presence)
  - ``set[int]`` of on-bit indices
  - ``dict[int, int]`` mapping on-bit indices -> 1 (values are ignored)
  - ``numpy.ndarray`` of shape ``(n_bits,)`` with 0/1 or bool values

Counts (hashed counts or original sparse counts)
  - ``dict[int, int]`` or ``dict[int, float]`` mapping feature_id/bit_index -> count
  - ``numpy.ndarray`` (or sequence convertible to one) of shape ``(n,)`` with
    non-negative counts

This module intentionally stays lightweight (no RDKit dependency) while providing
the most common similarity/distance measures used with fingerprints.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence, Union

import numpy as np


BitFP = Union[set[int], frozenset[int], Mapping[int, Any], np.ndarray]
CountFP = Union[Mapping[int, float], Mapping[int, int], np.ndarray, Sequence[float]]


def _as_bitset(fp: BitFP) -> set[int]:
    """Normalize a bit fingerprint into a python set of on-bit indices."""
    if isinstance(fp, (set, frozenset)):
        return {int(x) for x in fp}

    if isinstance(fp, np.ndarray):
        if fp.ndim != 1:
            raise ValueError("Bit vector numpy arrays must be 1D")
        return {int(i) for i in np.flatnonzero(fp)}

    if isinstance(fp, Mapping):
        return {int(k) for k in fp.keys()}

    # Optional compatibility with RDKit ExplicitBitVect without importing RDKit:
    get_on_bits = getattr(fp, "GetOnBits", None)
    if callable(get_on_bits):
        return {int(i) for i in get_on_bits()}

    raise TypeError(
        "Unsupported bit fingerprint type. Expected set/dict/numpy array (or RDKit ExplicitBitVect)."
    )


def _as_dense_counts(fp: CountFP) -> np.ndarray:
    """Normalize a dense count fingerprint to a 1D float64 numpy array."""
    if isinstance(fp, np.ndarray):
        arr = fp
    else:
        # Accept lists/tuples etc.
        arr = np.asarray(fp, dtype=np.float64)
    if arr.ndim != 1:
        raise ValueError("Dense count vectors must be 1D")
    return arr.astype(np.float64, copy=False)


def _is_sparse_counts(fp: Any) -> bool:
    return isinstance(fp, Mapping) and not isinstance(fp, np.ndarray)


def _validate_nonnegative_dense(arr: np.ndarray) -> None:
    if np.any(arr < 0):
        raise ValueError("Count vectors must be non-negative for Tanimoto/Dice.")


def _validate_nonnegative_sparse(d: Mapping[int, float]) -> None:
    # Light validation: short-circuit as soon as we see an invalid value.
    for v in d.values():
        if float(v) < 0:
            raise ValueError("Count vectors must be non-negative for Tanimoto/Dice.")


def tanimoto_similarity_bits(a: BitFP, b: BitFP) -> float:
    """Tanimoto similarity for binary/presence fingerprints.

    Returns:
        Similarity in [0, 1]. If both fingerprints are empty (all zeros),
        returns 1.0 by convention.
    """
    sa = _as_bitset(a)
    sb = _as_bitset(b)
    if not sa and not sb:
        return 1.0
    inter = len(sa & sb)
    union = len(sa) + len(sb) - inter
    return float(inter / union) if union else 1.0


def tanimoto_distance_bits(a: BitFP, b: BitFP) -> float:
    """Tanimoto distance for binary/presence fingerprints (1 - similarity)."""
    return 1.0 - tanimoto_similarity_bits(a, b)


def tanimoto_similarity_counts(a: CountFP, b: CountFP) -> float:
    """Generalized Tanimoto similarity for non-negative count vectors.

    This is the standard extension of Tanimoto to count vectors:
        sim = (a·b) / (||a||^2 + ||b||^2 - a·b)

    Works with both dense (numpy/sequence) and sparse (dict-like) inputs.
    If both vectors are all zeros, returns 1.0 by convention.
    """
    # sparse-sparse
    if _is_sparse_counts(a) and _is_sparse_counts(b):
        da = {int(k): float(v) for k, v in a.items()}
        db = {int(k): float(v) for k, v in b.items()}
        _validate_nonnegative_sparse(da)
        _validate_nonnegative_sparse(db)

        # dot over smaller dict
        if len(da) > len(db):
            da, db = db, da
        dot = 0.0
        for k, va in da.items():
            vb = db.get(k)
            if vb is not None:
                dot += va * float(vb)

        na = sum(v * v for v in da.values())
        nb = sum(v * v for v in db.values())
        denom = na + nb - dot
        if denom == 0.0:
            # both zero
            return 1.0
        return float(dot / denom)

    # dense-dense
    if not _is_sparse_counts(a) and not _is_sparse_counts(b):
        va = _as_dense_counts(a)
        vb = _as_dense_counts(b)
        if va.shape != vb.shape:
            raise ValueError("Dense count vectors must have the same length")
        _validate_nonnegative_dense(va)
        _validate_nonnegative_dense(vb)

        dot = float(np.dot(va, vb))
        na = float(np.dot(va, va))
        nb = float(np.dot(vb, vb))
        denom = na + nb - dot
        if denom == 0.0:
            return 1.0
        return float(dot / denom)

    # sparse-dense (or dense-sparse)
    if _is_sparse_counts(a):
        da = {int(k): float(v) for k, v in a.items()}
        vb = _as_dense_counts(b)
        _validate_nonnegative_sparse(da)
        _validate_nonnegative_dense(vb)
        dot = 0.0
        na = 0.0
        for k, va in da.items():
            if 0 <= k < vb.shape[0]:
                dot += va * float(vb[k])
            na += va * va
        nb = float(np.dot(vb, vb))
        denom = na + nb - dot
        if denom == 0.0:
            return 1.0
        return float(dot / denom)

    # dense-sparse
    return tanimoto_similarity_counts(b, a)


def tanimoto_distance_counts(a: CountFP, b: CountFP) -> float:
    """Generalized Tanimoto distance for count vectors (1 - similarity)."""
    return 1.0 - tanimoto_similarity_counts(a, b)


__all__ = [
    "BitFP",
    "CountFP",
    "tanimoto_similarity_bits",
    "tanimoto_distance_bits",
    "tanimoto_similarity_counts",
    "tanimoto_distance_counts",
]


