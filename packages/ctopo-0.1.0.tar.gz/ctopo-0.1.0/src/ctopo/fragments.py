"""Fragmentation utilities.

This module contains RDKit-based helpers to decompose a Complex into ligand fragments
without reconstructing ligand RDKit molecules from graphs.

Current scope (v1):
- Bridging ligands are not handled specially: removing metal centers may split a bridging
  ligand into multiple fragments. This is expected behavior for now.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple, Union

from rdkit import Chem

from ctopo.core.complex import Complex
from ctopo.core.ligand import Ligand, SmilesSettings, SvgSettings, ligand_from_mol


def _set_orig_idx_props(mol: Chem.Mol, prop: str = 'orig_idx') -> None:
    for i, a in enumerate(mol.GetAtoms()):
        a.SetIntProp(prop, int(i))


def _remove_atoms_by_index(mol: Chem.Mol, atom_indices: Sequence[int]) -> Chem.Mol:
    rw = Chem.RWMol(mol)
    for idx in sorted({int(i) for i in atom_indices}, reverse=True):
        rw.RemoveAtom(int(idx))
    return rw.GetMol()


@dataclass(frozen=True, slots=True)
class LigandCount:
    """Unique ligand representative with occurrence count."""
    smiles: str
    ligand: Ligand
    count: int


def ligands_from_complex(
    complex: Complex,
    sanitize_frags: bool = True,
    smiles_settings: Optional[SmilesSettings] = None,
    svg_settings: Optional[SvgSettings] = None,
) -> List[LigandCount]:
    """Extract ligand fragments from a Complex via RDKit fragmentation.

    Assumptions:
      - `complex.metal_atoms` and `complex.donor_atoms` are correct (e.g. Complex was
        created via `ctopo.core.complex.complex_from_mol` which validates coordination).

    Algorithm:
      - copy complex.mol
      - annotate atoms with int prop 'orig_idx'
      - remove metal atoms
      - split into fragments via Chem.GetMolFrags(asMols=True)
      - for each fragment, recover donor atoms by checking orig_idx ∈ complex.donor_atoms
      - build Ligand objects from fragments
      - compute unique ligands by canonical+isomeric SMILES (canonical=True, isomericSmiles=True)

    Args:
        complex: cTopo Complex object.
        sanitize_frags: Passed to RDKit GetMolFrags(sanitizeFrags=...). Default True.
        smiles_settings: Optional Ligand visualization default SMILES settings to store.
        svg_settings: Optional Ligand visualization default SVG settings to store.

    Returns:
        list of LigandCount (unique ligands with counts), sorted by SMILES.

    Raises:
        TypeError: If complex.mol is None.
    """
    if complex.mol is None:
        raise TypeError('complex.mol must be an RDKit Mol, got None')

    mol = Chem.Mol(complex.mol)
    _set_orig_idx_props(mol, prop='orig_idx')

    metal_atoms = sorted(int(i) for i in complex.metal_atoms)
    donor_orig: Set[int] = {int(i) for i in complex.donor_atoms}

    mol_no_metals = _remove_atoms_by_index(mol, metal_atoms)

    frags = Chem.GetMolFrags(mol_no_metals, asMols=True, sanitizeFrags=bool(sanitize_frags))

    all_ligands: List[Ligand] = []
    for frag in frags:
        donors_in_frag: List[int] = []
        for a in frag.GetAtoms():
            if a.HasProp('orig_idx') and int(a.GetIntProp('orig_idx')) in donor_orig:
                donors_in_frag.append(int(a.GetIdx()))

        if not donors_in_frag:
            continue

        lig = ligand_from_mol(
            frag,
            donors_in_frag,
            smiles_settings=smiles_settings,
            svg_settings=svg_settings,
        )
        all_ligands.append(lig)

    counts: Dict[str, int] = {}
    reps: Dict[str, Ligand] = {}
    for lig in all_ligands:
        m = Chem.Mol(lig.mol)
        for idx in lig.donor_atoms:
            m.GetAtomWithIdx(idx).SetAtomMapNum(1)
        key = Chem.MolToSmiles(m, canonical=True, isomericSmiles=True)
        counts[key] = counts.get(key, 0) + 1
        if key not in reps:
            reps[key] = lig

    unique_counts: List[LigandCount] = [
        LigandCount(smiles=smi, ligand=reps[smi], count=int(counts[smi]))
        for smi in sorted(reps.keys())
    ]

    return unique_counts


__all__ = [
    'LigandCount',
    'ligands_from_complex',
]


