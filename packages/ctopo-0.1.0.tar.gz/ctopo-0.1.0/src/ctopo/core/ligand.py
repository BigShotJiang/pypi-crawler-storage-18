"""Ligand graph object and construction from an RDKit molecule.

A Ligand is defined by:
  - an RDKit Mol (source of truth)
  - a NetworkX graph representation of that Mol
  - an atom partition into donors, skeleton, and substituents

Partition rule (ligand):
  - donor_atoms are provided by the caller
  - skeleton_atoms are atoms on *any* shortest path between any donor pair (excluding donors)
  - substituent_atoms are all remaining atoms
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import FrozenSet, Optional, Sequence, Tuple

import networkx as nx
from rdkit import Chem

from ctopo.core.atom_types import AtomType
from ctopo.core.graph import mol_to_nx
from ctopo.core.partition import skeleton_from_donors, validate_atom_indices


@dataclass(frozen=True, slots=True)
class SmilesSettings:
    """Settings for SMILES generation.

    Mirrors `PreparedMol.to_smiles()` in `ctopo.visuals`.
    """

    canonical: bool = True
    isomeric: bool = False

    def as_kwargs(self) -> dict:
        return {'canonical': self.canonical, 'isomeric': self.isomeric}


@dataclass(frozen=True, slots=True)
class SvgSettings:
    """Settings for SVG generation.

    Mirrors `PreparedMol.to_svg()` in `ctopo.visuals`.
    """

    size: Tuple[int, int] = (300, 220)
    line_width: int = 2
    add_atom_indices: bool = False

    def as_kwargs(self) -> dict:
        return {
            'size': self.size,
            'line_width': self.line_width,
            'add_atom_indices': self.add_atom_indices,
        }


@dataclass(frozen=True, slots=True)
class LigandVisualization:
    """Simple output container for ligand visualizations."""

    smiles: str
    svg: str


@dataclass(frozen=True, slots=True)
class Ligand:
    """Ligand represented as an RDKit molecule plus a NetworkX graph and atom partitions.

    Attributes:
        mol: RDKit molecule
        G: NetworkX graph with node attributes
        donor_atoms: Frozen set of donor atom indices
        skeleton_atoms: Frozen set of skeleton atom indices (excluding donors)
        substituent_atoms: Frozen set of substituent atom indices
        smiles_settings: Default settings for SMILES generation in visualization helpers
        svg_settings: Default settings for SVG generation in visualization helpers

    Visualization:
        The methods `visualize_ligand`, `visualize_skeleton`, and `visualize_topology`
        return (smiles, svg) pairs that are convenient for building dataset browsers.

        Keyword arguments for visual style are forwarded to the corresponding functions
        in `ctopo.visuals`:
          - `visualize_ligand`   -> `ctopo.visuals.prepare_ligand_visual`
          - `visualize_skeleton` -> `ctopo.visuals.prepare_skeleton_visual`
          - `visualize_topology` -> `ctopo.visuals.prepare_topology_visual`

        See `ctopo.visuals` for the available options.
    """

    mol: Chem.Mol
    G: nx.Graph
    donor_atoms: FrozenSet[int]
    skeleton_atoms: FrozenSet[int]
    substituent_atoms: FrozenSet[int]
    smiles_settings: SmilesSettings = field(default_factory=SmilesSettings)
    svg_settings: SvgSettings = field(default_factory=SvgSettings)

    @property
    def denticity(self) -> int:
        """Returns ligand's denticity"""
        return len(self.donor_atoms)

    def visualize_ligand(self, **kwargs) -> LigandVisualization:
        """Return ligand visualization (SMILES with donor maps + chemical-like SVG).

        Keyword arguments are forwarded to `ctopo.visuals.prepare_ligand_visual`.
        See `ctopo.visuals` for available options.
        """
        from ctopo.visuals import prepare_ligand_visual

        prepared = prepare_ligand_visual(self, **kwargs)
        return LigandVisualization(
            smiles=prepared.to_smiles(**self.smiles_settings.as_kwargs()),
            svg=prepared.to_svg(**self.svg_settings.as_kwargs()),
        )

    def visualize_skeleton(
        self,
        donors: bool = True,
        skeleton: bool = True,
        bonds: bool = True,
        **kwargs,
    ) -> LigandVisualization:
        """Return skeleton visualization (SMILES + SVG) for this ligand.

        Args:
            donors: If True, donor atoms are shown as original elements. If False,
                donors are dummies labeled 'DA'.
            skeleton: If True, skeleton atoms are shown as original elements. If False,
                skeleton atoms are dummies with empty labels.
            bonds: If True, keep original bond orders from the skeleton graph.
                If False, force all bonds to be single.

        Keyword arguments are forwarded to `ctopo.visuals.prepare_skeleton_visual`.
        See `ctopo.visuals` for available options.
        """
        from ctopo.topology import get_ligands_skeleton
        from ctopo.visuals import prepare_skeleton_visual

        G_skel = get_ligands_skeleton(self.G)
        prepared = prepare_skeleton_visual(
            G_skel,
            use_original_donor_atoms=donors,
            use_original_skeleton_atoms=skeleton,
            use_original_bonds=bonds,
            **kwargs,
        )
        return LigandVisualization(
            smiles=prepared.to_smiles(**self.smiles_settings.as_kwargs()),
            svg=prepared.to_svg(**self.svg_settings.as_kwargs()),
        )

    def visualize_topology(
        self,
        donors: bool = False,
        **kwargs,
    ) -> LigandVisualization:
        """Return topology visualization (SMILES + SVG) for this ligand.

        Args:
            donors: If True, donor atoms are shown as original elements. If False,
                donors are dummies labeled 'DA'. Non-donor atoms are always dummies
                with empty labels in the topology depiction.

        Keyword arguments are forwarded to `ctopo.visuals.prepare_topology_visual`.
        See `ctopo.visuals` for available options.
        """
        from ctopo.topology import get_ligands_topology
        from ctopo.visuals import prepare_topology_visual

        G_topo = get_ligands_topology(self.G)
        prepared = prepare_topology_visual(
            G_topo,
            use_original_donor_atoms=donors,
            **kwargs,
        )
        return LigandVisualization(
            smiles=prepared.to_smiles(**self.smiles_settings.as_kwargs()),
            svg=prepared.to_svg(**self.svg_settings.as_kwargs()),
        )


def ligand_from_mol(
    mol: Chem.Mol,
    donor_atoms: Sequence[int],
    smiles_settings: Optional[SmilesSettings] = None,
    svg_settings: Optional[SvgSettings] = None,
) -> Ligand:
    """Construct a Ligand from an RDKit Mol and explicit donor atom indices.

    Args:
        mol: RDKit molecule.
        donor_atoms: Atom indices that should be treated as donor atoms.
        smiles_settings: Optional default SMILES settings stored in the Ligand and
            used by visualization helpers.
        svg_settings: Optional default SVG settings stored in the Ligand and
            used by visualization helpers.

    Returns:
        Ligand instance with populated graph and atom partitions.

    Raises:
        TypeError: If `mol` is None or donor_atoms contains non-integers.
        ValueError: If donor atom indices are out of range.
        nx.NodeNotFound: If a donor index is not present in the graph.
    """
    if mol is None:
        raise TypeError('mol must be an RDKit Mol, got None')

    for a in mol.GetAtoms():
        a.SetAtomMapNum(0)

    n = mol.GetNumAtoms()
    donors = validate_atom_indices(n, donor_atoms, 'donor_atoms')

    G = mol_to_nx(mol)

    donor_set = set(donors)
    skel_candidate = skeleton_from_donors(G, donors)

    skeleton_atoms = set(skel_candidate) - donor_set
    substituent_atoms = set(G.nodes) - donor_set - skeleton_atoms

    for i in substituent_atoms:
        G.nodes[i]['atom_type'] = int(AtomType.SUBSTITUENT)
    for i in skeleton_atoms:
        G.nodes[i]['atom_type'] = int(AtomType.SKELETON)
    for i in donor_set:
        G.nodes[i]['atom_type'] = int(AtomType.DONOR)

    return Ligand(
        mol=mol,
        G=G,
        donor_atoms=frozenset(donors),
        skeleton_atoms=frozenset(skeleton_atoms),
        substituent_atoms=frozenset(substituent_atoms),
        smiles_settings=smiles_settings or SmilesSettings(),
        svg_settings=svg_settings or SvgSettings(),
    )


__all__ = [
    'SmilesSettings',
    'SvgSettings',
    'LigandVisualization',
    'Ligand',
    'ligand_from_mol',
]


