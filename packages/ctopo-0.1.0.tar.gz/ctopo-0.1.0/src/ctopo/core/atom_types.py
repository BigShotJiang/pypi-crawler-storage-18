"""Shared atom-type codes used in ligand/complex partitioning."""

from enum import IntEnum


class AtomType(IntEnum):
    """Atom partition labels stored in graph node attribute `atom_type`."""
    UNDEFINED = -1
    SUBSTITUENT = 0
    SKELETON = 1
    DONOR = 2
    CENTER = 3
    METAL = 3 # alias


__all__ = [
    'AtomType',
]


