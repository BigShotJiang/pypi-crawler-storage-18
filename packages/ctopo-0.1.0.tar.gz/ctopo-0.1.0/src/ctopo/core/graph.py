"""NetworkX-based chemical graph initialized from an RDKit Mol.

This module provides a single conversion utility that maps an RDKit molecule to an
undirected NetworkX graph with atom and bond attributes.
"""

from __future__ import annotations

import networkx as nx
from rdkit import Chem

from ctopo.core.atom_types import AtomType


def mol_to_nx(mol: Chem.Mol) -> nx.Graph:
    """Transform an RDKit Mol into a NetworkX Graph.

    Adds two extra node attributes useful for atom-pair / topological-torsion style
    atom typing:
      - heavy_degree: number of non-hydrogen neighbors (independent of whether H are explicit)
      - num_pi_electrons: RDKit-style "pi count" used in atom-pairs/torsions (aromatic -> 1,
        otherwise (heavy_valence - heavy_degree), rounded and floored at 0)

    Args:
        mol: RDKit molecule to convert.

    Returns:
        A NetworkX undirected graph whose nodes correspond to atom indices.

    Raises:
        TypeError: If `mol` is None.
    """
    if mol is None:
        raise TypeError('mol must be an RDKit Mol, got None')

    # update properties for RWMol-created mols
    mol.UpdatePropertyCache(strict=False)

    G = nx.Graph()
    sym_ranks = Chem.CanonicalRankAtoms(mol, breakTies=False)

    # nodes
    for i in range(mol.GetNumAtoms()):
        a = mol.GetAtomWithIdx(i)

        # heavy-atom connectivity (robust to explicit/implicit H)
        heavy_degree = sum(1 for n in a.GetNeighbors() if n.GetAtomicNum() > 1)

        # "heavy valence" = sum of bond orders to heavy neighbors only
        heavy_valence = 0.0
        for b in a.GetBonds():
            other = b.GetOtherAtom(a)
            if other.GetAtomicNum() > 1:
                heavy_valence += float(b.GetBondTypeAsDouble())

        # RDKit-style pi-count used in atom-pairs/torsions:
        # aromatic => 1, else max(0, heavy_valence - heavy_degree)
        if a.GetIsAromatic():
            num_pi_electrons = 1
        else:
            num_pi_electrons = int(round(max(0.0, heavy_valence - float(heavy_degree))))

        G.add_node(
            i,
            idx=i,
            symbol=a.GetSymbol(),
            Z=int(a.GetAtomicNum()),
            degree=int(a.GetTotalDegree()),
            heavy_degree=int(heavy_degree),
            num_pi_electrons=int(num_pi_electrons),
            num_hs=int(a.GetTotalNumHs()),
            charge=int(a.GetFormalCharge()),
            aromatic=bool(a.GetIsAromatic()),
            in_ring=bool(a.IsInRing()),
            isotope=int(a.GetIsotope() or 0),
            map_number=int(a.GetAtomMapNum() or 0),
            chiral_tag=int(a.GetChiralTag()),
            cip_code=a.GetProp('_CIPCode') if a.HasProp('_CIPCode') else '',
            symmetry_rank=int(sym_ranks[i]),
            atom_type=int(AtomType.UNDEFINED),
        )

    # edges
    for b in mol.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        G.add_edge(
            i,
            j,
            idx=int(b.GetIdx()),
            bond_type=str(b.GetBondType()),
            bond_code=int(b.GetBondType()),
            bond_order=float(b.GetBondTypeAsDouble()),
            bond_direction=(i, j),
            is_dative=(str(b.GetBondType()) == 'DATIVE'),
            aromatic=bool(b.GetIsAromatic()),
            in_ring=bool(b.IsInRing()),
        )

    return G


__all__ = [
    'mol_to_nx',
]


