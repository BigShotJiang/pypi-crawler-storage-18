"""Complex graph object and construction from an RDKit molecule.

A Complex is defined by:
  - an RDKit Mol (source of truth)
  - a NetworkX graph representation of that Mol
  - an atom partition into metals, donors, skeleton, and substituents

Partition rule (complex):
  - metal_atoms are provided by the caller
  - donor_atoms are all neighbors of metal_atoms (excluding metals)
  - metals are removed from the graph
  - skeleton_atoms are atoms on *any* shortest path between any donor pair (excluding donors)
  - substituent_atoms are all remaining non-metal atoms
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import FrozenSet, Sequence

import networkx as nx
from rdkit import Chem

from ctopo.core.atom_types import AtomType
from ctopo.core.graph import mol_to_nx
from ctopo.core.partition import skeleton_from_donors, validate_atom_indices


def _is_dative_bond(b: Chem.Bond) -> bool:
    bt = str(b.GetBondType())
    return bt in ('DATIVE', 'DATIVEL', 'DATIVER')


def _validate_metal_bonding(mol: Chem.Mol, metal_atoms: set[int]) -> None:
    """Validate coordination encoding around metal atoms.

    Rules:
      - Metal–nonmetal bonds must be dative and oriented donor -> metal
        (metal is the end atom of the dative bond).
      - Metal–metal bonds are allowed, but must be non-dative.
    """
    for m in sorted(metal_atoms):
        a = mol.GetAtomWithIdx(int(m))
        bonds = list(a.GetBonds())
        if len(bonds) == 0:
            raise ValueError(f'metal atom {m} has no bonds')

        for b in bonds:
            other = int(b.GetOtherAtomIdx(int(m)))

            if other in metal_atoms:
                # Metal–metal bonds are allowed but must be non-dative
                if _is_dative_bond(b):
                    raise ValueError(
                        f'metal–metal bond between {m} and {other} must be non-dative '
                        f'(found {str(b.GetBondType())})'
                    )
                continue

            # Metal–nonmetal bonds must be dative and oriented donor -> metal
            if not _is_dative_bond(b):
                raise ValueError(
                    f'metal atom {m} has a non-dative bond to non-metal atom {other} '
                    f'of type {str(b.GetBondType())}'
                )
            if int(b.GetEndAtomIdx()) != int(m):
                raise ValueError(
                    f'dative bond must end at metal atom {m} (found end={b.GetEndAtomIdx()})'
                )
            if int(b.GetBeginAtomIdx()) == int(m):
                raise ValueError(
                    f'dative bond must start at a donor atom and end at metal atom {m}'
                )


@dataclass(frozen=True, slots=True)
class Complex:
    """Complex represented as an RDKit molecule plus a NetworkX graph and atom partitions.

    Attributes:
        mol: RDKit molecule
        G: NetworkX graph with node attributes
        metal_atoms: Frozen set of metal atom indices
        donor_atoms: Frozen set of donor atom indices
        skeleton_atoms: Frozen set of skeleton atom indices (excluding donors)
        substituent_atoms: Frozen set of substituent atom indices
    """

    mol: Chem.Mol
    G: nx.Graph
    metal_atoms: FrozenSet[int]
    donor_atoms: FrozenSet[int]
    skeleton_atoms: FrozenSet[int]
    substituent_atoms: FrozenSet[int]


def complex_from_mol(mol: Chem.Mol, metal_atoms: Sequence[int]) -> Complex:
    """Construct a Complex from an RDKit Mol and explicit metal atom indices.

    Node attribute `atom_type` is assigned as:
      - int(AtomType.CENTER) for metal atoms (metal centers / center atoms)
      - int(AtomType.DONOR) for donor atoms (neighbors of metals, excluding metals)
      - int(AtomType.SKELETON) for skeleton atoms (excluding donors/metals)
      - int(AtomType.SUBSTITUENT) for remaining non-metal atoms

    Skeleton is computed on the graph with metal atoms removed, so shortest paths do not
    traverse metal centers.

    Validity checks (coordination encoding):
      - metal–nonmetal bonds must be dative and oriented donor -> metal (metal is end atom)
      - metal–metal bonds are allowed but must be non-dative

    Args:
        mol: RDKit molecule.
        metal_atoms: Atom indices that should be treated as metal centers.

    Returns:
        Complex instance with populated graph and atom partitions.

    Raises:
        TypeError: If `mol` is None or metal_atoms contains non-integers.
        ValueError: If metal atom indices are out of range or metal_atoms is empty,
            or if bonding validity checks fail.
        nx.NodeNotFound: If a metal index is not present in the graph (shouldn’t happen if mol is consistent).
    """
    if mol is None:
        raise TypeError('mol must be an RDKit Mol, got None')

    for a in mol.GetAtoms():
        a.SetAtomMapNum(0)

    n = mol.GetNumAtoms()
    metals = validate_atom_indices(n, metal_atoms, 'metal_atoms')
    if len(metals) == 0:
        raise ValueError('metal_atoms must be non-empty for Complex construction')

    metal_set = set(metals)

    # Validate coordination encoding on the RDKit Mol (independent of graph conversion).
    _validate_metal_bonding(mol, metal_set)

    G = mol_to_nx(mol)

    # Donors = neighbors of metals (excluding metals)
    donor_set: set[int] = set()
    for m in metals:
        for nbr in G.neighbors(m):
            if nbr not in metal_set:
                donor_set.add(int(nbr))

    # Build a metal-removed graph for skeleton detection
    G_no_metals = G.subgraph(set(G.nodes) - metal_set)

    # Skeleton candidate includes donors; skeleton_atoms excludes donors
    skel_candidate = skeleton_from_donors(G_no_metals, sorted(donor_set))
    skeleton_atoms = set(skel_candidate) - donor_set

    # Substituents are remaining non-metal atoms not in donor/skeleton
    substituent_atoms = set(G_no_metals.nodes) - donor_set - skeleton_atoms

    # Assign atom_type codes on the FULL graph
    for i in substituent_atoms:
        G.nodes[i]['atom_type'] = int(AtomType.SUBSTITUENT)
    for i in skeleton_atoms:
        G.nodes[i]['atom_type'] = int(AtomType.SKELETON)
    for i in donor_set:
        G.nodes[i]['atom_type'] = int(AtomType.DONOR)
    for i in metal_set:
        G.nodes[i]['atom_type'] = int(AtomType.CENTER)

    return Complex(
        mol=mol,
        G=G,
        metal_atoms=frozenset(metals),
        donor_atoms=frozenset(donor_set),
        skeleton_atoms=frozenset(skeleton_atoms),
        substituent_atoms=frozenset(substituent_atoms),
    )


__all__ = [
    'Complex',
    'complex_from_mol',
]


