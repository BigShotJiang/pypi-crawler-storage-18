"""Core graph objects and partitioning algorithms for cTopo.

The `ctopo.core` package contains the fundamental data structures and logic for
representing ligands and coordination complexes as NetworkX graphs derived from
RDKit molecules.

Key concepts:
- `AtomType`: integer-coded node labels used for partitioning atoms into
  UNDEFINED / SUBSTITUENT / SKELETON / DONOR / CENTER.
- `mol_to_nx`: conversion of an RDKit `Mol` to a schema-stable NetworkX graph.
- `ligand_from_mol`, `complex_from_mol`: constructors that assign `atom_type`
  and compute donor/skeleton/substituent partitions according to cTopo rules.
"""

from ctopo.core.atom_types import AtomType
from ctopo.core.graph import mol_to_nx
from ctopo.core.ligand import (
    SmilesSettings,
    SvgSettings,
    Ligand,
    ligand_from_mol,
)
from ctopo.core.complex import Complex, complex_from_mol

__all__ = [
    'AtomType',
    'mol_to_nx',
    'Ligand',
    'ligand_from_mol',
    'Complex',
    'complex_from_mol',
]


