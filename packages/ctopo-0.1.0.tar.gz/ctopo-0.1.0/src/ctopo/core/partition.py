"""Graph-based partitioning utilities (donors/skeleton/substituents) for chemical graphs.

This module contains shared helper functions used by Ligand and Complex constructors,
including validation of atom indices and skeleton construction from donor atoms.
"""

from __future__ import annotations

from collections.abc import Iterable, Sequence
from itertools import combinations

import networkx as nx


def validate_atom_indices(n_atoms: int, indices: Iterable[int], name: str) -> list[int]:
    """Validate and normalize a collection of atom indices.

    Args:
        n_atoms: Number of atoms in the parent molecule/graph.
        indices: Iterable of atom indices to validate.
        name: Name of the parameter for error messages.

    Returns:
        Sorted list of unique valid indices.

    Raises:
        TypeError: If any index is not an int
        ValueError: If any index is out of range [0, n_atoms - 1].
    """
    out: list[int] = []

    for i in indices:
        if isinstance(i, bool) or not isinstance(i, int):
            raise TypeError(f'{name} must contain ints; got {type(i)}')
        if i < 0 or i >= n_atoms:
            raise ValueError(f'{name} index {i} out of range [0, {n_atoms - 1}]')
        out.append(i)

    return sorted(set(out))


def skeleton_from_donors(G: nx.Graph, donor_atoms: Sequence[int]) -> set[int]:
    """Union of nodes on all shortest paths between all donor-atom pairs.

    Args:
        G: NetworkX graph where nodes are atom indices.
        donor_atoms: Donor atom node indices.

    Returns:
        Set of atom indices on shortest paths between donor pairs (may include donors).

    Raises:
        nx.NodeNotFound: If a donor index is not present in G.
    """
    donors = list(donor_atoms)
    if len(donors) < 2:
        return set()

    skel: set[int] = set()

    for s, t in combinations(donors, 2):
        try:
            for path in nx.all_shortest_paths(G, s, t):
                skel.update(path)
        except nx.NetworkXNoPath:
            continue

    return skel


__all__ = [
    'validate_atom_indices',
    'skeleton_from_donors',
]


