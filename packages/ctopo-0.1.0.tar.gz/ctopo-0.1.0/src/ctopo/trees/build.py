"""Hierarchy builder for ligand datasets.

This module builds a hierarchical representation of a ligand dataset as a directed
acyclic graph (a tree in the typical configuration), where internal nodes correspond
to progressively more detailed structural abstractions and leaves correspond to
individual ligands (or unique ligands if `collapse_leaves=True`).

The intended high-level hierarchy is:

    denticity -> topology -> skeleton -> ligand

Where:
- denticity is `Ligand.denticity` (number of donor atoms),
- topology is the reduced donor-linker topology graph (computed by `get_ligands_topology`),
- skeleton is the ligand skeleton subgraph (computed by `get_ligands_skeleton`),
- ligand leaves represent the original ligand depiction/SMILES.

Levels are configured using `LevelSpec` objects (or short tuple forms such as
`('skeleton', 'da', 'bonds')`). Each level yields a grouping key (SMILES) and, for
non-denticity nodes, a thumbnail SVG depiction.

Monotonic detail constraint
--------------------------
The level sequence must be hierarchical not only in kind (denticity -> topo -> skeleton -> ligand),
but also in the information content ("flags") between adjacent levels.

Example (valid):
    ('skeleton', 'da') -> ('skeleton', 'da', 'bonds')

Example (invalid, loses information):
    ('skeleton', 'da') -> ('skeleton', 'bonds')

This constraint is validated by `validate_levels`.

Performance notes
-----------------
Generating SVG depictions can be expensive. The builder avoids redundant work by:
- computing SMILES keys per ligand per level (cheap),
- generating SVG only once per unique (level, SMILES) node,
- optionally disabling leaf SVG generation (`include_leaf_svg=False`).

Output graph format
-------------------
The returned object is an `nx.DiGraph` with node attributes suitable for downstream rendering.
At minimum, nodes store:
- kind: 'root' | 'denticity' | 'topo' | 'skeleton' | 'ligand'
- level: a tuple identifier of the level
- label: short label
- smiles: grouping key (None for root/denticity)
- svg: thumbnail (None for root/denticity and optionally leaves)
- leaf_count: number of leaf ligands under the node

The graph is expected to be a tree for `tree_to_html`:
each node (except root) has exactly one parent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

import networkx as nx
from rdkit import Chem

from ctopo.core.ligand import Ligand
from ctopo.topology import get_ligands_skeleton, get_ligands_topology
from ctopo.visuals import (
    prepare_ligand_visual,
    prepare_skeleton_visual,
    prepare_topology_visual,
)

LevelId = Union[str, Sequence[str]]


def _norm_flag(x: str) -> str:
    return str(x).strip().lower()


_KIND_RANK: Dict[str, int] = {
    'denticity': 0,
    'topo': 1,
    'topology': 1,
    'skeleton': 2,
    'ligand': 3,
}


@dataclass(frozen=True, slots=True)
class LevelSpec:
    """A single hierarchy level specification.

    A `LevelSpec` defines how ligands are grouped at a particular level of the hierarchy.

    Parameters:
        kind:
            One of: 'denticity', 'topo' (or 'topology'), 'skeleton', 'ligand'.
        flags:
            A set of optional modifiers affecting how the grouping key and depiction are produced.

    Supported flags (case-insensitive):
        'da':
            Preserve original donor atom elements in depictions/SMILES where applicable
            (otherwise donors are shown as dummy atoms labelled 'DA').
        'bonds' (skeleton only):
            Preserve original bond orders in skeleton depictions/SMILES (otherwise all single).
        'skeleton' (skeleton only):
            Preserve original elements for skeleton atoms (otherwise dummy atoms).

    Notes:
        `validate_levels` enforces that adjacent levels are monotone in the information they retain,
        so that a later level never 'forgets' a previously requested feature.
    """

    kind: str
    flags: frozenset[str] = field(default_factory=frozenset)

    @property
    def kind_norm(self) -> str:
        k = _norm_flag(self.kind)
        if k == 'topology':
            return 'topo'
        return k

    @property
    def id(self) -> Tuple[str, ...]:
        parts = [self.kind_norm]
        for f in sorted(self.flags):
            parts.append(f)
        return tuple(parts)

    @property
    def features(self) -> frozenset[str]:
        """Features that must not be lost across adjacent levels."""
        k = self.kind_norm
        feats: set[str] = set()

        if k in ('topo', 'skeleton'):
            if 'da' in self.flags:
                feats.add('da')

        if k == 'skeleton':
            if 'bonds' in self.flags:
                feats.add('bonds')
            if 'skeleton' in self.flags:
                feats.add('skeleton')

        if k == 'ligand':
            feats.update({'da', 'bonds', 'skeleton'})

        return frozenset(feats)

    def short_label(self) -> str:
        k = self.kind_norm
        if k == 'denticity':
            return 'denticity'
        if k == 'ligand':
            return 'ligand'
        if not self.flags:
            return k
        flag_txt = '+'.join(f.upper() if f == 'da' else f for f in sorted(self.flags))
        return f'{k}+{flag_txt}'


def level_spec(level: Union[LevelSpec, LevelId]) -> LevelSpec:
    """Creates LevelSpec object from text description"""
    if isinstance(level, LevelSpec):
        return level
    if isinstance(level, str):
        parts = (level,)
    else:
        parts = tuple(level)
        if len(parts) == 0:
            raise ValueError('empty level spec')

    kind = str(parts[0])
    flags = frozenset(_norm_flag(x) for x in parts[1:])
    return LevelSpec(kind=kind, flags=flags)


def validate_levels(levels: Sequence[Union[LevelSpec, LevelId]], *, require_leaf: bool = True) -> List[LevelSpec]:
    """Validate and normalize a sequence of level specifications.

    This function enforces two constraints:

    1) Kind order:
       The level kinds must follow the structural hierarchy:
           denticity -> topo -> skeleton -> ligand

    2) Monotone information retention:
       Adjacent levels must not lose features. For example:
           ('skeleton', 'da') -> ('skeleton', 'da', 'bonds')  is valid
           ('skeleton', 'da') -> ('skeleton', 'bonds')        is invalid (drops 'da')

    Args:
        levels:
            Sequence of `LevelSpec` or short forms:
              - 'denticity'
              - ('topo',) or ('topo', 'da')
              - ('skeleton',), ('skeleton', 'bonds'), ('skeleton', 'da', 'bonds'), ...
              - 'ligand'
        require_leaf:
            If True, the last level must be 'ligand'.

    Returns:
        A list of normalized `LevelSpec` instances.

    Raises:
        ValueError: if levels are empty, contain unknown kinds, violate kind ordering,
            violate monotonicity, or (if require_leaf=True) do not end with 'ligand'.
    """
    specs = [level_spec(lv) for lv in levels]
    if len(specs) == 0:
        raise ValueError('levels must be non-empty')

    # Normalize kind names
    specs = [LevelSpec(kind=s.kind_norm, flags=s.flags) for s in specs]

    # Kind order + monotone features
    for i in range(len(specs) - 1):
        a = specs[i]
        b = specs[i + 1]

        ra = _KIND_RANK.get(a.kind_norm)
        rb = _KIND_RANK.get(b.kind_norm)
        if ra is None or rb is None:
            raise ValueError(f'unknown level kind: {a.kind_norm!r} or {b.kind_norm!r}')

        if rb < ra:
            raise ValueError(f'level order must be denticity -> topo -> skeleton -> ligand, got {a.kind_norm} -> {b.kind_norm}')

        if not (a.features <= b.features):
            raise ValueError(
                f'levels must be monotone in features, got {a.id} -> {b.id} '
                f'({sorted(a.features)} -> {sorted(b.features)})'
            )

    if require_leaf and specs[-1].kind_norm != 'ligand':
        raise ValueError('last level must be ligand (leaf)')

    return specs


def _smiles_metrics(smiles: str, cache: Dict[str, Tuple[int, int, int, int]]) -> Tuple[int, int, int, int]:
    """Return (n_atoms, n_bonds, branching, rings) for sorting."""
    if smiles in cache:
        return cache[smiles]
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        out = (10**9, 10**9, 10**9, 10**9)
        cache[smiles] = out
        return out

    n_atoms = mol.GetNumAtoms()
    n_bonds = mol.GetNumBonds()
    branching = sum(max(0, int(a.GetTotalDegree()) - 2) for a in mol.GetAtoms())
    rings = int(mol.GetRingInfo().NumRings())
    out = (int(n_atoms), int(n_bonds), int(branching), int(rings))
    cache[smiles] = out
    return out


def build_ligand_tree(
    ligands: Sequence[Ligand],
    levels: Sequence[Union[LevelSpec, LevelId]] = (
        'denticity',
        ('topo',),
        ('skeleton',),
        ('skeleton', 'bonds'),
        ('skeleton', 'da', 'bonds'),
        'ligand',
    ),
    ligand_ids: Optional[Sequence[str]] = None,
    collapse_leaves: bool = False,
    include_leaf_svg: bool = True,
    topo_kwargs: Optional[Mapping[str, Any]] = None,
    skeleton_kwargs: Optional[Mapping[str, Any]] = None,
    ligand_kwargs: Optional[Mapping[str, Any]] = None,
) -> nx.DiGraph:
    """Build a hierarchical tree (as an `nx.DiGraph`) for a ligand dataset.

    The resulting graph groups ligands by successive abstractions defined by `levels`.
    Internal nodes represent unique groups at each level; leaf nodes represent ligands.

    Args:
        ligands:
            Input ligands.
        levels:
            Level specification sequence. See `LevelSpec` and `validate_levels`.
        ligand_ids:
            Optional stable identifiers for ligands, used for leaf labels (non-collapsed mode)
            and for leaf example lists (collapsed mode).
        collapse_leaves:
            If False, create one leaf node per input ligand.
            If True, create one leaf node per unique ligand SMILES and store occurrences in `count`.
        include_leaf_svg:
            If True, leaf nodes store an SVG depiction. If False, leaves have `svg=None`.
        topo_kwargs:
            Optional keyword arguments forwarded to `ctopo.visuals.prepare_topology_visual`.
        skeleton_kwargs:
            Optional keyword arguments forwarded to `ctopo.visuals.prepare_skeleton_visual`.
        ligand_kwargs:
            Optional keyword arguments forwarded to `ctopo.visuals.prepare_ligand_visual`.
    Returns:
        An `nx.DiGraph` rooted at a single `'root'` node.

        Node attributes typically include: `kind`, `level`, `label`, `smiles`, `svg`,
        `leaf_count`, and `sort_key`.

        Leaf nodes additionally include `count` and (in non-collapsed mode) `source_index`
        and/or `source_id`.

    Notes:
        SVG generation is performed only for unique nodes per level (and optionally leaves),
        to reduce overhead on large datasets.
    """
    specs = validate_levels(levels, require_leaf=True)

    if ligand_ids is not None and len(ligand_ids) != len(ligands):
        raise ValueError('ligand_ids must match ligands length')

    topo_kwargs = dict(topo_kwargs or {})
    skeleton_kwargs = dict(skeleton_kwargs or {})
    ligand_kwargs = dict(ligand_kwargs or {})

    G = nx.DiGraph()
    next_id = 0

    def new_node_id() -> int:
        nonlocal next_id
        nid = next_id
        next_id += 1
        return nid

    root = new_node_id()
    G.add_node(
        root,
        kind='root',
        level=('root',),
        label='root',
        smiles=None,
        svg=None,
        leaf_count=0,
        sort_key=[0, 0, 0, 0, ''],
    )

    # Maps for unique grouping nodes per level
    group_nodes: Dict[Tuple[int, Any], int] = {}
    leaf_nodes: Dict[str, int] = {}

    metrics_cache: Dict[str, Tuple[int, int, int, int]] = {}

    for idx, lig in enumerate(ligands):
        parent = root

        # Precompute graphs only if needed
        need_topo = any(s.kind_norm == 'topo' for s in specs)
        need_skel = any(s.kind_norm == 'skeleton' for s in specs)
        topo_g = get_ligands_topology(lig.G) if need_topo else None
        skel_g = get_ligands_skeleton(lig.G) if need_skel else None

        for li, spec in enumerate(specs):
            k = spec.kind_norm

            if k == 'denticity':
                key = int(lig.denticity)
                map_key = (li, key)
                nid = group_nodes.get(map_key)
                if nid is None:
                    nid = new_node_id()
                    group_nodes[map_key] = nid
                    G.add_node(
                        nid,
                        kind='denticity',
                        level=spec.id,
                        label=f'DA={key}',
                        smiles=None,
                        svg=None,
                        leaf_count=0,
                        sort_key=[key, 0, 0, 0, f'{key}'],
                    )
                if not G.has_edge(parent, nid):
                    G.add_edge(parent, nid)
                parent = nid
                continue

            if k == 'topo':
                assert topo_g is not None
                prepared = prepare_topology_visual(
                    topo_g,
                    use_original_donor_atoms=('da' in spec.flags),
                    **topo_kwargs,
                )
                smiles = prepared.to_smiles(**lig.smiles_settings.as_kwargs())
                map_key = (li, smiles)
                nid = group_nodes.get(map_key)
                if nid is None:
                    nid = new_node_id()
                    group_nodes[map_key] = nid
                    svg = prepared.to_svg(**lig.svg_settings.as_kwargs())
                    m = _smiles_metrics(smiles, metrics_cache)
                    G.add_node(
                        nid,
                        kind='topo',
                        level=spec.id,
                        label=spec.short_label(),
                        smiles=smiles,
                        svg=svg,
                        leaf_count=0,
                        sort_key=[m[0], m[2], m[3], m[1], smiles],
                    )
                if not G.has_edge(parent, nid):
                    G.add_edge(parent, nid)
                parent = nid
                continue

            if k == 'skeleton':
                assert skel_g is not None
                prepared = prepare_skeleton_visual(
                    skel_g,
                    use_original_donor_atoms=('da' in spec.flags),
                    use_original_skeleton_atoms=('skeleton' in spec.flags),
                    use_original_bonds=('bonds' in spec.flags),
                    **skeleton_kwargs,
                )
                smiles = prepared.to_smiles(**lig.smiles_settings.as_kwargs())
                map_key = (li, smiles)
                nid = group_nodes.get(map_key)
                if nid is None:
                    nid = new_node_id()
                    group_nodes[map_key] = nid
                    svg = prepared.to_svg(**lig.svg_settings.as_kwargs())
                    m = _smiles_metrics(smiles, metrics_cache)
                    G.add_node(
                        nid,
                        kind='skeleton',
                        level=spec.id,
                        label=spec.short_label(),
                        smiles=smiles,
                        svg=svg,
                        leaf_count=0,
                        sort_key=[m[0], m[2], m[3], m[1], smiles],
                    )
                if not G.has_edge(parent, nid):
                    G.add_edge(parent, nid)
                parent = nid
                continue

            if k == 'ligand':
                prepared = prepare_ligand_visual(lig, **ligand_kwargs)
                smiles = prepared.to_smiles(**lig.smiles_settings.as_kwargs())

                if collapse_leaves:
                    nid = leaf_nodes.get(smiles)
                    if nid is None:
                        nid = new_node_id()
                        leaf_nodes[smiles] = nid
                        svg = prepared.to_svg(**lig.svg_settings.as_kwargs()) if include_leaf_svg else None
                        m = _smiles_metrics(smiles, metrics_cache)
                        G.add_node(
                            nid,
                            kind='ligand',
                            level=spec.id,
                            label='ligand',
                            smiles=smiles,
                            svg=svg,
                            count=1,
                            leaf_count=0,
                            sort_key=[m[0], m[2], m[3], m[1], smiles],
                            examples=[],
                        )
                    else:
                        G.nodes[nid]['count'] = int(G.nodes[nid].get('count', 1)) + 1
                        ex = G.nodes[nid].get('examples', [])
                        if isinstance(ex, list) and len(ex) < 10:
                            ex.append(ligand_ids[idx] if ligand_ids is not None else str(idx))
                            G.nodes[nid]['examples'] = ex
                else:
                    nid = new_node_id()
                    svg = prepared.to_svg(**lig.svg_settings.as_kwargs()) if include_leaf_svg else None
                    m = _smiles_metrics(smiles, metrics_cache)
                    G.add_node(
                        nid,
                        kind='ligand',
                        level=spec.id,
                        label=(ligand_ids[idx] if ligand_ids is not None else f'ligand {idx}'),
                        smiles=smiles,
                        svg=svg,
                        source_index=int(idx),
                        source_id=(ligand_ids[idx] if ligand_ids is not None else None),
                        count=1,
                        leaf_count=0,
                        sort_key=[m[0], m[2], m[3], m[1], f'{idx}:{smiles}'],
                    )

                if not G.has_edge(parent, nid):
                    G.add_edge(parent, nid)
                parent = nid
                continue

            raise ValueError(f'unsupported level kind: {k!r}')

    # Compute leaf_count bottom-up (supports collapsed leaves with count>1)
    topo_order = list(nx.topological_sort(G))
    for nid in topo_order:
        G.nodes[nid]['leaf_count'] = 0

    for nid in topo_order:
        if G.nodes[nid].get('kind') == 'ligand':
            G.nodes[nid]['leaf_count'] = int(G.nodes[nid].get('count', 1))

    for nid in reversed(topo_order):
        children = list(G.successors(nid))
        if not children:
            continue
        G.nodes[nid]['leaf_count'] = sum(int(G.nodes[c].get('leaf_count', 0)) for c in children)

    return G


__all__ = [
    'LevelSpec',
    'level_spec',
    'validate_levels',
    'build_ligand_tree',
]


