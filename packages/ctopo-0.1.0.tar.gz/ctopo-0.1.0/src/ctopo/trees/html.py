"""HTML renderer for ligand hierarchy trees.

This module turns a ligand hierarchy graph (typically produced by `ctopo.trees.build.build_ligand_tree`)
into a self-contained HTML document that can be opened directly in a web browser.

The output uses simple built-in HTML elements (<details>/<summary>) for collapsible nodes, and
CSS for styling. Child nodes are placed into a scrollable container to keep large branching
factors manageable; by default only a small vertical window is shown while allowing scrolling.

Expected input graph
--------------------
The renderer expects a directed acyclic graph that behaves like a tree:
- exactly one root node (in-degree == 0),
- every other node has exactly one parent (in-degree == 1).

Node attributes used by the renderer:
- svg: an SVG snippet to display as a thumbnail (optional for some nodes)
- label: human-readable label
- kind: node type string (e.g. 'topo', 'skeleton', 'ligand')
- leaf_count: number of ligand leaves under the node (used as a summary statistic)
- sort_key: used to order children consistently

This renderer intentionally avoids external dependencies and keeps the HTML portable.
If you later want a richer UI (search, lazy-loading, virtual scrolling, etc.), this module
can be replaced while keeping the builder output unchanged.
"""

from __future__ import annotations

import html
from typing import Any, Dict, Iterable, List, Optional, Tuple

import networkx as nx


def _find_root(G: nx.DiGraph) -> int:
    roots = [n for n in G.nodes if G.in_degree(n) == 0]
    if len(roots) != 1:
        raise ValueError(f'expected exactly 1 root (in_degree==0), got {len(roots)}')
    return int(roots[0])


def _sorted_children(G: nx.DiGraph, nid: int) -> List[int]:
    kids = list(G.successors(nid))

    def kfun(x: int) -> Tuple[Any, ...]:
        sk = G.nodes[x].get('sort_key')
        if isinstance(sk, (list, tuple)):
            return tuple(sk)
        return (sk,)

    return sorted((int(k) for k in kids), key=kfun)


def tree_to_html(
    G: nx.DiGraph,
    root: Optional[int] = None,
    title: str = 'cTopo ligand tree',
    max_children_visible: int = 5,
    child_item_height_px: int = 120,
    open_root: bool = True,
) -> str:
    """Render a ligand tree into a self-contained HTML string.

    Args:
        G:
            A directed acyclic graph representing a tree. Typically produced by
            `ctopo.trees.build.build_ligand_tree`.
        root:
            Optional explicit root node id. If None, the unique node with in-degree == 0 is used.
        title:
            HTML document title.
        max_children_visible:
            Maximum number of child 'cards' visible in the children container before scrolling.
        child_item_height_px:
            Approximate pixel height of each child item; used to compute container max-height.
        open_root:
            If True, the root node is expanded by default.

    Returns:
        A complete HTML document as a string.

    Raises:
        ValueError: if the graph is not a DAG, does not have exactly one root, or is not tree-like
            (some nodes have multiple parents).
    """
    if root is None:
        root = _find_root(G)
    root = int(root)

    # Basic structural validation (tree-like)
    if not nx.is_directed_acyclic_graph(G):
        raise ValueError('tree_to_html expects an acyclic directed graph')

    for n in G.nodes:
        if int(n) == root:
            continue
        if G.in_degree(n) != 1:
            raise ValueError('tree_to_html expects a tree (each node except root has exactly one parent)')

    max_h = int(max_children_visible) * int(child_item_height_px)

    def node_header(nid: int, idx: Optional[int], total: Optional[int]) -> str:
        nd = G.nodes[nid]
        kind = str(nd.get('kind', 'node'))
        label = str(nd.get('label', kind))
        leaf_count = int(nd.get('leaf_count', 0))

        pos = ''
        if idx is not None and total is not None and total > 0:
            pos = f'<span class="pos">[{idx + 1}/{total}]</span>'

        svg = nd.get('svg')
        thumb = '<div class="thumb empty"></div>'
        if isinstance(svg, str) and svg.strip():
            thumb = f'<div class="thumb">{svg}</div>'

        txt = (
            f'<div class="txt">'
            f'<div class="label">{html.escape(label)} {pos}</div>'
            f'<div class="meta">{html.escape(kind)} · leaves: {leaf_count}</div>'
            f'</div>'
        )
        return f'<div class="head">{thumb}{txt}</div>'

    def render_node(nid: int, idx: Optional[int] = None, total: Optional[int] = None) -> str:
        nd = G.nodes[nid]
        kind = str(nd.get('kind', 'node'))

        children = _sorted_children(G, nid)

        if kind == 'ligand' or len(children) == 0:
            return f'<div class="node leaf">{node_header(nid, idx, total)}</div>'

        open_attr = ''
        if open_root and int(nid) == int(root):
            open_attr = ' open'

        kids_html = []
        for j, c in enumerate(children):
            kids_html.append(render_node(int(c), j, len(children)))

        kids_block = (
            f'<div class="children" style="max-height:{max_h}px">'
            + ''.join(kids_html)
            + '</div>'
        )
        return (
            f'<details class="node"{open_attr}>'
            f'<summary>{node_header(nid, idx, total)}</summary>'
            f'{kids_block}'
            f'</details>'
        )

    body = render_node(root)

    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title>
<style>
  body {{
    font-family: system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
    margin: 16px;
    background: #fff;
    color: #111;
  }}
  .node {{
    margin: 6px 0 6px 14px;
  }}
  summary {{
    cursor: pointer;
    list-style: none;
  }}
  summary::-webkit-details-marker {{
    display: none;
  }}
  .head {{
    display: flex;
    gap: 10px;
    align-items: center;
    border: 1px solid #e6e6e6;
    border-radius: 10px;
    padding: 8px;
    background: #fafafa;
  }}
  .thumb {{
    width: 120px;
    height: 90px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    border-radius: 8px;
    background: #fff;
    border: 1px solid #eee;
  }}
  .thumb svg {{
    max-width: 120px;
    max-height: 90px;
  }}
  .thumb.empty {{
    background: #f0f0f0;
  }}
  .txt .label {{
    font-size: 14px;
    font-weight: 600;
    line-height: 1.2;
  }}
  .txt .meta {{
    font-size: 12px;
    color: #555;
    margin-top: 2px;
  }}
  .pos {{
    font-size: 12px;
    color: #666;
    margin-left: 6px;
    font-weight: 500;
  }}
  .children {{
    margin-left: 22px;
    overflow-y: auto;
    padding-right: 6px;
    border-left: 2px solid #eee;
  }}
  .leaf .head {{
    background: #ffffff;
  }}
</style>
</head>
<body>
{body}
</body>
</html>
"""


__all__ = [
    'tree_to_html',
]


