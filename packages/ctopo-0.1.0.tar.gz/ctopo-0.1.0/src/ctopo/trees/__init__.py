"""Ligand dataset hierarchy tools.

This package provides two layers:

- `ctopo.trees.build`: build a hierarchical, tree-like `networkx.DiGraph` from a list
  of `ctopo.core.ligand.Ligand` objects. The hierarchy is defined by a sequence of
  `LevelSpec` entries (e.g. denticity -> topology -> skeleton -> ligand leaves).

- `ctopo.trees.html`: render such a tree into a simple self-contained HTML document
  suitable for quick interactive browsing in a web browser (collapsible nodes, scrollable
  children lists).

The tree graph produced by `build_ligand_tree` is intended to be reusable:
you can export it to JSON, compute statistics, or render it with other front-ends.

Typical usage:

    from ctopo.trees import build_ligand_tree, tree_to_html
    T = build_ligand_tree(ligands, collapse_leaves=True)
    html = tree_to_html(T)

See `ctopo.trees.build.LevelSpec` for level configuration.
"""

from ctopo.trees.build import LevelSpec, build_ligand_tree, level_spec, validate_levels
from ctopo.trees.html import tree_to_html

__all__ = [
    'LevelSpec',
    'build_ligand_tree',
    'level_spec',
    'validate_levels',
    'tree_to_html',
]


