"""RDKit-backed visualization and SMILES utilities for cTopo graphs.

The core cTopo objects are graph-based (NetworkX). For human-facing
visualizations and canonical string representations (SMILES), RDKit is much
better suited.

This module provides three high-level preparers:

* prepare_ligand_visual   – ligand Mol with donor maps + highlighting.
* prepare_skeleton_visual – skeleton graph -> Mol with configurable restoration
  of elements/bonds.
* prepare_topology_visual – topology graph -> Mol, with donors shown as either
  original elements or as 'DA' labels.

All preparers return a PreparedMol bundle which contains:
  - the RDKit Mol
  - optional atom-label overrides
  - optional highlight information

Donor atoms can be marked by the same atom-map number (:1 by default), which
helps group similar ligands by a stable SMILES key.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Set, Tuple

import networkx as nx
from rdkit import Chem
from rdkit.Chem import rdDepictor
from rdkit.Chem.Draw import rdMolDraw2D

from ctopo.core.atom_types import AtomType
from ctopo.core.ligand import Ligand
from ctopo.topology import get_ligands_skeleton

Color = Tuple[float, float, float]


def _copy_mol(mol: Chem.Mol) -> Chem.Mol:
    return Chem.Mol(mol)


def _ensure_2d(mol: Chem.Mol) -> Chem.Mol:
    """Ensure the molecule has 2D coordinates for drawing."""
    if mol.GetNumConformers() == 0:
        rdDepictor.Compute2DCoords(mol)
    return mol


def _clear_all_atom_maps(mol: Chem.Mol) -> None:
    for a in mol.GetAtoms():
        a.SetAtomMapNum(0)


def _set_donor_atom_maps(mol: Chem.Mol, donor_atoms: Iterable[int], map_num: int) -> None:
    if map_num <= 0:
        raise ValueError('map_num must be a positive integer')
    for i in donor_atoms:
        mol.GetAtomWithIdx(int(i)).SetAtomMapNum(int(map_num))


@dataclass(frozen=True, slots=True)
class PreparedMol:
    """A bundle of an RDKit Mol and drawing metadata."""

    mol: Chem.Mol
    atom_labels: Optional[Dict[int, str]] = None
    highlight_atoms: Optional[List[int]] = None
    highlight_bonds: Optional[List[int]] = None
    highlight_atom_colors: Optional[Dict[int, Color]] = None
    highlight_bond_colors: Optional[Dict[int, Color]] = None
    highlight_atom_radii: Optional[Dict[int, float]] = None

    def to_smiles(self, canonical: bool = True, isomeric: bool = True) -> str:
        """Generate a SMILES string from the stored RDKit Mol."""
        return Chem.MolToSmiles(self.mol, canonical=canonical, isomericSmiles=isomeric)

    def to_svg(
        self,
        size: tuple[int, int] = (300, 220),
        line_width: int = 2,
        add_atom_indices: bool = False,
    ) -> str:
        """Render the prepared molecule as an SVG string."""
        mol = _ensure_2d(_copy_mol(self.mol))

        for a in mol.GetAtoms():
            a.SetAtomMapNum(0)

        drawer = rdMolDraw2D.MolDraw2DSVG(int(size[0]), int(size[1]))
        opts = drawer.drawOptions()
        opts.bondLineWidth = int(line_width)
        opts.addAtomIndices = bool(add_atom_indices)

        if self.atom_labels:
            for i, lab in self.atom_labels.items():
                opts.atomLabels[int(i)] = str(lab)

        highlight_atoms = self.highlight_atoms or []
        highlight_bonds = self.highlight_bonds or []
        ha_colors = self.highlight_atom_colors or {}
        hb_colors = self.highlight_bond_colors or {}
        ha_radii = self.highlight_atom_radii or {}

        rdMolDraw2D.PrepareAndDrawMolecule(
            drawer,
            mol,
            highlightAtoms=[int(i) for i in highlight_atoms],
            highlightBonds=[int(i) for i in highlight_bonds],
            highlightAtomColors={int(k): v for k, v in ha_colors.items()},
            highlightBondColors={int(k): v for k, v in hb_colors.items()},
            highlightAtomRadii={int(k): float(v) for k, v in ha_radii.items()},
        )
        drawer.FinishDrawing()
        return drawer.GetDrawingText()


def _bond_type_from_graph_edge(attrs: Mapping, force_single: bool) -> Chem.BondType:
    """Map cTopo edge attrs to an RDKit bond type."""
    if force_single:
        return Chem.BondType.SINGLE

    bt = str(attrs.get('bond_type', ''))
    if bt == 'SINGLE':
        return Chem.BondType.SINGLE
    if bt == 'DOUBLE':
        return Chem.BondType.DOUBLE
    if bt == 'TRIPLE':
        return Chem.BondType.TRIPLE
    if bt == 'AROMATIC':
        return Chem.BondType.AROMATIC
    if bt.startswith('DATIV') or bt == 'DATIVE':
        return Chem.BondType.SINGLE

    bo = attrs.get('bond_order')
    try:
        bo_f = float(bo)
    except Exception:
        bo_f = 1.0

    if abs(bo_f - 1.0) < 1e-6:
        return Chem.BondType.SINGLE
    if abs(bo_f - 2.0) < 1e-6:
        return Chem.BondType.DOUBLE
    if abs(bo_f - 3.0) < 1e-6:
        return Chem.BondType.TRIPLE
    if abs(bo_f - 1.5) < 1e-6:
        return Chem.BondType.AROMATIC
    return Chem.BondType.SINGLE


def _graph_to_mol(
    G: nx.Graph,
    atom_Z: Mapping[int, int],
    force_single_bonds: bool,
    sanitize: bool = False,
) -> tuple[Chem.Mol, Dict[int, int]]:
    """Build an RDKit Mol from a NetworkX graph.

    Args:
        G: NetworkX graph.
        atom_Z: mapping node_id -> atomic number to use in the RDKit Mol.
        force_single_bonds: if True, all bonds will be SINGLE.
        sanitize: if True, attempts Chem.SanitizeMol(mol). Default False.

    Returns:
        (mol, node_to_atomidx)
    """
    nodes = sorted(int(n) for n in G.nodes())
    node_to_idx: Dict[int, int] = {}

    rw = Chem.RWMol()
    for n in nodes:
        Z = int(atom_Z.get(n, 0))
        a = Chem.Atom(Z)
        a.SetNoImplicit(True)
        idx = rw.AddAtom(a)
        node_to_idx[n] = int(idx)

    for u, v, attrs in G.edges(data=True):
        u_i = node_to_idx[int(u)]
        v_i = node_to_idx[int(v)]
        btype = _bond_type_from_graph_edge(attrs, force_single=force_single_bonds)
        if rw.GetBondBetweenAtoms(u_i, v_i) is None:
            rw.AddBond(u_i, v_i, btype)

    mol = rw.GetMol()
    if sanitize:
        Chem.SanitizeMol(mol)

    return mol, node_to_idx


def prepare_ligand_visual(
    ligand: Ligand,
    donor_map_num: int = 1,
    donor_color: Color = (1.0, 0.80, 0.45),
    skeleton_bond_color: Color = (0.65, 0.80, 1.0),
    donor_radius: float = 0.45,
    mark_donors_in_smiles: bool = True,
    highlight_skeleton_bonds: bool = True,
) -> PreparedMol:
    """Prepare an RDKit Mol of the ligand for drawing and SMILES generation.

    Behavior:
      - starts from ligand.mol (source of truth)
      - optionally sets the same atom-map number on all donor atoms
      - highlights donor atoms and (optionally) skeleton bonds

    Skeleton bonds are computed from the ligand graph partition.
    """
    mol = _copy_mol(ligand.mol)
    _clear_all_atom_maps(mol)

    donors = sorted(int(i) for i in ligand.donor_atoms)
    if mark_donors_in_smiles:
        _set_donor_atom_maps(mol, donors, donor_map_num)

    highlight_atoms = donors
    highlight_atom_colors = {i: donor_color for i in donors}
    highlight_atom_radii = {i: float(donor_radius) for i in donors}

    highlight_bonds: List[int] = []
    highlight_bond_colors: Dict[int, Color] = {}

    if highlight_skeleton_bonds:
        skelG = get_ligands_skeleton(ligand.G)
        for u, v in skelG.edges():
            b = mol.GetBondBetweenAtoms(int(u), int(v))
            if b is None:
                continue
            bid = int(b.GetIdx())
            highlight_bonds.append(bid)
            highlight_bond_colors[bid] = skeleton_bond_color

    return PreparedMol(
        mol=mol,
        atom_labels=None,
        highlight_atoms=highlight_atoms,
        highlight_bonds=highlight_bonds,
        highlight_atom_colors=highlight_atom_colors,
        highlight_bond_colors=highlight_bond_colors,
        highlight_atom_radii=highlight_atom_radii,
    )


def prepare_skeleton_visual(
    G_skeleton: nx.Graph,
    use_original_donor_atoms: bool = True,
    use_original_skeleton_atoms: bool = True,
    use_original_bonds: bool = True,
    donor_map_num: int = 1,
    mark_donors_in_smiles: bool = True,
    donor_color: Color = (1.0, 0.80, 0.45),
    donor_radius: float = 0.45,
    donor_label: str = 'DA',
) -> PreparedMol:
    """Prepare an RDKit Mol for a ligand skeleton graph."""
    donors: Set[int] = set()
    skeleton_nodes: Set[int] = set()

    for n, data in G_skeleton.nodes(data=True):
        at = int(data.get('atom_type', int(AtomType.UNDEFINED)))
        if at == int(AtomType.DONOR):
            donors.add(int(n))
        else:
            skeleton_nodes.add(int(n))

    atom_Z: Dict[int, int] = {}
    node_labels: Dict[int, str] = {}

    for n in donors:
        if use_original_donor_atoms:
            atom_Z[n] = int(G_skeleton.nodes[n].get('Z', 0))
        else:
            atom_Z[n] = 0
            node_labels[n] = donor_label

    for n in skeleton_nodes:
        if use_original_skeleton_atoms:
            atom_Z[n] = int(G_skeleton.nodes[n].get('Z', 0))
        else:
            atom_Z[n] = 0
            node_labels[n] = ''  # hide label

    mol, node_to_idx = _graph_to_mol(
        G_skeleton,
        atom_Z=atom_Z,
        force_single_bonds=(not use_original_bonds),
        sanitize=False,
    )

    atom_labels_idx: Dict[int, str] = {
        node_to_idx[int(n)]: str(lab) for n, lab in node_labels.items()
    }

    _clear_all_atom_maps(mol)
    if mark_donors_in_smiles:
        _set_donor_atom_maps(mol, [node_to_idx[n] for n in sorted(donors)], donor_map_num)

    ha = [node_to_idx[n] for n in sorted(donors)]
    ha_colors = {i: donor_color for i in ha}
    ha_radii = {i: float(donor_radius) for i in ha}

    return PreparedMol(
        mol=mol,
        atom_labels=atom_labels_idx,
        highlight_atoms=ha,
        highlight_bonds=[],
        highlight_atom_colors=ha_colors,
        highlight_bond_colors={},
        highlight_atom_radii=ha_radii,
    )


def prepare_topology_visual(
    G_topology: nx.Graph,
    use_original_donor_atoms: bool = False,
    donor_map_num: int = 1,
    mark_donors_in_smiles: bool = True,
    donor_color: Color = (1.0, 0.80, 0.45),
    donor_radius: float = 0.45,
    donor_label: str = 'DA',
) -> PreparedMol:
    """Prepare an RDKit Mol for a ligand topology graph."""
    donors: Set[int] = set()
    for n, data in G_topology.nodes(data=True):
        if int(data.get('atom_type', int(AtomType.UNDEFINED))) == int(AtomType.DONOR):
            donors.add(int(n))

    atom_Z: Dict[int, int] = {}
    node_labels: Dict[int, str] = {}

    for n, data in G_topology.nodes(data=True):
        n = int(n)
        if n in donors:
            if use_original_donor_atoms:
                atom_Z[n] = int(data.get('Z', 0))
            else:
                atom_Z[n] = 0
                node_labels[n] = donor_label
        else:
            atom_Z[n] = 0
            node_labels[n] = ''  # hide dummy labels

    mol, node_to_idx = _graph_to_mol(
        G_topology,
        atom_Z=atom_Z,
        force_single_bonds=True,
        sanitize=False,
    )

    atom_labels_idx: Dict[int, str] = {
        node_to_idx[int(n)]: str(lab) for n, lab in node_labels.items()
    }

    _clear_all_atom_maps(mol)
    if mark_donors_in_smiles:
        _set_donor_atom_maps(mol, [node_to_idx[n] for n in sorted(donors)], donor_map_num)

    ha = [node_to_idx[n] for n in sorted(donors)]
    ha_colors = {i: donor_color for i in ha}
    ha_radii = {i: float(donor_radius) for i in ha}

    return PreparedMol(
        mol=mol,
        atom_labels=atom_labels_idx,
        highlight_atoms=ha,
        highlight_bonds=[],
        highlight_atom_colors=ha_colors,
        highlight_bond_colors={},
        highlight_atom_radii=ha_radii,
    )



__all__ = [
    'PreparedMol',
    'prepare_ligand_visual',
    'prepare_skeleton_visual',
    'prepare_topology_visual',
]


