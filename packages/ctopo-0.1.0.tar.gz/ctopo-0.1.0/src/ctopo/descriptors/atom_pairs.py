"""AtomPairs fingerprints on a NetworkX chemical graph.

This module implements a simple AtomPairs-style fingerprint core that operates on
a NetworkX graph and a provided per-atom invariant vector (typically produced by
`ctopo.descriptors.atom_hashes.atomic_invariants_from_graph`).

Definition (ctopo-native):
- For each unordered atom pair (i, j), i != j, compute the topological distance d
  as the shortest path length in the graph (in number of bonds).
- If d is within [min_distance, max_distance], emit a feature whose id is a hash of:
    (d, min(inv_i, inv_j), max(inv_i, inv_j))
  using the same boost-style hash mechanism as in Morgan (`hash_components`).
- The output is a sparse counts dict: feature_id -> count.

Notes:
- This is NOT intended to be RDKit-identical AtomPairs. The “atom types” are your
  invariants, so the chemistry is controlled by the invariant construction.
- `emit_from` is interpreted as: include a pair if at least one endpoint is in emit_from.
  (This is the most useful symmetric interpretation while avoiding double-counting.)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import networkx as nx

from ctopo.descriptors.atom_hashes import hash_components


_UINT32_MASK = (1 << 32) - 1


@dataclass(frozen=True)
class AtomPairsSpec:
    """Parameters controlling AtomPairs fingerprint generation.

    Args:
        min_distance: Minimum topological distance (in bonds) to include.
        max_distance: Maximum topological distance (in bonds) to include.
        bits: Bit width for feature id hashing (default 32).
    """
    min_distance: int = 1
    max_distance: int = 30
    bits: int = 32

    def __post_init__(self) -> None:
        if self.min_distance < 0:
            raise ValueError("min_distance must be >= 0")
        if self.max_distance < self.min_distance:
            raise ValueError("max_distance must be >= min_distance")
        if self.bits <= 0:
            raise ValueError("bits must be a positive integer")


def _pair_feature_id(inv_i: int, inv_j: int, dist: int, bits: int = 32) -> int:
    """Compute a stable feature id for an unordered atom pair.

    Args:
        inv_i: Atom invariant for atom i.
        inv_j: Atom invariant for atom j.
        dist: Topological distance between atoms (shortest path length, in bonds).
        bits: Bit width for hashing.

    Returns:
        Integer feature id hashed to `bits`.
    """
    a = int(inv_i) & _UINT32_MASK
    b = int(inv_j) & _UINT32_MASK
    lo, hi = (a, b) if a <= b else (b, a)
    return int(hash_components([int(dist), int(lo), int(hi)], bits=bits))


def atom_pairs_sparse_counts(
    G: nx.Graph,
    atom_invariants: Sequence[int],
    emit_from: Optional[Iterable[int]] = None,
    min_distance: int = 1,
    max_distance: int = 30,
    bits: int = 32,
    pair_info: Optional[Dict[int, List[Dict[str, int]]]] = None,
) -> Dict[int, int]:
    """Compute a sparse count AtomPairs fingerprint.

    Args:
        G: Molecular graph (NetworkX, undirected).
        atom_invariants: Round-0 atom invariants, indexed by node id (node id is atom id).
        emit_from: Optional iterable of atom ids restricting emission:
            a pair (i, j) is included if i in emit_from OR j in emit_from.
            (If None, all pairs are included.)
        min_distance: Minimum shortest-path distance (in bonds) to include.
        max_distance: Maximum shortest-path distance (in bonds) to include.
        bits: Bit width for feature id hashing (default 32).
        pair_info: Optional mapping populated as pair_info[feature_id] -> list of dicts
            with keys: {'a', 'b', 'distance'}. This is helpful for debugging/analysis.

    Returns:
        Mapping feature_id -> count.

    Raises:
        ValueError: If min/max distances are invalid or invariants are too short.
        TypeError: If emit_from is a string.
    """
    spec = AtomPairsSpec(min_distance=min_distance, max_distance=max_distance, bits=bits)

    if isinstance(emit_from, str):
        raise TypeError("emit_from must be an iterable of atom indices (not a string)")

    node_ids = sorted(int(n) for n in G.nodes())
    max_node = max(node_ids) if node_ids else -1
    if max_node >= len(atom_invariants):
        raise ValueError("atom_invariants is too short for the maximum node id in G")

    include_atoms: Optional[set[int]]
    if emit_from is None:
        include_atoms = None
    else:
        include_atoms = {int(a) for a in emit_from}

    # Pull invariants into a dict keyed by node id for fast access.
    invariants: Dict[int, int] = {a: int(atom_invariants[a]) for a in node_ids}

    out: Dict[int, int] = {}

    # Enumerate unordered pairs using bounded BFS from each source.
    # We avoid double counting by enforcing j > i.
    for i in node_ids:
        # Bounded shortest paths from i
        dist_map = nx.single_source_shortest_path_length(G, i, cutoff=spec.max_distance)

        # Deterministic target iteration
        for j, d in sorted(dist_map.items()):
            j = int(j)
            d = int(d)
            if j <= i:
                continue  # ensures unordered pair counted once; also skips i==j
            if d < spec.min_distance or d > spec.max_distance:
                continue

            if include_atoms is not None:
                if (i not in include_atoms) and (j not in include_atoms):
                    continue

            fid = _pair_feature_id(invariants[i], invariants[j], d, bits=spec.bits)
            out[fid] = out.get(fid, 0) + 1

            if pair_info is not None:
                pair_info.setdefault(fid, []).append(
                    {"a": int(i), "b": int(j), "distance": int(d)}
                )

    return out


