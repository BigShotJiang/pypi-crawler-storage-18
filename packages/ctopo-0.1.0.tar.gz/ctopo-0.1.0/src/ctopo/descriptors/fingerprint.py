"""High-level fingerprint computation API.

This module provides user-facing convenience functions that combine:
- atom invariant preparation (via :func:`ctopo.descriptors.atom_hashes.atomic_invariants_from_graph`)
- core fingerprint algorithm execution (Morgan, AtomPairs)
- output formatting (sparse counts / folded counts / bits)

The core fingerprint implementations remain in their dedicated modules, while this
module wires them together into ergonomic entry points for Ligand/Complex objects.
"""

from __future__ import annotations

from dataclasses import dataclass, is_dataclass, replace
from typing import Any, Dict, Iterable, Literal, Mapping, Optional, Sequence, Union

import networkx as nx

from ctopo.core.atom_types import AtomType
from ctopo.descriptors.atom_hashes import AtomicProperties, atomic_invariants_from_graph
from ctopo.descriptors.fp_formats import BitsFormat, FoldCountsFormat, counts_to_bits, fold_counts
from ctopo.descriptors.graph_views import GraphView, make_graph_view
from ctopo.descriptors.atom_pairs import AtomPairsSpec, atom_pairs_sparse_counts
from ctopo.descriptors.morgan import MorganSpec, morgan_sparse_counts


OutputKind = Literal['sparse_counts', 'folded_counts', 'bits']
FingerprintKind = Literal['morgan', 'atompairs']

BondMode = Literal['all', 'skeleton_only', 'substituent_only', 'all_single']

EmitRegime = Literal['all', 'skeleton', 'substituent', 'donor', 'center']
EmitFromStructure = Union[None, EmitRegime, Iterable[int]]
EmitFromFingerprint = Optional[Iterable[int]]


def _is_substituent_atom(atom_type: int) -> bool:
    """Check whether an atom type represents a substituent.

    Args:
        atom_type: Integer atom type code from the node attribute ``atom_type``.

    Returns:
        True if atom_type indicates a substituent atom, False otherwise.
    """
    return int(atom_type) == int(AtomType.SUBSTITUENT)


def _copy_graph_with_fp_bond_codes(
    G: nx.Graph,
    bond_mode: BondMode,
    atom_type_key: str = 'atom_type',
    bond_code_key: str = 'bond_code',
    fp_bond_code_key: str = 'fp_bond_code',
) -> nx.Graph:
    """Copy a graph and write fingerprint bond codes under a dedicated edge key.

    Args:
        G: Input molecular graph.
        bond_mode: Controls which edges keep their original bond codes:
            - 'all': keep all original bond codes
            - 'skeleton_only': keep codes only for bonds where both atoms are not substituents
            - 'substituent_only': keep codes only for bonds where at least one atom is a substituent
            - 'all_single': set all bonds to single
        atom_type_key: Node attribute key holding the atom type.
        bond_code_key: Edge attribute key holding the original integer bond code.
        fp_bond_code_key: Edge attribute key to store the fingerprint bond code.

    Returns:
        A shallow copy of G with an extra edge attribute ``fp_bond_code_key``.

    Raises:
        ValueError: If bond_mode is unsupported.
    """
    H = G.copy()

    if bond_mode not in ('all', 'skeleton_only', 'substituent_only', 'all_single'):
        raise ValueError(f'Unsupported bond_mode: {bond_mode!r}')

    for u, v, data in H.edges(data=True):
        if bond_mode == 'all_single':
            data[fp_bond_code_key] = 1
            continue

        original = int(data.get(bond_code_key, 1))

        if bond_mode == 'all':
            data[fp_bond_code_key] = original
            continue

        tu = int(H.nodes[u].get(atom_type_key, int(AtomType.UNDEFINED)))
        tv = int(H.nodes[v].get(atom_type_key, int(AtomType.UNDEFINED)))

        u_sub = _is_substituent_atom(tu)
        v_sub = _is_substituent_atom(tv)

        if bond_mode == 'skeleton_only':
            data[fp_bond_code_key] = original if (not u_sub and not v_sub) else 1
            continue

        if bond_mode == 'substituent_only':
            data[fp_bond_code_key] = original if (u_sub or v_sub) else 1
            continue

        raise ValueError(f'Unsupported bond_mode: {bond_mode!r}')

    return H


def fingerprint(
    G: nx.Graph,
    kind: FingerprintKind,
    invariants: Sequence[int],
    output: OutputKind = 'sparse_counts',
    fp_size: int = 2048,
    emit_from: EmitFromFingerprint = None,
    spec: Optional[Union[MorganSpec, AtomPairsSpec]] = None,
    bit_info: Optional[Dict[int, Any]] = None,
    folded_format: FoldCountsFormat = 'dict',
    bits_format: BitsFormat = 'set',
) -> Any:
    """Compute a fingerprint from a NetworkX chemical graph.

    This is a low-level function: if you want graph views, named emission regimes,
    or atom invariant construction from atom attributes, use
    :func:`fingerprint_from_structure` instead.

    Args:
        G: Molecular graph as a NetworkX undirected graph.
        kind: Fingerprint kind ('morgan' or 'atompairs').
        invariants: Per-atom invariants indexed by node id.
        output: Output format: 'sparse_counts', 'folded_counts', or 'bits'.
        fp_size: Size for folded outputs ('folded_counts' and 'bits').
        emit_from: Optional iterable restricting which atom centers emit features.
            This must be node ids in the provided graph G.
        spec: Algorithm configuration. For 'morgan', a MorganSpec is required.
        bit_info: Optional mutable mapping populated with provenance information
            (when supported by the underlying algorithm).
        folded_format: Output format for folded counts ('dict' or 'numpy').
        bits_format: Output format for bits ('set', 'dict', or 'numpy').

    Returns:
        Fingerprint in the requested format.

    Raises:
        ValueError: If an unsupported kind/output is requested.
        TypeError: If emit_from is a string (named regimes are not supported here).
        TypeError: If a spec of the wrong type is provided.
    """
    if output not in ('sparse_counts', 'folded_counts', 'bits'):
        raise ValueError(f'Unsupported output format: {output!r}')

    if isinstance(emit_from, str):
        raise TypeError('emit_from must be an iterable of node ids (not a string). Use fingerprint_from_structure() for regimes.')

    if kind == 'morgan':
        if spec is None:
            raise ValueError('For kind=\'morgan\', spec must be provided (MorganSpec).')
        if not isinstance(spec, MorganSpec):
            raise TypeError('For kind=\'morgan\', spec must be a MorganSpec.')

        counts = morgan_sparse_counts(
            G,
            radius=spec.radius,
            atom_invariants=invariants,
            emit_from=emit_from,
            use_chirality=spec.use_chirality,
            use_bond_types=spec.use_bond_types,
            only_nonzero_invariants=spec.only_nonzero_invariants,
            include_redundant_environments=spec.include_redundant_environments,
            bit_info=bit_info,
            bond_code_key=spec.bond_code_key,
            bond_idx_key=spec.bond_idx_key,
            chiral_tag_key=spec.chiral_tag_key,
            cip_code_key=spec.cip_code_key,
        )

        if output == 'sparse_counts':
            return counts
        if output == 'folded_counts':
            return fold_counts(counts, fp_size, output_format=folded_format)
        return counts_to_bits(counts, fp_size, output_format=bits_format)

    if kind == 'atompairs':
        ap_spec = spec
        if ap_spec is None:
            ap_spec = AtomPairsSpec()
        if not isinstance(ap_spec, AtomPairsSpec):
            raise TypeError('For kind=\'atompairs\', spec must be an AtomPairsSpec (or None).')

        counts = atom_pairs_sparse_counts(
            G,
            atom_invariants=invariants,
            emit_from=emit_from,
            min_distance=ap_spec.min_distance,
            max_distance=ap_spec.max_distance,
            bits=ap_spec.bits,
        )

        if output == 'sparse_counts':
            return counts
        if output == 'folded_counts':
            return fold_counts(counts, fp_size, output_format=folded_format)
        return counts_to_bits(counts, fp_size, output_format=bits_format)

    raise ValueError(f'Unsupported fingerprint kind: {kind!r}')


def _emit_nodes_for_regime(
    G: nx.Graph,
    regime: EmitRegime,
    atom_type_key: str = 'atom_type',
) -> set[int]:
    """Resolve a named emission regime to a set of node ids.

    Args:
        G: Graph whose node ids are used.
        regime: Named regime.
        atom_type_key: Node attribute key holding atom type.

    Returns:
        Set of node ids that should emit environments.

    Raises:
        ValueError: If regime is unknown.
    """
    if regime == 'all':
        return set(int(n) for n in G.nodes())

    if regime == 'center':
        return {int(n) for n, d in G.nodes(data=True) if int(d.get(atom_type_key, 0)) == int(AtomType.CENTER)}

    if regime == 'donor':
        return {int(n) for n, d in G.nodes(data=True) if int(d.get(atom_type_key, 0)) == int(AtomType.DONOR)}

    if regime == 'substituent':
        return {int(n) for n, d in G.nodes(data=True) if int(d.get(atom_type_key, 0)) == int(AtomType.SUBSTITUENT)}

    if regime == 'skeleton':
        # Skeleton includes donor atoms by convention.
        return {
            int(n) for n, d in G.nodes(data=True)
            if int(d.get(atom_type_key, 0)) in (int(AtomType.SKELETON), int(AtomType.DONOR))
        }

    raise ValueError(f'Unknown emit_from regime: {regime!r}')


def fingerprint_from_structure(
    structure: Any,
    kind: FingerprintKind,
    spec: Optional[Union[MorganSpec, AtomPairsSpec]],
    atomic_properties: AtomicProperties,
    graph_view: GraphView = 'original',
    keep_metals: bool = True,
    bond_mode: BondMode = 'all',
    output: OutputKind = 'sparse_counts',
    fp_size: int = 2048,
    emit_from: EmitFromStructure = None,
    bit_info: Optional[Dict[int, Any]] = None,
    folded_format: FoldCountsFormat = 'dict',
    bits_format: BitsFormat = 'set',
    atom_type_key: str = 'atom_type',
    idx_key: str = 'idx',
    bond_code_key: str = 'bond_code',
    fp_bond_code_key: str = 'fp_bond_code',
) -> Any:
    """Compute a fingerprint from a Ligand or Complex (ctopo core objects).

    This is a convenience wrapper that:
    1) reads ``structure.G`` (NetworkX graph)
    2) builds a named graph view (subgraph + relabel to 0..n-1)
    3) writes fingerprint bond codes under ``fp_bond_code_key`` according to bond_mode
    4) computes atom invariants from node attributes (including per-atom_type property selection)
    5) resolves emit_from (regime or explicit list of original atom indices) into view node ids
    6) calls :func:`fingerprint`

    Indexing conventions:
    - The view graph is relabeled to node ids 0..n-1.
    - The original atom index is preserved as node attribute ``idx_key``.
    - If ``emit_from`` is an explicit iterable, it is interpreted as original atom indices
      (values of ``idx_key``), not view node ids.

    Args:
        structure: Ligand or Complex object with attribute ``G``.
        kind: Fingerprint kind ('morgan' or 'atompairs').
        spec: Algorithm configuration.
            - for kind='morgan', this must be a MorganSpec
            - for kind='atompairs', this can be an AtomPairsSpec or None (defaults are used)
        atomic_properties: Atomic-property selection for invariant construction.
            This can be either:
            - a list of property names applied to all atom types, or
            - a dict mapping atom_type -> list of property names.
        graph_view: Named view applied before fingerprinting.
        keep_metals: If False, attempts to drop metal atoms in the view (Complex use).
        bond_mode: Bond handling regime for fingerprint bond codes.
        output: Output format: 'sparse_counts', 'folded_counts', or 'bits'.
        fp_size: Size for folded outputs.
        emit_from: Optional emission selector:
            - None or 'all': emit from all atoms
            - named regime ('skeleton', 'substituent', 'donor', 'center')
            - explicit iterable of original atom indices (node[idx_key])
        bit_info: Optional provenance mapping (see Morgan docs).
        folded_format: Output format for folded counts ('dict' or 'numpy').
        bits_format: Output format for bits ('set', 'dict', or 'numpy').
        atom_type_key: Node attribute key holding atom type.
        idx_key: Node attribute key holding original atom index.
        bond_code_key: Edge attribute key holding original bond code.
        fp_bond_code_key: Edge attribute key to store fingerprint bond code.

    Returns:
        Fingerprint in the requested format.

    Raises:
        AttributeError: If structure has no attribute ``G``.
        ValueError: If the created view is not relabeled to 0..n-1.
    """
    if not hasattr(structure, 'G'):
        raise AttributeError('structure must have attribute G (NetworkX graph)')

    G: nx.Graph = structure.G

    V, old_to_new, new_to_old = make_graph_view(
        G,
        view=graph_view,
        keep_metals=keep_metals,
        atom_type_key=atom_type_key,
        idx_key=idx_key,
    )

    # Defensive invariant: the view must be relabeled 0..n-1.
    if set(V.nodes()) != set(range(V.number_of_nodes())):
        raise ValueError('View graph must be relabeled to node ids 0..n-1')

    H = _copy_graph_with_fp_bond_codes(
        V,
        bond_mode=bond_mode,
        atom_type_key=atom_type_key,
        bond_code_key=bond_code_key,
        fp_bond_code_key=fp_bond_code_key,
    )

    invariants = atomic_invariants_from_graph(H, atomic_properties)

    # Resolve emit_from to view node ids:
    view_emit_from: Optional[Iterable[int]] = None

    if emit_from is None or emit_from == 'all':
        view_emit_from = None

    elif isinstance(emit_from, str):
        # named regime in view node space
        view_emit_from = sorted(_emit_nodes_for_regime(H, emit_from, atom_type_key=atom_type_key))

    else:
        # explicit list of ORIGINAL atom indices (node[idx_key]) -> view node ids
        idx_to_view = {int(H.nodes[n].get(idx_key, n)): int(n) for n in H.nodes()}
        resolved = []
        for a in emit_from:
            ia = int(a)
            if ia in idx_to_view:
                resolved.append(idx_to_view[ia])
        view_emit_from = sorted(set(resolved))

    # Ensure Morgan spec uses the dedicated bond code key
    fp_spec = spec
    if kind == 'morgan':
        if spec is None:
            raise ValueError("For kind='morgan', spec must be provided (MorganSpec).")
        if not isinstance(spec, MorganSpec):
            raise TypeError("For kind='morgan', spec must be a MorganSpec.")
        if getattr(spec, 'bond_code_key', None) != fp_bond_code_key:
            if is_dataclass(spec):
                fp_spec = replace(spec, bond_code_key=fp_bond_code_key)
            else:
                try:
                    setattr(spec, 'bond_code_key', fp_bond_code_key)
                    fp_spec = spec
                except Exception:
                    fp_spec = spec

    return fingerprint(
        H,
        kind=kind,
        invariants=invariants,
        output=output,
        fp_size=fp_size,
        emit_from=view_emit_from,
        spec=fp_spec,
        bit_info=bit_info,
        folded_format=folded_format,
        bits_format=bits_format,
    )


@dataclass(frozen=True)
class Fingerprinter:
    """Configured fingerprint callable.

    This is a small factory object to bundle fingerprint settings into a reusable
    callable. It is meant for repeated feature extraction from many Ligands/Complexes.

    Args:
        kind: Fingerprint kind.
        spec: Algorithm configuration (MorganSpec for now).
        atomic_properties: Atom invariant property selection.
        graph_view: Named graph view.
        keep_metals: Whether to keep metal atoms in Complex graphs.
        bond_mode: Bond handling regime.
        output: Output format.
        fp_size: Folding size for folded outputs.
        emit_from: Emission selector (regime or list of original atom indices).
        folded_format: Folded counts output format.
        bits_format: Bits output format.
        atom_type_key: Node attribute key holding atom type.
        idx_key: Node attribute key holding original atom index.
        bond_code_key: Edge attribute key holding original bond code.
        fp_bond_code_key: Edge attribute key to store fingerprint bond code.
    """
    kind: FingerprintKind
    spec: Optional[Union[MorganSpec, AtomPairsSpec]]
    atomic_properties: AtomicProperties
    graph_view: GraphView = 'original'
    keep_metals: bool = True
    bond_mode: BondMode = 'all'
    output: OutputKind = 'sparse_counts'
    fp_size: int = 2048
    emit_from: EmitFromStructure = None
    folded_format: FoldCountsFormat = 'dict'
    bits_format: BitsFormat = 'set'
    atom_type_key: str = 'atom_type'
    idx_key: str = 'idx'
    bond_code_key: str = 'bond_code'
    fp_bond_code_key: str = 'fp_bond_code'

    def __call__(self, structure: Any, bit_info: Optional[Dict[int, Any]] = None) -> Any:
        """Compute a fingerprint for a structure with stored settings.

        Args:
            structure: Ligand or Complex (must have attribute G).
            bit_info: Optional provenance dict populated by the algorithm.

        Returns:
            Fingerprint in the configured output format.

        Raises:
            See :func:`fingerprint_from_structure`.
        """
        return fingerprint_from_structure(
            structure=structure,
            kind=self.kind,
            spec=self.spec,
            atomic_properties=self.atomic_properties,
            graph_view=self.graph_view,
            keep_metals=self.keep_metals,
            bond_mode=self.bond_mode,
            output=self.output,
            fp_size=self.fp_size,
            emit_from=self.emit_from,
            bit_info=bit_info,
            folded_format=self.folded_format,
            bits_format=self.bits_format,
            atom_type_key=self.atom_type_key,
            idx_key=self.idx_key,
            bond_code_key=self.bond_code_key,
            fp_bond_code_key=self.fp_bond_code_key,
        )


def make_fingerprinter(
    kind: FingerprintKind,
    spec: Optional[Union[MorganSpec, AtomPairsSpec]],
    atomic_properties: AtomicProperties,
    graph_view: GraphView = 'original',
    keep_metals: bool = True,
    bond_mode: BondMode = 'all',
    output: OutputKind = 'sparse_counts',
    fp_size: int = 2048,
    emit_from: EmitFromStructure = None,
    folded_format: FoldCountsFormat = 'dict',
    bits_format: BitsFormat = 'set',
    atom_type_key: str = 'atom_type',
    idx_key: str = 'idx',
    bond_code_key: str = 'bond_code',
    fp_bond_code_key: str = 'fp_bond_code',
) -> Fingerprinter:
    """Create a configured fingerprint callable.

    Args:
        kind: Fingerprint kind.
        spec: Algorithm configuration (MorganSpec for now).
        atomic_properties: Atom invariant property selection.
        graph_view: Named graph view.
        keep_metals: Whether to keep metal atoms in Complex graphs.
        bond_mode: Bond handling regime.
        output: Output format.
        fp_size: Folding size for folded outputs.
        emit_from: Emission selector (regime or list of original atom indices).
        folded_format: Folded counts output format.
        bits_format: Bits output format.
        atom_type_key: Node attribute key holding atom type.
        idx_key: Node attribute key holding original atom index.
        bond_code_key: Edge attribute key holding original bond code.
        fp_bond_code_key: Edge attribute key to store fingerprint bond code.

    Returns:
        A configured :class:`Fingerprinter` instance.
    """
    return Fingerprinter(
        kind=kind,
        spec=spec,
        atomic_properties=atomic_properties,
        graph_view=graph_view,
        keep_metals=keep_metals,
        bond_mode=bond_mode,
        output=output,
        fp_size=fp_size,
        emit_from=emit_from,
        folded_format=folded_format,
        bits_format=bits_format,
        atom_type_key=atom_type_key,
        idx_key=idx_key,
        bond_code_key=bond_code_key,
        fp_bond_code_key=fp_bond_code_key,
    )


__all__ = [
    'OutputKind',
    'FingerprintKind',
    'BondMode',
    'EmitRegime',
    'EmitFromStructure',
    'fingerprint',
    'fingerprint_from_structure',
    'Fingerprinter',
    'make_fingerprinter',
]
