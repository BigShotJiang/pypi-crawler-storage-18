"""Descriptor and fingerprint computation utilities.

This subpackage contains:
- RDKit-free implementations of fingerprints (Morgan, AtomPairs)
- atom invariant hashing helpers
- graph view helpers for selecting subgraphs (skeleton/substituent, etc.)
- utilities to convert sparse count fingerprints into folded arrays or bit sets

Public API is re-exported here for convenience.
"""

from __future__ import annotations

from ctopo.descriptors.atom_hashes import (
    ALLOWED_PROPERTIES,
    DEFAULT_PROPERTIES,
    atomic_invariants_from_graph,
)
from ctopo.descriptors.graph_views import GraphView, make_graph_view
from ctopo.descriptors.atom_pairs import AtomPairsSpec, atom_pairs_sparse_counts
from ctopo.descriptors.morgan import MorganSpec, morgan_sparse_counts
from ctopo.descriptors.fp_formats import (
    BitsFormat,
    FoldCountsFormat,
    counts_to_bits,
    fold_counts,
)
from ctopo.descriptors.fingerprint import (
    Fingerprinter,
    fingerprint,
    fingerprint_from_structure,
    make_fingerprinter,
)


__all__ = [
    'ALLOWED_PROPERTIES',
    'DEFAULT_PROPERTIES',
    'atomic_invariants_from_graph',
    'BitsFormat',
    'FoldCountsFormat',
    'counts_to_bits',
    'fold_counts',
    'GraphView',
    'make_graph_view',
    'AtomPairsSpec',
    'atom_pairs_sparse_counts',
    'MorganSpec',
    'morgan_sparse_counts',
    'Fingerprinter',
    'fingerprint',
    'fingerprint_from_structure',
    'make_fingerprinter',
]
