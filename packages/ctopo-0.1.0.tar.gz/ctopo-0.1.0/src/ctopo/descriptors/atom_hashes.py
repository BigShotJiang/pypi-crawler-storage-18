"""Hashing helpers and graph-based atom invariants.

This module is intentionally RDKit-free. It operates on ctopo's NetworkX graphs
(e.g., Ligand.G and Complex.G) and expects required atom attributes to be present
on each node.

Supported atom properties for invariant construction are limited to:
- Z
- degree
- num_hs
- charge
- atom_type
- aromatic
- in_ring

These values are used "as is" (booleans are converted to 0/1).
"""

from __future__ import annotations

from typing import Dict, Mapping, Sequence, Union

import networkx as nx


ALLOWED_PROPERTIES: tuple[str, ...] = (
    'atom_type',
    'Z',
    'degree',
    'heavy_degree',
    'num_pi_electrons',
    'num_hs',
    'charge',
    'in_ring',
    'aromatic',  
)

DEFAULT_PROPERTIES: tuple[str, ...] = (
    'atom_type',
    'Z',
    'heavy_degree',
    'num_pi_electrons',
    'num_hs',
    'in_ring',
)

AtomicProperties = Union[Sequence[str], Mapping[int, Sequence[str]]]


def boost_hash_combine(seed: int, hv: int, bits: int = 32) -> int:
    """Combine two integers using Boost's classic `hash_combine` with wrapping.

    Args:
        seed: Current hash value.
        hv: Next value to mix in.
        bits: Bit width to wrap to (default 32). For RDKit parity use 32.

    Returns:
        Updated hash value wrapped to ``bits``.

    Raises:
        ValueError: If bits <= 0.
    """
    if bits <= 0:
        raise ValueError('bits must be a positive integer')
    mask = (1 << bits) - 1
    seed &= mask
    hv &= mask
    k = 0x9e3779b9 if bits <= 32 else 0x9e3779b97f4a7c15
    seed ^= (hv + k + ((seed << 6) & mask) + (seed >> 2)) & mask

    return seed & mask


def hash_components(values: Sequence[int], bits: int = 32) -> int:
    """Hash an ordered sequence of integers into a single value.

    Args:
        values: Integer components to mix in order.
        bits: Bit width to wrap to (default 32).

    Returns:
        Hash value representing the ordered components, wrapped to ``bits``.

    Raises:
        ValueError: If bits <= 0.
    """
    s = 0
    for v in values:
        s = boost_hash_combine(s, int(v), bits)

    return s


def _validate_properties_list(props: Sequence[str]) -> tuple[str, ...]:
    """Validate and normalize a list of property keys.

    Args:
        props: Sequence of atom property keys.

    Returns:
        Tuple of validated property keys.

    Raises:
        KeyError: If a property key is unsupported.
    """
    props_t = tuple(str(p) for p in props)
    unknown = [p for p in props_t if p not in ALLOWED_PROPERTIES]
    if unknown:
        raise KeyError(
            f'Unsupported atom property keys: {unknown}. Allowed keys: {ALLOWED_PROPERTIES}'
        )
    return props_t


def atomic_invariants_from_graph(
    G: nx.Graph,
    properties: AtomicProperties | None = None,
    bits: int = 32,
    node_idxs: Sequence[int] | None = None,
    atom_type_key: str = 'atom_type',
) -> list[int]:
    """Build per-atom invariants from a ctopo graph using selected properties.

    If ``properties`` is a list/tuple of strings, that list is used for all atoms.
    If it is a mapping ``atom_type -> list[str]``, each atom uses the list
    corresponding to its ``atom_type`` (with fallback to DEFAULT_PROPERTIES).

    Args:
        G: NetworkX graph produced by ctopo (Ligand.G or Complex.G).
        properties: Ordered list of property keys to include for each atom, or
            a dict mapping ``atom_type`` -> property list. If not provided,
            DEFAULT_PROPERTIES is used.
        bits: Bit width for the hashed invariant integers (default 32).
        node_idxs: Optional list of node ids to compute invariants. If not provided,
            it falls back to ``sorted(G.nodes())``.
        atom_type_key: Node attribute key holding the integer atom type.

    Returns:
        List of hashed invariants, one per node in the chosen node order.

    Raises:
        KeyError: If an unknown property key is provided, or a node lacks a required attribute.
        ValueError: If bits <= 0.
        TypeError: If properties is neither a sequence of strings nor a mapping.
    """
    if bits <= 0:
        raise ValueError('bits must be a positive integer')

    if properties is None:
        global_props = _validate_properties_list(DEFAULT_PROPERTIES)
        props_by_type: Dict[int, tuple[str, ...]] | None = None

    elif isinstance(properties, Mapping):
        # Validate dict form
        props_by_type = {}
        for k, v in properties.items():
            props_by_type[int(k)] = _validate_properties_list(v)
        global_props = _validate_properties_list(DEFAULT_PROPERTIES)

    else:
        # Sequence[str] form
        global_props = _validate_properties_list(properties)
        props_by_type = None

    if node_idxs is None:
        node_idxs = sorted(G.nodes())

    invariants: list[int] = []

    for idx in node_idxs:
        node = G.nodes[idx]

        if props_by_type is not None:
            at = int(node.get(atom_type_key, 0))
            props = props_by_type.get(at, global_props)
        else:
            props = global_props

        try:
            comps = [node[p] for p in props]
        except KeyError as e:
            missing = e.args[0]
            raise KeyError(
                f'Node {idx} is missing required property {missing!r} for invariant computation'
            ) from None

        invariants.append(hash_components([int(v) for v in comps], bits))

    return invariants


__all__ = [
    'AtomicProperties',
    'ALLOWED_PROPERTIES',
    'DEFAULT_PROPERTIES',
    'boost_hash_combine',
    'hash_components',
    'atomic_invariants_from_graph',
]
