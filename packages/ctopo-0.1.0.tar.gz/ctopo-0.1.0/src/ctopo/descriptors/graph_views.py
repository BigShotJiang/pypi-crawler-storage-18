"""Graph-view helpers for fingerprint computations.

This module defines lightweight transformations ("views") of a chemical graph
represented as an undirected NetworkX graph (ctopo core graphs: Ligand.G and
Complex.G).

A view is a subgraph selection plus a relabeling step to ensure node ids are
contiguous ``0..n-1``. The original atom index is preserved in the node
attribute ``idx``.
"""

from __future__ import annotations

from typing import Dict, Literal, Optional, Sequence, Tuple

import networkx as nx

from ctopo.core.atom_types import AtomType


GraphView = Literal[
    'original',
    'skeleton',
    'skeleton_alpha_substituents',
    'substituent',
    'substituent_alpha_skeleton',
]


def make_graph_view(
    G: nx.Graph,
    view: GraphView = 'original',
    keep_metals: bool = True,
    atom_type_key: str = 'atom_type',
    idx_key: str = 'idx',
) -> Tuple[nx.Graph, Dict[int, int], Dict[int, int]]:
    """Create a relabeled subgraph view with mappings.

    The returned graph is a copy, relabeled to contiguous node ids ``0..n-1``.
    The original atom index should remain available as ``node[idx_key]``.

    Args:
        G: Input molecular graph.
        view: Named view to build.
        keep_metals: If False, drops atoms of CENTER/METAL type.
        atom_type_key: Node attribute key holding atom types (AtomType codes).
        idx_key: Node attribute key holding the original atom index.

    Returns:
        A tuple (V, old_to_new, new_to_old) where:
            V: the view graph with node ids 0..n-1,
            old_to_new: mapping old node id -> new node id,
            new_to_old: mapping new node id -> old node id.

    Raises:
        ValueError: If the view name is unknown.
    """
    if view not in (
        'original',
        'skeleton',
        'skeleton_alpha_substituents',
        'substituent',
        'substituent_alpha_skeleton',
    ):
        raise ValueError(f'Unknown graph view: {view!r}')

    # Start from node set selection
    nodes = set(G.nodes())

    if not keep_metals:
        drop = set()
        for n, data in G.nodes(data=True):
            atom_type = int(data.get(atom_type_key, int(AtomType.UNDEFINED)))
            if atom_type == int(AtomType.CENTER):
                drop.add(n)
        nodes.difference_update(drop)

    if view == 'original':
        keep = nodes

    else:
        def atype(n: int) -> int:
            return int(G.nodes[n].get(atom_type_key, int(AtomType.UNDEFINED)))

        skeleton = {n for n in nodes if atype(n) in (int(AtomType.SKELETON), int(AtomType.DONOR))}
        substituent = {n for n in nodes if atype(n) == int(AtomType.SUBSTITUENT)}

        if view == 'skeleton':
            keep = skeleton

        elif view == 'substituent':
            keep = substituent

        elif view == 'skeleton_alpha_substituents':
            alpha = set()
            for n in skeleton:
                for nb in G.neighbors(n):
                    if nb in substituent:
                        alpha.add(nb)
            keep = skeleton | alpha

        elif view == 'substituent_alpha_skeleton':
            alpha = set()
            for n in substituent:
                for nb in G.neighbors(n):
                    if nb in skeleton:
                        alpha.add(nb)
            keep = substituent | alpha

        else:
            raise ValueError(f'Unknown graph view: {view!r}')

    V0 = G.subgraph(sorted(keep)).copy()

    # Relabel to 0..n-1 (stable order by old node id)
    old_nodes = sorted(V0.nodes())
    old_to_new = {old: i for i, old in enumerate(old_nodes)}
    new_to_old = {i: old for old, i in old_to_new.items()}

    V = nx.relabel_nodes(V0, old_to_new, copy=True)

    return V, old_to_new, new_to_old


__all__ = [
    'GraphView',
    'make_graph_view',
]
