"""Morgan (ECFP-style) fingerprints on a NetworkX chemical graph.

This module implements an RDKit-compatible Morgan fingerprint core that operates on
a NetworkX graph where all required atom/bond properties are stored as node/edge
attributes (i.e., RDKit is not required by the algorithm itself).

Key points for RDKit-compatibility:
- Hash mixing uses boost-style hash_combine applied incrementally, including hashing
  (bondType, neighborInvariant) pairs before combining into the environment id.
- Optional redundant-environment suppression via environment bond-set tracking.
- Chirality handling mirrors RDKit’s logic (conditional inclusion and CIP mixing).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import networkx as nx


def _bitinfo_env(
    center: int,
    radius: int,
    env_sig: int,
    bpos_to_edge: List[Tuple[int, int, int]],
) -> Dict[str, object]:
    """Build a stable bit_info environment record.

    Args:
        center: Center atom id.
        radius: Environment radius (0 for atom invariants; >=1 otherwise).
        env_sig: Bitmask of bonds included in the environment.
        bpos_to_edge: List mapping bond-position -> (bond_idx, u, v).

    Returns:
        Dict with keys: 'radius', 'center', 'nodes', 'edges'.

    Raises:
        None.
    """
    nodes = {int(center)}
    edges: list[int] = []

    sig = int(env_sig)
    while sig:
        low = sig & -sig
        bpos = low.bit_length() - 1
        sig ^= low
        if 0 <= bpos < len(bpos_to_edge):
            bidx, u, v = bpos_to_edge[bpos]
            edges.append(int(bidx))
            nodes.add(int(u))
            nodes.add(int(v))

    return {
        'radius': int(radius),
        'center': int(center),
        'nodes': tuple(sorted(nodes)),
        'edges': tuple(sorted(edges)),
    }

from ctopo.descriptors.atom_hashes import boost_hash_combine, hash_components


_UINT32_MASK = (1 << 32) - 1
_SINGLE_BOND_CODE = 1


@dataclass(frozen=True)
class MorganSpec:
    """Parameters controlling Morgan fingerprint generation.

    Args:
        radius: Number of iterations (ECFP radius).
        use_chirality: If True, incorporate chirality information.
        use_bond_types: If True, incorporate bond types in neighbor pairs.
        only_nonzero_invariants: If True, atoms with round-0 invariant==0 do not emit.
        include_redundant_environments: If True, do not suppress redundant environments.
        bond_code_key: Edge attribute name for integer bond code.
        bond_idx_key: Edge attribute name for unique bond index (for env masks).
        chiral_tag_key: Node attribute name for chiral tag integer.
        cip_code_key: Node attribute name for CIP code string ('R','S',...).

    Raises:
        ValueError: If radius is negative.
    """

    radius: int
    use_chirality: bool = False
    use_bond_types: bool = True
    only_nonzero_invariants: bool = False
    include_redundant_environments: bool = False

    bond_code_key: str = 'bond_code'
    bond_idx_key: str = 'idx'
    chiral_tag_key: str = 'chiral_tag'
    cip_code_key: str = 'cip_code'

    def __post_init__(self) -> None:
        if self.radius < 0:
            raise ValueError('radius must be >= 0')


def _build_index_maps(G: nx.Graph, bond_idx_key: str) -> Tuple[List[int], Dict[int, int], Dict[Tuple[int, int], int], int, List[Tuple[int, int, int]]]:
    """Create stable node and bond index mappings.

    Args:
        G: Molecular graph.
        bond_idx_key: Edge attribute holding a unique bond index.

    Returns:
        node_ids: Sorted list of node ids.
        node_pos: Mapping node_id -> 0..n-1 position.
        edge_bpos: Mapping (u,v) canonicalized -> 0..m-1 bond-position.
        num_bonds: Number of bonds m.
        bpos_to_edge: List of (bond_idx, u, v) in bond-position order.

    Raises:
        ValueError: If an edge is missing bond_idx_key or bond indices are duplicated.
    """
    node_ids = sorted(G.nodes())
    node_pos = {a: i for i, a in enumerate(node_ids)}

    bond_ids: List[Tuple[int, int, int]] = []
    for u, v, d in G.edges(data=True):
        if bond_idx_key not in d:
            raise ValueError(f'Edge ({u},{v}) missing required bond index attribute {bond_idx_key!r}')
        bond_ids.append((int(d[bond_idx_key]), int(u), int(v)))

    bond_ids.sort(key=lambda x: x[0])
    seen = set()
    edge_bpos: Dict[Tuple[int, int], int] = {}
    for bpos, (bidx, u, v) in enumerate(bond_ids):
        if bidx in seen:
            raise ValueError(f'Duplicate bond index {bidx} encountered in graph')
        seen.add(bidx)
        key = (u, v) if u <= v else (v, u)
        edge_bpos[key] = bpos

    return node_ids, node_pos, edge_bpos, len(bond_ids), bond_ids


def _pair_hash_u32(a: int, b: int) -> int:
    """Compute boost-like hash for a pair of uint32 values.

    Args:
        a: First value.
        b: Second value.

    Returns:
        32-bit hashed value.

    Raises:
        None.
    """
    # boost::hash<std::pair<T,T>> effectively hash_combine(seed=0, a), then hash_combine(seed, b)
    return int(hash_components([int(a) & _UINT32_MASK, int(b) & _UINT32_MASK], bits=32)) & _UINT32_MASK


def _cip_salt(cip: str) -> int:
    """Map CIP code to the salt used by RDKit.

    Args:
        cip: CIP code string.

    Returns:
        Integer salt: R->3, S->2, other->1.

    Raises:
        None.
    """
    if cip == 'R':
        return 3
    if cip == 'S':
        return 2
    return 1


def morgan_sparse_counts(
    G: nx.Graph,
    radius: int,
    atom_invariants: Sequence[int],
    emit_from: Optional[Iterable[int]] = None,
    use_chirality: bool = False,
    use_bond_types: bool = True,
    only_nonzero_invariants: bool = False,
    include_redundant_environments: bool = False,
    bit_info: Optional[Dict[int, List[Dict[str, object]]]] = None,
    bond_code_key: str = 'bond_code',
    bond_idx_key: str = 'idx',
    chiral_tag_key: str = 'chiral_tag',
    cip_code_key: str = 'cip_code',
) -> Dict[int, int]:
    """Compute an RDKit-compatible sparse count Morgan fingerprint.

    Args:
        G: Molecular graph (NetworkX, undirected).
        radius: Number of iterations (ECFP radius).
        atom_invariants: Round-0 atom invariants, indexed by atom id (node id).
            For strict RDKit-compat, this should match RDKit’s invariants for the same molecule.
        emit_from: Optional iterable of atom ids to act as centers (like RDKit emitFrom).
        use_chirality: If True, incorporate chirality.
        use_bond_types: If True, incorporate bond types in hashing.
        only_nonzero_invariants: If True, atoms with invariant==0 (round-0) do not emit.
        include_redundant_environments: If True, do not suppress redundant environments.
        bit_info: Optional dict populated as bit_info[feature_id] -> list of (atom_id, radius).
        bond_code_key: Edge attribute name for integer bond code.
        bond_idx_key: Edge attribute name for unique bond index (for env masks).
        chiral_tag_key: Node attribute name for chiral tag integer.
        cip_code_key: Node attribute name for CIP code string ('R','S',...).

    Returns:
        Mapping feature_id -> count.

    Raises:
        ValueError: If node ids are incompatible with atom_invariants length or
            if required edge attributes are missing.
    """
    params = MorganSpec(
        radius=radius,
        use_chirality=use_chirality,
        use_bond_types=use_bond_types,
        only_nonzero_invariants=only_nonzero_invariants,
        include_redundant_environments=include_redundant_environments,
        bond_code_key=bond_code_key,
        bond_idx_key=bond_idx_key,
        chiral_tag_key=chiral_tag_key,
        cip_code_key=cip_code_key,
    )

    node_ids, node_pos, edge_bpos, _, bpos_to_edge = _build_index_maps(G, params.bond_idx_key)

    # We assume node ids are integer atom ids and atom_invariants is indexed by that id.
    # This matches your RDKit->nx conversion (node id == atom idx).
    max_node = max(node_ids) if node_ids else -1
    if max_node >= len(atom_invariants):
        raise ValueError('atom_invariants is too short for the maximum node id in G')

    include_atoms: set[int]
    if emit_from is None:
        include_atoms = set(node_ids)
    else:
        if isinstance(emit_from, str):
            raise TypeError('emit_from must be an iterable of atom indices (not a string)')
        include_atoms = set(int(a) for a in emit_from)

    # invariants are stored by node id:
    invariants: Dict[int, int] = {a: int(atom_invariants[int(a)]) & _UINT32_MASK for a in node_ids}
    invariant_cpy: Dict[int, int] = dict(invariants)

    # round-0 emission:
    out: Dict[int, int] = {}
    for a in node_ids:
        if a in include_atoms:
            inv = invariants[a]
            if (not params.only_nonzero_invariants) or inv != 0:
                out[inv] = out.get(inv, 0) + 1
                if bit_info is not None:
                    bit_info.setdefault(inv, []).append({'radius': 0, 'center': a, 'nodes': (a,), 'edges': ()})

    # Environment masks (bond sets) per atom, represented as Python ints (bitsets).
    atom_env: Dict[int, int] = {a: 0 for a in node_ids}
    dead_atoms: set[int] = set()
    chiral_atoms: set[int] = set()

    # Atom processing order (onlyNonzeroInvariants puts zeros last).
    if params.only_nonzero_invariants:
        atom_order = sorted(node_ids, key=lambda a: (1 if invariant_cpy[a] == 0 else 0, a))
    else:
        atom_order = list(node_ids)

    # Environments already emitted (bond-set signatures).
    neighborhoods_seen: set[int] = set()

    for layer in range(params.radius):
        round_invariants: Dict[int, int] = {a: 0 for a in node_ids}
        round_env: Dict[int, int] = dict(atom_env)
        neighborhoods_this_round: List[Tuple[int, int, int]] = []

        for a in atom_order:
            if a in dead_atoms:
                # RDKit skips processing and leaves round_invariants[a]=0.
                continue

            # expand environment:
            invar = int(layer) & _UINT32_MASK
            invar = boost_hash_combine(invar, invariants[a], bits=32)

            looks_chiral = False
            if params.use_chirality:
                looks_chiral = int(G.nodes[a].get(params.chiral_tag_key, 0)) != 0

            possible_dupes: List[int] = []
            nbrs: List[Tuple[int, int]] = []

            for b in G.adj[a]:
                ekey = (a, b) if a <= b else (b, a)
                if ekey not in edge_bpos:
                    # should not happen if edge map built from G
                    continue
                bpos = edge_bpos[ekey]
                round_env[a] |= (1 << bpos)

                # grow by union with neighbor's previous environment
                round_env[a] |= atom_env[b]

                bt = int(G.edges[a, b].get(params.bond_code_key, _SINGLE_BOND_CODE))
                if not params.use_bond_types:
                    bt = _SINGLE_BOND_CODE

                nb_inv = invariants[b]
                nbrs.append((bt, nb_inv))

                # Chirality disambiguation: only in later rounds once atom is already chiral.
                if params.use_chirality and looks_chiral and (a in chiral_atoms):
                    if bt != _SINGLE_BOND_CODE:
                        looks_chiral = False
                    else:
                        possible_dupes.append(nb_inv)

            # neighbor list is sorted before hashing:
            nbrs.sort()

            # if chiral and already flagged, ensure no duplicate neighbor invariants:
            if params.use_chirality and looks_chiral and (a in chiral_atoms):
                possible_dupes.sort()
                for i in range(1, len(possible_dupes)):
                    if possible_dupes[i] == possible_dupes[i - 1]:
                        looks_chiral = False
                        break

            # incremental hash combine of neighbor pair hashes:
            for bt, nb_inv in nbrs:
                ph = _pair_hash_u32(bt, nb_inv)
                invar = boost_hash_combine(invar, ph, bits=32)

            # incorporate chirality salt:
            if params.use_chirality and looks_chiral:
                chiral_atoms.add(a)
                cip = str(G.nodes[a].get(params.cip_code_key, ''))
                invar = boost_hash_combine(invar, _cip_salt(cip), bits=32)

            invar &= _UINT32_MASK
            round_invariants[a] = invar

            # redundant environment suppression (unless user asked to include redundants):
            env_sig = round_env[a]
            if (not params.include_redundant_environments) and (env_sig in neighborhoods_seen):
                dead_atoms.add(a)

            neighborhoods_this_round.append((env_sig, invar, a))

        # Sort then emit unique environments (or all, if include_redundant_environments)
        neighborhoods_this_round.sort()

        for env_sig, invar, a in neighborhoods_this_round:
            if params.include_redundant_environments or (env_sig not in neighborhoods_seen):
                if (not params.only_nonzero_invariants) or (invariant_cpy[a] != 0):
                    if a in include_atoms:
                        out[invar] = out.get(invar, 0) + 1
                        if bit_info is not None:
                            # RDKit stores layer+1 for radii >=1
                            bit_info.setdefault(invar, []).append(_bitinfo_env(a, layer + 1, env_sig, bpos_to_edge))

                # RDKit only tracks neighborhoods for included atoms (emitFrom behavior)
                if a in include_atoms and (not params.include_redundant_environments):
                    neighborhoods_seen.add(env_sig)
            else:
                # duplicate within this round: mark dead in RDKit mode
                if not params.include_redundant_environments:
                    dead_atoms.add(a)

        invariants = round_invariants
        atom_env = round_env

    return out


