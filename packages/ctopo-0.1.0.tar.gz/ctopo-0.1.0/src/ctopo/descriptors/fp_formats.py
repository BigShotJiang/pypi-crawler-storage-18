"""Fingerprint format utilities.

This module provides helpers to transform a sparse count fingerprint
(mapping feature_id -> count) into commonly used fixed-size representations.

The sparse-count representation is the canonical internal format in ctopo,
since it is convenient for both algorithm implementations and ML workflows.
"""

from __future__ import annotations

from typing import Dict, Literal, Optional, Set, Union

import numpy as np


CountsFP = Dict[int, int]
FoldedCountsFP = Dict[int, int]
BitsSet = Set[int]
BitsDict = Dict[int, int]

FoldCountsOut = Union[FoldedCountsFP, np.ndarray]
BitsOut = Union[BitsSet, BitsDict, np.ndarray]

FoldCountsFormat = Literal['dict', 'numpy']
BitsFormat = Literal['set', 'dict', 'numpy']


def fold_counts(
    counts: CountsFP,
    fp_size: int,
    output_format: FoldCountsFormat = 'dict',
    dtype: Optional[np.dtype] = None,
) -> FoldCountsOut:
    """Fold sparse feature counts into a fixed-size hashed count fingerprint.

    Args:
        counts: Sparse mapping feature_id -> count.
        fp_size: Target fingerprint length (number of positions).
        output_format: Output format. Supported values:
            - 'dict': return dict bit_index -> count (sparse)
            - 'numpy': return dense numpy array of shape (fp_size,)
        dtype: Optional numpy dtype for output_format='numpy'. If omitted, uses
            numpy.int32.

    Returns:
        Folded fingerprint in the requested format.

    Raises:
        ValueError: If fp_size <= 0.
        ValueError: If output_format is unsupported.
    """

    if fp_size <= 0:
        raise ValueError('fp_size must be a positive integer')

    m = int(fp_size)

    if output_format == 'dict':
        out: FoldedCountsFP = {}
        for fid, c in counts.items():
            bit = int(fid) % m
            out[bit] = out.get(bit, 0) + int(c)
        return out

    if output_format == 'numpy':
        if dtype is None:
            dtype = np.int32
        arr = np.zeros(m, dtype=dtype)
        for fid, c in counts.items():
            bit = int(fid) % m
            arr[bit] += int(c)
        return arr

    raise ValueError(f'Unsupported output_format: {output_format!r}')


def counts_to_bits(
    counts: CountsFP,
    fp_size: int,
    output_format: BitsFormat = 'set',
    dtype: Optional[np.dtype] = None,
) -> BitsOut:
    """Convert sparse feature counts into a fixed-size presence representation.

    Args:
        counts: Sparse mapping feature_id -> count.
        fp_size: Target fingerprint length (number of positions).
        output_format: Output format. Supported values:
            - 'set': return set of present bit indices
            - 'dict': return dict bit_index -> 1 for present bits
            - 'numpy': return dense numpy array of shape (fp_size,) with 0/1 values
        dtype: Optional numpy dtype for output_format='numpy'. If omitted, uses
            numpy.uint8.

    Returns:
        Presence representation in the requested format.

    Raises:
        ValueError: If fp_size <= 0.
        ValueError: If output_format is unsupported.
    """

    if fp_size <= 0:
        raise ValueError('fp_size must be a positive integer')

    m = int(fp_size)

    if output_format in ('set', 'dict'):
        bits: BitsSet = set()
        for fid in counts.keys():
            bits.add(int(fid) % m)
        if output_format == 'set':
            return bits
        return {b: 1 for b in bits}

    if output_format == 'numpy':
        if dtype is None:
            dtype = np.uint8
        arr = np.zeros(m, dtype=dtype)
        for fid in counts.keys():
            bit = int(fid) % m
            arr[bit] = 1
        return arr

    raise ValueError(f'Unsupported output_format: {output_format!r}')




__all__ = [
    'FoldCountsFormat',
    'BitsFormat',
    'fold_counts',
    'counts_to_bits',
]
