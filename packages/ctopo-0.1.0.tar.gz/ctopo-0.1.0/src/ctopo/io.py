"""I/O helpers for constructing cTopo objects from SMILES.

Conventions:
- Donor atoms are indicated by non-zero atomic map numbers in the SMILES.
- For ligands: mapped atoms become donor atoms.
- For complexes:
    * donor atoms must be mapped (map number != 0),
    * metal center atoms are inferred from dative bonds originating at mapped donors,
    * all metal bonds must be dative and oriented donor -> metal (validated by complex_from_mol).
"""

from __future__ import annotations

from typing import Optional, Sequence

from rdkit import Chem

from ctopo.core.ligand import Ligand, SmilesSettings, SvgSettings, ligand_from_mol
from ctopo.core.complex import Complex, complex_from_mol, _is_dative_bond


def ligand_from_smiles(
    smiles: str,
    smiles_settings: Optional[SmilesSettings] = None,
    svg_settings: Optional[SvgSettings] = None,
) -> Ligand:
    """Construct a Ligand from a SMILES string.

    Donor atoms are determined by atoms with atom map numbers != 0.

    The function:
      - parses SMILES,
      - collects donor atom indices (map != 0),
      - clears atom map numbers everywhere,
      - calls ligand_from_mol(mol, donor_atoms=...).

    Args:
        smiles: SMILES string. Donors must be marked via atom-map numbers.
        smiles_settings: Optional default visualization SMILES settings to store in Ligand.
        svg_settings: Optional default visualization SVG settings to store in Ligand.

    Returns:
        Ligand instance.

    Raises:
        ValueError: If SMILES is invalid or no donor atoms are marked.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError('invalid SMILES')

    donor_atoms = [a.GetIdx() for a in mol.GetAtoms() if int(a.GetAtomMapNum()) != 0]
    if len(donor_atoms) == 0:
        raise ValueError('ligand_from_smiles requires donor atoms marked by atom-map numbers')

    for a in mol.GetAtoms():
        a.SetAtomMapNum(0)

    return ligand_from_mol(
        mol,
        donor_atoms,
        smiles_settings=smiles_settings,
        svg_settings=svg_settings,
    )


def complex_from_smiles(smiles: str) -> Complex:
    """Construct a Complex from a SMILES string.

    Convention (no atom-map requirement):
      - Metal–ligand coordination must be encoded via RDKit dative bonds.
      - Each dative bond must be oriented donor -> metal (i.e., the metal is the end atom).
      - Any atom inferred as a metal center must have only:
          * dative bonds to non-metal atoms (metal is the end atom), and
          * non-dative bonds to other metal atoms (metal–metal bonds are allowed but must be non-dative).

    Atom-map numbers (if present) are ignored for inference and cleared before constructing
    the cTopo object.

    Args:
        smiles: SMILES string. Coordination must be represented with dative bonds.

    Returns:
        Complex instance.

    Raises:
        ValueError: If SMILES is invalid or the coordination encoding requirements are violated.
    """
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError('invalid SMILES')

    dative_bonds = [b for b in mol.GetBonds() if _is_dative_bond(b)]
    if len(dative_bonds) == 0:
        raise ValueError('complex_from_smiles requires at least one dative bond to infer metal centers')

    # Metals are inferred as acceptors (end atoms) of dative bonds.
    metal_atoms: set[int] = {int(b.GetEndAtomIdx()) for b in dative_bonds}

    # Dative bonds must be donor -> metal; metal may not be the donor (begin) in any dative bond.
    for b in dative_bonds:
        begin = int(b.GetBeginAtomIdx())
        end = int(b.GetEndAtomIdx())

        if end not in metal_atoms:
            raise ValueError('internal error: end atom of a dative bond must be inferred as metal')

        if begin in metal_atoms:
            raise ValueError(
                f'dative bond must start at donor and end at metal; found begin atom {begin} inferred as metal'
            )

    # Validate bonds incident to each inferred metal:
    # - metal–nonmetal must be dative and end at the metal
    # - metal–metal must be non-dative
    for m in sorted(metal_atoms):
        a = mol.GetAtomWithIdx(int(m))
        bonds = list(a.GetBonds())
        if len(bonds) == 0:
            raise ValueError(f'metal atom {m} has no bonds')

        for b in bonds:
            other = int(b.GetOtherAtomIdx(int(m)))

            if other in metal_atoms:
                # Metal–metal bonds are allowed, but must be non-dative
                if _is_dative_bond(b):
                    raise ValueError(
                        f'metal–metal bond between {m} and {other} must be non-dative (found {str(b.GetBondType())})'
                    )
                continue

            # Metal–nonmetal bonds must be dative and oriented donor -> metal
            if not _is_dative_bond(b):
                raise ValueError(
                    f'metal atom {m} has a non-dative bond to non-metal atom {other} of type {str(b.GetBondType())}'
                )
            if int(b.GetEndAtomIdx()) != int(m):
                raise ValueError(
                    f'dative bond must end at metal atom {m} (found end={b.GetEndAtomIdx()})'
                )

    # Clear atom-map numbers before building the cTopo object.
    for a in mol.GetAtoms():
        a.SetAtomMapNum(0)

    return complex_from_mol(mol, sorted(metal_atoms))



__all__ = [
    'ligand_from_smiles',
    'complex_from_smiles',
]


