"""Ligand skeleton and topology transformations for dataset visualization.

This module provides two lightweight graph transformations for ligand analysis:

1) get_ligands_skeleton(G):
   Returns the ligand "skeleton" as a subgraph of the original ligand graph.
   The skeleton contains donor atoms and skeleton atoms (i.e., atoms on the
   union of shortest paths between donor pairs).

2) get_ligands_topology(G):
   Returns a simplified "topology" graph derived from the skeleton by
   suppressing linear linkers and removing triangle "bubbles",
   mirroring the provided RDKit reference algorithm with ignore_cycles=False.

Topology graph requirements (per spec):
- contains only single bonds,
- donor atoms retain their original node attributes,
- all other remaining atoms are dummies with minimal attributes (only Z=0).
"""

from __future__ import annotations

from typing import Optional, Set, Tuple

import networkx as nx

from ctopo.core.atom_types import AtomType
from ctopo.core.partition import skeleton_from_donors



#%% Skeleton

def _donor_nodes(G: nx.Graph, atom_type_key: str = 'atom_type') -> list[int]:
    donors: list[int] = []
    for n, data in G.nodes(data=True):
        if int(data.get(atom_type_key, int(AtomType.UNDEFINED))) == int(AtomType.DONOR):
            donors.append(int(n))
    donors.sort()
    return donors


def _skeleton_nodes_from_labels(G: nx.Graph, atom_type_key: str = 'atom_type') -> Tuple[Set[int], bool]:
    """Return skeleton-node set using AtomType labels if present.

    Returns (keep_nodes, used_labels). If no labeled skeleton nodes exist,
    returns (empty_set, False).
    """
    keep: Set[int] = set()
    saw_skeleton = False
    for n, data in G.nodes(data=True):
        at = int(data.get(atom_type_key, int(AtomType.UNDEFINED)))
        if at == int(AtomType.SKELETON):
            saw_skeleton = True
            keep.add(int(n))
        elif at == int(AtomType.DONOR):
            keep.add(int(n))
    if not saw_skeleton:
        return set(), False
    return keep, True


def get_ligands_skeleton(G: nx.Graph, atom_type_key: str = 'atom_type') -> nx.Graph:
    """Return the ligand skeleton as an induced subgraph of the original graph.

    Skeleton definition:
      - Prefer precomputed AtomType labels: keep atoms with type in {DONOR, SKELETON}.
      - Otherwise compute skeleton as the union of nodes on all shortest paths
        between donor pairs (plus donors themselves).

    Args:
        G: Original ligand graph (NetworkX Graph).
        atom_type_key: Node attribute holding AtomType integer codes.

    Returns:
        A copy of the induced skeleton subgraph (same node ids as in G).

    Raises:
        ValueError: If no donor atoms are present.
    """
    donors = _donor_nodes(G, atom_type_key=atom_type_key)
    if not donors:
        raise ValueError('Ligand graph must contain at least one donor atom (AtomType.DONOR).')

    keep, used = _skeleton_nodes_from_labels(G, atom_type_key=atom_type_key)

    if not used:
        skel = skeleton_from_donors(G, donors)
        keep = set(donors) | set(skel)

    return G.subgraph(sorted(keep)).copy()



#%% Topology reduction helpers

def _neighbors_two(G: nx.Graph, n: int) -> tuple[int, int]:
    ns = list(G.neighbors(n))
    if len(ns) != 2:
        raise ValueError('Internal error: expected degree-2 node.')
    return int(ns[0]), int(ns[1])


def _find_degree2_non_donor(G: nx.Graph, donors: Set[int], bubble: bool) -> Optional[int]:
    """Find next removable node, mirroring RDKit's sequential scan behavior.

    bubble=False: degree-2 non-donor whose neighbors are NOT bonded
    bubble=True:  degree-2 non-donor whose neighbors ARE bonded
    """
    for n in sorted(G.nodes()):
        n = int(n)
        if n in donors:
            continue
        if G.degree(n) != 2:
            continue
        u, v = _neighbors_two(G, n)
        bonded = G.has_edge(u, v)
        if bubble and bonded:
            return n
        if (not bubble) and (not bonded):
            return n
    return None


def _remove_degree2_node(G: nx.Graph, n: int, bubble: bool) -> None:
    """Remove degree-2 node n; connect neighbors if not a bubble."""
    u, v = _neighbors_two(G, n)
    if not bubble:
        # Contract a linear linker: connect endpoints (single bond attrs added later)
        if u != v and not G.has_edge(u, v):
            G.add_edge(u, v)
    # Remove the node itself
    G.remove_node(n)


def _reduce_degree2(G: nx.Graph, donors: Set[int], bubble: bool) -> None:
    """Repeatedly remove degree-2 non-donor nodes under the chosen criterion."""
    n = _find_degree2_non_donor(G, donors, bubble=bubble)
    while n is not None:
        _remove_degree2_node(G, n, bubble=bubble)
        n = _find_degree2_non_donor(G, donors, bubble=bubble)


def _normalize_edges_single(G: nx.Graph) -> None:
    """Normalize all edges to single bonds with minimal deterministic attributes."""
    i = 0
    for u, v in sorted(G.edges()):
        data = G.edges[u, v]
        data.clear()
        data['idx'] = i
        data['bond_order'] = 1.0
        data['bond_type'] = 'SINGLE'
        i += 1



#%% Topology

def get_ligands_topology(G: nx.Graph, atom_type_key: str = 'atom_type') -> nx.Graph:
    """Return a simplified topology graph of the ligand (ignore_cycles=False behavior).

    Algorithm (mirrors your RDKit reference):
      - start from ligand skeleton
      - remove linear linkers (degree-2 non-donors, neighbors not bonded) by contracting
      - remove bubbles (degree-2 non-donors, neighbors bonded) by deleting
      - remove remaining linear linkers again
      - finalize:
          * donors keep original node attributes
          * non-donors become dummy nodes with only {'Z': 0}
          * all edges become single bonds with minimal attrs

    Args:
        G: Original ligand graph (NetworkX Graph).
        atom_type_key: Node attribute holding AtomType integer codes.

    Returns:
        A new NetworkX Graph representing the ligand topology.

    Raises:
        ValueError: If no donor atoms are present.
    """
    donors_list = _donor_nodes(G, atom_type_key=atom_type_key)
    if not donors_list:
        raise ValueError('Ligand graph must contain at least one donor atom (AtomType.DONOR).')
    donors: Set[int] = set(donors_list)

    topo = get_ligands_skeleton(G, atom_type_key=atom_type_key)

    # 1) Linear linkers
    _reduce_degree2(topo, donors, bubble=False)

    # 2) Bubbles (triangles created by contractions, etc.)
    _reduce_degree2(topo, donors, bubble=True)

    # 3) Remaining linear linkers
    _reduce_degree2(topo, donors, bubble=False)

    # Normalize edges (single bonds, minimal attrs)
    _normalize_edges_single(topo)

    # Normalize node attrs: donors keep original, others become dummies
    for n in list(topo.nodes()):
        n = int(n)
        if n in donors:
            attrs = dict(G.nodes[n]) if n in G.nodes else dict(topo.nodes[n])
            topo.nodes[n].clear()
            topo.nodes[n].update(attrs)
        else:
            topo.nodes[n].clear()
            topo.nodes[n]['Z'] = 0

    return topo


__all__ = [
    'get_ligands_skeleton',
    'get_ligands_topology',
]


