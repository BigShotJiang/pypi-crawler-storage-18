from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import pytest
from rdkit import Chem
from rdkit.Chem import rdchem

from ctopo.core.complex import complex_from_mol
from ctopo.fragments import ligands_from_complex


def _parse_ligand_smiles_and_extract_donors(smi: str) -> Tuple[Chem.Mol, List[int], int]:
    """Parse a ligand SMILES, return (mol_with_maps_cleared, donor_atom_indices, n_donors).

    Donors are atoms with atom map numbers != 0.
    """
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        raise ValueError(f'invalid ligand SMILES: {smi!r}')

    donors = [a.GetIdx() for a in mol.GetAtoms() if int(a.GetAtomMapNum()) != 0]
    if len(donors) == 0:
        raise ValueError(f'ligand SMILES has no mapped donor atoms: {smi!r}')

    # clear maps
    for a in mol.GetAtoms():
        a.SetAtomMapNum(0)

    # sanitize so that expected SMILES keys are stable
    Chem.SanitizeMol(mol)

    return mol, donors, len(donors)


def _expected_unique_counts_and_donor_counts(ligand_smiles: Sequence[str]) -> Tuple[Dict[str, int], Dict[str, int]]:
    """Compute expected unique SMILES->count and SMILES->n_donors from ligand SMILES list."""
    counts: Dict[str, int] = {}
    donor_counts: Dict[str, int] = {}

    for smi in ligand_smiles:
        mol, _, n_d = _parse_ligand_smiles_and_extract_donors(smi)
        key = Chem.MolToSmiles(mol, canonical=True, isomericSmiles=True)
        counts[key] = counts.get(key, 0) + 1
        if key in donor_counts:
            # same ligand type should have consistent donor count
            assert donor_counts[key] == n_d
        else:
            donor_counts[key] = n_d

    return counts, donor_counts


def build_complex_from_ligand_smiles_list(
    ligand_smiles: Sequence[str],
    *,
    metal_atomic_num: int = 29,  # Cu
    metal_charge: int = 2,
) -> Tuple[Chem.Mol, int]:
    """Build an RDKit complex Mol from ligand SMILES list.

    Steps:
      - parse each ligand SMILES
      - detect donor atoms via atom map numbers
      - clear atom map numbers
      - combine all ligands into one disconnected Mol
      - add one metal atom
      - add donor->metal dative bonds for each mapped donor atom

    Returns:
      (complex_mol, metal_atom_index)
    """
    if len(ligand_smiles) == 0:
        raise ValueError('ligand_smiles must be non-empty')

    ligand_mols: List[Chem.Mol] = []
    donors_per_lig: List[List[int]] = []

    for smi in ligand_smiles:
        mol, donors, _ = _parse_ligand_smiles_and_extract_donors(smi)
        ligand_mols.append(mol)
        donors_per_lig.append(donors)

    # Combine ligands into one Mol and compute global donor indices.
    combined = ligand_mols[0]
    donor_global: List[int] = list(donors_per_lig[0])
    offset = ligand_mols[0].GetNumAtoms()

    for mol, donors in zip(ligand_mols[1:], donors_per_lig[1:]):
        combined = Chem.CombineMols(combined, mol)
        donor_global.extend([offset + int(d) for d in donors])
        offset += mol.GetNumAtoms()

    rw = Chem.RWMol(combined)

    metal = Chem.Atom(int(metal_atomic_num))
    metal.SetFormalCharge(int(metal_charge))
    metal_idx = int(rw.AddAtom(metal))

    for d in donor_global:
        rw.AddBond(int(d), int(metal_idx), rdchem.BondType.DATIVE)

    mol = rw.GetMol()
    Chem.SanitizeMol(mol)
    return mol, metal_idx


@pytest.mark.parametrize(
    'ligand_smiles',
    [
        ['[Cl-:1]', '[Cl-:1]', '[NH2:1]CC[NH2:1]', '[NH2:1]CC[NH2:1]'],
        ['[O-:1]C(=O)CC[N:3](CCC(=O)[O-:2])CC[N:4](CCC(=O)[O-:5])CCC(=O)[O-:6]'],
    ],
)
def test_ligands_from_complex_unique_counts_and_return_all(ligand_smiles: Sequence[str]) -> None:
    expected_counts, expected_donor_counts = _expected_unique_counts_and_donor_counts(ligand_smiles)

    mol, metal_idx = build_complex_from_ligand_smiles_list(ligand_smiles, metal_atomic_num=29, metal_charge=2)
    comp = complex_from_mol(mol, [metal_idx])

    unique_counts = ligands_from_complex(comp)

    # We connected every ligand to the metal, so every input ligand should yield a donor-containing fragment.
    assert sum(lc.count for lc in unique_counts) == len(ligand_smiles)

    got_counts = {lc.smiles: lc.count for lc in unique_counts}
    assert sorted(got_counts.values()) == sorted(expected_counts.values())

    # Representative donor counts should match expectation per unique ligand SMILES.
    for lc in unique_counts:
        assert any( Chem.MolFromSmiles(lc.smiles).HasSubstructMatch(Chem.MolFromSmiles(smiles)) for smiles in ligand_smiles )

    # Extracted ligands should not contain the metal atom (Cu here).
    for lc in unique_counts:
        assert all(int(a.GetAtomicNum()) != 29 for a in lc.ligand.mol.GetAtoms())


