from __future__ import annotations

import numpy as np
import pytest

from ctopo.distances import (
    tanimoto_distance_bits,
    tanimoto_distance_counts,
    tanimoto_similarity_bits,
    tanimoto_similarity_counts,
)


def test_tanimoto_bits_identical_sets() -> None:
    a = {1, 2, 10}
    b = {1, 2, 10}
    assert tanimoto_similarity_bits(a, b) == 1.0
    assert tanimoto_distance_bits(a, b) == 0.0


def test_tanimoto_bits_disjoint_sets() -> None:
    a = {1, 2}
    b = {3, 4}
    assert tanimoto_similarity_bits(a, b) == 0.0
    assert tanimoto_distance_bits(a, b) == 1.0


def test_tanimoto_bits_partial_overlap_sets() -> None:
    a = {1, 2, 3}
    b = {3, 4}
    # inter = 1, union = 4 => 0.25
    assert tanimoto_similarity_bits(a, b) == 0.25
    assert tanimoto_distance_bits(a, b) == 0.75


def test_tanimoto_bits_empty_is_one_by_convention() -> None:
    assert tanimoto_similarity_bits(set(), set()) == 1.0
    assert tanimoto_distance_bits(set(), set()) == 0.0


def test_tanimoto_bits_numpy_bool_and_numpy_int() -> None:
    a = np.array([0, 1, 0, 1, 0], dtype=bool)      # on bits: {1, 3}
    b = np.array([0, 1, 1, 0, 0], dtype=np.int32)  # on bits: {1, 2}
    # inter = {1} size 1, union = {1,2,3} size 3 => 1/3
    assert tanimoto_similarity_bits(a, b) == pytest.approx(1.0 / 3.0)
    assert tanimoto_distance_bits(a, b) == pytest.approx(2.0 / 3.0)


def test_tanimoto_bits_mapping_keys_only() -> None:
    # values should be ignored
    a = {1: 999, 2: -5}
    b = {2: 0, 3: 0}
    # inter={2} size 1, union={1,2,3} size 3 => 1/3
    assert tanimoto_similarity_bits(a, b) == pytest.approx(1.0 / 3.0)


class _FakeExplicitBitVect:
    def __init__(self, on_bits: list[int]) -> None:
        self._on = on_bits

    def GetOnBits(self):
        return list(self._on)


def test_tanimoto_bits_rdkit_like_object() -> None:
    a = _FakeExplicitBitVect([1, 3, 5])
    b = _FakeExplicitBitVect([3, 4])
    # inter=1 (bit 3), union=4 => 0.25
    assert tanimoto_similarity_bits(a, b) == 0.25


def test_tanimoto_counts_sparse_sparse_correctness() -> None:
    a = {0: 2, 1: 1}
    b = {0: 1, 1: 1, 2: 1}
    # dot = 2*1 + 1*1 = 3
    # ||a||^2 = 2^2 + 1^2 = 5
    # ||b||^2 = 1^2 + 1^2 + 1^2 = 3
    # denom = 5 + 3 - 3 = 5 => sim = 3/5 = 0.6
    assert tanimoto_similarity_counts(a, b) == pytest.approx(0.6)
    assert tanimoto_distance_counts(a, b) == pytest.approx(0.4)


def test_tanimoto_counts_dense_dense_correctness() -> None:
    a = np.array([2.0, 1.0, 0.0])
    b = np.array([1.0, 1.0, 1.0])
    assert tanimoto_similarity_counts(a, b) == pytest.approx(0.6)
    assert tanimoto_distance_counts(a, b) == pytest.approx(0.4)


def test_tanimoto_counts_sparse_dense_matches_dense_dense() -> None:
    a_sparse = {0: 2, 1: 1}
    a_dense = np.array([2.0, 1.0, 0.0])
    b_dense = np.array([1.0, 1.0, 1.0])

    s1 = tanimoto_similarity_counts(a_sparse, b_dense)
    s2 = tanimoto_similarity_counts(a_dense, b_dense)
    assert s1 == pytest.approx(s2)

    # and symmetric
    s3 = tanimoto_similarity_counts(b_dense, a_sparse)
    assert s3 == pytest.approx(s2)


def test_tanimoto_counts_accepts_python_sequences() -> None:
    a = [2, 1, 0]
    b = [1, 1, 1]
    assert tanimoto_similarity_counts(a, b) == pytest.approx(0.6)


def test_tanimoto_counts_all_zero_is_one_by_convention() -> None:
    assert tanimoto_similarity_counts({}, {}) == 1.0
    assert tanimoto_distance_counts({}, {}) == 0.0

    assert tanimoto_similarity_counts([0.0, 0.0], [0.0, 0.0]) == 1.0
    assert tanimoto_distance_counts([0.0, 0.0], [0.0, 0.0]) == 0.0


def test_tanimoto_counts_negative_sparse_raises() -> None:
    with pytest.raises(ValueError):
        tanimoto_similarity_counts({0: -1}, {0: 1})


def test_tanimoto_counts_negative_dense_raises() -> None:
    with pytest.raises(ValueError):
        tanimoto_similarity_counts(np.array([0.0, -1.0]), np.array([0.0, 1.0]))


def test_tanimoto_counts_dense_length_mismatch_raises() -> None:
    with pytest.raises(ValueError):
        tanimoto_similarity_counts(np.array([1.0, 0.0]), np.array([1.0, 0.0, 0.0]))


def test_tanimoto_counts_sparse_out_of_bounds_key_ignored_in_dot() -> None:
    # key 10 is out of range for b, so it contributes to ||a||^2 but not to dot.
    a = {0: 1.0, 10: 1.0}
    b = np.array([1.0, 0.0, 0.0])
    # dot = 1*1 = 1
    # ||a||^2 = 1^2 + 1^2 = 2
    # ||b||^2 = 1
    # denom = 2 + 1 - 1 = 2 => sim = 1/2
    assert tanimoto_similarity_counts(a, b) == pytest.approx(0.5)


