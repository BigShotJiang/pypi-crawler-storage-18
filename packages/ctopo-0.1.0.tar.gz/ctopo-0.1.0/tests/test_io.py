from __future__ import annotations

import pytest
from rdkit import Chem, RDLogger
from rdkit.Chem import rdchem

from ctopo.io import ligand_from_smiles, complex_from_smiles
from ctopo.core.atom_types import AtomType

# turn off RDKit warning messages
RDLogger.DisableLog('rdApp.*')


#%% helpers

def _is_dative_bond(b: Chem.Bond) -> bool:
    bt = str(b.GetBondType())
    return bt in ('DATIVE', 'DATIVEL', 'DATIVER')


def _infer_expected_complex_sets(smiles: str) -> tuple[set[int], set[int]]:
    """Infer expected (donors, metals) from a SMILES using the same convention as io.py:
    - metals: end atoms of DATIVE bonds
    - donors: begin atoms of DATIVE bonds
    """
    mol = Chem.MolFromSmiles(smiles)
    assert mol is not None, 'test SMILES must be RDKit-parseable'

    metals: set[int] = set()
    donors: set[int] = set()
    for b in mol.GetBonds():
        if not _is_dative_bond(b):
            continue
        donors.add(int(b.GetBeginAtomIdx()))
        metals.add(int(b.GetEndAtomIdx()))

    return donors, metals


def _make_cu_dative_complex_smiles(
    *,
    n_donors: int = 2,
    reverse_direction: bool = False,
    use_non_dative_metal_ligand_bond: bool = False,
    add_atom_maps: bool = True,
) -> str:
    """Build a minimal Cu complex with N donors and return RDKit SMILES.

    By default creates donor -> metal DATIVE bonds.

    Options:
      - reverse_direction: metal -> donor DATIVE bonds (invalid for our convention)
      - use_non_dative_metal_ligand_bond: uses SINGLE instead of DATIVE for metal–ligand (invalid)
      - add_atom_maps: if True, puts atom-map numbers on donors (should be ignored/cleared by io)
    """
    rw = Chem.RWMol()

    cu = Chem.Atom(29)  # Cu
    cu.SetFormalCharge(2)
    m_idx = int(rw.AddAtom(cu))

    donor_idxs: list[int] = []
    for _ in range(int(n_donors)):
        n = Chem.Atom(7)  # N
        d_idx = int(rw.AddAtom(n))
        donor_idxs.append(d_idx)

        if use_non_dative_metal_ligand_bond:
            rw.AddBond(d_idx, m_idx, rdchem.BondType.SINGLE)
        else:
            if reverse_direction:
                rw.AddBond(m_idx, d_idx, rdchem.BondType.DATIVE)
            else:
                rw.AddBond(d_idx, m_idx, rdchem.BondType.DATIVE)

    mol = rw.GetMol()

    if add_atom_maps:
        for j, d_idx in enumerate(donor_idxs, start=1):
            mol.GetAtomWithIdx(int(d_idx)).SetAtomMapNum(int(j))

    Chem.SanitizeMol(mol)
    return Chem.MolToSmiles(mol)


def _make_bimetal_complex_smiles(
    *,
    metal_metal_bond_dative: bool = False,
    add_atom_maps: bool = False,
) -> str:
    """Build a bimetal complex with a metal–metal bond and one donor to each metal.

    - Metals are inferred from end atoms of donor->metal dative bonds.
    - Metal–metal bond is allowed only if non-dative.

    Returns RDKit SMILES.
    """
    rw = Chem.RWMol()

    m1 = Chem.Atom(29)  # Cu
    m1.SetFormalCharge(2)
    m1_idx = int(rw.AddAtom(m1))

    m2 = Chem.Atom(29)  # Cu
    m2.SetFormalCharge(2)
    m2_idx = int(rw.AddAtom(m2))

    if metal_metal_bond_dative:
        rw.AddBond(m1_idx, m2_idx, rdchem.BondType.DATIVE)
    else:
        rw.AddBond(m1_idx, m2_idx, rdchem.BondType.SINGLE)

    # one donor to each metal
    d1 = int(rw.AddAtom(Chem.Atom(7)))
    d2 = int(rw.AddAtom(Chem.Atom(7)))

    rw.AddBond(d1, m1_idx, rdchem.BondType.DATIVE)
    rw.AddBond(d2, m2_idx, rdchem.BondType.DATIVE)

    mol = rw.GetMol()

    if add_atom_maps:
        mol.GetAtomWithIdx(d1).SetAtomMapNum(1)
        mol.GetAtomWithIdx(d2).SetAtomMapNum(2)

    Chem.SanitizeMol(mol)
    return Chem.MolToSmiles(mol)


#%% ligand_from_smiles

def test_ligand_from_smiles_basic_maps_to_donors_and_clears_maps() -> None:
    smiles = 'CC[O:1]CC[NH:2]C'

    mol = Chem.MolFromSmiles(smiles)
    expected_donors = {a.GetIdx() for a in mol.GetAtoms() if int(a.GetAtomMapNum()) != 0}

    lig = ligand_from_smiles(smiles)

    assert set(lig.donor_atoms) == expected_donors
    assert all(int(a.GetAtomMapNum()) == 0 for a in lig.mol.GetAtoms())

    for d in expected_donors:
        assert int(lig.G.nodes[int(d)]['atom_type']) == int(AtomType.DONOR)


def test_ligand_from_smiles_requires_mapped_donors() -> None:
    with pytest.raises(ValueError):
        ligand_from_smiles('CCOCCN')


def test_ligand_from_smiles_invalid_smiles_raises() -> None:
    with pytest.raises(ValueError):
        ligand_from_smiles('this_is_not_smiles')


#%% complex_from_smiles

def test_complex_from_smiles_valid_infers_metals_and_clears_maps() -> None:
    smiles = _make_cu_dative_complex_smiles(n_donors=2, add_atom_maps=True)
    expected_donors, expected_metals = _infer_expected_complex_sets(smiles)
    assert expected_donors and expected_metals

    comp = complex_from_smiles(smiles)

    assert set(comp.metal_atoms) == expected_metals
    assert set(comp.donor_atoms) == expected_donors

    # maps must be cleared in stored mol
    assert all(int(a.GetAtomMapNum()) == 0 for a in comp.mol.GetAtoms())

    for m in expected_metals:
        assert int(comp.G.nodes[int(m)]['atom_type']) == int(AtomType.CENTER)
    for d in expected_donors:
        assert int(comp.G.nodes[int(d)]['atom_type']) == int(AtomType.DONOR)


def test_complex_from_smiles_requires_at_least_one_dative_bond() -> None:
    with pytest.raises(ValueError):
        complex_from_smiles('CCO')  # no dative bonds


def test_complex_from_smiles_non_dative_metal_ligand_bond_raises() -> None:
    smiles = _make_cu_dative_complex_smiles(n_donors=1, use_non_dative_metal_ligand_bond=True)
    with pytest.raises(ValueError):
        complex_from_smiles(smiles)


def test_complex_from_smiles_allows_metal_metal_non_dative_bond() -> None:
    smiles = _make_bimetal_complex_smiles(metal_metal_bond_dative=False, add_atom_maps=True)
    expected_donors, expected_metals = _infer_expected_complex_sets(smiles)
    assert len(expected_metals) == 2
    assert len(expected_donors) == 2

    comp = complex_from_smiles(smiles)

    assert set(comp.metal_atoms) == expected_metals
    assert set(comp.donor_atoms) == expected_donors
    assert all(int(a.GetAtomMapNum()) == 0 for a in comp.mol.GetAtoms())


def test_complex_from_smiles_rejects_metal_metal_dative_bond() -> None:
    smiles = _make_bimetal_complex_smiles(metal_metal_bond_dative=True)
    with pytest.raises(ValueError):
        complex_from_smiles(smiles)


def test_complex_from_smiles_invalid_smiles_raises() -> None:
    with pytest.raises(ValueError):
        complex_from_smiles('not_a_smiles')


