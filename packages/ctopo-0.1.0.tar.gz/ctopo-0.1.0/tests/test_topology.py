from __future__ import annotations

from typing import Dict, List, Tuple

import networkx as nx
import pytest
from rdkit import Chem

from ctopo.core.ligand import Ligand, ligand_from_mol
from ctopo.topology import get_ligands_skeleton, get_ligands_topology


def ligand_from_smiles_with_donors(smiles: str) -> Tuple[Ligand, Dict[int, int]]:
    """Create a Ligand from a SMILES string with donor atoms marked by atom-map numbers.

    Algorithm:
      - parse SMILES
      - collect donor atom indices as those with atomMapNum != 0
      - record mapping donor_atom_idx -> donor_atom_mapnum
      - clear all atomMapNum values
      - construct Ligand via ``ligand_from_mol(mol, donor_atoms=...)``

    Returns:
      (ligand, idx_to_mapnum)
    """
    mol = Chem.MolFromSmiles(smiles)
    assert mol is not None, f'Failed to parse SMILES: {smiles}'

    idx_to_mapnum: Dict[int, int] = {}
    donor_idxs: List[int] = []

    for a in mol.GetAtoms():
        m = int(a.GetAtomMapNum())
        if m:
            donor_idxs.append(int(a.GetIdx()))
            idx_to_mapnum[int(a.GetIdx())] = m

    # clear atom map numbers everywhere
    for a in mol.GetAtoms():
        a.SetAtomMapNum(0)

    lig = ligand_from_mol(mol, donor_atoms=donor_idxs)
    return lig, idx_to_mapnum


def _topology_surrogate(G_topo: nx.Graph, idx_to_mapnum: Dict[int, int]) -> Tuple[List[str], List[Tuple[str, str]]]:
    """Convert topology graph to a compact, SMILES-map-number-based description.

    Donors are labeled as "DA<mapnum>", e.g. "DA1".
    Non-donors are labeled as "X0", "X1", ... in ascending node-id order.

    Returns:
      (donor_labels_sorted, edges_sorted)
    """
    donors = {n for n in G_topo.nodes() if int(n) in idx_to_mapnum}
    donor_labels = [f'DA{idx_to_mapnum[int(n)]}' for n in sorted(donors, key=lambda x: idx_to_mapnum[int(x)])]

    non_donors = [int(n) for n in G_topo.nodes() if int(n) not in donors]
    non_donors_sorted = sorted(non_donors)
    dummy_label = {n: f'X{i}' for i, n in enumerate(non_donors_sorted)}

    def lab(n: int) -> str:
        if int(n) in idx_to_mapnum:
            return f'DA{idx_to_mapnum[int(n)]}'
        return dummy_label[int(n)]

    edges: List[Tuple[str, str]] = []
    for u, v in G_topo.edges():
        a, b = lab(int(u)), lab(int(v))
        edges.append(tuple(sorted((a, b))))
    edges.sort()
    return donor_labels, edges


def _assert_edges_match(smiles: str, edges_expected: List[Tuple[str, str]]) -> None:
    lig, idx_to_map = ligand_from_smiles_with_donors(smiles)
    topo = get_ligands_topology(lig.G)

    donors, edges = _topology_surrogate(topo, idx_to_map)

    # normalize expected edges
    exp = [tuple(sorted(e)) for e in edges_expected]
    exp.sort()
    assert edges == exp

    # structural invariants: all edges single bond
    for _, _, d in topo.edges(data=True):
        assert d.get('bond_order') == 1.0
        assert d.get('bond_type') == 'SINGLE'

    # donor nodes keep attributes; non-donors are strict dummies with only Z=0
    donor_idxs = set(lig.donor_atoms)
    for n, data in topo.nodes(data=True):
        n = int(n)
        if n in donor_idxs:
            assert dict(data) == dict(lig.G.nodes[n])
        else:
            assert dict(data) == {'Z': 0}


def test_skeleton_is_induced_subgraph_of_ligand_partition() -> None:
    # diethylenetriamine (linear tridentate)
    smiles = '[NH2:1]CC[NH:2]CC[NH2:3]'
    lig, _ = ligand_from_smiles_with_donors(smiles)

    skel = get_ligands_skeleton(lig.G)
    expected_nodes = set(lig.donor_atoms) | set(lig.skeleton_atoms)

    assert set(skel.nodes()) == expected_nodes
    # induced subgraph check: edge set must match induced edges from original
    induced = lig.G.subgraph(sorted(expected_nodes))
    assert set(skel.edges()) == set(induced.edges())


def test_topology_bidentate_contracts_to_da_da() -> None:
    # ethylenediamine
    smiles = '[NH2:1]CC[NH2:2]'
    _assert_edges_match(smiles, [('DA1', 'DA2')])


def test_topology_tridentate_linear_to_chain() -> None:
    # diethylenetriamine
    smiles = '[NH2:1]CC[NH:2]CC[NH2:3]'
    _assert_edges_match(smiles, [('DA1', 'DA2'), ('DA2', 'DA3')])


def test_topology_tridentate_tripod_to_star_with_dummy_center() -> None:
    # tris(aminomethyl)methane-like tripod
    smiles = 'C(C[NH2:1])(C[NH2:2])C[NH2:3]'
    _assert_edges_match(smiles, [('DA1', 'X0'), ('DA2', 'X0'), ('DA3', 'X0')])


def test_topology_eliminates_aromatic_cycle_linker() -> None:
    # p-phenylenediamine: cycle with two branches should collapse away
    smiles = '[NH2:1]c1ccc(cc1)[NH2:2]'
    _assert_edges_match(smiles, [('DA1', 'DA2')])


def test_topology_edta() -> None:
    # edta-like
    smiles = '[O-:1]C(=O)CC[N:3](CCC(=O)[O-:2])CC[N:4](CCC(=O)[O-:5])CCC(=O)[O-:6]'
    _assert_edges_match(smiles, [('DA1', 'DA3'), ('DA2', 'DA3'), ('DA3', 'DA4'), ('DA4', 'DA5'), ('DA4', 'DA6')])


def test_topology_pentapod_small_cycle() -> None:
    # pentapod amine
    smiles = '[NH2:1]CCC1C(CC[NH2:2])C(CC[NH2:3])C(CC[NH2:4])C1CC[NH2:5]'
    _assert_edges_match(
        smiles,
        [
            ('DA1', 'X0'), ('DA2', 'X1'), ('DA3', 'X2'), ('DA4', 'X3'), ('DA5', 'X4'),
            ('X0', 'X1'), ('X1', 'X2'), ('X2', 'X3'), ('X3', 'X4'), ('X4', 'X0'),
        ]
    )


def test_topology_pentapod_big_cycle() -> None:
    # pentapod amine
    smiles = '[NH2:1]CCC1C(CC[NH2:2])C(CC[NH2:3])C(CC[NH2:4])C(CC[NH2:5])CCCCCC1'
    _assert_edges_match(
        smiles,
        [
            ('DA1', 'X0'), ('DA2', 'X0'), ('DA3', 'X1'), ('DA4', 'X2'), ('DA5', 'X2'),
            ('X0', 'X1'), ('X1', 'X2')
        ]
    )


