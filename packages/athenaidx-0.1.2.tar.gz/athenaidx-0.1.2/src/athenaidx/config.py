import logging
from selenium import webdriver
from dotenv import load_dotenv

class Config:
    def __init__(self, driver: webdriver.Chrome | None = None) -> None:
        load_dotenv()
        self.driver = driver if driver else self.create_driver()
        self.set_logging_level(logging.INFO)

    def create_driver(self) -> webdriver.Chrome:
        options = webdriver.ChromeOptions()
        driver = webdriver.Chrome(options=options)
        self.driver = driver
        return driver

    def get_driver(self) -> webdriver.Chrome:
        return self.driver
    
    def set_driver(self, driver: webdriver.Chrome) -> None:
        self.driver = driver
        
    def set_logging_level(self, level: int) -> None:
        import logging
        logging.basicConfig(level=level)