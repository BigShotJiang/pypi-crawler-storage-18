"""
PNEX Publisher - Python client for publishing sensor data to PNEX IoT platform.

This package provides an easy-to-use interface for publishing sensor data
to PNEX Server with ChaCha20 encryption and WebSocket communication.

Example:
    >>> from pnex_publisher import PNEXPublisher
    >>> publisher = PNEXPublisher(
    ...     device_token="your-token",
    ...     device_id="sensor-001",
    ...     encryption_key="base64-32-byte-key"
    ... )
    >>> await publisher.connect()
    >>> await publisher.publish("temperature", 23.5)
    >>> await publisher.disconnect()
"""

__version__ = "0.1.1"

from .publisher import PNEXPublisher
from .config import PNEXConfig
from .crypto import ChaChaEncryptor
from .exceptions import (
    PNEXError,
    ConfigurationError,
    EncryptionError,
    ConnectionError,
    PublishError,
)

__all__ = [
    "PNEXPublisher",
    "PNEXConfig",
    "ChaChaEncryptor",
    "PNEXError",
    "ConfigurationError",
    "EncryptionError",
    "ConnectionError",
    "PublishError",
]
