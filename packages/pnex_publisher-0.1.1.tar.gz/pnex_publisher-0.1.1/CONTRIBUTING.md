# Contributing to PNEX Publisher

Thank you for your interest in contributing to PNEX Publisher! This document provides guidelines and instructions for contributing to this project.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please be respectful and considerate of others.

## Getting Started

### Prerequisites

- Python 3.8 or higher
- [UV](https://github.com/astral-sh/uv) package manager (recommended)
- Git

### Development Setup

1. **Fork the repository** on GitHub
2. **Clone your fork** locally:
   ```bash
   git clone https://github.com/YOUR-USERNAME/py-publisher.git
   cd py-publisher
   ```
3. **Install development dependencies**:
   ```bash
   uv pip install -e ".[dev]"
   ```
4. **Create a branch** for your changes:
   ```bash
   git checkout -b feature/your-feature-name
   ```

## Development Workflow

### Code Style

We use several tools to maintain code quality:

- **Black** for code formatting
- **Ruff** for linting
- **Mypy** for type checking

Run these before committing:
```bash
black .
ruff check --fix
mypy src/
```

### Testing

- Write tests for new features
- Ensure existing tests pass
- Run tests with:
  ```bash
  pytest
  ```

### Documentation

- Update README.md for user-facing changes
- Add docstrings to new functions and classes
- Update examples if API changes

## Pull Request Process

1. **Ensure your code passes all checks**:
   - Formatting (Black)
   - Linting (Ruff)
   - Type checking (Mypy)
   - Tests (Pytest)

2. **Update documentation** if needed

3. **Create a pull request**:
   - Use a descriptive title
   - Reference any related issues
   - Provide a clear description of changes

4. **Respond to review feedback** promptly

## Issue Reporting

When reporting issues, please include:

- PNEX Publisher version
- Python version
- Steps to reproduce
- Expected vs actual behavior
- Error messages or logs

## Feature Requests

Feature requests are welcome! Please:

1. Check if the feature already exists
2. Explain the use case
3. Describe the expected behavior

## Release Process

Releases are managed by maintainers through GitHub releases. The workflow automatically publishes to PyPI when a release is created.

## Questions?

Feel free to open an issue for questions about contributing.

## License

By contributing, you agree that your contributions will be licensed under the project's MIT License.