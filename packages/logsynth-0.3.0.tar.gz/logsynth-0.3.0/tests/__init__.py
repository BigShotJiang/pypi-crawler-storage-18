"""LogSynth tests."""
