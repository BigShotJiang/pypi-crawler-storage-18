# psycopol-synth
[![PyPI version](https://badge.fury.io/py/psycopol-synth.svg)](https://badge.fury.io/py/psycopol-synth)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/psycopol-synth)](https://pepy.tech/project/psycopol-synth)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A lightweight Python package for automatically extracting and summarizing key concepts from complex psychological and political theories.  
Given a text excerpt or a summary of a theoretical work, `psycopol_synth` uses an LLM to identify post‑Freudian psychological ideas, their relationship to political dynamics, and the main arguments, critiques, and potential applications.

## Features

- Extracts **concepts**, **relationships**, and **implications** from dense theory texts.  
- Works with the free tier of LLM7 out of the box.  
- Accepts any LangChain chat model (OpenAI, Anthropic, Google Gemini …).  
- Returns a structured list of tokens that match a predefined regex pattern, guaranteeing consistent output for downstream processing.

## Installation

```bash
pip install psycopol_synth
```

## Quickstart

```python
from psycopol_synth import psycopol_synth

text = """
In his critique of classical political theory, Freud argues that the emotional underpinnings of state ideology are rooted in subconscious desires. Contemporary scholars extend this view by incorporating psychoanalytic frameworks into analyses of political mobilization.
"""

# Using the default LLM7 provider
results = psycopol_synth(user_input=text)

# results is a list of extracted strings following the regex pattern
print(results)
```

### Using a Custom LLM

`psycopol_synth` accepts any LangChain chat model.  
Below are examples for several popular providers.

#### OpenAI

```python
from langchain_openai import ChatOpenAI
from psycopol_synth import psycopol_synth

llm = ChatOpenAI()  # You can set `model_name`, `temperature`, etc.
response = psycopol_synth(user_input=text, llm=llm)
```

#### Anthropic

```python
from langchain_anthropic import ChatAnthropic
from psycopol_synth import psycopol_synth

llm = ChatAnthropic()
response = psycopol_synth(user_input=text, llm=llm)
```

#### Google Gemini

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from psycopol_synth import psycopol_synth

llm = ChatGoogleGenerativeAI()
response = psycopol_synth(user_input=text, llm=llm)
```

### Specifying an LLM7 API Key

The default `ChatLLM7` instance uses the `LLM7_API_KEY` environment variable.  
If you wish to supply the key directly:

```python
response = psycopol_synth(user_input=text, api_key="your_llm7_api_key")
```

A free key can be obtained by registering at <https://token.llm7.io/>.

## Function Signature

```python
def psycopol_synth(
    user_input: str,
    api_key: Optional[str] = None,
    llm: Optional[BaseChatModel] = None
) -> List[str]
```

| Parameter | Type                | Description |
|-----------|---------------------|-------------|
| `user_input` | `str` | The raw text or summary that you wish to analyze. |
| `llm` | `Optional[BaseChatModel]` | A LangChain chat model instance. If omitted, the function falls back to `ChatLLM7`. |
| `api_key` | `Optional[str]` | API key for the LLM7 provider. Ignored if a custom LLM is supplied. |

## Rate Limits & Performance

- The free tier of LLM7 comfortably handles the majority of use cases.  
- If you exceed the default limits, simply provide your own `api_key` to increase the quota.

## Issues & Support

Please report bugs or submit feature requests at  
<https://github.com/chigwell/psycopol-synth/issues>.

## Author

- **Eugene Evstafev**  
- Email: <hi@euegne.plus>  
- GitHub: <https://github.com/chigwell>