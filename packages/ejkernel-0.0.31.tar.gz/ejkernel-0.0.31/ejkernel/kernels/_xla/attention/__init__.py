# Copyright 2025 The EasyDeL/ejKernel Author @erfanzar (Erfan Zare Chavoshi).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""XLA backend for standard multi-head attention.

This submodule provides XLA-optimized implementation of standard
multi-head attention with support for various masking patterns
and attention biases.

Features:
    - Standard scaled dot-product attention
    - Support for attention masks and biases
    - Configurable softmax scaling
    - Multiple output formats (BSHD, BHSD)
"""

from ._interface import attention

__all__ = ("attention",)
