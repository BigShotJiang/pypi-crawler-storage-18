#!/bin/bash
if ! grep -q "skouzaPy" ~/.bashrc; then
  echo "" >> ~/.bashrc
  echo "# Skouza Language" >> ~/.bashrc
  echo 'export PATH=$PATH:/home/skouza/skouzaPy' >> ~/.bashrc
  echo "Added to PATH. Please restart your terminal or run 'source ~/.bashrc'"
else
  echo "Already in PATH."
fi
