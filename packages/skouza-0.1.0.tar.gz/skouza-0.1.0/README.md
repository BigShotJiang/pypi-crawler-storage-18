# 🌟 Skouza (Darija Language)

**Skouza** is an innovative programming language that brings Moroccan culture to the world of software development. It allows you to write code using **Darija (Moroccan Arabic)** syntax.

## 🚀 Installation

You can install Skouza directly from PyPI:

```bash
pip install skouza
```

## 🛠️ Usage

Create a file with the `.drj` extension (e.g., `salam.drj`):

```darija
x = 100
kteb("Mar7ba bi jame3")

ila x > 10:
    kteb("x kbar mn 10")
wla:
    kteb("x sgher mn 10")
```

Then run it using the `skouza` command:

```bash
skouza salam.drj
```

## 📖 Syntax Reference

| Darija    | Python Equivalent |
| --------- | ----------------- |
| `kteb`    | `print`           |
| `dakhel`  | `input`           |
| `ila`     | `if`              |
| `wla`     | `else`            |
| `wla_ila` | `elif`            |
| `ma_hadd` | `while`           |
| `li_kull` | `for`             |
| `fi`      | `in`              |
| `dalla`   | `def`             |
| `rje3`    | `return`          |
| `jib`     | `import`          |
| `sah`     | `True`            |
| `ghalet`  | `False`           |
| `walo`    | `None`            |

## 🤝 Contribution

Contributions are welcome! Feel free to open issues or submit pull requests on [GitHub](https://github.com/skouza/skouzaPy).

## 📄 License

This project is licensed under the MIT License.
