import sys
import re

DARIJA_TO_PYTHON = {
    r'\bkteb\b': 'print',
    r'\bdakhel\b': 'input',
    r'\bila\b': 'if',
    r'\bwla\b': 'else',
    r'\bwla_ila\b': 'elif', 
    r'\bma_hadd\b': 'while',
    r'\bli_kull\b': 'for',
    r'\bfi\b': 'in',
    r'\bdalla\b': 'def',
    r'\brje3\b': 'return',
    r'\bjib\b': 'import',
    r'\bsah\b': 'True',
    r'\bghalet\b': 'False',
    r'\bwalo\b': 'None',
    r'\bjarreb\b': 'try',
    r'\bkhta\b': 'except',
    r'\bmen\b': 'from',
    r'\bwa\b': 'and',
    r'\baw\b': 'or',
    r'\blayssa\b': 'not', 
    r'\bmachi\b': 'not',
    r'\bclass\b': 'nou3', 
    r'\bnhi\b': 'break',
    r'\bkemmel\b': 'continue',
    r'\bpass\b': 'douz', 
}

def transpile(source_code):
    transpiled_code = source_code
    for darija_pattern, python_word in DARIJA_TO_PYTHON.items():
        transpiled_code = re.sub(darija_pattern, python_word, transpiled_code)
    return transpiled_code

def run_darija_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            source_code = f.read()
        python_code = transpile(source_code)
        exec(python_code, globals())
    except FileNotFoundError:
        print(f"Error: File '{file_path}' lqa walou.")
    except Exception as e:
        print(f"Error f l'code dyalk: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Kteb smit l'fichier: python interpreter.py <fichier.drj>")
    else:
        run_darija_file(sys.argv[1])
