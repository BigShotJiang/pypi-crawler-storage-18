import sys
from skouza.interpreter import run_darija_file

def main():
    if len(sys.argv) < 2:
        print("Kteb smit l'fichier: skouza <fichier.drj>")
    else:
        run_darija_file(sys.argv[1])

if __name__ == "__main__":
    main()
