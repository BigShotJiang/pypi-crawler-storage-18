@echo off
pushd "%~dp0"
python3 interpreter.py %*
popd
