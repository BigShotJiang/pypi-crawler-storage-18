import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging

from config import get_settings, get_config
from models import Base, engine
from api.routes import health, accounts, deployments, kyma, maintenance
from tasks.scheduled import start_scheduler, stop_scheduler
from instance_lock import acquire_lock, check_lock

# Setup logging
settings = get_settings()
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# 单实例检查
if check_lock():
    logger.error("❌ Another scheduler instance is already running!")
    logger.error("   If you're sure no other instance is running, delete /tmp/btp-scheduler.lock")
    sys.exit(1)

if not acquire_lock():
    sys.exit(1)

logger.info("✓ Single instance lock acquired")
logger = logging.getLogger(__name__)

# Create tables
Base.metadata.create_all(bind=engine)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    start_scheduler()
    yield
    # Shutdown
    stop_scheduler()

# Create app
app = FastAPI(title="BTP Scheduler", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routes
app.include_router(health.router, prefix="/api/v1")
app.include_router(accounts.router, prefix="/api/v1")
app.include_router(deployments.router, prefix="/api/v1")
app.include_router(kyma.router, prefix="/api/v1")
app.include_router(maintenance.router, prefix="/api/v1")

@app.get("/")
def root():
    return {"message": "BTP Scheduler API", "version": "1.0.0"}

if __name__ == "__main__":
    import uvicorn
    config = get_config()
    uvicorn.run(
        "server:app",
        host=config["api"]["host"],
        port=config["api"]["port"],
        reload=True
    )
