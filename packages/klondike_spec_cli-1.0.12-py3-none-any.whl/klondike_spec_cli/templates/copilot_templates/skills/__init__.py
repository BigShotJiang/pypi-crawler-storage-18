"""Skills for GitHub Copilot."""
