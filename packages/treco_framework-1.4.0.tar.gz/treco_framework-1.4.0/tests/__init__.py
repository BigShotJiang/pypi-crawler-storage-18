"""Tests for TRECO framework."""
