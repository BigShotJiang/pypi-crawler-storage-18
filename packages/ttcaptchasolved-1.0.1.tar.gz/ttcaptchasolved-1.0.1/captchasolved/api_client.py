"""
CaptchaSolved - TikTok Captcha Solver API Client

This module handles API communication with captchasolved.com
All solving happens server-side - this client just sends images and receives results.

Get your API key at: https://captchasolved.com
"""

import base64
import json
import urllib.request
import urllib.error
from typing import Union, Optional
from dataclasses import dataclass
from pathlib import Path


# API Configuration
API_BASE_URL = "https://api.captchasolved.com/api/v1"


class CaptchaSolvedError(Exception):
    """Base exception for CaptchaSolved errors"""
    pass


class InvalidApiKeyError(CaptchaSolvedError):
    """Raised when API key is invalid"""
    pass


class NoCreditsError(CaptchaSolvedError):
    """Raised when account has no credits remaining"""
    pass


class ImageProcessingError(CaptchaSolvedError):
    """Raised when server cannot process the image"""
    pass


@dataclass
class PuzzleResult:
    """Result from puzzle/slide captcha solving"""
    slide_x_proportion: float  # 0.0 to 1.0 - multiply by puzzle width to get pixels
    
    def get_slide_pixels(self, puzzle_width: int) -> int:
        """Get slide distance in pixels for given puzzle width"""
        return int(self.slide_x_proportion * puzzle_width)


@dataclass
class RotateResult:
    """Result from rotate captcha solving"""
    angle: float  # Degrees to rotate (0-360)
    
    def get_slider_position(self, slider_width: int) -> int:
        """Get slider position for given slider width"""
        return int((self.angle / 360) * slider_width)


@dataclass
class ShapesResult:
    """Result from 3D shapes captcha - two points to click"""
    point_one_proportion_x: float  # 0.0 to 1.0
    point_one_proportion_y: float
    point_two_proportion_x: float
    point_two_proportion_y: float
    
    def get_click_points(self, width: int, height: int) -> tuple:
        """Get click coordinates in pixels"""
        return (
            (int(self.point_one_proportion_x * width), int(self.point_one_proportion_y * height)),
            (int(self.point_two_proportion_x * width), int(self.point_two_proportion_y * height))
        )


@dataclass
class IconResult:
    """Result from icon/object selection captcha"""
    point_one_proportion_x: float
    point_one_proportion_y: float
    point_two_proportion_x: float
    point_two_proportion_y: float
    
    def get_click_points(self, width: int, height: int) -> tuple:
        """Get click coordinates in pixels"""
        return (
            (int(self.point_one_proportion_x * width), int(self.point_one_proportion_y * height)),
            (int(self.point_two_proportion_x * width), int(self.point_two_proportion_y * height))
        )


def _to_base64(image: Union[str, bytes, 'np.ndarray', 'Image.Image']) -> str:
    """
    Convert image to base64 string.
    
    Accepts:
        - str: file path or already base64 encoded string
        - bytes: raw image bytes
        - np.ndarray: OpenCV/numpy image array
        - PIL.Image: PIL Image object
    
    Returns:
        Base64 encoded string
    """
    # Already base64
    if isinstance(image, str):
        if image.startswith('data:'):
            return image.split(',')[1]
        # Check if it's a file path
        if len(image) < 500 and (Path(image).exists() or '/' in image or '\\' in image):
            with open(image, 'rb') as f:
                return base64.b64encode(f.read()).decode('utf-8')
        # Assume it's already base64
        return image
    
    # Raw bytes
    if isinstance(image, bytes):
        return base64.b64encode(image).decode('utf-8')
    
    # NumPy array (OpenCV)
    try:
        import numpy as np
        if isinstance(image, np.ndarray):
            import cv2
            _, buffer = cv2.imencode('.png', image)
            return base64.b64encode(buffer).decode('utf-8')
    except ImportError:
        pass
    
    # PIL Image
    try:
        from PIL import Image
        if isinstance(image, Image.Image):
            from io import BytesIO
            buffer = BytesIO()
            image.save(buffer, format='PNG')
            return base64.b64encode(buffer.getvalue()).decode('utf-8')
    except ImportError:
        pass
    
    raise TypeError(f"Cannot convert {type(image)} to base64. Supported: str (path/base64), bytes, numpy array, PIL Image")


class ApiClient:
    """
    API client for CaptchaSolved.com
    
    Usage:
        client = ApiClient("your-api-key")
        
        # Solve puzzle captcha
        result = client.puzzle(puzzle_image, piece_image)
        slide_distance = result.get_slide_pixels(puzzle_width)
        
        # Solve rotate captcha  
        result = client.rotate(outer_image, inner_image)
        angle = result.angle
        
        # Solve shapes captcha
        result = client.shapes(captcha_image)
        points = result.get_click_points(img_width, img_height)
    """
    
    def __init__(self, api_key: str, timeout: int = 30):
        """
        Initialize the API client.
        
        Args:
            api_key: Your API key from captchasolved.com
            timeout: Request timeout in seconds
        """
        if not api_key:
            raise InvalidApiKeyError("API key is required. Get one at https://captchasolved.com")
        
        self.api_key = api_key
        self.timeout = timeout
        self.base_url = API_BASE_URL
    
    def _make_request(self, endpoint: str, data: dict) -> dict:
        """Make a POST request to the API"""
        url = f"{self.base_url}/{endpoint}?licenseKey={self.api_key}"
        
        json_data = json.dumps(data).encode('utf-8')
        
        req = urllib.request.Request(
            url,
            data=json_data,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "CaptchaSolved-Python/1.0.0"
            },
            method="POST"
        )
        
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                return json.loads(response.read().decode('utf-8'))
                
        except urllib.error.HTTPError as e:
            body = e.read().decode('utf-8')
            try:
                error_data = json.loads(body)
                message = error_data.get("error", str(e))
            except:
                message = body or str(e)
            
            if e.code == 401:
                raise InvalidApiKeyError(f"Invalid API key. Get one at https://captchasolved.com")
            elif e.code == 402:
                raise NoCreditsError(f"No credits remaining. Buy more at https://captchasolved.com")
            elif e.code == 400:
                raise ImageProcessingError(f"Bad request: {message}")
            elif e.code == 500:
                raise CaptchaSolvedError(f"Server error: {message}")
            else:
                raise CaptchaSolvedError(f"API error ({e.code}): {message}")
                
        except urllib.error.URLError as e:
            raise CaptchaSolvedError(f"Connection error: {e}. Check your internet connection.")
        except Exception as e:
            raise CaptchaSolvedError(f"Unexpected error: {e}")
    
    def puzzle(
        self, 
        puzzle_image: Union[str, bytes], 
        piece_image: Union[str, bytes]
    ) -> PuzzleResult:
        """
        Solve a puzzle/slide captcha.
        
        Args:
            puzzle_image: The background puzzle image (file path, bytes, base64, numpy array, or PIL Image)
            piece_image: The puzzle piece image
        
        Returns:
            PuzzleResult with slide_x_proportion (0.0-1.0)
            
        Example:
            result = client.puzzle("background.png", "piece.png")
            pixels = result.get_slide_pixels(puzzle_width=300)
            # slide the piece 'pixels' pixels to the right
        """
        data = {
            "puzzleImageB64": _to_base64(puzzle_image),
            "pieceImageB64": _to_base64(piece_image)
        }
        
        response = self._make_request("puzzle", data)
        
        return PuzzleResult(
            slide_x_proportion=float(response.get("slideXProportion", 0))
        )
    
    def rotate(
        self, 
        outer_image: Union[str, bytes], 
        inner_image: Union[str, bytes]
    ) -> RotateResult:
        """
        Solve a rotate captcha.
        
        Args:
            outer_image: The outer/background image
            inner_image: The inner image to rotate
        
        Returns:
            RotateResult with angle in degrees (0-360)
            
        Example:
            result = client.rotate("outer.png", "inner.png")
            angle = result.angle  # degrees to rotate
            slider_pos = result.get_slider_position(slider_width=280)
        """
        data = {
            "outerImageB64": _to_base64(outer_image),
            "innerImageB64": _to_base64(inner_image)
        }
        
        response = self._make_request("rotate", data)
        
        return RotateResult(
            angle=float(response.get("angle", 0))
        )
    
    def shapes(self, image: Union[str, bytes]) -> ShapesResult:
        """
        Solve a 3D shapes captcha.
        
        Args:
            image: The shapes captcha image
        
        Returns:
            ShapesResult with coordinates of the two matching shapes (as proportions 0.0-1.0)
            
        Example:
            result = client.shapes("captcha.png")
            (x1, y1), (x2, y2) = result.get_click_points(width=300, height=200)
            # click at (x1, y1) then (x2, y2)
        """
        data = {
            "imageB64": _to_base64(image)
        }
        
        response = self._make_request("shapes", data)
        
        return ShapesResult(
            point_one_proportion_x=float(response.get("pointOneProportionX", 0)),
            point_one_proportion_y=float(response.get("pointOneProportionY", 0)),
            point_two_proportion_x=float(response.get("pointTwoProportionX", 0)),
            point_two_proportion_y=float(response.get("pointTwoProportionY", 0))
        )
    
    def icon(self, challenge: str, image: Union[str, bytes]) -> IconResult:
        """
        Solve an icon/object selection captcha (e.g., "Which of these objects...").
        
        Args:
            challenge: The challenge text
            image: The captcha image
        
        Returns:
            IconResult with coordinates to click
        """
        data = {
            "challenge": challenge,
            "imageB64": _to_base64(image)
        }
        
        response = self._make_request("icon", data)
        
        return IconResult(
            point_one_proportion_x=float(response.get("pointOneProportionX", 0)),
            point_one_proportion_y=float(response.get("pointOneProportionY", 0)),
            point_two_proportion_x=float(response.get("pointTwoProportionX", 0)),
            point_two_proportion_y=float(response.get("pointTwoProportionY", 0))
        )


# Convenience function
def create_client(api_key: str) -> ApiClient:
    """Create an API client instance"""
    return ApiClient(api_key)
