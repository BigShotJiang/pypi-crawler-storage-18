"""
Playwright integration for CaptchaSolved

Automatically detects and solves TikTok captchas in Playwright.

Usage (sync):
    from playwright.sync_api import sync_playwright
    from captchasolved.playwright import PlaywrightSolver
    
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        
        solver = PlaywrightSolver(page, "your-api-key")
        page.goto("https://tiktok.com/login")
        solver.solve_captcha_if_present()

Usage (async):
    from playwright.async_api import async_playwright
    from captchasolved.playwright import AsyncPlaywrightSolver
    
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        
        solver = AsyncPlaywrightSolver(page, "your-api-key")
        await page.goto("https://tiktok.com/login")
        await solver.solve_captcha_if_present()
"""

import time
import random
import base64
import asyncio
from typing import Optional, Any

from .api_client import ApiClient, CaptchaSolvedError


# Shared selectors
CAPTCHA_SELECTORS = {
    'wrapper': 'div[class*="captcha"], div[class*="Captcha"], #captcha-verify-container',
    'puzzle_bg': 'img[class*="captcha"][class*="bg"], img[src*="puzzle"]',
    'puzzle_piece': 'img[class*="captcha"][class*="piece"], img[class*="puzzle-piece"]',
    'rotate_outer': 'img[class*="outer"], img[class*="whirl-outer"]',
    'rotate_inner': 'img[class*="inner"], img[class*="whirl-inner"]',
    'slider': 'div[class*="slider"], div[class*="secsdk-captcha-drag"]',
    'slider_button': 'div[class*="slider-button"], div[class*="secsdk-captcha-drag-icon"]',
    'shapes_image': 'img[class*="shapes"], img[class*="3d"]',
}


class PlaywrightSolver:
    """
    Synchronous Playwright captcha solver.
    """
    
    def __init__(self, page, api_key: str, debug: bool = False):
        """
        Initialize the solver.
        
        Args:
            page: Playwright Page instance
            api_key: Your CaptchaSolved API key
            debug: Enable debug logging
        """
        self.page = page
        self.client = ApiClient(api_key)
        self.debug = debug
    
    def _log(self, message: str):
        if self.debug:
            print(f"[CaptchaSolved] {message}")
    
    def _random_delay(self, min_ms: int = 100, max_ms: int = 300):
        time.sleep(random.uniform(min_ms / 1000, max_ms / 1000))
    
    def _find_element(self, selector: str):
        """Find element using selector"""
        try:
            element = self.page.query_selector(selector)
            return element
        except:
            return None
    
    def _get_image_base64(self, element) -> Optional[str]:
        """Get base64 of image from element"""
        try:
            src = element.get_attribute("src")
            if src:
                if src.startswith("data:"):
                    return src.split(",")[1]
                else:
                    # Use page to fetch
                    response = self.page.request.get(src)
                    return base64.b64encode(response.body()).decode('utf-8')
            return base64.b64encode(element.screenshot()).decode('utf-8')
        except Exception as e:
            self._log(f"Error getting image: {e}")
            return None
    
    def _human_slide(self, element, distance: int):
        """Perform human-like sliding"""
        box = element.bounding_box()
        if not box:
            return
        
        start_x = box['x'] + box['width'] / 2
        start_y = box['y'] + box['height'] / 2
        
        self.page.mouse.move(start_x, start_y)
        self.page.mouse.down()
        
        steps = max(15, min(30, distance // 10))
        for i in range(steps):
            progress = (i + 1) / steps
            ease = 1 - (1 - progress) ** 3
            x = start_x + distance * ease + random.randint(-2, 2)
            y = start_y + random.randint(-2, 2)
            self.page.mouse.move(x, y)
            time.sleep(random.uniform(0.01, 0.03))
        
        self.page.mouse.move(start_x + distance, start_y)
        time.sleep(random.uniform(0.05, 0.15))
        self.page.mouse.up()
    
    def _detect_captcha_type(self) -> Optional[str]:
        """Detect captcha type"""
        wrapper = self._find_element(CAPTCHA_SELECTORS['wrapper'])
        if not wrapper:
            return None
        
        if self._find_element(CAPTCHA_SELECTORS['puzzle_bg']):
            return "puzzle"
        if self._find_element(CAPTCHA_SELECTORS['rotate_outer']):
            return "rotate"
        if self._find_element(CAPTCHA_SELECTORS['shapes_image']):
            return "shapes"
        if self._find_element(CAPTCHA_SELECTORS['slider']):
            return "puzzle"
        
        return None
    
    def solve_puzzle(self) -> bool:
        """Solve puzzle captcha"""
        self._log("Solving puzzle...")
        try:
            bg = self._find_element(CAPTCHA_SELECTORS['puzzle_bg'])
            piece = self._find_element(CAPTCHA_SELECTORS['puzzle_piece'])
            
            if not bg or not piece:
                return False
            
            bg_b64 = self._get_image_base64(bg)
            piece_b64 = self._get_image_base64(piece)
            
            if not bg_b64 or not piece_b64:
                return False
            
            result = self.client.puzzle(bg_b64, piece_b64)
            
            box = bg.bounding_box()
            distance = result.get_slide_pixels(int(box['width']))
            
            slider = self._find_element(CAPTCHA_SELECTORS['slider_button'])
            if not slider:
                return False
            
            self._random_delay(200, 400)
            self._human_slide(slider, distance)
            self._random_delay(500, 1000)
            
            return True
        except Exception as e:
            self._log(f"Error: {e}")
            return False
    
    def solve_rotate(self) -> bool:
        """Solve rotate captcha"""
        self._log("Solving rotate...")
        try:
            outer = self._find_element(CAPTCHA_SELECTORS['rotate_outer'])
            inner = self._find_element(CAPTCHA_SELECTORS['rotate_inner'])
            
            if not outer or not inner:
                return False
            
            outer_b64 = self._get_image_base64(outer)
            inner_b64 = self._get_image_base64(inner)
            
            if not outer_b64 or not inner_b64:
                return False
            
            result = self.client.rotate(outer_b64, inner_b64)
            
            slider = self._find_element(CAPTCHA_SELECTORS['slider'])
            slider_button = self._find_element(CAPTCHA_SELECTORS['slider_button'])
            
            if not slider or not slider_button:
                return False
            
            slider_box = slider.bounding_box()
            button_box = slider_button.bounding_box()
            distance = result.get_slider_position(int(slider_box['width'] - button_box['width']))
            
            self._random_delay(200, 400)
            self._human_slide(slider_button, distance)
            self._random_delay(500, 1000)
            
            return True
        except Exception as e:
            self._log(f"Error: {e}")
            return False
    
    def solve_shapes(self) -> bool:
        """Solve shapes captcha"""
        self._log("Solving shapes...")
        try:
            img = self._find_element(CAPTCHA_SELECTORS['shapes_image'])
            if not img:
                return False
            
            img_b64 = self._get_image_base64(img)
            if not img_b64:
                return False
            
            result = self.client.shapes(img_b64)
            
            box = img.bounding_box()
            (x1, y1), (x2, y2) = result.get_click_points(int(box['width']), int(box['height']))
            
            # Click first point
            self._random_delay(200, 400)
            self.page.mouse.click(box['x'] + x1, box['y'] + y1)
            
            # Click second point
            self._random_delay(300, 600)
            self.page.mouse.click(box['x'] + x2, box['y'] + y2)
            
            self._random_delay(500, 1000)
            return True
        except Exception as e:
            self._log(f"Error: {e}")
            return False
    
    def solve_captcha_if_present(self, max_retries: int = 3) -> bool:
        """Detect and solve any captcha"""
        self._log("Checking for captcha...")
        time.sleep(1)
        
        for attempt in range(max_retries):
            captcha_type = self._detect_captcha_type()
            
            if not captcha_type:
                self._log("No captcha detected")
                return True
            
            self._log(f"Detected: {captcha_type} (attempt {attempt + 1})")
            
            if captcha_type == "puzzle":
                success = self.solve_puzzle()
            elif captcha_type == "rotate":
                success = self.solve_rotate()
            elif captcha_type == "shapes":
                success = self.solve_shapes()
            else:
                success = False
            
            if success:
                time.sleep(2)
                if not self._detect_captcha_type():
                    self._log("Solved!")
                    return True
            
            self._random_delay(1000, 2000)
        
        return False


class AsyncPlaywrightSolver:
    """
    Asynchronous Playwright captcha solver.
    """
    
    def __init__(self, page, api_key: str, debug: bool = False):
        self.page = page
        self.client = ApiClient(api_key)
        self.debug = debug
    
    def _log(self, message: str):
        if self.debug:
            print(f"[CaptchaSolved] {message}")
    
    async def _random_delay(self, min_ms: int = 100, max_ms: int = 300):
        await asyncio.sleep(random.uniform(min_ms / 1000, max_ms / 1000))
    
    async def _find_element(self, selector: str):
        try:
            return await self.page.query_selector(selector)
        except:
            return None
    
    async def _get_image_base64(self, element) -> Optional[str]:
        try:
            src = await element.get_attribute("src")
            if src:
                if src.startswith("data:"):
                    return src.split(",")[1]
                else:
                    response = await self.page.request.get(src)
                    body = await response.body()
                    return base64.b64encode(body).decode('utf-8')
            screenshot = await element.screenshot()
            return base64.b64encode(screenshot).decode('utf-8')
        except Exception as e:
            self._log(f"Error: {e}")
            return None
    
    async def _human_slide(self, element, distance: int):
        box = await element.bounding_box()
        if not box:
            return
        
        start_x = box['x'] + box['width'] / 2
        start_y = box['y'] + box['height'] / 2
        
        await self.page.mouse.move(start_x, start_y)
        await self.page.mouse.down()
        
        steps = max(15, min(30, distance // 10))
        for i in range(steps):
            progress = (i + 1) / steps
            ease = 1 - (1 - progress) ** 3
            x = start_x + distance * ease + random.randint(-2, 2)
            y = start_y + random.randint(-2, 2)
            await self.page.mouse.move(x, y)
            await asyncio.sleep(random.uniform(0.01, 0.03))
        
        await self.page.mouse.move(start_x + distance, start_y)
        await asyncio.sleep(random.uniform(0.05, 0.15))
        await self.page.mouse.up()
    
    async def _detect_captcha_type(self) -> Optional[str]:
        wrapper = await self._find_element(CAPTCHA_SELECTORS['wrapper'])
        if not wrapper:
            return None
        
        if await self._find_element(CAPTCHA_SELECTORS['puzzle_bg']):
            return "puzzle"
        if await self._find_element(CAPTCHA_SELECTORS['rotate_outer']):
            return "rotate"
        if await self._find_element(CAPTCHA_SELECTORS['shapes_image']):
            return "shapes"
        if await self._find_element(CAPTCHA_SELECTORS['slider']):
            return "puzzle"
        
        return None
    
    async def solve_puzzle(self) -> bool:
        self._log("Solving puzzle...")
        try:
            bg = await self._find_element(CAPTCHA_SELECTORS['puzzle_bg'])
            piece = await self._find_element(CAPTCHA_SELECTORS['puzzle_piece'])
            
            if not bg or not piece:
                return False
            
            bg_b64 = await self._get_image_base64(bg)
            piece_b64 = await self._get_image_base64(piece)
            
            if not bg_b64 or not piece_b64:
                return False
            
            result = self.client.puzzle(bg_b64, piece_b64)
            
            box = await bg.bounding_box()
            distance = result.get_slide_pixels(int(box['width']))
            
            slider = await self._find_element(CAPTCHA_SELECTORS['slider_button'])
            if not slider:
                return False
            
            await self._random_delay(200, 400)
            await self._human_slide(slider, distance)
            await self._random_delay(500, 1000)
            
            return True
        except Exception as e:
            self._log(f"Error: {e}")
            return False
    
    async def solve_rotate(self) -> bool:
        self._log("Solving rotate...")
        try:
            outer = await self._find_element(CAPTCHA_SELECTORS['rotate_outer'])
            inner = await self._find_element(CAPTCHA_SELECTORS['rotate_inner'])
            
            if not outer or not inner:
                return False
            
            outer_b64 = await self._get_image_base64(outer)
            inner_b64 = await self._get_image_base64(inner)
            
            if not outer_b64 or not inner_b64:
                return False
            
            result = self.client.rotate(outer_b64, inner_b64)
            
            slider = await self._find_element(CAPTCHA_SELECTORS['slider'])
            slider_button = await self._find_element(CAPTCHA_SELECTORS['slider_button'])
            
            if not slider or not slider_button:
                return False
            
            slider_box = await slider.bounding_box()
            button_box = await slider_button.bounding_box()
            distance = result.get_slider_position(int(slider_box['width'] - button_box['width']))
            
            await self._random_delay(200, 400)
            await self._human_slide(slider_button, distance)
            await self._random_delay(500, 1000)
            
            return True
        except Exception as e:
            self._log(f"Error: {e}")
            return False
    
    async def solve_shapes(self) -> bool:
        self._log("Solving shapes...")
        try:
            img = await self._find_element(CAPTCHA_SELECTORS['shapes_image'])
            if not img:
                return False
            
            img_b64 = await self._get_image_base64(img)
            if not img_b64:
                return False
            
            result = self.client.shapes(img_b64)
            
            box = await img.bounding_box()
            (x1, y1), (x2, y2) = result.get_click_points(int(box['width']), int(box['height']))
            
            await self._random_delay(200, 400)
            await self.page.mouse.click(box['x'] + x1, box['y'] + y1)
            
            await self._random_delay(300, 600)
            await self.page.mouse.click(box['x'] + x2, box['y'] + y2)
            
            await self._random_delay(500, 1000)
            return True
        except Exception as e:
            self._log(f"Error: {e}")
            return False
    
    async def solve_captcha_if_present(self, max_retries: int = 3) -> bool:
        self._log("Checking for captcha...")
        await asyncio.sleep(1)
        
        for attempt in range(max_retries):
            captcha_type = await self._detect_captcha_type()
            
            if not captcha_type:
                self._log("No captcha detected")
                return True
            
            self._log(f"Detected: {captcha_type} (attempt {attempt + 1})")
            
            if captcha_type == "puzzle":
                success = await self.solve_puzzle()
            elif captcha_type == "rotate":
                success = await self.solve_rotate()
            elif captcha_type == "shapes":
                success = await self.solve_shapes()
            else:
                success = False
            
            if success:
                await asyncio.sleep(2)
                if not await self._detect_captcha_type():
                    self._log("Solved!")
                    return True
            
            await self._random_delay(1000, 2000)
        
        return False
