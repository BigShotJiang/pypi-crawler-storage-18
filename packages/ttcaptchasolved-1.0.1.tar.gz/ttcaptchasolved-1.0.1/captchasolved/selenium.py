"""
Selenium integration for CaptchaSolved

Automatically detects and solves TikTok captchas in Selenium WebDriver.

Usage:
    from selenium import webdriver
    from captchasolved.selenium import SeleniumSolver
    
    driver = webdriver.Chrome()
    solver = SeleniumSolver(driver, "your-api-key")
    
    driver.get("https://tiktok.com/login")
    # ... fill form ...
    
    solver.solve_captcha_if_present()
"""

import time
import random
import base64
import re
from typing import Optional, Tuple, Any
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

from .api_client import ApiClient, CaptchaSolvedError


class SeleniumSolver:
    """
    Automatic TikTok captcha solver for Selenium.
    
    Detects captcha type (puzzle, rotate, shapes) and solves automatically.
    """
    
    # TikTok captcha selectors
    CAPTCHA_SELECTORS = {
        'wrapper': [
            'div[class*="captcha"]',
            'div[class*="Captcha"]',
            '#captcha-verify-container',
            'div[data-testid="captcha"]',
        ],
        'puzzle_bg': [
            'img[class*="captcha"][class*="bg"]',
            'img[src*="puzzle"]',
            'div[class*="captcha"] img:first-child',
        ],
        'puzzle_piece': [
            'img[class*="captcha"][class*="piece"]',
            'img[class*="puzzle-piece"]',
            'div[class*="captcha"] img:last-child',
        ],
        'rotate_outer': [
            'img[class*="outer"]',
            'img[class*="whirl-outer"]',
        ],
        'rotate_inner': [
            'img[class*="inner"]',
            'img[class*="whirl-inner"]',
        ],
        'slider': [
            'div[class*="slider"]',
            'div[class*="secsdk-captcha-drag"]',
            'div[class*="captcha_verify_slide"]',
        ],
        'slider_button': [
            'div[class*="slider-button"]',
            'div[class*="secsdk-captcha-drag-icon"]',
            'div[class*="captcha_verify_slide--button"]',
            'span[class*="slider"]',
        ],
        'shapes_image': [
            'img[class*="shapes"]',
            'img[class*="3d"]',
        ],
    }
    
    def __init__(self, driver: WebDriver, api_key: str, debug: bool = False):
        """
        Initialize the solver.
        
        Args:
            driver: Selenium WebDriver instance
            api_key: Your CaptchaSolved API key
            debug: Enable debug logging
        """
        self.driver = driver
        self.client = ApiClient(api_key)
        self.debug = debug
    
    def _log(self, message: str):
        """Debug logging"""
        if self.debug:
            print(f"[CaptchaSolved] {message}")
    
    def _random_delay(self, min_ms: int = 100, max_ms: int = 300):
        """Add human-like random delay"""
        time.sleep(random.uniform(min_ms / 1000, max_ms / 1000))
    
    def _find_element(self, selectors: list) -> Optional[Any]:
        """Find element using multiple selectors"""
        for selector in selectors:
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    return elements[0]
            except:
                continue
        return None
    
    def _get_image_base64(self, element) -> Optional[str]:
        """Get base64 of image from element"""
        try:
            # Try getting from src
            src = element.get_attribute("src")
            if src:
                if src.startswith("data:"):
                    return src.split(",")[1]
                else:
                    # Fetch image from URL
                    import urllib.request
                    with urllib.request.urlopen(src, timeout=10) as response:
                        return base64.b64encode(response.read()).decode('utf-8')
            
            # Try screenshot
            return element.screenshot_as_base64
        except Exception as e:
            self._log(f"Error getting image: {e}")
            return None
    
    def _human_slide(self, element, distance: int, duration: float = 0.5):
        """Perform human-like sliding motion"""
        action = ActionChains(self.driver)
        action.click_and_hold(element)
        
        # Calculate steps based on distance
        steps = max(15, min(30, distance // 10))
        
        current_x = 0
        for i in range(steps):
            # Ease-out curve for natural movement
            progress = (i + 1) / steps
            ease = 1 - (1 - progress) ** 3  # Cubic ease-out
            
            target_x = int(distance * ease)
            step_x = target_x - current_x
            
            # Add slight randomness
            step_x += random.randint(-2, 2)
            step_y = random.randint(-1, 1)
            
            action.move_by_offset(step_x, step_y)
            action.pause(duration / steps + random.uniform(0, 0.02))
            
            current_x += step_x
        
        # Final adjustment
        remaining = distance - current_x
        if remaining != 0:
            action.move_by_offset(remaining, 0)
        
        action.pause(random.uniform(0.05, 0.15))
        action.release()
        action.perform()
    
    def _human_click(self, element, offset_x: int = 0, offset_y: int = 0):
        """Perform human-like click"""
        action = ActionChains(self.driver)
        
        # Move with slight overshoot and correction
        action.move_to_element_with_offset(element, offset_x + random.randint(-5, 5), offset_y + random.randint(-5, 5))
        action.pause(random.uniform(0.05, 0.1))
        action.move_by_offset(random.randint(-3, 3), random.randint(-3, 3))
        action.pause(random.uniform(0.05, 0.1))
        action.click()
        action.perform()
    
    def _detect_captcha_type(self) -> Optional[str]:
        """Detect which type of captcha is present"""
        # Check for captcha wrapper first
        wrapper = self._find_element(self.CAPTCHA_SELECTORS['wrapper'])
        if not wrapper:
            return None
        
        # Check for puzzle
        puzzle_bg = self._find_element(self.CAPTCHA_SELECTORS['puzzle_bg'])
        puzzle_piece = self._find_element(self.CAPTCHA_SELECTORS['puzzle_piece'])
        if puzzle_bg and puzzle_piece:
            return "puzzle"
        
        # Check for rotate
        rotate_outer = self._find_element(self.CAPTCHA_SELECTORS['rotate_outer'])
        rotate_inner = self._find_element(self.CAPTCHA_SELECTORS['rotate_inner'])
        if rotate_outer and rotate_inner:
            return "rotate"
        
        # Check for shapes
        shapes_img = self._find_element(self.CAPTCHA_SELECTORS['shapes_image'])
        if shapes_img:
            return "shapes"
        
        # Default to puzzle if we have a slider
        slider = self._find_element(self.CAPTCHA_SELECTORS['slider'])
        if slider:
            return "puzzle"
        
        return None
    
    def solve_puzzle(self) -> bool:
        """
        Solve a puzzle/slide captcha.
        
        Returns:
            True if solved successfully
        """
        self._log("Solving puzzle captcha...")
        
        try:
            # Find images
            puzzle_bg = self._find_element(self.CAPTCHA_SELECTORS['puzzle_bg'])
            puzzle_piece = self._find_element(self.CAPTCHA_SELECTORS['puzzle_piece'])
            
            if not puzzle_bg or not puzzle_piece:
                self._log("Could not find puzzle images")
                return False
            
            # Get images as base64
            bg_b64 = self._get_image_base64(puzzle_bg)
            piece_b64 = self._get_image_base64(puzzle_piece)
            
            if not bg_b64 or not piece_b64:
                self._log("Could not get puzzle images")
                return False
            
            # Send to API
            self._log("Sending to API...")
            result = self.client.puzzle(bg_b64, piece_b64)
            
            # Calculate slide distance
            puzzle_width = puzzle_bg.size['width']
            slide_distance = result.get_slide_pixels(puzzle_width)
            
            self._log(f"Slide distance: {slide_distance}px")
            
            # Find and slide the button
            slider_button = self._find_element(self.CAPTCHA_SELECTORS['slider_button'])
            if not slider_button:
                self._log("Could not find slider button")
                return False
            
            self._random_delay(200, 400)
            self._human_slide(slider_button, slide_distance)
            self._random_delay(500, 1000)
            
            return True
            
        except CaptchaSolvedError as e:
            self._log(f"API error: {e}")
            return False
        except Exception as e:
            self._log(f"Error solving puzzle: {e}")
            return False
    
    def solve_rotate(self) -> bool:
        """
        Solve a rotate captcha.
        
        Returns:
            True if solved successfully
        """
        self._log("Solving rotate captcha...")
        
        try:
            # Find images
            outer_img = self._find_element(self.CAPTCHA_SELECTORS['rotate_outer'])
            inner_img = self._find_element(self.CAPTCHA_SELECTORS['rotate_inner'])
            
            if not outer_img or not inner_img:
                self._log("Could not find rotate images")
                return False
            
            # Get images as base64
            outer_b64 = self._get_image_base64(outer_img)
            inner_b64 = self._get_image_base64(inner_img)
            
            if not outer_b64 or not inner_b64:
                self._log("Could not get rotate images")
                return False
            
            # Send to API
            self._log("Sending to API...")
            result = self.client.rotate(outer_b64, inner_b64)
            
            self._log(f"Rotate angle: {result.angle}°")
            
            # Find slider
            slider = self._find_element(self.CAPTCHA_SELECTORS['slider'])
            slider_button = self._find_element(self.CAPTCHA_SELECTORS['slider_button'])
            
            if not slider or not slider_button:
                self._log("Could not find slider")
                return False
            
            # Calculate slide distance
            slider_width = slider.size['width']
            button_width = slider_button.size['width']
            slide_distance = result.get_slider_position(slider_width - button_width)
            
            self._log(f"Slide distance: {slide_distance}px")
            
            self._random_delay(200, 400)
            self._human_slide(slider_button, slide_distance)
            self._random_delay(500, 1000)
            
            return True
            
        except CaptchaSolvedError as e:
            self._log(f"API error: {e}")
            return False
        except Exception as e:
            self._log(f"Error solving rotate: {e}")
            return False
    
    def solve_shapes(self) -> bool:
        """
        Solve a 3D shapes captcha.
        
        Returns:
            True if solved successfully
        """
        self._log("Solving shapes captcha...")
        
        try:
            # Find image
            shapes_img = self._find_element(self.CAPTCHA_SELECTORS['shapes_image'])
            
            if not shapes_img:
                self._log("Could not find shapes image")
                return False
            
            # Get image as base64
            img_b64 = self._get_image_base64(shapes_img)
            
            if not img_b64:
                self._log("Could not get shapes image")
                return False
            
            # Send to API
            self._log("Sending to API...")
            result = self.client.shapes(img_b64)
            
            # Get click points
            img_width = shapes_img.size['width']
            img_height = shapes_img.size['height']
            (x1, y1), (x2, y2) = result.get_click_points(img_width, img_height)
            
            self._log(f"Click points: ({x1}, {y1}) and ({x2}, {y2})")
            
            # Click the two points
            # Convert to offsets from element center
            center_x = img_width // 2
            center_y = img_height // 2
            
            self._random_delay(200, 400)
            self._human_click(shapes_img, x1 - center_x, y1 - center_y)
            
            self._random_delay(300, 600)
            self._human_click(shapes_img, x2 - center_x, y2 - center_y)
            
            self._random_delay(500, 1000)
            
            return True
            
        except CaptchaSolvedError as e:
            self._log(f"API error: {e}")
            return False
        except Exception as e:
            self._log(f"Error solving shapes: {e}")
            return False
    
    def solve_captcha_if_present(self, timeout: int = 15, max_retries: int = 3) -> bool:
        """
        Detect and solve any TikTok captcha if present.
        
        Args:
            timeout: Seconds to wait for captcha to appear
            max_retries: Number of retry attempts
        
        Returns:
            True if captcha was solved or no captcha present
        """
        self._log("Checking for captcha...")
        
        # Wait for possible captcha
        time.sleep(1)
        
        for attempt in range(max_retries):
            captcha_type = self._detect_captcha_type()
            
            if not captcha_type:
                self._log("No captcha detected")
                return True
            
            self._log(f"Detected: {captcha_type} (attempt {attempt + 1}/{max_retries})")
            
            # Solve based on type
            if captcha_type == "puzzle":
                success = self.solve_puzzle()
            elif captcha_type == "rotate":
                success = self.solve_rotate()
            elif captcha_type == "shapes":
                success = self.solve_shapes()
            else:
                success = False
            
            if success:
                # Check if captcha is gone
                time.sleep(2)
                if not self._detect_captcha_type():
                    self._log("Captcha solved successfully!")
                    return True
                self._log("Captcha still present, retrying...")
            
            self._random_delay(1000, 2000)
        
        self._log("Failed to solve captcha after all attempts")
        return False
