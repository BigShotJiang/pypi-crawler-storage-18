"""
CaptchaSolved - TikTok Captcha Solver API

The easiest way to solve TikTok captchas. Works with Selenium, Playwright, and any automation framework.

Website: https://captchasolved.com
Docs: https://captchasolved.com/docs

Quick Start:
    # Install
    pip install captchasolved
    
    # Direct API usage
    from captchasolved import ApiClient
    
    client = ApiClient("your-api-key")
    result = client.puzzle(puzzle_image, piece_image)
    slide_pixels = result.get_slide_pixels(puzzle_width)
    
    # Selenium integration
    from captchasolved.selenium import SeleniumSolver
    
    solver = SeleniumSolver(driver, "your-api-key")
    solver.solve_captcha_if_present()
    
    # Playwright integration
    from captchasolved.playwright import PlaywrightSolver, AsyncPlaywrightSolver
    
    solver = PlaywrightSolver(page, "your-api-key")
    solver.solve_captcha_if_present()
"""

from .api_client import (
    ApiClient,
    CaptchaSolvedError,
    InvalidApiKeyError,
    NoCreditsError,
    ImageProcessingError,
    PuzzleResult,
    RotateResult,
    ShapesResult,
    IconResult,
    create_client,
)

__version__ = "1.0.1"
__author__ = "CaptchaSolved"
__email__ = "support@captchasolved.com"
__url__ = "https://captchasolved.com"

__all__ = [
    # Client
    "ApiClient",
    "create_client",
    
    # Exceptions
    "CaptchaSolvedError",
    "InvalidApiKeyError", 
    "NoCreditsError",
    "ImageProcessingError",
    
    # Result types
    "PuzzleResult",
    "RotateResult",
    "ShapesResult",
    "IconResult",
]
