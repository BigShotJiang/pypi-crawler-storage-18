# CaptchaSolved - TikTok Captcha Solver API

[![PyPI version](https://badge.fury.io/py/captchasolved.svg)](https://pypi.org/project/captchasolved/)
[![Python](https://img.shields.io/pypi/pyversions/captchasolved.svg)](https://pypi.org/project/captchasolved/)

The easiest way to solve TikTok captchas automatically. Works with Selenium, Playwright, and any automation framework.

**Get your API key at: https://captchasolved.com**

## Supported Captchas

| Type | Description | Accuracy |
|------|-------------|----------|
| 🧩 Puzzle/Slide | Slide the piece to complete the puzzle | 100% |
| 🔄 Rotate | Rotate the image to the correct angle | 99% |
| 🎲 3D Shapes | Click the matching 3D objects | 98% |
| 🖼️ Icon | Select the correct objects | 98% |

## Installation

```bash
pip install captchasolved
```

With Selenium:
```bash
pip install captchasolved[selenium]
```

With Playwright:
```bash
pip install captchasolved[playwright]
```

## Quick Start

### Direct API Client

```python
from captchasolved import ApiClient

client = ApiClient("your-api-key")

# Solve puzzle/slide captcha
result = client.puzzle(puzzle_image, piece_image)
slide_pixels = result.get_slide_pixels(puzzle_width=300)
print(f"Slide {slide_pixels} pixels to the right")

# Solve rotate captcha
result = client.rotate(outer_image, inner_image)
print(f"Rotate {result.angle} degrees")

# Solve shapes captcha
result = client.shapes(captcha_image)
(x1, y1), (x2, y2) = result.get_click_points(width=300, height=200)
print(f"Click at ({x1}, {y1}) and ({x2}, {y2})")
```

### Selenium Integration

```python
from selenium import webdriver
from captchasolved.selenium import SeleniumSolver

driver = webdriver.Chrome()
driver.get("https://www.tiktok.com/login")

# Create solver
solver = SeleniumSolver(driver, "your-api-key")

# Fill login form...
# Then solve any captcha that appears
solver.solve_captcha_if_present()
```

### Playwright Integration (Sync)

```python
from playwright.sync_api import sync_playwright
from captchasolved.playwright import PlaywrightSolver

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto("https://www.tiktok.com/login")
    
    solver = PlaywrightSolver(page, "your-api-key")
    solver.solve_captcha_if_present()
```

### Playwright Integration (Async)

```python
import asyncio
from playwright.async_api import async_playwright
from captchasolved.playwright import AsyncPlaywrightSolver

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()
        await page.goto("https://www.tiktok.com/login")
        
        solver = AsyncPlaywrightSolver(page, "your-api-key")
        await solver.solve_captcha_if_present()

asyncio.run(main())
```

## API Response Format

### Puzzle Result
```python
result = client.puzzle(puzzle_image, piece_image)

# slide_x_proportion is 0.0 to 1.0
result.slide_x_proportion  # e.g., 0.65

# Get pixels for a specific width
result.get_slide_pixels(puzzle_width=300)  # e.g., 195
```

### Rotate Result
```python
result = client.rotate(outer_image, inner_image)

# Angle in degrees (0-360)
result.angle  # e.g., 127.5

# Get slider position for a specific width
result.get_slider_position(slider_width=280)  # e.g., 99
```

### Shapes Result
```python
result = client.shapes(captcha_image)

# Proportions (0.0 to 1.0)
result.point_one_proportion_x  # e.g., 0.25
result.point_one_proportion_y  # e.g., 0.5

# Get pixel coordinates
(x1, y1), (x2, y2) = result.get_click_points(width=300, height=200)
```

## Image Input Formats

The API accepts images in multiple formats:

```python
# File path
result = client.puzzle("path/to/puzzle.png", "path/to/piece.png")

# Base64 string
result = client.puzzle(base64_puzzle, base64_piece)

# Raw bytes
result = client.puzzle(puzzle_bytes, piece_bytes)

# NumPy array (OpenCV)
result = client.puzzle(cv2_image, cv2_piece)

# PIL Image
result = client.puzzle(pil_image, pil_piece)
```

## Error Handling

```python
from captchasolved import ApiClient, InvalidApiKeyError, NoCreditsError

client = ApiClient("your-api-key")

try:
    result = client.puzzle(puzzle, piece)
except InvalidApiKeyError:
    print("Invalid API key - get one at https://captchasolved.com")
except NoCreditsError:
    print("No credits remaining - buy more at https://captchasolved.com")
except CaptchaSolvedError as e:
    print(f"Error: {e}")
```

## Pricing

| Plan | Solves | Price | Per Solve |
|------|--------|-------|-----------|
| Starter | 1,000 | $9 | $0.009 |
| Pro | 10,000 | $49 | $0.0049 |
| Enterprise | 100,000 | $299 | $0.003 |

**Get your API key at: https://captchasolved.com**

## Support

- 📧 Email: support@captchasolved.com
- 💬 Telegram: @captchasolved
- 📖 Docs: https://captchasolved.com/docs

## License

MIT License - see LICENSE file for details.
