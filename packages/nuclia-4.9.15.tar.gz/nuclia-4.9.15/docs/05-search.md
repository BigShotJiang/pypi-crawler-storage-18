# Search and answer generation

## Search

Nuclia supports 2 different search endpoints:

- `search`: returns several result sets according the different search techniques (full-text, fuzzy, semantic).
- `find`: returns a single result set where all different results are merged into a hierarchical structure.

Both endpoints support the same query parameters.

- CLI:

  ```bash
  nuclia kb search search --query="My search"
  nuclia kb search find --query="My search" --filters="['/icon/application/pdf','/classification.labels/region/Asia']"
  ```

- SDK:

  ```python
  from nuclia import sdk
  search = sdk.NucliaSearch()
  search.search(query="My search", filters=['/icon/application/pdf', '/classification.labels/region/Asia'])
  search.find(query="My search")
  ```

Get JSON output:

```bash
nuclia kb search find --query="My search" --json
```

Get YAML output:

```bash
nuclia kb search search --query="My search" --yaml
```

## Generative answer

Based on a `find` request, Nuclia uses a generative AI to answer the question based on the context without hallucinations and with the find result and relations.

- CLI:

  ```bash
  nuclia kb search ask --query="My question"
  ```

- SDK:

  ```python
  from nuclia import sdk
  search = sdk.NucliaSearch()
  search.ask(query="My question")
  ```

  You can also use the `AskRequest` item to configure the request with all the parameters supported:

  ```python
  from nuclia import sdk
  from nucliadb_models.search import AskRequest

  search = sdk.NucliaSearch()
  query = AskRequest(query="My question", prefer_markdown=True, citations=True)
  search.ask(query=query)
  ```

### Reasoning

Some LLMs support reasoning. In some models, reasoning is enabled by default, while in others it must be explicitly requested. You can control this behavior using the reasoning parameter.

- SDK:

  ```python
  from nuclia import sdk
  from nucliadb_models.search import AskRequest, Reasoning

  search = sdk.NucliaSearch()
  query = AskRequest(
    query="My question with extra reasoning effort",
    max_tokens=5000,
    reasoning=Reasoning(
        display=True,      # Show reasoning in the response
        effort="low",      # Can be "low", "medium", or "high"
        budget_tokens=1024 # How many tokens reasoning can use
    ),
  )
  search.ask(query=query)
  ```

Model Support for Reasoning Options:

* **OpenAI models** → support `effort` only.
* **Google & Anthropic models** → support `budget_tokens` only.

:::tip
If you send just one of these values (`effort` or `budget_tokens`), Nuclia will automatically fill in the other for you.
:::

:::warning
* Enabling reasoning can use additional tokens, which may increase your usage costs.
* You may need to increase `max_tokens` to give the LLM enough room to reason and generate an answer.
:::

## Filtering

Any endpoint that involves search (`search`, `find` and `ask`) also support more advanced filtering expressions. Expressions can have one of the following operators:

- `all`: this is the default. Will make search return results containing all specified filter labels.
- `any`: returns results containing at least one of the labels.
- `none`: returns results that do not contain any of the labels.
- `not_all`: returns results that do not contain all specified labels.

Note that multiple expressions can be chained in the `filters` parameter and the conjunction of all of them will be computed.

Here are some examples:

- CLI:

  ```bash
  nuclia kb search find --query="My search" --filters="[{'any':['/icon/application/pdf','/icon/image/mp4']}]"
  ```

- SDK:

  ```python
  from nuclia import sdk
  from nucliadb_models.search import Filter

  search = sdk.NucliaSearch()
  search.ask(
    query="My question",
    filters=[Filter(any=['/classification.labels/region/Europe','/classification.labels/region/Asia'])],
  )
  ```

## Using RAG strategies

RAG strategies can be used to improve the quality of the answers by extending the search results passed to the LLM as context.

- CLI:

  ```bash
  nuclia kb search ask --query="My question" --rag_strategies='[{"name":"hierarchy"}]'
  ```

- SDK:

  ```python
  from nuclia import sdk
  search = sdk.NucliaSearch()
  search.ask(query="My question", rag_strategies=[{"name": "hierarchy"}])
  ```

See the [RAG strategies documentation](https://docs.rag.progress.cloud/docs/rag/rag-strategy) for more information.

## Complex queries

The Python SDK allows to use all the options supported by the `/find` and `/ask` endpoints,
but not all of the options can be passed as specific parameter.
In these cases, you can just pass your query as a dictionnary in the `query` parameter.

- CLI:

  ```bash
  nuclia kb search find --query='{"query": "My search", "filters": ["/icon/application/pdf", "/classification.labels/region/Asia"]}'
  nuclia kb search ask --query='{"query": "My search","top_k": 5}'
  ```

- SDK:

  ```python
  from nuclia import sdk
  search = sdk.NucliaSearch()
  search.find(query={"query": "My search", "filters": ["/icon/application/pdf", "/classification.labels/region/Asia"]})
  search.ask(query={"query": "My search","top_k": 5})
  ```

## Graph queries

The Python SDK allows graph queries supported by the `/graph` endpoint. Although
a bit cumbersome, the knowledge graph can be queried as in this example:

- CLI:

  ```bash
  nuclia kb search graph --query='{"query": {"prop": "path", "source": {"value": "Rust"}, "destination": {"value": "Python"}}}'
  ```

- SDK:

  ```python
  from nuclia import sdk
  search = sdk.NucliaSearch()
  search.graph(
      query={
          "query": {
              "prop": "path",
              "source": {"value": "Rust"},
              "destination": {"value": "Python"}
          }
      }
  )
  ```

For more information about graph querying, please refer to [Nuclia's graph
doc](https://docs.rag.progress.cloud/docs/rag/advanced/graph) or the [API reference](https://docs.rag.progress.cloud/docs/api#tag/Search/operation/graph_search_knowledgebox_kb__kbid__graph_post)
