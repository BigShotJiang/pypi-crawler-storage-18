"""Performance tests for sqlit."""
