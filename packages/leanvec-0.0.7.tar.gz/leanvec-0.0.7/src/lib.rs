use parking_lot::RwLock;
use pyo3::prelude::*;
use roaring::RoaringBitmap;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use std::cmp::Reverse;
use std::collections::{BinaryHeap, HashMap};
use std::fs::{File, OpenOptions};
use std::io::{BufReader, BufWriter, Seek, SeekFrom, Write};
use std::path::PathBuf;
use std::sync::Arc;
use memmap2::MmapMut;

const M: usize = 12; // Max neighbors per node
const EF_CONSTRUCTION: usize = 100;
const DIM: usize = 768; // Fixed Dimension for vector storage

#[inline(always)]
fn quantize(val: f32) -> u8 {
    let clamped = val.clamp(-1.0, 1.0);
    ((clamped + 1.0) * 127.5) as u8
}

#[inline(always)]
fn dist_sq_u8(a: &[u8], b: &[u8]) -> u32 {
    let mut d: u32 = 0;
    for i in 0..a.len() {
        let diff = (a[i] as i32) - (b[i] as i32);
        d += (diff * diff) as u32;
    }
    d
}

// --- Persistence Structures ---

#[derive(Serialize, Deserialize)]
enum WalEntry {
    Insert { id: String, vec: Vec<f32>, meta: Map<String, Value> },
    Delete { id: String },
}

#[derive(Serialize, Deserialize)]
struct SnapshotData {
    flat_graph: Vec<usize>, 
    enter_point: Option<usize>,
    str_index: HashMap<String, HashMap<String, RoaringBitmap>>,
    num_store: HashMap<String, Vec<f32>>,
    valid_ids: RoaringBitmap,
    deleted: RoaringBitmap,
    ext_to_int: HashMap<String, usize>,
    int_to_ext: Vec<String>,
}

#[derive(Serialize)]
struct SnapshotView<'a> {
    flat_graph: &'a Vec<usize>,
    enter_point: Option<usize>,
    str_index: &'a HashMap<String, HashMap<String, RoaringBitmap>>,
    num_store: &'a HashMap<String, Vec<f32>>,
    valid_ids: &'a RoaringBitmap,
    deleted: &'a RoaringBitmap,
    ext_to_int: &'a HashMap<String, usize>,
    int_to_ext: &'a Vec<String>,
}

struct CoreIndex {
    mmap: MmapMut,
    vector_file: File,
    capacity_vectors: usize,

    // RAM Structures
    flat_graph: Vec<usize>, // structure: [neighbor0..M for id 0, neighbor0..M for id 1, ...]
    enter_point: Option<usize>,
    str_index: HashMap<String, HashMap<String, RoaringBitmap>>,
    num_store: HashMap<String, Vec<f32>>,
    valid_ids: RoaringBitmap,
    deleted: RoaringBitmap,
    ext_to_int: HashMap<String, usize>,
    int_to_ext: Vec<String>,
}

impl CoreIndex {
    fn new(base_path: &PathBuf) -> Self {
        let vec_path = base_path.join("vectors.bin");
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .open(&vec_path)
            .expect("Failed to open vector storage file");

        let len = file.metadata().unwrap().len() as usize;
        let capacity_vectors = std::cmp::max(100_000, len / DIM);
        
        let required_bytes = capacity_vectors * DIM;
        if len < required_bytes {
            file.set_len(required_bytes as u64).unwrap();
        }

        let mmap = unsafe { MmapMut::map_mut(&file).expect("Failed to mmap vector file") };

        Self {
            mmap,
            vector_file: file,
            capacity_vectors,
            flat_graph: Vec::with_capacity(capacity_vectors * M),
            enter_point: None,
            str_index: HashMap::new(),
            num_store: HashMap::new(),
            valid_ids: RoaringBitmap::new(),
            deleted: RoaringBitmap::new(),
            ext_to_int: HashMap::new(),
            int_to_ext: Vec::with_capacity(capacity_vectors),
        }
    }

    fn ensure_capacity(&mut self) {
        let current_count = self.int_to_ext.len();
        if current_count >= self.capacity_vectors {
            let new_cap = self.capacity_vectors + 100_000;
            let new_bytes = new_cap * DIM;
            
            self.mmap.flush().unwrap();
            self.vector_file.set_len(new_bytes as u64).unwrap();
            self.capacity_vectors = new_cap;
            self.mmap = unsafe { MmapMut::map_mut(&self.vector_file).unwrap() };
        }
    }

    #[inline(always)]
    fn get_vector(&self, idx: usize) -> &[u8] {
        let start = idx * DIM;
        &self.mmap[start..start + DIM]
    }

    #[inline(always)]
    fn get_neighbors(&self, idx: usize) -> &[usize] {
        let start = idx * M;
        let neighbors = &self.flat_graph[start..start + M];
        // Return only slots that aren't usize::MAX
        let end = neighbors.iter().position(|&x| x == usize::MAX).unwrap_or(M);
        &neighbors[..end]
    }

    fn add_neighbor(&mut self, node_idx: usize, neighbor_idx: usize) {
        let start = node_idx * M;
        for i in 0..M {
            if self.flat_graph[start + i] == usize::MAX {
                self.flat_graph[start + i] = neighbor_idx;
                return;
            }
            if self.flat_graph[start + i] == neighbor_idx { return; }
        }
    }

    fn insert_in_mem(&mut self, ext_id: String, vector: Vec<f32>, metadata: Map<String, Value>) {
        if self.ext_to_int.contains_key(&ext_id) { return; }

        self.ensure_capacity();
        let new_id = self.int_to_ext.len();

        // 1. Quantize and Write to Mmap
        let start = new_id * DIM;
        for (i, &val) in vector.iter().take(DIM).enumerate() {
            self.mmap[start + i] = quantize(val);
        }

        // 2. Initialize Graph Node
        for _ in 0..M { self.flat_graph.push(usize::MAX); }

        self.int_to_ext.push(ext_id.clone());
        self.ext_to_int.insert(ext_id, new_id);
        self.valid_ids.insert(new_id as u32);

        // 3. Metadata Processing
        for (key, val) in metadata {
            match val {
                Value::String(s) => {
                    self.str_index.entry(key).or_default().entry(s).or_default().insert(new_id as u32);
                },
                Value::Number(n) => {
                    if let Some(f) = n.as_f64() {
                        let col = self.num_store.entry(key).or_insert_with(|| vec![f32::NAN; new_id]);
                        if col.len() < new_id { col.resize(new_id, f32::NAN); }
                        col.push(f as f32);
                    }
                },
                Value::Bool(b) => {
                    let s = if b { "true".to_string() } else { "false".to_string() };
                    self.str_index.entry(key).or_default().entry(s).or_default().insert(new_id as u32);
                },
                _ => {} 
            }
        }

        for col in self.num_store.values_mut() {
            if col.len() == new_id { col.push(f32::NAN); }
        }

        // 4. HNSW Search and Connect
        if self.enter_point.is_none() {
            self.enter_point = Some(new_id);
            return;
        }

        let q_vec = self.get_vector(new_id).to_vec();
        let neighbors = self._search_core(&q_vec, EF_CONSTRUCTION, None);
        
        for (_dist, neighbor_id) in neighbors.into_iter().take(M) {
            self.add_neighbor(new_id, neighbor_id);
            self.add_neighbor(neighbor_id, new_id);
        }

        if new_id % 10000 == 0 { let _ = self.mmap.flush_async(); }
    }

    fn delete_in_mem(&mut self, ext_id: String) {
        if let Some(&int_id) = self.ext_to_int.get(&ext_id) {
            self.deleted.insert(int_id as u32);
            self.valid_ids.remove(int_id as u32);
            self.ext_to_int.remove(&ext_id);

            if Some(int_id) == self.enter_point {
                self.enter_point = self.valid_ids.max().map(|x| x as usize);
            }
        }
    }

    // --- Filter Logic ---

    fn is_expensive_filter(&self, filter: &Value) -> bool {
        match filter {
            Value::Object(map) => {
                if let Some(clauses) = map.get("$and").or(map.get("$or")) {
                    if let Value::Array(arr) = clauses {
                        return arr.iter().any(|f| self.is_expensive_filter(f));
                    }
                }
                for (key, val) in map {
                    if key.starts_with("$") { continue; }
                    if self.num_store.contains_key(key) { return true; }
                    if let Value::Object(ops) = val {
                        for (op, _) in ops {
                            if ["$gt", "$gte", "$lt", "$lte"].contains(&op.as_str()) { return true; }
                        }
                    }
                }
                false
            },
            _ => false
        }
    }

    fn evaluate_filter(&self, filter: &Value, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        match filter {
            Value::Object(map) => {
                if let Some(clauses) = map.get("$and") {
                    if let Value::Array(arr) = clauses {
                        let (cheap, expensive): (Vec<&Value>, Vec<&Value>) = arr.iter()
                            .partition(|f| !self.is_expensive_filter(f));
                        let mut current_res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
                        for f in cheap {
                            current_res &= self.evaluate_filter(f, None);
                            if current_res.is_empty() { return current_res; }
                        }
                        for f in expensive {
                            current_res &= self.evaluate_filter(f, Some(&current_res));
                            if current_res.is_empty() { return current_res; }
                        }
                        return current_res;
                    }
                }
                if let Some(clauses) = map.get("$or") {
                    if let Value::Array(arr) = clauses {
                        let mut res = RoaringBitmap::new();
                        for sub in arr { res |= self.evaluate_filter(sub, None); }
                        if let Some(m) = mask { res &= m; }
                        return res;
                    }
                }
                if let Some(clause) = map.get("$not") {
                    let sub = self.evaluate_filter(clause, None);
                    let mut res = &self.valid_ids - &sub;
                    if let Some(m) = mask { res &= m; }
                    return res;
                }
                let mut res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
                for (key, val) in map {
                    if key.starts_with("$") { continue; }
                    res &= self.evaluate_field_condition(key, val, Some(&res));
                    if res.is_empty() { return res; }
                }
                res
            },
            _ => RoaringBitmap::new(),
        }
    }

    fn evaluate_field_condition(&self, field: &str, condition: &Value, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        if condition.is_string() || condition.is_boolean() {
            return self.get_bitmap_str_eq(field, condition);
        }
        if condition.is_number() {
            return self.evaluate_numeric_op(field, "$eq", condition.as_f64().unwrap() as f32, mask);
        }
        if let Value::Object(op_map) = condition {
            let mut res = mask.cloned().unwrap_or_else(|| self.valid_ids.clone());
            for (op, val) in op_map {
                let op_res = match op.as_str() {
                    "$eq" => {
                        if val.is_number() { self.evaluate_numeric_op(field, "$eq", val.as_f64().unwrap() as f32, mask) }
                        else { self.get_bitmap_str_eq(field, val) }
                    },
                    "$ne" => {
                         if val.is_number() { self.evaluate_numeric_op(field, "$ne", val.as_f64().unwrap() as f32, mask) }
                         else { &self.valid_ids - &self.get_bitmap_str_eq(field, val) }
                    },
                    "$in" => {
                        let mut u = RoaringBitmap::new();
                        if let Value::Array(arr) = val {
                            for item in arr { u |= self.evaluate_field_condition(field, item, None); }
                        }
                        u
                    },
                    "$nin" => {
                        let mut u = RoaringBitmap::new();
                        if let Value::Array(arr) = val {
                            for item in arr { u |= self.evaluate_field_condition(field, item, None); }
                        }
                        &self.valid_ids - &u
                    },
                    "$gt" | "$gte" | "$lt" | "$lte" => {
                        if let Some(f) = val.as_f64() { self.evaluate_numeric_op(field, op, f as f32, mask) }
                        else { RoaringBitmap::new() }
                    },
                    _ => RoaringBitmap::new()
                };
                res &= op_res;
            }
            return res;
        }
        RoaringBitmap::new()
    }

    fn get_bitmap_str_eq(&self, field: &str, val: &Value) -> RoaringBitmap {
        let key_str = match val {
            Value::String(s) => s.clone(),
            Value::Bool(b) => if *b { "true".to_string() } else { "false".to_string() },
            _ => return RoaringBitmap::new(),
        };
        self.str_index.get(field)
            .and_then(|m| m.get(&key_str))
            .cloned().unwrap_or_default()
    }

    fn evaluate_numeric_op(&self, field: &str, op: &str, target: f32, mask: Option<&RoaringBitmap>) -> RoaringBitmap {
        if let Some(column) = self.num_store.get(field) {
            let mut matches: Vec<u32> = Vec::with_capacity(1024); 
            let use_sparse = if let Some(m) = mask { (m.len() as usize) < (self.int_to_ext.len() / 2) } else { false };

            if use_sparse {
                if let Some(m) = mask {
                    for id in m.iter() {
                        if let Some(&val) = column.get(id as usize) {
                            if val.is_nan() { continue; }
                            let is_match = match op {
                                "$gt" => val > target, "$gte" => val >= target,
                                "$lt" => val < target, "$lte" => val <= target,
                                "$eq" => (val - target).abs() < f32::EPSILON,
                                "$ne" => (val - target).abs() > f32::EPSILON,
                                _ => false
                            };
                            if is_match { matches.push(id); }
                        }
                    }
                    return RoaringBitmap::from_sorted_iter(matches.into_iter()).unwrap(); 
                }
            }

            for (i, &val) in column.iter().enumerate() {
                 let is_match = match op {
                    "$gt" => val > target, "$gte" => val >= target,
                    "$lt" => val < target, "$lte" => val <= target,
                    "$eq" => (val - target).abs() < f32::EPSILON,
                    "$ne" => (val - target).abs() > f32::EPSILON,
                    _ => false
                };
                if is_match { matches.push(i as u32); }
            }
            let mut bm = RoaringBitmap::from_sorted_iter(matches.into_iter()).unwrap();
            if let Some(m) = mask { bm &= m; } else { bm &= &self.valid_ids; }
            return bm;
        }
        RoaringBitmap::new()
    }

    fn _search_core(&self, target_vec: &[u8], ef: usize, filter: Option<&RoaringBitmap>) -> Vec<(u32, usize)> {
        if self.enter_point.is_none() { return vec![]; }

        let mut visited = RoaringBitmap::new();
        let mut candidates = BinaryHeap::new(); 
        let mut results = BinaryHeap::new();

        let ep = self.enter_point.unwrap();
        let d_ep = dist_sq_u8(target_vec, self.get_vector(ep));
        
        candidates.push(Reverse((d_ep, ep)));
        visited.insert(ep as u32);
        
        if !self.deleted.contains(ep as u32) && filter.map_or(true, |bm| bm.contains(ep as u32)) {
             results.push((d_ep, ep));
        }

        while let Some(Reverse((d_curr, curr_id))) = candidates.pop() {
            if results.len() >= ef && d_curr > results.peek().unwrap().0 { break; }

            for &neighbor in self.get_neighbors(curr_id) {
                if !visited.contains(neighbor as u32) {
                    visited.insert(neighbor as u32);
                    let dist = dist_sq_u8(target_vec, self.get_vector(neighbor));
                    let threshold = if results.len() >= ef { results.peek().unwrap().0 } else { u32::MAX };

                    if dist <= threshold {
                        candidates.push(Reverse((dist, neighbor)));
                        if !self.deleted.contains(neighbor as u32) && filter.map_or(true, |bm| bm.contains(neighbor as u32)) {
                            results.push((dist, neighbor));
                            if results.len() > ef { results.pop(); }
                        }
                    }
                }
            }
        }
        results.into_sorted_vec()
    }

    fn compact_memory(&mut self) {
        self.flat_graph.shrink_to_fit();
        self.int_to_ext.shrink_to_fit();
        self.ext_to_int.shrink_to_fit();
        self.num_store.shrink_to_fit();
        for col in self.num_store.values_mut() { col.shrink_to_fit(); }
    }
}

// --- Python Class Wrapper ---

#[pyclass]
struct LeanDB {
    inner: Arc<RwLock<CoreIndex>>,
    base_path: PathBuf,
    wal_writer: Arc<RwLock<BufWriter<File>>>,
}

#[pymethods]
impl LeanDB {
    #[new]
    fn new(storage_path: String) -> PyResult<Self> {
        let path = PathBuf::from(storage_path);
        std::fs::create_dir_all(&path)?;
        let snapshot_path = path.join("snapshot.bin");
        let wal_path = path.join("wal.bin");

        let mut index = CoreIndex::new(&path);
        
        if snapshot_path.exists() {
            let f = File::open(&snapshot_path)?;
            if let Ok(snap) = bincode::deserialize_from::<_, SnapshotData>(BufReader::new(f)) {
                index.flat_graph = snap.flat_graph;
                index.enter_point = snap.enter_point;
                index.str_index = snap.str_index;
                index.num_store = snap.num_store;
                index.valid_ids = snap.valid_ids;
                index.deleted = snap.deleted;
                index.ext_to_int = snap.ext_to_int;
                index.int_to_ext = snap.int_to_ext;
                index.ensure_capacity();
            }
        }

        if wal_path.exists() {
            let f = File::open(&wal_path)?;
            let mut reader = BufReader::new(f);
            while let Ok(entry) = bincode::deserialize_from::<_, WalEntry>(&mut reader) {
                match entry {
                    WalEntry::Insert { id, vec, meta } => index.insert_in_mem(id, vec, meta),
                    WalEntry::Delete { id } => index.delete_in_mem(id),
                }
            }
        }

        let wal_file = OpenOptions::new().create(true).append(true).open(&wal_path)?;

        Ok(LeanDB {
            inner: Arc::new(RwLock::new(index)),
            base_path: path,
            wal_writer: Arc::new(RwLock::new(BufWriter::new(wal_file))),
        })
    }

    fn add(&self, id: String, vector: Vec<f32>, metadata: String) -> PyResult<()> {
        let meta_map: Map<String, Value> = serde_json::from_str(&metadata)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid JSON: {}", e)))?;

        {
            let mut writer = self.wal_writer.write();
            let entry = WalEntry::Insert { id: id.clone(), vec: vector.clone(), meta: meta_map.clone() };
            bincode::serialize_into(&mut *writer, &entry).unwrap();
        }

        let mut guard = self.inner.write();
        guard.insert_in_mem(id, vector, meta_map);
        Ok(())
    }

    fn delete(&self, id: String) {
        {
            let mut writer = self.wal_writer.write();
            let entry = WalEntry::Delete { id: id.clone() };
            bincode::serialize_into(&mut *writer, &entry).unwrap();
        }
        self.inner.write().delete_in_mem(id);
    }

    fn delete_by_filter(&self, filter_json: String) -> PyResult<usize> {
        let filter_val: Value = serde_json::from_str(&filter_json)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid Filter: {}", e)))?;

        let mut guard = self.inner.write();
        let mut writer = self.wal_writer.write();
        let matches = guard.evaluate_filter(&filter_val, None);
        
        let mut count = 0;
        for int_id in matches.iter() {
            let idx = int_id as usize;
            if idx < guard.int_to_ext.len() {
                let ext_id = guard.int_to_ext[idx].clone();
                let entry = WalEntry::Delete { id: ext_id.clone() };
                if bincode::serialize_into(&mut *writer, &entry).is_ok() {
                    guard.delete_in_mem(ext_id);
                    count += 1;
                }
            }
        }
        Ok(count)
    }

    fn persist(&self) -> PyResult<()> {
        let snapshot_path = self.base_path.join("snapshot.bin");
        let tmp_path = self.base_path.join("snapshot.bin.tmp");

        {
            let mut guard = self.inner.write();
            guard.compact_memory();
            guard.mmap.flush().unwrap();
        } 
        
        {
            let guard = self.inner.read();
            let mut writer = BufWriter::with_capacity(1024 * 1024, File::create(&tmp_path)?);
            let view = SnapshotView {
                flat_graph: &guard.flat_graph,
                enter_point: guard.enter_point,
                str_index: &guard.str_index,
                num_store: &guard.num_store,
                valid_ids: &guard.valid_ids,
                deleted: &guard.deleted,
                ext_to_int: &guard.ext_to_int,
                int_to_ext: &guard.int_to_ext,
            };
            bincode::serialize_into(&mut writer, &view).unwrap();
            writer.flush()?;
        }

        std::fs::rename(&tmp_path, &snapshot_path)?;
        
        {
            let mut wal_guard = self.wal_writer.write();
            let file = wal_guard.get_mut();
            file.set_len(0)?;
            file.seek(SeekFrom::Start(0))?;
        }
        Ok(())
    }

    fn search(&self, vector: Vec<f32>, k: usize, filter_json: Option<String>) -> PyResult<Vec<(String, f32)>> {
        let guard = self.inner.read();
        let q_vec: Vec<u8> = vector.iter().take(DIM).map(|&x| quantize(x)).collect();

        let mut mask: Option<RoaringBitmap> = None;
        if let Some(json_str) = filter_json {
             let filter_val: Value = serde_json::from_str(&json_str).unwrap();
             mask = Some(guard.evaluate_filter(&filter_val, None));
        }

        let raw_results = guard._search_core(&q_vec, k * 5, mask.as_ref());

        Ok(raw_results.iter()
            .take(k)
            .map(|(_d, idx)| (guard.int_to_ext[*idx].clone(), *_d as f32))
            .collect())
    }
    
    fn count(&self) -> usize {
        let guard = self.inner.read();
        guard.int_to_ext.len() - guard.deleted.len() as usize
    }
}

#[pymodule]
fn leanvec(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<LeanDB>()?;
    Ok(())
}