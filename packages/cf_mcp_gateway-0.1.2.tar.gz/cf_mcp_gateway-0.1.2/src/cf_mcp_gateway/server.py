"""FastMCP server for the Cloudflare MCP Gateway."""

import logging
from typing import Any

from fastmcp import Client, FastMCP
from fastmcp.client.transports import StreamableHttpTransport
from mcp.types import TextContent

from .config import GatewaySettings
from .registry import ServiceRegistry

logger = logging.getLogger(__name__)

# Global state for the gateway
_settings: GatewaySettings | None = None
_registry: ServiceRegistry | None = None
_service_endpoints: dict[str, str] = {}  # Store endpoints, not transports

# Create the FastMCP server instance
mcp = FastMCP(
    "Cloudflare MCP Gateway",
    instructions="A unified gateway for accessing multiple Cloudflare services. "
    "Tools are prefixed with the service name (e.g., docs_, kv_, r2_).",
)


async def initialize_gateway(settings: GatewaySettings) -> None:
    """Initialize the gateway with settings.

    Args:
        settings: Gateway configuration settings.
    """
    global _settings, _registry

    _settings = settings
    _registry = ServiceRegistry(settings)

    logger.info(
        f"Initialized registry with {len(_registry)} services: "
        f"{', '.join(s.id for s in _registry)}"
    )


async def _call_upstream_tool(service_id: str, tool_name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Call the upstream tool with a completely fresh connection.

    This creates a fresh transport AND client for each tool call to avoid
    the FastMCP proxy bug where connections hang after list_tools.
    Transport reuse causes hanging even with fresh clients.
    """
    if not _settings:
        raise RuntimeError("Gateway not initialized")

    endpoint = _service_endpoints.get(service_id)
    if not endpoint:
        raise RuntimeError(f"No endpoint configured for service {service_id}")

    # Create fresh transport AND client for each call
    auth_headers = {
        "Authorization": f"Bearer {_settings.cloudflare_api_token}",
        "CF-Account-ID": _settings.cloudflare_account_id,
    }
    transport = StreamableHttpTransport(url=endpoint, headers=auth_headers)
    client = Client(transport)

    async with client:
        result = await client.call_tool(tool_name, arguments)
        return result.content


def _make_query_tool(svc_id: str, orig_name: str, description: str):
    """Create a tool function for query-based tools."""
    async def tool_fn(query: str) -> list[TextContent]:
        """Search tool."""
        return await _call_upstream_tool(svc_id, orig_name, {'query': query})
    tool_fn.__doc__ = description
    return tool_fn


def _make_no_args_tool(svc_id: str, orig_name: str, description: str):
    """Create a tool function for no-argument tools."""
    async def tool_fn() -> list[TextContent]:
        """No-args tool."""
        return await _call_upstream_tool(svc_id, orig_name, {})
    tool_fn.__doc__ = description
    return tool_fn


def _register_tool(service_id: str, tool) -> None:
    """Register a single tool from the upstream service.

    Creates a properly typed wrapper function based on the tool's input schema.
    """
    prefixed_name = f"{service_id}_{tool.name}"
    original_name = tool.name
    description = tool.description or f"Call {original_name} on {service_id}"

    # Get the input schema
    input_schema = tool.inputSchema if hasattr(tool, 'inputSchema') else {}
    properties = input_schema.get('properties', {})

    if properties:
        param_names = list(properties.keys())

        if len(param_names) == 1 and param_names[0] == 'query':
            # Special case for search-style tools with single 'query' parameter
            tool_fn = _make_query_tool(service_id, original_name, description)
            mcp.tool(name=prefixed_name, description=description)(tool_fn)
        elif len(param_names) == 0:
            # No parameters
            tool_fn = _make_no_args_tool(service_id, original_name, description)
            mcp.tool(name=prefixed_name, description=description)(tool_fn)
        else:
            # Multiple parameters - dynamically create function
            # Sanitize function name for Python
            func_name = prefixed_name.replace("-", "_").replace(".", "_")

            # Build parameter string
            param_str = ', '.join(f'{name}: str = ""' for name in param_names)

            # Build args dict construction
            args_lines = '\n    '.join(
                f'if {name} != "": args["{name}"] = {name}'
                for name in param_names
            )

            func_code = f'''
async def {func_name}({param_str}) -> list:
    """{description}"""
    args = {{}}
    {args_lines}
    return await _call_upstream_tool("{service_id}", "{original_name}", args)
'''
            local_vars = {'_call_upstream_tool': _call_upstream_tool, 'list': list}
            exec(func_code, local_vars)
            tool_fn = local_vars[func_name]
            mcp.tool(name=prefixed_name, description=description)(tool_fn)
    else:
        # No schema defined - create a no-args function
        tool_fn = _make_no_args_tool(service_id, original_name, description)
        mcp.tool(name=prefixed_name, description=description)(tool_fn)

    logger.debug(f"Registered tool: {prefixed_name}")


async def connect_and_mount_services() -> None:
    """Connect to all enabled upstream services and import their tools."""
    global _service_endpoints

    if not _registry or not _settings:
        raise RuntimeError("Gateway not initialized. Call initialize_gateway() first.")

    auth_headers = {
        "Authorization": f"Bearer {_settings.cloudflare_api_token}",
        "CF-Account-ID": _settings.cloudflare_account_id,
    }

    for service in _registry.get_enabled_services():
        try:
            logger.info(f"Connecting to {service.id} at {service.endpoint}")

            # Store endpoint for later use (fresh transport per call)
            _service_endpoints[service.id] = service.endpoint

            # Create a temporary transport+client just to fetch tool definitions
            transport = StreamableHttpTransport(url=service.endpoint, headers=auth_headers)
            client = Client(transport)

            async with client:
                # Fetch all tools from the upstream server
                tools_result = await client.list_tools()
                tools = tools_result.tools if hasattr(tools_result, 'tools') else tools_result

                logger.info(f"Found {len(tools)} tools from {service.id}")

                # Create wrapper tools for each upstream tool
                for tool in tools:
                    try:
                        _register_tool(service.id, tool)
                    except Exception as e:
                        logger.warning(f"Failed to register tool {tool.name}: {e}")
                        logger.exception(e)

            # Transport is now closed, will create fresh one per tool call
            logger.info(f"Successfully imported tools from {service.id} with prefix '{service.id}_'")

        except Exception as e:
            logger.warning(f"Failed to connect to {service.id}, will skip: {e}")
            logger.exception(e)


async def shutdown_gateway() -> None:
    """Perform graceful shutdown of the gateway."""
    global _service_endpoints

    logger.info("Shutting down gateway...")
    _service_endpoints = {}
    logger.info("Gateway shutdown complete")
