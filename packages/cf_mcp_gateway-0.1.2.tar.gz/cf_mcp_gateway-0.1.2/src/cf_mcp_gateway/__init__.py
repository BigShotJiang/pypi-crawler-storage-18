"""Centralized MCP Gateway for Cloudflare services."""

__version__ = "0.1.0"
