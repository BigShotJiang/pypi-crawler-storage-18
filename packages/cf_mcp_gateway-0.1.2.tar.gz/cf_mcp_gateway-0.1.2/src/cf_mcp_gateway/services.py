"""Service definitions for Cloudflare MCP services."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ServiceConfig:
    """Configuration for a Cloudflare MCP service."""

    id: str
    name: str
    endpoint: str
    description: str


# Available Cloudflare MCP services (Phase 1)
AVAILABLE_SERVICES: dict[str, ServiceConfig] = {
    "docs": ServiceConfig(
        id="docs",
        name="Documentation",
        endpoint="https://docs.mcp.cloudflare.com/mcp",
        description="Cloudflare documentation reference and search",
    ),
    "bindings": ServiceConfig(
        id="bindings",
        name="Workers Bindings",
        endpoint="https://bindings.mcp.cloudflare.com/mcp",
        description="Storage, AI, and compute primitives for Workers",
    ),
    "builds": ServiceConfig(
        id="builds",
        name="Workers Builds",
        endpoint="https://builds.mcp.cloudflare.com/mcp",
        description="Deployment insights and management for Workers",
    ),
    "observability": ServiceConfig(
        id="observability",
        name="Observability",
        endpoint="https://observability.mcp.cloudflare.com/mcp",
        description="Logs and analytics debugging",
    ),
    "radar": ServiceConfig(
        id="radar",
        name="Radar",
        endpoint="https://radar.mcp.cloudflare.com/mcp",
        description="Internet traffic insights and URL scanning",
    ),
    "browser": ServiceConfig(
        id="browser",
        name="Browser Rendering",
        endpoint="https://browser.mcp.cloudflare.com/mcp",
        description="Web page fetching, markdown conversion, and screenshots",
    ),
    "ai-gateway": ServiceConfig(
        id="ai-gateway",
        name="AI Gateway",
        endpoint="https://ai-gateway.mcp.cloudflare.com/mcp",
        description="Prompt/response log search and analysis",
    ),
    "d1": ServiceConfig(
        id="d1",
        name="D1",
        endpoint="https://d1.mcp.cloudflare.com/mcp",
        description="Serverless SQL database operations",
    ),
    "kv": ServiceConfig(
        id="kv",
        name="KV",
        endpoint="https://kv.mcp.cloudflare.com/mcp",
        description="Key-value storage operations",
    ),
    "r2": ServiceConfig(
        id="r2",
        name="R2",
        endpoint="https://r2.mcp.cloudflare.com/mcp",
        description="Object storage operations",
    ),
}


def get_available_service_ids() -> list[str]:
    """Return list of all available service IDs."""
    return list(AVAILABLE_SERVICES.keys())


def validate_service_ids(service_ids: list[str]) -> tuple[list[str], list[str]]:
    """Validate service IDs and return (valid, invalid) lists."""
    valid = []
    invalid = []
    for sid in service_ids:
        if sid in AVAILABLE_SERVICES:
            valid.append(sid)
        else:
            invalid.append(sid)
    return valid, invalid
