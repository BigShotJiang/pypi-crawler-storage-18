import argparse
import asyncio
import multiprocessing
import os
import subprocess
import sys
import time
from pathlib import Path

from pydantic import ValidationError

from osa_tool.aboutgen.about_generator import AboutGenerator
from osa_tool.analytics.report_maker import (
    ReportGenerator,
    WhatHasBeenDoneReportGenerator,
)
from osa_tool.analytics.sourcerank import SourceRank
from osa_tool.config.settings import ConfigLoader, GitSettings
from osa_tool.conversion.notebook_converter import NotebookConverter
from osa_tool.docs_generator.docs_run import generate_documentation
from osa_tool.docs_generator.license import compile_license_file
from osa_tool.git_agent.git_agent import GitHubAgent, GitLabAgent, GitverseAgent
from osa_tool.organization.repo_organizer import RepoOrganizer
from osa_tool.osatreesitter.docgen import DocGen
from osa_tool.osatreesitter.osa_treesitter import OSA_TreeSitter
from osa_tool.readmegen.readme_core import ReadmeAgent
from osa_tool.readmegen.utils import format_time
from osa_tool.scheduler.scheduler import ModeScheduler
from osa_tool.scheduler.todo_list import ToDoList
from osa_tool.scheduler.workflow_manager import (
    GitHubWorkflowManager,
    GitLabWorkflowManager,
    GitverseWorkflowManager,
)
from osa_tool.translation.dir_translator import DirectoryTranslator
from osa_tool.translation.readme_translator import ReadmeTranslator
from osa_tool.utils.arguments_parser import build_parser_from_yaml
from osa_tool.utils.logger import logger, setup_logging
from osa_tool.utils.prompts_builder import PromptLoader
from osa_tool.utils.utils import (
    delete_repository,
    osa_project_root,
    parse_folder_name,
    rich_section,
)
from osa_tool.validation.doc_validator import DocValidator
from osa_tool.validation.paper_validator import PaperValidator
from osa_tool.validation.report_generator import (
    ReportGenerator as ValidationReportGenerator,
)


def main():
    """Main function to generate a README.md file for a Git repository.

    Handles command-line arguments, clones the repository, creates and checks out a branch,
    generates the README.md file, and commits and pushes the changes.
    """

    # Create a command line argument parser
    parser = build_parser_from_yaml(extra_sections=["settings", "arguments", "workflow"])
    args = parser.parse_args()
    create_fork = not args.no_fork
    create_pull_request = not args.no_pull_request

    # Initialize logging
    logs_dir = os.path.join(os.path.dirname(osa_project_root()), "logs")
    repo_name = parse_folder_name(args.repository)
    setup_logging(repo_name, logs_dir)

    # Load prompts
    prompts = PromptLoader()

    loop = asyncio.get_event_loop()
    asyncio.set_event_loop(loop)

    start_time = time.time()
    try:
        # Switch to output directory if present
        if args.output:
            output_path = Path(args.output).resolve()
            if not output_path.exists():
                output_path.mkdir(parents=True, exist_ok=True)
                logger.info(f"Created directory: {output_path}")
            os.chdir(output_path)
            logger.info(f"Output path changed to {output_path}")

        # Load configurations and update
        config_loader = load_configuration(args)

        # Initialize Git agent and Workflow Manager for used platform, perform operations
        git_agent, workflow_manager = initialize_git_platform(args)

        if create_fork:
            git_agent.star_repository()
            git_agent.create_fork()
        git_agent.clone_repository()

        # Initialize ModeScheduler
        sourcerank = SourceRank(config_loader)
        scheduler = ModeScheduler(config_loader, sourcerank, prompts, args, workflow_manager, git_agent.metadata)
        plan = scheduler.plan
        what_has_been_done = ToDoList(scheduler.plan)

        if create_fork:
            git_agent.create_and_checkout_branch()

        # Repository Analysis Report generation
        # NOTE: Must run first - switches GitHub branches
        if plan.get("report"):
            rich_section("Report generation")
            analytics = ReportGenerator(config_loader, sourcerank, prompts, git_agent.metadata)
            analytics.build_pdf()
            if create_fork:
                git_agent.upload_report(analytics.filename, analytics.output_path)
            what_has_been_done.mark_did("report")

        # NOTE: Must run first - switches GitHub branches
        if plan.get("validate_doc"):
            rich_section("Document validation")
            content = loop.run_until_complete(DocValidator(config_loader, prompts).validate(plan.get("attachment")))
            if content:
                va_re_gen = ValidationReportGenerator(config_loader, git_agent.metadata, sourcerank)
                va_re_gen.build_pdf("Document", content)
                if create_fork:
                    git_agent.upload_report(va_re_gen.filename, va_re_gen.output_path)
                what_has_been_done.mark_did("validate_doc")
            else:
                logger.warning("Document validation returned no content. Skipping report generation.")
        # NOTE: Must run first - switches GitHub branches
        if plan.get("validate_paper"):
            rich_section("Paper validation")
            content = loop.run_until_complete(PaperValidator(config_loader, prompts).validate(plan.get("attachment")))
            if content:
                va_re_gen = ValidationReportGenerator(config_loader, git_agent.metadata, sourcerank)
                va_re_gen.build_pdf("Paper", content)
                if create_fork:
                    git_agent.upload_report(va_re_gen.filename, va_re_gen.output_path)
                what_has_been_done.mark_did("validate_paper")
            else:
                logger.warning("Paper validation returned no content. Skipping report generation.")

        # .ipynb to .py conversion
        if notebook := plan.get("convert_notebooks"):
            rich_section("Jupyter notebooks conversion")
            convert_notebooks(args.repository, notebook)
            what_has_been_done.mark_did("convert_notebooks")

        # Auto translating names of directories
        if plan.get("translate_dirs"):
            rich_section("Directory and file translation")
            translation = DirectoryTranslator(config_loader)
            translation.rename_directories_and_files()
            what_has_been_done.mark_did("translate_dirs")

        # Docstring generation
        if plan.get("docstring"):
            rich_section("Docstrings generation")
            generate_docstrings(config_loader, loop, args.ignore_list)
            what_has_been_done.mark_did("docstring")

        # License compiling
        if license_type := plan.get("ensure_license"):
            rich_section("License generation")
            compile_license_file(sourcerank, license_type, git_agent.metadata)
            what_has_been_done.mark_did("ensure_license")

        # Generate community documentation
        if plan.get("community_docs"):
            rich_section("Community docs generation")
            generate_documentation(config_loader, git_agent.metadata)
            what_has_been_done.mark_did("community_docs")

        # Requirements generation
        if plan.get("requirements"):
            rich_section("Requirements generation")
            generate_requirements(args.repository)
            what_has_been_done.mark_did("requirements")

        # Readme generation
        if plan.get("readme"):
            rich_section("README generation")
            readme_agent = ReadmeAgent(
                config_loader, prompts, plan.get("attachment"), plan.get("refine_readme"), git_agent.metadata
            )
            readme_agent.generate_readme()
            what_has_been_done.mark_did("readme")

        # Readme translation
        translate_readme = plan.get("translate_readme")
        if translate_readme:
            rich_section("README translation")
            ReadmeTranslator(config_loader, prompts, git_agent.metadata, translate_readme).translate_readme()
            what_has_been_done.mark_did("translate_readme")

        # About section generation
        about_gen = None
        if plan.get("about"):
            rich_section("About Section generation")
            about_gen = AboutGenerator(config_loader, prompts, git_agent)
            about_gen.generate_about_content()
            if create_fork:
                git_agent.update_about_section(about_gen.get_about_content())
            if not create_pull_request:
                logger.info("About section:\n" + about_gen.get_about_section_message())
            what_has_been_done.mark_did("about")

        # Generate platform-specified CI/CD files
        if plan.get("generate_workflows"):
            rich_section("Workflows generation")
            workflow_manager.update_workflow_config(config_loader, plan)
            workflow_manager.generate_workflow(config_loader)
            what_has_been_done.mark_did("generate_workflows")

        # Organize repository by adding 'tests' and 'examples' directories if they aren't exist
        if plan.get("organize"):
            rich_section("Repository organization")
            organizer = RepoOrganizer(os.path.join(os.getcwd(), parse_folder_name(args.repository)))
            organizer.organize()
            what_has_been_done.mark_did("organize")

        if create_fork and create_pull_request:
            rich_section("Publishing changes")
            if git_agent.commit_and_push_changes(force=True):
                git_agent.create_pull_request(body=about_gen.get_about_section_message() if about_gen else "")
            else:
                logger.warning("No changes were committed — pull request will not be created.")
                if about_gen:
                    logger.info("About section:\n" + about_gen.get_about_section_message())

        if plan.get("delete_dir"):
            rich_section("Repository deletion")
            delete_repository(args.repository)
            what_has_been_done.mark_did("delete_dir")

        new_source_rank = SourceRank(config_loader)
        WhatHasBeenDoneReportGenerator(
            config_loader, new_source_rank, what_has_been_done.list_for_report, git_agent.metadata
        ).build_pdf()

        elapsed_time = time.time() - start_time
        rich_section(f"All operations completed successfully in total time: {format_time(elapsed_time)}")
        sys.exit(0)

    except Exception as e:
        logger.error("Error: %s", e, exc_info=False if args.web_mode else True)
        sys.exit(1)

    finally:
        loop.close()


def initialize_git_platform(args):
    if "github.com" in args.repository:
        git_agent = GitHubAgent(args.repository, args.branch, author=args.author)
        workflow_manager = GitHubWorkflowManager(args.repository, git_agent.metadata, args)
    elif "gitlab." in args.repository:
        git_agent = GitLabAgent(args.repository, args.branch, author=args.author)
        workflow_manager = GitLabWorkflowManager(args.repository, git_agent.metadata, args)
    elif "gitverse.ru" in args.repository:
        git_agent = GitverseAgent(args.repository, args.branch, author=args.author)
        workflow_manager = GitverseWorkflowManager(args.repository, git_agent.metadata, args)
    else:
        raise ValueError(f"Cannot initialize Git Agent and Workflow Manager for this platform: {args.repository}")

    return git_agent, workflow_manager


def convert_notebooks(repo_url: str, notebook_paths: list[str] | None = None) -> None:
    """Converts Jupyter notebooks to Python scripts based on provided paths.

    Args:
        repo_url: Repository url.
        notebook_paths: A list of paths to the notebooks to be converted (or None).
                        If empty, the converter will process the current repository.
    """
    try:
        converter = NotebookConverter()
        if len(notebook_paths) == 0:
            converter.process_path(os.path.basename(repo_url))
        else:
            for path in notebook_paths:
                converter.process_path(path)

    except Exception as e:
        logger.error("Error while converting notebooks: %s", repr(e), exc_info=True)


def generate_requirements(repo_url):
    logger.info(f"Starting the generation of requirements")
    repo_path = Path(parse_folder_name(repo_url)).resolve()
    try:
        result = subprocess.run(
            ["pipreqs", "--scan-notebooks", "--force", "--encoding", "utf-8", repo_path],
            capture_output=True,
            text=True,
            check=True,
        )
        logger.info(f"Requirements generated successfully at: {repo_path}")
        logger.debug(result)
    except subprocess.CalledProcessError as e:
        logger.error(f"Error while generating project's requirements: {e.stderr}")


def generate_docstrings(config_loader: ConfigLoader, loop: asyncio.AbstractEventLoop, ignore_list: list[str]) -> None:
    """Generates a docstrings for .py's classes and methods of the provided repository.

    Args:
        config_loader: The configuration object which contains settings for osa_tool.
        loop: Link to the event loop in the main thread.
    """

    sem = asyncio.Semaphore(100)
    workers = multiprocessing.cpu_count()
    repo_url = config_loader.config.git.repository
    repo_path = parse_folder_name(repo_url)

    try:
        rate_limit = config_loader.config.llm.rate_limit
        ts = OSA_TreeSitter(repo_path, ignore_list)
        res = ts.analyze_directory(ts.cwd)
        dg = DocGen(config_loader)

        # getting the project source code and start generating docstrings
        source_code = loop.run_until_complete(dg._get_project_source_code(res, sem))

        # first stage
        # generate for functions and methods first
        fn_generated_docstrings = loop.run_until_complete(
            dg._generate_docstrings_for_items(res, docstring_type=("functions", "methods"), rate_limit=rate_limit)
        )
        fn_augmented = dg._run_in_executor(
            res, source_code, generated_docstrings=fn_generated_docstrings, n_workers=workers
        )
        loop.run_until_complete(dg._write_augmented_code(res, augmented_code=fn_augmented, sem=sem))

        # re-analyze project after docstrings writing
        res = ts.analyze_directory(ts.cwd)
        source_code = loop.run_until_complete(dg._get_project_source_code(ts.analyze_directory(ts.cwd), sem))

        # then generate description for classes based on filled methods docstrings
        cl_generated_docstrings = loop.run_until_complete(
            dg._generate_docstrings_for_items(res, docstring_type="classes", rate_limit=rate_limit)
        )
        cl_augmented = dg._run_in_executor(
            res, source_code, generated_docstrings=cl_generated_docstrings, n_workers=workers
        )
        loop.run_until_complete(dg._write_augmented_code(res, augmented_code=cl_augmented, sem=sem))

        # generate the main idea
        loop.run_until_complete(dg.generate_the_main_idea(res))

        # re-analyze project and read augmented source code
        res = ts.analyze_directory(ts.cwd)
        source_code = loop.run_until_complete(dg._get_project_source_code(res, sem))

        # update docstrings for project based on generated main idea
        generated_after_idea = loop.run_until_complete(
            dg._generate_docstrings_for_items(
                res, docstring_type=("functions", "methods", "classes"), rate_limit=rate_limit
            )
        )

        # augment the source code and persist it
        augmented_after_idea = dg._run_in_executor(res, source_code, generated_after_idea, workers)
        loop.run_until_complete(dg._write_augmented_code(res, augmented_after_idea, sem))

        modules_summaries = loop.run_until_complete(dg.summarize_submodules(res, rate_limit))
        dg.generate_documentation_mkdocs(repo_path, res, modules_summaries)
        dg.create_mkdocs_git_workflow(repo_url, repo_path)

    except Exception as e:
        dg._purge_temp_files(repo_path)
        logger.error("Error while generating codebase documentation: %s", repr(e), exc_info=True)


def load_configuration(args: argparse.Namespace) -> ConfigLoader:
    """
    Load and update the osa_tool configuration using command-line arguments.

    This function takes the parsed command-line arguments (argparse.Namespace)
    generated from `build_parser_from_yaml` and updates the global configuration
    object (`ConfigLoader`) accordingly.

    It validates the provided repository URL via `GitSettings` and applies all
    LLM-related settings such as model name, API provider, temperature, max tokens,
    and other model parameters.

    Args:
        args (argparse.Namespace):
            Parsed arguments returned by `parser.parse_args()`. It must contain:
                - args.repository    : URL of the repository to analyze
                - args.api           : LLM API provider name
                - args.base_url      : Base URL of an OpenAI-compatible API
                - args.model         : LLM model name
                - args.temperature   : Sampling temperature
                - args.max_tokens    : Maximum number of output tokens
                - args.context_window: Total context window size
                - args.top_p         : Nucleus sampling parameter
                - args.max_retries   : Maximum retry attempts for LLM API calls

    Returns:
        ConfigLoader:
            The updated configuration object ready to be used by osa_tool.

    Raises:
        ValueError:
            If the repository URL fails validation inside `GitSettings`.
    """
    config_loader = ConfigLoader()

    try:
        config_loader.config.git = GitSettings(repository=args.repository)
    except ValidationError as es:
        first_error = es.errors()[0]
        raise ValueError(f"{first_error['msg']}{first_error['input']}")
    config_loader.config.llm = config_loader.config.llm.model_copy(
        update={
            "api": args.api,
            "base_url": args.base_url,
            "model": args.model,
            "temperature": args.temperature,
            "max_tokens": args.max_tokens,
            "context_window": args.context_window,
            "top_p": args.top_p,
            "max_retries": args.max_retries,
        }
    )
    logger.info("Config successfully updated and loaded")
    return config_loader


if __name__ == "__main__":
    main()
