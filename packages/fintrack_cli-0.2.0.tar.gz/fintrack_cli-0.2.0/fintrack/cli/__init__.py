"""CLI commands for FinTrack."""
