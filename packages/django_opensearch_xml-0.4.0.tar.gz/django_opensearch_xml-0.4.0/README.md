# OpenSearch application for django

This application provide a way to integrate the [OpenSearch](https://developer.mozilla.org/en-US/docs/Web/OpenSearch)
XML file to a django application.

[[_TOC_]]

## Installation

Install the package `pip install django-opensearch-xml`

## Configuration

+ Add "opensearch_xml" to settings.INSTALLED_APPS.
  ```python
  INSTALLED_APPS = [
    ...,
    "opensearch_xml",
    ...
  ]
  ```
+ Add "opensearch_xml" to URLS
  ```python
  from django.urls import path, include


  urlpatterns = [
    ...,
    path("opensearch/", include("opensearch_xml.urls")),
    ...
  ]
  ```

In the base template add the template tag that renders the `search` link

```html
{% load opensearch_xml %}
<!DOCTYPE html>
<html lang="en" class="no-js" {{ html_attr|safe }}>
<head>
    ..
    {% opensearch_xml %}
</head>
<body>
...
</body>
</html>
```

## Settings

Add OPENSEARCH_XML_\<params\> to the application settings

`OPENSEARCH_XML_CONTACT_EMAIL = ""`
: Email address of the maintainer the application

`OPENSEARCH_XML_SHORT_NAME = ""`
: Brief human-readable name of the search engine</dd>

`OPENSEARCH_XML_DESCRIPTION = ""`
: Human-readable description of the search engine and its contents - **REQUIRED**

`OPENSEARCH_XML_FAVICON_WIDTH = 16`
: Width of the favicon

`OPENSEARCH_XML_FAVICON_HEIGHT = 16`
: Height of the favicon

`OPENSEARCH_XML_FAVICON_TYPE = "image/x-icon"`
: Type of the icon

`OPENSEARCH_XML_FAVICON_FILE = ""`
: File on the favicon, relative to the path referenced in STATIC_PATH


`OPENSEARCH_XML_SEARCH_URL = "search"`
: Django URL name of the search. This URL will be passed to the `reverse()` function

`OPENSEARCH_XML_SEARCH_QUERYSTRING = "q="`
: Querystring used to prepend the search parameters

`OPENSEARCH_XML_INPUT_ENCODING = "UTF-8"`
: Encoding for the querystring

## Usage

Add the template tag `{% opensearch_xml_meta %}` into the page `<head>`.

```html
{% load opensearch_xml_tags %}
<html lang="en">
<head>
    <title>My title</title>
    ...
    {% opensearch_xml_meta %}
</head>
<body>
...
</body>
</html>
```
