AI Detection & Response Python-based SDK for monitoring agent workflows, language model execution, tool calls, and relevant data sources.

## Features

- **Automatic tracing**: Works with any language model provider (OpenAI, Anthropic, custom)
- **Zero code changes**: Just initialize and go
- **Comprehensive telemetry**: Tracks tools, models, prompts, reasoning
- **Simple API**: 2 lines of code

## Supported Frameworks

- OpenAI SDK
- Anthropic SDK
- Google (Gemini) SDK
- AWS Bedrock SDK
- Azure Foundry SDK
- LiteLLM SDK
- LangChain

## Installation

```bash
pip install evoke-sdk
```

## Quick Start

```python
import evoke

# Initialize once at startup
evoke.init(api_key="evoke_pk_your_api_key")

# All LLM calls are now automatically traced!
from openai import OpenAI
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## What Gets Tracked

- **Models**: Which models were used (gpt-4, claude-3, etc.)
- **Prompts & Responses**: Full input and output data
- **Tools**: Which tools/functions were called
- **Data Sources**: Which vector stores/retrievers were accessed
- **Tokens**: Input/output/cached token counts
- **Timing**: Duration and timestamps
- **Errors**: Exceptions and stack traces

## Optional: Explicit Tracing

Use the `@guard` decorator for high-level workflows:

```python
@evoke.guard(name="customer_support_agent")
def handle_customer_query(query: str):
    # Your agent logic
    return agent.run(query)
```

## Optional: Add Custom Context

Link custom business values to track custom events and create custom detections:

```python
@evoke.guard(name="process_order")
def process_order(order_id: str, user_id: str):
    evoke.add_context(
        user_id=user_id,
        order_id=order_id,
        environment="production"
    )
    return process()
```

## Flush Before Exit

Ensure all data is sent before your app exits:

```python
# At the end of your script
evoke.flush()
```