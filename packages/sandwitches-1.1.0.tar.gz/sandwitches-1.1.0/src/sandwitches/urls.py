"""
URL configuration for sandwitches project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.contrib import admin
from django.urls import path
from . import views
from .api import api


from django.conf import settings
from django.conf.urls.static import static
from debug_toolbar.toolbar import debug_toolbar_urls
import os
import sys


urlpatterns = [
    path("", views.index, name="index"),
    path("admin/", admin.site.urls),
    path("recipes/<slug:slug>/", views.recipe_detail, name="recipe_detail"),
    path("setup/", views.setup, name="setup"),
    path("api/", api.urls),
    path("signup/", views.signup, name="signup"),
    path("recipes/<int:pk>/rate/", views.recipe_rate, name="recipe_rate"),
]

if "test" not in sys.argv or "PYTEST_VERSION" in os.environ:
    from debug_toolbar.toolbar import debug_toolbar_urls

    urlpatterns = [
        *urlpatterns,
    ] + debug_toolbar_urls()


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
