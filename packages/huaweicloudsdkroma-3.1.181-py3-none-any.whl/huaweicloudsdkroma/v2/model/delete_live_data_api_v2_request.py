# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteLiveDataApiV2Request:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'ld_api_id': 'str'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'ld_api_id': 'ld_api_id'
    }

    def __init__(self, instance_id=None, ld_api_id=None):
        r"""DeleteLiveDataApiV2Request

        The model defined in huaweicloud sdk

        :param instance_id: 实例ID
        :type instance_id: str
        :param ld_api_id: 后端API的编号
        :type ld_api_id: str
        """
        
        

        self._instance_id = None
        self._ld_api_id = None
        self.discriminator = None

        self.instance_id = instance_id
        self.ld_api_id = ld_api_id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this DeleteLiveDataApiV2Request.

        实例ID

        :return: The instance_id of this DeleteLiveDataApiV2Request.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this DeleteLiveDataApiV2Request.

        实例ID

        :param instance_id: The instance_id of this DeleteLiveDataApiV2Request.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def ld_api_id(self):
        r"""Gets the ld_api_id of this DeleteLiveDataApiV2Request.

        后端API的编号

        :return: The ld_api_id of this DeleteLiveDataApiV2Request.
        :rtype: str
        """
        return self._ld_api_id

    @ld_api_id.setter
    def ld_api_id(self, ld_api_id):
        r"""Sets the ld_api_id of this DeleteLiveDataApiV2Request.

        后端API的编号

        :param ld_api_id: The ld_api_id of this DeleteLiveDataApiV2Request.
        :type ld_api_id: str
        """
        self._ld_api_id = ld_api_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteLiveDataApiV2Request):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
