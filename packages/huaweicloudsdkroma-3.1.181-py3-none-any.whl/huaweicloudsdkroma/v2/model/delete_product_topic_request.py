# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteProductTopicRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'product_id': 'int',
        'topic_id': 'int'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'product_id': 'product_id',
        'topic_id': 'topic_id'
    }

    def __init__(self, instance_id=None, product_id=None, topic_id=None):
        r"""DeleteProductTopicRequest

        The model defined in huaweicloud sdk

        :param instance_id: 实例ID
        :type instance_id: str
        :param product_id: 产品ID
        :type product_id: int
        :param topic_id: 产品主题ID
        :type topic_id: int
        """
        
        

        self._instance_id = None
        self._product_id = None
        self._topic_id = None
        self.discriminator = None

        self.instance_id = instance_id
        self.product_id = product_id
        self.topic_id = topic_id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this DeleteProductTopicRequest.

        实例ID

        :return: The instance_id of this DeleteProductTopicRequest.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this DeleteProductTopicRequest.

        实例ID

        :param instance_id: The instance_id of this DeleteProductTopicRequest.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def product_id(self):
        r"""Gets the product_id of this DeleteProductTopicRequest.

        产品ID

        :return: The product_id of this DeleteProductTopicRequest.
        :rtype: int
        """
        return self._product_id

    @product_id.setter
    def product_id(self, product_id):
        r"""Sets the product_id of this DeleteProductTopicRequest.

        产品ID

        :param product_id: The product_id of this DeleteProductTopicRequest.
        :type product_id: int
        """
        self._product_id = product_id

    @property
    def topic_id(self):
        r"""Gets the topic_id of this DeleteProductTopicRequest.

        产品主题ID

        :return: The topic_id of this DeleteProductTopicRequest.
        :rtype: int
        """
        return self._topic_id

    @topic_id.setter
    def topic_id(self, topic_id):
        r"""Sets the topic_id of this DeleteProductTopicRequest.

        产品主题ID

        :param topic_id: The topic_id of this DeleteProductTopicRequest.
        :type topic_id: int
        """
        self._topic_id = topic_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteProductTopicRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
