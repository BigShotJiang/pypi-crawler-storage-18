"""
hello-one-two - A useful Python package
"""

def hello_world():
    """A simple greeting function"""
    return "Hello from hello-one-two!"

def add_numbers(a, b):
    """Add two numbers together"""
    return a + b

def get_package_info():
    """Return basic package information"""
    return {
        "name": "hello-one-two",
        "version": "2.3.2",
        "description": "A useful Python package"
    }

# Package version
__version__ = "2.3.2"
