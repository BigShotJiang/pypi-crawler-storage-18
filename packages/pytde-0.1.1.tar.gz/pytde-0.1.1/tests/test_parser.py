"""
Tests for TDE (Tableau Data Extract) file parser.
"""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path

from pytde import (
    TDEParser,
    read_tde,
    read_tde_metadata,
    TDE_MAGIC,
    DATA_BLOCK_MARKER,
    INDEX_BLOCK_MARKER,
)


# Test file paths
TEST_DATA_DIR = Path(__file__).parent
SALES_PLANNING_FILE = TEST_DATA_DIR / "Sales Planning newleaf.tde"


@pytest.fixture
def sales_planning_path():
    """Path to the Sales Planning TDE file."""
    if not SALES_PLANNING_FILE.exists():
        pytest.skip(f"Test file not found: {SALES_PLANNING_FILE}")
    return str(SALES_PLANNING_FILE)


class TestConstants:
    """Test TDE format constants."""

    def test_magic_bytes_length(self):
        assert len(TDE_MAGIC) == 8

    def test_magic_bytes_value(self):
        expected = bytes([0x20, 0x02, 0x01, 0x62, 0xa0, 0x1e, 0xab, 0x07])
        assert TDE_MAGIC == expected

    def test_data_block_marker(self):
        expected = bytes([0xf0, 0xca, 0x12, 0x78])
        assert DATA_BLOCK_MARKER == expected

    def test_index_block_marker(self):
        expected = bytes([0xf1, 0xca, 0x12, 0x78])
        assert INDEX_BLOCK_MARKER == expected


class TestTDEParserHeader:
    """Test TDE header parsing."""

    def test_read_header_valid_file(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)
        with open(sales_planning_path, 'rb') as f:
            parser.content = f.read()

        header = parser._read_header()

        assert header.magic == TDE_MAGIC
        assert header.format_version == 2
        assert header.file_size == 51306
        assert header.root_index_offset > 0

    def test_read_header_invalid_magic(self, tmp_path):
        # Create a file with invalid magic bytes
        invalid_file = tmp_path / "invalid.tde"
        invalid_file.write_bytes(b'\x00' * 100)

        parser = TDEParser(str(invalid_file))
        with open(str(invalid_file), 'rb') as f:
            parser.content = f.read()

        with pytest.raises(ValueError, match="Invalid TDE file"):
            parser._read_header()


class TestTDEParserXML:
    """Test XML metadata extraction."""

    def test_read_xml_metadata(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)
        with open(sales_planning_path, 'rb') as f:
            parser.content = f.read()

        xml = parser._read_xml_metadata()

        assert xml.startswith('<?xml')
        assert '</datasource>' in xml
        assert 'Extract' in xml


class TestTDEParserBlocks:
    """Test block parsing functionality."""

    def test_get_block_info(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)
        with open(sales_planning_path, 'rb') as f:
            parser.content = f.read()

        # Find first data block
        pos = parser.content.find(DATA_BLOCK_MARKER)
        assert pos > 0

        block = parser._get_block_info(pos)

        assert block is not None
        assert block.file_pos == pos
        assert block.data_offset == pos + 32
        assert block.size > 0

    def test_read_block_data(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)
        with open(sales_planning_path, 'rb') as f:
            parser.content = f.read()

        # Find first data block
        pos = parser.content.find(DATA_BLOCK_MARKER)
        data = parser._read_block_data(pos)

        assert data is not None
        assert len(data) > 0


class TestTDEParserStringDictionary:
    """Test string dictionary reading."""

    def test_read_string_dictionary(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)

        # Test with known data: "Central", "East", "West"
        # Format: 4-byte length + UTF-8 string
        test_data = (
            b'\x07\x00\x00\x00Central'
            b'\x04\x00\x00\x00East'
            b'\x04\x00\x00\x00West'
        )

        strings = parser._read_string_dictionary(test_data)

        assert len(strings) == 3
        assert strings[0] == 'Central'
        assert strings[1] == 'East'
        assert strings[2] == 'West'

    def test_read_string_dictionary_empty(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)
        strings = parser._read_string_dictionary(b'')
        assert strings == []


class TestTDEParserNumeric:
    """Test numeric data reading."""

    def test_read_doubles(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)

        # Test with known double values
        import struct
        test_data = struct.pack('<d', 74813.94) + struct.pack('<d', 188411.22)

        doubles = parser._read_doubles(test_data)

        assert len(doubles) == 2
        assert abs(doubles[0] - 74813.94) < 0.01
        assert abs(doubles[1] - 188411.22) < 0.01

    def test_read_doubles_empty(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)
        doubles = parser._read_doubles(b'')
        assert doubles == []

    def test_read_integers(self, sales_planning_path):
        parser = TDEParser(sales_planning_path)

        import struct
        test_data = struct.pack('<q', 100) + struct.pack('<q', 200)

        integers = parser._read_integers(test_data, size=8)

        assert len(integers) == 2
        assert integers[0] == 100
        assert integers[1] == 200


class TestReadTDE:
    """Test the main read_tde function."""

    def test_read_tde_sales_planning(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 43
        assert 'Sales' in df.columns

    def test_read_tde_sales_columns(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        expected_columns = {'Region', 'Sales', 'Sales Person'}
        assert set(df.columns) == expected_columns

    def test_read_tde_sales_total(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        total_sales = df['Sales'].sum()
        expected_total = 15602877.08

        assert abs(total_sales - expected_total) < 0.01

    def test_read_tde_sales_data_types(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        assert df['Sales'].dtype == np.float64
        assert df['Region'].dtype == object
        assert df['Sales Person'].dtype == object


class TestReadTDEMetadata:
    """Test the read_tde_metadata function."""

    def test_metadata_file_path(self, sales_planning_path):
        metadata = read_tde_metadata(sales_planning_path)
        assert metadata['file_path'] == sales_planning_path

    def test_metadata_format_version(self, sales_planning_path):
        metadata = read_tde_metadata(sales_planning_path)
        assert metadata['format_version'] == 2

    def test_metadata_file_size(self, sales_planning_path):
        metadata = read_tde_metadata(sales_planning_path)
        assert metadata['file_size'] == 51306

    def test_metadata_columns(self, sales_planning_path):
        metadata = read_tde_metadata(sales_planning_path)

        assert 'columns' in metadata
        assert 'Sales' in metadata['columns']

    def test_metadata_column_types(self, sales_planning_path):
        metadata = read_tde_metadata(sales_planning_path)

        assert 'column_types' in metadata
        assert metadata['column_types']['Sales'] == 'double'

    def test_metadata_xml(self, sales_planning_path):
        metadata = read_tde_metadata(sales_planning_path)

        assert 'xml_metadata' in metadata
        assert metadata['xml_metadata'].startswith('<?xml')


class TestTDEParserEdgeCases:
    """Test edge cases and error handling."""

    def test_nonexistent_file(self):
        with pytest.raises(FileNotFoundError):
            read_tde('/nonexistent/path/file.tde')

    def test_empty_dataframe_on_no_data(self, tmp_path):
        # Create a minimal valid TDE file with just header
        # This should return empty DataFrame
        minimal_file = tmp_path / "minimal.tde"

        # Write magic + minimal header
        content = TDE_MAGIC + b'\x02\x00\x00\x00' + b'\x00' * 100
        minimal_file.write_bytes(content)

        # Parser should handle gracefully
        parser = TDEParser(str(minimal_file))
        try:
            df = parser.parse()
            # Should either raise or return empty DataFrame
            assert isinstance(df, pd.DataFrame)
        except (ValueError, IndexError):
            # Expected for malformed file
            pass


class TestDataFrameIntegrity:
    """Test DataFrame integrity and consistency."""

    def test_no_missing_values_in_sales(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        # Sales column should have no NaN values
        assert df['Sales'].notna().all()

    def test_sales_values_positive(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        assert (df['Sales'] > 0).all()

    def test_all_columns_same_length(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        lengths = [len(df[col].dropna()) for col in df.columns]
        # All columns should have data
        assert all(length > 0 for length in lengths)

    def test_unique_regions(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        unique_regions = df['Region'].unique()
        expected_regions = {'Central', 'East', 'West'}

        assert set(unique_regions) == expected_regions

    def test_sales_statistics(self, sales_planning_path):
        df = read_tde(sales_planning_path)

        # Verify basic statistics
        assert df['Sales'].min() > 10000
        assert df['Sales'].max() < 2000000
        assert 300000 < df['Sales'].mean() < 400000


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
