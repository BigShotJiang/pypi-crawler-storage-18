# Pyarmor 9.2.0 (basic), 009672, 2025-12-25T15:27:59.579995
from .pyarmor_runtime import __pyarmor__
