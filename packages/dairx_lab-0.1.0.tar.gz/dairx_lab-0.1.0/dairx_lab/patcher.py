"""
DAIRX Labs - Framework Patchers
Monkey-patch PyTorch & TensorFlow to auto-capture metrics
"""

import sys
import time
from typing import Any, Optional


class PyTorchPatcher:
    """Auto-patch PyTorch training loops"""
    
    def __init__(self, tracker: Any):
        """
        Initialize patcher
        
        Args:
            tracker: Parent Tracker instance
        """
        self.tracker = tracker
        self.original_backward = None
        self.step_count = 0
        self.last_log_time = time.time()
        
    def patch(self):
        """Monkey-patch PyTorch"""
        try:
            import torch
            
            # Patch Tensor.backward()
            self.original_backward = torch.Tensor.backward
            
            # Create a closure that captures self
            patcher_instance = self
            
            def _tracked_backward(tensor_self, *args, **kwargs):
                """Wrapped backward() that captures metrics"""
                # Call original backward
                result = patcher_instance.original_backward(tensor_self, *args, **kwargs)
                
                # Increment step
                patcher_instance.step_count += 1
                
                # Log every 10 steps (configurable)
                if patcher_instance.step_count % 10 == 0:
                    patcher_instance._capture_metrics(tensor_self)
                
                return result
            
            torch.Tensor.backward = _tracked_backward
            
            print("[DAIRX] PyTorch auto-tracking enabled")
            
        except ImportError:
            pass
    
    def _legacy_tracked_backward(self, tensor, *args, **kwargs):
        """Legacy method - not used anymore"""
        # Call original backward
        if self.original_backward:
            result = self.original_backward(tensor, *args, **kwargs)
        
        # Increment step
        self.step_count += 1
        
        # Log every 10 steps (configurable)
        if self.step_count % 10 == 0:
            self._capture_metrics(tensor)
        
        return result if self.original_backward else None
    
    def _capture_metrics(self, loss_tensor):
        """Capture and send metrics"""
        try:
            import torch
            
            # Extract loss value
            loss_value = None
            if hasattr(loss_tensor, 'item'):
                loss_value = loss_tensor.item()
            
            # Get GPU metrics
            gpu_util = None
            gpu_memory = None
            gpu_temp = None
            
            if torch.cuda.is_available():
                try:
                    import pynvml
                    pynvml.nvmlInit()
                    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                    gpu_util = pynvml.nvmlDeviceGetUtilizationRates(handle).gpu
                    mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                    gpu_memory = mem_info.used / (1024**3)  # GB
                    gpu_temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                except:
                    pass
            
            # Prepare metrics
            metrics = {
                'loss': loss_value,
                'gpuUtilization': gpu_util,
                'gpuMemoryUsed': gpu_memory,
                'gpuTemperature': gpu_temp,
            }
            
            # Remove None values
            metrics = {k: v for k, v in metrics.items() if v is not None}
            
            # Log to DAIRX
            if metrics:
                self.tracker.log_metrics(metrics, step=self.step_count)
            
        except Exception as e:
            # Silent fail - don't break user's training
            pass


class TensorFlowPatcher:
    """Auto-patch TensorFlow training loops"""
    
    def __init__(self, tracker: Any):
        """
        Initialize patcher
        
        Args:
            tracker: Parent Tracker instance
        """
        self.tracker = tracker
        self.step_count = 0
    
    def patch(self):
        """Monkey-patch TensorFlow"""
        try:
            import tensorflow as tf
            
            # Create custom callback
            class DairxCallback(tf.keras.callbacks.Callback):
                def __init__(self, tracker, patcher):
                    super().__init__()
                    self.tracker = tracker
                    self.patcher = patcher
                
                def on_epoch_end(self, epoch, logs=None):
                    """Called at end of each epoch"""
                    logs = logs or {}
                    
                    metrics = {
                        'loss': logs.get('loss'),
                        'accuracy': logs.get('accuracy'),
                        'validationLoss': logs.get('val_loss'),
                        'validationAcc': logs.get('val_accuracy'),
                    }
                    
                    # Remove None values
                    metrics = {k: v for k, v in metrics.items() if v is not None}
                    
                    if metrics:
                        self.tracker.log_metrics(metrics, epoch=epoch)
                
                def on_batch_end(self, batch, logs=None):
                    """Called at end of each batch"""
                    self.patcher.step_count += 1
                    
                    # Log every 50 batches
                    if self.patcher.step_count % 50 == 0:
                        logs = logs or {}
                        metrics = {
                            'loss': logs.get('loss'),
                            'accuracy': logs.get('accuracy'),
                        }
                        metrics = {k: v for k, v in metrics.items() if v is not None}
                        
                        if metrics:
                            self.tracker.log_metrics(metrics, step=self.patcher.step_count)
            
            # Store callback for user to access
            self.callback = DairxCallback(self.tracker, self)
            
            # Patch Model.fit()
            original_fit = tf.keras.Model.fit
            
            def tracked_fit(model_self, *args, **kwargs):
                """Wrapped fit() that adds DAIRX callback"""
                callbacks = kwargs.get('callbacks', [])
                if not isinstance(callbacks, list):
                    callbacks = [callbacks]
                
                # Add DAIRX callback
                callbacks.append(self.callback)
                kwargs['callbacks'] = callbacks
                
                return original_fit(model_self, *args, **kwargs)
            
            tf.keras.Model.fit = tracked_fit
            
            print("[DAIRX] TensorFlow auto-tracking enabled")
            
        except ImportError:
            pass


class JAXPatcher:
    """Auto-patch JAX training loops (Phase 2)"""
    
    def __init__(self, tracker: Any):
        self.tracker = tracker
    
    def patch(self):
        """Monkey-patch JAX (TODO: Phase 2)"""
        print("[DAIRX] JAX auto-tracking coming soon...")
