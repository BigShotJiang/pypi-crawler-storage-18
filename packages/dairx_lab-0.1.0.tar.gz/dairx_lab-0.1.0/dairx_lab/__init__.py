"""
DAIRX Labs - Python SDK
The ONE-LINE magic that creates the moat

Usage:
    from dairx_lab import track
    track()  # That's it!
"""

__version__ = "0.1.0"

from .tracker import track, Tracker
from .client import DairxLabClient

__all__ = ['track', 'Tracker', 'DairxLabClient']
