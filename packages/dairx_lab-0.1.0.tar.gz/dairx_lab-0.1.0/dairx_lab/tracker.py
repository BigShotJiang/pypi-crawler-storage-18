"""
DAIRX Labs - Main Tracker
Auto-detects framework and monkey-patches training loop
"""

import os
import sys
import time
import threading
from typing import Optional, Dict, Any

from .client import DairxLabClient
from .patcher import PyTorchPatcher, TensorFlowPatcher


class Tracker:
    """Main experiment tracker"""
    
    def __init__(
        self, 
        api_key: Optional[str] = None,
        experiment_name: Optional[str] = None,
        api_url: str = "https://dairx.com"
    ):
        """
        Initialize DAIRX Labs tracker
        
        Args:
            api_key: DAIRX API key (or set DAIRX_API_KEY env var)
            experiment_name: Name for this experiment (auto-generated if not provided)
            api_url: DAIRX API URL
        """
        self.api_key = api_key or os.getenv('DAIRX_API_KEY')
        if not self.api_key:
            raise ValueError(
                "DAIRX API key required. Get yours at https://dairx.com/dashboard\n"
                "Set it via: export DAIRX_API_KEY='your_key_here'\n"
                "Or pass it: track(api_key='your_key')"
            )
        
        self.client = DairxLabClient(api_key=self.api_key, api_url=api_url)
        self.experiment_name = experiment_name or self._generate_name()
        self.experiment_id: Optional[str] = None
        self.framework: Optional[str] = None
        self.patcher: Optional[Any] = None
        self._metrics_buffer: list = []
        self._lock = threading.Lock()
        
    def _generate_name(self) -> str:
        """Generate experiment name from script name + timestamp"""
        script_name = os.path.basename(sys.argv[0]).replace('.py', '')
        timestamp = time.strftime('%Y%m%d_%H%M%S')
        return f"{script_name}_{timestamp}"
    
    def _detect_framework(self) -> str:
        """Auto-detect ML framework"""
        if 'torch' in sys.modules:
            return 'pytorch'
        elif 'tensorflow' in sys.modules:
            return 'tensorflow'
        elif 'jax' in sys.modules:
            return 'jax'
        else:
            return 'other'
    
    def _detect_instance_id(self) -> Optional[str]:
        """Auto-detect DAIRX instance ID from environment"""
        # DAIRX injects this env var when launching instances
        return os.getenv('DAIRX_INSTANCE_ID')
    
    def _detect_gpu_type(self) -> str:
        """Auto-detect GPU type"""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            name = pynvml.nvmlDeviceGetName(handle)
            if isinstance(name, bytes):
                name = name.decode('utf-8')
            return name
        except:
            return 'Unknown'
    
    def start(self, **kwargs):
        """Start tracking experiment"""
        self.framework = self._detect_framework()
        
        # Auto-detect instance ID and GPU if on DAIRX
        instance_id = kwargs.get('instance_id') or self._detect_instance_id()
        gpu_type = kwargs.get('gpu_type') or self._detect_gpu_type()
        
        # Create experiment on DAIRX
        experiment_data = {
            'name': self.experiment_name,
            'framework': self.framework,
            'gpuType': gpu_type,
            'costPerHour': kwargs.get('cost_per_hour', 0),
            'instanceId': instance_id,  # Link to DAIRX instance for cost tracking
            **kwargs
        }
        
        response = self.client.create_experiment(experiment_data)
        if response and 'experiment' in response:
            self.experiment_id = response['experiment']['id']
            print(f"[DAIRX] Tracking experiment: {self.experiment_name}")
            print(f"[DAIRX] View at: https://dairx.com/dashboard/lab?id={self.experiment_id}")
        
        # Monkey-patch framework
        if self.framework == 'pytorch':
            self.patcher = PyTorchPatcher(self)
            self.patcher.patch()
        elif self.framework == 'tensorflow':
            self.patcher = TensorFlowPatcher(self)
            self.patcher.patch()
        
        return self
    
    def log_metrics(self, metrics: Dict[str, Any], step: Optional[int] = None, epoch: Optional[int] = None):
        """
        Log training metrics
        
        Args:
            metrics: Dictionary of metrics (loss, accuracy, etc.)
            step: Training step/iteration
            epoch: Training epoch
        """
        if not self.experiment_id:
            print("[DAIRX] Warning: Experiment not started. Call track() first.")
            return
        
        # Prepare payload
        payload = {
            'experimentId': self.experiment_id,
            'apiKey': self.api_key,
            'step': step,
            'epoch': epoch,
            **metrics
        }
        
        # Send to DAIRX (async to avoid blocking training)
        threading.Thread(
            target=self.client.ingest_metric,
            args=(payload,),
            daemon=True
        ).start()
    
    def checkpoint(self, path: str, epoch: int, step: int, metrics: Optional[Dict] = None):
        """Save checkpoint metadata"""
        if not self.experiment_id:
            return
        
        checkpoint_data = {
            'experimentId': self.experiment_id,
            'epoch': epoch,
            'step': step,
            'checkpointPath': path,
            'metrics': metrics or {}
        }
        
        # TODO: Send to checkpoint API
        print(f"[DAIRX] Checkpoint saved: {path}")
    
    def finish(self, status: str = 'COMPLETED'):
        """Mark experiment as completed"""
        if not self.experiment_id:
            return
        
        # TODO: Update experiment status
        print(f"[DAIRX] Experiment finished: {status}")


# Global singleton
_global_tracker: Optional[Tracker] = None


def track(
    api_key: Optional[str] = None,
    experiment_name: Optional[str] = None,
    **kwargs
) -> Tracker:
    """
    The ONE-LINE magic function
    
    Usage:
        from dairx_lab import track
        track()  # Start tracking immediately
    
    Args:
        api_key: DAIRX API key (optional if set in env)
        experiment_name: Custom experiment name (optional)
        **kwargs: Additional experiment configuration
    
    Returns:
        Tracker instance
    """
    global _global_tracker
    
    if _global_tracker is None:
        _global_tracker = Tracker(
            api_key=api_key,
            experiment_name=experiment_name
        )
        _global_tracker.start(**kwargs)
    
    return _global_tracker
