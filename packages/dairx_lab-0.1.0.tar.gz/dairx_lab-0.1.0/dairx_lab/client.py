"""
DAIRX Labs - HTTP Client
Handles communication with DAIRX API
"""

import requests
import json
from typing import Dict, Any, Optional


class DairxLabClient:
    """HTTP client for DAIRX Labs API"""
    
    def __init__(self, api_key: str, api_url: str = "https://dairx.com"):
        """
        Initialize client
        
        Args:
            api_key: DAIRX API key
            api_url: Base URL for DAIRX API
        """
        self.api_key = api_key
        self.api_url = api_url.rstrip('/')
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'X-API-Key': self.api_key
        })
    
    def create_experiment(self, data: Dict[str, Any]) -> Optional[Dict]:
        """Create new experiment"""
        try:
            response = self.session.post(
                f"{self.api_url}/api/lab/experiments",
                json=data,
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"[DAIRX] Error creating experiment: {e}")
            return None
    
    def ingest_metric(self, payload: Dict[str, Any]) -> bool:
        """Send metric to DAIRX"""
        try:
            response = self.session.post(
                f"{self.api_url}/api/lab/ingest",
                json=payload,
                timeout=5
            )
            response.raise_for_status()
            return True
        except Exception as e:
            # Silent fail to avoid disrupting training
            return False
    
    def get_experiment(self, experiment_id: str) -> Optional[Dict]:
        """Get experiment details"""
        try:
            response = self.session.get(
                f"{self.api_url}/api/lab/experiments?id={experiment_id}",
                timeout=10
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"[DAIRX] Error fetching experiment: {e}")
            return None
    
    def update_experiment(self, experiment_id: str, data: Dict[str, Any]) -> bool:
        """Update experiment"""
        try:
            response = self.session.patch(
                f"{self.api_url}/api/lab/experiments?id={experiment_id}",
                json=data,
                timeout=10
            )
            response.raise_for_status()
            return True
        except Exception as e:
            print(f"[DAIRX] Error updating experiment: {e}")
            return False
