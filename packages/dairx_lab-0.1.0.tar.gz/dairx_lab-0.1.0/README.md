# DAIRX Labs - Python SDK

**One-line experiment tracking for GPU compute**

## Installation

```bash
pip install dairx-lab
```

## Quickstart

```python
from dairx_lab import track

# That's it! One line.
track()

# Your existing training code...
# DAIRX automatically captures loss, accuracy, GPU metrics
```

## Features

- ✅ **Zero Configuration**: Auto-detects PyTorch, TensorFlow, JAX
- ✅ **Auto Metric Logging**: Captures loss, accuracy, GPU utilization, temperature
- ✅ **GPU Monitoring**: Real-time GPU metrics (utilization, memory, temperature)
- ✅ **Cost Tracking**: Links to your DAIRX instance for cost analysis
- ✅ **AI Insights**: Get smart recommendations (cheaper GPUs, stalled training alerts)

## Usage

### Basic Tracking

```python
from dairx_lab import track

# Start tracking (uses DAIRX_API_KEY env var)
track()

# Or provide API key directly
track(api_key="dairx_xxx")

# Or customize experiment name
track(experiment_name="bert-finetuning-v2")
```

### PyTorch Example

```python
import torch
from dairx_lab import track

# Enable tracking
track()

# Your existing training loop - no changes needed!
for epoch in range(10):
    for batch in dataloader:
        outputs = model(batch)
        loss = criterion(outputs, labels)
        loss.backward()  # DAIRX captures metrics here
        optimizer.step()
```

### TensorFlow/Keras Example

```python
import tensorflow as tf
from dairx_lab import track

# Enable tracking
track()

# Your existing training - no changes needed!
model.fit(
    train_data,
    epochs=10,
    validation_data=val_data
)  # DAIRX automatically adds callback
```

### Manual Metric Logging

```python
from dairx_lab import track

tracker = track()

# Log custom metrics
tracker.log_metrics({
    'custom_score': 0.95,
    'precision': 0.87,
    'recall': 0.92
}, step=100, epoch=5)
```

## Configuration

### Environment Variables

```bash
export DAIRX_API_KEY="dairx_xxx"  # Get from https://dairx.com/dashboard
export DAIRX_API_URL="https://dairx.com"  # Optional
```

### API Key

Get your API key at [https://dairx.com/dashboard](https://dairx.com/dashboard)

## Dashboard

View your experiments at [https://dairx.com/dashboard/lab](https://dairx.com/dashboard/lab)

- 📊 Training curves (loss, accuracy)
- 🎯 GPU utilization & temperature
- 💰 Cost per experiment
- 🤖 AI recommendations
- 🔄 Compare multiple experiments

## Features in Detail

### Auto-Detection

DAIRX Labs automatically detects:
- Framework (PyTorch, TensorFlow, JAX)
- GPU type and count
- Python version
- CUDA version
- Training metrics (loss, accuracy, learning rate)

### GPU Metrics

Automatically captures:
- GPU utilization %
- Memory usage (GB)
- Temperature (°C)
- Power draw (W)

### AI Insights

Get smart alerts for:
- 🔴 Stalled training (loss not improving)
- ⚠️ Low GPU utilization (underutilized hardware)
- 🔥 High GPU temperature (thermal issues)
- 💡 Cheaper GPU alternatives (cost optimization)
- 📈 Diverging loss (training instability)

## Examples

See [examples/](./examples/) for complete working examples:
- PyTorch classification
- TensorFlow image segmentation
- Transformer fine-tuning
- Multi-GPU training

## Support

- 📖 [Documentation](https://dairx.com/docs/lab)
- 💬 [Discord Community](https://discord.gg/dairx)
- 🐛 [Issue Tracker](https://github.com/Project-DAIRX/dairx-lab/issues)
- 📧 [Email Support](mailto:support@dairx.com)

## License

MIT License - see [LICENSE](LICENSE)

---

**Made with ❤️ by [DAIRX](https://dairx.com)** - The smart GPU marketplace
