#!/usr/bin/env python3
"""
DAIRX Lab SDK - Unit Tests
Run with: python -m pytest tests/test_sdk.py -v
"""

import pytest
import sys
import os

# Add parent to path for local testing
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestImports:
    """Test that all imports work correctly"""
    
    def test_import_track(self):
        """Can import the main track function"""
        from dairx_lab import track
        assert callable(track)
    
    def test_import_tracker(self):
        """Can import Tracker class"""
        from dairx_lab import Tracker
        assert Tracker is not None
    
    def test_import_client(self):
        """Can import DairxLabClient"""
        from dairx_lab import DairxLabClient
        assert DairxLabClient is not None
    
    def test_version(self):
        """Version is defined"""
        import dairx_lab
        assert hasattr(dairx_lab, '__version__')
        assert dairx_lab.__version__ == '0.1.0'


class TestClient:
    """Test the HTTP client"""
    
    def test_client_init(self):
        """Client initializes with API key"""
        from dairx_lab import DairxLabClient
        client = DairxLabClient(api_key='test_key', api_url='https://test.com')
        assert client.api_key == 'test_key'
        assert client.api_url == 'https://test.com'
    
    def test_client_headers(self):
        """Client sets correct headers"""
        from dairx_lab import DairxLabClient
        client = DairxLabClient(api_key='test_key')
        assert 'X-API-Key' in client.session.headers
        assert client.session.headers['X-API-Key'] == 'test_key'


class TestTracker:
    """Test the Tracker class"""
    
    def test_tracker_requires_api_key(self):
        """Tracker raises error without API key"""
        from dairx_lab import Tracker
        
        # Clear env var if set
        old_key = os.environ.pop('DAIRX_API_KEY', None)
        
        try:
            with pytest.raises(ValueError, match="API key required"):
                Tracker()
        finally:
            # Restore env var
            if old_key:
                os.environ['DAIRX_API_KEY'] = old_key
    
    def test_tracker_accepts_api_key(self):
        """Tracker accepts API key parameter"""
        from dairx_lab import Tracker
        tracker = Tracker(api_key='test_key')
        assert tracker.api_key == 'test_key'
    
    def test_tracker_reads_env_var(self):
        """Tracker reads from environment variable"""
        from dairx_lab import Tracker
        
        os.environ['DAIRX_API_KEY'] = 'env_test_key'
        try:
            tracker = Tracker()
            assert tracker.api_key == 'env_test_key'
        finally:
            del os.environ['DAIRX_API_KEY']
    
    def test_experiment_name_generation(self):
        """Tracker generates experiment name"""
        from dairx_lab import Tracker
        tracker = Tracker(api_key='test_key')
        assert tracker.experiment_name is not None
        assert len(tracker.experiment_name) > 0


class TestFrameworkDetection:
    """Test framework auto-detection"""
    
    def test_detect_no_framework(self):
        """Returns 'other' when no framework loaded"""
        from dairx_lab import Tracker
        tracker = Tracker(api_key='test_key')
        # Before start(), framework is None
        assert tracker.framework is None
    
    def test_detect_pytorch(self):
        """Detects PyTorch when imported"""
        # This test requires torch to be installed
        pytest.importorskip('torch')
        
        import torch  # noqa: F401 - importing for detection
        from dairx_lab import Tracker
        
        tracker = Tracker(api_key='test_key')
        detected = tracker._detect_framework()
        assert detected == 'pytorch'
    
    def test_detect_tensorflow(self):
        """Detects TensorFlow when imported"""
        # This test requires tensorflow to be installed
        pytest.importorskip('tensorflow')
        
        import tensorflow  # noqa: F401 - importing for detection
        from dairx_lab import Tracker
        
        tracker = Tracker(api_key='test_key')
        detected = tracker._detect_framework()
        # Could be pytorch or tensorflow depending on what's loaded first
        assert detected in ['pytorch', 'tensorflow']


class TestPatchers:
    """Test framework patchers"""
    
    def test_pytorch_patcher_exists(self):
        """PyTorch patcher class exists"""
        from dairx_lab.patcher import PyTorchPatcher
        assert PyTorchPatcher is not None
    
    def test_tensorflow_patcher_exists(self):
        """TensorFlow patcher class exists"""
        from dairx_lab.patcher import TensorFlowPatcher
        assert TensorFlowPatcher is not None
    
    def test_jax_patcher_exists(self):
        """JAX patcher class exists (placeholder)"""
        from dairx_lab.patcher import JAXPatcher
        assert JAXPatcher is not None


class TestLogMetrics:
    """Test metric logging"""
    
    def test_log_metrics_method_exists(self):
        """Tracker has log_metrics method"""
        from dairx_lab import Tracker
        tracker = Tracker(api_key='test_key')
        assert hasattr(tracker, 'log_metrics')
        assert callable(tracker.log_metrics)
    
    def test_checkpoint_method_exists(self):
        """Tracker has checkpoint method"""
        from dairx_lab import Tracker
        tracker = Tracker(api_key='test_key')
        assert hasattr(tracker, 'checkpoint')
        assert callable(tracker.checkpoint)
    
    def test_finish_method_exists(self):
        """Tracker has finish method"""
        from dairx_lab import Tracker
        tracker = Tracker(api_key='test_key')
        assert hasattr(tracker, 'finish')
        assert callable(tracker.finish)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
