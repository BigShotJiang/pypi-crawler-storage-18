"""
DAIRX Labs - Setup Configuration
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="dairx-lab",
    version="0.1.0",
    author="DAIRX",
    author_email="support@dairx.com",
    description="One-line experiment tracking for GPU compute",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Project-DAIRX/dairx-lab",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "gpu": ["nvidia-ml-py3>=7.352.0"],  # For GPU metrics
        "torch": ["torch>=1.12.0"],
        "tensorflow": ["tensorflow>=2.10.0"],
    },
    keywords="machine-learning deep-learning experiment-tracking gpu pytorch tensorflow",
    project_urls={
        "Homepage": "https://dairx.com",
        "Documentation": "https://dairx.com/docs/lab",
        "Source": "https://github.com/Project-DAIRX/dairx-lab",
        "Tracker": "https://github.com/Project-DAIRX/dairx-lab/issues",
    },
)
