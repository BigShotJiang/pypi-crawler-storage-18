First version.

Work in progress.
