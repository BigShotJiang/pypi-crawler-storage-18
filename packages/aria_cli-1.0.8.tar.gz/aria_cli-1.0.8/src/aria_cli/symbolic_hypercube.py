"""
ARIA Symbolic Hypercube Integration v1.0.0

Connects Q-Symbolic Protocol to the 64-Agent Hypercube Mesh

This module:
  1. Wraps HyperCubeOrchestrator with symbolic messaging
  2. Encodes all inter-agent messages using G10QR
  3. Expands messages through Q0-Q38 layers on receive
  4. Minimizes message size for maximum throughput
"""

import asyncio
import json
import time
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass

# Import core systems
try:
    from .q_symbolic_protocol import (
        SymbolicProtocol,
        QDatabase,
        QExpansionEngine,
        G10QR,
        MicroMessage,
        SymbolicDictionary,
        QLayer,
    )
    from .q_hypercube_mesh import (
        HyperCubeOrchestrator,
        HyperAgent,
        HyperMessage,
        HyperPort,
        AgentWork,
        AgentResult,
        MergeStrategy,
        AgentState,
    )
    HAS_DEPS = True
except ImportError:
    HAS_DEPS = False


@dataclass
class SymbolicMessage:
    """
    A symbolic message in the hypercube mesh.
    
    Compression levels:
      - FULL: Original JSON (100% size, debugging)
      - SYMBOLIC: Text symbols (20-40% size, human-readable)
      - G10QR: Binary compact (10-30% size, structured)
      - MICRO: 16-byte fixed (5-15% size, ultra-compact)
    """
    raw_bytes: bytes
    format: str  # "full", "symbolic", "g10qr", "micro"
    original_size: int
    compressed_size: int
    source_agent: int
    target_agent: int  # 0 = broadcast
    chain_id: Optional[str] = None
    stage: int = 0
    
    @property
    def compression_ratio(self) -> float:
        if self.original_size == 0:
            return 0.0
        return 1 - (self.compressed_size / self.original_size)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "format": self.format,
            "original_size": self.original_size,
            "compressed_size": self.compressed_size,
            "compression_ratio": f"{self.compression_ratio*100:.1f}%",
            "source_agent": self.source_agent,
            "target_agent": self.target_agent,
            "chain_id": self.chain_id,
            "stage": self.stage,
        }


class SymbolicHypercube:
    """
    Symbolic messaging layer for the 64-agent hypercube mesh.
    
    Features:
      - Automatic message compression using Q-Symbolic Protocol
      - Transparent encode/decode on send/receive
      - Q0-Q38 layer expansion for message understanding
      - Configurable compression level per message type
    
    Usage:
        mesh = SymbolicHypercube()
        mesh.init()
        
        # Scatter with symbolic encoding
        await mesh.scatter_symbolic({
            "action": "execute",
            "type": "python", 
            "command": "result = agent_id * 2"
        })
        
        # Results come back with Q-expansion
        results = await mesh.gather_expanded()
    """
    
    def __init__(
        self,
        mesh_root: Optional[Path] = None,
        default_format: str = "g10qr",
    ):
        if not HAS_DEPS:
            raise ImportError("Required modules not available")
        
        self.mesh_root = mesh_root or Path.home() / ".aria" / "hypercube"
        self.default_format = default_format
        
        # Core systems
        self.protocol = SymbolicProtocol()
        self.q_db = self.protocol.q_db
        self.expansion_engine = self.protocol.expansion_engine
        self.orchestrator: Optional[HyperCubeOrchestrator] = None
        
        # Stats
        self.stats = {
            "messages_encoded": 0,
            "messages_decoded": 0,
            "bytes_original": 0,
            "bytes_compressed": 0,
            "expansions_performed": 0,
        }
    
    def init(self) -> None:
        """Initialize the hypercube mesh with symbolic support"""
        self.orchestrator = HyperCubeOrchestrator(self.mesh_root)
        print(f"✅ Symbolic Hypercube initialized: {self.mesh_root}")
        print(f"   64 agents ready with Q-Symbolic Protocol")
        print(f"   Default format: {self.default_format}")
    
    # =========================================================================
    # ENCODING / DECODING
    # =========================================================================
    
    def encode_message(
        self,
        message: Dict[str, Any],
        format: Optional[str] = None,
    ) -> SymbolicMessage:
        """
        Encode a message using Q-Symbolic Protocol.
        
        Args:
            message: Full message dictionary
            format: Encoding format ("full", "symbolic", "g10qr", "micro")
        
        Returns:
            SymbolicMessage with encoded bytes
        """
        fmt = format or self.default_format
        original = json.dumps(message).encode('utf-8')
        original_size = len(original)
        
        if fmt == "full":
            # No compression
            encoded = original
        elif fmt == "symbolic":
            # Symbolic text
            symbolic = self.q_db.encode_message(message)
            encoded = symbolic.encode('utf-8')
        elif fmt == "micro":
            # 16-byte micro format
            micro = MicroMessage.from_dict(message)
            encoded = micro.to_bytes()
        else:  # g10qr (default)
            # G10QR binary
            symbolic = self.q_db.encode_message(message)
            encoded = G10QR.encode(
                symbolic,
                compress=True,
                chain_id=message.get("chain_id"),
                priority_high=message.get("priority") in ["critical", "high"],
            )
        
        # Update stats
        self.stats["messages_encoded"] += 1
        self.stats["bytes_original"] += original_size
        self.stats["bytes_compressed"] += len(encoded)
        
        return SymbolicMessage(
            raw_bytes=encoded,
            format=fmt,
            original_size=original_size,
            compressed_size=len(encoded),
            source_agent=message.get("source_agent", message.get("agent_id", 0)),
            target_agent=message.get("target_agent", 0),
            chain_id=message.get("chain_id"),
            stage=message.get("stage", 0),
        )
    
    def decode_message(
        self,
        symbolic_msg: SymbolicMessage,
        expand: bool = True,
    ) -> Dict[str, Any]:
        """
        Decode a symbolic message with optional Q-expansion.
        
        Args:
            symbolic_msg: The encoded symbolic message
            expand: Whether to run Q0-Q38 expansion
        
        Returns:
            Decoded message with optional Q-expansion data
        """
        data = symbolic_msg.raw_bytes
        fmt = symbolic_msg.format
        
        if fmt == "full":
            decoded = json.loads(data.decode('utf-8'))
        elif fmt == "symbolic":
            symbolic = data.decode('utf-8')
            decoded = self.q_db.decode_message(symbolic)
        elif fmt == "micro":
            micro = MicroMessage.from_bytes(data)
            decoded = micro.to_dict()
        else:  # g10qr
            payload, metadata = G10QR.decode(data)
            if isinstance(payload, str):
                decoded = self.q_db.decode_message(payload)
                decoded["_g10qr_metadata"] = metadata
            else:
                decoded = payload
        
        # Q-layer expansion
        if expand:
            symbolic_str = self.q_db.encode_message(decoded)
            expanded = self.expansion_engine.expand(symbolic_str)
            decoded["_q_expansion"] = {
                "layers_traversed": expanded["final"]["layers_used"],
                "description": expanded["final"]["description"],
                "ready": expanded["final"]["ready"],
                "plan": expanded["final"]["plan"],
            }
            self.stats["expansions_performed"] += 1
        
        self.stats["messages_decoded"] += 1
        return decoded
    
    # =========================================================================
    # SCATTER / GATHER WITH SYMBOLIC ENCODING
    # =========================================================================
    
    async def scatter_symbolic(
        self,
        message: Dict[str, Any],
        format: Optional[str] = None,
        agent_filter: Optional[List[int]] = None,
    ) -> Dict[str, Any]:
        """
        Scatter a message to all 64 agents using symbolic encoding.
        
        Args:
            message: Message to scatter
            format: Encoding format (uses default if not specified)
            agent_filter: Optional list of agents to target (default: all)
        
        Returns:
            Scatter operation summary
        """
        if not self.orchestrator:
            raise RuntimeError("Hypercube not initialized. Call init() first.")
        
        # Encode once
        symbolic = self.encode_message(message, format)
        
        # Target agents
        targets = agent_filter or list(range(1, 65))
        
        # Write to all target agent folders
        results = {"sent": 0, "failed": 0, "compression": symbolic.to_dict()}
        
        for agent_id in targets:
            try:
                agent = self.orchestrator.agents.get(agent_id)
                if agent:
                    # Create work item with symbolic payload
                    msg_path = agent.folder.work / f"symbolic_{int(time.time()*1000)}.sym"
                    with open(msg_path, 'wb') as f:
                        f.write(symbolic.raw_bytes)
                    
                    # Also write metadata
                    meta_path = msg_path.with_suffix('.meta')
                    with open(meta_path, 'w') as f:
                        json.dump(symbolic.to_dict(), f)
                    
                    results["sent"] += 1
            except Exception as e:
                results["failed"] += 1
        
        return results
    
    async def gather_symbolic(
        self,
        expand: bool = True,
        timeout: float = 60.0,
    ) -> List[Dict[str, Any]]:
        """
        Gather results from all agents with Q-expansion.
        
        Args:
            expand: Whether to expand through Q-layers
            timeout: Maximum wait time
        
        Returns:
            List of decoded and expanded results
        """
        if not self.orchestrator:
            raise RuntimeError("Hypercube not initialized. Call init() first.")
        
        results = []
        
        for agent_id in range(1, 65):
            agent = self.orchestrator.agents.get(agent_id)
            if agent:
                # Check for result files
                for result_file in agent.folder.results.glob("*.json"):
                    try:
                        with open(result_file, 'r') as f:
                            result_data = json.load(f)
                        
                        # Expand through Q-layers if requested
                        if expand and "_q_expansion" not in result_data:
                            symbolic_str = self.q_db.encode_message(result_data)
                            expanded = self.expansion_engine.expand(symbolic_str)
                            result_data["_q_expansion"] = {
                                "layers_traversed": expanded["final"]["layers_used"],
                                "description": expanded["final"]["description"],
                            }
                            self.stats["expansions_performed"] += 1
                        
                        results.append(result_data)
                    except Exception:
                        pass
        
        return results
    
    # =========================================================================
    # PARALLEL EXECUTION WITH SYMBOLIC MESSAGING
    # =========================================================================
    
    async def run_parallel_symbolic(
        self,
        task: Dict[str, Any],
        format: str = "micro",
    ) -> Dict[str, Any]:
        """
        Run a task on all 64 agents in parallel using symbolic messaging.
        
        Args:
            task: Task definition
            format: Message format (use "micro" for fastest)
        
        Returns:
            Combined results from all agents
        """
        if not self.orchestrator:
            raise RuntimeError("Hypercube not initialized. Call init() first.")
        
        start_time = time.time()
        
        # Encode task once as micro-message for minimum overhead
        symbolic = self.encode_message(task, format)
        
        async def run_agent(agent_id: int) -> Dict[str, Any]:
            """Run task on single agent"""
            agent = self.orchestrator.agents.get(agent_id)
            if not agent:
                return {"agent_id": agent_id, "success": False, "error": "Agent not found"}
            
            try:
                # Create work item
                work = AgentWork(
                    task_id=f"sym_{agent_id}_{int(time.time()*1000)}",
                    task_type=task.get("type", "echo"),
                    command=task.get("command", ""),
                    payload={
                        "symbolic": symbolic.raw_bytes.hex(),
                        "format": symbolic.format,
                        **task.get("payload", {})
                    },
                    priority=task.get("priority", "normal"),
                    source_agent=0,
                    chain_id=task.get("chain_id"),
                    stage=task.get("stage", 0),
                )
                
                # Execute
                result = await agent.execute_work(work)
                
                return {
                    "agent_id": agent_id,
                    "success": result.success,
                    "output": result.output,
                    "duration": result.duration,
                }
            except Exception as e:
                return {
                    "agent_id": agent_id,
                    "success": False,
                    "error": str(e),
                }
        
        # Run all 64 agents in parallel
        tasks = [run_agent(i) for i in range(1, 65)]
        agent_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Process results
        successful = [r for r in agent_results if isinstance(r, dict) and r.get("success")]
        failed = [r for r in agent_results if isinstance(r, dict) and not r.get("success")]
        
        total_time = time.time() - start_time
        
        return {
            "total_agents": 64,
            "successful": len(successful),
            "failed": len(failed),
            "success_rate": len(successful) / 64,
            "total_time": total_time,
            "avg_time_per_agent": total_time / 64,
            "message_format": symbolic.format,
            "message_size": symbolic.compressed_size,
            "compression_ratio": f"{symbolic.compression_ratio*100:.1f}%",
            "results": agent_results,
        }
    
    # =========================================================================
    # CHAINED PIPELINE WITH SYMBOLIC ENCODING
    # =========================================================================
    
    async def run_chain_symbolic(
        self,
        stages: List[Dict[str, Any]],
        format: str = "g10qr",
    ) -> Dict[str, Any]:
        """
        Run a multi-stage chained pipeline with symbolic messaging.
        
        Each stage:
          1. Encodes task symbolically (minimal bytes)
          2. Scatters to all 64 agents
          3. Agents process in parallel
          4. Results merge at barrier
          5. Merged result feeds next stage
        
        Args:
            stages: List of stage definitions
            format: Message format for inter-stage messaging
        
        Returns:
            Complete pipeline results
        """
        if not self.orchestrator:
            raise RuntimeError("Hypercube not initialized. Call init() first.")
        
        import uuid
        chain_id = str(uuid.uuid4())[:8]
        
        start_time = time.time()
        stage_results = []
        previous_output = None
        
        for stage_num, stage_def in enumerate(stages):
            stage_start = time.time()
            
            # Inject previous stage output if available
            task = {
                **stage_def,
                "chain_id": chain_id,
                "stage": stage_num,
                "previous_output": previous_output,
            }
            
            # Run stage
            result = await self.run_parallel_symbolic(task, format)
            result["stage_num"] = stage_num
            result["stage_time"] = time.time() - stage_start
            
            stage_results.append(result)
            
            # Merge for next stage
            successful_outputs = [
                r.get("output") for r in result.get("results", [])
                if isinstance(r, dict) and r.get("success")
            ]
            previous_output = successful_outputs
        
        total_time = time.time() - start_time
        
        return {
            "chain_id": chain_id,
            "total_stages": len(stages),
            "total_time": total_time,
            "stage_results": stage_results,
            "final_output": previous_output,
            "message_format": format,
            "stats": self.get_stats(),
        }
    
    # =========================================================================
    # UTILITIES
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get protocol statistics"""
        total_original = self.stats["bytes_original"]
        total_compressed = self.stats["bytes_compressed"]
        
        return {
            "messages_encoded": self.stats["messages_encoded"],
            "messages_decoded": self.stats["messages_decoded"],
            "bytes_original": total_original,
            "bytes_compressed": total_compressed,
            "overall_compression": f"{(1 - total_compressed/total_original)*100:.1f}%" if total_original > 0 else "N/A",
            "expansions_performed": self.stats["expansions_performed"],
            "q_database_stats": self.q_db.get_stats(),
        }
    
    def get_topology(self) -> str:
        """Get ASCII topology visualization"""
        if not self.orchestrator:
            return "Not initialized"
        return self.orchestrator.get_topology()
    
    def demo(self) -> None:
        """Run a demonstration of symbolic hypercube"""
        print("\n" + "="*70)
        print("  SYMBOLIC HYPERCUBE DEMONSTRATION")
        print("="*70 + "\n")
        
        # Initialize
        self.init()
        
        # Demo message
        message = {
            "action": "execute",
            "type": "python",
            "priority": "high",
            "command": "result = agent_id * 42",
        }
        
        print("📦 Original Message:")
        print(f"   {json.dumps(message)}")
        print(f"   Size: {len(json.dumps(message))} bytes\n")
        
        # Encode in all formats
        for fmt in ["full", "symbolic", "g10qr", "micro"]:
            encoded = self.encode_message(message, fmt)
            print(f"📝 {fmt.upper()} Format:")
            print(f"   Size: {encoded.compressed_size} bytes")
            print(f"   Compression: {encoded.compression_ratio*100:.1f}%")
            if fmt == "symbolic":
                print(f"   Content: {encoded.raw_bytes.decode('utf-8')}")
            elif fmt != "full":
                print(f"   Hex: {encoded.raw_bytes.hex()[:40]}...")
            print()
        
        # Q-Layer expansion demo
        symbolic = self.encode_message(message, "symbolic")
        decoded = self.decode_message(symbolic, expand=True)
        
        print("🔄 Q-Layer Expansion:")
        expansion = decoded.get("_q_expansion", {})
        print(f"   Layers traversed: {expansion.get('layers_traversed', 0)}")
        print(f"   Description: {expansion.get('description', '')}")
        print(f"   Ready: {expansion.get('ready', False)}")
        
        print("\n✅ Symbolic Hypercube Demo Complete!")
        print(f"\n📊 Stats: {json.dumps(self.get_stats(), indent=2)}")


# =============================================================================
# CLI INTEGRATION
# =============================================================================

def create_symbolic_cli():
    """Create CLI commands for symbolic hypercube"""
    try:
        import typer
    except ImportError:
        return None
    
    app = typer.Typer(
        name="symbolic",
        help="🔷 Q-Symbolic Protocol Commands",
        no_args_is_help=True,
    )
    
    @app.command()
    def demo():
        """Run symbolic protocol demonstration"""
        mesh = SymbolicHypercube()
        mesh.demo()
    
    @app.command()
    def encode(
        message: str = typer.Argument(..., help="JSON message to encode"),
        format: str = typer.Option("g10qr", "-f", "--format", help="Format: full, symbolic, g10qr, micro"),
    ):
        """Encode a message using Q-Symbolic Protocol"""
        try:
            msg_dict = json.loads(message)
        except json.JSONDecodeError:
            # Treat as simple command
            msg_dict = {"action": "execute", "command": message}
        
        mesh = SymbolicHypercube()
        encoded = mesh.encode_message(msg_dict, format)
        
        print(f"\n🔷 Encoded Message ({format.upper()}):")
        print(f"   Original: {encoded.original_size} bytes")
        print(f"   Compressed: {encoded.compressed_size} bytes")
        print(f"   Ratio: {encoded.compression_ratio*100:.1f}% reduction")
        
        if format == "symbolic":
            print(f"   Content: {encoded.raw_bytes.decode('utf-8')}")
        else:
            print(f"   Hex: {encoded.raw_bytes.hex()}")
    
    @app.command()
    def stats():
        """Show Q-Database statistics"""
        mesh = SymbolicHypercube()
        stats = mesh.q_db.get_stats()
        print("\n📊 Q-Database Statistics:")
        print(json.dumps(stats, indent=2))
    
    @app.command()
    def parallel(
        command: str = typer.Argument("echo Hello from symbolic agent!"),
        format: str = typer.Option("micro", "-f", "--format"),
    ):
        """Run command on all 64 agents with symbolic encoding"""
        import asyncio
        
        mesh = SymbolicHypercube()
        mesh.init()
        
        task = {
            "action": "execute",
            "type": "echo",
            "command": command,
        }
        
        result = asyncio.run(mesh.run_parallel_symbolic(task, format))
        
        print(f"\n✅ Parallel Execution Complete:")
        print(f"   Agents: {result['successful']}/{result['total_agents']}")
        print(f"   Time: {result['total_time']:.3f}s")
        print(f"   Format: {result['message_format']}")
        print(f"   Message Size: {result['message_size']} bytes")
        print(f"   Compression: {result['compression_ratio']}")
    
    return app


# Export
__all__ = [
    "SymbolicHypercube",
    "SymbolicMessage",
    "create_symbolic_cli",
]


if __name__ == "__main__":
    # Run demo
    mesh = SymbolicHypercube()
    mesh.demo()
