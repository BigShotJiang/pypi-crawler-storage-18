"""
ARIA Q-Symbolic Protocol v1.0.0

Ultra-Compact Symbolic Messaging for 64-Agent Hypercube Mesh

Architecture:
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │                      Q-SYMBOLIC EXPANSION PROTOCOL                          │
  │                                                                             │
  │   SENDER                                                     RECEIVER       │
  │   ┌─────────┐                                               ┌─────────┐    │
  │   │ Message │──► SYMBOLIC ──► G10QR ──► [64-bit] ──► Q0-Q38 │ EXPAND  │    │
  │   │  Full   │    SUB      ENCODE     TRANSMIT    RECURSIVE │  Full   │    │
  │   └─────────┘                                               └─────────┘    │
  │                                                                             │
  │   "Execute task with priority high"                                        │
  │         ↓ Symbolic Sub                                                     │
  │   "§X.T:P=H"  (8 bytes vs 32 bytes = 75% compression)                     │
  │         ↓ G10QR Encode                                                     │
  │   0x47 0x31 0x30 0x51 0x52 (5-byte QR header + payload)                   │
  │         ↓ Transmit to Agent                                                │
  │         ↓ Q0-Q38 Recursive Expansion                                       │
  │   Full semantic understanding restored                                     │
  └─────────────────────────────────────────────────────────────────────────────┘

Key Concepts:
  - Symbolic Substitution: Common patterns → compact symbols
  - G10QR Encoding: QR-inspired binary compact format
  - Q-Layer Expansion: Recursive unpacking through Q0-Q38 layers
  - Q-Database: Symbol dictionary with version control
  - Micro-Messages: Minimum viable inter-agent payloads
"""

import json
import hashlib
import struct
import base64
import zlib
import time
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from collections import OrderedDict


# =============================================================================
# Q-LAYER DEFINITIONS (Q0-Q38)
# =============================================================================

class QLayer(IntEnum):
    """Full Q0-Q38 Cognitive Architecture for message expansion"""
    # Foundation (Q0-Q9)
    Q0_VOID = 0           # Null potential
    Q1_PERCEPTION = 1     # Raw input
    Q2_ATTENTION = 2      # Focus
    Q3_PATTERN = 3        # Pattern match
    Q4_MEMORY_SHORT = 4   # Working memory
    Q5_MEMORY_LONG = 5    # Long-term memory
    Q6_ASSOCIATION = 6    # Linking
    Q7_CONTEXT = 7        # Context frame
    Q8_LANGUAGE = 8       # Linguistic
    Q9_EMOTION = 9        # Affective
    
    # Reasoning (Q10-Q19)
    Q10_LOGIC = 10        # Logic
    Q11_INFERENCE = 11    # Inference
    Q12_HYPOTHESIS = 12   # Hypothesis
    Q13_ABSTRACTION = 13  # Abstraction
    Q14_ANALOGY = 14      # Analogy
    Q15_CAUSATION = 15    # Causation
    Q16_PREDICTION = 16   # Prediction
    Q17_EVALUATION = 17   # Evaluation
    Q18_SYNTHESIS = 18    # Synthesis
    Q19_CREATIVITY = 19   # Creativity
    
    # Action (Q20-Q29)
    Q20_INTENTION = 20    # Intention
    Q21_PLANNING = 21     # Planning
    Q22_DECISION = 22     # Decision
    Q23_EXECUTION = 23    # Execution
    Q24_MONITORING = 24   # Monitoring
    Q25_FEEDBACK = 25     # Feedback
    Q26_CORRECTION = 26   # Correction
    Q27_OPTIMIZATION = 27 # Optimization
    Q28_LEARNING = 28     # Learning
    Q29_ADAPTATION = 29   # Adaptation
    
    # Meta (Q30-Q38)
    Q30_AWARENESS = 30    # Self-awareness
    Q31_REFLECTION = 31   # Reflection
    Q32_METACOGNITION = 32  # Metacognition
    Q33_IDENTITY = 33     # Identity
    Q34_VALUES = 34       # Values
    Q35_WISDOM = 35       # Wisdom
    Q36_INTEGRATION = 36  # Integration
    Q37_EMERGENCE = 37    # Emergence
    Q38_TRANSCENDENCE = 38  # Transcendence


# =============================================================================
# SYMBOLIC SUBSTITUTION DICTIONARY
# =============================================================================

class SymbolicDictionary:
    """
    Core symbolic substitution dictionary for ultra-compact messaging.
    
    Symbol Format:
      § = Symbol prefix
      Single letter = Category (X=execute, D=data, S=state, M=meta, etc.)
      Dot-separated = Hierarchy
      Colon = Key-value separator
      Equals = Assignment
    
    Examples:
      "Execute task" → "§X"
      "With priority high" → ":P=H"
      "On agent 42" → "@42"
      "Result success" → "→✓"
      "Chain stage 3" → "⛓3"
    """
    
    # Version for compatibility
    VERSION = "1.0.0"
    
    # Core action symbols (1 byte each)
    ACTIONS = {
        "execute": "§X",
        "run": "§X",
        "start": "§S",
        "stop": "§H",  # Halt
        "pause": "§P",
        "resume": "§R",
        "send": "§>",
        "receive": "§<",
        "broadcast": "§*",
        "scatter": "§⊗",
        "gather": "§⊕",
        "merge": "§∪",
        "split": "§∩",
        "chain": "§⛓",
        "parallel": "§∥",
        "sequential": "§→",
        "transform": "§τ",
        "analyze": "§α",
        "generate": "§γ",
        "validate": "§✓",
        "search": "§?",
        "filter": "§⊂",
        "aggregate": "§Σ",
        "map": "§μ",
        "reduce": "§ρ",
    }
    
    # Priority symbols
    PRIORITIES = {
        "critical": "P=C",
        "high": "P=H",
        "normal": "P=N",
        "low": "P=L",
        "background": "P=B",
    }
    
    # State symbols
    STATES = {
        "idle": "Ω=I",
        "running": "Ω=R",
        "waiting": "Ω=W",
        "completed": "Ω=C",
        "failed": "Ω=F",
        "error": "Ω=E",
        "pending": "Ω=P",
        "success": "✓",
        "failure": "✗",
    }
    
    # Type symbols
    TYPES = {
        "shell": "T=S",
        "python": "T=P",
        "function": "T=F",
        "echo": "T=E",
        "agent": "T=A",
        "data": "T=D",
        "command": "T=C",
        "query": "T=Q",
        "response": "T=R",
    }
    
    # Q-Layer symbols (single char + number)
    Q_LAYERS = {
        "q0": "Q0", "q1": "Q1", "q2": "Q2", "q3": "Q3", "q4": "Q4",
        "q5": "Q5", "q6": "Q6", "q7": "Q7", "q8": "Q8", "q9": "Q9",
        "q10": "Qa", "q11": "Qb", "q12": "Qc", "q13": "Qd", "q14": "Qe",
        "q15": "Qf", "q16": "Qg", "q17": "Qh", "q18": "Qi", "q19": "Qj",
        "q20": "Qk", "q21": "Ql", "q22": "Qm", "q23": "Qn", "q24": "Qo",
        "q25": "Qp", "q26": "Qq", "q27": "Qr", "q28": "Qs", "q29": "Qt",
        "q30": "Qu", "q31": "Qv", "q32": "Qw", "q33": "Qx", "q34": "Qy",
        "q35": "Qz", "q36": "Q!", "q37": "Q@", "q38": "Q#",
    }
    
    # Merge strategy symbols
    MERGE_STRATEGIES = {
        "all": "M=A",
        "concat": "M=C",
        "reduce": "M=R",
        "first": "M=1",
        "best": "M=B",
        "vote": "M=V",
        "tree": "M=T",
    }
    
    # Common phrases → micro symbols
    PHRASES = {
        "with payload": "↓",
        "from agent": "←",
        "to agent": "→",
        "chain id": "⛓",
        "stage": "◊",
        "timeout": "⏱",
        "retry": "↻",
        "result": "⊢",
        "error": "⊥",
        "data": "△",
        "config": "⚙",
        "all agents": "@*",
    }
    
    # Numbers compact (agent IDs 1-64)
    @staticmethod
    def encode_agent_id(agent_id: int) -> str:
        """Encode agent ID (1-64) as single char"""
        if 1 <= agent_id <= 64:
            # Use ASCII printable range
            return chr(0x40 + agent_id)  # A-Z, then more
        return f"@{agent_id}"
    
    @staticmethod
    def decode_agent_id(char: str) -> int:
        """Decode agent ID from single char"""
        if len(char) == 1 and ord(char) >= 0x41:
            return ord(char) - 0x40
        if char.startswith("@"):
            return int(char[1:])
        return 0


# =============================================================================
# G10QR ENCODER/DECODER
# =============================================================================

class G10QR:
    """
    G10QR: Compact QR-inspired binary encoding for agent messages.
    
    Format:
      ┌──────────┬──────────┬──────────┬──────────┬──────────────────┐
      │ MAGIC(2) │ VERSION  │ FLAGS    │ LENGTH   │ PAYLOAD          │
      │ 0x47 0x51│ 0x10     │ 1 byte   │ 2 bytes  │ N bytes          │
      └──────────┴──────────┴──────────┴──────────┴──────────────────┘
    
    Flags:
      bit 0: Compressed (zlib)
      bit 1: Encrypted
      bit 2: Requires ACK
      bit 3: Is response
      bit 4: Has chain ID
      bit 5: Multi-part
      bit 6: Priority high
      bit 7: Reserved
    
    Total overhead: 6 bytes header
    Max payload: 65535 bytes
    """
    
    MAGIC = b'GQ'  # G10QR magic bytes
    VERSION = 0x10  # v1.0
    
    # Flags
    FLAG_COMPRESSED = 0x01
    FLAG_ENCRYPTED = 0x02
    FLAG_REQUIRES_ACK = 0x04
    FLAG_IS_RESPONSE = 0x08
    FLAG_HAS_CHAIN = 0x10
    FLAG_MULTIPART = 0x20
    FLAG_PRIORITY = 0x40
    FLAG_RESERVED = 0x80
    
    @classmethod
    def encode(
        cls,
        payload: Union[str, bytes, Dict],
        compress: bool = True,
        requires_ack: bool = False,
        is_response: bool = False,
        chain_id: Optional[str] = None,
        priority_high: bool = False,
    ) -> bytes:
        """
        Encode a message to G10QR format.
        
        Args:
            payload: Message content (str, bytes, or dict)
            compress: Whether to compress payload
            requires_ack: Whether ACK is required
            is_response: Whether this is a response
            chain_id: Optional chain ID (8 chars)
            priority_high: High priority flag
        
        Returns:
            G10QR encoded bytes
        """
        # Convert payload to bytes
        if isinstance(payload, dict):
            payload_bytes = json.dumps(payload, separators=(',', ':')).encode('utf-8')
        elif isinstance(payload, str):
            payload_bytes = payload.encode('utf-8')
        else:
            payload_bytes = payload
        
        # Build flags
        flags = 0
        if priority_high:
            flags |= cls.FLAG_PRIORITY
        if requires_ack:
            flags |= cls.FLAG_REQUIRES_ACK
        if is_response:
            flags |= cls.FLAG_IS_RESPONSE
        if chain_id:
            flags |= cls.FLAG_HAS_CHAIN
        
        # Compress if requested and beneficial
        if compress and len(payload_bytes) > 32:
            compressed = zlib.compress(payload_bytes, level=9)
            if len(compressed) < len(payload_bytes):
                payload_bytes = compressed
                flags |= cls.FLAG_COMPRESSED
        
        # Add chain ID if present
        if chain_id:
            chain_bytes = chain_id[:8].encode('utf-8').ljust(8, b'\x00')
            payload_bytes = chain_bytes + payload_bytes
        
        # Build packet
        length = len(payload_bytes)
        if length > 65535:
            raise ValueError(f"Payload too large: {length} bytes (max 65535)")
        
        header = struct.pack('>2sBBH', cls.MAGIC, cls.VERSION, flags, length)
        return header + payload_bytes
    
    @classmethod
    def decode(cls, data: bytes) -> Tuple[Any, Dict[str, Any]]:
        """
        Decode a G10QR message.
        
        Args:
            data: G10QR encoded bytes
        
        Returns:
            Tuple of (payload, metadata)
        """
        if len(data) < 6:
            raise ValueError("Invalid G10QR packet: too short")
        
        # Parse header
        magic, version, flags, length = struct.unpack('>2sBBH', data[:6])
        
        if magic != cls.MAGIC:
            raise ValueError(f"Invalid magic bytes: {magic}")
        
        if version != cls.VERSION:
            raise ValueError(f"Unsupported version: {version}")
        
        # Extract payload
        payload_bytes = data[6:6+length]
        
        # Extract chain ID if present
        chain_id = None
        if flags & cls.FLAG_HAS_CHAIN:
            chain_id = payload_bytes[:8].rstrip(b'\x00').decode('utf-8')
            payload_bytes = payload_bytes[8:]
        
        # Decompress if needed
        if flags & cls.FLAG_COMPRESSED:
            payload_bytes = zlib.decompress(payload_bytes)
        
        # Try to decode as JSON
        try:
            payload = json.loads(payload_bytes.decode('utf-8'))
        except (json.JSONDecodeError, UnicodeDecodeError):
            try:
                payload = payload_bytes.decode('utf-8')
            except UnicodeDecodeError:
                payload = payload_bytes
        
        metadata = {
            "version": version,
            "compressed": bool(flags & cls.FLAG_COMPRESSED),
            "encrypted": bool(flags & cls.FLAG_ENCRYPTED),
            "requires_ack": bool(flags & cls.FLAG_REQUIRES_ACK),
            "is_response": bool(flags & cls.FLAG_IS_RESPONSE),
            "chain_id": chain_id,
            "priority_high": bool(flags & cls.FLAG_PRIORITY),
            "original_size": length,
        }
        
        return payload, metadata
    
    @classmethod
    def estimate_size(cls, payload: Union[str, bytes, Dict]) -> Tuple[int, int]:
        """Estimate original vs encoded size"""
        if isinstance(payload, dict):
            original = len(json.dumps(payload).encode('utf-8'))
        elif isinstance(payload, str):
            original = len(payload.encode('utf-8'))
        else:
            original = len(payload)
        
        # Estimate compressed size
        encoded = cls.encode(payload)
        return original, len(encoded)


# =============================================================================
# Q-DATABASE CONVERTER
# =============================================================================

class QDatabase:
    """
    Q-Database: Symbol dictionary with versioning and learning.
    
    Maintains:
      - Base symbol dictionary (static)
      - Learned symbols (dynamic, from usage patterns)
      - Frequency counts (for optimization)
      - Version history (for compatibility)
    """
    
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or Path.home() / ".aria" / "q-db"
        self.db_path.mkdir(parents=True, exist_ok=True)
        
        # Symbol dictionaries
        self.base_dict = SymbolicDictionary()
        self.learned: Dict[str, str] = {}
        self.frequency: Dict[str, int] = {}
        
        # Reverse lookups
        self._build_reverse_maps()
        
        # Load learned symbols
        self._load_learned()
    
    def _build_reverse_maps(self) -> None:
        """Build reverse lookup maps for decoding"""
        self.reverse_actions = {v: k for k, v in self.base_dict.ACTIONS.items()}
        self.reverse_priorities = {v: k for k, v in self.base_dict.PRIORITIES.items()}
        self.reverse_states = {v: k for k, v in self.base_dict.STATES.items()}
        self.reverse_types = {v: k for k, v in self.base_dict.TYPES.items()}
        self.reverse_q_layers = {v: k for k, v in self.base_dict.Q_LAYERS.items()}
        self.reverse_merge = {v: k for k, v in self.base_dict.MERGE_STRATEGIES.items()}
        self.reverse_phrases = {v: k for k, v in self.base_dict.PHRASES.items()}
    
    def _load_learned(self) -> None:
        """Load learned symbols from disk"""
        learned_file = self.db_path / "learned.json"
        if learned_file.exists():
            try:
                with open(learned_file, 'r') as f:
                    data = json.load(f)
                self.learned = data.get("symbols", {})
                self.frequency = data.get("frequency", {})
            except Exception:
                pass
    
    def _save_learned(self) -> None:
        """Save learned symbols to disk"""
        learned_file = self.db_path / "learned.json"
        with open(learned_file, 'w') as f:
            json.dump({
                "symbols": self.learned,
                "frequency": self.frequency,
                "version": SymbolicDictionary.VERSION,
            }, f, indent=2)
    
    def encode_message(self, message: Dict[str, Any]) -> str:
        """
        Encode a full message to symbolic format.
        
        Input: {"action": "execute", "type": "python", "priority": "high", ...}
        Output: "§X:T=P:P=H:..."
        """
        parts = []
        
        # Action
        action = message.get("action", "").lower()
        if action in self.base_dict.ACTIONS:
            parts.append(self.base_dict.ACTIONS[action])
            self._track_usage(action)
        
        # Type
        task_type = message.get("type", message.get("task_type", "")).lower()
        if task_type in self.base_dict.TYPES:
            parts.append(self.base_dict.TYPES[task_type])
        
        # Priority
        priority = message.get("priority", "").lower()
        if priority in self.base_dict.PRIORITIES:
            parts.append(self.base_dict.PRIORITIES[priority])
        
        # State
        state = message.get("state", "").lower()
        if state in self.base_dict.STATES:
            parts.append(self.base_dict.STATES[state])
        
        # Agent IDs
        if "agent_id" in message:
            parts.append(f"@{message['agent_id']}")
        if "target_agent" in message:
            parts.append(f"→{message['target_agent']}")
        if "source_agent" in message:
            parts.append(f"←{message['source_agent']}")
        
        # Chain/Stage
        if "chain_id" in message:
            parts.append(f"⛓{message['chain_id'][:4]}")
        if "stage" in message:
            parts.append(f"◊{message['stage']}")
        
        # Merge strategy
        merge = message.get("merge_strategy", "").lower()
        if merge in self.base_dict.MERGE_STRATEGIES:
            parts.append(self.base_dict.MERGE_STRATEGIES[merge])
        
        # Q-Layer
        q_layer = message.get("q_layer", "").lower()
        if q_layer in self.base_dict.Q_LAYERS:
            parts.append(self.base_dict.Q_LAYERS[q_layer])
        
        # Command (compact)
        if "command" in message:
            cmd = message["command"]
            if len(cmd) <= 20:
                parts.append(f"«{cmd}»")
            else:
                # Hash for long commands
                cmd_hash = hashlib.md5(cmd.encode()).hexdigest()[:6]
                parts.append(f"#C{cmd_hash}")
        
        return ":".join(parts) if parts else "§∅"
    
    def decode_message(self, symbolic: str) -> Dict[str, Any]:
        """
        Decode a symbolic message back to full format.
        
        Input: "§X:T=P:P=H:@42:◊3"
        Output: {"action": "execute", "type": "python", "priority": "high", ...}
        """
        result = {}
        
        parts = symbolic.split(":")
        
        for part in parts:
            # Action
            if part in self.reverse_actions:
                result["action"] = self.reverse_actions[part]
            # Type
            elif part in self.reverse_types:
                result["type"] = self.reverse_types[part]
            # Priority
            elif part in self.reverse_priorities:
                result["priority"] = self.reverse_priorities[part]
            # State
            elif part in self.reverse_states:
                result["state"] = self.reverse_states[part]
            # Merge
            elif part in self.reverse_merge:
                result["merge_strategy"] = self.reverse_merge[part]
            # Q-Layer
            elif part in self.reverse_q_layers:
                result["q_layer"] = self.reverse_q_layers[part]
            # Agent ID
            elif part.startswith("@"):
                result["agent_id"] = int(part[1:]) if part[1:].isdigit() else part[1:]
            # Target agent
            elif part.startswith("→"):
                result["target_agent"] = int(part[1:]) if part[1:].isdigit() else part[1:]
            # Source agent
            elif part.startswith("←"):
                result["source_agent"] = int(part[1:]) if part[1:].isdigit() else part[1:]
            # Chain ID
            elif part.startswith("⛓"):
                result["chain_id"] = part[1:]
            # Stage
            elif part.startswith("◊"):
                result["stage"] = int(part[1:]) if part[1:].isdigit() else 0
            # Command
            elif part.startswith("«") and part.endswith("»"):
                result["command"] = part[1:-1]
        
        return result
    
    def _track_usage(self, term: str) -> None:
        """Track symbol usage frequency"""
        self.frequency[term] = self.frequency.get(term, 0) + 1
        
        # Periodically save
        if sum(self.frequency.values()) % 100 == 0:
            self._save_learned()
    
    def learn_pattern(self, original: str, symbolic: str) -> None:
        """Learn a new symbol pattern"""
        if len(symbolic) < len(original) * 0.5:  # At least 50% compression
            self.learned[original.lower()] = symbolic
            self._save_learned()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get database statistics"""
        return {
            "version": SymbolicDictionary.VERSION,
            "base_symbols": len(self.base_dict.ACTIONS) + len(self.base_dict.TYPES),
            "learned_symbols": len(self.learned),
            "total_encodings": sum(self.frequency.values()),
            "top_used": sorted(self.frequency.items(), key=lambda x: x[1], reverse=True)[:10],
        }


# =============================================================================
# Q-LAYER EXPANSION ENGINE
# =============================================================================

class QExpansionEngine:
    """
    Recursive Q0-Q38 Layer Expansion Engine.
    
    Takes a compact symbolic message and expands it through the
    Q cognitive layers, adding context and understanding at each level.
    
    Expansion Flow:
      Q0 (Void) → Q1 (Perception) → Q3 (Pattern) → Q8 (Language) →
      Q10 (Logic) → Q18 (Synthesis) → Q23 (Execution) → Q38 (Transcendence)
    """
    
    # Layer expansion order (optimized path through Q-system)
    EXPANSION_PATH = [
        QLayer.Q0_VOID,        # Start from potential
        QLayer.Q1_PERCEPTION,  # Perceive the symbolic input
        QLayer.Q3_PATTERN,     # Match patterns
        QLayer.Q7_CONTEXT,     # Add context
        QLayer.Q8_LANGUAGE,    # Linguistic expansion
        QLayer.Q10_LOGIC,      # Logical validation
        QLayer.Q11_INFERENCE,  # Infer missing pieces
        QLayer.Q18_SYNTHESIS,  # Synthesize full meaning
        QLayer.Q23_EXECUTION,  # Prepare for execution
        QLayer.Q38_TRANSCENDENCE,  # Unified understanding
    ]
    
    def __init__(self, q_db: Optional[QDatabase] = None):
        self.q_db = q_db or QDatabase()
        
        # Layer handlers
        self.layer_handlers: Dict[QLayer, callable] = {
            QLayer.Q0_VOID: self._expand_void,
            QLayer.Q1_PERCEPTION: self._expand_perception,
            QLayer.Q3_PATTERN: self._expand_pattern,
            QLayer.Q7_CONTEXT: self._expand_context,
            QLayer.Q8_LANGUAGE: self._expand_language,
            QLayer.Q10_LOGIC: self._expand_logic,
            QLayer.Q11_INFERENCE: self._expand_inference,
            QLayer.Q18_SYNTHESIS: self._expand_synthesis,
            QLayer.Q23_EXECUTION: self._expand_execution,
            QLayer.Q38_TRANSCENDENCE: self._expand_transcendence,
        }
        
        # Expansion trace
        self.trace: List[Dict[str, Any]] = []
    
    def expand(
        self,
        symbolic_message: str,
        full_expansion: bool = True,
        target_layer: Optional[QLayer] = None,
    ) -> Dict[str, Any]:
        """
        Recursively expand a symbolic message through Q-layers.
        
        Args:
            symbolic_message: Compact symbolic message (e.g., "§X:T=P:P=H")
            full_expansion: Whether to expand through all layers
            target_layer: Stop at specific layer (if not full)
        
        Returns:
            Fully expanded message with semantic understanding
        """
        self.trace = []
        
        # Start with decoded base
        current = {
            "raw_symbolic": symbolic_message,
            "decoded": self.q_db.decode_message(symbolic_message),
            "expansions": {},
            "metadata": {
                "expanded_at": time.time(),
                "layers_traversed": [],
            }
        }
        
        # Determine path
        path = self.EXPANSION_PATH
        if target_layer and not full_expansion:
            try:
                idx = path.index(target_layer)
                path = path[:idx+1]
            except ValueError:
                pass
        
        # Expand through layers
        for layer in path:
            handler = self.layer_handlers.get(layer)
            if handler:
                layer_result = handler(current)
                current["expansions"][layer.name] = layer_result
                current["metadata"]["layers_traversed"].append(layer.name)
                
                self.trace.append({
                    "layer": layer.name,
                    "result": layer_result,
                })
        
        # Final synthesis
        current["final"] = self._synthesize_final(current)
        
        return current
    
    def _expand_void(self, state: Dict) -> Dict[str, Any]:
        """Q0: Initialize from void potential"""
        return {
            "initialized": True,
            "potential": "manifest",
            "timestamp": time.time(),
        }
    
    def _expand_perception(self, state: Dict) -> Dict[str, Any]:
        """Q1: Perceive the raw symbolic input"""
        symbolic = state.get("raw_symbolic", "")
        return {
            "input_length": len(symbolic),
            "symbol_count": len(symbolic.split(":")),
            "has_action": "§" in symbolic,
            "has_target": "→" in symbolic or "@" in symbolic,
            "has_chain": "⛓" in symbolic,
        }
    
    def _expand_pattern(self, state: Dict) -> Dict[str, Any]:
        """Q3: Recognize patterns in the message"""
        decoded = state.get("decoded", {})
        patterns = []
        
        if "action" in decoded:
            patterns.append(f"action:{decoded['action']}")
        if "type" in decoded:
            patterns.append(f"type:{decoded['type']}")
        if decoded.get("agent_id"):
            patterns.append("targeted")
        if decoded.get("chain_id"):
            patterns.append("chained")
        
        return {
            "patterns_found": patterns,
            "pattern_count": len(patterns),
            "is_command": "action" in decoded,
            "is_query": decoded.get("action") in ["search", "query", "ask"],
        }
    
    def _expand_context(self, state: Dict) -> Dict[str, Any]:
        """Q7: Add contextual understanding"""
        decoded = state.get("decoded", {})
        
        context = {
            "execution_context": "local" if not decoded.get("target_agent") else "remote",
            "synchronicity": "async" if decoded.get("chain_id") else "sync",
            "priority_context": decoded.get("priority", "normal"),
        }
        
        # Add Q-layer context
        if "q_layer" in decoded:
            q_name = decoded["q_layer"]
            context["cognitive_layer"] = q_name
            context["cognitive_group"] = self._get_layer_group(q_name)
        
        return context
    
    def _expand_language(self, state: Dict) -> Dict[str, Any]:
        """Q8: Linguistic expansion to natural language"""
        decoded = state.get("decoded", {})
        
        # Build natural language description
        parts = []
        
        if "action" in decoded:
            parts.append(decoded["action"].capitalize())
        
        if "type" in decoded:
            parts.append(f"a {decoded['type']} task")
        
        if decoded.get("target_agent"):
            parts.append(f"on agent {decoded['target_agent']}")
        
        if "priority" in decoded:
            parts.append(f"with {decoded['priority']} priority")
        
        if decoded.get("stage") is not None:
            parts.append(f"at stage {decoded['stage']}")
        
        natural_language = " ".join(parts) if parts else "Unknown operation"
        
        return {
            "natural_language": natural_language,
            "word_count": len(natural_language.split()),
            "formality": "imperative",
        }
    
    def _expand_logic(self, state: Dict) -> Dict[str, Any]:
        """Q10: Logical validation"""
        decoded = state.get("decoded", {})
        
        valid = True
        issues = []
        
        # Validate action
        if not decoded.get("action"):
            valid = False
            issues.append("Missing action")
        
        # Validate agent target for remote ops
        if decoded.get("target_agent"):
            target = decoded["target_agent"]
            if isinstance(target, int) and not (1 <= target <= 64):
                valid = False
                issues.append(f"Invalid agent ID: {target}")
        
        return {
            "valid": valid,
            "issues": issues,
            "completeness": len(decoded) / 10.0,  # Rough completeness score
        }
    
    def _expand_inference(self, state: Dict) -> Dict[str, Any]:
        """Q11: Infer missing information"""
        decoded = state.get("decoded", {})
        inferred = {}
        
        # Infer defaults
        if not decoded.get("priority"):
            inferred["priority"] = "normal"
        
        if not decoded.get("type") and decoded.get("action"):
            # Infer type from action
            action = decoded["action"]
            if action in ["analyze", "search", "validate"]:
                inferred["type"] = "function"
            else:
                inferred["type"] = "shell"
        
        if not decoded.get("timeout"):
            inferred["timeout"] = 300.0
        
        return {
            "inferred_fields": inferred,
            "inference_count": len(inferred),
        }
    
    def _expand_synthesis(self, state: Dict) -> Dict[str, Any]:
        """Q18: Synthesize complete understanding"""
        decoded = state.get("decoded", {})
        inferred = state.get("expansions", {}).get("Q11_INFERENCE", {}).get("inferred_fields", {})
        context = state.get("expansions", {}).get("Q7_CONTEXT", {})
        
        # Merge all information
        synthesized = {**decoded, **inferred}
        
        return {
            "synthesized_message": synthesized,
            "field_count": len(synthesized),
            "context_applied": bool(context),
        }
    
    def _expand_execution(self, state: Dict) -> Dict[str, Any]:
        """Q23: Prepare for execution"""
        synthesis = state.get("expansions", {}).get("Q18_SYNTHESIS", {})
        message = synthesis.get("synthesized_message", {})
        
        # Build execution plan
        plan = {
            "action": message.get("action", "execute"),
            "type": message.get("type", "shell"),
            "target": message.get("target_agent", "local"),
            "priority": message.get("priority", "normal"),
            "timeout": message.get("timeout", 300.0),
        }
        
        if message.get("command"):
            plan["command"] = message["command"]
        
        if message.get("chain_id"):
            plan["chain_id"] = message["chain_id"]
            plan["stage"] = message.get("stage", 0)
        
        return {
            "execution_plan": plan,
            "ready": bool(plan.get("action")),
        }
    
    def _expand_transcendence(self, state: Dict) -> Dict[str, Any]:
        """Q38: Unified field understanding"""
        execution = state.get("expansions", {}).get("Q23_EXECUTION", {})
        language = state.get("expansions", {}).get("Q8_LANGUAGE", {})
        
        return {
            "unified": True,
            "description": language.get("natural_language", ""),
            "executable": execution.get("ready", False),
            "expansion_complete": True,
        }
    
    def _synthesize_final(self, state: Dict) -> Dict[str, Any]:
        """Create final output"""
        execution = state.get("expansions", {}).get("Q23_EXECUTION", {})
        transcendence = state.get("expansions", {}).get("Q38_TRANSCENDENCE", {})
        
        return {
            "plan": execution.get("execution_plan", {}),
            "description": transcendence.get("description", ""),
            "ready": transcendence.get("executable", False),
            "layers_used": len(state.get("metadata", {}).get("layers_traversed", [])),
        }
    
    def _get_layer_group(self, q_name: str) -> str:
        """Get group for a Q-layer name"""
        try:
            num = int(q_name.replace("q", ""))
            if num <= 9:
                return "FOUNDATION"
            elif num <= 19:
                return "REASONING"
            elif num <= 29:
                return "ACTION"
            else:
                return "META"
        except ValueError:
            return "UNKNOWN"
    
    def get_trace(self) -> List[Dict[str, Any]]:
        """Get expansion trace"""
        return self.trace


# =============================================================================
# MICRO MESSAGE PROTOCOL
# =============================================================================

@dataclass
class MicroMessage:
    """
    Ultra-compact micro-message for agent communication.
    
    Total size: ~20-50 bytes for typical messages
    vs ~200-500 bytes for JSON equivalent
    """
    source: int           # Source agent (1-64) - 1 byte
    target: int           # Target agent (1-64, 0=broadcast) - 1 byte
    action: int           # Action code (0-255) - 1 byte
    task_type: int        # Type code (0-15) - 4 bits
    priority: int         # Priority (0-7) - 3 bits
    flags: int            # Flags - 1 byte
    chain_id: int         # Chain ID (0-65535) - 2 bytes
    stage: int            # Stage (0-255) - 1 byte
    payload_hash: bytes   # Payload hash (4 bytes)
    timestamp: int        # Unix timestamp (4 bytes)
    
    # Action codes
    ACTION_CODES = {
        "execute": 1, "run": 1, "start": 2, "stop": 3, "pause": 4,
        "resume": 5, "send": 6, "receive": 7, "broadcast": 8,
        "scatter": 9, "gather": 10, "merge": 11, "split": 12,
        "chain": 13, "parallel": 14, "transform": 15, "analyze": 16,
        "generate": 17, "validate": 18, "search": 19, "filter": 20,
        "aggregate": 21, "map": 22, "reduce": 23, "echo": 24,
    }
    
    # Type codes
    TYPE_CODES = {
        "shell": 0, "python": 1, "function": 2, "echo": 3,
        "agent": 4, "data": 5, "command": 6, "query": 7,
    }
    
    # Priority codes
    PRIORITY_CODES = {
        "critical": 0, "high": 1, "normal": 2, "low": 3, "background": 4,
    }
    
    def to_bytes(self) -> bytes:
        """Serialize to bytes (16 bytes fixed)"""
        type_priority = (self.task_type << 4) | (self.priority & 0x0F)
        
        return struct.pack(
            '>BBBBBHBi4s',
            self.source,
            self.target,
            self.action,
            type_priority,
            self.flags,
            self.chain_id,
            self.stage,
            self.timestamp,
            self.payload_hash,
        )
    
    @classmethod
    def from_bytes(cls, data: bytes) -> 'MicroMessage':
        """Deserialize from bytes"""
        source, target, action, type_priority, flags, chain_id, stage, timestamp, payload_hash = struct.unpack(
            '>BBBBBHBi4s', data[:16]
        )
        
        return cls(
            source=source,
            target=target,
            action=action,
            task_type=(type_priority >> 4) & 0x0F,
            priority=type_priority & 0x0F,
            flags=flags,
            chain_id=chain_id,
            stage=stage,
            payload_hash=payload_hash,
            timestamp=timestamp,
        )
    
    @classmethod
    def from_dict(cls, msg: Dict[str, Any]) -> 'MicroMessage':
        """Create from dictionary message"""
        action_name = msg.get("action", "execute").lower()
        type_name = msg.get("type", msg.get("task_type", "shell")).lower()
        priority_name = msg.get("priority", "normal").lower()
        
        # Calculate payload hash
        payload = msg.get("payload", msg.get("command", ""))
        if isinstance(payload, dict):
            payload = json.dumps(payload, sort_keys=True)
        payload_hash = hashlib.md5(str(payload).encode()).digest()[:4]
        
        return cls(
            source=msg.get("source_agent", msg.get("agent_id", 0)),
            target=msg.get("target_agent", 0),
            action=cls.ACTION_CODES.get(action_name, 1),
            task_type=cls.TYPE_CODES.get(type_name, 0),
            priority=cls.PRIORITY_CODES.get(priority_name, 2),
            flags=0,
            chain_id=hash(msg.get("chain_id", "")) & 0xFFFF if msg.get("chain_id") else 0,
            stage=msg.get("stage", 0),
            payload_hash=payload_hash,
            timestamp=int(time.time()),
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        # Reverse lookups
        action_name = next((k for k, v in self.ACTION_CODES.items() if v == self.action), "execute")
        type_name = next((k for k, v in self.TYPE_CODES.items() if v == self.task_type), "shell")
        priority_name = next((k for k, v in self.PRIORITY_CODES.items() if v == self.priority), "normal")
        
        return {
            "source_agent": self.source,
            "target_agent": self.target,
            "action": action_name,
            "type": type_name,
            "priority": priority_name,
            "chain_id": self.chain_id if self.chain_id else None,
            "stage": self.stage,
            "timestamp": self.timestamp,
        }


# =============================================================================
# SYMBOLIC PROTOCOL INTERFACE
# =============================================================================

class SymbolicProtocol:
    """
    Main interface for the Q-Symbolic Protocol.
    
    Combines:
      - Symbolic substitution (SymbolicDictionary)
      - G10QR encoding
      - Q-Database conversion
      - Q-Layer expansion
      - Micro-message format
    """
    
    def __init__(self):
        self.q_db = QDatabase()
        self.expansion_engine = QExpansionEngine(self.q_db)
    
    def encode(
        self,
        message: Dict[str, Any],
        format: str = "g10qr",
    ) -> bytes:
        """
        Encode a message using the Q-Symbolic Protocol.
        
        Args:
            message: Full message dictionary
            format: Output format ("g10qr", "micro", "symbolic")
        
        Returns:
            Encoded bytes
        """
        if format == "micro":
            # Ultra-compact 16-byte format
            micro = MicroMessage.from_dict(message)
            return micro.to_bytes()
        
        elif format == "symbolic":
            # Symbolic string (human-readable compact)
            symbolic = self.q_db.encode_message(message)
            return symbolic.encode('utf-8')
        
        else:  # g10qr (default)
            # Symbolic + G10QR binary encoding
            symbolic = self.q_db.encode_message(message)
            return G10QR.encode(
                symbolic,
                compress=True,
                requires_ack=message.get("requires_ack", False),
                chain_id=message.get("chain_id"),
                priority_high=message.get("priority") in ["critical", "high"],
            )
    
    def decode(
        self,
        data: bytes,
        format: str = "g10qr",
        expand: bool = True,
    ) -> Dict[str, Any]:
        """
        Decode a message using the Q-Symbolic Protocol.
        
        Args:
            data: Encoded bytes
            format: Input format ("g10qr", "micro", "symbolic")
            expand: Whether to expand through Q-layers
        
        Returns:
            Decoded message with optional Q-expansion
        """
        if format == "micro":
            micro = MicroMessage.from_bytes(data)
            decoded = micro.to_dict()
        
        elif format == "symbolic":
            symbolic = data.decode('utf-8')
            decoded = self.q_db.decode_message(symbolic)
        
        else:  # g10qr
            payload, metadata = G10QR.decode(data)
            if isinstance(payload, str):
                decoded = self.q_db.decode_message(payload)
                decoded["_g10qr_metadata"] = metadata
            else:
                decoded = payload
        
        # Optional Q-layer expansion
        if expand:
            symbolic = self.q_db.encode_message(decoded)
            expanded = self.expansion_engine.expand(symbolic)
            decoded["_q_expansion"] = expanded
        
        return decoded
    
    def get_compression_ratio(self, message: Dict[str, Any]) -> Dict[str, float]:
        """Calculate compression ratios for different formats"""
        original = json.dumps(message).encode('utf-8')
        original_size = len(original)
        
        g10qr = self.encode(message, "g10qr")
        micro = self.encode(message, "micro")
        symbolic = self.encode(message, "symbolic")
        
        return {
            "original_bytes": original_size,
            "g10qr_bytes": len(g10qr),
            "g10qr_ratio": 1 - (len(g10qr) / original_size),
            "micro_bytes": len(micro),
            "micro_ratio": 1 - (len(micro) / original_size),
            "symbolic_bytes": len(symbolic),
            "symbolic_ratio": 1 - (len(symbolic) / original_size),
        }


# =============================================================================
# DEMO & TESTING
# =============================================================================

def demo():
    """Demonstrate the Q-Symbolic Protocol"""
    print("\n" + "="*70)
    print("  ARIA Q-SYMBOLIC PROTOCOL - ULTRA-COMPACT AGENT MESSAGING")
    print("="*70 + "\n")
    
    protocol = SymbolicProtocol()
    
    # Sample message
    message = {
        "action": "execute",
        "type": "python",
        "priority": "high",
        "agent_id": 42,
        "target_agent": 17,
        "chain_id": "abc123",
        "stage": 3,
        "command": "result = agent_id * 2",
        "merge_strategy": "all",
    }
    
    print("📦 Original Message:")
    print(f"   {json.dumps(message, indent=2)}")
    print(f"   Size: {len(json.dumps(message))} bytes\n")
    
    # Symbolic encoding
    symbolic = protocol.q_db.encode_message(message)
    print("📝 Symbolic Encoding:")
    print(f"   {symbolic}")
    print(f"   Size: {len(symbolic)} bytes\n")
    
    # G10QR encoding
    g10qr = protocol.encode(message, "g10qr")
    print("🔷 G10QR Encoding:")
    print(f"   {g10qr.hex()}")
    print(f"   Size: {len(g10qr)} bytes\n")
    
    # Micro message
    micro = protocol.encode(message, "micro")
    print("⚡ Micro Message (16 bytes):")
    print(f"   {micro.hex()}")
    print(f"   Size: {len(micro)} bytes\n")
    
    # Compression ratios
    ratios = protocol.get_compression_ratio(message)
    print("📊 Compression Ratios:")
    print(f"   Original:  {ratios['original_bytes']} bytes")
    print(f"   G10QR:     {ratios['g10qr_bytes']} bytes ({ratios['g10qr_ratio']*100:.1f}% reduction)")
    print(f"   Symbolic:  {ratios['symbolic_bytes']} bytes ({ratios['symbolic_ratio']*100:.1f}% reduction)")
    print(f"   Micro:     {ratios['micro_bytes']} bytes ({ratios['micro_ratio']*100:.1f}% reduction)\n")
    
    # Q-Layer Expansion
    print("🔄 Q-Layer Expansion (Q0 → Q38):")
    expanded = protocol.expansion_engine.expand(symbolic)
    
    for layer_name, layer_data in list(expanded.get("expansions", {}).items())[:5]:
        print(f"   {layer_name}: {json.dumps(layer_data)[:60]}...")
    
    print(f"\n   Final Description: {expanded['final']['description']}")
    print(f"   Layers Traversed: {expanded['final']['layers_used']}")
    print(f"   Ready for Execution: {expanded['final']['ready']}")
    
    # Round-trip test
    print("\n🔁 Round-Trip Decode Test:")
    decoded = protocol.decode(g10qr, "g10qr", expand=False)
    print(f"   Decoded: {decoded}")
    
    print("\n✅ Q-Symbolic Protocol Demo Complete!")
    
    return expanded


if __name__ == "__main__":
    demo()
