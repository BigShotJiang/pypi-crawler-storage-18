"""
ARIA Security Scanner v1.0.0

Code security analysis and vulnerability detection.

Features:
  - Pattern-based vulnerability detection
  - Secret/credential detection
  - Dependency vulnerability checking
  - Security best practices validation
"""

import os
import re
import json
import hashlib
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Set, Tuple
from enum import Enum
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed


# =============================================================================
# ENUMS AND DATACLASSES
# =============================================================================

class Severity(str, Enum):
    """Finding severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class FindingType(str, Enum):
    """Types of security findings"""
    SECRET = "secret"
    VULNERABILITY = "vulnerability"
    BAD_PRACTICE = "bad_practice"
    INSECURE_CONFIG = "insecure_config"
    DEPENDENCY = "dependency"
    HARDCODED_CRED = "hardcoded_credential"


@dataclass
class SecurityFinding:
    """A security finding/issue"""
    type: FindingType
    severity: Severity
    title: str
    description: str
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    code_snippet: Optional[str] = None
    recommendation: Optional[str] = None
    cwe_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "file": self.file_path,
            "line": self.line_number,
            "snippet": self.code_snippet[:100] if self.code_snippet else None,
            "recommendation": self.recommendation,
            "cwe": self.cwe_id,
        }


@dataclass
class ScanResult:
    """Result of a security scan"""
    scan_time: float
    files_scanned: int
    findings: List[SecurityFinding]
    summary: Dict[str, int] = field(default_factory=dict)
    
    @property
    def critical_count(self) -> int:
        return len([f for f in self.findings if f.severity == Severity.CRITICAL])
    
    @property
    def high_count(self) -> int:
        return len([f for f in self.findings if f.severity == Severity.HIGH])
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "scan_time_seconds": round(self.scan_time, 2),
            "files_scanned": self.files_scanned,
            "total_findings": len(self.findings),
            "critical": self.critical_count,
            "high": self.high_count,
            "summary": self.summary,
            "findings": [f.to_dict() for f in self.findings],
        }


# =============================================================================
# SECURITY PATTERNS
# =============================================================================

# Secret patterns (regex, description, severity)
SECRET_PATTERNS = [
    # API Keys
    (r'(?i)(api[_-]?key|apikey)\s*[=:]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?', "API Key", Severity.HIGH),
    (r'(?i)(secret[_-]?key|secretkey)\s*[=:]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?', "Secret Key", Severity.CRITICAL),
    (r'(?i)(access[_-]?key|accesskey)\s*[=:]\s*["\']?([a-zA-Z0-9_\-]{16,})["\']?', "Access Key", Severity.HIGH),
    
    # AWS
    (r'AKIA[0-9A-Z]{16}', "AWS Access Key ID", Severity.CRITICAL),
    (r'(?i)aws[_-]?secret[_-]?access[_-]?key\s*[=:]\s*["\']?([a-zA-Z0-9/+=]{40})["\']?', "AWS Secret Key", Severity.CRITICAL),
    
    # Azure
    (r'(?i)(azure|az)[_-]?(storage|account)[_-]?key\s*[=:]\s*["\']?([a-zA-Z0-9/+=]{40,})["\']?', "Azure Storage Key", Severity.CRITICAL),
    
    # GitHub
    (r'gh[pousr]_[A-Za-z0-9_]{36,}', "GitHub Token", Severity.CRITICAL),
    (r'github_pat_[a-zA-Z0-9]{22}_[a-zA-Z0-9]{59}', "GitHub PAT", Severity.CRITICAL),
    
    # Generic tokens
    (r'(?i)(token|auth[_-]?token)\s*[=:]\s*["\']?([a-zA-Z0-9_\-]{20,})["\']?', "Auth Token", Severity.HIGH),
    (r'(?i)(bearer)\s+([a-zA-Z0-9_\-\.]+)', "Bearer Token", Severity.HIGH),
    
    # Passwords
    (r'(?i)(password|passwd|pwd)\s*[=:]\s*["\']([^"\']{6,})["\']', "Hardcoded Password", Severity.CRITICAL),
    (r'(?i)(password|passwd|pwd)\s*[=:]\s*([^\s"\']{6,})\s', "Hardcoded Password", Severity.CRITICAL),
    
    # Private keys
    (r'-----BEGIN (RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----', "Private Key", Severity.CRITICAL),
    (r'-----BEGIN PGP PRIVATE KEY BLOCK-----', "PGP Private Key", Severity.CRITICAL),
    
    # Database
    (r'(?i)(mongodb|mysql|postgres|redis)://[^\s"\']+', "Database Connection String", Severity.HIGH),
    (r'(?i)jdbc:[a-z]+://[^\s"\']+', "JDBC Connection String", Severity.HIGH),
    
    # Slack
    (r'xox[baprs]-[0-9]{10,13}-[0-9]{10,13}-[a-zA-Z0-9]{24}', "Slack Token", Severity.HIGH),
    
    # Stripe
    (r'sk_live_[a-zA-Z0-9]{24,}', "Stripe Live Key", Severity.CRITICAL),
    (r'sk_test_[a-zA-Z0-9]{24,}', "Stripe Test Key", Severity.MEDIUM),
    
    # SendGrid
    (r'SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}', "SendGrid API Key", Severity.HIGH),
    
    # Twilio
    (r'SK[a-f0-9]{32}', "Twilio API Key", Severity.HIGH),
]

# Vulnerability patterns
VULN_PATTERNS = [
    # SQL Injection
    (r'(?i)(execute|cursor\.execute|query)\s*\(\s*["\'][^"\']*%s', "Potential SQL Injection (Python)", Severity.HIGH, "CWE-89"),
    (r'(?i)\.query\s*\([^)]*\+', "Potential SQL Injection (JS)", Severity.HIGH, "CWE-89"),
    (r'(?i)SELECT.*FROM.*WHERE.*\+', "Potential SQL Injection", Severity.HIGH, "CWE-89"),
    
    # Command Injection
    (r'(?i)(os\.system|subprocess\.call|subprocess\.run|shell=True)', "Command Execution", Severity.MEDIUM, "CWE-78"),
    (r'(?i)eval\s*\([^)]+\)', "Eval Usage", Severity.HIGH, "CWE-94"),
    (r'(?i)exec\s*\([^)]+\)', "Exec Usage", Severity.HIGH, "CWE-94"),
    
    # Path Traversal
    (r'open\s*\([^)]*\+', "Potential Path Traversal", Severity.MEDIUM, "CWE-22"),
    (r'(?i)\.\./', "Directory Traversal Pattern", Severity.LOW, "CWE-22"),
    
    # XSS
    (r'(?i)innerHTML\s*=', "InnerHTML Assignment (XSS Risk)", Severity.MEDIUM, "CWE-79"),
    (r'(?i)document\.write\s*\(', "Document.write (XSS Risk)", Severity.MEDIUM, "CWE-79"),
    (r'(?i)dangerouslySetInnerHTML', "React dangerouslySetInnerHTML", Severity.MEDIUM, "CWE-79"),
    
    # Insecure
    (r'(?i)verify\s*=\s*False', "SSL Verification Disabled", Severity.HIGH, "CWE-295"),
    (r'(?i)ssl\s*=\s*False', "SSL Disabled", Severity.HIGH, "CWE-319"),
    (r'(?i)http://', "Insecure HTTP URL", Severity.LOW, "CWE-319"),
    
    # Cryptography
    (r'(?i)(md5|sha1)\s*\(', "Weak Hash Algorithm", Severity.MEDIUM, "CWE-328"),
    (r'(?i)DES|3DES|RC4', "Weak Encryption Algorithm", Severity.HIGH, "CWE-327"),
    (r'(?i)random\.(random|randint|choice)', "Insecure Random (Python)", Severity.MEDIUM, "CWE-330"),
    (r'Math\.random\s*\(', "Insecure Random (JS)", Severity.MEDIUM, "CWE-330"),
    
    # Debug/Development
    (r'(?i)debug\s*=\s*True', "Debug Mode Enabled", Severity.MEDIUM, "CWE-489"),
    (r'(?i)console\.log\s*\(', "Console.log in Code", Severity.INFO, None),
    (r'(?i)print\s*\([^)]*password', "Possible Password Logging", Severity.HIGH, "CWE-532"),
    
    # CORS
    (r'(?i)Access-Control-Allow-Origin.*\*', "Permissive CORS", Severity.MEDIUM, "CWE-942"),
]

# Files to skip
SKIP_PATTERNS = [
    r'\.git/',
    r'node_modules/',
    r'__pycache__/',
    r'\.pyc$',
    r'\.min\.js$',
    r'\.map$',
    r'package-lock\.json$',
    r'yarn\.lock$',
    r'\.png$|\.jpg$|\.gif$|\.ico$',
    r'\.woff$|\.ttf$|\.eot$',
    r'\.pdf$|\.doc$|\.xls$',
]


# =============================================================================
# SECURITY SCANNER
# =============================================================================

class SecurityScanner:
    """
    Code security scanner
    
    Usage:
        scanner = SecurityScanner()
        
        # Scan a directory
        result = scanner.scan_directory("/path/to/project")
        
        # Scan a single file
        findings = scanner.scan_file("/path/to/file.py")
        
        # Check for secrets
        secrets = scanner.find_secrets(code_content)
    """
    
    def __init__(
        self,
        skip_patterns: Optional[List[str]] = None,
        max_file_size: int = 1024 * 1024,  # 1MB
        max_workers: int = 4,
    ):
        self.skip_patterns = [re.compile(p) for p in (skip_patterns or SKIP_PATTERNS)]
        self.max_file_size = max_file_size
        self.max_workers = max_workers
        
        # Compile patterns
        self.secret_patterns = [
            (re.compile(p, re.IGNORECASE), desc, sev)
            for p, desc, sev in SECRET_PATTERNS
        ]
        self.vuln_patterns = [
            (re.compile(p, re.IGNORECASE), desc, sev, cwe)
            for p, desc, sev, cwe in VULN_PATTERNS
        ]
    
    def _should_skip(self, filepath: str) -> bool:
        """Check if file should be skipped"""
        for pattern in self.skip_patterns:
            if pattern.search(filepath):
                return True
        return False
    
    def _is_text_file(self, filepath: Path) -> bool:
        """Check if file is likely a text file"""
        text_extensions = {
            ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".h",
            ".cs", ".go", ".rb", ".php", ".rs", ".swift", ".kt", ".scala",
            ".json", ".yaml", ".yml", ".toml", ".xml", ".html", ".css",
            ".md", ".txt", ".sh", ".bash", ".zsh", ".ps1", ".bat", ".cmd",
            ".sql", ".graphql", ".proto", ".env", ".ini", ".cfg", ".conf",
        }
        return filepath.suffix.lower() in text_extensions
    
    # =========================================================================
    # SCANNING
    # =========================================================================
    
    def find_secrets(self, content: str, filepath: Optional[str] = None) -> List[SecurityFinding]:
        """Find secrets/credentials in content"""
        findings = []
        lines = content.split("\n")
        
        for i, line in enumerate(lines, 1):
            # Skip comments and empty lines
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or stripped.startswith("//"):
                continue
            
            for pattern, desc, severity in self.secret_patterns:
                if pattern.search(line):
                    findings.append(SecurityFinding(
                        type=FindingType.SECRET,
                        severity=severity,
                        title=f"Potential {desc} Detected",
                        description=f"Found pattern matching {desc} in code",
                        file_path=filepath,
                        line_number=i,
                        code_snippet=line[:80] + "..." if len(line) > 80 else line,
                        recommendation="Remove secret and use environment variables or secret manager",
                    ))
                    break  # One finding per line
        
        return findings
    
    def find_vulnerabilities(self, content: str, filepath: Optional[str] = None) -> List[SecurityFinding]:
        """Find vulnerability patterns in content"""
        findings = []
        lines = content.split("\n")
        
        for i, line in enumerate(lines, 1):
            for pattern, desc, severity, cwe in self.vuln_patterns:
                if pattern.search(line):
                    findings.append(SecurityFinding(
                        type=FindingType.VULNERABILITY,
                        severity=severity,
                        title=desc,
                        description=f"Potential security issue: {desc}",
                        file_path=filepath,
                        line_number=i,
                        code_snippet=line[:80] + "..." if len(line) > 80 else line,
                        cwe_id=cwe,
                        recommendation=self._get_recommendation(desc),
                    ))
        
        return findings
    
    def _get_recommendation(self, finding_type: str) -> str:
        """Get recommendation for finding type"""
        recommendations = {
            "SQL Injection": "Use parameterized queries or prepared statements",
            "Command Execution": "Avoid using shell=True; validate and sanitize input",
            "Eval Usage": "Avoid eval(); use safer alternatives",
            "Path Traversal": "Validate file paths; use os.path.basename()",
            "XSS": "Sanitize user input; use proper encoding",
            "SSL": "Enable SSL/TLS verification",
            "Weak Hash": "Use SHA-256 or stronger; use bcrypt for passwords",
            "Weak Encryption": "Use AES-256 or stronger encryption",
            "Insecure Random": "Use secrets module for cryptographic randomness",
            "Debug Mode": "Disable debug mode in production",
            "CORS": "Restrict CORS to specific origins",
        }
        
        for key, rec in recommendations.items():
            if key.lower() in finding_type.lower():
                return rec
        
        return "Review and fix the security issue"
    
    def scan_file(self, filepath: Path) -> List[SecurityFinding]:
        """Scan a single file for security issues"""
        filepath = Path(filepath)
        
        if not filepath.exists():
            return []
        
        if self._should_skip(str(filepath)):
            return []
        
        if not self._is_text_file(filepath):
            return []
        
        if filepath.stat().st_size > self.max_file_size:
            return []
        
        try:
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except Exception:
            return []
        
        findings = []
        findings.extend(self.find_secrets(content, str(filepath)))
        findings.extend(self.find_vulnerabilities(content, str(filepath)))
        
        return findings
    
    def scan_directory(
        self,
        directory: Path,
        recursive: bool = True,
        file_types: Optional[List[str]] = None,
    ) -> ScanResult:
        """Scan a directory for security issues"""
        directory = Path(directory)
        start_time = time.time()
        all_findings = []
        files_scanned = 0
        
        # Collect files
        if recursive:
            files = list(directory.rglob("*"))
        else:
            files = list(directory.glob("*"))
        
        files = [f for f in files if f.is_file()]
        
        if file_types:
            files = [f for f in files if f.suffix.lower() in file_types]
        
        # Scan with thread pool
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_file = {
                executor.submit(self.scan_file, f): f
                for f in files
            }
            
            for future in as_completed(future_to_file):
                try:
                    findings = future.result()
                    all_findings.extend(findings)
                    files_scanned += 1
                except Exception:
                    pass
        
        # Build summary
        summary = {}
        for f in all_findings:
            key = f"{f.type.value}_{f.severity.value}"
            summary[key] = summary.get(key, 0) + 1
        
        return ScanResult(
            scan_time=time.time() - start_time,
            files_scanned=files_scanned,
            findings=all_findings,
            summary=summary,
        )
    
    # =========================================================================
    # SPECIALIZED SCANS
    # =========================================================================
    
    def scan_git_history(self, repo_path: Path, max_commits: int = 100) -> List[SecurityFinding]:
        """Scan git history for leaked secrets"""
        import subprocess
        
        findings = []
        repo_path = Path(repo_path)
        
        try:
            result = subprocess.run(
                ["git", "log", f"-{max_commits}", "--diff-filter=A", "--name-only", "--pretty=format:%H"],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=60,
            )
            
            if result.returncode != 0:
                return findings
            
            # Get list of added files from history
            lines = result.stdout.strip().split("\n")
            current_commit = None
            
            for line in lines:
                if len(line) == 40:  # Commit hash
                    current_commit = line
                elif line and current_commit:
                    # Check file content at that commit
                    try:
                        file_result = subprocess.run(
                            ["git", "show", f"{current_commit}:{line}"],
                            cwd=repo_path,
                            capture_output=True,
                            text=True,
                            timeout=10,
                        )
                        if file_result.returncode == 0:
                            secrets = self.find_secrets(file_result.stdout, f"{line} (commit: {current_commit[:8]})")
                            findings.extend(secrets)
                    except Exception:
                        pass
        
        except Exception:
            pass
        
        return findings
    
    def check_env_file(self, filepath: Path) -> List[SecurityFinding]:
        """Check .env file for issues"""
        findings = []
        filepath = Path(filepath)
        
        if not filepath.exists():
            return findings
        
        try:
            with open(filepath, "r") as f:
                content = f.read()
        except Exception:
            return findings
        
        lines = content.split("\n")
        
        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            
            if "=" in line:
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip("\"'")
                
                # Check for empty values
                if not value:
                    findings.append(SecurityFinding(
                        type=FindingType.INSECURE_CONFIG,
                        severity=Severity.INFO,
                        title="Empty Environment Variable",
                        description=f"Variable {key} has no value",
                        file_path=str(filepath),
                        line_number=i,
                    ))
                
                # Check for placeholder values
                if value.lower() in ["changeme", "xxx", "password", "secret", "your_key_here"]:
                    findings.append(SecurityFinding(
                        type=FindingType.INSECURE_CONFIG,
                        severity=Severity.HIGH,
                        title="Placeholder Credential",
                        description=f"Variable {key} appears to have a placeholder value",
                        file_path=str(filepath),
                        line_number=i,
                        recommendation="Replace with actual secure value",
                    ))
        
        return findings


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def quick_scan(directory: str) -> Dict[str, Any]:
    """Quick security scan of a directory"""
    scanner = SecurityScanner()
    result = scanner.scan_directory(Path(directory))
    return result.to_dict()


def find_secrets_in_file(filepath: str) -> List[Dict[str, Any]]:
    """Find secrets in a single file"""
    scanner = SecurityScanner()
    findings = scanner.scan_file(Path(filepath))
    return [f.to_dict() for f in findings if f.type == FindingType.SECRET]


def scan_for_vulnerabilities(filepath: str) -> List[Dict[str, Any]]:
    """Scan file for vulnerabilities"""
    scanner = SecurityScanner()
    findings = scanner.scan_file(Path(filepath))
    return [f.to_dict() for f in findings if f.type == FindingType.VULNERABILITY]
