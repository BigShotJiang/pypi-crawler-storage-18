"""
ARIA Daemon Scout v1.0.0

Background service for mesh node discovery and handshaking.

Features:
  - Automatic peer discovery
  - Secure handshake protocol
  - Persistent connection management
  - Health monitoring
  - Auto-reconnection
"""

import os
import json
import time
import socket
import hashlib
import asyncio
import threading
import logging
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List, Callable, Set, Tuple
from enum import Enum
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("aria.scout")


# =============================================================================
# ENUMS AND DATACLASSES
# =============================================================================

class PeerState(str, Enum):
    """Peer connection states"""
    DISCOVERED = "discovered"
    HANDSHAKING = "handshaking"
    CONNECTED = "connected"
    AUTHENTICATED = "authenticated"
    DISCONNECTED = "disconnected"
    FAILED = "failed"
    BLOCKED = "blocked"


class HandshakeResult(str, Enum):
    """Handshake results"""
    SUCCESS = "success"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    ERROR = "error"
    VERSION_MISMATCH = "version_mismatch"
    AUTH_FAILED = "auth_failed"


class DiscoveryMethod(str, Enum):
    """How peer was discovered"""
    BROADCAST = "broadcast"
    TAILSCALE = "tailscale"
    MANUAL = "manual"
    QR_SCAN = "qr_scan"
    MDNS = "mdns"
    SAVED = "saved"


@dataclass
class PeerIdentity:
    """Peer identity information"""
    peer_id: str
    name: str
    host: str
    port: int
    version: str = "1.0.0"
    capabilities: List[str] = field(default_factory=list)
    platform: str = ""
    public_key: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PeerIdentity":
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class Peer:
    """A discovered peer"""
    identity: PeerIdentity
    state: PeerState = PeerState.DISCOVERED
    discovery_method: DiscoveryMethod = DiscoveryMethod.BROADCAST
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    last_handshake: float = 0
    handshake_attempts: int = 0
    latency_ms: float = 0
    is_tailscale: bool = False
    tailscale_name: Optional[str] = None
    
    @property
    def address(self) -> str:
        return f"{self.identity.host}:{self.identity.port}"
    
    @property
    def age(self) -> float:
        return time.time() - self.first_seen
    
    @property
    def time_since_seen(self) -> float:
        return time.time() - self.last_seen
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "identity": self.identity.to_dict(),
            "state": self.state.value,
            "discovery_method": self.discovery_method.value,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "last_handshake": self.last_handshake,
            "handshake_attempts": self.handshake_attempts,
            "latency_ms": self.latency_ms,
            "is_tailscale": self.is_tailscale,
            "tailscale_name": self.tailscale_name,
        }


@dataclass
class HandshakeMessage:
    """Handshake protocol message"""
    type: str  # "hello", "challenge", "response", "ack", "reject"
    sender_id: str
    timestamp: float
    version: str = "1.0.0"
    payload: Dict[str, Any] = field(default_factory=dict)
    signature: Optional[str] = None
    
    def to_json(self) -> str:
        return json.dumps(asdict(self))
    
    @classmethod
    def from_json(cls, data: str) -> "HandshakeMessage":
        parsed = json.loads(data)
        return cls(**parsed)
    
    def sign(self, secret: str) -> str:
        """Generate signature"""
        content = f"{self.type}:{self.sender_id}:{self.timestamp}:{json.dumps(self.payload)}"
        self.signature = hashlib.sha256(f"{content}:{secret}".encode()).hexdigest()
        return self.signature
    
    def verify(self, secret: str) -> bool:
        """Verify signature"""
        content = f"{self.type}:{self.sender_id}:{self.timestamp}:{json.dumps(self.payload)}"
        expected = hashlib.sha256(f"{content}:{secret}".encode()).hexdigest()
        return self.signature == expected


# =============================================================================
# SCOUT DAEMON
# =============================================================================

class ScoutDaemon:
    """
    Background service for peer discovery and handshaking
    
    Usage:
        scout = ScoutDaemon(identity, port=8766)
        
        # Add callbacks
        scout.on_peer_discovered(lambda peer: print(f"Found: {peer.identity.name}"))
        scout.on_peer_connected(lambda peer: print(f"Connected: {peer.identity.name}"))
        
        # Start daemon
        scout.start()
        
        # Manual discovery
        scout.discover_network()
        
        # Connect to peer
        scout.handshake(peer)
    """
    
    # Protocol constants
    BROADCAST_PORT = 8766
    HANDSHAKE_TIMEOUT = 10.0
    DISCOVERY_INTERVAL = 30.0
    HEARTBEAT_INTERVAL = 15.0
    MAX_HANDSHAKE_ATTEMPTS = 3
    
    def __init__(
        self,
        identity: PeerIdentity,
        port: int = 8766,
        shared_secret: Optional[str] = None,
    ):
        self.identity = identity
        self.port = port
        self.shared_secret = shared_secret or self._generate_secret()
        
        # Peer management
        self.peers: Dict[str, Peer] = {}
        self.blocked_peers: Set[str] = set()
        
        # State
        self._running = False
        self._discovery_thread: Optional[threading.Thread] = None
        self._listener_thread: Optional[threading.Thread] = None
        self._heartbeat_thread: Optional[threading.Thread] = None
        
        # Callbacks
        self._on_peer_discovered: List[Callable[[Peer], None]] = []
        self._on_peer_connected: List[Callable[[Peer], None]] = []
        self._on_peer_disconnected: List[Callable[[Peer], None]] = []
        self._on_message: List[Callable[[Peer, Dict], None]] = []
        
        # Persistence
        self.data_dir = Path.home() / ".aria" / "scout"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Load saved peers
        self._load_peers()
    
    def _generate_secret(self) -> str:
        """Generate shared secret"""
        return hashlib.sha256(f"{self.identity.peer_id}{time.time()}".encode()).hexdigest()[:32]
    
    # =========================================================================
    # CALLBACKS
    # =========================================================================
    
    def on_peer_discovered(self, callback: Callable[[Peer], None]):
        """Register callback for peer discovery"""
        self._on_peer_discovered.append(callback)
    
    def on_peer_connected(self, callback: Callable[[Peer], None]):
        """Register callback for peer connection"""
        self._on_peer_connected.append(callback)
    
    def on_peer_disconnected(self, callback: Callable[[Peer], None]):
        """Register callback for peer disconnection"""
        self._on_peer_disconnected.append(callback)
    
    def on_message(self, callback: Callable[[Peer, Dict], None]):
        """Register callback for messages"""
        self._on_message.append(callback)
    
    def _emit_discovered(self, peer: Peer):
        for cb in self._on_peer_discovered:
            try:
                cb(peer)
            except Exception as e:
                logger.error(f"Callback error: {e}")
    
    def _emit_connected(self, peer: Peer):
        for cb in self._on_peer_connected:
            try:
                cb(peer)
            except Exception as e:
                logger.error(f"Callback error: {e}")
    
    def _emit_disconnected(self, peer: Peer):
        for cb in self._on_peer_disconnected:
            try:
                cb(peer)
            except Exception as e:
                logger.error(f"Callback error: {e}")
    
    # =========================================================================
    # DISCOVERY
    # =========================================================================
    
    def discover_network(self, timeout: float = 3.0) -> List[Peer]:
        """Broadcast discovery request on local network"""
        logger.info("Starting network discovery...")
        discovered = []
        
        # Create broadcast message
        msg = HandshakeMessage(
            type="discover",
            sender_id=self.identity.peer_id,
            timestamp=time.time(),
            payload={"name": self.identity.name, "port": self.identity.port},
        )
        
        try:
            # UDP broadcast
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.settimeout(timeout)
            
            # Broadcast to local network
            sock.sendto(msg.to_json().encode(), ('<broadcast>', self.BROADCAST_PORT))
            
            # Collect responses
            start = time.time()
            while time.time() - start < timeout:
                try:
                    data, addr = sock.recvfrom(4096)
                    response = HandshakeMessage.from_json(data.decode())
                    
                    if response.type == "announce" and response.sender_id != self.identity.peer_id:
                        peer = self._process_announce(response, addr[0])
                        if peer:
                            discovered.append(peer)
                except socket.timeout:
                    break
                except Exception as e:
                    logger.debug(f"Discovery response error: {e}")
            
            sock.close()
        except Exception as e:
            logger.error(f"Discovery broadcast error: {e}")
        
        # Also check Tailscale peers
        tailscale_peers = self._discover_tailscale()
        discovered.extend(tailscale_peers)
        
        logger.info(f"Discovered {len(discovered)} peers")
        return discovered
    
    def _discover_tailscale(self) -> List[Peer]:
        """Discover peers via Tailscale"""
        peers = []
        
        try:
            import subprocess
            result = subprocess.run(
                ["tailscale", "status", "--json"],
                capture_output=True, text=True, timeout=5
            )
            
            if result.returncode == 0:
                status = json.loads(result.stdout)
                for ip, peer_info in status.get("Peer", {}).items():
                    if peer_info.get("Online"):
                        peer_id = hashlib.md5(ip.encode()).hexdigest()[:12]
                        
                        if peer_id not in self.peers:
                            identity = PeerIdentity(
                                peer_id=peer_id,
                                name=peer_info.get("HostName", ip),
                                host=ip,
                                port=8765,  # Default mesh port
                            )
                            peer = Peer(
                                identity=identity,
                                discovery_method=DiscoveryMethod.TAILSCALE,
                                is_tailscale=True,
                                tailscale_name=peer_info.get("HostName"),
                            )
                            self.peers[peer_id] = peer
                            peers.append(peer)
                            self._emit_discovered(peer)
        except Exception as e:
            logger.debug(f"Tailscale discovery error: {e}")
        
        return peers
    
    def _process_announce(self, msg: HandshakeMessage, host: str) -> Optional[Peer]:
        """Process announce message"""
        peer_id = msg.sender_id
        
        if peer_id in self.blocked_peers:
            return None
        
        if peer_id in self.peers:
            # Update existing
            self.peers[peer_id].last_seen = time.time()
            return None
        
        # New peer
        identity = PeerIdentity(
            peer_id=peer_id,
            name=msg.payload.get("name", host),
            host=host,
            port=msg.payload.get("port", 8765),
            version=msg.version,
            capabilities=msg.payload.get("capabilities", []),
        )
        
        peer = Peer(
            identity=identity,
            discovery_method=DiscoveryMethod.BROADCAST,
        )
        
        self.peers[peer_id] = peer
        self._emit_discovered(peer)
        
        return peer
    
    # =========================================================================
    # HANDSHAKE
    # =========================================================================
    
    def handshake(self, peer: Peer) -> HandshakeResult:
        """Perform handshake with peer"""
        if peer.identity.peer_id in self.blocked_peers:
            return HandshakeResult.REJECTED
        
        if peer.handshake_attempts >= self.MAX_HANDSHAKE_ATTEMPTS:
            peer.state = PeerState.FAILED
            return HandshakeResult.ERROR
        
        peer.state = PeerState.HANDSHAKING
        peer.handshake_attempts += 1
        
        try:
            start = time.time()
            
            # Step 1: Send HELLO
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.HANDSHAKE_TIMEOUT)
            sock.connect((peer.identity.host, peer.identity.port))
            
            hello = HandshakeMessage(
                type="hello",
                sender_id=self.identity.peer_id,
                timestamp=time.time(),
                payload={
                    "name": self.identity.name,
                    "version": self.identity.version,
                    "capabilities": self.identity.capabilities,
                },
            )
            hello.sign(self.shared_secret)
            sock.send(hello.to_json().encode())
            
            # Step 2: Receive CHALLENGE
            data = sock.recv(4096)
            challenge = HandshakeMessage.from_json(data.decode())
            
            if challenge.type == "reject":
                sock.close()
                peer.state = PeerState.FAILED
                return HandshakeResult.REJECTED
            
            if challenge.type != "challenge":
                sock.close()
                peer.state = PeerState.FAILED
                return HandshakeResult.ERROR
            
            # Step 3: Send RESPONSE
            challenge_value = challenge.payload.get("challenge")
            response_value = hashlib.sha256(
                f"{challenge_value}:{self.shared_secret}".encode()
            ).hexdigest()
            
            response = HandshakeMessage(
                type="response",
                sender_id=self.identity.peer_id,
                timestamp=time.time(),
                payload={"response": response_value},
            )
            response.sign(self.shared_secret)
            sock.send(response.to_json().encode())
            
            # Step 4: Receive ACK
            data = sock.recv(4096)
            ack = HandshakeMessage.from_json(data.decode())
            
            sock.close()
            
            if ack.type == "ack":
                peer.state = PeerState.CONNECTED
                peer.last_handshake = time.time()
                peer.latency_ms = (time.time() - start) * 1000
                self._emit_connected(peer)
                self._save_peers()
                return HandshakeResult.SUCCESS
            else:
                peer.state = PeerState.FAILED
                return HandshakeResult.AUTH_FAILED
        
        except socket.timeout:
            peer.state = PeerState.DISCONNECTED
            return HandshakeResult.TIMEOUT
        
        except Exception as e:
            logger.error(f"Handshake error: {e}")
            peer.state = PeerState.FAILED
            return HandshakeResult.ERROR
    
    def _handle_handshake_request(self, conn: socket.socket, addr: Tuple[str, int]):
        """Handle incoming handshake request"""
        try:
            conn.settimeout(self.HANDSHAKE_TIMEOUT)
            
            # Receive HELLO
            data = conn.recv(4096)
            hello = HandshakeMessage.from_json(data.decode())
            
            if hello.type != "hello":
                conn.close()
                return
            
            peer_id = hello.sender_id
            
            if peer_id in self.blocked_peers:
                reject = HandshakeMessage(
                    type="reject",
                    sender_id=self.identity.peer_id,
                    timestamp=time.time(),
                    payload={"reason": "blocked"},
                )
                conn.send(reject.to_json().encode())
                conn.close()
                return
            
            # Send CHALLENGE
            import secrets
            challenge_value = secrets.token_hex(32)
            
            challenge = HandshakeMessage(
                type="challenge",
                sender_id=self.identity.peer_id,
                timestamp=time.time(),
                payload={"challenge": challenge_value},
            )
            conn.send(challenge.to_json().encode())
            
            # Receive RESPONSE
            data = conn.recv(4096)
            response = HandshakeMessage.from_json(data.decode())
            
            # Verify response
            expected = hashlib.sha256(
                f"{challenge_value}:{self.shared_secret}".encode()
            ).hexdigest()
            
            if response.payload.get("response") == expected:
                # Send ACK
                ack = HandshakeMessage(
                    type="ack",
                    sender_id=self.identity.peer_id,
                    timestamp=time.time(),
                    payload={"status": "connected"},
                )
                conn.send(ack.to_json().encode())
                
                # Register peer
                identity = PeerIdentity(
                    peer_id=peer_id,
                    name=hello.payload.get("name", addr[0]),
                    host=addr[0],
                    port=hello.payload.get("port", 8765),
                    version=hello.version,
                    capabilities=hello.payload.get("capabilities", []),
                )
                
                if peer_id not in self.peers:
                    peer = Peer(identity=identity, discovery_method=DiscoveryMethod.MANUAL)
                    self.peers[peer_id] = peer
                
                self.peers[peer_id].state = PeerState.CONNECTED
                self.peers[peer_id].last_handshake = time.time()
                self._emit_connected(self.peers[peer_id])
            else:
                reject = HandshakeMessage(
                    type="reject",
                    sender_id=self.identity.peer_id,
                    timestamp=time.time(),
                    payload={"reason": "auth_failed"},
                )
                conn.send(reject.to_json().encode())
            
            conn.close()
        
        except Exception as e:
            logger.error(f"Handshake handler error: {e}")
            try:
                conn.close()
            except:
                pass
    
    # =========================================================================
    # DAEMON LIFECYCLE
    # =========================================================================
    
    def start(self):
        """Start the scout daemon"""
        if self._running:
            return
        
        self._running = True
        logger.info(f"Starting Scout Daemon: {self.identity.name} ({self.identity.peer_id})")
        
        # Start listener thread
        self._listener_thread = threading.Thread(target=self._listener_loop, daemon=True)
        self._listener_thread.start()
        
        # Start discovery thread
        self._discovery_thread = threading.Thread(target=self._discovery_loop, daemon=True)
        self._discovery_thread.start()
        
        # Start heartbeat thread
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()
        
        logger.info("Scout Daemon started")
    
    def stop(self):
        """Stop the scout daemon"""
        logger.info("Stopping Scout Daemon...")
        self._running = False
        self._save_peers()
        
        # Wait for threads
        for thread in [self._listener_thread, self._discovery_thread, self._heartbeat_thread]:
            if thread and thread.is_alive():
                thread.join(timeout=2)
        
        logger.info("Scout Daemon stopped")
    
    def _listener_loop(self):
        """Listen for incoming connections"""
        try:
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind(('0.0.0.0', self.port))
            server.listen(5)
            server.settimeout(1.0)
            
            logger.info(f"Listening on port {self.port}")
            
            while self._running:
                try:
                    conn, addr = server.accept()
                    threading.Thread(
                        target=self._handle_handshake_request,
                        args=(conn, addr),
                        daemon=True
                    ).start()
                except socket.timeout:
                    continue
                except Exception as e:
                    logger.error(f"Listener error: {e}")
            
            server.close()
        except Exception as e:
            logger.error(f"Failed to start listener: {e}")
    
    def _discovery_loop(self):
        """Periodic discovery"""
        while self._running:
            try:
                self.discover_network()
            except Exception as e:
                logger.error(f"Discovery error: {e}")
            
            time.sleep(self.DISCOVERY_INTERVAL)
    
    def _heartbeat_loop(self):
        """Periodic heartbeat to connected peers"""
        while self._running:
            try:
                for peer_id, peer in list(self.peers.items()):
                    if peer.state == PeerState.CONNECTED:
                        if peer.time_since_seen > self.HEARTBEAT_INTERVAL * 3:
                            peer.state = PeerState.DISCONNECTED
                            self._emit_disconnected(peer)
            except Exception as e:
                logger.error(f"Heartbeat error: {e}")
            
            time.sleep(self.HEARTBEAT_INTERVAL)
    
    # =========================================================================
    # PERSISTENCE
    # =========================================================================
    
    def _save_peers(self):
        """Save peers to disk"""
        try:
            data = {
                peer_id: peer.to_dict()
                for peer_id, peer in self.peers.items()
                if peer.state in [PeerState.CONNECTED, PeerState.AUTHENTICATED]
            }
            filepath = self.data_dir / "peers.json"
            with open(filepath, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save peers: {e}")
    
    def _load_peers(self):
        """Load saved peers"""
        try:
            filepath = self.data_dir / "peers.json"
            if filepath.exists():
                with open(filepath, "r") as f:
                    data = json.load(f)
                
                for peer_id, peer_data in data.items():
                    identity = PeerIdentity.from_dict(peer_data["identity"])
                    peer = Peer(
                        identity=identity,
                        state=PeerState.DISCONNECTED,
                        discovery_method=DiscoveryMethod.SAVED,
                        first_seen=peer_data.get("first_seen", time.time()),
                        is_tailscale=peer_data.get("is_tailscale", False),
                        tailscale_name=peer_data.get("tailscale_name"),
                    )
                    self.peers[peer_id] = peer
                
                logger.info(f"Loaded {len(self.peers)} saved peers")
        except Exception as e:
            logger.debug(f"No saved peers: {e}")
    
    # =========================================================================
    # PEER MANAGEMENT
    # =========================================================================
    
    def get_peer(self, peer_id: str) -> Optional[Peer]:
        """Get peer by ID"""
        return self.peers.get(peer_id)
    
    def get_connected_peers(self) -> List[Peer]:
        """Get all connected peers"""
        return [p for p in self.peers.values() if p.state == PeerState.CONNECTED]
    
    def add_peer_manual(self, host: str, port: int = 8765, name: str = "") -> Peer:
        """Manually add a peer"""
        peer_id = hashlib.md5(f"{host}:{port}".encode()).hexdigest()[:12]
        
        identity = PeerIdentity(
            peer_id=peer_id,
            name=name or host,
            host=host,
            port=port,
        )
        
        peer = Peer(identity=identity, discovery_method=DiscoveryMethod.MANUAL)
        self.peers[peer_id] = peer
        self._emit_discovered(peer)
        
        return peer
    
    def block_peer(self, peer_id: str):
        """Block a peer"""
        self.blocked_peers.add(peer_id)
        if peer_id in self.peers:
            self.peers[peer_id].state = PeerState.BLOCKED
    
    def unblock_peer(self, peer_id: str):
        """Unblock a peer"""
        self.blocked_peers.discard(peer_id)
        if peer_id in self.peers:
            self.peers[peer_id].state = PeerState.DISCONNECTED


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def create_identity(name: str, port: int = 8765) -> PeerIdentity:
    """Create a peer identity"""
    peer_id = hashlib.sha256(f"{name}{time.time()}".encode()).hexdigest()[:12]
    hostname = socket.gethostname()
    
    return PeerIdentity(
        peer_id=peer_id,
        name=name,
        host=socket.gethostbyname(hostname),
        port=port,
        platform=os.name,
        capabilities=["file_transfer", "compute", "sync"],
    )


def start_scout(name: str = "", port: int = 8766) -> ScoutDaemon:
    """Start a scout daemon"""
    name = name or socket.gethostname()
    identity = create_identity(name, port)
    scout = ScoutDaemon(identity, port)
    scout.start()
    return scout


def discover_peers(timeout: float = 5.0) -> List[Peer]:
    """Quick peer discovery without starting daemon"""
    identity = create_identity("scout_temp")
    scout = ScoutDaemon(identity)
    peers = scout.discover_network(timeout)
    return peers
