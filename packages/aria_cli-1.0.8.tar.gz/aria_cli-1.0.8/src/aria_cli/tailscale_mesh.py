"""
ARIA Tailscale Mesh v1.0.0

HTTP-based mesh network over Tailscale VPN for PC ↔ Phone communication.

Usage:
  # On PC (horus)
  aria tailscale serve --name horus
  
  # On Phone (Termux)
  aria tailscale serve --name phone
  aria tailscale connect 100.109.42.106  # PC's Tailscale IP
"""

import asyncio
import json
import socket
import threading
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from urllib.request import urlopen, Request
from urllib.error import URLError
import os

# =============================================================================
# CONFIGURATION
# =============================================================================

DEFAULT_PORT = 8765
MESH_DIR = Path.home() / ".aria" / "tailscale-mesh"
HEARTBEAT_INTERVAL = 10.0
MESSAGE_TIMEOUT = 60.0


# =============================================================================
# DATA STRUCTURES
# =============================================================================

class MessageType(str, Enum):
    """Message types for mesh communication"""
    HELLO = "hello"
    HEARTBEAT = "heartbeat"
    MESSAGE = "message"
    COMMAND = "command"
    RESPONSE = "response"
    BROADCAST = "broadcast"
    FILE_SYNC = "file_sync"
    FILE_UPLOAD = "file_upload"
    FILE_REQUEST = "file_request"
    WORKFLOW_TRIGGER = "workflow_trigger"
    DISCONNECT = "disconnect"


# =============================================================================
# WORKFLOW SYSTEM
# =============================================================================

@dataclass
class WorkflowRule:
    """A rule that triggers actions when events occur"""
    rule_id: str
    name: str
    trigger_type: str  # "file_received", "message_received", "command", "schedule"
    trigger_filter: Dict[str, Any]  # Filters like {"source": "phone", "file_ext": ".jpg"}
    actions: List[Dict[str, Any]]  # Actions like {"type": "forward", "target": "other-pc"}
    enabled: bool = True
    
    def matches(self, event_type: str, event_data: Dict) -> bool:
        """Check if this rule matches an event"""
        if not self.enabled or event_type != self.trigger_type:
            return False
        for key, pattern in self.trigger_filter.items():
            value = event_data.get(key, "")
            if pattern.startswith("*"):
                if not str(value).endswith(pattern[1:]):
                    return False
            elif pattern.endswith("*"):
                if not str(value).startswith(pattern[:-1]):
                    return False
            elif str(value) != str(pattern):
                return False
        return True
    
    def to_dict(self) -> Dict:
        return {
            "rule_id": self.rule_id,
            "name": self.name,
            "trigger_type": self.trigger_type,
            "trigger_filter": self.trigger_filter,
            "actions": self.actions,
            "enabled": self.enabled,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "WorkflowRule":
        return cls(
            rule_id=data["rule_id"],
            name=data["name"],
            trigger_type=data["trigger_type"],
            trigger_filter=data.get("trigger_filter", {}),
            actions=data.get("actions", []),
            enabled=data.get("enabled", True),
        )


@dataclass
class MeshNode:
    """A node in the Tailscale mesh"""
    node_id: str
    name: str
    ip: str
    port: int = DEFAULT_PORT
    last_seen: float = 0.0
    is_local: bool = False
    tailscale_ip: str = ""
    device_type: str = "unknown"  # pc, phone, server
    capabilities: List[str] = field(default_factory=list)
    
    @property
    def is_alive(self) -> bool:
        return time.time() - self.last_seen < HEARTBEAT_INTERVAL * 3
    
    @property
    def endpoint(self) -> str:
        return f"http://{self.tailscale_ip or self.ip}:{self.port}"
    
    def to_dict(self) -> Dict:
        return {
            "node_id": self.node_id,
            "name": self.name,
            "ip": self.ip,
            "port": self.port,
            "tailscale_ip": self.tailscale_ip,
            "device_type": self.device_type,
            "capabilities": self.capabilities,
            "last_seen": self.last_seen,
        }


@dataclass
class MeshMessage:
    """A message in the mesh network"""
    msg_id: str
    msg_type: MessageType
    source: str
    target: str  # node_id or "broadcast"
    payload: Any
    timestamp: float = field(default_factory=time.time)
    ttl: int = 10  # max hops
    
    def to_dict(self) -> Dict:
        return {
            "msg_id": self.msg_id,
            "msg_type": self.msg_type.value if isinstance(self.msg_type, MessageType) else self.msg_type,
            "source": self.source,
            "target": self.target,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "ttl": self.ttl,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "MeshMessage":
        return cls(
            msg_id=data["msg_id"],
            msg_type=MessageType(data["msg_type"]) if isinstance(data["msg_type"], str) else data["msg_type"],
            source=data["source"],
            target=data["target"],
            payload=data["payload"],
            timestamp=data.get("timestamp", time.time()),
            ttl=data.get("ttl", 10),
        )


# =============================================================================
# HTTP MESSAGE HANDLER
# =============================================================================

class MeshRequestHandler(BaseHTTPRequestHandler):
    """HTTP handler for mesh messages"""
    
    mesh: "TailscaleMesh" = None  # Set by server
    
    def log_message(self, format, *args):
        """Suppress default logging"""
        pass
    
    def _send_cors_headers(self):
        """Send CORS headers to allow cross-origin requests"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()
    
    def do_GET(self):
        """Handle GET requests - status and discovery"""
        if self.path == "/":
            self._send_json({"status": "ok", "node": self.mesh.local_node.to_dict()})
        elif self.path == "/ui":
            self._send_ui()
        elif self.path == "/nodes":
            self._send_json({"nodes": [n.to_dict() for n in self.mesh.nodes.values()]})
        elif self.path == "/status":
            self._send_json({
                "node": self.mesh.local_node.to_dict(),
                "peers": len(self.mesh.nodes) - 1,
                "messages_sent": self.mesh.stats.get("sent", 0),
                "messages_received": self.mesh.stats.get("received", 0),
            })
        elif self.path == "/files":
            # List files in shared folder
            self._send_json({"files": self.mesh.list_shared_files()})
        elif self.path.startswith("/files/"):
            # Download a file
            filename = self.path[7:]  # Remove "/files/"
            self._send_file(filename)
        elif self.path == "/workflows":
            # List workflow rules
            self._send_json({"workflows": [r.to_dict() for r in self.mesh.workflows.values()]})
        else:
            self.send_error(404)
    
    def _send_ui(self):
        """Serve the mobile web UI"""
        html = '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>ARIA Mesh</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff; min-height: 100vh; padding: 15px;
        }
        .container { max-width: 500px; margin: 0 auto; }
        h1 { text-align: center; font-size: 22px; margin-bottom: 15px;
            background: linear-gradient(90deg, #00d4ff, #7b2cbf);
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .card { background: rgba(255,255,255,0.1); border-radius: 14px;
            padding: 15px; margin-bottom: 12px; backdrop-filter: blur(10px); }
        .card h3 { font-size: 14px; margin-bottom: 10px; opacity: 0.8; }
        .dot { display: inline-block; width: 10px; height: 10px;
            border-radius: 50%; margin-right: 6px; }
        .online { background: #00ff88; box-shadow: 0 0 8px #00ff88; }
        .offline { background: #ff4757; }
        input, button, textarea { width: 100%; padding: 12px;
            border: none; border-radius: 10px; font-size: 15px; margin-bottom: 8px; }
        input, textarea { background: rgba(255,255,255,0.15); color: #fff; }
        input::placeholder, textarea::placeholder { color: rgba(255,255,255,0.5); }
        button { background: linear-gradient(90deg, #00d4ff, #7b2cbf);
            color: #fff; font-weight: 600; cursor: pointer; }
        button:active { transform: scale(0.98); }
        .btn2 { background: rgba(255,255,255,0.2); }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
        .node { display: flex; justify-content: space-between;
            padding: 10px; background: rgba(255,255,255,0.08);
            border-radius: 8px; margin-bottom: 6px; font-size: 13px; }
        .log { max-height: 150px; overflow-y: auto; background: rgba(0,0,0,0.3);
            border-radius: 10px; padding: 10px; font-family: monospace; font-size: 12px; }
        .msg { margin-bottom: 6px; padding: 6px; border-radius: 5px; }
        .sent { background: rgba(0,212,255,0.2); text-align: right; }
        .rcv { background: rgba(123,44,191,0.2); }
        .ts { font-size: 9px; opacity: 0.5; }
    </style>
</head>
<body>
<div class="container">
    <h1>🌐 ARIA Mesh</h1>
    <div class="card">
        <h3><span class="dot" id="dot"></span>Status</h3>
        <div id="status">Connecting...</div>
    </div>
    <div class="card">
        <h3>📡 Nodes</h3>
        <div id="nodes"><div style="opacity:0.5">Loading...</div></div>
        <button class="btn2" onclick="loadNodes()">Refresh</button>
    </div>
    <div class="card">
        <h3>💬 Send</h3>
        <textarea id="msg" rows="2" placeholder="Message or command..."></textarea>
        <div class="grid">
            <button onclick="send('message')">Message</button>
            <button onclick="send('command')">Command</button>
        </div>
    </div>
    <div class="card">
        <h3>⚡ Quick</h3>
        <div class="grid">
            <button class="btn2" onclick="quick('aria status')">Status</button>
            <button class="btn2" onclick="quick('hostname')">Hostname</button>
            <button class="btn2" onclick="quick('dir')">Files</button>
            <button class="btn2" onclick="quick('date')">Date</button>
        </div>
    </div>
    <div class="card">
        <h3>📨 Log</h3>
        <div class="log" id="log"><div style="opacity:0.5">Ready</div></div>
    </div>
</div>
<script>
const BASE = location.origin;
const nodeId = 'phone-' + Math.random().toString(36).substr(2,6);
let connected = false;

async function init() {
    try {
        const r = await fetch(BASE + '/connect', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                node_id: nodeId, name: 'Phone', ip: '0.0.0.0', port: 0,
                tailscale_ip: '', device_type: 'phone', capabilities: ['message']
            })
        });
        const d = await r.json();
        if (d.status === 'connected') {
            connected = true;
            document.getElementById('dot').className = 'dot online';
            document.getElementById('status').textContent = 'Connected to ' + d.node.name;
            log('✓ Connected to ' + d.node.name);
            loadNodes();
        }
    } catch(e) {
        document.getElementById('dot').className = 'dot offline';
        document.getElementById('status').textContent = 'Failed: ' + e.message;
    }
}

async function loadNodes() {
    try {
        const r = await fetch(BASE + '/nodes');
        const d = await r.json();
        document.getElementById('nodes').innerHTML = d.nodes.map(n =>
            '<div class="node"><span>' + n.name + '</span><span style="opacity:0.6">' + 
            (n.tailscale_ip || n.ip) + '</span></div>'
        ).join('');
    } catch(e) {}
}

async function send(type) {
    const txt = document.getElementById('msg').value;
    if (!txt) return;
    try {
        await fetch(BASE + '/message', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                msg_id: Math.random().toString(36).substr(2,8),
                msg_type: type, source: nodeId, target: 'horus',
                payload: type === 'command' ? {command: txt} : {text: txt},
                timestamp: Date.now()/1000, ttl: 10
            })
        });
        log('➤ ' + txt, 'sent');
        document.getElementById('msg').value = '';
    } catch(e) { log('✗ ' + e.message); }
}

function quick(cmd) {
    document.getElementById('msg').value = cmd;
    send('command');
}

function log(m, cls='') {
    const el = document.getElementById('log');
    if (el.querySelector('div[style]')) el.innerHTML = '';
    el.innerHTML += '<div class="msg ' + cls + '">' + m + 
        '<div class="ts">' + new Date().toLocaleTimeString() + '</div></div>';
    el.scrollTop = el.scrollHeight;
}

init();
setInterval(loadNodes, 10000);
</script>
</body>
</html>'''
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self._send_cors_headers()
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))
    
    def do_POST(self):
        """Handle POST requests - receive messages, files, workflows"""
        content_length = int(self.headers.get('Content-Length', 0))
        
        if self.path == "/message":
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body.decode('utf-8'))
                msg = MeshMessage.from_dict(data)
                self.mesh._handle_message(msg)
                self._send_json({"status": "ok", "msg_id": msg.msg_id})
            except Exception as e:
                self._send_json({"status": "error", "error": str(e)}, 400)
        
        elif self.path == "/connect":
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body.decode('utf-8'))
                node = MeshNode(
                    node_id=data["node_id"],
                    name=data["name"],
                    ip=data.get("ip", self.client_address[0]),
                    port=data.get("port", DEFAULT_PORT),
                    tailscale_ip=data.get("tailscale_ip", ""),
                    device_type=data.get("device_type", "unknown"),
                    capabilities=data.get("capabilities", []),
                    last_seen=time.time(),
                )
                self.mesh.nodes[node.node_id] = node
                print(f"📱 {node.name} ({node.device_type}) connected from {node.tailscale_ip or node.ip}")
                self._send_json({"status": "connected", "node": self.mesh.local_node.to_dict()})
            except Exception as e:
                self._send_json({"status": "error", "error": str(e)}, 400)
        
        elif self.path == "/upload":
            # File upload - expects JSON with base64 data
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body.decode('utf-8'))
                filename = data.get("filename", "unknown")
                file_data = data.get("data", "")  # Base64 encoded
                source = data.get("source", "unknown")
                
                result = self.mesh.receive_file(filename, file_data, source)
                self._send_json(result)
            except Exception as e:
                self._send_json({"status": "error", "error": str(e)}, 400)
        
        elif self.path == "/workflow":
            # Create or update workflow rule
            body = self.rfile.read(content_length)
            try:
                data = json.loads(body.decode('utf-8'))
                rule = WorkflowRule.from_dict(data)
                self.mesh.add_workflow(rule)
                self._send_json({"status": "ok", "rule_id": rule.rule_id})
            except Exception as e:
                self._send_json({"status": "error", "error": str(e)}, 400)
        
        else:
            self.send_error(404)
    
    def _send_file(self, filename: str):
        """Send a file from the shared folder"""
        import base64
        filepath = self.mesh.shared_dir / filename
        if not filepath.exists() or not filepath.is_file():
            self.send_error(404, f"File not found: {filename}")
            return
        try:
            with open(filepath, 'rb') as f:
                content = f.read()
            self.send_response(200)
            # Determine content type
            ext = filepath.suffix.lower()
            content_types = {
                '.txt': 'text/plain', '.json': 'application/json',
                '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
                '.pdf': 'application/pdf', '.html': 'text/html',
            }
            self.send_header('Content-Type', content_types.get(ext, 'application/octet-stream'))
            self.send_header('Content-Length', len(content))
            self.send_header('Content-Disposition', f'attachment; filename="{filename}"')
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(content)
        except Exception as e:
            self._send_json({"status": "error", "error": str(e)}, 500)
    
    def _send_json(self, data: Dict, status: int = 200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self._send_cors_headers()  # Allow cross-origin requests from iPhone
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))


# =============================================================================
# TAILSCALE MESH
# =============================================================================

class TailscaleMesh:
    """
    Tailscale Mesh Network
    
    HTTP-based mesh over Tailscale VPN for PC ↔ Phone communication.
    Features:
    - Cross-device messaging and commands
    - File sharing between devices
    - Workflow automation (when X happens on device A, do Y on device B)
    """
    
    def __init__(
        self,
        name: str = None,
        port: int = DEFAULT_PORT,
        device_type: str = "pc",
    ):
        self.node_id = str(uuid.uuid4())[:8]
        self.name = name or socket.gethostname()
        self.port = port
        self.device_type = device_type
        
        # Get IPs
        self.local_ip = self._get_local_ip()
        self.tailscale_ip = self._get_tailscale_ip()
        
        # Local node
        self.local_node = MeshNode(
            node_id=self.node_id,
            name=self.name,
            ip=self.local_ip,
            port=self.port,
            tailscale_ip=self.tailscale_ip,
            device_type=self.device_type,
            is_local=True,
            last_seen=time.time(),
            capabilities=["message", "command", "file_sync", "workflow", "q-symbolic"],
        )
        
        # Nodes registry
        self.nodes: Dict[str, MeshNode] = {self.node_id: self.local_node}
        
        # Message handlers
        self.handlers: Dict[MessageType, List[Callable]] = {mt: [] for mt in MessageType}
        
        # Stats
        self.stats = {"sent": 0, "received": 0, "files": 0, "workflows_triggered": 0}
        
        # Server
        self.server: Optional[HTTPServer] = None
        self._running = False
        self._server_thread: Optional[threading.Thread] = None
        self._heartbeat_thread: Optional[threading.Thread] = None
        
        # Storage directories
        MESH_DIR.mkdir(parents=True, exist_ok=True)
        self.shared_dir = MESH_DIR / "shared"
        self.shared_dir.mkdir(exist_ok=True)
        self.inbox_dir = MESH_DIR / "inbox"
        self.inbox_dir.mkdir(exist_ok=True)
        
        # Workflow rules
        self.workflows: Dict[str, WorkflowRule] = {}
        self._load_workflows()
        
        self._save_node_info()
    
    def _get_local_ip(self) -> str:
        """Get local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def _get_tailscale_ip(self) -> str:
        """Get Tailscale IP if available"""
        try:
            import subprocess
            # Try to get Tailscale IP from interface
            if os.name == 'nt':
                # Windows - try multiple paths
                tailscale_paths = [
                    "tailscale",
                    r"C:\Program Files\Tailscale\tailscale.exe",
                    r"C:\Program Files (x86)\Tailscale\tailscale.exe",
                ]
                for ts_path in tailscale_paths:
                    try:
                        result = subprocess.run(
                            [ts_path, "ip", "-4"],
                            capture_output=True, text=True, timeout=5
                        )
                        if result.returncode == 0 and result.stdout.strip():
                            return result.stdout.strip()
                    except:
                        continue
            else:
                # Linux/Android - check for Tailscale interface
                result = subprocess.run(
                    ["ip", "addr", "show", "tailscale0"],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        if 'inet ' in line and '100.' in line:
                            return line.split()[1].split('/')[0]
                
                # Try tailscale CLI
                try:
                    result = subprocess.run(
                        ["tailscale", "ip", "-4"],
                        capture_output=True, text=True, timeout=5
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        return result.stdout.strip()
                except:
                    pass
        except:
            pass
        return ""
    
    def _save_node_info(self):
        """Save local node info to file"""
        info_file = MESH_DIR / "local_node.json"
        with open(info_file, 'w') as f:
            json.dump(self.local_node.to_dict(), f, indent=2)
    
    def start(self):
        """Start the mesh server"""
        if self._running:
            return
        
        # Create HTTP server
        MeshRequestHandler.mesh = self
        self.server = HTTPServer(('0.0.0.0', self.port), MeshRequestHandler)
        self._running = True
        
        # Start server thread
        self._server_thread = threading.Thread(target=self._run_server, daemon=True)
        self._server_thread.start()
        
        # Start heartbeat thread
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()
        
        return self
    
    def _run_server(self):
        """Run the HTTP server"""
        while self._running:
            self.server.handle_request()
    
    def _heartbeat_loop(self):
        """Send heartbeats to known peers"""
        while self._running:
            time.sleep(HEARTBEAT_INTERVAL)
            for node in list(self.nodes.values()):
                if node.node_id != self.node_id:
                    try:
                        self._send_to_node(node, MeshMessage(
                            msg_id=str(uuid.uuid4())[:8],
                            msg_type=MessageType.HEARTBEAT,
                            source=self.node_id,
                            target=node.node_id,
                            payload={"timestamp": time.time()},
                        ))
                    except:
                        pass
    
    def stop(self):
        """Stop the mesh server"""
        self._running = False
        if self.server:
            self.server.shutdown()
    
    def connect(self, target_ip: str, target_port: int = DEFAULT_PORT) -> Optional[MeshNode]:
        """Connect to a peer node"""
        try:
            # Handle case where port is already in the IP string
            if ":" in target_ip:
                parts = target_ip.rsplit(":", 1)
                target_ip = parts[0]
                try:
                    target_port = int(parts[1])
                except ValueError:
                    pass  # Keep default port
            
            # Send connection request
            url = f"http://{target_ip}:{target_port}/connect"
            data = json.dumps(self.local_node.to_dict()).encode('utf-8')
            req = Request(url, data=data, headers={'Content-Type': 'application/json'})
            
            with urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode('utf-8'))
                if result.get("status") == "connected":
                    node_data = result.get("node", {})
                    node = MeshNode(
                        node_id=node_data["node_id"],
                        name=node_data["name"],
                        ip=node_data.get("ip", target_ip),
                        port=node_data.get("port", target_port),
                        tailscale_ip=node_data.get("tailscale_ip", target_ip),
                        device_type=node_data.get("device_type", "unknown"),
                        capabilities=node_data.get("capabilities", []),
                        last_seen=time.time(),
                    )
                    self.nodes[node.node_id] = node
                    print(f"✅ Connected to {node.name} ({node.tailscale_ip or node.ip})")
                    return node
        except Exception as e:
            print(f"❌ Failed to connect to {target_ip}:{target_port}: {e}")
        return None
    
    def send(self, target: str, payload: Any, msg_type: MessageType = MessageType.MESSAGE) -> bool:
        """Send a message to a target node"""
        # Find target node
        target_node = None
        for node in self.nodes.values():
            if node.node_id == target or node.name.lower() == target.lower():
                target_node = node
                break
        
        if not target_node:
            print(f"❌ Target node not found: {target}")
            return False
        
        msg = MeshMessage(
            msg_id=str(uuid.uuid4())[:8],
            msg_type=msg_type,
            source=self.node_id,
            target=target_node.node_id,
            payload=payload,
        )
        
        return self._send_to_node(target_node, msg)
    
    def broadcast(self, payload: Any, msg_type: MessageType = MessageType.BROADCAST) -> int:
        """Broadcast a message to all nodes"""
        count = 0
        for node in self.nodes.values():
            if node.node_id != self.node_id:
                msg = MeshMessage(
                    msg_id=str(uuid.uuid4())[:8],
                    msg_type=msg_type,
                    source=self.node_id,
                    target="broadcast",
                    payload=payload,
                )
                if self._send_to_node(node, msg):
                    count += 1
        return count
    
    def _send_to_node(self, node: MeshNode, msg: MeshMessage) -> bool:
        """Send a message to a specific node"""
        try:
            url = f"{node.endpoint}/message"
            data = json.dumps(msg.to_dict()).encode('utf-8')
            req = Request(url, data=data, headers={'Content-Type': 'application/json'})
            
            with urlopen(req, timeout=10) as response:
                result = json.loads(response.read().decode('utf-8'))
                if result.get("status") == "ok":
                    self.stats["sent"] += 1
                    return True
        except Exception as e:
            self.stats["errors"] += 1
        return False
    
    def _handle_message(self, msg: MeshMessage):
        """Handle an incoming message"""
        self.stats["received"] += 1
        
        # Update sender's last_seen
        if msg.source in self.nodes:
            self.nodes[msg.source].last_seen = time.time()
        
        # Handle by type
        if msg.msg_type == MessageType.HEARTBEAT:
            pass  # Just update last_seen
        elif msg.msg_type == MessageType.MESSAGE:
            self._on_message(msg)
        elif msg.msg_type == MessageType.COMMAND:
            self._on_command(msg)
        
        # Call registered handlers
        for handler in self.handlers.get(msg.msg_type, []):
            try:
                handler(msg)
            except Exception as e:
                print(f"Handler error: {e}")
    
    def _on_message(self, msg: MeshMessage):
        """Handle a data message"""
        source = self.nodes.get(msg.source)
        source_name = source.name if source else msg.source
        print(f"\n📨 Message from {source_name}: {msg.payload}")
    
    def _on_command(self, msg: MeshMessage):
        """Handle a command message"""
        source = self.nodes.get(msg.source)
        source_name = source.name if source else msg.source
        print(f"\n⚡ Command from {source_name}: {msg.payload}")
        
        # Execute command and send response
        cmd = msg.payload.get("command", "")
        if cmd:
            try:
                import subprocess
                result = subprocess.run(
                    cmd, shell=True, capture_output=True, text=True, timeout=30
                )
                response = {
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "returncode": result.returncode,
                }
            except Exception as e:
                response = {"error": str(e)}
            
            # Send response back
            if source:
                self.send(source.node_id, response, MessageType.RESPONSE)
    
    def on(self, msg_type: MessageType, handler: Callable):
        """Register a message handler"""
        self.handlers[msg_type].append(handler)
    
    # =========================================================================
    # FILE SHARING
    # =========================================================================
    
    def list_shared_files(self) -> List[Dict]:
        """List files in the shared folder"""
        files = []
        for f in self.shared_dir.iterdir():
            if f.is_file():
                files.append({
                    "name": f.name,
                    "size": f.stat().st_size,
                    "modified": f.stat().st_mtime,
                })
        return files
    
    def receive_file(self, filename: str, data_b64: str, source: str) -> Dict:
        """Receive and save a file from another device"""
        import base64
        try:
            # Decode and save
            file_data = base64.b64decode(data_b64)
            filepath = self.inbox_dir / filename
            with open(filepath, 'wb') as f:
                f.write(file_data)
            
            self.stats["files"] += 1
            print(f"\n📁 File received from {source}: {filename} ({len(file_data)} bytes)")
            
            # Trigger workflow
            self._trigger_workflow("file_received", {
                "filename": filename,
                "source": source,
                "size": len(file_data),
                "path": str(filepath),
                "ext": Path(filename).suffix.lower(),
            })
            
            return {"status": "ok", "filename": filename, "size": len(file_data)}
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def send_file(self, target: str, filepath: str) -> bool:
        """Send a file to another device"""
        import base64
        
        # Find target node
        target_node = None
        for node in self.nodes.values():
            if node.node_id == target or node.name.lower() == target.lower():
                target_node = node
                break
        
        if not target_node:
            print(f"❌ Target node not found: {target}")
            return False
        
        # Read and encode file
        path = Path(filepath)
        if not path.exists():
            print(f"❌ File not found: {filepath}")
            return False
        
        try:
            with open(path, 'rb') as f:
                data = f.read()
            data_b64 = base64.b64encode(data).decode('utf-8')
            
            # Send to target
            url = f"{target_node.endpoint}/upload"
            payload = json.dumps({
                "filename": path.name,
                "data": data_b64,
                "source": self.name,
            }).encode('utf-8')
            req = Request(url, data=payload, headers={'Content-Type': 'application/json'})
            
            with urlopen(req, timeout=60) as response:
                result = json.loads(response.read().decode('utf-8'))
                if result.get("status") == "ok":
                    print(f"✅ File sent to {target_node.name}: {path.name}")
                    return True
        except Exception as e:
            print(f"❌ Failed to send file: {e}")
        return False
    
    # =========================================================================
    # WORKFLOW AUTOMATION
    # =========================================================================
    
    def _load_workflows(self):
        """Load workflow rules from disk"""
        workflows_file = MESH_DIR / "workflows.json"
        if workflows_file.exists():
            try:
                with open(workflows_file, 'r') as f:
                    data = json.load(f)
                for rule_data in data:
                    rule = WorkflowRule.from_dict(rule_data)
                    self.workflows[rule.rule_id] = rule
            except Exception as e:
                print(f"Warning: Failed to load workflows: {e}")
    
    def _save_workflows(self):
        """Save workflow rules to disk"""
        workflows_file = MESH_DIR / "workflows.json"
        try:
            with open(workflows_file, 'w') as f:
                json.dump([r.to_dict() for r in self.workflows.values()], f, indent=2)
        except Exception as e:
            print(f"Warning: Failed to save workflows: {e}")
    
    def add_workflow(self, rule: WorkflowRule):
        """Add or update a workflow rule"""
        self.workflows[rule.rule_id] = rule
        self._save_workflows()
        print(f"✅ Workflow added: {rule.name}")
    
    def remove_workflow(self, rule_id: str):
        """Remove a workflow rule"""
        if rule_id in self.workflows:
            del self.workflows[rule_id]
            self._save_workflows()
    
    def _trigger_workflow(self, event_type: str, event_data: Dict):
        """Check and execute matching workflow rules"""
        for rule in self.workflows.values():
            if rule.matches(event_type, event_data):
                print(f"⚡ Workflow triggered: {rule.name}")
                self.stats["workflows_triggered"] += 1
                self._execute_workflow_actions(rule.actions, event_data)
    
    def _execute_workflow_actions(self, actions: List[Dict], event_data: Dict):
        """Execute workflow actions"""
        for action in actions:
            action_type = action.get("type", "")
            
            if action_type == "forward":
                # Forward file to another device
                target = action.get("target", "")
                filepath = event_data.get("path", "")
                if target and filepath:
                    print(f"   → Forwarding to {target}")
                    self.send_file(target, filepath)
            
            elif action_type == "command":
                # Execute a local command
                cmd = action.get("command", "")
                if cmd:
                    # Substitute event data
                    for key, value in event_data.items():
                        cmd = cmd.replace(f"${{{key}}}", str(value))
                    print(f"   → Running: {cmd}")
                    import subprocess
                    subprocess.Popen(cmd, shell=True)
            
            elif action_type == "message":
                # Send a message to another device
                target = action.get("target", "")
                text = action.get("text", "")
                if target and text:
                    # Substitute event data
                    for key, value in event_data.items():
                        text = text.replace(f"${{{key}}}", str(value))
                    print(f"   → Messaging {target}: {text}")
                    self.send(target, {"text": text})
            
            elif action_type == "notify":
                # Print notification
                text = action.get("text", "Workflow triggered")
                print(f"   🔔 {text}")
    
    def status(self) -> Dict:
        """Get mesh status"""
        return {
            "local": self.local_node.to_dict(),
            "peers": [n.to_dict() for n in self.nodes.values() if n.node_id != self.node_id],
            "stats": self.stats,
        }
    
    def list_nodes(self) -> List[MeshNode]:
        """List all known nodes"""
        return list(self.nodes.values())


# =============================================================================
# CLI FUNCTIONS
# =============================================================================

def create_mesh(name: str = None, port: int = DEFAULT_PORT, device_type: str = "pc") -> TailscaleMesh:
    """Create and start a Tailscale mesh node"""
    mesh = TailscaleMesh(name=name, port=port, device_type=device_type)
    mesh.start()
    return mesh


def demo():
    """Run a demo of the Tailscale mesh"""
    print("=" * 60)
    print("🌐 TAILSCALE MESH NETWORK DEMO")
    print("=" * 60)
    
    mesh = create_mesh(name="demo-node")
    
    print(f"\n📡 Local Node:")
    print(f"   ID: {mesh.node_id}")
    print(f"   Name: {mesh.name}")
    print(f"   Local IP: {mesh.local_ip}")
    print(f"   Tailscale IP: {mesh.tailscale_ip or 'Not connected'}")
    print(f"   Port: {mesh.port}")
    print(f"   Endpoint: http://{mesh.tailscale_ip or mesh.local_ip}:{mesh.port}")
    
    print(f"\n✅ Mesh server running!")
    print(f"\nConnect from another device:")
    print(f"   aria tailscale connect {mesh.tailscale_ip or mesh.local_ip}")
    
    return mesh


if __name__ == "__main__":
    demo()
    input("\nPress Enter to stop...")
