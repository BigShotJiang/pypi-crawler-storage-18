"""
ARIA Q-Mesh Distributed Compute Pipeline v0.4.0

Chained Pipeline Parallel Compute across Q-Folder Mesh Network

Architecture:
  ┌─────────────────────────────────────────────────────────────────────────┐
  │                    Q-MESH COMPUTE PIPELINE                               │
  │                                                                          │
  │   INPUT ──► [T1] ──► [T2] ──► [T3] ──► OUTPUT   (Sequential Chain)      │
  │                                                                          │
  │   INPUT ──┬─► [T1] ─┬──► [MERGE] ──► OUTPUT    (Parallel Fan-Out)       │
  │           ├─► [T2] ─┤                                                    │
  │           └─► [T3] ─┘                                                    │
  │                                                                          │
  │   [T1] ◄──► [T2] ◄──► [T3] ◄──► [T4]           (Mesh Compute Grid)      │
  │     ▲         ▲         ▲         ▲                                      │
  │     │         │         │         │                                      │
  │   [T5] ◄──► [T6] ◄──► [T7] ◄──► [T8]                                    │
  └─────────────────────────────────────────────────────────────────────────┘

Compute Patterns:
  - CHAIN: Sequential pipeline (A → B → C → D)
  - FAN_OUT: Parallel distribution (A → [B,C,D] → Merge)
  - MAP_REDUCE: Distribute + Aggregate (Split → Map → Reduce)
  - SCATTER_GATHER: Broadcast + Collect
  - RING: Circular processing
  - GRID: 2D mesh parallel compute

Each Terminal:
  - Has its own Q-Folder that can talk to ALL other folders
  - Can receive tasks, process them, and forward results
  - Can split work and parallelize across the mesh
  - Participates in collective operations
"""

import asyncio
import json
import os
import time
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass
from enum import Enum
import queue

try:
    from .q_folder_mesh import (
        QMeshNode, QMessage, MessageType,
        NodeState
    )
except ImportError:
    # Standalone execution
    from q_folder_mesh import (
        QMeshNode, QMessage, MessageType,
        NodeState
    )


# =============================================================================
# COMPUTE ENUMS
# =============================================================================

class ComputePattern(Enum):
    """Distributed compute patterns"""
    CHAIN = "chain"           # Sequential: A → B → C
    FAN_OUT = "fan_out"       # Parallel: A → [B,C,D]
    FAN_IN = "fan_in"         # Merge: [B,C,D] → A
    MAP_REDUCE = "map_reduce" # Split → Map → Reduce
    SCATTER_GATHER = "scatter_gather"  # Broadcast → Collect
    RING = "ring"             # Circular: A → B → C → A
    GRID = "grid"             # 2D mesh compute
    PIPELINE = "pipeline"     # Multi-stage pipeline


class TaskState(Enum):
    """State of a compute task"""
    PENDING = "pending"
    QUEUED = "queued"
    RUNNING = "running"
    WAITING = "waiting"  # Waiting for dependencies
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(Enum):
    """Task priority levels"""
    CRITICAL = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    BACKGROUND = 5


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class ComputeTask:
    """A task to be executed in the mesh"""
    id: str
    name: str
    command: str  # Shell command or Python code
    task_type: str  # "shell", "python", "function"
    payload: Dict[str, Any]
    priority: TaskPriority
    timeout: float  # seconds
    retries: int
    dependencies: List[str]  # Task IDs that must complete first
    created_at: float
    source_node: str
    target_node: Optional[str]  # None = any available node
    chain_id: Optional[str]  # For pipeline chains
    stage: int  # Stage in pipeline (0, 1, 2, ...)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "command": self.command,
            "task_type": self.task_type,
            "payload": self.payload,
            "priority": self.priority.value,
            "timeout": self.timeout,
            "retries": self.retries,
            "dependencies": self.dependencies,
            "created_at": self.created_at,
            "source_node": self.source_node,
            "target_node": self.target_node,
            "chain_id": self.chain_id,
            "stage": self.stage,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ComputeTask':
        return cls(
            id=data["id"],
            name=data["name"],
            command=data["command"],
            task_type=data["task_type"],
            payload=data["payload"],
            priority=TaskPriority(data["priority"]),
            timeout=data["timeout"],
            retries=data["retries"],
            dependencies=data.get("dependencies", []),
            created_at=data["created_at"],
            source_node=data["source_node"],
            target_node=data.get("target_node"),
            chain_id=data.get("chain_id"),
            stage=data.get("stage", 0),
        )


@dataclass
class TaskResult:
    """Result of a completed task"""
    task_id: str
    node_id: str
    state: TaskState
    output: Any
    error: Optional[str]
    started_at: float
    completed_at: float
    exit_code: int
    metrics: Dict[str, float]
    
    @property
    def duration(self) -> float:
        return self.completed_at - self.started_at
    
    @property
    def success(self) -> bool:
        return self.state == TaskState.COMPLETED and self.exit_code == 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "node_id": self.node_id,
            "state": self.state.value,
            "output": self.output,
            "error": self.error,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "exit_code": self.exit_code,
            "duration": self.duration,
            "metrics": self.metrics,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskResult':
        return cls(
            task_id=data["task_id"],
            node_id=data["node_id"],
            state=TaskState(data["state"]),
            output=data["output"],
            error=data.get("error"),
            started_at=data["started_at"],
            completed_at=data["completed_at"],
            exit_code=data["exit_code"],
            metrics=data.get("metrics", {}),
        )


@dataclass
class ComputeChain:
    """A chain of tasks forming a pipeline"""
    id: str
    name: str
    pattern: ComputePattern
    stages: List[List[ComputeTask]]  # stages[0] = first stage tasks, etc.
    created_at: float
    source_node: str
    state: TaskState
    results: Dict[str, TaskResult]  # task_id -> result
    
    @property
    def total_tasks(self) -> int:
        return sum(len(stage) for stage in self.stages)
    
    @property
    def completed_tasks(self) -> int:
        return len([r for r in self.results.values() if r.success])
    
    @property
    def progress(self) -> float:
        if self.total_tasks == 0:
            return 0.0
        return self.completed_tasks / self.total_tasks
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "pattern": self.pattern.value,
            "stages": [[t.to_dict() for t in stage] for stage in self.stages],
            "created_at": self.created_at,
            "source_node": self.source_node,
            "state": self.state.value,
            "results": {k: v.to_dict() for k, v in self.results.items()},
            "progress": self.progress,
        }


# =============================================================================
# COMPUTE NODE (Extends QMeshNode)
# =============================================================================

class QComputeNode(QMeshNode):
    """
    A compute-enabled mesh node.
    
    Extends QMeshNode with:
      - Task execution (shell commands, Python code)
      - Pipeline support (chained tasks)
      - Parallel compute (distribute across mesh)
      - Result aggregation
    """
    
    def __init__(self, name: Optional[str] = None, **kwargs):
        super().__init__(name=name, **kwargs)
        
        # Task management
        self.task_queue: queue.PriorityQueue = queue.PriorityQueue()
        self.active_tasks: Dict[str, ComputeTask] = {}
        self.completed_tasks: Dict[str, TaskResult] = {}
        self.chains: Dict[str, ComputeChain] = {}
        
        # Compute configuration
        self.max_concurrent_tasks = 4
        self.default_timeout = 300.0  # 5 minutes
        
        # Task handlers
        self.task_handlers: Dict[str, Callable] = {}
        self._register_default_task_handlers()
        
        # Add compute message handlers
        self.message_handlers[MessageType.COMMAND] = self._handle_compute_command
        
        # Setup compute folders
        self._setup_compute_folders()
    
    def _setup_compute_folders(self) -> None:
        """Create compute-specific folders"""
        (self.folder_path / "tasks").mkdir(exist_ok=True)
        (self.folder_path / "results").mkdir(exist_ok=True)
        (self.folder_path / "chains").mkdir(exist_ok=True)
    
    def _register_default_task_handlers(self) -> None:
        """Register default task type handlers"""
        self.task_handlers["shell"] = self._execute_shell
        self.task_handlers["python"] = self._execute_python
        self.task_handlers["function"] = self._execute_function
        self.task_handlers["echo"] = self._execute_echo
    
    # =========================================================================
    # TASK EXECUTION
    # =========================================================================
    
    async def _execute_shell(self, task: ComputeTask) -> TaskResult:
        """Execute a shell command"""
        started_at = time.time()
        
        try:
            process = await asyncio.create_subprocess_shell(
                task.command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=task.payload.get("cwd", str(Path.cwd())),
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=task.timeout
                )
            except asyncio.TimeoutError:
                process.kill()
                return TaskResult(
                    task_id=task.id,
                    node_id=self.id,
                    state=TaskState.FAILED,
                    output=None,
                    error="Task timed out",
                    started_at=started_at,
                    completed_at=time.time(),
                    exit_code=-1,
                    metrics={"timeout": True},
                )
            
            return TaskResult(
                task_id=task.id,
                node_id=self.id,
                state=TaskState.COMPLETED if process.returncode == 0 else TaskState.FAILED,
                output=stdout.decode() if stdout else None,
                error=stderr.decode() if stderr else None,
                started_at=started_at,
                completed_at=time.time(),
                exit_code=process.returncode or 0,
                metrics={},
            )
            
        except Exception as e:
            return TaskResult(
                task_id=task.id,
                node_id=self.id,
                state=TaskState.FAILED,
                output=None,
                error=str(e),
                started_at=started_at,
                completed_at=time.time(),
                exit_code=-1,
                metrics={},
            )
    
    async def _execute_python(self, task: ComputeTask) -> TaskResult:
        """Execute Python code"""
        started_at = time.time()
        
        try:
            # Create isolated namespace
            namespace = {
                "__builtins__": __builtins__,
                "payload": task.payload,
                "result": None,
            }
            
            # Execute code
            exec(task.command, namespace)
            
            return TaskResult(
                task_id=task.id,
                node_id=self.id,
                state=TaskState.COMPLETED,
                output=namespace.get("result"),
                error=None,
                started_at=started_at,
                completed_at=time.time(),
                exit_code=0,
                metrics={},
            )
            
        except Exception as e:
            return TaskResult(
                task_id=task.id,
                node_id=self.id,
                state=TaskState.FAILED,
                output=None,
                error=str(e),
                started_at=started_at,
                completed_at=time.time(),
                exit_code=-1,
                metrics={},
            )
    
    async def _execute_function(self, task: ComputeTask) -> TaskResult:
        """Execute a registered function"""
        started_at = time.time()
        
        func_name = task.command
        func = self.task_handlers.get(func_name, None)
        
        if not func:
            return TaskResult(
                task_id=task.id,
                node_id=self.id,
                state=TaskState.FAILED,
                output=None,
                error=f"Unknown function: {func_name}",
                started_at=started_at,
                completed_at=time.time(),
                exit_code=-1,
                metrics={},
            )
        
        try:
            if asyncio.iscoroutinefunction(func):
                output = await func(task.payload)
            else:
                output = func(task.payload)
            
            return TaskResult(
                task_id=task.id,
                node_id=self.id,
                state=TaskState.COMPLETED,
                output=output,
                error=None,
                started_at=started_at,
                completed_at=time.time(),
                exit_code=0,
                metrics={},
            )
            
        except Exception as e:
            return TaskResult(
                task_id=task.id,
                node_id=self.id,
                state=TaskState.FAILED,
                output=None,
                error=str(e),
                started_at=started_at,
                completed_at=time.time(),
                exit_code=-1,
                metrics={},
            )
    
    async def _execute_echo(self, task: ComputeTask) -> TaskResult:
        """Simple echo task for testing"""
        now = time.time()
        return TaskResult(
            task_id=task.id,
            node_id=self.id,
            state=TaskState.COMPLETED,
            output=task.payload,
            error=None,
            started_at=now,
            completed_at=now,
            exit_code=0,
            metrics={},
        )
    
    async def execute_task(self, task: ComputeTask) -> TaskResult:
        """Execute a task based on its type"""
        handler = self.task_handlers.get(task.task_type, self._execute_shell)
        
        self.active_tasks[task.id] = task
        
        try:
            result = await handler(task)
        finally:
            del self.active_tasks[task.id]
        
        self.completed_tasks[task.id] = result
        
        # Save result to disk
        result_file = self.folder_path / "results" / f"{task.id}.json"
        with open(result_file, 'w') as f:
            json.dump(result.to_dict(), f, indent=2)
        
        return result
    
    # =========================================================================
    # TASK SUBMISSION
    # =========================================================================
    
    def submit_task(
        self,
        command: str,
        name: Optional[str] = None,
        task_type: str = "shell",
        payload: Optional[Dict[str, Any]] = None,
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout: Optional[float] = None,
        target_node: Optional[str] = None,
    ) -> str:
        """Submit a task for execution"""
        task = ComputeTask(
            id=str(uuid.uuid4())[:12],
            name=name or f"task-{time.time():.0f}",
            command=command,
            task_type=task_type,
            payload=payload or {},
            priority=priority,
            timeout=timeout or self.default_timeout,
            retries=3,
            dependencies=[],
            created_at=time.time(),
            source_node=self.id,
            target_node=target_node,
            chain_id=None,
            stage=0,
        )
        
        if target_node and target_node != self.id:
            # Send to remote node
            self.send_message(
                target=target_node,
                payload={"action": "execute_task", "task": task.to_dict()},
                msg_type=MessageType.COMMAND,
            )
        else:
            # Execute locally
            self.task_queue.put((task.priority.value, time.time(), task))
        
        return task.id
    
    def submit_to_all(
        self,
        command: str,
        task_type: str = "shell",
        payload: Optional[Dict[str, Any]] = None,
    ) -> List[str]:
        """Submit a task to all connected nodes (scatter)"""
        task_ids = []
        
        for peer_id in self.peers:
            task_id = self.submit_task(
                command=command,
                task_type=task_type,
                payload=payload,
                target_node=peer_id,
            )
            task_ids.append(task_id)
        
        # Also run locally
        local_id = self.submit_task(
            command=command,
            task_type=task_type,
            payload=payload,
        )
        task_ids.append(local_id)
        
        return task_ids
    
    # =========================================================================
    # PIPELINE / CHAIN OPERATIONS
    # =========================================================================
    
    def create_chain(
        self,
        name: str,
        tasks: List[Dict[str, Any]],
        pattern: ComputePattern = ComputePattern.CHAIN,
    ) -> str:
        """
        Create a compute chain/pipeline.
        
        For CHAIN pattern, tasks execute sequentially across nodes.
        For FAN_OUT pattern, tasks execute in parallel.
        """
        chain_id = str(uuid.uuid4())[:12]
        stages = []
        
        if pattern == ComputePattern.CHAIN:
            # Each task is its own stage, executed sequentially
            available_nodes = [self.id] + list(self.peers.keys())
            
            for i, task_def in enumerate(tasks):
                target_node = available_nodes[i % len(available_nodes)]
                
                task = ComputeTask(
                    id=str(uuid.uuid4())[:12],
                    name=task_def.get("name", f"stage-{i}"),
                    command=task_def["command"],
                    task_type=task_def.get("type", "shell"),
                    payload=task_def.get("payload", {}),
                    priority=TaskPriority(task_def.get("priority", 3)),
                    timeout=task_def.get("timeout", self.default_timeout),
                    retries=task_def.get("retries", 3),
                    dependencies=[],
                    created_at=time.time(),
                    source_node=self.id,
                    target_node=target_node,
                    chain_id=chain_id,
                    stage=i,
                )
                stages.append([task])
                
        elif pattern == ComputePattern.FAN_OUT:
            # All tasks in parallel as single stage
            available_nodes = [self.id] + list(self.peers.keys())
            parallel_tasks = []
            
            for i, task_def in enumerate(tasks):
                target_node = available_nodes[i % len(available_nodes)]
                
                task = ComputeTask(
                    id=str(uuid.uuid4())[:12],
                    name=task_def.get("name", f"parallel-{i}"),
                    command=task_def["command"],
                    task_type=task_def.get("type", "shell"),
                    payload=task_def.get("payload", {}),
                    priority=TaskPriority(task_def.get("priority", 3)),
                    timeout=task_def.get("timeout", self.default_timeout),
                    retries=task_def.get("retries", 3),
                    dependencies=[],
                    created_at=time.time(),
                    source_node=self.id,
                    target_node=target_node,
                    chain_id=chain_id,
                    stage=0,
                )
                parallel_tasks.append(task)
            
            stages.append(parallel_tasks)
            
        elif pattern == ComputePattern.MAP_REDUCE:
            # Stage 0: Map (parallel)
            # Stage 1: Reduce (single node)
            available_nodes = [self.id] + list(self.peers.keys())
            map_tasks = []
            
            for i, task_def in enumerate(tasks[:-1]):  # All but last
                target_node = available_nodes[i % len(available_nodes)]
                
                task = ComputeTask(
                    id=str(uuid.uuid4())[:12],
                    name=task_def.get("name", f"map-{i}"),
                    command=task_def["command"],
                    task_type=task_def.get("type", "shell"),
                    payload=task_def.get("payload", {}),
                    priority=TaskPriority(task_def.get("priority", 3)),
                    timeout=task_def.get("timeout", self.default_timeout),
                    retries=task_def.get("retries", 3),
                    dependencies=[],
                    created_at=time.time(),
                    source_node=self.id,
                    target_node=target_node,
                    chain_id=chain_id,
                    stage=0,
                )
                map_tasks.append(task)
            
            stages.append(map_tasks)
            
            # Reduce task
            if tasks:
                reduce_def = tasks[-1]
                reduce_task = ComputeTask(
                    id=str(uuid.uuid4())[:12],
                    name=reduce_def.get("name", "reduce"),
                    command=reduce_def["command"],
                    task_type=reduce_def.get("type", "shell"),
                    payload=reduce_def.get("payload", {}),
                    priority=TaskPriority(reduce_def.get("priority", 3)),
                    timeout=reduce_def.get("timeout", self.default_timeout),
                    retries=reduce_def.get("retries", 3),
                    dependencies=[t.id for t in map_tasks],
                    created_at=time.time(),
                    source_node=self.id,
                    target_node=self.id,  # Reduce locally
                    chain_id=chain_id,
                    stage=1,
                )
                stages.append([reduce_task])
        
        chain = ComputeChain(
            id=chain_id,
            name=name,
            pattern=pattern,
            stages=stages,
            created_at=time.time(),
            source_node=self.id,
            state=TaskState.PENDING,
            results={},
        )
        
        self.chains[chain_id] = chain
        
        # Save chain to disk
        chain_file = self.folder_path / "chains" / f"{chain_id}.json"
        with open(chain_file, 'w') as f:
            json.dump(chain.to_dict(), f, indent=2)
        
        return chain_id
    
    async def run_chain(self, chain_id: str) -> ComputeChain:
        """Execute a compute chain"""
        chain = self.chains.get(chain_id)
        if not chain:
            raise ValueError(f"Chain not found: {chain_id}")
        
        chain.state = TaskState.RUNNING
        
        for stage_idx, stage_tasks in enumerate(chain.stages):
            # Check dependencies for this stage
            if stage_idx > 0:
                prev_stage = chain.stages[stage_idx - 1]
                for prev_task in prev_stage:
                    if prev_task.id not in chain.results:
                        chain.state = TaskState.FAILED
                        return chain
                    if not chain.results[prev_task.id].success:
                        chain.state = TaskState.FAILED
                        return chain
            
            # Execute all tasks in this stage (parallel)
            stage_results = await asyncio.gather(*[
                self._run_chain_task(task, chain)
                for task in stage_tasks
            ])
            
            # Store results
            for result in stage_results:
                chain.results[result.task_id] = result
                
                # If any task failed, stop chain
                if not result.success:
                    chain.state = TaskState.FAILED
                    return chain
        
        chain.state = TaskState.COMPLETED
        return chain
    
    async def _run_chain_task(
        self,
        task: ComputeTask,
        chain: ComputeChain
    ) -> TaskResult:
        """Run a single task in a chain"""
        # Inject previous stage results into payload
        if task.stage > 0 and chain.stages[task.stage - 1]:
            prev_results = [
                chain.results[t.id].output
                for t in chain.stages[task.stage - 1]
                if t.id in chain.results
            ]
            task.payload["_prev_results"] = prev_results
        
        if task.target_node and task.target_node != self.id:
            # Send to remote node
            self.send_message(
                target=task.target_node,
                payload={"action": "execute_task", "task": task.to_dict()},
                msg_type=MessageType.COMMAND,
            )
            
            # Wait for result (with timeout)
            result = await self._wait_for_result(task.id, timeout=task.timeout)
            return result
        else:
            # Execute locally
            return await self.execute_task(task)
    
    async def _wait_for_result(self, task_id: str, timeout: float) -> TaskResult:
        """Wait for a result from a remote node"""
        start = time.time()
        
        while (time.time() - start) < timeout:
            # Check result file
            result_file = self.folder_path / "results" / f"{task_id}.json"
            if result_file.exists():
                with open(result_file, 'r') as f:
                    data = json.load(f)
                return TaskResult.from_dict(data)
            
            await asyncio.sleep(0.5)
        
        # Timeout
        return TaskResult(
            task_id=task_id,
            node_id=self.id,
            state=TaskState.FAILED,
            output=None,
            error="Timeout waiting for remote result",
            started_at=start,
            completed_at=time.time(),
            exit_code=-1,
            metrics={"timeout": True},
        )
    
    # =========================================================================
    # MESSAGE HANDLERS
    # =========================================================================
    
    def _handle_compute_command(self, msg: QMessage) -> None:
        """Handle compute command messages"""
        action = msg.payload.get("action")
        
        if action == "execute_task":
            task_data = msg.payload.get("task")
            if task_data:
                task = ComputeTask.from_dict(task_data)
                self.task_queue.put((task.priority.value, time.time(), task))
        
        elif action == "get_result":
            task_id = msg.payload.get("task_id")
            result = self.completed_tasks.get(task_id)
            if result:
                self.send_message(
                    target=msg.source_node,
                    payload={"action": "result", "result": result.to_dict()},
                    msg_type=MessageType.RESPONSE,
                )
        
        elif action == "result":
            result_data = msg.payload.get("result")
            if result_data:
                result = TaskResult.from_dict(result_data)
                self.completed_tasks[result.task_id] = result
                
                # Save to disk
                result_file = self.folder_path / "results" / f"{result.task_id}.json"
                with open(result_file, 'w') as f:
                    json.dump(result.to_dict(), f, indent=2)
    
    # =========================================================================
    # TASK PROCESSING LOOP
    # =========================================================================
    
    async def process_tasks(self) -> None:
        """Process pending tasks in the queue"""
        while len(self.active_tasks) < self.max_concurrent_tasks:
            try:
                _priority, _timestamp, task = self.task_queue.get_nowait()
            except queue.Empty:
                break
            
            # Execute task
            asyncio.create_task(self._process_single_task(task))
    
    async def _process_single_task(self, task: ComputeTask) -> None:
        """Process a single task"""
        result = await self.execute_task(task)
        
        # If part of a chain, notify source
        if task.chain_id and task.source_node != self.id:
            self.send_message(
                target=task.source_node,
                payload={"action": "result", "result": result.to_dict()},
                msg_type=MessageType.RESPONSE,
            )
    
    async def run(self) -> None:
        """Main event loop with task processing"""
        self._running = True
        self.state = NodeState.IDLE
        
        last_heartbeat = 0
        
        while self._running:
            try:
                # Process inbox
                await self.process_inbox()
                
                # Process outbox
                await self.process_outbox()
                
                # Process tasks
                await self.process_tasks()
                
                # Send heartbeats
                if time.time() - last_heartbeat > 5.0:
                    await self.send_heartbeats()
                    await self.update_registry()
                    last_heartbeat = time.time()
                
                await asyncio.sleep(0.1)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.metrics["errors"] += 1
                print(f"Error in compute loop: {e}")
                await asyncio.sleep(1)
        
        self.state = NodeState.OFFLINE
    
    # =========================================================================
    # HIGH-LEVEL API
    # =========================================================================
    
    def run_command(self, command: str, on_node: str = None) -> str:
        """Run a shell command (locally or on a specific node)"""
        return self.submit_task(
            command=command,
            task_type="shell",
            target_node=on_node,
        )
    
    def run_python(self, code: str, on_node: Optional[str] = None) -> str:
        """Run Python code (locally or on a specific node)"""
        return self.submit_task(
            command=code,
            task_type="python",
            target_node=on_node,
        )
    
    def scatter(self, command: str, task_type: str = "shell") -> List[str]:
        """Scatter a task to all nodes (including self)"""
        return self.submit_to_all(command=command, task_type=task_type)
    
    def pipeline(
        self,
        name: str,
        steps: List[str],
        pattern: ComputePattern = ComputePattern.CHAIN,
    ) -> str:
        """Create and run a pipeline of commands"""
        tasks = [{"command": cmd} for cmd in steps]
        chain_id = self.create_chain(name=name, tasks=tasks, pattern=pattern)
        return chain_id
    
    def map_reduce(
        self,
        map_commands: List[str],
        reduce_command: str,
    ) -> str:
        """Create a map-reduce chain"""
        tasks = [{"command": cmd, "name": f"map-{i}"} for i, cmd in enumerate(map_commands)]
        tasks.append({"command": reduce_command, "name": "reduce"})
        
        return self.create_chain(
            name="map-reduce",
            tasks=tasks,
            pattern=ComputePattern.MAP_REDUCE,
        )
    
    def get_chain_status(self, chain_id: str) -> Dict[str, Any]:
        """Get status of a compute chain"""
        chain = self.chains.get(chain_id)
        if not chain:
            return {"error": "Chain not found"}
        
        return {
            "id": chain.id,
            "name": chain.name,
            "pattern": chain.pattern.value,
            "state": chain.state.value,
            "progress": chain.progress,
            "total_tasks": chain.total_tasks,
            "completed_tasks": chain.completed_tasks,
            "stages": len(chain.stages),
        }
    
    def get_compute_status(self) -> Dict[str, Any]:
        """Get compute node status"""
        return {
            **self.get_status(),
            "active_tasks": len(self.active_tasks),
            "queued_tasks": self.task_queue.qsize(),
            "completed_tasks": len(self.completed_tasks),
            "chains": len(self.chains),
            "max_concurrent": self.max_concurrent_tasks,
        }


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_compute_node(name: Optional[str] = None) -> QComputeNode:
    """Create a compute-enabled mesh node"""
    return QComputeNode(name=name)


def quick_scatter(command: str) -> Dict[str, Any]:
    """Quick scatter a command to all available nodes"""
    node = create_compute_node(name="scatter-coordinator")
    node.auto_connect()
    node.start()
    
    task_ids = node.scatter(command)
    
    return {
        "node_id": node.id,
        "task_ids": task_ids,
        "nodes": len(task_ids),
    }


# =============================================================================
# DEMO
# =============================================================================

async def demo():
    """Demo the compute pipeline system"""
    print("=== Q-Mesh Compute Pipeline Demo ===\n")
    
    # Create compute node
    node = create_compute_node(name="compute-demo")
    print(f"Created node: {node.name} ({node.id})")
    
    # Discover peers
    peers = node.discover_peers()
    print(f"Discovered {len(peers)} peers")
    
    if peers:
        node.auto_connect()
        print(f"Connected to {len(node.peers)} peers")
    
    # Create a pipeline
    print("\n--- Creating Pipeline ---")
    chain_id = node.pipeline(
        name="demo-pipeline",
        steps=[
            "echo 'Step 1: Initializing...'",
            "echo 'Step 2: Processing...'",
            "echo 'Step 3: Finalizing...'",
        ],
        pattern=ComputePattern.CHAIN,
    )
    print(f"Created chain: {chain_id}")
    
    # Run the chain
    print("\n--- Running Pipeline ---")
    chain = await node.run_chain(chain_id)
    
    print(f"Chain state: {chain.state.value}")
    print(f"Progress: {chain.progress * 100:.0f}%")
    
    for task_id, result in chain.results.items():
        print(f"  Task {task_id}: {result.state.value}")
        if result.output:
            print(f"    Output: {result.output.strip()}")
    
    print("\n--- Done ---")
    node.stop()


if __name__ == "__main__":
    asyncio.run(demo())
