"""
ARIA Device Monitor v1.0.0

System metrics monitoring and performance tracking.

Features:
  - CPU, Memory, Disk monitoring
  - Process management
  - Network I/O tracking
  - Performance alerts
  - Historical metrics storage
"""

import os
import json
import time
import threading
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Callable, Tuple
from enum import Enum
from pathlib import Path
from datetime import datetime
from collections import deque

# Try to import psutil (optional)
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


# =============================================================================
# ENUMS AND DATACLASSES
# =============================================================================

class AlertLevel(str, Enum):
    """Alert severity levels"""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class MetricType(str, Enum):
    """Types of metrics"""
    CPU = "cpu"
    MEMORY = "memory"
    DISK = "disk"
    NETWORK = "network"
    PROCESS = "process"
    SYSTEM = "system"


@dataclass
class SystemMetrics:
    """Current system metrics snapshot"""
    timestamp: float
    
    # CPU
    cpu_percent: float = 0.0
    cpu_count: int = 0
    cpu_freq: float = 0.0
    cpu_per_core: List[float] = field(default_factory=list)
    
    # Memory
    memory_total: int = 0
    memory_available: int = 0
    memory_percent: float = 0.0
    memory_used: int = 0
    
    # Swap
    swap_total: int = 0
    swap_used: int = 0
    swap_percent: float = 0.0
    
    # Disk
    disk_total: int = 0
    disk_used: int = 0
    disk_free: int = 0
    disk_percent: float = 0.0
    
    # Network
    bytes_sent: int = 0
    bytes_recv: int = 0
    packets_sent: int = 0
    packets_recv: int = 0
    
    # System
    boot_time: float = 0.0
    uptime: float = 0.0
    load_average: Tuple[float, float, float] = (0.0, 0.0, 0.0)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "datetime": datetime.fromtimestamp(self.timestamp).isoformat(),
            "cpu": {
                "percent": self.cpu_percent,
                "count": self.cpu_count,
                "freq_mhz": self.cpu_freq,
                "per_core": self.cpu_per_core,
            },
            "memory": {
                "total_gb": round(self.memory_total / (1024**3), 2),
                "available_gb": round(self.memory_available / (1024**3), 2),
                "used_gb": round(self.memory_used / (1024**3), 2),
                "percent": self.memory_percent,
            },
            "swap": {
                "total_gb": round(self.swap_total / (1024**3), 2),
                "used_gb": round(self.swap_used / (1024**3), 2),
                "percent": self.swap_percent,
            },
            "disk": {
                "total_gb": round(self.disk_total / (1024**3), 2),
                "used_gb": round(self.disk_used / (1024**3), 2),
                "free_gb": round(self.disk_free / (1024**3), 2),
                "percent": self.disk_percent,
            },
            "network": {
                "bytes_sent": self.bytes_sent,
                "bytes_recv": self.bytes_recv,
                "packets_sent": self.packets_sent,
                "packets_recv": self.packets_recv,
            },
            "system": {
                "uptime_hours": round(self.uptime / 3600, 2),
                "load_average": list(self.load_average),
            },
        }


@dataclass
class ProcessInfo:
    """Information about a running process"""
    pid: int
    name: str
    status: str
    cpu_percent: float
    memory_percent: float
    memory_mb: float
    threads: int
    cmdline: str
    create_time: float
    username: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "pid": self.pid,
            "name": self.name,
            "status": self.status,
            "cpu_percent": round(self.cpu_percent, 1),
            "memory_percent": round(self.memory_percent, 2),
            "memory_mb": round(self.memory_mb, 1),
            "threads": self.threads,
            "username": self.username,
            "cmdline": self.cmdline[:100] if self.cmdline else "",
            "uptime": time.time() - self.create_time,
        }


@dataclass
class Alert:
    """System alert"""
    timestamp: float
    level: AlertLevel
    metric_type: MetricType
    message: str
    value: float
    threshold: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "datetime": datetime.fromtimestamp(self.timestamp).isoformat(),
            "level": self.level.value,
            "type": self.metric_type.value,
            "message": self.message,
            "value": self.value,
            "threshold": self.threshold,
        }


# =============================================================================
# FALLBACK IMPLEMENTATIONS (when psutil not available)
# =============================================================================

class FallbackMonitor:
    """Fallback monitoring using system commands"""
    
    @staticmethod
    def get_cpu_percent() -> float:
        """Get CPU usage (Windows-specific fallback)"""
        try:
            if os.name == "nt":
                import subprocess
                result = subprocess.run(
                    ["wmic", "cpu", "get", "loadpercentage"],
                    capture_output=True, text=True, timeout=5
                )
                lines = result.stdout.strip().split("\n")
                if len(lines) >= 2:
                    return float(lines[1].strip())
            return 0.0
        except Exception:
            return 0.0
    
    @staticmethod
    def get_memory_info() -> Dict[str, int]:
        """Get memory info (Windows-specific fallback)"""
        try:
            if os.name == "nt":
                import subprocess
                result = subprocess.run(
                    ["wmic", "OS", "get", "TotalVisibleMemorySize,FreePhysicalMemory"],
                    capture_output=True, text=True, timeout=5
                )
                lines = result.stdout.strip().split("\n")
                if len(lines) >= 2:
                    parts = lines[1].split()
                    if len(parts) >= 2:
                        free_kb = int(parts[0])
                        total_kb = int(parts[1])
                        return {
                            "total": total_kb * 1024,
                            "available": free_kb * 1024,
                            "used": (total_kb - free_kb) * 1024,
                            "percent": (total_kb - free_kb) / total_kb * 100,
                        }
            return {"total": 0, "available": 0, "used": 0, "percent": 0}
        except Exception:
            return {"total": 0, "available": 0, "used": 0, "percent": 0}
    
    @staticmethod
    def get_disk_usage(path: str = "/") -> Dict[str, int]:
        """Get disk usage"""
        try:
            if os.name == "nt":
                import shutil
                total, used, free = shutil.disk_usage(path)
                return {
                    "total": total,
                    "used": used,
                    "free": free,
                    "percent": used / total * 100,
                }
            return {"total": 0, "used": 0, "free": 0, "percent": 0}
        except Exception:
            return {"total": 0, "used": 0, "free": 0, "percent": 0}


# =============================================================================
# DEVICE MONITOR CLASS
# =============================================================================

class DeviceMonitor:
    """
    System metrics monitoring and alerting
    
    Usage:
        monitor = DeviceMonitor()
        
        # Get current metrics
        metrics = monitor.get_metrics()
        
        # Start continuous monitoring
        monitor.start_monitoring(interval=5)
        
        # Get top processes
        processes = monitor.get_top_processes()
    """
    
    # Default thresholds
    DEFAULT_THRESHOLDS = {
        "cpu_warning": 80.0,
        "cpu_critical": 95.0,
        "memory_warning": 80.0,
        "memory_critical": 95.0,
        "disk_warning": 80.0,
        "disk_critical": 95.0,
    }
    
    def __init__(
        self,
        thresholds: Optional[Dict[str, float]] = None,
        history_size: int = 1000,
    ):
        self.thresholds = {**self.DEFAULT_THRESHOLDS, **(thresholds or {})}
        self.history_size = history_size
        
        self.metrics_history: deque = deque(maxlen=history_size)
        self.alerts_history: deque = deque(maxlen=100)
        
        self._monitoring = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._alert_callbacks: List[Callable[[Alert], None]] = []
        
        self.cache_dir = Path.home() / ".aria" / "monitor-cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        self._last_net_io: Optional[Dict] = None
        self._last_net_time: float = 0
    
    def has_psutil(self) -> bool:
        """Check if psutil is available"""
        return HAS_PSUTIL
    
    def add_alert_callback(self, callback: Callable[[Alert], None]):
        """Add callback for alerts"""
        self._alert_callbacks.append(callback)
    
    def _emit_alert(self, alert: Alert):
        """Emit alert to all callbacks"""
        self.alerts_history.append(alert)
        for callback in self._alert_callbacks:
            try:
                callback(alert)
            except Exception:
                pass
    
    # =========================================================================
    # METRICS COLLECTION
    # =========================================================================
    
    def get_metrics(self) -> SystemMetrics:
        """Get current system metrics"""
        now = time.time()
        metrics = SystemMetrics(timestamp=now)
        
        if HAS_PSUTIL:
            # CPU
            metrics.cpu_percent = psutil.cpu_percent(interval=0.1)
            metrics.cpu_count = psutil.cpu_count()
            metrics.cpu_per_core = psutil.cpu_percent(interval=0.1, percpu=True)
            try:
                freq = psutil.cpu_freq()
                metrics.cpu_freq = freq.current if freq else 0
            except Exception:
                pass
            
            # Memory
            mem = psutil.virtual_memory()
            metrics.memory_total = mem.total
            metrics.memory_available = mem.available
            metrics.memory_used = mem.used
            metrics.memory_percent = mem.percent
            
            # Swap
            try:
                swap = psutil.swap_memory()
                metrics.swap_total = swap.total
                metrics.swap_used = swap.used
                metrics.swap_percent = swap.percent
            except Exception:
                pass
            
            # Disk
            try:
                disk = psutil.disk_usage("/")
                metrics.disk_total = disk.total
                metrics.disk_used = disk.used
                metrics.disk_free = disk.free
                metrics.disk_percent = disk.percent
            except Exception:
                pass
            
            # Network I/O
            try:
                net = psutil.net_io_counters()
                metrics.bytes_sent = net.bytes_sent
                metrics.bytes_recv = net.bytes_recv
                metrics.packets_sent = net.packets_sent
                metrics.packets_recv = net.packets_recv
            except Exception:
                pass
            
            # System info
            try:
                metrics.boot_time = psutil.boot_time()
                metrics.uptime = now - metrics.boot_time
            except Exception:
                pass
            
            # Load average (Unix only)
            try:
                metrics.load_average = os.getloadavg()
            except AttributeError:
                pass
        
        else:
            # Fallback implementations
            metrics.cpu_percent = FallbackMonitor.get_cpu_percent()
            
            mem = FallbackMonitor.get_memory_info()
            metrics.memory_total = mem.get("total", 0)
            metrics.memory_available = mem.get("available", 0)
            metrics.memory_used = mem.get("used", 0)
            metrics.memory_percent = mem.get("percent", 0)
            
            disk = FallbackMonitor.get_disk_usage("C:\\" if os.name == "nt" else "/")
            metrics.disk_total = disk.get("total", 0)
            metrics.disk_used = disk.get("used", 0)
            metrics.disk_free = disk.get("free", 0)
            metrics.disk_percent = disk.get("percent", 0)
        
        return metrics
    
    def get_network_speed(self) -> Dict[str, float]:
        """Get current network speed (bytes/sec)"""
        if not HAS_PSUTIL:
            return {"upload": 0.0, "download": 0.0}
        
        try:
            net = psutil.net_io_counters()
            now = time.time()
            
            if self._last_net_io is None:
                self._last_net_io = {"sent": net.bytes_sent, "recv": net.bytes_recv}
                self._last_net_time = now
                return {"upload": 0.0, "download": 0.0}
            
            elapsed = now - self._last_net_time
            if elapsed <= 0:
                return {"upload": 0.0, "download": 0.0}
            
            upload_speed = (net.bytes_sent - self._last_net_io["sent"]) / elapsed
            download_speed = (net.bytes_recv - self._last_net_io["recv"]) / elapsed
            
            self._last_net_io = {"sent": net.bytes_sent, "recv": net.bytes_recv}
            self._last_net_time = now
            
            return {"upload": upload_speed, "download": download_speed}
            
        except Exception:
            return {"upload": 0.0, "download": 0.0}
    
    # =========================================================================
    # PROCESS MANAGEMENT
    # =========================================================================
    
    def get_processes(self, sort_by: str = "memory") -> List[ProcessInfo]:
        """Get all running processes"""
        if not HAS_PSUTIL:
            return []
        
        processes = []
        
        for proc in psutil.process_iter(['pid', 'name', 'status', 'cpu_percent',
                                          'memory_percent', 'memory_info',
                                          'num_threads', 'cmdline', 'create_time',
                                          'username']):
            try:
                info = proc.info
                processes.append(ProcessInfo(
                    pid=info['pid'],
                    name=info['name'] or "",
                    status=info['status'] or "",
                    cpu_percent=info['cpu_percent'] or 0,
                    memory_percent=info['memory_percent'] or 0,
                    memory_mb=(info['memory_info'].rss if info['memory_info'] else 0) / (1024 * 1024),
                    threads=info['num_threads'] or 0,
                    cmdline=" ".join(info['cmdline']) if info['cmdline'] else "",
                    create_time=info['create_time'] or 0,
                    username=info['username'] or "",
                ))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        
        # Sort
        if sort_by == "cpu":
            processes.sort(key=lambda p: p.cpu_percent, reverse=True)
        elif sort_by == "memory":
            processes.sort(key=lambda p: p.memory_percent, reverse=True)
        elif sort_by == "name":
            processes.sort(key=lambda p: p.name.lower())
        
        return processes
    
    def get_top_processes(self, n: int = 10, sort_by: str = "memory") -> List[ProcessInfo]:
        """Get top N processes by resource usage"""
        return self.get_processes(sort_by=sort_by)[:n]
    
    def find_process(self, name: str) -> List[ProcessInfo]:
        """Find processes by name"""
        all_procs = self.get_processes()
        return [p for p in all_procs if name.lower() in p.name.lower()]
    
    def kill_process(self, pid: int, force: bool = False) -> bool:
        """Kill a process by PID"""
        if not HAS_PSUTIL:
            return False
        
        try:
            proc = psutil.Process(pid)
            if force:
                proc.kill()
            else:
                proc.terminate()
            return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False
    
    # =========================================================================
    # ALERTING
    # =========================================================================
    
    def check_alerts(self, metrics: SystemMetrics) -> List[Alert]:
        """Check metrics against thresholds and generate alerts"""
        alerts = []
        now = time.time()
        
        # CPU alerts
        if metrics.cpu_percent >= self.thresholds["cpu_critical"]:
            alerts.append(Alert(
                timestamp=now,
                level=AlertLevel.CRITICAL,
                metric_type=MetricType.CPU,
                message=f"Critical CPU usage: {metrics.cpu_percent:.1f}%",
                value=metrics.cpu_percent,
                threshold=self.thresholds["cpu_critical"],
            ))
        elif metrics.cpu_percent >= self.thresholds["cpu_warning"]:
            alerts.append(Alert(
                timestamp=now,
                level=AlertLevel.WARNING,
                metric_type=MetricType.CPU,
                message=f"High CPU usage: {metrics.cpu_percent:.1f}%",
                value=metrics.cpu_percent,
                threshold=self.thresholds["cpu_warning"],
            ))
        
        # Memory alerts
        if metrics.memory_percent >= self.thresholds["memory_critical"]:
            alerts.append(Alert(
                timestamp=now,
                level=AlertLevel.CRITICAL,
                metric_type=MetricType.MEMORY,
                message=f"Critical memory usage: {metrics.memory_percent:.1f}%",
                value=metrics.memory_percent,
                threshold=self.thresholds["memory_critical"],
            ))
        elif metrics.memory_percent >= self.thresholds["memory_warning"]:
            alerts.append(Alert(
                timestamp=now,
                level=AlertLevel.WARNING,
                metric_type=MetricType.MEMORY,
                message=f"High memory usage: {metrics.memory_percent:.1f}%",
                value=metrics.memory_percent,
                threshold=self.thresholds["memory_warning"],
            ))
        
        # Disk alerts
        if metrics.disk_percent >= self.thresholds["disk_critical"]:
            alerts.append(Alert(
                timestamp=now,
                level=AlertLevel.CRITICAL,
                metric_type=MetricType.DISK,
                message=f"Critical disk usage: {metrics.disk_percent:.1f}%",
                value=metrics.disk_percent,
                threshold=self.thresholds["disk_critical"],
            ))
        elif metrics.disk_percent >= self.thresholds["disk_warning"]:
            alerts.append(Alert(
                timestamp=now,
                level=AlertLevel.WARNING,
                metric_type=MetricType.DISK,
                message=f"High disk usage: {metrics.disk_percent:.1f}%",
                value=metrics.disk_percent,
                threshold=self.thresholds["disk_warning"],
            ))
        
        return alerts
    
    # =========================================================================
    # CONTINUOUS MONITORING
    # =========================================================================
    
    def start_monitoring(
        self,
        interval: float = 5.0,
        check_alerts: bool = True,
    ):
        """Start continuous background monitoring"""
        if self._monitoring:
            return
        
        self._monitoring = True
        
        def monitor_loop():
            while self._monitoring:
                try:
                    metrics = self.get_metrics()
                    self.metrics_history.append(metrics)
                    
                    if check_alerts:
                        alerts = self.check_alerts(metrics)
                        for alert in alerts:
                            self._emit_alert(alert)
                    
                except Exception:
                    pass
                
                time.sleep(interval)
        
        self._monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self._monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop background monitoring"""
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2)
    
    def get_history(self, duration: float = 300) -> List[SystemMetrics]:
        """Get metrics history for duration (seconds)"""
        now = time.time()
        cutoff = now - duration
        return [m for m in self.metrics_history if m.timestamp >= cutoff]
    
    def get_alerts(self, duration: float = 3600) -> List[Alert]:
        """Get alerts for duration (seconds)"""
        now = time.time()
        cutoff = now - duration
        return [a for a in self.alerts_history if a.timestamp >= cutoff]
    
    # =========================================================================
    # SUMMARY AND REPORTING
    # =========================================================================
    
    def get_summary(self) -> Dict[str, Any]:
        """Get current system summary"""
        metrics = self.get_metrics()
        speed = self.get_network_speed()
        
        return {
            "status": "healthy" if metrics.cpu_percent < 80 and metrics.memory_percent < 80 else "stressed",
            "cpu": f"{metrics.cpu_percent:.1f}%",
            "memory": f"{metrics.memory_percent:.1f}%",
            "disk": f"{metrics.disk_percent:.1f}%",
            "network": {
                "upload": f"{speed['upload'] / 1024:.1f} KB/s",
                "download": f"{speed['download'] / 1024:.1f} KB/s",
            },
            "uptime_hours": round(metrics.uptime / 3600, 1),
            "process_count": len(self.get_processes()) if HAS_PSUTIL else 0,
        }
    
    def export_metrics(self, filepath: Optional[Path] = None) -> Path:
        """Export metrics history to JSON file"""
        if filepath is None:
            filepath = self.cache_dir / f"metrics_{int(time.time())}.json"
        
        data = {
            "exported_at": datetime.now().isoformat(),
            "metrics": [m.to_dict() for m in self.metrics_history],
            "alerts": [a.to_dict() for a in self.alerts_history],
        }
        
        with open(filepath, "w") as f:
            json.dump(data, f, indent=2)
        
        return filepath


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def quick_status() -> Dict[str, Any]:
    """Get quick system status"""
    monitor = DeviceMonitor()
    return monitor.get_summary()


def top_processes(n: int = 10) -> List[Dict[str, Any]]:
    """Get top processes by memory usage"""
    monitor = DeviceMonitor()
    return [p.to_dict() for p in monitor.get_top_processes(n)]
