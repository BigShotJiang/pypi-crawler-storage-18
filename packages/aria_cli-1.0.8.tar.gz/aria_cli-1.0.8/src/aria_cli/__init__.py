"""
ARIA CLI v1.0.8 - Natural Language Quantum AI Command Line Interface

Full Q0-Q38 Cognitive Architecture with LLM Integration + Q-Mesh Distributed Compute

The Q-System is a 39-layer recursive cognitive architecture:
- Q0-Q9: Foundation layers (perception, memory, attention)
- Q10-Q19: Reasoning layers (logic, inference, hypothesis)
- Q20-Q29: Action layers (planning, execution, feedback)
- Q30-Q38: Meta-cognitive layers (self-reflection, adaptation, transcendence)

New in v1.0.6:
- QR code generation for mesh connections
- Daemon scout for peer discovery and handshaking
- Q-Mesh distributed terminal communication
- Chained pipeline parallel compute
- Multi-platform binary distribution
- Docker containerization
"""

__version__ = "1.0.8"
__author__ = "Universal Crown Prime"
__description__ = "ARIA CLI - Natural Language Quantum AI with Q0-Q38 System & F1/M1 Cycles"

from .q_system import (
    QSystem,
    QLayer,
    QOperator,
    QCommand,
)

from .nlp_engine import (
    NLPEngine,
    Intent,
    Entity,
    ParsedInput,
)

from .llm_connector import (
    LLMConnector,
    LLMProvider,
    LLMConfig,
    LLMResponse,
)

from .aria_connector import (
    AriaConnector,
    SyncMode,
    AriaPlugin,
    PluginManager,
)

from .q38_connector import (
    Q38Connector,
    Q38Config,
    Q38Response,
)

from .knowledge_connector import (
    KnowledgeConnector,
    KnowledgeResult,
    ARIAConnector,  # Legacy alias
)

from .auth import (
    AuthManager,
    AuthProvider,
    AuthStatus,
    User,
    Session,
    CredentialStore,
    get_auth,
)

from .ssh_router import (
    SSHRouter,
    SSHHost,
    SSHConnection,
    SSHAuthMethod,
    ConnectionStatus,
    CommandResult,
    get_router,
)

from .aria_space import (
    AriaSpace,
    Workspace,
    SyncFile,
    SyncResult,
    SyncDirection,
    SyncStrategy,
    FileStatus,
    get_space,
)

from .termux_setup import (
    TermuxSetup,
    TermuxDevice,
    get_termux_setup,
)

from .agents import (
    AriaAgent,
    AgentRegistry,
    AgentSwarm,
    AgentMessage,
    MessageType,
    MessagePriority,
    AgentCapability,
    AgentState,
    AgentStatus,
    TaskAgent,
    ReasoningAgent,
    CoordinatorAgent,
    GeneratorAgent,
    create_agent,
    get_registry,
)

from .agent_channels import (
    ChannelManager,
    DirectChannel,
    BroadcastChannel,
    StreamChannel,
    PersistentChannel,
    ChannelType,
    ChannelState,
    get_channel_manager,
)

from .file_manager import (
    AriaFileManager,
    FileManager,
    FileBrowser,
    FileOperations,
    FileTransfer,
    FileRouter,
    Environment,
    FileEntry,
    OperationResult,
    Platform,
    FileType,
    FileLocation,
    OperationType,
    EnvironmentDetector,
    get_file_manager,
    get_manager,
)

from .infinite_storage import (
    InfiniteStorage,
    StorageConfig,
    StorageResult,
    StorageBackend,
    CompressionLevel,
    LRUCache,
    PersistentCache,
    get_storage,
)

from .github_automation import (
    GitHubCLI,
    GitHubAutomation,
    GitHubResult,
    F1CycleEngine,
    F1CycleResult,
    M1MasterOrchestrator,
    M1MasterCycle,
    F1Phase,
    CycleStatus,
    SystemType,
    get_github_cli,
    get_github_automation,
    quick_status,
)

from .terminal_f1_mesh import (
    F1TerminalMesh,
    TerminalNode,
    TerminalIdentity,
    TerminalSnapshot,
    TerminalState,
    MeshTopology,
    MeshConnection,
    F1Improvement,
    ImprovementType,
    F1TerminalAnalyzer,
    F1TerminalImprover,
    F1TerminalValidator,
    get_mesh,
    create_terminal,
    run_f1_between,
)

# CLI imports (may fail if typer/rich not installed)
try:
    from .cli import (
        AriaCLI,
        main,
    )
except ImportError:
    AriaCLI = None
    def main():
        print("ARIA CLI v1.0.5 - Install typer and rich for full CLI: pip install typer rich")
        print("Core modules available: from aria_cli import QSystem, NLPEngine, LLMConnector")

# New v1.0.5 modules (optional imports)
try:
    from .network_scanner import (
        NetworkScanner,
        NetworkDevice,
        OpenPort,
        ScanResult as NetworkScanResult,
        DeviceType,
        ServiceType,
        quick_scan as network_quick_scan,
        find_mesh_servers,
    )
except ImportError:
    NetworkScanner = None

try:
    from .device_monitor import (
        DeviceMonitor,
        SystemMetrics,
        ProcessInfo,
        Alert,
        AlertLevel,
        MetricType,
        quick_status as monitor_quick_status,
        top_processes,
    )
except ImportError:
    DeviceMonitor = None

try:
    from .compression_tools import (
        CompressionEngine,
        Algorithm,
        CompressionResult,
        BenchmarkResult,
        StreamingCompressor,
        compress,
        decompress,
        benchmark_data,
        best_algorithm,
    )
except ImportError:
    CompressionEngine = None

try:
    from .security_scanner import (
        SecurityScanner,
        SecurityFinding,
        Severity,
        FindingType,
        quick_scan as security_quick_scan,
        find_secrets_in_file,
        scan_for_vulnerabilities,
    )
except ImportError:
    SecurityScanner = None

try:
    from .sync_engine import (
        SyncEngine,
        SyncProfile,
        SyncResult,
        SyncChange,
        FileInfo,
        SyncAction,
        SyncDirection as FileSyncDirection,
        ConflictResolution,
        quick_sync,
        preview_sync,
        bidirectional_sync,
    )
except ImportError:
    SyncEngine = None

__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__description__",
    # Q-System
    "QSystem",
    "QLayer", 
    "QOperator",
    "QCommand",
    # NLP
    "NLPEngine",
    "Intent",
    "Entity",
    "ParsedInput",
    # LLM
    "LLMConnector",
    "LLMProvider",
    "LLMConfig",
    "LLMResponse",
    # Connector
    "AriaConnector",
    "SyncMode",
    "AriaPlugin",
    "PluginManager",
    # Q38 Native Integration
    "Q38Connector",
    "Q38Config",
    "Q38Response",
    # Knowledge Base (SQLite)
    "KnowledgeConnector",
    "KnowledgeResult",
    "ARIAConnector",  # Legacy alias
    # Authentication
    "AuthManager",
    "AuthProvider",
    "AuthStatus",
    "User",
    "Session",
    "CredentialStore",
    "get_auth",
    # SSH Router
    "SSHRouter",
    "SSHHost",
    "SSHConnection",
    "SSHAuthMethod",
    "ConnectionStatus",
    "CommandResult",
    "get_router",
    # AriaSpace - Personal Codespace
    "AriaSpace",
    "Workspace",
    "SyncFile",
    "SyncResult",
    "SyncDirection",
    "SyncStrategy",
    "FileStatus",
    "get_space",
    # Termux Integration
    "TermuxSetup",
    "TermuxDevice",
    "get_termux_setup",
    # Agents
    "AriaAgent",
    "AgentRegistry",
    "AgentSwarm",
    "AgentMessage",
    "MessageType",
    "MessagePriority",
    "AgentCapability",
    "AgentState",
    "AgentStatus",
    "TaskAgent",
    "ReasoningAgent",
    "CoordinatorAgent",
    "GeneratorAgent",
    "create_agent",
    "get_registry",
    # Agent Channels
    "ChannelManager",
    "DirectChannel",
    "BroadcastChannel",
    "StreamChannel",
    "PersistentChannel",
    "ChannelType",
    "ChannelState",
    "get_channel_manager",
    # File Manager
    "AriaFileManager",
    "FileManager",
    "FileBrowser",
    "FileOperations",
    "FileTransfer",
    "FileRouter",
    "Environment",
    "FileEntry",
    "OperationResult",
    "Platform",
    "FileType",
    "FileLocation",
    "OperationType",
    "EnvironmentDetector",
    "get_file_manager",
    "get_manager",
    # Infinite Storage
    "InfiniteStorage",
    "StorageConfig",
    "StorageResult",
    "StorageBackend",
    "CompressionLevel",
    "LRUCache",
    "PersistentCache",
    "get_storage",
    # GitHub Automation (F1/M1 Cycles)
    "GitHubCLI",
    "GitHubAutomation",
    "GitHubResult",
    "F1CycleEngine",
    "F1CycleResult",
    "M1MasterOrchestrator",
    "M1MasterCycle",
    "F1Phase",
    "CycleStatus",
    "SystemType",
    "get_github_cli",
    "get_github_automation",
    "quick_status",
    # Terminal F1 Mesh
    "F1TerminalMesh",
    "TerminalNode",
    "TerminalIdentity",
    "TerminalSnapshot",
    "TerminalState",
    "MeshTopology",
    "MeshConnection",
    "F1Improvement",
    "ImprovementType",
    "F1TerminalAnalyzer",
    "F1TerminalImprover",
    "F1TerminalValidator",
    "get_mesh",
    "create_terminal",
    "run_f1_between",
    # CLI
    "AriaCLI",
    "main",
    # Network Scanner (v1.0.5)
    "NetworkScanner",
    "NetworkDevice",
    "OpenPort",
    "NetworkScanResult",
    "DeviceType",
    "ServiceType",
    "network_quick_scan",
    "find_mesh_servers",
    # Device Monitor (v1.0.5)
    "DeviceMonitor",
    "SystemMetrics",
    "ProcessInfo",
    "Alert",
    "AlertLevel",
    "MetricType",
    "monitor_quick_status",
    "top_processes",
    # Compression Tools (v1.0.5)
    "CompressionEngine",
    "Algorithm",
    "CompressionResult",
    "BenchmarkResult",
    "StreamingCompressor",
    "compress",
    "decompress",
    "benchmark_data",
    "best_algorithm",
    # Security Scanner (v1.0.5)
    "SecurityScanner",
    "SecurityFinding",
    "Severity",
    "FindingType",
    "security_quick_scan",
    "find_secrets_in_file",
    "scan_for_vulnerabilities",
    # Sync Engine (v1.0.5)
    "SyncEngine",
    "SyncProfile",
    "SyncResult",
    "SyncChange",
    "FileInfo",
    "SyncAction",
    "FileSyncDirection",
    "ConflictResolution",
    "quick_sync",
    "preview_sync",
    "bidirectional_sync",
]
