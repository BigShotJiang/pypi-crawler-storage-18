"""
ARIA QR Connect v1.0.0

QR code generation for mesh network connections.

Features:
  - Generate QR codes for mesh connection
  - Encode connection URLs and credentials
  - Support for terminal and image output
  - Deep link generation for mobile apps
"""

import json
import base64
import hashlib
import time
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from pathlib import Path
from enum import Enum

# Try to import qrcode library
try:
    import qrcode
    from qrcode.constants import ERROR_CORRECT_L, ERROR_CORRECT_M, ERROR_CORRECT_Q, ERROR_CORRECT_H
    HAS_QRCODE = True
except ImportError:
    HAS_QRCODE = False
    ERROR_CORRECT_L = ERROR_CORRECT_M = ERROR_CORRECT_Q = ERROR_CORRECT_H = 0

# Try PIL for image output
try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


# =============================================================================
# ENUMS AND DATACLASSES
# =============================================================================

class QRFormat(str, Enum):
    """QR code output formats"""
    TERMINAL = "terminal"
    PNG = "png"
    SVG = "svg"
    ASCII = "ascii"
    UTF8 = "utf8"


class ConnectionType(str, Enum):
    """Types of connections encoded in QR"""
    MESH_SERVER = "mesh_server"
    TAILSCALE_PEER = "tailscale_peer"
    WIFI_DIRECT = "wifi_direct"
    BLUETOOTH = "bluetooth"
    URL = "url"


@dataclass
class MeshConnectionInfo:
    """Information for mesh connection"""
    host: str
    port: int = 8765
    name: str = ""
    token: Optional[str] = None
    protocol: str = "ws"
    tailscale_ip: Optional[str] = None
    capabilities: List[str] = field(default_factory=list)
    
    def to_url(self) -> str:
        """Convert to WebSocket URL"""
        auth = f"?token={self.token}" if self.token else ""
        return f"{self.protocol}://{self.host}:{self.port}/mesh{auth}"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "aria_mesh",
            "version": "1.0",
            "host": self.host,
            "port": self.port,
            "name": self.name,
            "token": self.token,
            "protocol": self.protocol,
            "tailscale_ip": self.tailscale_ip,
            "capabilities": self.capabilities,
            "timestamp": int(time.time()),
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(',', ':'))
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MeshConnectionInfo":
        return cls(
            host=data["host"],
            port=data.get("port", 8765),
            name=data.get("name", ""),
            token=data.get("token"),
            protocol=data.get("protocol", "ws"),
            tailscale_ip=data.get("tailscale_ip"),
            capabilities=data.get("capabilities", []),
        )


@dataclass
class QRResult:
    """Result of QR code generation"""
    success: bool
    data: str
    format: QRFormat
    filepath: Optional[Path] = None
    ascii_art: Optional[str] = None
    error: Optional[str] = None


# =============================================================================
# QR CODE GENERATOR
# =============================================================================

class QRGenerator:
    """
    QR code generator for ARIA mesh connections
    
    Usage:
        gen = QRGenerator()
        
        # Generate mesh connection QR
        result = gen.generate_mesh_qr("192.168.1.100", port=8765, name="MyPC")
        
        # Print to terminal
        gen.print_qr(result)
        
        # Save as image
        gen.save_qr(result, "mesh_connect.png")
    """
    
    # ASCII characters for QR rendering
    ASCII_CHARS = {
        "block": "██",
        "space": "  ",
        "half_top": "▀▀",
        "half_bottom": "▄▄",
    }
    
    UTF8_CHARS = {
        True: "█",
        False: " ",
    }
    
    def __init__(self, box_size: int = 10, border: int = 4):
        self.box_size = box_size
        self.border = border
        self.output_dir = Path.home() / ".aria" / "qr-codes"
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def _generate_token(self, seed: str = "") -> str:
        """Generate a connection token"""
        data = f"{seed}{time.time()}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    def _create_qr(self, data: str, error_correction=None) -> Any:
        """Create QR code object"""
        if not HAS_QRCODE:
            raise RuntimeError("qrcode library not installed. Run: pip install qrcode[pil]")
        
        if error_correction is None:
            error_correction = ERROR_CORRECT_M
        
        qr = qrcode.QRCode(
            version=None,  # Auto-size
            error_correction=error_correction,
            box_size=self.box_size,
            border=self.border,
        )
        qr.add_data(data)
        qr.make(fit=True)
        return qr
    
    def _qr_to_ascii(self, qr) -> str:
        """Convert QR code to ASCII art"""
        matrix = qr.get_matrix()
        lines = []
        
        for row in matrix:
            line = ""
            for cell in row:
                line += self.ASCII_CHARS["block"] if cell else self.ASCII_CHARS["space"]
            lines.append(line)
        
        return "\n".join(lines)
    
    def _qr_to_utf8_compact(self, qr) -> str:
        """Convert QR to compact UTF-8 using half-blocks"""
        matrix = qr.get_matrix()
        height = len(matrix)
        lines = []
        
        # Process two rows at a time
        for y in range(0, height, 2):
            line = ""
            for x in range(len(matrix[y])):
                top = matrix[y][x] if y < height else False
                bottom = matrix[y + 1][x] if y + 1 < height else False
                
                if top and bottom:
                    line += "█"
                elif top and not bottom:
                    line += "▀"
                elif not top and bottom:
                    line += "▄"
                else:
                    line += " "
            lines.append(line)
        
        return "\n".join(lines)
    
    # =========================================================================
    # GENERATION METHODS
    # =========================================================================
    
    def generate_mesh_qr(
        self,
        host: str,
        port: int = 8765,
        name: str = "",
        include_token: bool = True,
        tailscale_ip: Optional[str] = None,
        capabilities: Optional[List[str]] = None,
        output_format: QRFormat = QRFormat.TERMINAL,
    ) -> QRResult:
        """
        Generate QR code for mesh server connection
        
        Args:
            host: Server IP or hostname
            port: Server port
            name: Server name/identifier
            include_token: Generate and include auth token
            tailscale_ip: Optional Tailscale IP
            capabilities: Server capabilities list
            output_format: Output format
        
        Returns:
            QRResult with generated QR code
        """
        token = self._generate_token(host) if include_token else None
        
        info = MeshConnectionInfo(
            host=host,
            port=port,
            name=name or host,
            token=token,
            tailscale_ip=tailscale_ip,
            capabilities=capabilities or ["file_transfer", "compute", "sync"],
        )
        
        return self.generate_from_info(info, output_format)
    
    def generate_from_info(
        self,
        info: MeshConnectionInfo,
        output_format: QRFormat = QRFormat.TERMINAL,
    ) -> QRResult:
        """Generate QR from MeshConnectionInfo"""
        data = info.to_json()
        return self.generate(data, output_format)
    
    def generate_url_qr(
        self,
        url: str,
        output_format: QRFormat = QRFormat.TERMINAL,
    ) -> QRResult:
        """Generate QR code for a URL"""
        return self.generate(url, output_format)
    
    def generate(
        self,
        data: str,
        output_format: QRFormat = QRFormat.TERMINAL,
    ) -> QRResult:
        """
        Generate QR code from arbitrary data
        
        Args:
            data: Data to encode
            output_format: Output format
        
        Returns:
            QRResult with QR code
        """
        if not HAS_QRCODE:
            # Fallback: return data as base64
            return QRResult(
                success=False,
                data=data,
                format=output_format,
                error="qrcode library not installed. Run: pip install qrcode[pil]",
            )
        
        try:
            qr = self._create_qr(data)
            
            if output_format in [QRFormat.TERMINAL, QRFormat.ASCII]:
                ascii_art = self._qr_to_ascii(qr)
                return QRResult(
                    success=True,
                    data=data,
                    format=output_format,
                    ascii_art=ascii_art,
                )
            
            elif output_format == QRFormat.UTF8:
                utf8_art = self._qr_to_utf8_compact(qr)
                return QRResult(
                    success=True,
                    data=data,
                    format=output_format,
                    ascii_art=utf8_art,
                )
            
            elif output_format == QRFormat.PNG:
                if not HAS_PIL:
                    return QRResult(
                        success=False,
                        data=data,
                        format=output_format,
                        error="PIL not installed. Run: pip install pillow",
                    )
                
                filepath = self.output_dir / f"qr_{int(time.time())}.png"
                img = qr.make_image(fill_color="black", back_color="white")
                img.save(str(filepath))
                
                return QRResult(
                    success=True,
                    data=data,
                    format=output_format,
                    filepath=filepath,
                )
            
            elif output_format == QRFormat.SVG:
                try:
                    import qrcode.image.svg
                    filepath = self.output_dir / f"qr_{int(time.time())}.svg"
                    img = qr.make_image(image_factory=qrcode.image.svg.SvgImage)
                    img.save(str(filepath))
                    
                    return QRResult(
                        success=True,
                        data=data,
                        format=output_format,
                        filepath=filepath,
                    )
                except ImportError:
                    return QRResult(
                        success=False,
                        data=data,
                        format=output_format,
                        error="SVG support not available",
                    )
            
            else:
                return QRResult(
                    success=False,
                    data=data,
                    format=output_format,
                    error=f"Unknown format: {output_format}",
                )
        
        except Exception as e:
            return QRResult(
                success=False,
                data=data,
                format=output_format,
                error=str(e),
            )
    
    # =========================================================================
    # OUTPUT METHODS
    # =========================================================================
    
    def print_qr(self, result: QRResult, title: Optional[str] = None):
        """Print QR code to terminal"""
        if title:
            print(f"\n{'='*40}")
            print(f"  {title}")
            print(f"{'='*40}\n")
        
        if result.ascii_art:
            print(result.ascii_art)
        elif result.filepath:
            print(f"QR saved to: {result.filepath}")
        elif result.error:
            print(f"Error: {result.error}")
        else:
            print(f"Data: {result.data}")
        
        print()
    
    def save_qr(
        self,
        result: QRResult,
        filepath: Optional[Path] = None,
    ) -> Optional[Path]:
        """Save QR code to file"""
        if result.filepath and result.filepath.exists():
            if filepath:
                import shutil
                shutil.copy(result.filepath, filepath)
                return Path(filepath)
            return result.filepath
        
        if result.ascii_art and filepath:
            with open(filepath, "w") as f:
                f.write(result.ascii_art)
            return Path(filepath)
        
        return None


# =============================================================================
# DEEP LINK GENERATOR
# =============================================================================

class DeepLinkGenerator:
    """Generate deep links for mobile apps"""
    
    SCHEMES = {
        "aria": "aria://",
        "web": "https://aria.mesh/",
    }
    
    def __init__(self, scheme: str = "aria"):
        self.scheme = self.SCHEMES.get(scheme, scheme)
    
    def connect_link(self, info: MeshConnectionInfo) -> str:
        """Generate connect deep link"""
        encoded = base64.urlsafe_b64encode(info.to_json().encode()).decode()
        return f"{self.scheme}connect?data={encoded}"
    
    def file_link(self, host: str, file_id: str) -> str:
        """Generate file download deep link"""
        return f"{self.scheme}file/{host}/{file_id}"
    
    def scan_link(self) -> str:
        """Generate scan/discovery deep link"""
        return f"{self.scheme}scan"


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def generate_mesh_qr(host: str, port: int = 8765, name: str = "") -> QRResult:
    """Quick generate mesh connection QR"""
    gen = QRGenerator()
    return gen.generate_mesh_qr(host, port, name)


def print_mesh_qr(host: str, port: int = 8765, name: str = ""):
    """Generate and print mesh QR to terminal"""
    gen = QRGenerator()
    result = gen.generate_mesh_qr(host, port, name, output_format=QRFormat.UTF8)
    gen.print_qr(result, f"ARIA Mesh: {name or host}:{port}")
    return result


def save_mesh_qr(host: str, port: int = 8765, filepath: str = "mesh_qr.png") -> Path:
    """Generate and save mesh QR as image"""
    gen = QRGenerator()
    result = gen.generate_mesh_qr(host, port, output_format=QRFormat.PNG)
    if result.filepath:
        import shutil
        shutil.copy(result.filepath, filepath)
        return Path(filepath)
    return result.filepath
