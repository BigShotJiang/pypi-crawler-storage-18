"""
ARIA Q-Folder Mesh Network v0.4.0

Multi-Directional Distributed Terminal Communication System

Architecture:
  ┌─────────────────────────────────────────────────────────────┐
  │                    Q-FOLDER MESH NETWORK                     │
  │                                                              │
  │    Terminal-1 ◄──────► Q-Folder ◄──────► Terminal-2         │
  │        │                  │                  │               │
  │        ▼                  ▼                  ▼               │
  │    Q-Folder ◄──────► Q-Folder ◄──────► Q-Folder             │
  │        │                  │                  │               │
  │        ▼                  ▼                  ▼               │
  │    Terminal-3 ◄──────► Q-Folder ◄──────► Terminal-4         │
  └─────────────────────────────────────────────────────────────┘

Key Concepts:
  - Q-Folder: A ported folder that can send/receive messages in ANY direction
  - Mesh Node: A terminal instance with its own Q-Folder port
  - Leapfrog: Message routing through intermediate nodes
  - Handshake: Mutual discovery and connection establishment
  - Multi-Port: Each folder has multiple directional ports (N, S, E, W, UP, DOWN)

Message Flow:
  1. Node A writes to its Q-Folder outbox
  2. Message is picked up by routing daemon
  3. Routed through intermediate Q-Folders (leapfrog)
  4. Arrives at Node B's Q-Folder inbox
  5. Node B processes and can respond via any direction
"""

import asyncio
import json
import os
import time
import uuid
import hashlib
import shutil
import threading
from pathlib import Path
from typing import Optional, List, Dict, Any, Set, Tuple, Callable, Union
from dataclasses import dataclass, field
from enum import Enum, auto
from datetime import datetime
from collections import defaultdict
import queue
import socket

# fcntl is only available on Unix
if os.name != 'nt':
    import fcntl
else:
    fcntl = None


# =============================================================================
# CONSTANTS
# =============================================================================

DEFAULT_MESH_ROOT = Path.home() / ".aria" / "q-mesh"
MESSAGE_EXPIRY_SECONDS = 300  # 5 minutes
HEARTBEAT_INTERVAL = 5.0  # seconds
ROUTING_INTERVAL = 0.5  # seconds
MAX_HOP_COUNT = 10
HANDSHAKE_TIMEOUT = 10.0  # seconds


# =============================================================================
# ENUMS
# =============================================================================

class PortDirection(Enum):
    """Directional ports for Q-Folder communication"""
    NORTH = "north"      # Up in mesh grid
    SOUTH = "south"      # Down in mesh grid  
    EAST = "east"        # Right in mesh grid
    WEST = "west"        # Left in mesh grid
    UP = "up"            # Higher layer/priority
    DOWN = "down"        # Lower layer/priority
    BROADCAST = "broadcast"  # All directions
    DIRECT = "direct"    # Point-to-point (skip routing)


class MessageType(Enum):
    """Types of messages in the Q-Folder mesh"""
    HANDSHAKE_REQUEST = "handshake_request"
    HANDSHAKE_RESPONSE = "handshake_response"
    HEARTBEAT = "heartbeat"
    DATA = "data"
    COMMAND = "command"
    RESPONSE = "response"
    BROADCAST = "broadcast"
    LEAPFROG = "leapfrog"  # Relay message
    SYNC = "sync"
    DISCONNECT = "disconnect"
    ROUTE_DISCOVERY = "route_discovery"
    ROUTE_ANNOUNCE = "route_announce"


class NodeState(Enum):
    """State of a mesh node"""
    INITIALIZING = "initializing"
    DISCOVERING = "discovering"
    CONNECTED = "connected"
    ROUTING = "routing"
    IDLE = "idle"
    BUSY = "busy"
    OFFLINE = "offline"
    ERROR = "error"


class ConnectionState(Enum):
    """State of a connection between nodes"""
    PENDING = "pending"
    HANDSHAKING = "handshaking"
    ESTABLISHED = "established"
    STALE = "stale"
    DISCONNECTED = "disconnected"


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class QMessage:
    """A message in the Q-Folder mesh network"""
    id: str
    type: MessageType
    source_node: str
    target_node: str  # Can be specific node ID or "broadcast"
    port: PortDirection
    payload: Dict[str, Any]
    timestamp: float
    ttl: int  # Time-to-live (hop count)
    hops: List[str] = field(default_factory=list)  # Nodes traversed
    priority: int = 5  # 1-10
    requires_ack: bool = False
    ack_id: Optional[str] = None  # If this is an ACK, references original
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type.value,
            "source_node": self.source_node,
            "target_node": self.target_node,
            "port": self.port.value,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "ttl": self.ttl,
            "hops": self.hops,
            "priority": self.priority,
            "requires_ack": self.requires_ack,
            "ack_id": self.ack_id,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'QMessage':
        return cls(
            id=data["id"],
            type=MessageType(data["type"]),
            source_node=data["source_node"],
            target_node=data["target_node"],
            port=PortDirection(data["port"]),
            payload=data["payload"],
            timestamp=data["timestamp"],
            ttl=data["ttl"],
            hops=data.get("hops", []),
            priority=data.get("priority", 5),
            requires_ack=data.get("requires_ack", False),
            ack_id=data.get("ack_id"),
        )
    
    @property
    def is_expired(self) -> bool:
        return (time.time() - self.timestamp) > MESSAGE_EXPIRY_SECONDS
    
    @property
    def hop_count(self) -> int:
        return len(self.hops)
    
    def add_hop(self, node_id: str) -> None:
        self.hops.append(node_id)
        self.ttl -= 1


@dataclass
class NodeInfo:
    """Information about a mesh node"""
    id: str
    name: str
    host: str
    pid: int
    folder_path: Path
    created_at: float
    last_seen: float
    state: NodeState
    capabilities: Set[str] = field(default_factory=set)
    ports: Dict[str, str] = field(default_factory=dict)  # direction -> connected_node_id
    metrics: Dict[str, float] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "host": self.host,
            "pid": self.pid,
            "folder_path": str(self.folder_path),
            "created_at": self.created_at,
            "last_seen": self.last_seen,
            "state": self.state.value,
            "capabilities": list(self.capabilities),
            "ports": self.ports,
            "metrics": self.metrics,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'NodeInfo':
        return cls(
            id=data["id"],
            name=data["name"],
            host=data["host"],
            pid=data["pid"],
            folder_path=Path(data["folder_path"]),
            created_at=data["created_at"],
            last_seen=data["last_seen"],
            state=NodeState(data["state"]),
            capabilities=set(data.get("capabilities", [])),
            ports=data.get("ports", {}),
            metrics=data.get("metrics", {}),
        )
    
    @property
    def is_stale(self) -> bool:
        return (time.time() - self.last_seen) > (HEARTBEAT_INTERVAL * 3)


@dataclass
class RouteEntry:
    """A routing table entry"""
    target_node: str
    next_hop: str
    hop_count: int
    port: PortDirection
    last_updated: float
    latency_ms: float = 0.0
    reliability: float = 1.0  # 0-1
    
    @property
    def is_stale(self) -> bool:
        return (time.time() - self.last_updated) > 60.0  # 1 minute


@dataclass
class PeerConnection:
    """A connection to a peer node"""
    peer_id: str
    peer_info: NodeInfo
    state: ConnectionState
    port: PortDirection
    established_at: float
    last_message: float
    messages_sent: int = 0
    messages_received: int = 0
    errors: int = 0
    
    @property
    def is_healthy(self) -> bool:
        return self.state == ConnectionState.ESTABLISHED and not self.peer_info.is_stale


# =============================================================================
# Q-FOLDER CLASS
# =============================================================================

class QFolder:
    """
    A ported folder that can communicate in multiple directions.
    Each Q-Folder has:
      - inbox/  : Incoming messages
      - outbox/ : Outgoing messages
      - routes/ : Routing table
      - peers/  : Peer node info
      - pending/: Messages awaiting ACK
    """
    
    def __init__(self, node_id: str, folder_path: Path):
        self.node_id = node_id
        self.path = folder_path
        self._setup_structure()
    
    def _setup_structure(self) -> None:
        """Create folder structure"""
        (self.path / "inbox").mkdir(parents=True, exist_ok=True)
        (self.path / "outbox").mkdir(parents=True, exist_ok=True)
        (self.path / "routes").mkdir(parents=True, exist_ok=True)
        (self.path / "peers").mkdir(parents=True, exist_ok=True)
        (self.path / "pending").mkdir(parents=True, exist_ok=True)
        (self.path / "processed").mkdir(parents=True, exist_ok=True)
    
    @property
    def inbox(self) -> Path:
        return self.path / "inbox"
    
    @property
    def outbox(self) -> Path:
        return self.path / "outbox"
    
    @property
    def routes(self) -> Path:
        return self.path / "routes"
    
    @property
    def peers(self) -> Path:
        return self.path / "peers"
    
    @property
    def pending(self) -> Path:
        return self.path / "pending"
    
    @property
    def processed(self) -> Path:
        return self.path / "processed"
    
    def write_message(self, msg: QMessage, outgoing: bool = True) -> Path:
        """Write a message to inbox or outbox"""
        folder = self.outbox if outgoing else self.inbox
        filename = f"{msg.priority:02d}_{msg.timestamp:.0f}_{msg.id}.json"
        filepath = folder / filename
        
        with open(filepath, 'w') as f:
            json.dump(msg.to_dict(), f, indent=2)
        
        return filepath
    
    def read_messages(self, incoming: bool = True, limit: int = 100) -> List[Tuple[QMessage, Path]]:
        """Read messages from inbox or outbox, sorted by priority"""
        folder = self.inbox if incoming else self.outbox
        messages = []
        
        for filepath in sorted(folder.glob("*.json"))[:limit]:
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                msg = QMessage.from_dict(data)
                if not msg.is_expired:
                    messages.append((msg, filepath))
                else:
                    # Clean up expired
                    filepath.unlink()
            except Exception as e:
                print(f"Error reading message {filepath}: {e}")
        
        return messages
    
    def move_to_processed(self, filepath: Path) -> None:
        """Move a processed message to archive"""
        dest = self.processed / filepath.name
        shutil.move(str(filepath), str(dest))
    
    def delete_message(self, filepath: Path) -> None:
        """Delete a message file"""
        if filepath.exists():
            filepath.unlink()
    
    def save_peer(self, peer: NodeInfo) -> None:
        """Save peer information"""
        filepath = self.peers / f"{peer.id}.json"
        with open(filepath, 'w') as f:
            json.dump(peer.to_dict(), f, indent=2)
    
    def load_peers(self) -> List[NodeInfo]:
        """Load all peer information"""
        peers = []
        for filepath in self.peers.glob("*.json"):
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                peers.append(NodeInfo.from_dict(data))
            except Exception:
                pass
        return peers
    
    def save_route(self, route: RouteEntry) -> None:
        """Save a routing entry"""
        filepath = self.routes / f"{route.target_node}.json"
        with open(filepath, 'w') as f:
            json.dump({
                "target_node": route.target_node,
                "next_hop": route.next_hop,
                "hop_count": route.hop_count,
                "port": route.port.value,
                "last_updated": route.last_updated,
                "latency_ms": route.latency_ms,
                "reliability": route.reliability,
            }, f, indent=2)
    
    def load_routes(self) -> Dict[str, RouteEntry]:
        """Load all routing entries"""
        routes = {}
        for filepath in self.routes.glob("*.json"):
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                route = RouteEntry(
                    target_node=data["target_node"],
                    next_hop=data["next_hop"],
                    hop_count=data["hop_count"],
                    port=PortDirection(data["port"]),
                    last_updated=data["last_updated"],
                    latency_ms=data.get("latency_ms", 0.0),
                    reliability=data.get("reliability", 1.0),
                )
                if not route.is_stale:
                    routes[route.target_node] = route
            except Exception:
                pass
        return routes
    
    def cleanup_old_messages(self, max_age_seconds: int = 3600) -> int:
        """Clean up old messages from processed folder"""
        cleaned = 0
        cutoff = time.time() - max_age_seconds
        
        for filepath in self.processed.glob("*.json"):
            if filepath.stat().st_mtime < cutoff:
                filepath.unlink()
                cleaned += 1
        
        return cleaned


# =============================================================================
# MESH NODE CLASS
# =============================================================================

class QMeshNode:
    """
    A node in the Q-Folder mesh network.
    
    Each node:
      - Has its own Q-Folder for message passing
      - Discovers and connects to peer nodes
      - Routes messages through the mesh
      - Can send/receive in any direction (leapfrogging)
    """
    
    def __init__(
        self,
        name: Optional[str] = None,
        mesh_root: Optional[Path] = None,
    ):
        self.id = str(uuid.uuid4())[:8]
        self.name = name or f"node-{self.id}"
        self.host = socket.gethostname()
        self.pid = os.getpid()
        self.created_at = time.time()
        self.state = NodeState.INITIALIZING
        
        # Set up Q-Folder
        self.mesh_root = mesh_root or DEFAULT_MESH_ROOT
        self.folder_path = self.mesh_root / "nodes" / self.id
        self.q_folder = QFolder(self.id, self.folder_path)
        
        # Connections and routing
        self.peers: Dict[str, PeerConnection] = {}
        self.routing_table: Dict[str, RouteEntry] = {}
        self.port_assignments: Dict[PortDirection, str] = {}  # direction -> peer_id
        
        # Message handling
        self.message_handlers: Dict[MessageType, Callable] = {}
        self.pending_acks: Dict[str, QMessage] = {}
        self.received_ids: Set[str] = set()  # Prevent duplicates
        
        # Background tasks
        self._running = False
        self._tasks: List[asyncio.Task] = []
        self._message_queue: queue.Queue = queue.Queue()
        
        # Metrics
        self.metrics = {
            "messages_sent": 0,
            "messages_received": 0,
            "messages_routed": 0,
            "handshakes_completed": 0,
            "errors": 0,
        }
        
        # Register default handlers
        self._register_default_handlers()
        
        # Announce presence
        self._announce_node()
    
    def _register_default_handlers(self) -> None:
        """Register default message handlers"""
        self.message_handlers[MessageType.HANDSHAKE_REQUEST] = self._handle_handshake_request
        self.message_handlers[MessageType.HANDSHAKE_RESPONSE] = self._handle_handshake_response
        self.message_handlers[MessageType.HEARTBEAT] = self._handle_heartbeat
        self.message_handlers[MessageType.ROUTE_DISCOVERY] = self._handle_route_discovery
        self.message_handlers[MessageType.ROUTE_ANNOUNCE] = self._handle_route_announce
        self.message_handlers[MessageType.DATA] = self._handle_data
        self.message_handlers[MessageType.COMMAND] = self._handle_command
        self.message_handlers[MessageType.LEAPFROG] = self._handle_leapfrog
        self.message_handlers[MessageType.DISCONNECT] = self._handle_disconnect
    
    def _announce_node(self) -> None:
        """Announce this node's presence in the mesh"""
        info = self.get_info()
        
        # Write to shared registry
        registry_path = self.mesh_root / "registry"
        registry_path.mkdir(parents=True, exist_ok=True)
        
        node_file = registry_path / f"{self.id}.json"
        with open(node_file, 'w') as f:
            json.dump(info.to_dict(), f, indent=2)
    
    def get_info(self) -> NodeInfo:
        """Get this node's information"""
        return NodeInfo(
            id=self.id,
            name=self.name,
            host=self.host,
            pid=self.pid,
            folder_path=self.folder_path,
            created_at=self.created_at,
            last_seen=time.time(),
            state=self.state,
            capabilities={"route", "relay", "f1", "sync"},
            ports={d.value: p for d, p in self.port_assignments.items()},
            metrics=self.metrics,
        )
    
    # =========================================================================
    # DISCOVERY
    # =========================================================================
    
    def discover_peers(self) -> List[NodeInfo]:
        """Discover other nodes in the mesh"""
        self.state = NodeState.DISCOVERING
        peers = []
        
        registry_path = self.mesh_root / "registry"
        if not registry_path.exists():
            return peers
        
        for node_file in registry_path.glob("*.json"):
            if node_file.stem == self.id:
                continue  # Skip self
            
            try:
                with open(node_file, 'r') as f:
                    data = json.load(f)
                
                info = NodeInfo.from_dict(data)
                
                # Check if node is alive (file was updated recently)
                if not info.is_stale:
                    peers.append(info)
                else:
                    # Clean up stale node
                    node_file.unlink()
            except Exception as e:
                print(f"Error reading node {node_file}: {e}")
        
        return peers
    
    def connect_to_peer(self, peer_info: NodeInfo, port: PortDirection) -> bool:
        """Establish connection to a peer node"""
        if peer_info.id in self.peers:
            return True  # Already connected
        
        # Send handshake
        handshake_msg = self._create_message(
            type=MessageType.HANDSHAKE_REQUEST,
            target=peer_info.id,
            port=port,
            payload={
                "node_info": self.get_info().to_dict(),
                "requested_port": port.value,
            },
            requires_ack=True,
        )
        
        self._send_to_peer_folder(handshake_msg, peer_info.folder_path)
        
        # Create pending connection
        self.peers[peer_info.id] = PeerConnection(
            peer_id=peer_info.id,
            peer_info=peer_info,
            state=ConnectionState.HANDSHAKING,
            port=port,
            established_at=0,
            last_message=time.time(),
        )
        
        return True
    
    def auto_connect(self, max_peers: int = 6) -> int:
        """Automatically discover and connect to peers"""
        peers = self.discover_peers()
        connected = 0
        
        # Assign ports in order
        available_ports = [
            PortDirection.NORTH,
            PortDirection.SOUTH,
            PortDirection.EAST,
            PortDirection.WEST,
            PortDirection.UP,
            PortDirection.DOWN,
        ]
        
        for i, peer in enumerate(peers[:max_peers]):
            if peer.id not in self.peers:
                port = available_ports[i % len(available_ports)]
                if self.connect_to_peer(peer, port):
                    connected += 1
        
        return connected
    
    # =========================================================================
    # MESSAGE CREATION AND SENDING
    # =========================================================================
    
    def _create_message(
        self,
        type: MessageType,
        target: str,
        port: PortDirection,
        payload: Dict[str, Any],
        priority: int = 5,
        requires_ack: bool = False,
        ack_id: Optional[str] = None,
    ) -> QMessage:
        """Create a new message"""
        return QMessage(
            id=str(uuid.uuid4())[:12],
            type=type,
            source_node=self.id,
            target_node=target,
            port=port,
            payload=payload,
            timestamp=time.time(),
            ttl=MAX_HOP_COUNT,
            hops=[],
            priority=priority,
            requires_ack=requires_ack,
            ack_id=ack_id,
        )
    
    def send_message(
        self,
        target: str,
        payload: Dict[str, Any],
        msg_type: MessageType = MessageType.DATA,
        port: Optional[PortDirection] = None,
        priority: int = 5,
    ) -> str:
        """Send a message to a target node"""
        # Determine port
        if port is None:
            route = self.routing_table.get(target)
            if route:
                port = route.port
            else:
                port = PortDirection.DIRECT
        
        msg = self._create_message(
            type=msg_type,
            target=target,
            port=port,
            payload=payload,
            priority=priority,
        )
        
        # Write to outbox
        self.q_folder.write_message(msg, outgoing=True)
        self.metrics["messages_sent"] += 1
        
        return msg.id
    
    def broadcast(
        self,
        payload: Dict[str, Any],
        msg_type: MessageType = MessageType.BROADCAST,
        priority: int = 5,
    ) -> str:
        """Broadcast a message to all connected peers"""
        msg = self._create_message(
            type=msg_type,
            target="broadcast",
            port=PortDirection.BROADCAST,
            payload=payload,
            priority=priority,
        )
        
        # Send to all peers
        for peer_id, conn in self.peers.items():
            if conn.state == ConnectionState.ESTABLISHED:
                self._send_to_peer_folder(msg, conn.peer_info.folder_path)
        
        self.metrics["messages_sent"] += 1
        return msg.id
    
    def _send_to_peer_folder(self, msg: QMessage, peer_folder: Path) -> None:
        """Send a message directly to a peer's inbox"""
        inbox = peer_folder / "inbox"
        inbox.mkdir(parents=True, exist_ok=True)
        
        filename = f"{msg.priority:02d}_{msg.timestamp:.0f}_{msg.id}.json"
        filepath = inbox / filename
        
        with open(filepath, 'w') as f:
            json.dump(msg.to_dict(), f, indent=2)
    
    # =========================================================================
    # MESSAGE ROUTING (LEAPFROG)
    # =========================================================================
    
    def route_message(self, msg: QMessage) -> bool:
        """Route a message through the mesh (leapfrog)"""
        if msg.target_node == self.id:
            return False  # Message is for us
        
        if msg.ttl <= 0:
            return False  # TTL expired
        
        if msg.target_node == "broadcast":
            # Broadcast to all peers except source
            for peer_id, conn in self.peers.items():
                if peer_id not in msg.hops and conn.state == ConnectionState.ESTABLISHED:
                    relay_msg = QMessage.from_dict(msg.to_dict())
                    relay_msg.add_hop(self.id)
                    relay_msg.type = MessageType.LEAPFROG
                    self._send_to_peer_folder(relay_msg, conn.peer_info.folder_path)
            
            self.metrics["messages_routed"] += 1
            return True
        
        # Find route to target
        route = self.routing_table.get(msg.target_node)
        if route:
            next_hop = route.next_hop
        else:
            # No known route - flood to all peers
            for peer_id, conn in self.peers.items():
                if peer_id not in msg.hops and conn.state == ConnectionState.ESTABLISHED:
                    relay_msg = QMessage.from_dict(msg.to_dict())
                    relay_msg.add_hop(self.id)
                    relay_msg.type = MessageType.LEAPFROG
                    self._send_to_peer_folder(relay_msg, conn.peer_info.folder_path)
            
            self.metrics["messages_routed"] += 1
            return True
        
        # Route to next hop
        if next_hop in self.peers:
            conn = self.peers[next_hop]
            relay_msg = QMessage.from_dict(msg.to_dict())
            relay_msg.add_hop(self.id)
            relay_msg.type = MessageType.LEAPFROG
            self._send_to_peer_folder(relay_msg, conn.peer_info.folder_path)
            self.metrics["messages_routed"] += 1
            return True
        
        return False
    
    # =========================================================================
    # MESSAGE HANDLERS
    # =========================================================================
    
    def _handle_handshake_request(self, msg: QMessage) -> None:
        """Handle incoming handshake request"""
        peer_info = NodeInfo.from_dict(msg.payload["node_info"])
        requested_port = PortDirection(msg.payload["requested_port"])
        
        # Accept connection
        self.peers[peer_info.id] = PeerConnection(
            peer_id=peer_info.id,
            peer_info=peer_info,
            state=ConnectionState.ESTABLISHED,
            port=self._opposite_port(requested_port),
            established_at=time.time(),
            last_message=time.time(),
        )
        
        # Send response
        response = self._create_message(
            type=MessageType.HANDSHAKE_RESPONSE,
            target=msg.source_node,
            port=self._opposite_port(requested_port),
            payload={
                "node_info": self.get_info().to_dict(),
                "accepted": True,
                "assigned_port": self._opposite_port(requested_port).value,
            },
            ack_id=msg.id,
        )
        
        self._send_to_peer_folder(response, peer_info.folder_path)
        self.port_assignments[self._opposite_port(requested_port)] = peer_info.id
        self.metrics["handshakes_completed"] += 1
        
        # Save peer info
        self.q_folder.save_peer(peer_info)
        
        # Update routing table
        self.routing_table[peer_info.id] = RouteEntry(
            target_node=peer_info.id,
            next_hop=peer_info.id,
            hop_count=1,
            port=self._opposite_port(requested_port),
            last_updated=time.time(),
        )
    
    def _handle_handshake_response(self, msg: QMessage) -> None:
        """Handle handshake response"""
        if msg.source_node in self.peers:
            conn = self.peers[msg.source_node]
            if msg.payload.get("accepted"):
                conn.state = ConnectionState.ESTABLISHED
                conn.established_at = time.time()
                
                peer_info = NodeInfo.from_dict(msg.payload["node_info"])
                conn.peer_info = peer_info
                
                assigned_port = PortDirection(msg.payload["assigned_port"])
                self.port_assignments[self._opposite_port(assigned_port)] = msg.source_node
                
                self.metrics["handshakes_completed"] += 1
                
                # Save peer and route
                self.q_folder.save_peer(peer_info)
                self.routing_table[peer_info.id] = RouteEntry(
                    target_node=peer_info.id,
                    next_hop=peer_info.id,
                    hop_count=1,
                    port=self._opposite_port(assigned_port),
                    last_updated=time.time(),
                )
    
    def _handle_heartbeat(self, msg: QMessage) -> None:
        """Handle heartbeat message"""
        if msg.source_node in self.peers:
            conn = self.peers[msg.source_node]
            conn.last_message = time.time()
            conn.peer_info.last_seen = time.time()
            conn.messages_received += 1
    
    def _handle_route_discovery(self, msg: QMessage) -> None:
        """Handle route discovery request"""
        # Share our routing table
        routes_data = {
            node_id: {
                "hop_count": route.hop_count + 1,
                "port": route.port.value,
                "reliability": route.reliability,
            }
            for node_id, route in self.routing_table.items()
        }
        
        response = self._create_message(
            type=MessageType.ROUTE_ANNOUNCE,
            target=msg.source_node,
            port=PortDirection.DIRECT,
            payload={"routes": routes_data},
        )
        
        if msg.source_node in self.peers:
            self._send_to_peer_folder(response, self.peers[msg.source_node].peer_info.folder_path)
    
    def _handle_route_announce(self, msg: QMessage) -> None:
        """Handle route announcement"""
        routes_data = msg.payload.get("routes", {})
        
        for node_id, route_info in routes_data.items():
            if node_id == self.id:
                continue
            
            hop_count = route_info["hop_count"]
            existing = self.routing_table.get(node_id)
            
            if existing is None or hop_count < existing.hop_count:
                self.routing_table[node_id] = RouteEntry(
                    target_node=node_id,
                    next_hop=msg.source_node,
                    hop_count=hop_count,
                    port=PortDirection(route_info["port"]),
                    last_updated=time.time(),
                    reliability=route_info.get("reliability", 1.0),
                )
    
    def _handle_data(self, msg: QMessage) -> None:
        """Handle data message"""
        self.metrics["messages_received"] += 1
        # Subclasses or external handlers process this
    
    def _handle_command(self, msg: QMessage) -> None:
        """Handle command message"""
        self.metrics["messages_received"] += 1
        # Execute command and send response
        command = msg.payload.get("command")
        args = msg.payload.get("args", {})
        
        # Basic command handling
        result = {"status": "received", "command": command}
        
        response = self._create_message(
            type=MessageType.RESPONSE,
            target=msg.source_node,
            port=PortDirection.DIRECT,
            payload=result,
            ack_id=msg.id,
        )
        
        if msg.source_node in self.peers:
            self._send_to_peer_folder(response, self.peers[msg.source_node].peer_info.folder_path)
    
    def _handle_leapfrog(self, msg: QMessage) -> None:
        """Handle leapfrog (relay) message"""
        if msg.target_node == self.id or msg.target_node == "broadcast":
            # Message is for us - process it
            original_type = MessageType(msg.payload.get("original_type", MessageType.DATA.value))
            handler = self.message_handlers.get(original_type, self._handle_data)
            handler(msg)
        else:
            # Relay to next hop
            self.route_message(msg)
    
    def _handle_disconnect(self, msg: QMessage) -> None:
        """Handle disconnect message"""
        if msg.source_node in self.peers:
            del self.peers[msg.source_node]
            
            # Remove from port assignments
            for port, peer_id in list(self.port_assignments.items()):
                if peer_id == msg.source_node:
                    del self.port_assignments[port]
            
            # Remove routes through this node
            self.routing_table = {
                k: v for k, v in self.routing_table.items()
                if v.next_hop != msg.source_node
            }
    
    def _opposite_port(self, port: PortDirection) -> PortDirection:
        """Get the opposite port direction"""
        opposites = {
            PortDirection.NORTH: PortDirection.SOUTH,
            PortDirection.SOUTH: PortDirection.NORTH,
            PortDirection.EAST: PortDirection.WEST,
            PortDirection.WEST: PortDirection.EAST,
            PortDirection.UP: PortDirection.DOWN,
            PortDirection.DOWN: PortDirection.UP,
            PortDirection.BROADCAST: PortDirection.BROADCAST,
            PortDirection.DIRECT: PortDirection.DIRECT,
        }
        return opposites.get(port, PortDirection.DIRECT)
    
    # =========================================================================
    # MAIN LOOP
    # =========================================================================
    
    async def process_inbox(self) -> int:
        """Process all messages in inbox"""
        messages = self.q_folder.read_messages(incoming=True)
        processed = 0
        
        for msg, filepath in messages:
            if msg.id in self.received_ids:
                # Duplicate
                self.q_folder.delete_message(filepath)
                continue
            
            self.received_ids.add(msg.id)
            
            # Update peer last_message time
            if msg.source_node in self.peers:
                self.peers[msg.source_node].last_message = time.time()
                self.peers[msg.source_node].messages_received += 1
            
            # Check if message is for us or needs routing
            if msg.target_node == self.id or msg.target_node == "broadcast":
                handler = self.message_handlers.get(msg.type, self._handle_data)
                try:
                    handler(msg)
                except Exception as e:
                    self.metrics["errors"] += 1
                    print(f"Error handling message {msg.id}: {e}")
            else:
                # Route to next hop
                self.route_message(msg)
            
            # Move to processed
            self.q_folder.move_to_processed(filepath)
            processed += 1
        
        return processed
    
    async def process_outbox(self) -> int:
        """Process all messages in outbox (route them)"""
        messages = self.q_folder.read_messages(incoming=False)
        sent = 0
        
        for msg, filepath in messages:
            if msg.target_node == "broadcast":
                # Send to all peers
                for peer_id, conn in self.peers.items():
                    if conn.state == ConnectionState.ESTABLISHED:
                        self._send_to_peer_folder(msg, conn.peer_info.folder_path)
                        conn.messages_sent += 1
            else:
                # Find route and send
                route = self.routing_table.get(msg.target_node)
                if route and route.next_hop in self.peers:
                    conn = self.peers[route.next_hop]
                    self._send_to_peer_folder(msg, conn.peer_info.folder_path)
                    conn.messages_sent += 1
                elif msg.target_node in self.peers:
                    conn = self.peers[msg.target_node]
                    self._send_to_peer_folder(msg, conn.peer_info.folder_path)
                    conn.messages_sent += 1
            
            self.q_folder.delete_message(filepath)
            sent += 1
        
        return sent
    
    async def send_heartbeats(self) -> None:
        """Send heartbeat to all connected peers"""
        for peer_id, conn in self.peers.items():
            if conn.state == ConnectionState.ESTABLISHED:
                heartbeat = self._create_message(
                    type=MessageType.HEARTBEAT,
                    target=peer_id,
                    port=conn.port,
                    payload={"timestamp": time.time()},
                    priority=1,
                )
                self._send_to_peer_folder(heartbeat, conn.peer_info.folder_path)
    
    async def update_registry(self) -> None:
        """Update node info in registry"""
        self._announce_node()
    
    async def run(self) -> None:
        """Main event loop"""
        self._running = True
        self.state = NodeState.IDLE
        
        last_heartbeat = 0
        last_cleanup = 0
        
        while self._running:
            try:
                # Process inbox
                await self.process_inbox()
                
                # Process outbox
                await self.process_outbox()
                
                # Send heartbeats periodically
                if time.time() - last_heartbeat > HEARTBEAT_INTERVAL:
                    await self.send_heartbeats()
                    await self.update_registry()
                    last_heartbeat = time.time()
                
                # Cleanup old messages periodically
                if time.time() - last_cleanup > 300:  # 5 minutes
                    self.q_folder.cleanup_old_messages()
                    last_cleanup = time.time()
                
                # Check for stale peers
                for peer_id, conn in list(self.peers.items()):
                    if conn.peer_info.is_stale:
                        conn.state = ConnectionState.STALE
                
                await asyncio.sleep(ROUTING_INTERVAL)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.metrics["errors"] += 1
                print(f"Error in mesh loop: {e}")
                await asyncio.sleep(1)
        
        self.state = NodeState.OFFLINE
    
    def start(self) -> None:
        """Start the mesh node in a background thread"""
        def run_loop():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            self._loop = loop
            loop.run_until_complete(self.run())
        
        thread = threading.Thread(target=run_loop, daemon=True)
        thread.start()
    
    def stop(self) -> None:
        """Stop the mesh node"""
        self._running = False
        
        # Send disconnect to all peers
        for peer_id, conn in self.peers.items():
            if conn.state == ConnectionState.ESTABLISHED:
                disconnect_msg = self._create_message(
                    type=MessageType.DISCONNECT,
                    target=peer_id,
                    port=conn.port,
                    payload={},
                )
                self._send_to_peer_folder(disconnect_msg, conn.peer_info.folder_path)
        
        # Remove from registry
        registry_file = self.mesh_root / "registry" / f"{self.id}.json"
        if registry_file.exists():
            registry_file.unlink()
    
    # =========================================================================
    # HIGH-LEVEL API
    # =========================================================================
    
    def send(self, target: str, data: Any) -> str:
        """Simple send interface"""
        return self.send_message(
            target=target,
            payload={"data": data},
            msg_type=MessageType.DATA,
        )
    
    def send_command(self, target: str, command: str, args: Dict = None) -> str:
        """Send a command to another node"""
        return self.send_message(
            target=target,
            payload={"command": command, "args": args or {}},
            msg_type=MessageType.COMMAND,
        )
    
    def broadcast_data(self, data: Any) -> str:
        """Broadcast data to all nodes"""
        return self.broadcast(payload={"data": data})
    
    def get_status(self) -> Dict[str, Any]:
        """Get mesh node status"""
        return {
            "id": self.id,
            "name": self.name,
            "state": self.state.value,
            "peers": len(self.peers),
            "connected": sum(1 for c in self.peers.values() if c.state == ConnectionState.ESTABLISHED),
            "routes": len(self.routing_table),
            "ports": {d.value: p for d, p in self.port_assignments.items()},
            "metrics": self.metrics,
        }
    
    def get_mesh_topology(self) -> Dict[str, Any]:
        """Get the full mesh topology as seen by this node"""
        return {
            "self": self.get_info().to_dict(),
            "peers": [
                {
                    "id": conn.peer_id,
                    "name": conn.peer_info.name,
                    "state": conn.state.value,
                    "port": conn.port.value,
                    "messages_sent": conn.messages_sent,
                    "messages_received": conn.messages_received,
                }
                for conn in self.peers.values()
            ],
            "routes": [
                {
                    "target": route.target_node,
                    "next_hop": route.next_hop,
                    "hops": route.hop_count,
                    "port": route.port.value,
                }
                for route in self.routing_table.values()
            ],
        }


# =============================================================================
# MESH NETWORK CLASS (COORDINATOR)
# =============================================================================

class QFolderMesh:
    """
    Coordinator for the Q-Folder mesh network.
    Manages multiple nodes and provides high-level operations.
    """
    
    def __init__(self, mesh_root: Optional[Path] = None):
        self.mesh_root = mesh_root or DEFAULT_MESH_ROOT
        self.mesh_root.mkdir(parents=True, exist_ok=True)
        self.nodes: Dict[str, QMeshNode] = {}
    
    def create_node(self, name: Optional[str] = None) -> QMeshNode:
        """Create a new mesh node"""
        node = QMeshNode(name=name, mesh_root=self.mesh_root)
        self.nodes[node.id] = node
        return node
    
    def discover_all_nodes(self) -> List[NodeInfo]:
        """Discover all nodes in the mesh"""
        nodes = []
        registry = self.mesh_root / "registry"
        
        if not registry.exists():
            return nodes
        
        for node_file in registry.glob("*.json"):
            try:
                with open(node_file, 'r') as f:
                    data = json.load(f)
                nodes.append(NodeInfo.from_dict(data))
            except Exception:
                pass
        
        return nodes
    
    def get_mesh_status(self) -> Dict[str, Any]:
        """Get overall mesh status"""
        all_nodes = self.discover_all_nodes()
        active = [n for n in all_nodes if not n.is_stale]
        
        return {
            "total_nodes": len(all_nodes),
            "active_nodes": len(active),
            "local_nodes": len(self.nodes),
            "nodes": [n.to_dict() for n in active],
        }
    
    def cleanup_stale_nodes(self) -> int:
        """Remove stale nodes from registry"""
        cleaned = 0
        registry = self.mesh_root / "registry"
        
        if not registry.exists():
            return cleaned
        
        for node_file in registry.glob("*.json"):
            try:
                with open(node_file, 'r') as f:
                    data = json.load(f)
                info = NodeInfo.from_dict(data)
                if info.is_stale:
                    node_file.unlink()
                    # Also clean up node folder
                    node_folder = self.mesh_root / "nodes" / info.id
                    if node_folder.exists():
                        shutil.rmtree(node_folder)
                    cleaned += 1
            except Exception:
                pass
        
        return cleaned


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_mesh_node(name: Optional[str] = None) -> QMeshNode:
    """Create and return a new mesh node"""
    return QMeshNode(name=name)


def get_mesh_status() -> Dict[str, Any]:
    """Get the mesh network status"""
    mesh = QFolderMesh()
    return mesh.get_mesh_status()


def list_mesh_nodes() -> List[Dict[str, Any]]:
    """List all nodes in the mesh"""
    mesh = QFolderMesh()
    return [n.to_dict() for n in mesh.discover_all_nodes()]


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        name = sys.argv[1]
    else:
        name = None
    
    print("Creating Q-Folder Mesh Node...")
    node = create_mesh_node(name=name)
    
    print(f"Node ID: {node.id}")
    print(f"Node Name: {node.name}")
    print(f"Folder: {node.folder_path}")
    
    print("\nDiscovering peers...")
    peers = node.discover_peers()
    print(f"Found {len(peers)} peers")
    
    if peers:
        print("\nConnecting to peers...")
        connected = node.auto_connect()
        print(f"Connected to {connected} peers")
    
    print("\nStarting mesh node...")
    node.start()
    
    print("\nNode is running. Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(5)
            status = node.get_status()
            print(f"\rPeers: {status['connected']}/{status['peers']} | Routes: {status['routes']} | Msgs: {status['metrics']['messages_sent']}/{status['metrics']['messages_received']}", end="")
    except KeyboardInterrupt:
        print("\n\nStopping node...")
        node.stop()
        print("Done.")
