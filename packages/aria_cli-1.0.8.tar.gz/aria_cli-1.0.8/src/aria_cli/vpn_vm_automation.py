"""
VPN + VM Integration Automation System
=======================================

Integrates:
- Phone Link (Windows ↔ Android)
- Termux automation via ADB/screen mirroring
- VPN configuration and deployment
- VM provisioning and management
- Q-Symbolic Expansion for config generation

Leverages your Intel Gen14 USB4 for high-speed device communication.
"""

from typing import List, Dict, Any, Generator, Optional, Tuple, Union
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
import subprocess
import json
import time
import os
import re
import socket
import hashlib
import shutil
import tempfile

# Import our modules
try:
    from .quintillion_generator import QuintillionGenerator, GenerationResult
    from .q_symbolic_protocol import SymbolicProtocol, G10QR
    from .usb4_topology_generator import USB4TopologyGenerator
except ImportError:
    from quintillion_generator import QuintillionGenerator, GenerationResult
    from q_symbolic_protocol import SymbolicProtocol, G10QR
    from usb4_topology_generator import USB4TopologyGenerator


class VPNProvider(Enum):
    """Supported VPN providers"""
    WIREGUARD = auto()
    OPENVPN = auto()
    TAILSCALE = auto()
    ZEROTIER = auto()
    CLOUDFLARE_WARP = auto()
    CUSTOM = auto()


class VMPlatform(Enum):
    """VM platforms"""
    HYPER_V = auto()
    VIRTUALBOX = auto()
    VMware = auto()
    WSL = auto()
    DOCKER = auto()
    QEMU = auto()
    TERMUX_PROOT = auto()


class DeviceType(Enum):
    """Connected device types"""
    WINDOWS_HOST = auto()
    ANDROID_PHONE = auto()
    LINUX_VM = auto()
    WSL_INSTANCE = auto()
    DOCKER_CONTAINER = auto()
    REMOTE_SERVER = auto()


@dataclass
class PhoneLinkDevice:
    """Phone Link connected device"""
    name: str
    model: str
    android_version: str
    ip_address: Optional[str]
    adb_serial: Optional[str]
    is_connected: bool
    battery_level: int = 0
    storage_free_gb: float = 0.0
    termux_installed: bool = False
    termux_version: Optional[str] = None


@dataclass
class VPNConfig:
    """VPN configuration"""
    provider: VPNProvider
    name: str
    server: str
    port: int
    protocol: str
    private_key: Optional[str] = None
    public_key: Optional[str] = None
    preshared_key: Optional[str] = None
    address: Optional[str] = None
    dns: List[str] = field(default_factory=lambda: ["1.1.1.1", "8.8.8.8"])
    allowed_ips: List[str] = field(default_factory=lambda: ["0.0.0.0/0"])
    persistent_keepalive: int = 25
    mtu: int = 1420
    
    def to_wireguard_conf(self) -> str:
        """Generate WireGuard config file"""
        return f"""[Interface]
PrivateKey = {self.private_key or '<YOUR_PRIVATE_KEY>'}
Address = {self.address or '10.0.0.2/24'}
DNS = {', '.join(self.dns)}
MTU = {self.mtu}

[Peer]
PublicKey = {self.public_key or '<SERVER_PUBLIC_KEY>'}
PresharedKey = {self.preshared_key or '<OPTIONAL_PSK>'}
Endpoint = {self.server}:{self.port}
AllowedIPs = {', '.join(self.allowed_ips)}
PersistentKeepalive = {self.persistent_keepalive}
"""
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "provider": self.provider.name,
            "name": self.name,
            "server": self.server,
            "port": self.port,
            "protocol": self.protocol,
            "address": self.address,
            "dns": self.dns,
            "allowed_ips": self.allowed_ips,
        }


@dataclass
class VMConfig:
    """Virtual Machine configuration"""
    platform: VMPlatform
    name: str
    os_type: str
    cpus: int = 2
    memory_mb: int = 2048
    disk_gb: int = 20
    network_mode: str = "nat"
    shared_folders: List[str] = field(default_factory=list)
    port_forwards: Dict[int, int] = field(default_factory=dict)
    vpn_config: Optional[VPNConfig] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "platform": self.platform.name,
            "name": self.name,
            "os_type": self.os_type,
            "cpus": self.cpus,
            "memory_mb": self.memory_mb,
            "disk_gb": self.disk_gb,
            "network_mode": self.network_mode,
        }


@dataclass 
class TermuxCommand:
    """Termux command to execute"""
    command: str
    description: str
    requires_root: bool = False
    timeout_seconds: int = 30
    expected_output: Optional[str] = None


class PhoneLinkIntegration:
    """
    Windows Phone Link integration for Android device automation
    """
    
    def __init__(self):
        self.adb_path = self._find_adb()
        self.connected_device: Optional[PhoneLinkDevice] = None
        self.phone_link_folder = Path.home() / "Phone Link"
        
    def _find_adb(self) -> Optional[Path]:
        """Find ADB executable"""
        # Check common locations
        locations = [
            Path(os.environ.get("ANDROID_HOME", "")) / "platform-tools" / "adb.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Android" / "Sdk" / "platform-tools" / "adb.exe",
            Path("C:/Android/sdk/platform-tools/adb.exe"),
            Path("C:/Program Files/Android/platform-tools/adb.exe"),
        ]
        
        for loc in locations:
            if loc.exists():
                return loc
        
        # Try PATH
        adb = shutil.which("adb")
        if adb:
            return Path(adb)
        
        return None
    
    def check_phone_link_status(self) -> Dict[str, Any]:
        """Check Phone Link connection status"""
        result = {
            "phone_link_running": False,
            "device_connected": False,
            "adb_available": self.adb_path is not None,
            "device_info": None,
        }
        
        # Check if Phone Link is running
        try:
            ps_result = subprocess.run(
                ["powershell", "-Command", "Get-Process PhoneExperienceHost -ErrorAction SilentlyContinue"],
                capture_output=True,
                text=True,
                timeout=5
            )
            result["phone_link_running"] = "PhoneExperienceHost" in ps_result.stdout
        except:
            pass
        
        # Check ADB devices
        if self.adb_path:
            try:
                adb_result = subprocess.run(
                    [str(self.adb_path), "devices", "-l"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                
                lines = adb_result.stdout.strip().split("\n")[1:]
                for line in lines:
                    if "device" in line and "offline" not in line:
                        result["device_connected"] = True
                        # Parse device info
                        parts = line.split()
                        if parts:
                            result["device_info"] = {
                                "serial": parts[0],
                                "status": "connected",
                            }
                            # Get more info
                            for part in parts[2:]:
                                if ":" in part:
                                    k, v = part.split(":", 1)
                                    result["device_info"][k] = v
            except:
                pass
        
        return result
    
    def get_device_info(self) -> Optional[PhoneLinkDevice]:
        """Get detailed device information"""
        if not self.adb_path:
            return None
        
        try:
            # Get device properties
            props = {}
            for prop in ["ro.product.model", "ro.product.manufacturer", 
                        "ro.build.version.release", "ro.serialno"]:
                result = subprocess.run(
                    [str(self.adb_path), "shell", f"getprop {prop}"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                props[prop] = result.stdout.strip()
            
            # Get battery level
            battery_result = subprocess.run(
                [str(self.adb_path), "shell", "dumpsys battery | grep level"],
                capture_output=True,
                text=True,
                timeout=5
            )
            battery = 0
            match = re.search(r"level: (\d+)", battery_result.stdout)
            if match:
                battery = int(match.group(1))
            
            # Check Termux
            termux_result = subprocess.run(
                [str(self.adb_path), "shell", "pm list packages | grep termux"],
                capture_output=True,
                text=True,
                timeout=5
            )
            termux_installed = "com.termux" in termux_result.stdout
            
            # Get IP address
            ip_result = subprocess.run(
                [str(self.adb_path), "shell", "ip route | grep wlan0 | awk '{print $9}'"],
                capture_output=True,
                text=True,
                timeout=5
            )
            ip_address = ip_result.stdout.strip() or None
            
            device = PhoneLinkDevice(
                name=f"{props.get('ro.product.manufacturer', 'Unknown')} {props.get('ro.product.model', 'Phone')}",
                model=props.get("ro.product.model", "Unknown"),
                android_version=props.get("ro.build.version.release", "Unknown"),
                ip_address=ip_address,
                adb_serial=props.get("ro.serialno"),
                is_connected=True,
                battery_level=battery,
                termux_installed=termux_installed,
            )
            
            self.connected_device = device
            return device
            
        except Exception as e:
            print(f"Error getting device info: {e}")
            return None
    
    def execute_termux_command(self, command: TermuxCommand) -> Dict[str, Any]:
        """Execute a command in Termux via ADB"""
        if not self.adb_path:
            return {"success": False, "error": "ADB not available"}
        
        result = {
            "success": False,
            "command": command.command,
            "output": "",
            "error": "",
            "execution_time_ms": 0,
        }
        
        try:
            start = time.perf_counter()
            
            # Method 1: Direct shell command (if Termux is running)
            # Use am broadcast to run in Termux
            termux_cmd = f"am broadcast --user 0 -a com.termux.RUN_COMMAND --es com.termux.RUN_COMMAND_PATH '/data/data/com.termux/files/usr/bin/bash' --esa com.termux.RUN_COMMAND_ARGUMENTS '-c,{command.command}' com.termux/.app.RunCommandService"
            
            proc = subprocess.run(
                [str(self.adb_path), "shell", termux_cmd],
                capture_output=True,
                text=True,
                timeout=command.timeout_seconds
            )
            
            result["output"] = proc.stdout
            result["error"] = proc.stderr
            result["success"] = proc.returncode == 0
            result["execution_time_ms"] = (time.perf_counter() - start) * 1000
            
        except subprocess.TimeoutExpired:
            result["error"] = f"Command timed out after {command.timeout_seconds}s"
        except Exception as e:
            result["error"] = str(e)
        
        return result
    
    def send_file_to_phone(self, local_path: Path, remote_path: str) -> bool:
        """Send file to phone via ADB"""
        if not self.adb_path:
            return False
        
        try:
            result = subprocess.run(
                [str(self.adb_path), "push", str(local_path), remote_path],
                capture_output=True,
                text=True,
                timeout=60
            )
            return result.returncode == 0
        except:
            return False
    
    def receive_file_from_phone(self, remote_path: str, local_path: Path) -> bool:
        """Receive file from phone via ADB"""
        if not self.adb_path:
            return False
        
        try:
            result = subprocess.run(
                [str(self.adb_path), "pull", remote_path, str(local_path)],
                capture_output=True,
                text=True,
                timeout=60
            )
            return result.returncode == 0
        except:
            return False
    
    def setup_termux_ssh(self) -> Dict[str, Any]:
        """Setup SSH server in Termux for direct connection"""
        commands = [
            TermuxCommand("pkg update -y", "Update packages"),
            TermuxCommand("pkg install openssh -y", "Install OpenSSH"),
            TermuxCommand("ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ''", "Generate SSH key"),
            TermuxCommand("sshd", "Start SSH daemon"),
            TermuxCommand("whoami && pwd", "Get user info"),
            TermuxCommand("cat ~/.ssh/id_ed25519.pub", "Get public key"),
        ]
        
        results = []
        for cmd in commands:
            result = self.execute_termux_command(cmd)
            results.append(result)
            if not result["success"]:
                break
        
        return {
            "success": all(r["success"] for r in results),
            "commands": results,
        }


class VPNManager:
    """
    VPN configuration and deployment manager
    """
    
    def __init__(self, q_generator: Optional[QuintillionGenerator] = None):
        self.q_generator = q_generator or QuintillionGenerator()
        self.configs: List[VPNConfig] = []
        self.active_vpn: Optional[VPNConfig] = None
    
    def generate_wireguard_keypair(self) -> Tuple[str, str]:
        """Generate WireGuard keypair"""
        try:
            # Try using wg command
            private = subprocess.run(
                ["wg", "genkey"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if private.returncode == 0:
                priv_key = private.stdout.strip()
                public = subprocess.run(
                    ["wg", "pubkey"],
                    input=priv_key,
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                return priv_key, public.stdout.strip()
        except:
            pass
        
        # Fallback: generate placeholder (need actual crypto library)
        import base64
        import secrets
        priv = base64.b64encode(secrets.token_bytes(32)).decode()
        pub = base64.b64encode(secrets.token_bytes(32)).decode()
        return priv, pub
    
    def create_vpn_config(
        self,
        provider: VPNProvider = VPNProvider.WIREGUARD,
        name: str = "aria-vpn",
        server: str = "vpn.example.com",
        port: int = 51820,
    ) -> VPNConfig:
        """Create a VPN configuration"""
        priv_key, pub_key = self.generate_wireguard_keypair()
        
        config = VPNConfig(
            provider=provider,
            name=name,
            server=server,
            port=port,
            protocol="udp",
            private_key=priv_key,
            public_key=pub_key,
            address="10.0.0.2/24",
        )
        
        self.configs.append(config)
        return config
    
    def generate_vpn_configs_at_scale(
        self,
        count: int = 1000,
        q_depth: int = 6
    ) -> GenerationResult:
        """Generate VPN configurations using Q-expansion"""
        start_time = time.perf_counter()
        
        lines = []
        servers = [
            "us-east.vpn.aria.io",
            "us-west.vpn.aria.io",
            "eu-west.vpn.aria.io",
            "eu-central.vpn.aria.io",
            "asia-east.vpn.aria.io",
            "asia-south.vpn.aria.io",
        ]
        
        for i in range(count):
            server = servers[i % len(servers)]
            port = 51820 + (i % 100)
            
            line = (
                f"§VPN[{i:08d}]@Q{q_depth}"
                f"::SERVER[{server}:{port}]"
                f"::ADDR[10.{(i // 256) % 256}.{i % 256}.2/24]"
                f"::DNS[1.1.1.1,8.8.8.8]"
                f"::MTU[1420]"
                f"::KEEPALIVE[25]"
            )
            lines.append(line)
        
        elapsed = (time.perf_counter() - start_time) * 1000
        output = "\n".join(lines)
        
        return GenerationResult(
            lines_generated=count,
            bytes_generated=len(output.encode()),
            seed_bytes=32,
            expansion_ratio=len(output.encode()) / 32,
            q_layers_used=q_depth,
            generation_time_ms=elapsed,
            sample_output="\n".join(lines[:5])
        )
    
    def deploy_to_termux(
        self,
        config: VPNConfig,
        phone_link: PhoneLinkIntegration
    ) -> Dict[str, Any]:
        """Deploy VPN config to Termux"""
        result = {"success": False, "steps": []}
        
        # Create temp config file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.conf', delete=False) as f:
            f.write(config.to_wireguard_conf())
            temp_path = Path(f.name)
        
        try:
            # Install WireGuard on Termux
            commands = [
                TermuxCommand("pkg install wireguard-tools -y", "Install WireGuard"),
                TermuxCommand("mkdir -p ~/vpn", "Create VPN directory"),
            ]
            
            for cmd in commands:
                step = phone_link.execute_termux_command(cmd)
                result["steps"].append(step)
            
            # Send config file
            remote_path = f"/data/data/com.termux/files/home/vpn/{config.name}.conf"
            if phone_link.send_file_to_phone(temp_path, remote_path):
                result["steps"].append({"success": True, "command": f"push {config.name}.conf"})
            
            # Activate VPN
            activate_cmd = TermuxCommand(
                f"wg-quick up ~/vpn/{config.name}.conf",
                "Activate VPN"
            )
            result["steps"].append(phone_link.execute_termux_command(activate_cmd))
            
            result["success"] = all(s.get("success", False) for s in result["steps"])
            
        finally:
            temp_path.unlink(missing_ok=True)
        
        return result
    
    def check_vpn_status(self) -> Dict[str, Any]:
        """Check VPN connection status on Windows"""
        result = {
            "wireguard_installed": False,
            "active_tunnels": [],
            "interfaces": [],
        }
        
        try:
            # Check WireGuard
            wg_result = subprocess.run(
                ["wg", "show"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if wg_result.returncode == 0:
                result["wireguard_installed"] = True
                result["active_tunnels"] = wg_result.stdout.strip().split("\n")
        except FileNotFoundError:
            pass
        except:
            pass
        
        # Check network interfaces
        try:
            ipconfig = subprocess.run(
                ["ipconfig", "/all"],
                capture_output=True,
                text=True,
                timeout=10
            )
            # Parse for VPN interfaces
            for line in ipconfig.stdout.split("\n"):
                if "WireGuard" in line or "TAP" in line or "VPN" in line:
                    result["interfaces"].append(line.strip())
        except:
            pass
        
        return result


class VMManager:
    """
    Virtual Machine provisioning and management
    """
    
    def __init__(self, q_generator: Optional[QuintillionGenerator] = None):
        self.q_generator = q_generator or QuintillionGenerator()
        self.vms: List[VMConfig] = []
        self.available_platforms = self._detect_platforms()
    
    def _detect_platforms(self) -> Dict[VMPlatform, bool]:
        """Detect available VM platforms"""
        platforms = {}
        
        # Check Hyper-V
        try:
            result = subprocess.run(
                ["powershell", "-Command", "Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V"],
                capture_output=True,
                text=True,
                timeout=10
            )
            platforms[VMPlatform.HYPER_V] = "Enabled" in result.stdout
        except:
            platforms[VMPlatform.HYPER_V] = False
        
        # Check WSL
        try:
            result = subprocess.run(["wsl", "--status"], capture_output=True, timeout=5)
            platforms[VMPlatform.WSL] = result.returncode == 0
        except:
            platforms[VMPlatform.WSL] = False
        
        # Check Docker
        try:
            result = subprocess.run(["docker", "--version"], capture_output=True, timeout=5)
            platforms[VMPlatform.DOCKER] = result.returncode == 0
        except:
            platforms[VMPlatform.DOCKER] = False
        
        # Check VirtualBox
        try:
            result = subprocess.run(["VBoxManage", "--version"], capture_output=True, timeout=5)
            platforms[VMPlatform.VIRTUALBOX] = result.returncode == 0
        except:
            platforms[VMPlatform.VIRTUALBOX] = False
        
        return platforms
    
    def list_wsl_distros(self) -> List[Dict[str, Any]]:
        """List installed WSL distributions"""
        distros = []
        
        try:
            result = subprocess.run(
                ["wsl", "--list", "--verbose"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            lines = result.stdout.strip().split("\n")[1:]  # Skip header
            for line in lines:
                line = line.strip().replace('\x00', '')
                if line:
                    parts = line.split()
                    if len(parts) >= 3:
                        distros.append({
                            "name": parts[0].replace("*", "").strip(),
                            "state": parts[1] if len(parts) > 1 else "Unknown",
                            "version": parts[2] if len(parts) > 2 else "2",
                            "default": "*" in line,
                        })
        except:
            pass
        
        return distros
    
    def list_docker_containers(self) -> List[Dict[str, Any]]:
        """List Docker containers"""
        containers = []
        
        try:
            result = subprocess.run(
                ["docker", "ps", "-a", "--format", "{{json .}}"],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            for line in result.stdout.strip().split("\n"):
                if line:
                    containers.append(json.loads(line))
        except:
            pass
        
        return containers
    
    def create_vm_config(
        self,
        platform: VMPlatform,
        name: str,
        os_type: str = "ubuntu",
        cpus: int = 2,
        memory_mb: int = 2048,
        disk_gb: int = 20,
    ) -> VMConfig:
        """Create VM configuration"""
        config = VMConfig(
            platform=platform,
            name=name,
            os_type=os_type,
            cpus=cpus,
            memory_mb=memory_mb,
            disk_gb=disk_gb,
        )
        
        self.vms.append(config)
        return config
    
    def generate_vm_configs_at_scale(
        self,
        count: int = 1000,
        q_depth: int = 6
    ) -> GenerationResult:
        """Generate VM configurations using Q-expansion"""
        start_time = time.perf_counter()
        
        lines = []
        os_types = ["ubuntu-22.04", "debian-12", "alpine", "centos-stream-9", "fedora-39"]
        platforms = ["WSL", "DOCKER", "HYPER_V", "VIRTUALBOX"]
        
        for i in range(count):
            os_type = os_types[i % len(os_types)]
            platform = platforms[i % len(platforms)]
            cpus = 1 + (i % 8)
            memory = 512 * (1 + (i % 16))
            
            line = (
                f"§VM[{i:08d}]@Q{q_depth}"
                f"::PLATFORM[{platform}]"
                f"::OS[{os_type}]"
                f"::CPU[{cpus}]"
                f"::MEM[{memory}MB]"
                f"::DISK[{10 + (i % 100)}GB]"
                f"::NET[bridge]"
            )
            lines.append(line)
        
        elapsed = (time.perf_counter() - start_time) * 1000
        output = "\n".join(lines)
        
        return GenerationResult(
            lines_generated=count,
            bytes_generated=len(output.encode()),
            seed_bytes=32,
            expansion_ratio=len(output.encode()) / 32,
            q_layers_used=q_depth,
            generation_time_ms=elapsed,
            sample_output="\n".join(lines[:5])
        )
    
    def deploy_wsl_with_vpn(
        self,
        distro: str = "Ubuntu",
        vpn_config: Optional[VPNConfig] = None
    ) -> Dict[str, Any]:
        """Deploy WSL instance with VPN configuration"""
        result = {"success": False, "steps": []}
        
        # Install WSL distro
        try:
            install = subprocess.run(
                ["wsl", "--install", "-d", distro],
                capture_output=True,
                text=True,
                timeout=300
            )
            result["steps"].append({
                "action": "install_distro",
                "success": install.returncode == 0,
                "output": install.stdout,
            })
        except Exception as e:
            result["steps"].append({"action": "install_distro", "success": False, "error": str(e)})
        
        if vpn_config:
            # Deploy VPN to WSL
            wg_commands = [
                "sudo apt update",
                "sudo apt install -y wireguard resolvconf",
                f"echo '{vpn_config.to_wireguard_conf()}' | sudo tee /etc/wireguard/wg0.conf",
                "sudo wg-quick up wg0",
            ]
            
            for cmd in wg_commands:
                try:
                    wsl_result = subprocess.run(
                        ["wsl", "-d", distro, "--", "bash", "-c", cmd],
                        capture_output=True,
                        text=True,
                        timeout=60
                    )
                    result["steps"].append({
                        "action": cmd[:50],
                        "success": wsl_result.returncode == 0,
                    })
                except Exception as e:
                    result["steps"].append({"action": cmd[:50], "success": False, "error": str(e)})
        
        result["success"] = all(s.get("success", False) for s in result["steps"])
        return result
    
    def execute_in_wsl(self, distro: str, command: str) -> Dict[str, Any]:
        """Execute command in WSL distro"""
        try:
            result = subprocess.run(
                ["wsl", "-d", distro, "--", "bash", "-c", command],
                capture_output=True,
                text=True,
                timeout=60
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}


class VPNVMAutomation:
    """
    Unified VPN + VM Automation System
    Combines Phone Link, VPN, VM, and Q-expansion
    """
    
    def __init__(self):
        self.q_generator = QuintillionGenerator(parallel_workers=4)
        self.phone_link = PhoneLinkIntegration()
        self.vpn_manager = VPNManager(self.q_generator)
        self.vm_manager = VMManager(self.q_generator)
        self.usb4 = USB4TopologyGenerator(self.q_generator)
        
        # Session state
        self.session_id = hashlib.sha256(str(time.time()).encode()).hexdigest()[:16]
        self.actions_log: List[Dict[str, Any]] = []
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get complete system status"""
        return {
            "session_id": self.session_id,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "phone_link": self.phone_link.check_phone_link_status(),
            "vpn": self.vpn_manager.check_vpn_status(),
            "vm_platforms": {k.name: v for k, v in self.vm_manager.available_platforms.items()},
            "wsl_distros": self.vm_manager.list_wsl_distros(),
            "docker_containers": self.vm_manager.list_docker_containers()[:5],  # Limit
            "usb4_host": self.usb4.host_router.to_dict(),
        }
    
    def setup_full_environment(
        self,
        vpn_server: str = "vpn.aria.io",
        vpn_port: int = 51820,
        wsl_distro: str = "Ubuntu",
        deploy_to_phone: bool = True,
    ) -> Dict[str, Any]:
        """
        Complete environment setup:
        1. Create VPN config
        2. Deploy to WSL
        3. Deploy to Termux (phone)
        4. Verify connectivity
        """
        result = {
            "success": False,
            "vpn_config": None,
            "wsl_deployment": None,
            "phone_deployment": None,
            "connectivity": None,
        }
        
        # Step 1: Create VPN config
        vpn_config = self.vpn_manager.create_vpn_config(
            provider=VPNProvider.WIREGUARD,
            name="aria-mesh-vpn",
            server=vpn_server,
            port=vpn_port,
        )
        result["vpn_config"] = vpn_config.to_dict()
        
        # Step 2: Deploy to WSL
        if self.vm_manager.available_platforms.get(VMPlatform.WSL):
            wsl_result = self.vm_manager.deploy_wsl_with_vpn(
                distro=wsl_distro,
                vpn_config=vpn_config
            )
            result["wsl_deployment"] = wsl_result
        
        # Step 3: Deploy to Phone (Termux)
        if deploy_to_phone:
            phone_status = self.phone_link.check_phone_link_status()
            if phone_status.get("device_connected"):
                phone_result = self.vpn_manager.deploy_to_termux(
                    config=vpn_config,
                    phone_link=self.phone_link
                )
                result["phone_deployment"] = phone_result
        
        # Step 4: Verify connectivity
        result["connectivity"] = self._verify_connectivity()
        
        result["success"] = (
            result.get("wsl_deployment", {}).get("success", True) and
            result.get("phone_deployment", {}).get("success", True)
        )
        
        self.actions_log.append({
            "action": "setup_full_environment",
            "timestamp": time.time(),
            "result": result["success"],
        })
        
        return result
    
    def _verify_connectivity(self) -> Dict[str, Any]:
        """Verify VPN mesh connectivity"""
        checks = {}
        
        # Check Windows VPN
        vpn_status = self.vpn_manager.check_vpn_status()
        checks["windows_vpn"] = len(vpn_status.get("active_tunnels", [])) > 0
        
        # Check WSL connectivity
        wsl_distros = self.vm_manager.list_wsl_distros()
        if wsl_distros:
            wsl_check = self.vm_manager.execute_in_wsl(
                wsl_distros[0]["name"],
                "ip addr show wg0 2>/dev/null || echo 'no-wg'"
            )
            checks["wsl_vpn"] = "no-wg" not in wsl_check.get("stdout", "no-wg")
        
        # Check phone connectivity
        phone_status = self.phone_link.check_phone_link_status()
        checks["phone_connected"] = phone_status.get("device_connected", False)
        
        return checks
    
    def automate_termux_setup(self, commands: List[str]) -> List[Dict[str, Any]]:
        """Automate Termux command sequence"""
        results = []
        
        device = self.phone_link.get_device_info()
        if not device:
            return [{"success": False, "error": "No device connected"}]
        
        for cmd in commands:
            termux_cmd = TermuxCommand(
                command=cmd,
                description=f"Execute: {cmd[:50]}",
                timeout_seconds=60
            )
            result = self.phone_link.execute_termux_command(termux_cmd)
            results.append(result)
            
            # Log action
            self.actions_log.append({
                "action": "termux_command",
                "command": cmd,
                "timestamp": time.time(),
                "success": result.get("success", False),
            })
        
        return results
    
    def generate_deployment_scripts(
        self,
        count: int = 100,
        q_depth: int = 4
    ) -> Dict[str, GenerationResult]:
        """Generate deployment scripts at Q-scale"""
        return {
            "vpn_configs": self.vpn_manager.generate_vpn_configs_at_scale(count, q_depth),
            "vm_configs": self.vm_manager.generate_vm_configs_at_scale(count, q_depth),
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get automation statistics"""
        return {
            "session_id": self.session_id,
            "actions_count": len(self.actions_log),
            "vpn_configs_created": len(self.vpn_manager.configs),
            "vms_configured": len(self.vm_manager.vms),
            "phone_connected": self.phone_link.connected_device is not None,
            "available_platforms": [
                k.name for k, v in self.vm_manager.available_platforms.items() if v
            ],
            "q_generator_stats": self.q_generator.get_statistics(),
        }


def demo():
    """Demonstrate VPN + VM Automation System"""
    print("\n" + "="*70)
    print("🔐 VPN + VM AUTOMATION SYSTEM - Q-SYMBOLIC INTEGRATION")
    print("="*70)
    
    automation = VPNVMAutomation()
    
    # System Status
    print("\n📊 SYSTEM STATUS")
    print("-" * 50)
    status = automation.get_system_status()
    
    print(f"  Session ID: {status['session_id']}")
    print(f"  Timestamp: {status['timestamp']}")
    
    # Phone Link
    print("\n📱 PHONE LINK STATUS:")
    phone = status["phone_link"]
    print(f"  Phone Link Running: {phone.get('phone_link_running', False)}")
    print(f"  Device Connected: {phone.get('device_connected', False)}")
    print(f"  ADB Available: {phone.get('adb_available', False)}")
    if phone.get("device_info"):
        print(f"  Device Serial: {phone['device_info'].get('serial', 'N/A')}")
    
    # VM Platforms
    print("\n🖥️ VM PLATFORMS:")
    for platform, available in status["vm_platforms"].items():
        icon = "✓" if available else "✗"
        print(f"  {icon} {platform}: {'Available' if available else 'Not Available'}")
    
    # WSL Distros
    print("\n🐧 WSL DISTRIBUTIONS:")
    for distro in status["wsl_distros"][:3]:
        default = " (default)" if distro.get("default") else ""
        print(f"  • {distro['name']} - {distro.get('state', 'Unknown')}{default}")
    
    # VPN Status
    print("\n🔒 VPN STATUS:")
    vpn = status["vpn"]
    print(f"  WireGuard Installed: {vpn.get('wireguard_installed', False)}")
    if vpn.get("active_tunnels"):
        print(f"  Active Tunnels: {len(vpn['active_tunnels'])}")
    
    # USB4 Host
    print("\n🔌 USB4 HOST CONTROLLER:")
    usb4 = status["usb4_host"]
    print(f"  {usb4['manufacturer']} {usb4['model']}")
    print(f"  Topology ID: {usb4['topology_id']}")
    
    # Generate configs at Q-scale
    print("\n🌌 GENERATING CONFIGS AT Q-SCALE...")
    print("-" * 50)
    
    scripts = automation.generate_deployment_scripts(count=10000, q_depth=6)
    
    for name, result in scripts.items():
        rate = result.lines_generated / (result.generation_time_ms / 1000)
        print(f"\n  {name.upper()}:")
        print(f"    Generated: {result.lines_generated:,} configs")
        print(f"    Size: {result.bytes_generated:,} bytes")
        print(f"    Time: {result.generation_time_ms:.2f}ms")
        print(f"    Rate: {rate:,.0f} configs/sec")
        print(f"    Sample:")
        for line in result.sample_output.split("\n")[:2]:
            print(f"      {line}")
    
    # Statistics
    print("\n📈 AUTOMATION STATISTICS:")
    print("-" * 50)
    stats = automation.get_statistics()
    for key, value in stats.items():
        if key != "q_generator_stats":
            print(f"  {key.replace('_', ' ').title()}: {value}")
    
    print("\n" + "="*70)
    print("✨ VPN + VM Automation System Ready!")
    print("="*70)
    print()


if __name__ == "__main__":
    demo()
