"""
ARIA Sync Engine v1.0.0

Cross-device file synchronization for mesh networks.

Features:
  - File change detection with hashing
  - Bi-directional sync
  - Conflict resolution
  - Mesh node synchronization
  - Sync profiles and rules
"""

import os
import json
import time
import hashlib
import shutil
import threading
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Set, Callable, Tuple
from enum import Enum
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed


# =============================================================================
# ENUMS AND DATACLASSES
# =============================================================================

class SyncAction(str, Enum):
    """Sync actions"""
    COPY = "copy"
    DELETE = "delete"
    UPDATE = "update"
    CONFLICT = "conflict"
    SKIP = "skip"


class ConflictResolution(str, Enum):
    """Conflict resolution strategies"""
    NEWER_WINS = "newer_wins"
    OLDER_WINS = "older_wins"
    LARGER_WINS = "larger_wins"
    SOURCE_WINS = "source_wins"
    DEST_WINS = "dest_wins"
    MANUAL = "manual"
    BOTH_KEEP = "both_keep"


class SyncDirection(str, Enum):
    """Sync direction"""
    SOURCE_TO_DEST = "source_to_dest"
    DEST_TO_SOURCE = "dest_to_source"
    BIDIRECTIONAL = "bidirectional"


@dataclass
class FileInfo:
    """Information about a file"""
    path: str
    relative_path: str
    size: int
    mtime: float
    hash: Optional[str] = None
    is_dir: bool = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "path": self.path,
            "relative_path": self.relative_path,
            "size": self.size,
            "mtime": self.mtime,
            "mtime_str": datetime.fromtimestamp(self.mtime).isoformat(),
            "hash": self.hash,
            "is_dir": self.is_dir,
        }


@dataclass
class SyncChange:
    """A detected change requiring sync"""
    action: SyncAction
    source_file: Optional[FileInfo]
    dest_file: Optional[FileInfo]
    reason: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "action": self.action.value,
            "source": self.source_file.to_dict() if self.source_file else None,
            "dest": self.dest_file.to_dict() if self.dest_file else None,
            "reason": self.reason,
        }


@dataclass
class SyncResult:
    """Result of a sync operation"""
    success: bool
    start_time: float
    end_time: float
    files_copied: int = 0
    files_updated: int = 0
    files_deleted: int = 0
    files_skipped: int = 0
    conflicts: int = 0
    bytes_transferred: int = 0
    errors: List[str] = field(default_factory=list)
    
    @property
    def duration(self) -> float:
        return self.end_time - self.start_time
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "success": self.success,
            "duration_seconds": round(self.duration, 2),
            "files_copied": self.files_copied,
            "files_updated": self.files_updated,
            "files_deleted": self.files_deleted,
            "files_skipped": self.files_skipped,
            "conflicts": self.conflicts,
            "bytes_transferred": self.bytes_transferred,
            "bytes_transferred_mb": round(self.bytes_transferred / (1024*1024), 2),
            "errors": self.errors,
        }


@dataclass
class SyncProfile:
    """A sync profile configuration"""
    name: str
    source: str
    destination: str
    direction: SyncDirection = SyncDirection.SOURCE_TO_DEST
    conflict_resolution: ConflictResolution = ConflictResolution.NEWER_WINS
    include_patterns: List[str] = field(default_factory=list)
    exclude_patterns: List[str] = field(default_factory=list)
    delete_orphans: bool = False
    verify_copies: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "source": self.source,
            "destination": self.destination,
            "direction": self.direction.value,
            "conflict_resolution": self.conflict_resolution.value,
            "include_patterns": self.include_patterns,
            "exclude_patterns": self.exclude_patterns,
            "delete_orphans": self.delete_orphans,
            "verify_copies": self.verify_copies,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SyncProfile":
        return cls(
            name=data["name"],
            source=data["source"],
            destination=data["destination"],
            direction=SyncDirection(data.get("direction", "source_to_dest")),
            conflict_resolution=ConflictResolution(data.get("conflict_resolution", "newer_wins")),
            include_patterns=data.get("include_patterns", []),
            exclude_patterns=data.get("exclude_patterns", []),
            delete_orphans=data.get("delete_orphans", False),
            verify_copies=data.get("verify_copies", True),
        )


# =============================================================================
# FILE UTILITIES
# =============================================================================

def file_hash(filepath: Path, chunk_size: int = 8192) -> str:
    """Calculate SHA-256 hash of a file"""
    hasher = hashlib.sha256()
    try:
        with open(filepath, "rb") as f:
            while chunk := f.read(chunk_size):
                hasher.update(chunk)
        return hasher.hexdigest()
    except Exception:
        return ""


def quick_hash(filepath: Path) -> str:
    """Quick hash using first/last chunks + size"""
    try:
        size = filepath.stat().st_size
        if size == 0:
            return "empty"
        
        hasher = hashlib.md5()
        hasher.update(str(size).encode())
        
        with open(filepath, "rb") as f:
            # First 4KB
            hasher.update(f.read(4096))
            
            # Last 4KB if file is large enough
            if size > 8192:
                f.seek(-4096, 2)
                hasher.update(f.read(4096))
        
        return hasher.hexdigest()
    except Exception:
        return ""


# =============================================================================
# SYNC ENGINE
# =============================================================================

class SyncEngine:
    """
    File synchronization engine
    
    Usage:
        engine = SyncEngine()
        
        # Simple sync
        result = engine.sync("/source", "/dest")
        
        # Bidirectional sync
        result = engine.sync("/folder1", "/folder2", direction=SyncDirection.BIDIRECTIONAL)
        
        # With profile
        profile = SyncProfile(name="backup", source="/home", destination="/backup")
        result = engine.sync_profile(profile)
    """
    
    DEFAULT_EXCLUDE = [
        ".git",
        ".svn",
        "__pycache__",
        "*.pyc",
        "*.pyo",
        ".DS_Store",
        "Thumbs.db",
        "node_modules",
        ".env",
        "*.log",
    ]
    
    def __init__(
        self,
        max_workers: int = 4,
        hash_method: str = "quick",  # "quick" or "full"
        progress_callback: Optional[Callable[[str, int, int], None]] = None,
    ):
        self.max_workers = max_workers
        self.hash_method = hash_method
        self.progress_callback = progress_callback
        
        self.profiles_dir = Path.home() / ".aria" / "sync-profiles"
        self.profiles_dir.mkdir(parents=True, exist_ok=True)
        
        self.state_dir = Path.home() / ".aria" / "sync-state"
        self.state_dir.mkdir(parents=True, exist_ok=True)
    
    def _hash_file(self, filepath: Path) -> str:
        """Hash a file using configured method"""
        if self.hash_method == "full":
            return file_hash(filepath)
        return quick_hash(filepath)
    
    def _should_exclude(self, path: str, patterns: List[str]) -> bool:
        """Check if path matches any exclude pattern"""
        import fnmatch
        name = os.path.basename(path)
        
        for pattern in patterns:
            if fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(path, pattern):
                return True
        return False
    
    def _should_include(self, path: str, patterns: List[str]) -> bool:
        """Check if path matches include patterns (empty = include all)"""
        if not patterns:
            return True
        
        import fnmatch
        name = os.path.basename(path)
        
        for pattern in patterns:
            if fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(path, pattern):
                return True
        return False
    
    # =========================================================================
    # FILE SCANNING
    # =========================================================================
    
    def scan_directory(
        self,
        directory: Path,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        compute_hashes: bool = True,
    ) -> Dict[str, FileInfo]:
        """Scan directory and return file info dict"""
        directory = Path(directory)
        exclude = exclude_patterns or self.DEFAULT_EXCLUDE
        include = include_patterns or []
        
        files = {}
        
        for root, dirs, filenames in os.walk(directory):
            # Filter directories
            dirs[:] = [d for d in dirs if not self._should_exclude(d, exclude)]
            
            for filename in filenames:
                filepath = Path(root) / filename
                relative = str(filepath.relative_to(directory))
                
                if self._should_exclude(relative, exclude):
                    continue
                
                if not self._should_include(relative, include):
                    continue
                
                try:
                    stat = filepath.stat()
                    file_hash = self._hash_file(filepath) if compute_hashes else None
                    
                    files[relative] = FileInfo(
                        path=str(filepath),
                        relative_path=relative,
                        size=stat.st_size,
                        mtime=stat.st_mtime,
                        hash=file_hash,
                        is_dir=False,
                    )
                except Exception:
                    pass
        
        return files
    
    # =========================================================================
    # CHANGE DETECTION
    # =========================================================================
    
    def compare_directories(
        self,
        source: Path,
        dest: Path,
        direction: SyncDirection = SyncDirection.SOURCE_TO_DEST,
        conflict_resolution: ConflictResolution = ConflictResolution.NEWER_WINS,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        delete_orphans: bool = False,
    ) -> List[SyncChange]:
        """Compare directories and determine required changes"""
        source = Path(source)
        dest = Path(dest)
        
        source_files = self.scan_directory(source, include_patterns, exclude_patterns)
        dest_files = self.scan_directory(dest, include_patterns, exclude_patterns)
        
        changes = []
        
        # Source -> Dest changes
        if direction in [SyncDirection.SOURCE_TO_DEST, SyncDirection.BIDIRECTIONAL]:
            for rel_path, src_info in source_files.items():
                if rel_path in dest_files:
                    dest_info = dest_files[rel_path]
                    
                    # Check if files differ
                    if src_info.hash and dest_info.hash and src_info.hash != dest_info.hash:
                        # Conflict - determine winner
                        action = self._resolve_conflict(src_info, dest_info, conflict_resolution)
                        if action == SyncAction.UPDATE:
                            changes.append(SyncChange(
                                action=SyncAction.UPDATE,
                                source_file=src_info,
                                dest_file=dest_info,
                                reason=f"Files differ, {conflict_resolution.value}",
                            ))
                        elif action == SyncAction.CONFLICT:
                            changes.append(SyncChange(
                                action=SyncAction.CONFLICT,
                                source_file=src_info,
                                dest_file=dest_info,
                                reason="Unresolved conflict",
                            ))
                else:
                    # New file
                    changes.append(SyncChange(
                        action=SyncAction.COPY,
                        source_file=src_info,
                        dest_file=None,
                        reason="New file in source",
                    ))
            
            # Check for orphans in dest
            if delete_orphans:
                for rel_path, dest_info in dest_files.items():
                    if rel_path not in source_files:
                        changes.append(SyncChange(
                            action=SyncAction.DELETE,
                            source_file=None,
                            dest_file=dest_info,
                            reason="Orphan file in destination",
                        ))
        
        # Dest -> Source changes (bidirectional only)
        if direction == SyncDirection.BIDIRECTIONAL:
            for rel_path, dest_info in dest_files.items():
                if rel_path not in source_files:
                    # Create reverse sync change
                    changes.append(SyncChange(
                        action=SyncAction.COPY,
                        source_file=dest_info,
                        dest_file=None,
                        reason="New file in destination (bidirectional)",
                    ))
        
        return changes
    
    def _resolve_conflict(
        self,
        src: FileInfo,
        dest: FileInfo,
        resolution: ConflictResolution,
    ) -> SyncAction:
        """Resolve a file conflict"""
        if resolution == ConflictResolution.NEWER_WINS:
            return SyncAction.UPDATE if src.mtime > dest.mtime else SyncAction.SKIP
        
        if resolution == ConflictResolution.OLDER_WINS:
            return SyncAction.UPDATE if src.mtime < dest.mtime else SyncAction.SKIP
        
        if resolution == ConflictResolution.LARGER_WINS:
            return SyncAction.UPDATE if src.size > dest.size else SyncAction.SKIP
        
        if resolution == ConflictResolution.SOURCE_WINS:
            return SyncAction.UPDATE
        
        if resolution == ConflictResolution.DEST_WINS:
            return SyncAction.SKIP
        
        if resolution == ConflictResolution.MANUAL:
            return SyncAction.CONFLICT
        
        if resolution == ConflictResolution.BOTH_KEEP:
            return SyncAction.CONFLICT
        
        return SyncAction.CONFLICT
    
    # =========================================================================
    # SYNC OPERATIONS
    # =========================================================================
    
    def sync(
        self,
        source: str,
        destination: str,
        direction: SyncDirection = SyncDirection.SOURCE_TO_DEST,
        conflict_resolution: ConflictResolution = ConflictResolution.NEWER_WINS,
        include_patterns: Optional[List[str]] = None,
        exclude_patterns: Optional[List[str]] = None,
        delete_orphans: bool = False,
        verify_copies: bool = True,
        dry_run: bool = False,
    ) -> SyncResult:
        """
        Synchronize directories
        
        Args:
            source: Source directory path
            destination: Destination directory path
            direction: Sync direction
            conflict_resolution: How to resolve conflicts
            include_patterns: File patterns to include
            exclude_patterns: File patterns to exclude
            delete_orphans: Delete files in dest not in source
            verify_copies: Verify copied files with hash
            dry_run: Preview changes without applying
        
        Returns:
            SyncResult with sync details
        """
        source = Path(source)
        destination = Path(destination)
        
        result = SyncResult(
            success=True,
            start_time=time.time(),
            end_time=0,
        )
        
        # Validate directories
        if not source.exists():
            result.success = False
            result.errors.append(f"Source does not exist: {source}")
            result.end_time = time.time()
            return result
        
        # Create destination if needed
        if not dry_run:
            destination.mkdir(parents=True, exist_ok=True)
        
        # Get changes
        changes = self.compare_directories(
            source, destination, direction, conflict_resolution,
            include_patterns, exclude_patterns, delete_orphans
        )
        
        # Apply changes
        total = len(changes)
        for i, change in enumerate(changes):
            if self.progress_callback:
                self.progress_callback(
                    change.source_file.relative_path if change.source_file else "unknown",
                    i + 1, total
                )
            
            try:
                if dry_run:
                    # Just count
                    if change.action == SyncAction.COPY:
                        result.files_copied += 1
                    elif change.action == SyncAction.UPDATE:
                        result.files_updated += 1
                    elif change.action == SyncAction.DELETE:
                        result.files_deleted += 1
                    elif change.action == SyncAction.CONFLICT:
                        result.conflicts += 1
                    continue
                
                if change.action == SyncAction.COPY:
                    self._copy_file(change.source_file, destination, verify_copies)
                    result.files_copied += 1
                    result.bytes_transferred += change.source_file.size
                
                elif change.action == SyncAction.UPDATE:
                    self._copy_file(change.source_file, destination, verify_copies)
                    result.files_updated += 1
                    result.bytes_transferred += change.source_file.size
                
                elif change.action == SyncAction.DELETE:
                    dest_path = destination / change.dest_file.relative_path
                    dest_path.unlink()
                    result.files_deleted += 1
                
                elif change.action == SyncAction.CONFLICT:
                    result.conflicts += 1
                
                elif change.action == SyncAction.SKIP:
                    result.files_skipped += 1
            
            except Exception as e:
                result.errors.append(f"{change.source_file.relative_path if change.source_file else 'unknown'}: {str(e)}")
        
        result.end_time = time.time()
        result.success = len(result.errors) == 0
        
        return result
    
    def _copy_file(self, file_info: FileInfo, dest_base: Path, verify: bool = True):
        """Copy a single file"""
        src_path = Path(file_info.path)
        dest_path = dest_base / file_info.relative_path
        
        # Create parent directories
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Copy file
        shutil.copy2(src_path, dest_path)
        
        # Verify if requested
        if verify:
            dest_hash = self._hash_file(dest_path)
            if file_info.hash and dest_hash != file_info.hash:
                raise ValueError("Hash mismatch after copy")
    
    # =========================================================================
    # PROFILE MANAGEMENT
    # =========================================================================
    
    def save_profile(self, profile: SyncProfile):
        """Save a sync profile"""
        filepath = self.profiles_dir / f"{profile.name}.json"
        with open(filepath, "w") as f:
            json.dump(profile.to_dict(), f, indent=2)
    
    def load_profile(self, name: str) -> Optional[SyncProfile]:
        """Load a sync profile by name"""
        filepath = self.profiles_dir / f"{name}.json"
        if not filepath.exists():
            return None
        
        with open(filepath, "r") as f:
            data = json.load(f)
        
        return SyncProfile.from_dict(data)
    
    def list_profiles(self) -> List[str]:
        """List all saved profiles"""
        return [f.stem for f in self.profiles_dir.glob("*.json")]
    
    def delete_profile(self, name: str) -> bool:
        """Delete a sync profile"""
        filepath = self.profiles_dir / f"{name}.json"
        if filepath.exists():
            filepath.unlink()
            return True
        return False
    
    def sync_profile(self, profile: SyncProfile, dry_run: bool = False) -> SyncResult:
        """Run sync using a profile"""
        return self.sync(
            source=profile.source,
            destination=profile.destination,
            direction=profile.direction,
            conflict_resolution=profile.conflict_resolution,
            include_patterns=profile.include_patterns,
            exclude_patterns=profile.exclude_patterns,
            delete_orphans=profile.delete_orphans,
            verify_copies=profile.verify_copies,
            dry_run=dry_run,
        )
    
    # =========================================================================
    # STATE TRACKING
    # =========================================================================
    
    def save_state(self, profile_name: str, files: Dict[str, FileInfo]):
        """Save sync state for a profile"""
        filepath = self.state_dir / f"{profile_name}.json"
        data = {
            "timestamp": time.time(),
            "files": {k: v.to_dict() for k, v in files.items()},
        }
        with open(filepath, "w") as f:
            json.dump(data, f)
    
    def load_state(self, profile_name: str) -> Optional[Dict[str, FileInfo]]:
        """Load previous sync state"""
        filepath = self.state_dir / f"{profile_name}.json"
        if not filepath.exists():
            return None
        
        with open(filepath, "r") as f:
            data = json.load(f)
        
        files = {}
        for k, v in data.get("files", {}).items():
            files[k] = FileInfo(
                path=v["path"],
                relative_path=v["relative_path"],
                size=v["size"],
                mtime=v["mtime"],
                hash=v.get("hash"),
            )
        
        return files


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def quick_sync(source: str, dest: str) -> Dict[str, Any]:
    """Quick sync between directories"""
    engine = SyncEngine()
    result = engine.sync(source, dest)
    return result.to_dict()


def preview_sync(source: str, dest: str) -> List[Dict[str, Any]]:
    """Preview sync changes without applying"""
    engine = SyncEngine()
    changes = engine.compare_directories(Path(source), Path(dest))
    return [c.to_dict() for c in changes]


def bidirectional_sync(folder1: str, folder2: str) -> Dict[str, Any]:
    """Bidirectional sync between folders"""
    engine = SyncEngine()
    result = engine.sync(
        folder1, folder2,
        direction=SyncDirection.BIDIRECTIONAL,
        conflict_resolution=ConflictResolution.NEWER_WINS,
    )
    return result.to_dict()
