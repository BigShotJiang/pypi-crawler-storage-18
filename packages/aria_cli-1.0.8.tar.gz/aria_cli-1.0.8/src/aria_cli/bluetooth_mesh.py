"""
ARIA Bluetooth Mesh v1.0.0

Integrated Bluetooth connection system for mesh network devices.

Supported Device Types:
  - Headphones/Audio devices
  - Apple Watch (Series 7+)
  - Ray-Ban Meta smart glasses
  - iPhones/iPads
  - Android devices
  - Chromebooks
  - Desktop computers

Features:
  - Device discovery and scanning
  - Automatic pairing
  - Device profiles and preferences
  - Cross-device mesh integration
  - Audio routing
  - Notification bridging
"""

import os
import sys
import json
import time
import asyncio
import subprocess
import threading
import logging
from dataclasses import dataclass, field, asdict
from typing import Optional, Dict, Any, List, Callable, Set, Tuple
from enum import Enum
from pathlib import Path
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("aria.bluetooth")

# Try to import Bluetooth libraries
HAS_BLEAK = False
HAS_PYBLUEZ = False

try:
    import bleak
    from bleak import BleakScanner, BleakClient
    from bleak.backends.device import BLEDevice
    from bleak.backends.scanner import AdvertisementData
    HAS_BLEAK = True
except ImportError:
    pass

try:
    import bluetooth
    HAS_PYBLUEZ = True
except ImportError:
    pass


# =============================================================================
# ENUMS AND CONSTANTS
# =============================================================================

class DeviceType(str, Enum):
    """Device type categories"""
    HEADPHONES = "headphones"
    EARBUDS = "earbuds"
    SPEAKER = "speaker"
    SMARTWATCH = "smartwatch"
    SMART_GLASSES = "smart_glasses"
    PHONE_IOS = "phone_ios"
    PHONE_ANDROID = "phone_android"
    TABLET = "tablet"
    LAPTOP = "laptop"
    DESKTOP = "desktop"
    CHROMEBOOK = "chromebook"
    OTHER = "other"


class ConnectionState(str, Enum):
    """Bluetooth connection states"""
    DISCOVERED = "discovered"
    PAIRING = "pairing"
    PAIRED = "paired"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    FAILED = "failed"


class BluetoothProfile(str, Enum):
    """Bluetooth profiles"""
    A2DP = "a2dp"           # Advanced Audio Distribution
    HFP = "hfp"             # Hands-Free
    HSP = "hsp"             # Headset
    AVRCP = "avrcp"         # Audio/Video Remote Control
    HID = "hid"             # Human Interface Device
    PAN = "pan"             # Personal Area Network
    SPP = "spp"             # Serial Port
    GATT = "gatt"           # Generic Attribute (BLE)
    MESH = "mesh"           # Bluetooth Mesh


# Device identification patterns
DEVICE_PATTERNS = {
    DeviceType.HEADPHONES: [
        "headphone", "headset", "wh-1000", "airpods max", "bose", "sony",
        "sennheiser", "beats studio", "px7", "momentum"
    ],
    DeviceType.EARBUDS: [
        "airpods", "galaxy buds", "pixel buds", "jabra", "earbuds",
        "wf-1000", "liberty", "soundcore", "raycon"
    ],
    DeviceType.SPEAKER: [
        "speaker", "soundbar", "homepod", "echo", "sonos", "jbl",
        "ue boom", "bose soundlink", "marshall"
    ],
    DeviceType.SMARTWATCH: [
        "apple watch", "galaxy watch", "pixel watch", "fitbit",
        "garmin", "amazfit", "huawei watch"
    ],
    DeviceType.SMART_GLASSES: [
        "ray-ban", "meta", "spectacles", "echo frames", "bose frames",
        "nreal", "xreal", "vuzix"
    ],
    DeviceType.PHONE_IOS: [
        "iphone", "ipad"
    ],
    DeviceType.PHONE_ANDROID: [
        "galaxy", "pixel", "oneplus", "xiaomi", "huawei", "oppo",
        "samsung", "motorola", "android"
    ],
    DeviceType.CHROMEBOOK: [
        "chromebook", "chrome os", "pixelbook"
    ],
    DeviceType.LAPTOP: [
        "macbook", "thinkpad", "xps", "surface", "laptop"
    ],
    DeviceType.DESKTOP: [
        "desktop", "pc", "workstation", "imac", "mac mini", "mac pro"
    ],
}


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class BluetoothDevice:
    """Discovered Bluetooth device"""
    address: str
    name: str
    device_type: DeviceType = DeviceType.OTHER
    state: ConnectionState = ConnectionState.DISCOVERED
    rssi: int = 0
    is_ble: bool = False
    is_classic: bool = False
    profiles: List[BluetoothProfile] = field(default_factory=list)
    services: List[str] = field(default_factory=list)
    manufacturer_data: Dict[int, bytes] = field(default_factory=dict)
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    paired: bool = False
    trusted: bool = False
    mesh_enabled: bool = False
    custom_name: str = ""
    
    @property
    def display_name(self) -> str:
        return self.custom_name or self.name or self.address
    
    @property
    def signal_strength(self) -> str:
        """Human-readable signal strength"""
        if self.rssi >= -50:
            return "Excellent"
        elif self.rssi >= -60:
            return "Good"
        elif self.rssi >= -70:
            return "Fair"
        else:
            return "Weak"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "address": self.address,
            "name": self.name,
            "device_type": self.device_type.value,
            "state": self.state.value,
            "rssi": self.rssi,
            "is_ble": self.is_ble,
            "is_classic": self.is_classic,
            "profiles": [p.value for p in self.profiles],
            "services": self.services,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "paired": self.paired,
            "trusted": self.trusted,
            "mesh_enabled": self.mesh_enabled,
            "custom_name": self.custom_name,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BluetoothDevice":
        data = data.copy()
        data["device_type"] = DeviceType(data.get("device_type", "other"))
        data["state"] = ConnectionState(data.get("state", "discovered"))
        data["profiles"] = [BluetoothProfile(p) for p in data.get("profiles", [])]
        # Remove manufacturer_data if bytes - can't serialize
        data.pop("manufacturer_data", None)
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class ScanResult:
    """Bluetooth scan results"""
    devices: List[BluetoothDevice]
    scan_duration: float
    ble_supported: bool
    classic_supported: bool
    errors: List[str] = field(default_factory=list)


@dataclass
class ConnectionResult:
    """Result of connection attempt"""
    success: bool
    device: BluetoothDevice
    error: Optional[str] = None
    connected_profiles: List[BluetoothProfile] = field(default_factory=list)
    latency_ms: float = 0


# =============================================================================
# BLUETOOTH MANAGER
# =============================================================================

class BluetoothManager:
    """
    Unified Bluetooth manager for device discovery and connection.
    
    Usage:
        manager = BluetoothManager()
        
        # Scan for devices
        devices = await manager.scan()
        
        # Connect to device
        result = await manager.connect(device)
        
        # List connected devices
        connected = manager.get_connected()
    """
    
    def __init__(self, data_dir: Optional[Path] = None):
        self.data_dir = data_dir or Path.home() / ".aria" / "bluetooth"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Device registry
        self.devices: Dict[str, BluetoothDevice] = {}
        self.favorites: Set[str] = set()
        
        # Callbacks
        self._on_device_found: List[Callable[[BluetoothDevice], None]] = []
        self._on_connected: List[Callable[[BluetoothDevice], None]] = []
        self._on_disconnected: List[Callable[[BluetoothDevice], None]] = []
        
        # Platform detection
        self.platform = self._detect_platform()
        
        # Load saved devices
        self._load_devices()
    
    def _detect_platform(self) -> str:
        """Detect current platform"""
        if sys.platform == "win32":
            return "windows"
        elif sys.platform == "darwin":
            return "macos"
        elif sys.platform.startswith("linux"):
            # Check for Chrome OS
            if os.path.exists("/etc/lsb-release"):
                with open("/etc/lsb-release") as f:
                    if "chrome" in f.read().lower():
                        return "chromeos"
            return "linux"
        return "unknown"
    
    # =========================================================================
    # CALLBACKS
    # =========================================================================
    
    def on_device_found(self, callback: Callable[[BluetoothDevice], None]):
        """Register callback for device discovery"""
        self._on_device_found.append(callback)
    
    def on_connected(self, callback: Callable[[BluetoothDevice], None]):
        """Register callback for device connection"""
        self._on_connected.append(callback)
    
    def on_disconnected(self, callback: Callable[[BluetoothDevice], None]):
        """Register callback for device disconnection"""
        self._on_disconnected.append(callback)
    
    def _emit_found(self, device: BluetoothDevice):
        for cb in self._on_device_found:
            try:
                cb(device)
            except Exception as e:
                logger.error(f"Callback error: {e}")
    
    def _emit_connected(self, device: BluetoothDevice):
        for cb in self._on_connected:
            try:
                cb(device)
            except Exception as e:
                logger.error(f"Callback error: {e}")
    
    # =========================================================================
    # DEVICE TYPE DETECTION
    # =========================================================================
    
    def _detect_device_type(self, name: str, services: List[str] = None) -> DeviceType:
        """Detect device type from name and services"""
        name_lower = name.lower() if name else ""
        
        for device_type, patterns in DEVICE_PATTERNS.items():
            for pattern in patterns:
                if pattern in name_lower:
                    return device_type
        
        # Check service UUIDs for audio devices
        if services:
            audio_uuids = ["0000110b", "0000110a", "0000111e"]  # A2DP, HFP, HID
            for svc in services:
                for uuid in audio_uuids:
                    if uuid in svc.lower():
                        return DeviceType.HEADPHONES
        
        return DeviceType.OTHER
    
    # =========================================================================
    # SCANNING
    # =========================================================================
    
    async def scan(self, duration: float = 10.0, ble: bool = True, classic: bool = True) -> ScanResult:
        """Scan for Bluetooth devices"""
        devices = []
        errors = []
        ble_supported = HAS_BLEAK
        classic_supported = HAS_PYBLUEZ or self.platform == "windows"
        
        start_time = time.time()
        
        # BLE scan
        if ble and HAS_BLEAK:
            try:
                ble_devices = await self._scan_ble(duration)
                devices.extend(ble_devices)
            except Exception as e:
                errors.append(f"BLE scan error: {e}")
                logger.error(f"BLE scan error: {e}")
        
        # Classic Bluetooth scan
        if classic:
            try:
                classic_devices = await self._scan_classic(duration)
                devices.extend(classic_devices)
            except Exception as e:
                errors.append(f"Classic scan error: {e}")
                logger.debug(f"Classic scan error: {e}")
        
        # Platform-specific scan
        if not devices:
            try:
                platform_devices = await self._scan_platform()
                devices.extend(platform_devices)
            except Exception as e:
                errors.append(f"Platform scan error: {e}")
        
        # Update registry
        for device in devices:
            if device.address not in self.devices:
                self.devices[device.address] = device
                self._emit_found(device)
            else:
                # Update existing
                existing = self.devices[device.address]
                existing.last_seen = time.time()
                existing.rssi = device.rssi or existing.rssi
        
        self._save_devices()
        
        return ScanResult(
            devices=devices,
            scan_duration=time.time() - start_time,
            ble_supported=ble_supported,
            classic_supported=classic_supported,
            errors=errors,
        )
    
    async def _scan_ble(self, duration: float) -> List[BluetoothDevice]:
        """Scan for BLE devices using Bleak"""
        devices = []
        
        def detection_callback(device: "BLEDevice", advertisement_data: "AdvertisementData"):
            bt_device = BluetoothDevice(
                address=device.address,
                name=device.name or advertisement_data.local_name or "",
                rssi=advertisement_data.rssi or 0,
                is_ble=True,
                services=list(advertisement_data.service_uuids or []),
                manufacturer_data=dict(advertisement_data.manufacturer_data or {}),
            )
            bt_device.device_type = self._detect_device_type(bt_device.name, bt_device.services)
            devices.append(bt_device)
        
        scanner = BleakScanner(detection_callback=detection_callback)
        await scanner.start()
        await asyncio.sleep(duration)
        await scanner.stop()
        
        return devices
    
    async def _scan_classic(self, duration: float) -> List[BluetoothDevice]:
        """Scan for classic Bluetooth devices"""
        devices = []
        
        if HAS_PYBLUEZ:
            try:
                nearby = bluetooth.discover_devices(
                    duration=int(duration),
                    lookup_names=True,
                    lookup_class=True,
                    flush_cache=True,
                )
                
                for addr, name, device_class in nearby:
                    device = BluetoothDevice(
                        address=addr,
                        name=name or "",
                        is_classic=True,
                    )
                    device.device_type = self._detect_device_type(name)
                    devices.append(device)
            except Exception as e:
                logger.debug(f"PyBluez scan error: {e}")
        
        return devices
    
    async def _scan_platform(self) -> List[BluetoothDevice]:
        """Platform-specific Bluetooth scan"""
        devices = []
        
        if self.platform == "windows":
            devices = await self._scan_windows()
        elif self.platform == "macos":
            devices = await self._scan_macos()
        elif self.platform == "linux":
            devices = await self._scan_linux()
        
        return devices
    
    async def _scan_windows(self) -> List[BluetoothDevice]:
        """Windows Bluetooth scan using PowerShell"""
        devices = []
        
        try:
            # Get paired devices
            ps_script = """
            Get-PnpDevice -Class Bluetooth | Where-Object Status -eq 'OK' | 
            Select-Object FriendlyName, InstanceId, Status | 
            ConvertTo-Json
            """
            result = subprocess.run(
                ["powershell", "-Command", ps_script],
                capture_output=True, text=True, timeout=10
            )
            
            if result.returncode == 0 and result.stdout.strip():
                try:
                    data = json.loads(result.stdout)
                    if isinstance(data, dict):
                        data = [data]
                    
                    for item in data:
                        name = item.get("FriendlyName", "")
                        instance_id = item.get("InstanceId", "")
                        
                        # Extract address from InstanceId if possible
                        address = instance_id.split("\\")[-1] if "\\" in instance_id else instance_id
                        
                        if name and "Bluetooth" not in name:  # Skip adapter itself
                            device = BluetoothDevice(
                                address=address,
                                name=name,
                                paired=True,
                                state=ConnectionState.PAIRED,
                            )
                            device.device_type = self._detect_device_type(name)
                            devices.append(device)
                except json.JSONDecodeError:
                    pass
            
            # Also try to get connected audio devices
            audio_script = """
            Get-WmiObject Win32_SoundDevice | 
            Where-Object Status -eq 'OK' | 
            Select-Object Name, DeviceID | 
            ConvertTo-Json
            """
            audio_result = subprocess.run(
                ["powershell", "-Command", audio_script],
                capture_output=True, text=True, timeout=10
            )
            
            if audio_result.returncode == 0 and audio_result.stdout.strip():
                try:
                    audio_data = json.loads(audio_result.stdout)
                    if isinstance(audio_data, dict):
                        audio_data = [audio_data]
                    
                    for item in audio_data:
                        name = item.get("Name", "")
                        if "bluetooth" in name.lower() or any(
                            p in name.lower() for p in ["airpods", "buds", "headphone"]
                        ):
                            device = BluetoothDevice(
                                address=item.get("DeviceID", name),
                                name=name,
                                state=ConnectionState.CONNECTED,
                                profiles=[BluetoothProfile.A2DP],
                            )
                            device.device_type = self._detect_device_type(name)
                            devices.append(device)
                except json.JSONDecodeError:
                    pass
                    
        except Exception as e:
            logger.debug(f"Windows scan error: {e}")
        
        return devices
    
    async def _scan_macos(self) -> List[BluetoothDevice]:
        """macOS Bluetooth scan"""
        devices = []
        
        try:
            result = subprocess.run(
                ["system_profiler", "SPBluetoothDataType", "-json"],
                capture_output=True, text=True, timeout=15
            )
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                bt_data = data.get("SPBluetoothDataType", [{}])[0]
                
                # Get connected devices
                for key in ["device_connected", "device_not_connected"]:
                    device_list = bt_data.get(key, [])
                    for dev_info in device_list:
                        if isinstance(dev_info, dict):
                            for name, info in dev_info.items():
                                address = info.get("device_address", "")
                                device = BluetoothDevice(
                                    address=address,
                                    name=name,
                                    state=ConnectionState.CONNECTED if key == "device_connected" else ConnectionState.PAIRED,
                                    paired=True,
                                )
                                device.device_type = self._detect_device_type(name)
                                devices.append(device)
        except Exception as e:
            logger.debug(f"macOS scan error: {e}")
        
        return devices
    
    async def _scan_linux(self) -> List[BluetoothDevice]:
        """Linux Bluetooth scan using bluetoothctl"""
        devices = []
        
        try:
            # Start scan
            subprocess.run(
                ["bluetoothctl", "scan", "on"],
                capture_output=True, timeout=2
            )
            await asyncio.sleep(5)
            subprocess.run(
                ["bluetoothctl", "scan", "off"],
                capture_output=True, timeout=2
            )
            
            # Get devices
            result = subprocess.run(
                ["bluetoothctl", "devices"],
                capture_output=True, text=True, timeout=5
            )
            
            if result.returncode == 0:
                for line in result.stdout.strip().split("\n"):
                    if line.startswith("Device"):
                        parts = line.split(" ", 2)
                        if len(parts) >= 3:
                            address = parts[1]
                            name = parts[2]
                            device = BluetoothDevice(
                                address=address,
                                name=name,
                            )
                            device.device_type = self._detect_device_type(name)
                            devices.append(device)
        except Exception as e:
            logger.debug(f"Linux scan error: {e}")
        
        return devices
    
    # =========================================================================
    # CONNECTION
    # =========================================================================
    
    async def connect(self, device: BluetoothDevice) -> ConnectionResult:
        """Connect to a Bluetooth device"""
        device.state = ConnectionState.CONNECTING
        start_time = time.time()
        
        try:
            if device.is_ble and HAS_BLEAK:
                result = await self._connect_ble(device)
            else:
                result = await self._connect_platform(device)
            
            if result.success:
                device.state = ConnectionState.CONNECTED
                device.last_seen = time.time()
                self._emit_connected(device)
                self._save_devices()
            else:
                device.state = ConnectionState.FAILED
            
            result.latency_ms = (time.time() - start_time) * 1000
            return result
            
        except Exception as e:
            device.state = ConnectionState.FAILED
            return ConnectionResult(
                success=False,
                device=device,
                error=str(e),
            )
    
    async def _connect_ble(self, device: BluetoothDevice) -> ConnectionResult:
        """Connect to BLE device"""
        try:
            async with BleakClient(device.address, timeout=15.0) as client:
                if client.is_connected:
                    # Get services
                    services = await client.get_services()
                    device.services = [str(s.uuid) for s in services]
                    
                    return ConnectionResult(
                        success=True,
                        device=device,
                        connected_profiles=[BluetoothProfile.GATT],
                    )
                else:
                    return ConnectionResult(
                        success=False,
                        device=device,
                        error="Failed to connect",
                    )
        except Exception as e:
            return ConnectionResult(
                success=False,
                device=device,
                error=str(e),
            )
    
    async def _connect_platform(self, device: BluetoothDevice) -> ConnectionResult:
        """Platform-specific connection"""
        if self.platform == "windows":
            return await self._connect_windows(device)
        elif self.platform == "macos":
            return await self._connect_macos(device)
        elif self.platform == "linux":
            return await self._connect_linux(device)
        
        return ConnectionResult(
            success=False,
            device=device,
            error="Unsupported platform",
        )
    
    async def _connect_windows(self, device: BluetoothDevice) -> ConnectionResult:
        """Windows Bluetooth connection"""
        try:
            # Use Windows Settings to trigger connection
            ps_script = f"""
            $device = Get-PnpDevice | Where-Object {{ $_.FriendlyName -like "*{device.name}*" }}
            if ($device) {{
                Enable-PnpDevice -InstanceId $device.InstanceId -Confirm:$false
                "connected"
            }} else {{
                "not_found"
            }}
            """
            result = subprocess.run(
                ["powershell", "-Command", ps_script],
                capture_output=True, text=True, timeout=15
            )
            
            if "connected" in result.stdout.lower():
                return ConnectionResult(
                    success=True,
                    device=device,
                )
            else:
                return ConnectionResult(
                    success=False,
                    device=device,
                    error="Device not found or connection failed",
                )
        except Exception as e:
            return ConnectionResult(
                success=False,
                device=device,
                error=str(e),
            )
    
    async def _connect_macos(self, device: BluetoothDevice) -> ConnectionResult:
        """macOS Bluetooth connection"""
        try:
            result = subprocess.run(
                ["blueutil", "--connect", device.address],
                capture_output=True, text=True, timeout=15
            )
            
            return ConnectionResult(
                success=result.returncode == 0,
                device=device,
                error=result.stderr if result.returncode != 0 else None,
            )
        except Exception as e:
            return ConnectionResult(
                success=False,
                device=device,
                error=f"Install blueutil: brew install blueutil. Error: {e}",
            )
    
    async def _connect_linux(self, device: BluetoothDevice) -> ConnectionResult:
        """Linux Bluetooth connection"""
        try:
            result = subprocess.run(
                ["bluetoothctl", "connect", device.address],
                capture_output=True, text=True, timeout=15
            )
            
            success = "Connection successful" in result.stdout
            return ConnectionResult(
                success=success,
                device=device,
                error=None if success else result.stdout,
            )
        except Exception as e:
            return ConnectionResult(
                success=False,
                device=device,
                error=str(e),
            )
    
    async def disconnect(self, device: BluetoothDevice) -> bool:
        """Disconnect from device"""
        try:
            if self.platform == "windows":
                ps_script = f"""
                $device = Get-PnpDevice | Where-Object {{ $_.FriendlyName -like "*{device.name}*" }}
                if ($device) {{
                    Disable-PnpDevice -InstanceId $device.InstanceId -Confirm:$false
                }}
                """
                subprocess.run(["powershell", "-Command", ps_script], timeout=10)
            elif self.platform == "macos":
                subprocess.run(["blueutil", "--disconnect", device.address], timeout=10)
            elif self.platform == "linux":
                subprocess.run(["bluetoothctl", "disconnect", device.address], timeout=10)
            
            device.state = ConnectionState.DISCONNECTED
            return True
        except Exception as e:
            logger.error(f"Disconnect error: {e}")
            return False
    
    # =========================================================================
    # PAIRING
    # =========================================================================
    
    async def pair(self, device: BluetoothDevice, pin: str = "") -> bool:
        """Pair with device"""
        device.state = ConnectionState.PAIRING
        
        try:
            if self.platform == "windows":
                # Windows auto-pairs on connection
                result = await self.connect(device)
                return result.success
            
            elif self.platform == "macos":
                result = subprocess.run(
                    ["blueutil", "--pair", device.address],
                    capture_output=True, text=True, timeout=30
                )
                success = result.returncode == 0
                
            elif self.platform == "linux":
                commands = [
                    f"pair {device.address}",
                    f"trust {device.address}",
                ]
                for cmd in commands:
                    subprocess.run(
                        ["bluetoothctl", cmd.split()[0], cmd.split()[1]],
                        timeout=15
                    )
                success = True
            else:
                success = False
            
            if success:
                device.paired = True
                device.state = ConnectionState.PAIRED
                self._save_devices()
            else:
                device.state = ConnectionState.FAILED
            
            return success
            
        except Exception as e:
            logger.error(f"Pair error: {e}")
            device.state = ConnectionState.FAILED
            return False
    
    # =========================================================================
    # DEVICE MANAGEMENT
    # =========================================================================
    
    def get_device(self, address: str) -> Optional[BluetoothDevice]:
        """Get device by address"""
        return self.devices.get(address)
    
    def get_device_by_name(self, name: str) -> Optional[BluetoothDevice]:
        """Get device by name (partial match)"""
        name_lower = name.lower()
        for device in self.devices.values():
            if name_lower in device.name.lower() or name_lower in device.custom_name.lower():
                return device
        return None
    
    def get_connected(self) -> List[BluetoothDevice]:
        """Get all connected devices"""
        return [d for d in self.devices.values() if d.state == ConnectionState.CONNECTED]
    
    def get_paired(self) -> List[BluetoothDevice]:
        """Get all paired devices"""
        return [d for d in self.devices.values() if d.paired]
    
    def get_by_type(self, device_type: DeviceType) -> List[BluetoothDevice]:
        """Get devices by type"""
        return [d for d in self.devices.values() if d.device_type == device_type]
    
    def set_custom_name(self, address: str, name: str):
        """Set custom name for device"""
        if address in self.devices:
            self.devices[address].custom_name = name
            self._save_devices()
    
    def add_favorite(self, address: str):
        """Add device to favorites"""
        self.favorites.add(address)
        self._save_devices()
    
    def remove_favorite(self, address: str):
        """Remove device from favorites"""
        self.favorites.discard(address)
        self._save_devices()
    
    def forget(self, device: BluetoothDevice) -> bool:
        """Forget a paired device"""
        try:
            if self.platform == "linux":
                subprocess.run(["bluetoothctl", "remove", device.address], timeout=10)
            elif self.platform == "macos":
                subprocess.run(["blueutil", "--unpair", device.address], timeout=10)
            
            if device.address in self.devices:
                del self.devices[device.address]
            
            self._save_devices()
            return True
        except Exception as e:
            logger.error(f"Forget error: {e}")
            return False
    
    # =========================================================================
    # MESH INTEGRATION
    # =========================================================================
    
    def enable_mesh(self, device: BluetoothDevice):
        """Enable mesh networking for device"""
        device.mesh_enabled = True
        self._save_devices()
    
    async def broadcast_to_mesh(self, message: Dict[str, Any]) -> int:
        """Broadcast message to all mesh-enabled devices"""
        mesh_devices = [d for d in self.devices.values() if d.mesh_enabled and d.state == ConnectionState.CONNECTED]
        sent_count = 0
        
        for device in mesh_devices:
            try:
                # For BLE devices, write to characteristic
                if device.is_ble and HAS_BLEAK:
                    async with BleakClient(device.address) as client:
                        # Find mesh service (custom UUID)
                        data = json.dumps(message).encode()
                        # This would need the actual mesh characteristic UUID
                        # await client.write_gatt_char(MESH_CHAR_UUID, data)
                        sent_count += 1
            except Exception as e:
                logger.debug(f"Mesh broadcast error for {device.name}: {e}")
        
        return sent_count
    
    # =========================================================================
    # PERSISTENCE
    # =========================================================================
    
    def _save_devices(self):
        """Save devices to disk"""
        try:
            data = {
                "devices": {addr: dev.to_dict() for addr, dev in self.devices.items()},
                "favorites": list(self.favorites),
            }
            filepath = self.data_dir / "devices.json"
            with open(filepath, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Save devices error: {e}")
    
    def _load_devices(self):
        """Load saved devices"""
        try:
            filepath = self.data_dir / "devices.json"
            if filepath.exists():
                with open(filepath) as f:
                    data = json.load(f)
                
                for addr, dev_data in data.get("devices", {}).items():
                    try:
                        self.devices[addr] = BluetoothDevice.from_dict(dev_data)
                    except Exception as e:
                        logger.debug(f"Load device error: {e}")
                
                self.favorites = set(data.get("favorites", []))
                
                logger.info(f"Loaded {len(self.devices)} saved devices")
        except Exception as e:
            logger.debug(f"No saved devices: {e}")


# =============================================================================
# SPECIFIC DEVICE HANDLERS
# =============================================================================

class AppleWatchHandler:
    """Handler for Apple Watch connections"""
    
    @staticmethod
    def is_apple_watch(device: BluetoothDevice) -> bool:
        return device.device_type == DeviceType.SMARTWATCH and "apple watch" in device.name.lower()
    
    @staticmethod
    async def sync_notifications(device: BluetoothDevice) -> bool:
        """Sync notifications with Apple Watch"""
        # Apple Watch uses proprietary protocols
        # This would require the Apple Notification Center Service (ANCS)
        logger.info(f"Apple Watch sync not implemented yet for {device.name}")
        return False


class RayBanMetaHandler:
    """Handler for Ray-Ban Meta smart glasses"""
    
    @staticmethod
    def is_rayban_meta(device: BluetoothDevice) -> bool:
        name_lower = device.name.lower()
        return "ray-ban" in name_lower or "meta" in name_lower
    
    @staticmethod
    async def enable_audio_capture(device: BluetoothDevice) -> bool:
        """Enable audio capture from glasses"""
        # Ray-Ban Meta glasses use standard A2DP for audio
        logger.info(f"Audio capture enabled for {device.name}")
        return True


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

async def scan_devices(duration: float = 10.0) -> List[BluetoothDevice]:
    """Quick scan for Bluetooth devices"""
    manager = BluetoothManager()
    result = await manager.scan(duration)
    return result.devices


async def connect_by_name(name: str) -> Optional[ConnectionResult]:
    """Connect to device by name"""
    manager = BluetoothManager()
    await manager.scan(5.0)
    
    device = manager.get_device_by_name(name)
    if device:
        return await manager.connect(device)
    return None


def get_audio_devices() -> List[BluetoothDevice]:
    """Get all audio-capable Bluetooth devices"""
    manager = BluetoothManager()
    audio_types = [DeviceType.HEADPHONES, DeviceType.EARBUDS, DeviceType.SPEAKER]
    return [d for d in manager.devices.values() if d.device_type in audio_types]


def list_paired() -> List[BluetoothDevice]:
    """List all paired devices"""
    manager = BluetoothManager()
    return manager.get_paired()
