"""
ARIA Compression Tools v1.0.0

Multi-algorithm compression utilities with benchmarking.

Features:
  - Multiple compression algorithms (gzip, lzma, lz4, zstd, brotli)
  - Automatic algorithm selection
  - Compression benchmarking
  - Streaming compression for large files
"""

import os
import io
import gzip
import time
import json
import hashlib
import threading
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Tuple, Callable, BinaryIO
from enum import Enum
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# Try optional compression libraries
try:
    import lzma
    HAS_LZMA = True
except ImportError:
    HAS_LZMA = False

try:
    import bz2
    HAS_BZ2 = True
except ImportError:
    HAS_BZ2 = False

try:
    import lz4.frame as lz4
    HAS_LZ4 = True
except ImportError:
    HAS_LZ4 = False

try:
    import zstandard as zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False

try:
    import brotli
    HAS_BROTLI = True
except ImportError:
    HAS_BROTLI = False


# =============================================================================
# ENUMS AND DATACLASSES
# =============================================================================

class Algorithm(str, Enum):
    """Compression algorithms"""
    GZIP = "gzip"
    LZMA = "lzma"
    BZ2 = "bz2"
    LZ4 = "lz4"
    ZSTD = "zstd"
    BROTLI = "brotli"
    NONE = "none"
    AUTO = "auto"


@dataclass
class CompressionResult:
    """Result of a compression operation"""
    algorithm: str
    original_size: int
    compressed_size: int
    ratio: float
    time_seconds: float
    success: bool
    error: Optional[str] = None
    
    @property
    def savings_percent(self) -> float:
        if self.original_size == 0:
            return 0.0
        return (1 - self.ratio) * 100
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "algorithm": self.algorithm,
            "original_size": self.original_size,
            "compressed_size": self.compressed_size,
            "ratio": round(self.ratio, 4),
            "savings_percent": round(self.savings_percent, 2),
            "time_seconds": round(self.time_seconds, 4),
            "throughput_mb_s": round(self.original_size / (1024*1024) / max(self.time_seconds, 0.001), 2),
            "success": self.success,
            "error": self.error,
        }


@dataclass
class BenchmarkResult:
    """Result of compression benchmark"""
    data_size: int
    results: List[CompressionResult]
    best_ratio: Optional[CompressionResult] = None
    best_speed: Optional[CompressionResult] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "data_size_bytes": self.data_size,
            "data_size_mb": round(self.data_size / (1024*1024), 2),
            "algorithms": [r.to_dict() for r in self.results],
            "best_ratio": self.best_ratio.to_dict() if self.best_ratio else None,
            "best_speed": self.best_speed.to_dict() if self.best_speed else None,
        }


# =============================================================================
# COMPRESSION ENGINE
# =============================================================================

class CompressionEngine:
    """
    Multi-algorithm compression engine
    
    Usage:
        engine = CompressionEngine()
        
        # Compress data
        compressed = engine.compress(data, algorithm=Algorithm.GZIP)
        
        # Decompress
        original = engine.decompress(compressed, algorithm=Algorithm.GZIP)
        
        # Auto-select best algorithm
        compressed = engine.compress(data, algorithm=Algorithm.AUTO)
        
        # Benchmark all algorithms
        results = engine.benchmark(data)
    """
    
    # Compression level presets
    LEVELS = {
        "fast": {"gzip": 1, "lzma": 1, "bz2": 1, "lz4": 0, "zstd": 1, "brotli": 1},
        "balanced": {"gzip": 6, "lzma": 6, "bz2": 5, "lz4": 6, "zstd": 9, "brotli": 6},
        "best": {"gzip": 9, "lzma": 9, "bz2": 9, "lz4": 12, "zstd": 19, "brotli": 11},
    }
    
    def __init__(self, preset: str = "balanced"):
        self.preset = preset
        self.levels = self.LEVELS.get(preset, self.LEVELS["balanced"])
        self._cache_dir = Path.home() / ".aria" / "compression-cache"
        self._cache_dir.mkdir(parents=True, exist_ok=True)
    
    def available_algorithms(self) -> List[Algorithm]:
        """Get list of available algorithms"""
        available = [Algorithm.GZIP, Algorithm.NONE]
        
        if HAS_LZMA:
            available.append(Algorithm.LZMA)
        if HAS_BZ2:
            available.append(Algorithm.BZ2)
        if HAS_LZ4:
            available.append(Algorithm.LZ4)
        if HAS_ZSTD:
            available.append(Algorithm.ZSTD)
        if HAS_BROTLI:
            available.append(Algorithm.BROTLI)
        
        return available
    
    # =========================================================================
    # CORE COMPRESSION
    # =========================================================================
    
    def compress(
        self,
        data: bytes,
        algorithm: Algorithm = Algorithm.GZIP,
        level: Optional[int] = None,
    ) -> Tuple[bytes, CompressionResult]:
        """
        Compress data using specified algorithm
        
        Args:
            data: Input bytes to compress
            algorithm: Compression algorithm to use
            level: Compression level (algorithm-specific)
        
        Returns:
            Tuple of (compressed_bytes, CompressionResult)
        """
        if algorithm == Algorithm.AUTO:
            return self._auto_compress(data)
        
        if algorithm == Algorithm.NONE:
            return data, CompressionResult(
                algorithm="none",
                original_size=len(data),
                compressed_size=len(data),
                ratio=1.0,
                time_seconds=0.0,
                success=True,
            )
        
        start = time.perf_counter()
        compressed = b""
        error = None
        success = True
        
        try:
            if algorithm == Algorithm.GZIP:
                lvl = level or self.levels.get("gzip", 6)
                compressed = gzip.compress(data, compresslevel=lvl)
            
            elif algorithm == Algorithm.LZMA:
                if not HAS_LZMA:
                    raise RuntimeError("LZMA not available")
                lvl = level or self.levels.get("lzma", 6)
                compressed = lzma.compress(data, preset=lvl)
            
            elif algorithm == Algorithm.BZ2:
                if not HAS_BZ2:
                    raise RuntimeError("BZ2 not available")
                lvl = level or self.levels.get("bz2", 5)
                compressed = bz2.compress(data, compresslevel=lvl)
            
            elif algorithm == Algorithm.LZ4:
                if not HAS_LZ4:
                    raise RuntimeError("LZ4 not available (pip install lz4)")
                lvl = level or self.levels.get("lz4", 6)
                compressed = lz4.compress(data, compression_level=lvl)
            
            elif algorithm == Algorithm.ZSTD:
                if not HAS_ZSTD:
                    raise RuntimeError("Zstandard not available (pip install zstandard)")
                lvl = level or self.levels.get("zstd", 9)
                compressor = zstd.ZstdCompressor(level=lvl)
                compressed = compressor.compress(data)
            
            elif algorithm == Algorithm.BROTLI:
                if not HAS_BROTLI:
                    raise RuntimeError("Brotli not available (pip install brotli)")
                lvl = level or self.levels.get("brotli", 6)
                compressed = brotli.compress(data, quality=lvl)
            
            else:
                raise ValueError(f"Unknown algorithm: {algorithm}")
        
        except Exception as e:
            success = False
            error = str(e)
            compressed = data  # Return original on error
        
        elapsed = time.perf_counter() - start
        
        return compressed, CompressionResult(
            algorithm=algorithm.value,
            original_size=len(data),
            compressed_size=len(compressed),
            ratio=len(compressed) / len(data) if len(data) > 0 else 1.0,
            time_seconds=elapsed,
            success=success,
            error=error,
        )
    
    def decompress(
        self,
        data: bytes,
        algorithm: Algorithm,
    ) -> bytes:
        """Decompress data using specified algorithm"""
        if algorithm == Algorithm.NONE:
            return data
        
        if algorithm == Algorithm.GZIP:
            return gzip.decompress(data)
        
        if algorithm == Algorithm.LZMA:
            if not HAS_LZMA:
                raise RuntimeError("LZMA not available")
            return lzma.decompress(data)
        
        if algorithm == Algorithm.BZ2:
            if not HAS_BZ2:
                raise RuntimeError("BZ2 not available")
            return bz2.decompress(data)
        
        if algorithm == Algorithm.LZ4:
            if not HAS_LZ4:
                raise RuntimeError("LZ4 not available")
            return lz4.decompress(data)
        
        if algorithm == Algorithm.ZSTD:
            if not HAS_ZSTD:
                raise RuntimeError("Zstandard not available")
            decompressor = zstd.ZstdDecompressor()
            return decompressor.decompress(data)
        
        if algorithm == Algorithm.BROTLI:
            if not HAS_BROTLI:
                raise RuntimeError("Brotli not available")
            return brotli.decompress(data)
        
        raise ValueError(f"Unknown algorithm: {algorithm}")
    
    def _auto_compress(self, data: bytes) -> Tuple[bytes, CompressionResult]:
        """Automatically select best algorithm based on data characteristics"""
        # For small data, use fast algorithms
        if len(data) < 1024:
            return self.compress(data, Algorithm.GZIP, level=1)
        
        # For medium data, try a few and pick best ratio
        if len(data) < 100 * 1024:
            candidates = [Algorithm.GZIP, Algorithm.LZMA] if HAS_LZMA else [Algorithm.GZIP]
            if HAS_ZSTD:
                candidates.append(Algorithm.ZSTD)
            
            best_compressed = None
            best_result = None
            
            for algo in candidates:
                compressed, result = self.compress(data, algo)
                if result.success:
                    if best_result is None or result.ratio < best_result.ratio:
                        best_compressed = compressed
                        best_result = result
            
            return best_compressed or data, best_result or CompressionResult(
                algorithm="none", original_size=len(data), compressed_size=len(data),
                ratio=1.0, time_seconds=0.0, success=True
            )
        
        # For large data, use zstd if available (fast + good ratio)
        if HAS_ZSTD:
            return self.compress(data, Algorithm.ZSTD)
        elif HAS_LZ4:
            return self.compress(data, Algorithm.LZ4)
        else:
            return self.compress(data, Algorithm.GZIP)
    
    # =========================================================================
    # FILE OPERATIONS
    # =========================================================================
    
    def compress_file(
        self,
        input_path: Path,
        output_path: Optional[Path] = None,
        algorithm: Algorithm = Algorithm.GZIP,
        chunk_size: int = 1024 * 1024,  # 1MB chunks
    ) -> CompressionResult:
        """Compress a file"""
        input_path = Path(input_path)
        
        if output_path is None:
            ext_map = {
                Algorithm.GZIP: ".gz",
                Algorithm.LZMA: ".xz",
                Algorithm.BZ2: ".bz2",
                Algorithm.LZ4: ".lz4",
                Algorithm.ZSTD: ".zst",
                Algorithm.BROTLI: ".br",
            }
            ext = ext_map.get(algorithm, ".compressed")
            output_path = input_path.with_suffix(input_path.suffix + ext)
        
        output_path = Path(output_path)
        original_size = input_path.stat().st_size
        start = time.perf_counter()
        
        try:
            with open(input_path, "rb") as f_in:
                data = f_in.read()
            
            compressed, _ = self.compress(data, algorithm)
            
            with open(output_path, "wb") as f_out:
                f_out.write(compressed)
            
            elapsed = time.perf_counter() - start
            compressed_size = output_path.stat().st_size
            
            return CompressionResult(
                algorithm=algorithm.value,
                original_size=original_size,
                compressed_size=compressed_size,
                ratio=compressed_size / original_size if original_size > 0 else 1.0,
                time_seconds=elapsed,
                success=True,
            )
        
        except Exception as e:
            return CompressionResult(
                algorithm=algorithm.value,
                original_size=original_size,
                compressed_size=0,
                ratio=1.0,
                time_seconds=time.perf_counter() - start,
                success=False,
                error=str(e),
            )
    
    def decompress_file(
        self,
        input_path: Path,
        output_path: Optional[Path] = None,
        algorithm: Optional[Algorithm] = None,
    ) -> bool:
        """Decompress a file"""
        input_path = Path(input_path)
        
        # Auto-detect algorithm from extension
        if algorithm is None:
            ext_map = {
                ".gz": Algorithm.GZIP,
                ".xz": Algorithm.LZMA,
                ".bz2": Algorithm.BZ2,
                ".lz4": Algorithm.LZ4,
                ".zst": Algorithm.ZSTD,
                ".br": Algorithm.BROTLI,
            }
            algorithm = ext_map.get(input_path.suffix.lower())
            if algorithm is None:
                raise ValueError(f"Cannot detect algorithm from extension: {input_path.suffix}")
        
        if output_path is None:
            # Remove compression extension
            output_path = input_path.with_suffix("")
        
        with open(input_path, "rb") as f:
            compressed = f.read()
        
        decompressed = self.decompress(compressed, algorithm)
        
        with open(output_path, "wb") as f:
            f.write(decompressed)
        
        return True
    
    # =========================================================================
    # BENCHMARKING
    # =========================================================================
    
    def benchmark(
        self,
        data: bytes,
        algorithms: Optional[List[Algorithm]] = None,
        iterations: int = 1,
    ) -> BenchmarkResult:
        """
        Benchmark compression algorithms
        
        Args:
            data: Sample data to compress
            algorithms: List of algorithms to test (None = all available)
            iterations: Number of iterations for averaging
        
        Returns:
            BenchmarkResult with comparison data
        """
        if algorithms is None:
            algorithms = [a for a in self.available_algorithms() if a != Algorithm.NONE]
        
        results = []
        
        for algo in algorithms:
            total_time = 0.0
            last_result = None
            
            for _ in range(iterations):
                _, result = self.compress(data, algo)
                total_time += result.time_seconds
                last_result = result
            
            if last_result:
                # Average the time
                last_result.time_seconds = total_time / iterations
                results.append(last_result)
        
        # Find best ratio and speed
        successful = [r for r in results if r.success]
        best_ratio = min(successful, key=lambda r: r.ratio) if successful else None
        best_speed = min(successful, key=lambda r: r.time_seconds) if successful else None
        
        return BenchmarkResult(
            data_size=len(data),
            results=results,
            best_ratio=best_ratio,
            best_speed=best_speed,
        )
    
    def benchmark_file(
        self,
        filepath: Path,
        max_sample_size: int = 10 * 1024 * 1024,  # 10MB
    ) -> BenchmarkResult:
        """Benchmark using file data"""
        with open(filepath, "rb") as f:
            data = f.read(max_sample_size)
        return self.benchmark(data)


# =============================================================================
# STREAMING COMPRESSION
# =============================================================================

class StreamingCompressor:
    """
    Streaming compression for large files
    
    Usage:
        with StreamingCompressor("output.gz", Algorithm.GZIP) as compressor:
            for chunk in large_data_generator():
                compressor.write(chunk)
    """
    
    def __init__(
        self,
        output_path: Path,
        algorithm: Algorithm = Algorithm.GZIP,
        level: Optional[int] = None,
    ):
        self.output_path = Path(output_path)
        self.algorithm = algorithm
        self.level = level or 6
        self._file: Optional[BinaryIO] = None
        self._compressor = None
        self._bytes_written = 0
        self._bytes_compressed = 0
    
    def __enter__(self):
        self._file = open(self.output_path, "wb")
        
        if self.algorithm == Algorithm.GZIP:
            self._compressor = gzip.GzipFile(
                fileobj=self._file, mode="wb", compresslevel=self.level
            )
        elif self.algorithm == Algorithm.LZMA and HAS_LZMA:
            self._compressor = lzma.open(self._file, "wb", preset=self.level)
        elif self.algorithm == Algorithm.ZSTD and HAS_ZSTD:
            ctx = zstd.ZstdCompressor(level=self.level)
            self._compressor = ctx.stream_writer(self._file)
        else:
            # Fallback to gzip
            self._compressor = gzip.GzipFile(
                fileobj=self._file, mode="wb", compresslevel=self.level
            )
        
        return self
    
    def write(self, data: bytes):
        """Write data to compressor"""
        self._bytes_written += len(data)
        self._compressor.write(data)
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._compressor:
            self._compressor.close()
        if self._file:
            self._file.close()
        
        if self.output_path.exists():
            self._bytes_compressed = self.output_path.stat().st_size


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def compress(data: bytes, algorithm: str = "gzip") -> bytes:
    """Simple compression function"""
    engine = CompressionEngine()
    algo = Algorithm(algorithm)
    compressed, _ = engine.compress(data, algo)
    return compressed


def decompress(data: bytes, algorithm: str = "gzip") -> bytes:
    """Simple decompression function"""
    engine = CompressionEngine()
    algo = Algorithm(algorithm)
    return engine.decompress(data, algo)


def benchmark_data(data: bytes) -> Dict[str, Any]:
    """Quick benchmark of data"""
    engine = CompressionEngine()
    result = engine.benchmark(data)
    return result.to_dict()


def best_algorithm(data: bytes) -> str:
    """Find best algorithm for data"""
    engine = CompressionEngine()
    result = engine.benchmark(data)
    if result.best_ratio:
        return result.best_ratio.algorithm
    return "gzip"
