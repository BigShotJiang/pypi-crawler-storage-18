"""
ARIA Network Scanner v1.0.0

Network discovery and device scanning capabilities for the mesh.

Features:
  - Local network device discovery
  - Port scanning
  - Service detection
  - Device fingerprinting
  - Tailscale peer discovery
"""

import socket
import subprocess
import json
import threading
import time
import os
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Callable
from enum import Enum
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed


# =============================================================================
# ENUMS AND DATACLASSES
# =============================================================================

class DeviceType(str, Enum):
    """Detected device types"""
    UNKNOWN = "unknown"
    PC = "pc"
    PHONE = "phone"
    TABLET = "tablet"
    SERVER = "server"
    ROUTER = "router"
    PRINTER = "printer"
    SMART_DEVICE = "smart_device"
    GAME_CONSOLE = "game_console"
    MEDIA_PLAYER = "media_player"


class ServiceType(str, Enum):
    """Common service types"""
    HTTP = "http"
    HTTPS = "https"
    SSH = "ssh"
    FTP = "ftp"
    SMB = "smb"
    MQTT = "mqtt"
    REDIS = "redis"
    POSTGRES = "postgres"
    MYSQL = "mysql"
    ARIA_MESH = "aria_mesh"
    UNKNOWN = "unknown"


@dataclass
class OpenPort:
    """Information about an open port"""
    port: int
    protocol: str = "tcp"
    service: ServiceType = ServiceType.UNKNOWN
    banner: str = ""
    response_time: float = 0.0


@dataclass
class NetworkDevice:
    """A discovered network device"""
    ip: str
    hostname: str = ""
    mac: str = ""
    device_type: DeviceType = DeviceType.UNKNOWN
    vendor: str = ""
    open_ports: List[OpenPort] = field(default_factory=list)
    is_tailscale: bool = False
    tailscale_name: str = ""
    response_time: float = 0.0
    last_seen: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "ip": self.ip,
            "hostname": self.hostname,
            "mac": self.mac,
            "device_type": self.device_type.value,
            "vendor": self.vendor,
            "open_ports": [asdict(p) for p in self.open_ports],
            "is_tailscale": self.is_tailscale,
            "tailscale_name": self.tailscale_name,
            "response_time": self.response_time,
            "last_seen": self.last_seen,
            "metadata": self.metadata,
        }


@dataclass
class ScanResult:
    """Result of a network scan"""
    network: str
    devices: List[NetworkDevice]
    scan_time: float
    scan_type: str
    total_hosts: int
    alive_hosts: int
    errors: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "network": self.network,
            "devices": [d.to_dict() for d in self.devices],
            "scan_time": self.scan_time,
            "scan_type": self.scan_type,
            "total_hosts": self.total_hosts,
            "alive_hosts": self.alive_hosts,
            "errors": self.errors,
        }


# =============================================================================
# COMMON PORTS AND SERVICE DETECTION
# =============================================================================

COMMON_PORTS = {
    21: ServiceType.FTP,
    22: ServiceType.SSH,
    80: ServiceType.HTTP,
    443: ServiceType.HTTPS,
    445: ServiceType.SMB,
    1883: ServiceType.MQTT,
    3306: ServiceType.MYSQL,
    5432: ServiceType.POSTGRES,
    6379: ServiceType.REDIS,
    8765: ServiceType.ARIA_MESH,  # Our mesh server
    8080: ServiceType.HTTP,
    8443: ServiceType.HTTPS,
}

QUICK_SCAN_PORTS = [22, 80, 443, 445, 3389, 5000, 8080, 8765]

MAC_VENDORS = {
    "00:1A:2B": "Apple",
    "00:50:56": "VMware",
    "08:00:27": "VirtualBox",
    "B8:27:EB": "Raspberry Pi",
    "DC:A6:32": "Raspberry Pi",
    "00:0C:29": "VMware",
}


# =============================================================================
# NETWORK SCANNER CLASS
# =============================================================================

class NetworkScanner:
    """
    Network device discovery and scanning
    
    Usage:
        scanner = NetworkScanner()
        
        # Quick ping sweep
        devices = scanner.ping_sweep("192.168.1.0/24")
        
        # Port scan specific host
        ports = scanner.port_scan("192.168.1.1", [22, 80, 443])
        
        # Full network discovery
        result = scanner.full_scan()
    """
    
    def __init__(self, timeout: float = 1.0, max_threads: int = 50):
        self.timeout = timeout
        self.max_threads = max_threads
        self.cache_dir = Path.home() / ".aria" / "network-cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._devices_cache: Dict[str, NetworkDevice] = {}
        self._scan_in_progress = False
        self._progress_callback: Optional[Callable] = None
    
    def set_progress_callback(self, callback: Callable[[int, int, str], None]):
        """Set a callback for progress updates: callback(current, total, message)"""
        self._progress_callback = callback
    
    def _report_progress(self, current: int, total: int, message: str = ""):
        """Report progress to callback if set"""
        if self._progress_callback:
            self._progress_callback(current, total, message)
    
    # =========================================================================
    # NETWORK UTILITIES
    # =========================================================================
    
    def get_local_ip(self) -> str:
        """Get local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"
    
    def get_network_range(self, ip: Optional[str] = None) -> str:
        """Get network range from IP (assumes /24)"""
        if ip is None:
            ip = self.get_local_ip()
        parts = ip.split(".")
        if len(parts) == 4:
            return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"
        return "192.168.1.0/24"
    
    def ip_range_from_cidr(self, cidr: str) -> List[str]:
        """Generate list of IPs from CIDR notation"""
        try:
            parts = cidr.split("/")
            base_ip = parts[0]
            prefix = int(parts[1]) if len(parts) > 1 else 24
            
            if prefix < 24:
                # Limit to /24 for safety
                prefix = 24
            
            base_parts = base_ip.split(".")
            if len(base_parts) != 4:
                return []
            
            # For /24, scan .1 to .254
            if prefix == 24:
                base = ".".join(base_parts[:3])
                return [f"{base}.{i}" for i in range(1, 255)]
            
            return []
        except Exception:
            return []
    
    def get_hostname(self, ip: str) -> str:
        """Resolve hostname for IP"""
        try:
            hostname, _, _ = socket.gethostbyaddr(ip)
            return hostname
        except socket.herror:
            return ""
        except Exception:
            return ""
    
    # =========================================================================
    # PING OPERATIONS
    # =========================================================================
    
    def ping(self, ip: str) -> Tuple[bool, float]:
        """
        Ping an IP address
        
        Returns:
            (is_alive, response_time_ms)
        """
        try:
            if os.name == "nt":  # Windows
                cmd = ["ping", "-n", "1", "-w", str(int(self.timeout * 1000)), ip]
            else:  # Linux/Mac
                cmd = ["ping", "-c", "1", "-W", str(int(self.timeout)), ip]
            
            start = time.time()
            result = subprocess.run(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=self.timeout + 1
            )
            elapsed = (time.time() - start) * 1000
            
            return result.returncode == 0, elapsed
            
        except subprocess.TimeoutExpired:
            return False, 0.0
        except Exception:
            return False, 0.0
    
    def ping_sweep(
        self, 
        network: Optional[str] = None,
        callback: Optional[Callable[[str, bool], None]] = None
    ) -> List[NetworkDevice]:
        """
        Ping sweep a network range
        
        Args:
            network: CIDR notation (e.g., "192.168.1.0/24"), auto-detect if None
            callback: Optional callback for each result: callback(ip, is_alive)
            
        Returns:
            List of alive devices
        """
        if network is None:
            network = self.get_network_range()
        
        ips = self.ip_range_from_cidr(network)
        devices = []
        
        with ThreadPoolExecutor(max_workers=self.max_threads) as executor:
            futures = {executor.submit(self.ping, ip): ip for ip in ips}
            
            for i, future in enumerate(as_completed(futures)):
                ip = futures[future]
                self._report_progress(i + 1, len(ips), f"Pinging {ip}")
                
                try:
                    is_alive, response_time = future.result()
                    
                    if callback:
                        callback(ip, is_alive)
                    
                    if is_alive:
                        device = NetworkDevice(
                            ip=ip,
                            hostname=self.get_hostname(ip),
                            response_time=response_time,
                        )
                        devices.append(device)
                        self._devices_cache[ip] = device
                        
                except Exception:
                    pass
        
        return devices
    
    # =========================================================================
    # PORT SCANNING
    # =========================================================================
    
    def scan_port(self, ip: str, port: int) -> Optional[OpenPort]:
        """
        Scan a single port
        
        Returns:
            OpenPort if open, None if closed
        """
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self.timeout)
            
            start = time.time()
            result = sock.connect_ex((ip, port))
            elapsed = time.time() - start
            
            if result == 0:
                # Port is open
                service = COMMON_PORTS.get(port, ServiceType.UNKNOWN)
                banner = self._grab_banner(sock, port)
                sock.close()
                
                return OpenPort(
                    port=port,
                    service=service,
                    banner=banner,
                    response_time=elapsed,
                )
            
            sock.close()
            return None
            
        except Exception:
            return None
    
    def _grab_banner(self, sock: socket.socket, port: int) -> str:
        """Attempt to grab service banner"""
        try:
            # Send probe based on port
            if port in [80, 8080, 8765]:
                sock.send(b"GET / HTTP/1.1\r\nHost: localhost\r\n\r\n")
            elif port == 22:
                pass  # SSH sends banner on connect
            else:
                sock.send(b"\r\n")
            
            sock.settimeout(0.5)
            banner = sock.recv(256).decode("utf-8", errors="ignore")
            return banner.strip()[:100]
        except Exception:
            return ""
    
    def port_scan(
        self, 
        ip: str, 
        ports: Optional[List[int]] = None
    ) -> List[OpenPort]:
        """
        Scan ports on a host
        
        Args:
            ip: Target IP address
            ports: List of ports to scan (default: common ports)
            
        Returns:
            List of open ports
        """
        if ports is None:
            ports = QUICK_SCAN_PORTS
        
        open_ports = []
        
        with ThreadPoolExecutor(max_workers=min(len(ports), 20)) as executor:
            futures = {executor.submit(self.scan_port, ip, port): port for port in ports}
            
            for i, future in enumerate(as_completed(futures)):
                port = futures[future]
                self._report_progress(i + 1, len(ports), f"Scanning {ip}:{port}")
                
                try:
                    result = future.result()
                    if result:
                        open_ports.append(result)
                except Exception:
                    pass
        
        return sorted(open_ports, key=lambda p: p.port)
    
    # =========================================================================
    # TAILSCALE INTEGRATION
    # =========================================================================
    
    def get_tailscale_peers(self) -> List[NetworkDevice]:
        """
        Get list of Tailscale peers
        
        Returns:
            List of Tailscale devices
        """
        devices = []
        
        try:
            result = subprocess.run(
                ["tailscale", "status", "--json"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            if result.returncode == 0:
                data = json.loads(result.stdout)
                peers = data.get("Peer", {})
                
                for peer_id, peer_info in peers.items():
                    ip = ""
                    if peer_info.get("TailscaleIPs"):
                        ip = peer_info["TailscaleIPs"][0]
                    
                    device = NetworkDevice(
                        ip=ip,
                        hostname=peer_info.get("HostName", ""),
                        device_type=self._guess_device_type(peer_info.get("OS", "")),
                        is_tailscale=True,
                        tailscale_name=peer_info.get("DNSName", "").split(".")[0],
                        metadata={
                            "os": peer_info.get("OS", ""),
                            "online": peer_info.get("Online", False),
                            "last_seen": peer_info.get("LastSeen", ""),
                            "peer_id": peer_id,
                        }
                    )
                    devices.append(device)
                    
        except FileNotFoundError:
            pass  # Tailscale not installed
        except Exception:
            pass
        
        return devices
    
    def _guess_device_type(self, os_info: str) -> DeviceType:
        """Guess device type from OS info"""
        os_lower = os_info.lower()
        if "windows" in os_lower:
            return DeviceType.PC
        elif "linux" in os_lower:
            return DeviceType.SERVER
        elif "android" in os_lower:
            return DeviceType.PHONE
        elif "ios" in os_lower or "iphone" in os_lower:
            return DeviceType.PHONE
        elif "macos" in os_lower or "darwin" in os_lower:
            return DeviceType.PC
        return DeviceType.UNKNOWN
    
    # =========================================================================
    # FULL NETWORK SCAN
    # =========================================================================
    
    def full_scan(
        self,
        network: Optional[str] = None,
        scan_ports: bool = True,
        include_tailscale: bool = True,
    ) -> ScanResult:
        """
        Full network discovery scan
        
        Args:
            network: CIDR notation (auto-detect if None)
            scan_ports: Whether to scan ports on discovered hosts
            include_tailscale: Include Tailscale peers
            
        Returns:
            ScanResult with all discovered devices
        """
        if network is None:
            network = self.get_network_range()
        
        start_time = time.time()
        errors = []
        devices = []
        
        # Ping sweep
        try:
            ping_devices = self.ping_sweep(network)
            devices.extend(ping_devices)
        except Exception as e:
            errors.append(f"Ping sweep failed: {e}")
        
        # Port scan discovered hosts
        if scan_ports:
            for device in devices:
                try:
                    device.open_ports = self.port_scan(device.ip)
                    # Update device type based on services
                    device.device_type = self._infer_device_type(device)
                except Exception as e:
                    errors.append(f"Port scan {device.ip} failed: {e}")
        
        # Add Tailscale peers
        if include_tailscale:
            try:
                tailscale_devices = self.get_tailscale_peers()
                for ts_device in tailscale_devices:
                    # Check if already in list
                    existing = next((d for d in devices if d.ip == ts_device.ip), None)
                    if existing:
                        existing.is_tailscale = True
                        existing.tailscale_name = ts_device.tailscale_name
                        existing.metadata.update(ts_device.metadata)
                    else:
                        devices.append(ts_device)
            except Exception as e:
                errors.append(f"Tailscale discovery failed: {e}")
        
        scan_time = time.time() - start_time
        
        result = ScanResult(
            network=network,
            devices=devices,
            scan_time=scan_time,
            scan_type="full",
            total_hosts=len(self.ip_range_from_cidr(network)),
            alive_hosts=len(devices),
            errors=errors,
        )
        
        # Cache result
        self._save_scan_result(result)
        
        return result
    
    def _infer_device_type(self, device: NetworkDevice) -> DeviceType:
        """Infer device type from open ports and services"""
        port_numbers = [p.port for p in device.open_ports]
        
        # Check for specific services
        if 8765 in port_numbers:
            return DeviceType.PC  # ARIA mesh server
        if 80 in port_numbers and 443 in port_numbers:
            return DeviceType.SERVER
        if 22 in port_numbers:
            return DeviceType.SERVER
        if 3389 in port_numbers:
            return DeviceType.PC
        if 515 in port_numbers or 9100 in port_numbers:
            return DeviceType.PRINTER
        
        return device.device_type
    
    def _save_scan_result(self, result: ScanResult):
        """Save scan result to cache"""
        try:
            cache_file = self.cache_dir / "last_scan.json"
            with open(cache_file, "w") as f:
                json.dump(result.to_dict(), f, indent=2)
        except Exception:
            pass
    
    def get_cached_scan(self) -> Optional[ScanResult]:
        """Get last cached scan result"""
        try:
            cache_file = self.cache_dir / "last_scan.json"
            if cache_file.exists():
                with open(cache_file) as f:
                    data = json.load(f)
                # Reconstruct ScanResult
                devices = [
                    NetworkDevice(
                        ip=d["ip"],
                        hostname=d.get("hostname", ""),
                        device_type=DeviceType(d.get("device_type", "unknown")),
                        is_tailscale=d.get("is_tailscale", False),
                        tailscale_name=d.get("tailscale_name", ""),
                    )
                    for d in data.get("devices", [])
                ]
                return ScanResult(
                    network=data.get("network", ""),
                    devices=devices,
                    scan_time=data.get("scan_time", 0),
                    scan_type=data.get("scan_type", "cached"),
                    total_hosts=data.get("total_hosts", 0),
                    alive_hosts=data.get("alive_hosts", 0),
                )
        except Exception:
            pass
        return None


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def quick_scan() -> List[Dict[str, Any]]:
    """Quick network scan returning simple device list"""
    scanner = NetworkScanner(timeout=0.5)
    devices = scanner.ping_sweep()
    return [d.to_dict() for d in devices]


def find_mesh_servers(network: Optional[str] = None) -> List[Dict[str, Any]]:
    """Find ARIA mesh servers on the network"""
    scanner = NetworkScanner(timeout=1.0)
    
    if network is None:
        network = scanner.get_network_range()
    
    devices = scanner.ping_sweep(network)
    mesh_servers = []
    
    for device in devices:
        port_result = scanner.scan_port(device.ip, 8765)
        if port_result:
            mesh_servers.append({
                "ip": device.ip,
                "hostname": device.hostname,
                "port": 8765,
                "response_time": port_result.response_time,
            })
    
    return mesh_servers


# Missing import for type hint
from typing import Tuple
