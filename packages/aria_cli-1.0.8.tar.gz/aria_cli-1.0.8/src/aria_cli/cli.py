"""
ARIA CLI v0.2.0 - Main Command Line Interface

Full Q0-Q38 cognitive architecture with:
- Interactive REPL mode
- Command chaining
- LLM integration
- GUI sync capabilities
- Rich terminal output
"""

import sys
from pathlib import Path
from typing import Optional, List, Any, Dict
from enum import Enum
import json
import os

try:
    import typer
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.syntax import Syntax
    from rich.markdown import Markdown
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.prompt import Prompt, Confirm
    from rich import print as rprint
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    Console = None
    typer = None


from .q_system import QSystem, QLayer, QOperator, QCommand
from .nlp_engine import NLPEngine, Intent, ParsedInput
from .llm_connector import LLMConnector, LLMConfig
from .q38_connector import Q38Connector, Q38Config
from .aria_space import AriaSpace, SyncDirection
from .termux_setup import TermuxSetup


# Console for rich output
console = Console() if HAS_RICH else None


def version_callback(value: bool):
    """Print version and exit"""
    if value:
        print("ARIA CLI v1.0.0")
        raise typer.Exit()


# Main app
if typer:
    app = typer.Typer(
        name="aria",
        help="ARIA CLI v1.0.0 - Advanced Recursive Intelligence Architecture with Q-Mesh Distributed Compute",
        add_completion=False,
    )
else:
    app = None


if app:
    @app.callback()
    def main_callback(
        version: bool = typer.Option(
            False, "--version", "-v", callback=version_callback,
            is_eager=True, help="Show version and exit"
        )
    ):
        """ARIA CLI - Advanced Recursive Intelligence Architecture"""
        pass


class OutputFormat(str, Enum):
    """Output format options"""
    PLAIN = "plain"
    JSON = "json"
    RICH = "rich"



class AriaCLI:
    """
    ARIA Command Line Interface
    
    Provides a unified interface to the Q0-Q38 cognitive system
    with LLM integration, GitHub automation, and F1/M1 cycle orchestration.
    """
    
    VERSION = "1.0.8"
    
    def __init__(
        self,
        config_path: Optional[Path] = None,
        output_format: OutputFormat = OutputFormat.RICH,
        use_llm: bool = True,
    ):
        """
        Initialize ARIA CLI
        
        Args:
            config_path: Path to configuration file
            output_format: Output format (plain, json, rich)
            use_llm: Whether to enable LLM integration
        """
        self.output_format = output_format
        self.use_llm = use_llm
        
        # Initialize subsystems
        self.q_system = QSystem()
        self.nlp = NLPEngine()
        self.llm: Optional[LLMConnector] = None
        self.q38: Optional[Q38Connector] = None
        
        # Configuration
        self.config = self._load_config(config_path)
        
        # Session state
        self.session_history: List[Dict[str, Any]] = []
        self.context: Dict[str, Any] = {}
        
        # Initialize LLM if requested
        if use_llm:
            self._init_llm()
        
        # Initialize Q38 cluster connector
        self._init_q38()
    
    def _load_config(self, config_path: Optional[Path] = None) -> Dict[str, Any]:
        """Load configuration from file or defaults"""
        default_config = {
            'llm': {
                'backend': 'auto',
                'model': None,
                'temperature': 0.7,
                'max_tokens': 2048,
            },
            'q_system': {
                'default_layer': 8,
                'trace_enabled': True,
            },
            'ui': {
                'theme': 'dark',
                'show_layer_info': True,
            },
        }
        
        if config_path and config_path.exists():
            try:
                with open(config_path) as f:
                    user_config = json.load(f)
                # Deep merge
                for key in user_config:
                    if isinstance(user_config[key], dict) and key in default_config:
                        default_config[key].update(user_config[key])
                    else:
                        default_config[key] = user_config[key]
            except Exception:
                pass
        
        return default_config
    
    def _init_llm(self):
        """Initialize LLM connector"""
        try:
            llm_config = LLMConfig(
                temperature=self.config['llm'].get('temperature', 0.7),
                max_tokens=self.config['llm'].get('max_tokens', 2048),
            )
            self.llm = LLMConnector(config=llm_config)
        except Exception:
            self.llm = None
    
    def _init_q38(self):
        """Initialize Q38 cluster connector"""
        try:
            q38_config = self.config.get('q38', {})
            cluster_config = Q38Config(
                base_port=q38_config.get('base_port', 8200),
                node_count=q38_config.get('node_count', 8),
                sync_port=q38_config.get('sync_port', 9000),
            )
            self.q38 = Q38Connector(config=cluster_config)
        except Exception as e:
            self.q38 = None
            # Q38 is optional - continue without it
    
    def output(self, content: Any, title: Optional[str] = None):
        """
        Output content in the configured format
        
        Args:
            content: Content to output
            title: Optional title for panels
        """
        if self.output_format == OutputFormat.JSON:
            if isinstance(content, (dict, list)):
                print(json.dumps(content, indent=2, default=str))
            else:
                print(json.dumps({'result': str(content)}, indent=2))
        
        elif self.output_format == OutputFormat.RICH and console:
            if isinstance(content, dict):
                table = Table(show_header=True)
                table.add_column("Key", style="cyan")
                table.add_column("Value", style="white")
                for k, v in content.items():
                    table.add_row(str(k), str(v))
                if title:
                    console.print(Panel(table, title=title))
                else:
                    console.print(table)
            elif isinstance(content, str):
                if title:
                    console.print(Panel(content, title=title))
                else:
                    console.print(content)
            else:
                console.print(content)
        
        else:
            print(content)
    
    def process(self, input_text: str) -> Dict[str, Any]:
        """
        Process user input through the full Q-System pipeline
        
        Args:
            input_text: User input text
            
        Returns:
            Processing result dictionary
        """
        # Parse input
        parsed = self.nlp.parse(input_text, context=self.context)
        
        # Create Q-Command
        command = QCommand(
            operator=QOperator[parsed.q_operator] if hasattr(QOperator, parsed.q_operator) else QOperator.ASK,
            payload=parsed.payload,
            layer=QLayer(parsed.q_layer) if parsed.q_layer <= 38 else QLayer.Q8_LANGUAGE,
            metadata={'context': self.context},
        )
        
        # Execute through Q-System
        result = self.q_system.execute(command)
        
        # Enhance with LLM if available
        if self.llm and self.llm.available:
            llm_response = self._enhance_with_llm(parsed, result)
            result['llm_response'] = llm_response
        
        # Update context
        self.context['last_intent'] = parsed.intent.name
        self.context['last_result'] = result
        
        # Store in history
        self.session_history.append({
            'input': input_text,
            'parsed': parsed.to_dict(),
            'result': result,
        })
        
        return result
    
    def _enhance_with_llm(self, parsed: ParsedInput, q_result: Dict[str, Any]) -> Optional[str]:
        """Enhance Q-System result with LLM generation"""
        if not self.llm:
            return None
        
        # Build prompt based on intent
        prompt = self._build_llm_prompt(parsed, q_result)
        
        try:
            response = self.llm.generate(
                prompt=prompt,
                context={
                    'q_layer': parsed.q_layer,
                    'intent': parsed.intent.name,
                    'keywords': parsed.keywords,
                },
            )
            return response
        except Exception as e:
            return f"LLM unavailable: {e}"
    
    def _build_llm_prompt(self, parsed: ParsedInput, q_result: Dict[str, Any]) -> str:
        """Build LLM prompt based on parsed input"""
        base = f"""You are ARIA, an Advanced Recursive Intelligence Architecture operating at Q-Layer {parsed.q_layer}.

User request: {parsed.raw_text}
Detected intent: {parsed.intent.name}
Keywords: {', '.join(parsed.keywords)}
Q-System processing complete. Provide a helpful response.

"""
        
        if parsed.intent == Intent.EXPLAIN:
            base += "Provide a clear, detailed explanation."
        elif parsed.intent == Intent.SUMMARIZE:
            base += "Provide a concise summary."
        elif parsed.intent == Intent.GENERATE:
            base += f"Generate the requested content: {parsed.payload.get('target', '')}"
        elif parsed.intent == Intent.ANALYZE:
            base += "Provide analytical insights."
        
        return base
    
    def interactive_mode(self):
        """Run interactive REPL mode"""
        if console:
            console.print(Panel.fit(
                f"[bold cyan]ARIA CLI v{self.VERSION}[/bold cyan]\n"
                f"[dim]Q0-Q38 Cognitive Architecture[/dim]\n\n"
                f"Type [bold green]help[/bold green] for commands, [bold red]exit[/bold red] to quit",
                title="Welcome",
                border_style="cyan",
            ))
        else:
            print(f"\nARIA CLI v{self.VERSION}")
            print("Type 'help' for commands, 'exit' to quit\n")
        
        while True:
            try:
                # Get input
                if console:
                    prompt_text = f"[bold cyan]ARIA[/bold cyan] [dim]Q{self.context.get('current_layer', 8)}[/dim] > "
                    user_input = Prompt.ask(prompt_text)
                else:
                    user_input = input(f"ARIA Q{self.context.get('current_layer', 8)} > ")
                
                user_input = user_input.strip()
                
                if not user_input:
                    continue
                
                # Handle special commands
                if user_input.lower() in ('exit', 'quit', 'q'):
                    if console:
                        console.print("[dim]Goodbye![/dim]")
                    else:
                        print("Goodbye!")
                    break
                
                if user_input.lower() == 'help':
                    self._show_help()
                    continue
                
                if user_input.lower() == 'status':
                    self._show_status()
                    continue
                
                if user_input.lower() == 'layers':
                    self._show_layers()
                    continue
                
                if user_input.lower().startswith('layer '):
                    layer_num = int(user_input.split()[1])
                    self._set_layer(layer_num)
                    continue
                
                if user_input.lower() == 'history':
                    self._show_history()
                    continue
                
                if user_input.lower() == 'clear':
                    self.session_history.clear()
                    self.nlp.clear_context()
                    if console:
                        console.print("[dim]History cleared[/dim]")
                    else:
                        print("History cleared")
                    continue
                
                # Q38 Commands
                if user_input.lower().startswith('q38 '):
                    self._handle_q38_command(user_input[4:].strip())
                    continue
                
                # Process through Q-System
                result = self.process(user_input)
                
                # Display result
                if self.output_format == OutputFormat.RICH and console:
                    self._display_result_rich(result)
                else:
                    self.output(result)
                
            except KeyboardInterrupt:
                if console:
                    console.print("\n[dim]Use 'exit' to quit[/dim]")
                else:
                    print("\nUse 'exit' to quit")
            except Exception as e:
                if console:
                    console.print(f"[red]Error: {e}[/red]")
                else:
                    print(f"Error: {e}")
    
    def _show_help(self):
        """Display help information"""
        if console:
            table = Table(title="ARIA CLI Commands", show_header=True)
            table.add_column("Command", style="cyan")
            table.add_column("Description", style="white")
            
            commands = [
                ("help", "Show this help message"),
                ("status", "Show system status"),
                ("layers", "List all Q-Layers"),
                ("layer <N>", "Switch to Q-Layer N"),
                ("history", "Show session history"),
                ("clear", "Clear session history"),
                ("q38 status", "Show Q38 cluster status"),
                ("q38 directions", "List all 64 directions"),
                ("q38 query <dir> <text>", "Query a specific direction"),
                ("exit", "Exit ARIA CLI"),
            ]
            
            for cmd, desc in commands:
                table.add_row(cmd, desc)
            
            console.print(table)
            console.print("\n[dim]Natural language queries are processed through the Q-System[/dim]")
        else:
            print("\nARIA CLI Commands:")
            print("  help     - Show this help message")
            print("  status   - Show system status")
            print("  layers   - List all Q-Layers")
            print("  layer N  - Switch to Q-Layer N")
            print("  history  - Show session history")
            print("  clear    - Clear session history")
            print("  q38 status     - Show Q38 cluster status")
            print("  q38 directions - List all 64 directions")
            print("  q38 query <dir> <text> - Query a direction")
            print("  exit     - Exit ARIA CLI")
            print("\nNatural language queries are processed through the Q-System\n")
    
    def _show_status(self):
        """Display system status"""
        status = {
            'Version': self.VERSION,
            'Q-System': 'Active',
            'Current Layer': self.context.get('current_layer', 8),
            'LLM': 'Connected' if self.llm and self.llm.available else 'Disconnected',
            'LLM Backend': getattr(self.llm, 'backend', 'N/A') if self.llm else 'N/A',
            'Q38 Cluster': 'Connected' if self.q38 else 'Disconnected',
            'Q38 Directions': len(self.q38.directions) if self.q38 else 0,
            'Session Commands': len(self.session_history),
            'NLP Context': len(self.nlp.get_context()),
        }
        self.output(status, title="System Status")
    
    def _handle_q38_command(self, cmd: str):
        """Handle Q38 cluster commands"""
        import asyncio
        
        parts = cmd.split(maxsplit=2)
        subcmd = parts[0].lower() if parts else ''
        
        if subcmd == 'status':
            self._show_q38_status()
        elif subcmd == 'directions':
            self._show_q38_directions()
        elif subcmd == 'query' and len(parts) >= 3:
            direction = parts[1]
            query_text = parts[2]
            asyncio.run(self._q38_query(direction, query_text))
        elif subcmd == 'init':
            asyncio.run(self._q38_init())
        elif subcmd == 'sync':
            event_data = parts[1] if len(parts) > 1 else 'ping'
            asyncio.run(self._q38_sync(event_data))
        else:
            if console:
                console.print("[yellow]Q38 Commands:[/yellow]")
                console.print("  q38 status     - Show cluster status")
                console.print("  q38 directions - List all directions")
                console.print("  q38 query <direction> <text> - Query a direction")
                console.print("  q38 init       - Initialize cluster")
                console.print("  q38 sync [event] - Broadcast sync event")
            else:
                print("Q38 Commands: status, directions, query <dir> <text>, init, sync")
    
    def _show_q38_status(self):
        """Display Q38 cluster status"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        status = {
            'API URL': self.q38.config.api_url,
            'Base Port': self.q38.config.base_port,
            'Node Count': self.q38.config.node_count,
            'Sync Port': self.q38.config.sync_port,
            'Active Nodes': len([d for d, n in self.q38.nodes.items() if n.get('active', False)]),
            'Total Directions': len(self.q38.directions),
        }
        self.output(status, title="Q38 Cluster Status")
    
    def _show_q38_directions(self):
        """Display all 64 directions"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        directions = self.q38.get_all_directions()
        
        if console:
            table = Table(title="Q38 64-Direction System", show_header=True)
            table.add_column("ID", style="cyan", width=3)
            table.add_column("Direction", style="white")
            table.add_column("Port", style="yellow")
            
            for i, direction in enumerate(directions):
                node = self.q38.nodes.get(direction)
                port = node.get('port', self.q38.config.base_port + i) if node else self.q38.config.base_port + i
                table.add_row(str(i), direction, str(port))
            
            console.print(table)
        else:
            print("\nQ38 64-Direction System:")
            for i, direction in enumerate(directions):
                print(f"  {i:2d}: {direction}")
    
    async def _q38_query(self, direction: str, query_text: str):
        """Query a specific Q38 direction"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        if console:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task(f"Querying direction: {direction}", total=None)
                result = await self.q38.direction_query(direction, query_text)
        else:
            print(f"Querying direction: {direction}...")
            result = await self.q38.direction_query(direction, query_text)
        
        self.output(result, title=f"Q38 Response: {direction}")
    
    async def _q38_init(self):
        """Initialize Q38 cluster"""
        if not self.q38:
            if console:
                console.print("[red]Q38 connector not available[/red]")
            else:
                print("Q38 connector not available")
            return
        
        if console:
            console.print("[cyan]Initializing Q38 cluster...[/cyan]")
        else:
            print("Initializing Q38 cluster...")
        
        # Check cluster status
        status = await self.q38.check_cluster_health()
        self.output(status, title="Q38 Cluster Health")
    
    async def _q38_sync(self, event_data: str):
        """Broadcast sync event to all Q38 nodes"""
        if not self.q38:
            if console:
                console.print("[red]Q38 cluster not connected[/red]")
            else:
                print("Q38 cluster not connected")
            return
        
        event = {
            'type': 'sync',
            'data': event_data,
            'source': 'aria-cli',
        }
        
        if console:
            console.print(f"[cyan]Broadcasting sync event: {event_data}[/cyan]")
        else:
            print(f"Broadcasting sync event: {event_data}")
        
        result = await self.q38.sync_event(event)
        self.output(result, title="Sync Result")
    
    def _show_layers(self):
        """Display all Q-Layers"""
        if console:
            table = Table(title="Q0-Q38 Cognitive Layers", show_header=True)
            table.add_column("Layer", style="cyan", width=5)
            table.add_column("Name", style="white")
            table.add_column("Domain", style="yellow")
            
            for layer in QLayer:
                domain = "FOUNDATION" if layer.value < 10 else \
                         "REASONING" if layer.value < 20 else \
                         "METACOGNITION" if layer.value < 30 else "TRANSCENDENCE"
                table.add_row(
                    str(layer.value),
                    layer.name.replace('_', ' '),
                    domain,
                )
            
            console.print(table)
        else:
            print("\nQ0-Q38 Cognitive Layers:")
            for layer in QLayer:
                print(f"  Q{layer.value:2d}: {layer.name}")
    
    def _set_layer(self, layer_num: int):
        """Set current working layer"""
        if 0 <= layer_num <= 38:
            self.context['current_layer'] = layer_num
            layer = QLayer(layer_num)
            if console:
                console.print(f"[green]Switched to {layer.name}[/green]")
            else:
                print(f"Switched to {layer.name}")
        else:
            if console:
                console.print("[red]Invalid layer. Use 0-38.[/red]")
            else:
                print("Invalid layer. Use 0-38.")
    
    def _show_history(self):
        """Display session history"""
        if not self.session_history:
            if console:
                console.print("[dim]No history yet[/dim]")
            else:
                print("No history yet")
            return
        
        if console:
            for i, entry in enumerate(self.session_history[-10:], 1):
                console.print(f"[dim]{i}.[/dim] [cyan]{entry['input']}[/cyan]")
                console.print(f"   [dim]Intent: {entry['parsed']['intent']}[/dim]")
        else:
            for i, entry in enumerate(self.session_history[-10:], 1):
                print(f"{i}. {entry['input']}")
                print(f"   Intent: {entry['parsed']['intent']}")
    
    def _display_result_rich(self, result: Dict[str, Any]):
        """Display result with rich formatting"""
        if not console:
            print(result)
            return
        
        # Main result panel
        if 'llm_response' in result and result['llm_response']:
            console.print(Panel(
                Markdown(result['llm_response']),
                title="ARIA Response",
                border_style="green",
            ))
        
        # Processing info
        if self.config['ui'].get('show_layer_info', True):
            info = result.get('processing', {})
            if info:
                console.print(f"[dim]Layer: Q{info.get('layer', '?')} | "
                            f"Operator: {info.get('operator', '?')} | "
                            f"Trace: {len(info.get('trace', []))} steps[/dim]")


# CLI Commands using Typer
if app:
    
    @app.command()
    def chat(
        llm: bool = typer.Option(True, "--llm/--no-llm", help="Enable LLM integration"),
        format: OutputFormat = typer.Option(OutputFormat.RICH, "--format", "-f", help="Output format"),
        config: Optional[Path] = typer.Option(None, "--config", "-c", help="Config file path"),
    ):
        """Start interactive ARIA session"""
        cli = AriaCLI(
            config_path=config,
            output_format=format,
            use_llm=llm,
        )
        cli.interactive_mode()
    
    @app.command()
    def ask(
        query: str = typer.Argument(..., help="Your question or command"),
        layer: int = typer.Option(8, "--layer", "-l", help="Q-Layer to use (0-38)"),
        format: OutputFormat = typer.Option(OutputFormat.RICH, "--format", "-f", help="Output format"),
    ):
        """Process a single query"""
        cli = AriaCLI(output_format=format)
        cli.context['current_layer'] = layer
        result = cli.process(query)
        cli.output(result)
    
    @app.command()
    def layers():
        """Show all Q0-Q38 layers"""
        cli = AriaCLI()
        cli._show_layers()
    
    @app.command()
    def status():
        """Show system status"""
        cli = AriaCLI()
        cli._show_status()
    
    @app.command()
    def version():
        """Show version information"""
        if console:
            console.print(f"[bold cyan]ARIA CLI[/bold cyan] v{AriaCLI.VERSION}")
            console.print(f"[dim]Q0-Q38 Cognitive Architecture[/dim]")
        else:
            print(f"ARIA CLI v{AriaCLI.VERSION}")
            print("Q0-Q38 Cognitive Architecture")


# =========================================================================
# Agent Commands - aria agent ...
# =========================================================================

# Import agents module
try:
    from .agents import (
        AriaAgent, AgentRegistry, AgentSwarm, AgentMessage,
        MessageType, MessagePriority, AgentCapability, AgentState,
        TaskAgent, ReasoningAgent, CoordinatorAgent, GeneratorAgent,
        create_agent, get_registry,
    )
    from .agent_channels import (
        ChannelManager, DirectChannel, BroadcastChannel,
        get_channel_manager,
    )
    HAS_AGENTS = True
except ImportError:
    HAS_AGENTS = False

agent_app = typer.Typer(
    name="agent",
    help="ARIA Agents - Autonomous AI agents with Q-System integration",
) if typer else None

if agent_app:
    app.add_typer(agent_app, name="agent")
    
    @agent_app.command("list")
    def agent_list():
        """List all registered agents"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        agents = registry.list_agents()
        
        if console:
            table = Table(title="Registered Agents")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="white")
            table.add_column("Q-Layer", style="magenta")
            table.add_column("State", style="green")
            table.add_column("Capabilities", style="dim")
            table.add_column("Messages", style="yellow")
            
            for a in agents:
                state_color = {
                    "IDLE": "green",
                    "BUSY": "yellow",
                    "ERROR": "red",
                    "STOPPED": "dim",
                }.get(a.state.name, "white")
                
                table.add_row(
                    a.agent_id[:16] + "...",
                    a.name,
                    f"Q{a.q_layer.value}",
                    f"[{state_color}]{a.state.name}[/{state_color}]",
                    ", ".join(c[:10] for c in [cap.name for cap in a.capabilities][:3]),
                    str(a.messages_processed),
                )
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(agents)} agents[/dim]")
        else:
            for a in agents:
                print(f"{a.agent_id}: {a.name} (Q{a.q_layer.value}) - {a.state.name}")
    
    @agent_app.command("create")
    def agent_create(
        name: str = typer.Argument(..., help="Agent name"),
        agent_type: str = typer.Option("task", "--type", "-t", help="Agent type: task, reasoning, coordinator, generator"),
        layer: int = typer.Option(None, "--layer", "-l", help="Q-Layer (0-38)"),
        start: bool = typer.Option(False, "--start", "-s", help="Start agent after creation"),
    ):
        """Create a new agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        
        async def _create():
            # Create agent
            kwargs = {}
            if layer is not None:
                kwargs['q_layer'] = QLayer(layer)
            
            agent = create_agent(agent_type, name, **kwargs)
            
            # Register
            registry = get_registry()
            await registry.register(agent)
            
            if start:
                await agent.start()
            
            return agent
        
        try:
            agent = asyncio.run(_create())
            
            if console:
                console.print(Panel(
                    f"[bold green]Agent Created[/bold green]\n\n"
                    f"[cyan]ID:[/cyan] {agent.id}\n"
                    f"[cyan]Name:[/cyan] {agent.name}\n"
                    f"[cyan]Type:[/cyan] {agent_type}\n"
                    f"[cyan]Q-Layer:[/cyan] Q{agent.q_layer.value} ({agent.q_layer.name})\n"
                    f"[cyan]State:[/cyan] {agent.state.name}\n"
                    f"[cyan]Capabilities:[/cyan] {', '.join(c.name for c in agent.capabilities)}",
                    title="🤖 New Agent",
                    border_style="green",
                ))
            else:
                print(f"Created agent: {agent.id}")
        except Exception as e:
            rprint(f"[red]Error creating agent: {e}[/red]")
    
    @agent_app.command("start")
    def agent_start(
        agent_id: str = typer.Argument(..., help="Agent ID or name"),
    ):
        """Start an agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        
        agent = registry.get(agent_id) or registry.get_by_name(agent_id)
        if not agent:
            rprint(f"[red]Agent not found: {agent_id}[/red]")
            return
        
        asyncio.run(agent.start())
        rprint(f"[green]Started agent: {agent.id}[/green]")
    
    @agent_app.command("stop")
    def agent_stop(
        agent_id: str = typer.Argument(..., help="Agent ID or name"),
    ):
        """Stop an agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        
        agent = registry.get(agent_id) or registry.get_by_name(agent_id)
        if not agent:
            rprint(f"[red]Agent not found: {agent_id}[/red]")
            return
        
        asyncio.run(agent.stop())
        rprint(f"[yellow]Stopped agent: {agent.id}[/yellow]")
    
    @agent_app.command("status")
    def agent_status(
        agent_id: str = typer.Argument(..., help="Agent ID or name"),
    ):
        """Get detailed agent status"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        registry = get_registry()
        agent = registry.get(agent_id) or registry.get_by_name(agent_id)
        
        if not agent:
            rprint(f"[red]Agent not found: {agent_id}[/red]")
            return
        
        status = agent.status
        
        if console:
            console.print(Panel(
                f"[cyan]ID:[/cyan] {status.agent_id}\n"
                f"[cyan]Name:[/cyan] {status.name}\n"
                f"[cyan]State:[/cyan] {status.state.name}\n"
                f"[cyan]Q-Layer:[/cyan] Q{status.q_layer.value} ({status.q_layer.name})\n"
                f"[cyan]Capabilities:[/cyan] {', '.join(c.name for c in status.capabilities)}\n"
                f"[cyan]Current Task:[/cyan] {status.current_task or 'None'}\n"
                f"[cyan]Messages Processed:[/cyan] {status.messages_processed}\n"
                f"[cyan]Messages Pending:[/cyan] {status.messages_pending}\n"
                f"[cyan]Uptime:[/cyan] {status.uptime_seconds:.1f}s\n"
                f"[cyan]Last Activity:[/cyan] {status.last_activity or 'Never'}\n"
                f"[cyan]Error:[/cyan] {status.error or 'None'}",
                title=f"🤖 Agent Status: {status.name}",
                border_style="cyan",
            ))
        else:
            print(json.dumps(status.to_dict(), indent=2))
    
    @agent_app.command("send")
    def agent_send(
        recipient: str = typer.Argument(..., help="Recipient agent ID or name"),
        message: str = typer.Argument(..., help="Message content"),
        sender: str = typer.Option("cli", "--from", "-f", help="Sender ID"),
        priority: str = typer.Option("NORMAL", "--priority", "-p", help="Message priority"),
    ):
        """Send a message to an agent"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        registry = get_registry()
        
        agent = registry.get(recipient) or registry.get_by_name(recipient)
        if not agent:
            rprint(f"[red]Agent not found: {recipient}[/red]")
            return
        
        try:
            priority_enum = MessagePriority[priority.upper()]
        except KeyError:
            priority_enum = MessagePriority.NORMAL
        
        msg = AgentMessage(
            type=MessageType.REQUEST,
            sender=sender,
            recipient=agent.id,
            payload={"message": message},
            priority=priority_enum,
        )
        
        asyncio.run(agent.receive(msg))
        rprint(f"[green]Message sent to {agent.name}[/green]")
        rprint(f"[dim]Message ID: {msg.id}[/dim]")
    
    @agent_app.command("types")
    def agent_types():
        """Show available agent types"""
        if console:
            table = Table(title="Agent Types")
            table.add_column("Type", style="cyan")
            table.add_column("Q-Layer", style="magenta")
            table.add_column("Description", style="white")
            table.add_column("Capabilities", style="dim")
            
            types = [
                ("task", "Q23", "Task execution agent", "SHELL_EXECUTION, FILE_OPERATIONS"),
                ("reasoning", "Q10", "Logical reasoning agent", "REASONING, ANALYSIS"),
                ("coordinator", "Q21", "Multi-agent coordinator", "AGENT_COORDINATION, TASK_DECOMPOSITION"),
                ("generator", "Q19", "Content generation agent", "TEXT_GENERATION, CODE_GENERATION"),
            ]
            
            for t in types:
                table.add_row(*t)
            
            console.print(table)
        else:
            print("Agent types: task, reasoning, coordinator, generator")
    
    @agent_app.command("capabilities")
    def agent_capabilities():
        """Show all agent capabilities"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        if console:
            table = Table(title="Agent Capabilities")
            table.add_column("Category", style="cyan")
            table.add_column("Capability", style="white")
            
            categories = {
                "Processing": ["TEXT_GENERATION", "CODE_GENERATION", "ANALYSIS", "SUMMARIZATION", "TRANSLATION"],
                "Data": ["FILE_OPERATIONS", "DATABASE_ACCESS", "WEB_SEARCH", "API_CALLS"],
                "System": ["SHELL_EXECUTION", "PROCESS_MANAGEMENT", "SCHEDULING"],
                "AI/ML": ["EMBEDDING", "CLASSIFICATION", "PREDICTION", "REASONING"],
                "Meta": ["AGENT_COORDINATION", "TASK_DECOMPOSITION", "SELF_IMPROVEMENT"],
            }
            
            for category, caps in categories.items():
                for cap in caps:
                    table.add_row(category, cap)
            
            console.print(table)


# Channel sub-commands
channel_app = typer.Typer(
    name="channel",
    help="Agent communication channels",
) if typer else None

if channel_app and agent_app:
    agent_app.add_typer(channel_app, name="channel")
    
    @channel_app.command("list")
    def channel_list():
        """List all channels"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        manager = get_channel_manager()
        channels = manager.list_channels()
        
        if console:
            table = Table(title="Agent Channels")
            table.add_column("ID", style="cyan")
            table.add_column("Name", style="white")
            table.add_column("Type", style="magenta")
            table.add_column("State", style="green")
            table.add_column("Messages", style="yellow")
            
            for ch in channels:
                state_color = {
                    "OPEN": "green",
                    "CLOSED": "dim",
                    "ERROR": "red",
                }.get(ch["state"], "white")
                
                table.add_row(
                    ch["id"][:20] + "...",
                    ch["name"],
                    ch["type"],
                    f"[{state_color}]{ch['state']}[/{state_color}]",
                    str(ch["metrics"]["messages_sent"]),
                )
            
            console.print(table)
            console.print(f"\n[dim]Total: {len(channels)} channels[/dim]")
        else:
            for ch in channels:
                print(f"{ch['id']}: {ch['name']} ({ch['type']}) - {ch['state']}")
    
    @channel_app.command("create")
    def channel_create(
        name: str = typer.Argument(..., help="Channel name"),
        channel_type: str = typer.Option("direct", "--type", "-t", help="Channel type: direct, broadcast, stream, persistent"),
        agent_a: str = typer.Option(None, "--agent-a", "-a", help="First agent (for direct/stream)"),
        agent_b: str = typer.Option(None, "--agent-b", "-b", help="Second agent (for direct/stream)"),
    ):
        """Create a new channel"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        manager = get_channel_manager()
        
        try:
            if channel_type == "direct":
                if not agent_a or not agent_b:
                    rprint("[red]Direct channel requires --agent-a and --agent-b[/red]")
                    return
                channel = manager.create_direct(name, agent_a, agent_b)
            elif channel_type == "broadcast":
                channel = manager.create_broadcast(name, agent_a)
            elif channel_type == "stream":
                if not agent_a or not agent_b:
                    rprint("[red]Stream channel requires --agent-a and --agent-b[/red]")
                    return
                channel = manager.create_stream(name, agent_a, agent_b)
            elif channel_type == "persistent":
                channel = manager.create_persistent(name)
            else:
                rprint(f"[red]Unknown channel type: {channel_type}[/red]")
                return
            
            asyncio.run(channel.open())
            
            rprint(f"[green]Created channel: {channel.id}[/green]")
            rprint(f"[dim]Type: {channel.type.name}, State: {channel.state.name}[/dim]")
        except Exception as e:
            rprint(f"[red]Error creating channel: {e}[/red]")


# Swarm sub-commands
swarm_app = typer.Typer(
    name="swarm",
    help="Agent swarm coordination",
) if typer else None

if swarm_app and agent_app:
    agent_app.add_typer(swarm_app, name="swarm")
    
    @swarm_app.command("create")
    def swarm_create(
        name: str = typer.Argument(..., help="Swarm name"),
    ):
        """Create a new agent swarm"""
        if not HAS_AGENTS:
            rprint("[red]Agents module not available[/red]")
            return
        
        import asyncio
        
        swarm = AgentSwarm(name)
        asyncio.run(swarm.initialize())
        
        if console:
            console.print(Panel(
                f"[bold green]Swarm Created[/bold green]\n\n"
                f"[cyan]ID:[/cyan] {swarm.id}\n"
                f"[cyan]Name:[/cyan] {swarm.name}\n"
                f"[cyan]Coordinator:[/cyan] {swarm.coordinator.id}\n"
                f"[cyan]Members:[/cyan] 0",
                title="🐝 New Swarm",
                border_style="green",
            ))
        else:
            print(f"Created swarm: {swarm.id}")
    
    @swarm_app.command("status")
    def swarm_status(
        swarm_id: str = typer.Argument(..., help="Swarm ID"),
    ):
        """Get swarm status"""
        rprint("[yellow]Swarm status lookup not yet implemented[/yellow]")
        rprint("[dim]Use: aria agent swarm create <name> to create a swarm[/dim]")


# =========================================================================
# AriaSpace Commands - aria space ...
# =========================================================================

space_app = typer.Typer(
    name="space",
    help="AriaSpace - Personal codespace for phone ↔ computer sync",
) if typer else None

if space_app:
    app.add_typer(space_app, name="space")
    
    @space_app.command("create")
    def space_create(
        name: str = typer.Argument(..., help="Workspace name"),
        remote_host: str = typer.Argument(..., help="SSH host for remote device"),
        remote_path: str = typer.Argument(..., help="Remote directory path"),
        local_path: Optional[str] = typer.Option(None, "--local", "-l", help="Local directory path"),
        description: str = typer.Option("", "--desc", "-d", help="Workspace description"),
    ):
        """Create a new AriaSpace workspace"""
        space = AriaSpace()
        local = local_path or str(Path.home() / "aria-space" / name)
        
        try:
            ws = space.create_workspace(
                name=name,
                local_root=local,
                remote_root=remote_path,
                remote_host=remote_host,
                description=description,
            )
            if console:
                console.print(f"[green]✅ Created workspace '{name}'[/green]")
                console.print(f"   Local:  {ws.local_root}")
                console.print(f"   Remote: {remote_host}:{remote_path}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
            else:
                print(f"Error: {e}")
    
    @space_app.command("create-meta-ai")
    def space_create_meta_ai(
        remote_host: str = typer.Argument(..., help="SSH host for Android device"),
        name: str = typer.Option("meta-ai", "--name", "-n", help="Workspace name"),
    ):
        """Quick setup for Meta AI folder sync"""
        space = AriaSpace()
        try:
            ws = space.create_meta_ai_workspace(remote_host, name=name)
            if console:
                console.print(f"[green]✅ Created Meta AI workspace '{name}'[/green]")
                console.print(f"   Local:  {ws.local_root}")
                console.print(f"   Remote: {remote_host}:/storage/emulated/0/Meta AI")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("list")
    def space_list():
        """List all AriaSpace workspaces"""
        space = AriaSpace()
        workspaces = space.list_workspaces()
        
        if not workspaces:
            if console:
                console.print("[dim]No workspaces configured[/dim]")
            else:
                print("No workspaces configured")
            return
        
        if console:
            table = Table(title="AriaSpace Workspaces")
            table.add_column("Name", style="cyan")
            table.add_column("Local", style="white")
            table.add_column("Remote", style="green")
            table.add_column("Last Sync", style="dim")
            
            for ws in workspaces:
                last_sync = ws.last_sync.strftime("%Y-%m-%d %H:%M") if ws.last_sync else "Never"
                table.add_row(
                    ws.name,
                    str(ws.local_root),
                    f"{ws.remote_host}:{ws.remote_root}",
                    last_sync,
                )
            
            console.print(table)
        else:
            for ws in workspaces:
                print(f"{ws.name}: {ws.local_root} <-> {ws.remote_host}:{ws.remote_root}")
    
    @space_app.command("sync")
    def space_sync(
        name: str = typer.Argument(..., help="Workspace name"),
        direction: str = typer.Option("bidirectional", "--direction", "-d", help="Sync direction: upload, download, bidirectional"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be done"),
    ):
        """Synchronize a workspace"""
        space = AriaSpace()
        
        dir_map = {
            "upload": SyncDirection.UPLOAD,
            "download": SyncDirection.DOWNLOAD,
            "bidirectional": SyncDirection.BIDIRECTIONAL,
            "up": SyncDirection.UPLOAD,
            "down": SyncDirection.DOWNLOAD,
            "both": SyncDirection.BIDIRECTIONAL,
        }
        
        try:
            result = space.sync(name, direction=dir_map.get(direction, SyncDirection.BIDIRECTIONAL), dry_run=dry_run)
            if console and result.success:
                console.print(f"[green]✅ Sync complete[/green]")
            elif not result.success:
                console.print(f"[yellow]⚠️ Sync completed with errors[/yellow]")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("pull")
    def space_pull(name: str = typer.Argument(..., help="Workspace name")):
        """Download from remote to local"""
        space = AriaSpace()
        space.pull(name)
    
    @space_app.command("push")
    def space_push(name: str = typer.Argument(..., help="Workspace name")):
        """Upload from local to remote"""
        space = AriaSpace()
        space.push(name)
    
    @space_app.command("files")
    def space_files(
        name: str = typer.Argument(..., help="Workspace name"),
        path: str = typer.Option("", "--path", "-p", help="Relative path"),
    ):
        """List files in workspace"""
        space = AriaSpace()
        
        try:
            files = space.list_files(name, path)
            
            if console:
                table = Table(title=f"Files in '{name}'")
                table.add_column("Status", style="white", width=10)
                table.add_column("Path", style="cyan")
                table.add_column("Local Size", style="dim", justify="right")
                table.add_column("Remote Size", style="dim", justify="right")
                
                status_icons = {
                    "synced": "[green]✓[/green]",
                    "modified_local": "[yellow]↑[/yellow]",
                    "modified_remote": "[blue]↓[/blue]",
                    "new_local": "[green]+L[/green]",
                    "new_remote": "[blue]+R[/blue]",
                    "conflict": "[red]!![/red]",
                }
                
                for f in files:
                    icon = status_icons.get(f.status.value, "?")
                    table.add_row(
                        icon,
                        f.relative_path,
                        f"{f.local_size:,}" if f.local_size else "-",
                        f"{f.remote_size:,}" if f.remote_size else "-",
                    )
                
                console.print(table)
                console.print(f"\n[dim]Total: {len(files)} files[/dim]")
            else:
                for f in files:
                    print(f"{f.status.value:15} {f.relative_path}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("browse")
    def space_browse(
        name: str = typer.Argument(..., help="Workspace name"),
        path: str = typer.Option("", "--path", "-p", help="Relative path"),
    ):
        """Browse remote directory"""
        space = AriaSpace()
        
        try:
            entries = space.browse_remote(name, path)
            
            if console:
                table = Table(title=f"Remote: {path or '/'}")
                table.add_column("Type", style="dim", width=4)
                table.add_column("Name", style="cyan")
                table.add_column("Size", style="dim", justify="right")
                table.add_column("Modified", style="dim")
                
                for entry in entries:
                    icon = "📁" if entry["is_dir"] else "📄"
                    size = "-" if entry["is_dir"] else f"{entry['size']:,}"
                    table.add_row(icon, entry["name"], size, entry.get("modified", ""))
                
                console.print(table)
            else:
                for entry in entries:
                    print(f"{'d' if entry['is_dir'] else '-'} {entry['name']}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("status")
    def space_status(name: str = typer.Argument(..., help="Workspace name")):
        """Show workspace status"""
        space = AriaSpace()
        
        try:
            status = space.get_status(name)
            
            if console:
                panel_content = (
                    f"[cyan]Workspace:[/cyan] {status['name']}\n"
                    f"[cyan]Local:[/cyan] {status['local_root']}\n"
                    f"[cyan]Remote:[/cyan] {status['remote_root']}\n"
                    f"[cyan]Host:[/cyan] {status['remote_host']}\n"
                    f"[cyan]Connected:[/cyan] {'[green]Yes[/green]' if status['connected'] else '[red]No[/red]'}\n"
                    f"[cyan]Local Files:[/cyan] {status['local_files']}\n"
                    f"[cyan]Last Sync:[/cyan] {status['last_sync'] or 'Never'}\n"
                    f"[cyan]Watching:[/cyan] {'Yes' if status['watching'] else 'No'}"
                )
                console.print(Panel(panel_content, title="Workspace Status"))
            else:
                for k, v in status.items():
                    print(f"{k}: {v}")
        except Exception as e:
            if console:
                console.print(f"[red]❌ Error: {e}[/red]")
    
    @space_app.command("delete")
    def space_delete(
        name: str = typer.Argument(..., help="Workspace name"),
        delete_local: bool = typer.Option(False, "--delete-local", help="Also delete local files"),
    ):
        """Delete a workspace"""
        space = AriaSpace()
        
        if console and not delete_local:
            if not Confirm.ask(f"Delete workspace '{name}'?"):
                return
        
        space.delete_workspace(name, delete_local=delete_local)


# =========================================================================
# Termux Setup Commands - aria termux ...
# =========================================================================

termux_app = typer.Typer(
    name="termux",
    help="Termux device setup and configuration",
) if typer else None

if termux_app:
    app.add_typer(termux_app, name="termux")
    
    @termux_app.command("wizard")
    def termux_wizard():
        """Interactive setup wizard for Termux connection"""
        setup = TermuxSetup()
        setup.wizard()
    
    @termux_app.command("discover")
    def termux_discover(
        network: str = typer.Option("192.168.1", "--network", "-n", help="Network prefix"),
        port: int = typer.Option(8022, "--port", "-p", help="SSH port to scan"),
    ):
        """Discover Termux devices on local network"""
        setup = TermuxSetup()
        devices = setup.discover_devices(network, port)
        
        if console:
            if devices:
                table = Table(title="Discovered Devices")
                table.add_column("IP", style="cyan")
                table.add_column("Port", style="white")
                table.add_column("Hostname", style="green")
                
                for d in devices:
                    table.add_row(d.ip_address, str(d.port), d.hostname)
                
                console.print(table)
            else:
                console.print("[yellow]No devices found[/yellow]")
    
    @termux_app.command("setup-script")
    def termux_script(
        output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    ):
        """Generate Termux setup script"""
        setup = TermuxSetup()
        
        if output:
            path = setup.save_termux_script(output)
            if console:
                console.print(f"[green]Saved to: {path}[/green]")
        else:
            if console:
                console.print(Panel(setup.generate_termux_script(), title="Termux Setup Script"))
            else:
                print(setup.generate_termux_script())
    
    @termux_app.command("add-host")
    def termux_add_host(
        name: str = typer.Argument(..., help="Host alias (e.g., termux-phone)"),
        ip: str = typer.Argument(..., help="IP address"),
        port: int = typer.Option(8022, "--port", "-p", help="SSH port"),
        user: str = typer.Option("u0_a", "--user", "-u", help="Username"),
    ):
        """Add Termux device to SSH config"""
        setup = TermuxSetup()
        setup.append_ssh_config(name, ip, port, user)
        
        if console:
            console.print(f"[green]✅ Added '{name}' to SSH config[/green]")
            console.print(f"[dim]Connect with: ssh {name}[/dim]")
    
    @termux_app.command("test")
    def termux_test(host: str = typer.Argument(..., help="SSH host to test")):
        """Test connection to Termux device"""
        setup = TermuxSetup()
        success, message = setup.test_connection(host)
        
        if console:
            if success:
                console.print(f"[green]✅ {message}[/green]")
                
                # Get device info
                info = setup.get_device_info(host)
                if info:
                    table = Table(title="Device Info")
                    table.add_column("Property", style="cyan")
                    table.add_column("Value", style="white")
                    
                    for k, v in info.items():
                        if v:
                            table.add_row(k.replace("_", " ").title(), v)
                    
                    console.print(table)
            else:
                console.print(f"[red]❌ {message}[/red]")
    
    @termux_app.command("find-meta-ai")
    def termux_find_meta_ai(host: str = typer.Argument(..., help="SSH host")):
        """Find Meta AI folder on device"""
        setup = TermuxSetup()
        
        if console:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
                progress.add_task("Searching for Meta AI folder...", total=None)
                path = setup.find_meta_ai_folder(host)
        else:
            path = setup.find_meta_ai_folder(host)
        
        if path:
            if console:
                console.print(f"[green]✅ Found: {path}[/green]")
            else:
                print(f"Found: {path}")
        else:
            if console:
                console.print("[yellow]Meta AI folder not found[/yellow]")
    
    @termux_app.command("folders")
    def termux_folders(host: str = typer.Argument(..., help="SSH host")):
        """List common Android folders on device"""
        setup = TermuxSetup()
        folders = setup.list_android_folders(host)
        
        if console:
            table = Table(title="Android Folders")
            table.add_column("Name", style="cyan")
            table.add_column("Path", style="white")
            table.add_column("Size", style="dim")
            table.add_column("Status", style="green")
            
            for f in folders:
                status = "✓" if f["exists"] else "✗"
                color = "green" if f["exists"] else "red"
                table.add_row(
                    f["name"],
                    f["path"],
                    f.get("size") or "-",
                    f"[{color}]{status}[/{color}]",
                )
            
            console.print(table)


# =========================================================================
# Files Commands - aria files ...
# =========================================================================

# Import file manager
try:
    from .file_manager import (
        AriaFileManager, get_file_manager,
        FileType, Platform, FileLocation,
    )
    HAS_FILES = True
except ImportError:
    HAS_FILES = False

files_app = typer.Typer(
    name="files",
    help="Aria File Manager - View, update, sync, and organize files",
) if typer else None

if files_app:
    app.add_typer(files_app, name="files")
    
    @files_app.command("env")
    def files_env():
        """Show current environment"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        env = manager.get_environment()
        
        if console:
            console.print(Panel(
                f"[cyan]Platform:[/cyan] {env['platform']}\n"
                f"[cyan]Hostname:[/cyan] {env['hostname']}\n"
                f"[cyan]User:[/cyan] {env['user']}\n"
                f"[cyan]Home:[/cyan] {env['home_dir']}\n"
                f"[cyan]Current:[/cyan] {env['current_dir']}\n"
                f"[cyan]Shell:[/cyan] {env['shell']}\n"
                f"[cyan]Python:[/cyan] {env['python_version']}\n"
                f"[cyan]ARIA:[/cyan] v{env['aria_version']}\n"
                f"[cyan]GUI:[/cyan] {'Yes' if env['has_gui'] else 'No'}\n"
                f"[cyan]SSH:[/cyan] {'Yes' if env['has_ssh'] else 'No'}",
                title="🌍 Environment",
                border_style="cyan",
            ))
        else:
            for k, v in env.items():
                print(f"{k}: {v}")
    
    @files_app.command("list")
    def files_list(
        path: Optional[str] = typer.Argument(None, help="Directory path"),
        pattern: str = typer.Option("*", "--pattern", "-p", help="Glob pattern"),
        recursive: bool = typer.Option(False, "--recursive", "-r", help="List recursively"),
        type_filter: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by type: code, text, image, etc."),
    ):
        """List files in directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        types = [type_filter] if type_filter else None
        files = manager.list_files(path, pattern, recursive, types)
        
        if console:
            table = Table(title=f"Files in {path or '.'}")
            table.add_column("Name", style="cyan")
            table.add_column("Type", style="magenta")
            table.add_column("Size", style="dim")
            table.add_column("Modified", style="dim")
            
            for f in files:
                icon = "📁" if f['is_dir'] else "📄"
                size = "-" if f['is_dir'] else f"{f['size']:,} B"
                mtime = f['modified'][:10] if f['modified'] else "-"
                table.add_row(
                    f"{icon} {f['name']}",
                    f['file_type'],
                    size,
                    mtime,
                )
            
            console.print(table)
            console.print(f"[dim]Total: {len(files)} items[/dim]")
        else:
            for f in files:
                print(f"{'[D]' if f['is_dir'] else '[F]'} {f['name']}")
    
    @files_app.command("remote")
    def files_remote(
        host: str = typer.Argument(..., help="SSH host"),
        path: str = typer.Option("~", "--path", "-p", help="Remote path"),
    ):
        """List files on remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        files = manager.list_remote(host, path)
        
        if not files:
            rprint(f"[yellow]No files found or unable to connect to {host}[/yellow]")
            return
        
        if console:
            table = Table(title=f"Remote: {host}:{path}")
            table.add_column("Name", style="cyan")
            table.add_column("Size", style="dim")
            table.add_column("Permissions", style="dim")
            
            for f in files:
                icon = "📁" if f['is_dir'] else "📄"
                table.add_row(
                    f"{icon} {f['name']}",
                    str(f['size']),
                    f['permissions'],
                )
            
            console.print(table)
    
    @files_app.command("search")
    def files_search(
        query: str = typer.Argument(..., help="Search query"),
        path: Optional[str] = typer.Option(None, "--path", "-p", help="Starting path"),
    ):
        """Search for files"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        files = manager.search(query, path)
        
        if console:
            table = Table(title=f"Search: '{query}'")
            table.add_column("Name", style="cyan")
            table.add_column("Path", style="dim")
            table.add_column("Type", style="magenta")
            
            for f in files[:50]:  # Limit results
                table.add_row(f['name'], f['path'], f['file_type'])
            
            console.print(table)
            console.print(f"[dim]Found: {len(files)} matches[/dim]")
    
    @files_app.command("tree")
    def files_tree(
        path: Optional[str] = typer.Argument(None, help="Root path"),
        depth: int = typer.Option(3, "--depth", "-d", help="Max depth"),
    ):
        """Show directory tree"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        tree = manager.tree(path, depth)
        
        def print_tree(node, prefix="", is_last=True):
            connector = "└── " if is_last else "├── "
            icon = "📁" if node.get('is_dir', True) else "📄"
            console.print(f"{prefix}{connector}{icon} {node['name']}")
            
            children = node.get('children', [])
            for i, child in enumerate(children):
                is_last_child = i == len(children) - 1
                new_prefix = prefix + ("    " if is_last else "│   ")
                print_tree(child, new_prefix, is_last_child)
        
        if console:
            console.print(f"[bold]{tree['name']}[/bold]")
            for i, child in enumerate(tree.get('children', [])):
                print_tree(child, "", i == len(tree.get('children', [])) - 1)
    
    @files_app.command("create")
    def files_create(
        path: str = typer.Argument(..., help="File/directory path"),
        content: str = typer.Option("", "--content", "-c", help="File content"),
        directory: bool = typer.Option(False, "--dir", "-d", help="Create directory"),
    ):
        """Create file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.create(path, content, directory)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("read")
    def files_read(
        path: str = typer.Argument(..., help="File path"),
        lines: int = typer.Option(0, "--lines", "-n", help="Number of lines (0=all)"),
    ):
        """Read file content"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        content, result = manager.read(path)
        
        if result['success']:
            if lines > 0:
                content = '\n'.join(content.split('\n')[:lines])
            
            if console:
                from rich.syntax import Syntax
                ext = Path(path).suffix.lstrip('.')
                lang = ext if ext in ('py', 'js', 'ts', 'json', 'html', 'css', 'md') else 'text'
                syntax = Syntax(content, lang, theme="monokai", line_numbers=True)
                console.print(syntax)
            else:
                print(content)
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("save")
    def files_save(
        path: str = typer.Argument(..., help="File path"),
        content: str = typer.Argument(..., help="Content to save"),
    ):
        """Save content to file"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.save(path, content)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("delete")
    def files_delete(
        path: str = typer.Argument(..., help="File/directory path"),
        recursive: bool = typer.Option(False, "--recursive", "-r", help="Delete recursively"),
        force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    ):
        """Delete file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        if not force:
            confirm = typer.confirm(f"Delete {path}?")
            if not confirm:
                rprint("[yellow]Cancelled[/yellow]")
                return
        
        manager = get_file_manager()
        result = manager.delete(path, recursive)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("copy")
    def files_copy(
        source: str = typer.Argument(..., help="Source path"),
        destination: str = typer.Argument(..., help="Destination path"),
    ):
        """Copy file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.copy(source, destination)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("move")
    def files_move(
        source: str = typer.Argument(..., help="Source path"),
        destination: str = typer.Argument(..., help="Destination path"),
    ):
        """Move file or directory"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.move(source, destination)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("upload")
    def files_upload(
        local_path: str = typer.Argument(..., help="Local file path"),
        host: str = typer.Argument(..., help="Remote SSH host"),
        remote_path: str = typer.Argument(..., help="Remote destination path"),
    ):
        """Upload file to remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        
        if console:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
                progress.add_task(f"Uploading to {host}...", total=None)
                result = manager.upload(local_path, host, remote_path)
        else:
            result = manager.upload(local_path, host, remote_path)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint(f"[dim]Transferred: {result['bytes_transferred']:,} bytes[/dim]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("download")
    def files_download(
        host: str = typer.Argument(..., help="Remote SSH host"),
        remote_path: str = typer.Argument(..., help="Remote file path"),
        local_path: str = typer.Argument(..., help="Local destination path"),
    ):
        """Download file from remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        
        if console:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}")) as progress:
                progress.add_task(f"Downloading from {host}...", total=None)
                result = manager.download(host, remote_path, local_path)
        else:
            result = manager.download(host, remote_path, local_path)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint(f"[dim]Transferred: {result['bytes_transferred']:,} bytes[/dim]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("sync")
    def files_sync(
        local_dir: str = typer.Argument(..., help="Local directory"),
        host: str = typer.Argument(..., help="Remote SSH host"),
        remote_dir: str = typer.Argument(..., help="Remote directory"),
        direction: str = typer.Option("bidirectional", "--direction", "-d", help="upload, download, or bidirectional"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Preview without syncing"),
    ):
        """Sync folder with remote host"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        results = manager.sync(local_dir, host, remote_dir, direction, dry_run)
        
        for result in results:
            if result['success']:
                rprint(f"[green]✅ {result['message']}[/green]")
            else:
                rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("open")
    def files_open(
        path: str = typer.Argument(..., help="File path to open"),
    ):
        """Open file with default application"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.open(path)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("serve")
    def files_serve(
        path: str = typer.Argument(..., help="HTML file or directory to serve"),
        port: int = typer.Option(8080, "--port", "-p", help="Port to serve on"),
        no_browser: bool = typer.Option(False, "--no-browser", help="Don't open browser"),
    ):
        """Serve HTML file locally"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.serve(path, port, not no_browser)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint("[dim]Press Ctrl+C to stop[/dim]")
            try:
                while True:
                    import time
                    time.sleep(1)
            except KeyboardInterrupt:
                manager.stop_server(port)
                rprint("\n[yellow]Server stopped[/yellow]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("route")
    def files_route(
        path: str = typer.Argument(..., help="Local file to serve and route"),
        host: str = typer.Argument(..., help="Remote host to route to"),
        port: int = typer.Option(8080, "--port", "-p", help="Remote port"),
    ):
        """Serve file and route to remote host via SSH tunnel"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.route(path, host, port)
        
        if result['success']:
            rprint(f"[green]✅ {result['message']}[/green]")
            rprint(f"[cyan]Access from {host} at: http://localhost:{port}/[/cyan]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("organize")
    def files_organize(
        source_dir: str = typer.Argument(..., help="Directory to organize"),
        target_dir: Optional[str] = typer.Option(None, "--target", "-t", help="Target directory"),
        by: str = typer.Option("type", "--by", "-b", help="Organize by: type, date, extension"),
        dry_run: bool = typer.Option(False, "--dry-run", help="Preview without moving"),
    ):
        """Organize files into folders"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        results = manager.organize(source_dir, target_dir, by, dry_run)
        
        if console:
            table = Table(title="Organization Results")
            table.add_column("File", style="cyan")
            table.add_column("Destination", style="white")
            table.add_column("Status", style="green")
            
            for result in results:
                status = "✅" if result['success'] else "❌"
                table.add_row(
                    Path(result['source']).name,
                    result['destination'] or "-",
                    status,
                )
            
            console.print(table)
            console.print(f"[dim]{'[DRY RUN] ' if dry_run else ''}Organized {len(results)} files[/dim]")
    
    @files_app.command("verify")
    def files_verify(
        path: str = typer.Argument(..., help="File path to verify"),
    ):
        """Verify file exists and is readable"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        valid, result = manager.verify(path)
        
        if valid:
            rprint(f"[green]✅ {result['message']}[/green]")
        else:
            rprint(f"[red]❌ {result['error']}[/red]")
    
    @files_app.command("message")
    def files_message(
        recipient: str = typer.Argument(..., help="Target device (SSH host) or 'local'"),
        message: str = typer.Argument(..., help="Message content"),
    ):
        """Send message to another device"""
        if not HAS_FILES:
            rprint("[red]File manager not available[/red]")
            return
        
        manager = get_file_manager()
        result = manager.message(recipient, message)
        
        if result.get('success'):
            rprint(f"[green]✅ Message sent to {recipient}[/green]")
        else:
            rprint(f"[red]❌ {result.get('error', 'Failed to send message')}[/red]")


# =============================================================================
# Infinite Storage Commands
# =============================================================================

# Try to import infinite storage
try:
    from .infinite_storage import (
        InfiniteStorage,
        StorageConfig,
        StorageBackend,
        CompressionLevel,
        get_storage,
    )
    HAS_INFINITE_STORAGE = True
except ImportError:
    HAS_INFINITE_STORAGE = False
    InfiniteStorage = None

# Create storage app
storage_app = typer.Typer(
    name="storage",
    help="Infinite Storage - Multi-backend cloud storage with compression & encryption",
) if typer else None

if storage_app:
    app.add_typer(storage_app, name="storage")
    
    @storage_app.command("status")
    def storage_status():
        """Show storage status and statistics"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def check():
            await storage.connect()
            health = await storage.health_check()
            return health
        
        health = asyncio.run(check())
        
        table = Table(title="📦 Infinite Storage Status")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Status", health.get('status', 'unknown'))
        table.add_row("API Available", "✅ Yes" if health.get('api_available') else "❌ No")
        table.add_row("Mode", "API" if health.get('api_available') else "Local Cache")
        
        if health.get('cache_stats'):
            stats = health['cache_stats']
            table.add_row("Cache Size", f"{stats.get('size', 0)} / {stats.get('max_size', 0)}")
            table.add_row("Cache Hit Rate", f"{stats.get('hit_rate', 0)}%")
        
        console.print(table)
    
    @storage_app.command("store")
    def storage_store(
        key: str = typer.Argument(..., help="Storage key"),
        value: str = typer.Argument(..., help="Value to store (or @filename for file)"),
        backend: str = typer.Option("REDIS", "-b", "--backend", help="Backend: REDIS, POSTGRESQL, S3, LOCAL"),
        ttl: int = typer.Option(None, "-t", "--ttl", help="Time-to-live in seconds"),
        no_compress: bool = typer.Option(False, "--no-compress", help="Disable compression"),
        no_encrypt: bool = typer.Option(False, "--no-encrypt", help="Disable encryption"),
    ):
        """Store data in infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        # Check if value is a file reference
        if value.startswith("@"):
            file_path = Path(value[1:])
            if file_path.exists():
                value = file_path.read_text()
            else:
                rprint(f"[red]File not found: {file_path}[/red]")
                return
        
        async def do_store():
            await storage.connect()
            return await storage.store(
                key=key,
                data=value,
                backend=StorageBackend(backend),
                ttl_seconds=ttl,
                use_compression=not no_compress,
                use_encryption=not no_encrypt,
            )
        
        result = asyncio.run(do_store())
        
        if result.success:
            rprint(f"[green]✅ Stored: {key}[/green]")
            rprint(f"   Size: {result.size_bytes} bytes")
            rprint(f"   Backend: {result.backend}")
            rprint(f"   Compressed: {'Yes' if result.compressed else 'No'}")
            rprint(f"   Encrypted: {'Yes' if result.encrypted else 'No'}")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("get")
    def storage_get(
        key: str = typer.Argument(..., help="Storage key"),
        output: str = typer.Option(None, "-o", "--output", help="Output file (optional)"),
        raw: bool = typer.Option(False, "--raw", help="Output raw value without formatting"),
    ):
        """Retrieve data from infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_get():
            await storage.connect()
            return await storage.retrieve(key)
        
        result = asyncio.run(do_get())
        
        if result.success:
            if output:
                # Save to file
                Path(output).write_text(str(result.data))
                rprint(f"[green]✅ Saved to: {output}[/green]")
            elif raw:
                print(result.data)
            else:
                rprint(f"[green]✅ Retrieved: {key}[/green]")
                rprint(f"   From Cache: {'Yes' if result.from_cache else 'No'}")
                console.print(Panel(str(result.data), title=key))
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("delete")
    def storage_delete(
        key: str = typer.Argument(..., help="Storage key to delete"),
        force: bool = typer.Option(False, "-f", "--force", help="Skip confirmation"),
    ):
        """Delete data from infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        if not force:
            confirm = Confirm.ask(f"Delete {key}?")
            if not confirm:
                rprint("Cancelled")
                return
        
        import asyncio
        storage = get_storage()
        
        async def do_delete():
            await storage.connect()
            return await storage.delete(key)
        
        result = asyncio.run(do_delete())
        
        if result.success:
            rprint(f"[green]✅ Deleted: {key}[/green]")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("upload")
    def storage_upload(
        file_path: str = typer.Argument(..., help="File to upload"),
        key: str = typer.Option(None, "-k", "--key", help="Custom storage key"),
        backend: str = typer.Option("S3", "-b", "--backend", help="Backend: REDIS, POSTGRESQL, S3, LOCAL"),
        ttl: int = typer.Option(None, "-t", "--ttl", help="Time-to-live in seconds"),
    ):
        """Upload file to infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_upload():
            await storage.connect()
            return await storage.store_file(
                file_path=file_path,
                key=key,
                backend=StorageBackend(backend),
                ttl_seconds=ttl,
            )
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Uploading...", total=None)
            result = asyncio.run(do_upload())
        
        if result.success:
            rprint(f"[green]✅ Uploaded: {file_path}[/green]")
            rprint(f"   Key: {result.key}")
            rprint(f"   Size: {result.size_bytes} bytes")
            rprint(f"   Backend: {result.backend}")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("download")
    def storage_download(
        key: str = typer.Argument(..., help="Storage key"),
        output: str = typer.Argument(..., help="Output file path"),
    ):
        """Download file from infinite storage"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_download():
            await storage.connect()
            return await storage.download_file(key, output)
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            progress.add_task("Downloading...", total=None)
            result = asyncio.run(do_download())
        
        if result.success:
            rprint(f"[green]✅ Downloaded: {key} → {output}[/green]")
        else:
            rprint(f"[red]❌ Error: {result.error}[/red]")
    
    @storage_app.command("list")
    def storage_list(
        pattern: str = typer.Argument("*", help="Key pattern (e.g., 'file:*')"),
    ):
        """List stored keys"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        import asyncio
        storage = get_storage()
        
        async def do_list():
            await storage.connect()
            return await storage.list_keys(pattern)
        
        keys = asyncio.run(do_list())
        
        if keys:
            table = Table(title=f"🔑 Keys matching '{pattern}'")
            table.add_column("#", style="dim")
            table.add_column("Key", style="cyan")
            
            for i, key in enumerate(keys, 1):
                table.add_row(str(i), key)
            
            console.print(table)
            rprint(f"[dim]Total: {len(keys)} keys[/dim]")
        else:
            rprint("[yellow]No keys found[/yellow]")
    
    @storage_app.command("cache")
    def storage_cache(
        action: str = typer.Argument("stats", help="Action: stats, clear"),
    ):
        """Manage local cache"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        storage = get_storage()
        
        if action == "clear":
            storage.clear_cache()
            rprint("[green]✅ Cache cleared[/green]")
        else:
            # Stats
            storage.print_stats()
    
    @storage_app.command("config")
    def storage_config(
        api_url: str = typer.Option(None, "--api-url", help="Storage API URL"),
        backend: str = typer.Option(None, "--backend", help="Default backend"),
        compression: str = typer.Option(None, "--compression", help="Compression: NONE, FAST, BALANCED, MAXIMUM"),
        encryption: bool = typer.Option(None, "--encryption", help="Enable encryption"),
    ):
        """View or update storage configuration"""
        if not HAS_INFINITE_STORAGE:
            rprint("[red]Infinite storage not available[/red]")
            return
        
        # Show current config
        storage = get_storage()
        config = storage.config
        
        table = Table(title="⚙️ Storage Configuration")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("API URL", config.api_url)
        table.add_row("Default Backend", config.default_backend.value)
        table.add_row("Compression", config.compression.value)
        table.add_row("Encryption", "Enabled" if config.encryption_enabled else "Disabled")
        table.add_row("Cache Enabled", "Yes" if config.cache_enabled else "No")
        table.add_row("Cache Max Size", str(config.cache_max_size))
        table.add_row("Cache TTL", f"{config.cache_ttl_seconds}s")
        table.add_row("Timeout", f"{config.timeout_seconds}s")
        
        console.print(table)
        
        rprint("\n[dim]Set via environment variables:[/dim]")
        rprint("  ARIA_STORAGE_API_URL, ARIA_STORAGE_BACKEND")
        rprint("  ARIA_STORAGE_COMPRESSION, ARIA_STORAGE_ENCRYPTION")


# =============================================================================
# GitHub Automation Commands (F1/M1 Cycle Integration)
# =============================================================================

# Try to import github automation
try:
    from .github_automation import (
        GitHubCLI,
        GitHubAutomation,
        F1CycleEngine,
        M1MasterOrchestrator,
        F1Phase,
        CycleStatus,
        SystemType,
        get_github_cli,
        get_github_automation,
        quick_status,
    )
    HAS_GITHUB_AUTOMATION = True
except ImportError:
    HAS_GITHUB_AUTOMATION = False
    GitHubCLI = None

# Create github app
github_app = typer.Typer(
    name="github",
    help="GitHub Automation with F1/M1 Cycle Integration",
) if typer else None

if github_app:
    app.add_typer(github_app, name="github")
    
    @github_app.command("status")
    def github_status():
        """Show GitHub authentication and repo status"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        
        async def check():
            return await quick_status()
        
        status = asyncio.run(check())
        
        table = Table(title="🐙 GitHub Status")
        table.add_column("Item", style="cyan")
        table.add_column("Status", style="green")
        
        auth_status = "✅ Authenticated" if status.get("authenticated") else "❌ Not authenticated"
        table.add_row("Authentication", auth_status)
        table.add_row("gh CLI", "✅ Available" if status.get("gh_available") else "❌ Not found")
        
        if status.get("repo"):
            repo = status["repo"]
            table.add_row("Repository", repo.get("name", "Unknown"))
            table.add_row("Owner", str(repo.get("owner", {}).get("login", "Unknown")))
            table.add_row("Default Branch", repo.get("defaultBranchRef", {}).get("name", "main"))
        
        console.print(table)
    
    @github_app.command("auth")
    def github_auth(
        web: bool = typer.Option(True, "--web", help="Open browser for authentication"),
        status_only: bool = typer.Option(False, "--status", help="Just show auth status"),
    ):
        """Authenticate with GitHub"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        if status_only:
            result = asyncio.run(gh.auth_status())
            if result.success:
                rprint("[green]✅ Authenticated with GitHub[/green]")
                rprint(f"[dim]{result.stdout}[/dim]")
            else:
                rprint("[red]❌ Not authenticated[/red]")
            return
        
        rprint("[cyan]🔐 Opening browser for GitHub authentication...[/cyan]")
        result = asyncio.run(gh.auth_login(web=web))
        if result.success:
            rprint("[green]✅ Successfully authenticated![/green]")
        else:
            rprint(f"[red]❌ Authentication failed: {result.stderr}[/red]")
    
    @github_app.command("repos")
    def github_repos(
        owner: str = typer.Option(None, "--owner", "-o", help="Repository owner"),
        limit: int = typer.Option(20, "--limit", "-l", help="Max repos to show"),
    ):
        """List GitHub repositories"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching repositories...[/cyan]"):
            result = asyncio.run(gh.repo_list(owner=owner, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        repos = result.parsed_data or []
        
        table = Table(title=f"📁 Repositories ({len(repos)})")
        table.add_column("Name", style="cyan")
        table.add_column("Owner", style="blue")
        table.add_column("Visibility", style="green")
        table.add_column("Updated", style="dim")
        
        for repo in repos:
            table.add_row(
                repo.get("name", ""),
                str(repo.get("owner", {}).get("login", "")),
                repo.get("visibility", ""),
                repo.get("updatedAt", "")[:10] if repo.get("updatedAt") else ""
            )
        
        console.print(table)
    
    @github_app.command("issues")
    def github_issues(
        state: str = typer.Option("open", "--state", "-s", help="Issue state: open, closed, all"),
        limit: int = typer.Option(20, "--limit", "-l", help="Max issues to show"),
    ):
        """List GitHub issues"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching issues...[/cyan]"):
            result = asyncio.run(gh.issue_list(state=state, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        issues = result.parsed_data or []
        
        table = Table(title=f"🔖 Issues ({len(issues)})")
        table.add_column("#", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("State", style="green")
        table.add_column("Author", style="blue")
        
        for issue in issues:
            table.add_row(
                str(issue.get("number", "")),
                issue.get("title", "")[:50],
                issue.get("state", ""),
                str(issue.get("author", {}).get("login", ""))
            )
        
        console.print(table)
    
    @github_app.command("prs")
    def github_prs(
        state: str = typer.Option("open", "--state", "-s", help="PR state: open, closed, merged, all"),
        limit: int = typer.Option(20, "--limit", "-l", help="Max PRs to show"),
    ):
        """List pull requests"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching pull requests...[/cyan]"):
            result = asyncio.run(gh.pr_list(state=state, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        prs = result.parsed_data or []
        
        table = Table(title=f"🔀 Pull Requests ({len(prs)})")
        table.add_column("#", style="cyan")
        table.add_column("Title", style="white")
        table.add_column("State", style="green")
        table.add_column("Branch", style="yellow")
        table.add_column("Author", style="blue")
        
        for pr in prs:
            table.add_row(
                str(pr.get("number", "")),
                pr.get("title", "")[:40],
                pr.get("state", ""),
                pr.get("headRefName", "")[:20],
                str(pr.get("author", {}).get("login", ""))
            )
        
        console.print(table)
    
    @github_app.command("workflows")
    def github_workflows():
        """List GitHub Actions workflows"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching workflows...[/cyan]"):
            result = asyncio.run(gh.workflow_list())
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        workflows = result.parsed_data or []
        
        table = Table(title="⚡ GitHub Workflows")
        table.add_column("ID", style="cyan")
        table.add_column("Name", style="white")
        table.add_column("State", style="green")
        table.add_column("Path", style="dim")
        
        for wf in workflows:
            table.add_row(
                str(wf.get("id", "")),
                wf.get("name", ""),
                wf.get("state", ""),
                wf.get("path", "")
            )
        
        console.print(table)
    
    @github_app.command("runs")
    def github_runs(
        workflow: str = typer.Option(None, "--workflow", "-w", help="Filter by workflow"),
        limit: int = typer.Option(10, "--limit", "-l", help="Max runs to show"),
    ):
        """List recent workflow runs"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        with console.status("[cyan]Fetching workflow runs...[/cyan]"):
            result = asyncio.run(gh.run_list(workflow=workflow, limit=limit))
        
        if not result.success:
            rprint(f"[red]❌ {result.stderr}[/red]")
            return
        
        runs = result.parsed_data or []
        
        table = Table(title="🏃 Workflow Runs")
        table.add_column("ID", style="cyan")
        table.add_column("Workflow", style="white")
        table.add_column("Status", style="yellow")
        table.add_column("Conclusion", style="green")
        
        for run in runs:
            conclusion = run.get("conclusion", "")
            if conclusion == "success":
                conclusion_style = "[green]✅ success[/green]"
            elif conclusion == "failure":
                conclusion_style = "[red]❌ failure[/red]"
            elif conclusion:
                conclusion_style = f"[yellow]{conclusion}[/yellow]"
            else:
                conclusion_style = "[dim]pending[/dim]"
            
            table.add_row(
                str(run.get("databaseId", "")),
                run.get("workflowName", "")[:30],
                run.get("status", ""),
                conclusion_style
            )
        
        console.print(table)
    
    @github_app.command("agent")
    def github_agent(
        description: str = typer.Argument(..., help="Task description for Copilot"),
        base: str = typer.Option(None, "--base", "-b", help="Base branch"),
        follow: bool = typer.Option(False, "--follow", "-f", help="Follow agent logs"),
    ):
        """Create a GitHub Copilot agent task"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint(f"[cyan]🤖 Creating Copilot agent task...[/cyan]")
        result = asyncio.run(gh.agent_task_create(description, base=base, follow=follow))
        
        if result.success:
            rprint("[green]✅ Agent task created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")
    
    # =========================================================================
    # F1 CYCLE COMMANDS
    # =========================================================================
    
    @github_app.command("f1")
    def github_f1(
        target: str = typer.Argument(..., help="Target: file path, issue:N, pr:N"),
        verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed output"),
    ):
        """Run F1 Three-Phase Cycle (Analyze → Optimize → Validate)"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        
        automation = get_github_automation()
        
        # Determine target type
        if target.startswith("issue:"):
            rprint(f"[cyan]🔄 Running F1 cycle on issue #{target.split(':')[1]}...[/cyan]")
            result = asyncio.run(automation.run_f1_on_issue(int(target.split(':')[1])))
        elif target.startswith("pr:"):
            rprint(f"[cyan]🔄 Running F1 cycle on PR #{target.split(':')[1]}...[/cyan]")
            result = asyncio.run(automation.run_f1_on_pr(int(target.split(':')[1])))
        else:
            rprint(f"[cyan]🔄 Running F1 cycle on file: {target}...[/cyan]")
            result = asyncio.run(automation.run_f1_on_file(target))
        
        # Display results
        table = Table(title="🔄 F1 Cycle Results")
        table.add_column("Phase", style="cyan")
        table.add_column("Details", style="white")
        
        table.add_row("System", result.system_id)
        table.add_row("Type", result.system_type.value)
        table.add_row("Status", 
            "[green]✅ Success[/green]" if result.success 
            else "[red]❌ Failed[/red]")
        table.add_row("Duration", f"{result.duration:.2f}s")
        
        if result.improvements:
            table.add_row("Improvements", "\n".join(f"• {i}" for i in result.improvements))
        if result.issues:
            table.add_row("Issues", "\n".join(f"• {i}" for i in result.issues))
        if result.commands_executed:
            table.add_row("Commands", "\n".join(f"$ {c}" for c in result.commands_executed))
        
        console.print(table)
        
        rprint("\n[dim]F1 Phases: ANALYZE → OPTIMIZE → VALIDATE[/dim]")
    
    @github_app.command("m1")
    def github_m1(
        workspace: bool = typer.Option(True, "--workspace/--no-workspace", help="Include workspace files"),
        gh_systems: bool = typer.Option(True, "--github/--no-github", help="Include GitHub systems"),
        max_iter: int = typer.Option(3, "--max-iter", "-i", help="Max iterations"),
    ):
        """Run M1 Master Cycle on all systems"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        from pathlib import Path
        
        automation = get_github_automation()
        automation.m1_orchestrator.max_iterations = max_iter
        
        rprint("[cyan]🌟 Starting M1 Master Cycle...[/cyan]")
        rprint(f"[dim]Include workspace: {workspace}, Include GitHub: {gh_systems}[/dim]")
        rprint(f"[dim]Max iterations: {max_iter}[/dim]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Running M1 cycle...", total=None)
            
            async def run_with_progress():
                return await automation.run_full_cycle(
                    include_workspace=workspace,
                    include_github=gh_systems
                )
            
            result = asyncio.run(run_with_progress())
        
        # Display results
        table = Table(title="🌟 M1 Master Cycle Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        status_text = {
            CycleStatus.SUCCESS: "[green]✅ All Complete[/green]",
            CycleStatus.PARTIAL: "[yellow]⚠️ Partial Success[/yellow]",
            CycleStatus.FAILED: "[red]❌ Failed[/red]",
        }.get(result.status, str(result.status))
        
        table.add_row("Status", status_text)
        table.add_row("Total Systems", str(result.total_systems))
        table.add_row("Completed", str(result.completed_systems))
        table.add_row("Progress", f"{result.progress:.1f}%")
        table.add_row("Iterations", str(result.current_iteration))
        table.add_row("F1 Cycles Run", str(len(result.f1_cycles)))
        
        if result.end_time:
            duration = result.end_time - result.start_time
            table.add_row("Duration", f"{duration:.2f}s")
        
        console.print(table)
        
        # Summary of cycle outcomes
        success_count = sum(1 for c in result.f1_cycles if c.success)
        fail_count = len(result.f1_cycles) - success_count
        
        rprint(f"\n[dim]F1 Cycles: {success_count} succeeded, {fail_count} failed[/dim]")
        rprint("[dim]M1 Master Cycle: Iterates all systems through F1 until complete[/dim]")
    
    @github_app.command("sync")
    def github_sync(
        source: str = typer.Option(None, "--source", "-s", help="Source repository"),
    ):
        """Sync repository with upstream"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint("[cyan]🔄 Syncing repository...[/cyan]")
        result = asyncio.run(gh.repo_sync(source=source))
        
        if result.success:
            rprint("[green]✅ Repository synced successfully![/green]")
            if result.stdout:
                rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Sync failed: {result.stderr}[/red]")
    
    @github_app.command("create-pr")
    def github_create_pr(
        title: str = typer.Argument(..., help="PR title"),
        body: str = typer.Option(None, "--body", "-b", help="PR body"),
        base: str = typer.Option("main", "--base", help="Base branch"),
        draft: bool = typer.Option(False, "--draft", "-d", help="Create as draft"),
        fill: bool = typer.Option(False, "--fill", "-f", help="Fill from commits"),
    ):
        """Create a pull request"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint("[cyan]📝 Creating pull request...[/cyan]")
        result = asyncio.run(gh.pr_create(title=title, body=body, base=base, draft=draft, fill=fill))
        
        if result.success:
            rprint("[green]✅ Pull request created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")
    
    @github_app.command("create-issue")
    def github_create_issue(
        title: str = typer.Argument(..., help="Issue title"),
        body: str = typer.Option(None, "--body", "-b", help="Issue body"),
        labels: str = typer.Option(None, "--labels", "-l", help="Comma-separated labels"),
        assignees: str = typer.Option(None, "--assignees", "-a", help="Comma-separated assignees"),
    ):
        """Create a GitHub issue"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        label_list = labels.split(",") if labels else None
        assignee_list = assignees.split(",") if assignees else None
        
        rprint("[cyan]📝 Creating issue...[/cyan]")
        result = asyncio.run(gh.issue_create(title=title, body=body, labels=label_list, assignees=assignee_list))
        
        if result.success:
            rprint("[green]✅ Issue created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")
    
    @github_app.command("release")
    def github_release(
        tag: str = typer.Argument(..., help="Release tag (e.g., v1.0.0)"),
        title: str = typer.Option(None, "--title", "-t", help="Release title"),
        notes: str = typer.Option(None, "--notes", "-n", help="Release notes"),
        draft: bool = typer.Option(False, "--draft", help="Create as draft"),
        prerelease: bool = typer.Option(False, "--prerelease", help="Mark as prerelease"),
    ):
        """Create a GitHub release"""
        if not HAS_GITHUB_AUTOMATION:
            rprint("[red]GitHub automation not available[/red]")
            return
        
        import asyncio
        gh = get_github_cli()
        
        rprint(f"[cyan]🚀 Creating release {tag}...[/cyan]")
        result = asyncio.run(gh.release_create(
            tag=tag, title=title, notes=notes,
            draft=draft, prerelease=prerelease,
            generate_notes=notes is None
        ))
        
        if result.success:
            rprint("[green]✅ Release created![/green]")
            rprint(f"[dim]{result.stdout}[/dim]")
        else:
            rprint(f"[red]❌ Failed: {result.stderr}[/red]")


# =============================================================================
# TERMINAL F1 MESH COMMANDS
# =============================================================================

try:
    from .terminal_f1_mesh import (
        F1TerminalMesh, TerminalNode, MeshTopology,
        get_mesh, create_terminal, run_f1_between,
        F1TerminalAnalyzer, F1TerminalImprover, F1TerminalValidator
    )
    HAS_TERMINAL_MESH = True
except ImportError:
    HAS_TERMINAL_MESH = False

# Create mesh app
mesh_app = typer.Typer(
    name="mesh",
    help="Terminal-to-Terminal F1 Mesh Network - Self-improving terminal network",
) if typer else None

if mesh_app:
    app.add_typer(mesh_app, name="mesh")
    
    @mesh_app.command("status")
    def mesh_status():
        """Show F1 mesh network status"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        mesh = get_mesh()
        status = mesh.get_status()
        
        # Main status table
        table = Table(title="🔗 F1 Terminal Mesh Status")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Mesh Name", status["name"])
        table.add_row("Topology", status["topology"])
        table.add_row("Terminals", str(status["terminals"]))
        table.add_row("Connections", str(status["connections"]))
        table.add_row("Total Cycles", str(status["total_cycles"]))
        table.add_row("Total Improvements", str(status["total_improvements"]))
        
        console.print(table)
        
        # Terminals table
        if status["terminals_list"]:
            term_table = Table(title="📟 Terminals")
            term_table.add_column("ID", style="dim")
            term_table.add_column("Name", style="cyan")
            term_table.add_column("Shell", style="blue")
            term_table.add_column("F1 Level", style="magenta")
            term_table.add_column("State", style="green")
            term_table.add_column("CWD", style="dim")
            
            # F1 Level names
            f1_level_names = ["BASIC", "CONFIGURED", "OPTIMIZED", "HARDENED", "ADVANCED", "MASTERY"]
            
            for t in status["terminals_list"]:
                state_icon = {
                    "idle": "⏸️",
                    "analyzing": "🔍",
                    "improving": "🔧",
                    "validating": "✅",
                    "error": "❌",
                }.get(t["state"], "❓")
                
                # F1 level display
                level = t.get("f1_level", 0)
                level_name = f1_level_names[min(level, 5)]
                level_display = f"L{level} {level_name}"
                
                term_table.add_row(
                    t["id"],
                    t["name"],
                    t["shell"],
                    level_display,
                    f"{state_icon} {t['state']}",
                    t["cwd"][:35] + "..." if len(t["cwd"]) > 35 else t["cwd"]
                )
            
            console.print(term_table)
        
        # Connections table
        if status["connections_list"]:
            conn_table = Table(title="🔗 Connections")
            conn_table.add_column("Source", style="cyan")
            conn_table.add_column("→", style="dim")
            conn_table.add_column("Target", style="blue")
            conn_table.add_column("Cycles", style="green")
            conn_table.add_column("Success", style="yellow")
            conn_table.add_column("Improvements", style="magenta")
            
            for c in status["connections_list"]:
                conn_table.add_row(
                    c["source"][:8],
                    "F1",
                    c["target"][:8],
                    str(c["cycles"]),
                    c["success_rate"],
                    str(c["improvements"])
                )
            
            console.print(conn_table)
    
    @mesh_app.command("create")
    def mesh_create_terminal(
        name: str = typer.Argument(..., help="Terminal name"),
        shell: str = typer.Option(None, "--shell", "-s", help="Shell type (powershell, bash, zsh)"),
    ):
        """Create a new terminal in the mesh"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        terminal = TerminalNode(name=name, shell=shell)
        mesh = get_mesh()
        mesh.add_terminal(terminal)
        
        rprint(f"[green]✅ Created terminal '{name}' (ID: {terminal.id})[/green]")
        rprint(f"[dim]Shell: {terminal.shell}[/dim]")
        rprint(f"[dim]Capabilities: {len(terminal.capabilities)} detected[/dim]")
        
        # Show connections
        if mesh.connections:
            rprint("\n[cyan]Mesh connections:[/cyan]")
            for conn in mesh.connections.values():
                src = mesh.terminals.get(conn.source_id)
                tgt = mesh.terminals.get(conn.target_id)
                if src and tgt:
                    rprint(f"  {src.name} ──F1──► {tgt.name}")
    
    @mesh_app.command("f1")
    def mesh_f1_cycle(
        source: str = typer.Argument(..., help="Source terminal name or ID"),
        target: str = typer.Argument(..., help="Target terminal name or ID"),
        auto_apply: bool = typer.Option(False, "--auto", "-a", help="Auto-apply safe improvements"),
        force: bool = typer.Option(False, "--force", "-f", help="Force apply ALL improvements"),
    ):
        """Run F1 cycle from source to target terminal"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        import asyncio
        
        mesh = get_mesh()
        
        # Find terminals
        source_term = next(
            (t for t in mesh.terminals.values() if t.name == source or t.id == source),
            None
        )
        target_term = next(
            (t for t in mesh.terminals.values() if t.name == target or t.id == target),
            None
        )
        
        if not source_term:
            rprint(f"[yellow]Creating source terminal '{source}'...[/yellow]")
            source_term = create_terminal(source)
        
        if not target_term:
            rprint(f"[yellow]Creating target terminal '{target}'...[/yellow]")
            target_term = create_terminal(target)
        
        rprint(f"\n[cyan]🔄 Running F1 cycle: {source_term.name} → {target_term.name}[/cyan]")
        if force:
            rprint("[yellow]⚠️  Force mode: ALL improvements with commands will be applied[/yellow]")
        elif auto_apply:
            rprint("[dim]Auto-apply mode: Safe improvements will be applied[/dim]")
        
        with console.status("[cyan]Phase 1: ANALYZE...[/cyan]"):
            result = asyncio.run(mesh.run_f1_cycle(
                source_term.id, target_term.id, 
                auto_apply=auto_apply,
                force_apply=force
            ))
        
        # Results
        status_icon = "✅" if result.success else "❌"
        rprint(f"\n{status_icon} F1 Cycle Complete")
        
        table = Table(title="📊 F1 Cycle Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Duration", f"{result.duration:.2f}s")
        table.add_row("Improvements Found", str(len(result.improvements_found)))
        table.add_row("Improvements Applied", str(len(result.improvements_applied)))
        table.add_row("Validation", "✅ PASSED" if result.validation_passed else "❌ FAILED")
        
        console.print(table)
        
        # Show improvements
        if result.improvements_found:
            imp_table = Table(title="💡 Improvements Found")
            imp_table.add_column("Type", style="blue")
            imp_table.add_column("Description", style="white")
            imp_table.add_column("Priority", style="yellow")
            imp_table.add_column("Applied", style="green")
            
            for imp in result.improvements_found[:10]:
                applied = "✅" if imp.id in result.improvements_applied else "⏸️"
                imp_table.add_row(
                    imp.type.value,
                    imp.description[:50] + "..." if len(imp.description) > 50 else imp.description,
                    str(imp.priority),
                    applied
                )
            
            console.print(imp_table)
        
        # Show F1 level status
        f1_level_names = ["BASIC", "CONFIGURED", "OPTIMIZED", "HARDENED", "ADVANCED", "MASTERY"]
        level = target_term.f1_level
        level_name = f1_level_names[min(level, 5)]
        total_improvements = sum(len(h) for h in target_term.improvement_history.values())
        
        rprint(f"\n📈 [cyan]Target F1 Level:[/cyan] [magenta]L{level} {level_name}[/magenta] ({total_improvements} total improvements)")
        
        if level < 5:
            next_level_name = f1_level_names[level + 1]
            rprint(f"[dim]Next level: L{level + 1} {next_level_name}[/dim]")
    
    @mesh_app.command("run")
    def mesh_run_all(
        iterations: int = typer.Option(5, "--iterations", "-i", help="Max iterations"),
        concurrent: int = typer.Option(3, "--concurrent", "-c", help="Max concurrent cycles"),
    ):
        """Run F1 cycles across entire mesh until stable"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        import asyncio
        
        mesh = get_mesh()
        
        if len(mesh.terminals) < 2:
            rprint("[yellow]Need at least 2 terminals in mesh[/yellow]")
            rprint("Create terminals with: aria mesh create <name>")
            return
        
        rprint(f"\n[cyan]🌐 Running F1 mesh cycle ({len(mesh.terminals)} terminals, {len(mesh.connections)} connections)[/cyan]")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Running mesh cycles...", total=None)
            
            result = asyncio.run(mesh.run_until_stable(
                max_iterations=iterations,
                stability_threshold=2
            ))
        
        # Summary
        rprint(f"\n✨ [green]Mesh cycle complete![/green]")
        
        table = Table(title="📊 Mesh Cycle Summary")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Iterations", str(result["iterations"]))
        table.add_row("Total Cycles", str(result["total_cycles"]))
        table.add_row("Total Improvements", str(result["total_improvements"]))
        table.add_row("Stable", "✅ Yes" if result["stable"] else "🔄 Continuing")
        
        console.print(table)
    
    @mesh_app.command("topology")
    def mesh_set_topology(
        topology: str = typer.Argument(
            "adaptive",
            help="Topology type: ring, star, full_mesh, adaptive"
        ),
    ):
        """Set mesh topology"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        topology_map = {
            "ring": MeshTopology.RING,
            "star": MeshTopology.STAR,
            "full_mesh": MeshTopology.FULL_MESH,
            "full": MeshTopology.FULL_MESH,
            "adaptive": MeshTopology.ADAPTIVE,
        }
        
        if topology.lower() not in topology_map:
            rprint(f"[red]Unknown topology: {topology}[/red]")
            rprint("Options: ring, star, full_mesh, adaptive")
            return
        
        mesh = get_mesh()
        mesh.topology = topology_map[topology.lower()]
        mesh._update_connections()
        
        rprint(f"[green]✅ Topology set to: {mesh.topology.value}[/green]")
        rprint(f"[dim]Connections: {len(mesh.connections)}[/dim]")
    
    @mesh_app.command("demo")
    def mesh_demo():
        """Run a demo of the F1 terminal mesh"""
        if not HAS_TERMINAL_MESH:
            rprint("[red]Terminal mesh not available[/red]")
            return
        
        import asyncio
        from .terminal_f1_mesh import demo
        
        asyncio.run(demo())


# =============================================================================
# Q-FOLDER MESH COMMANDS (Distributed Multi-Directional Folder Network)
# =============================================================================

try:
    from .q_folder_mesh import (
        QMeshNode, QFolderMesh, QMessage, MessageType,
        PortDirection, NodeState, ConnectionState,
        create_mesh_node, get_mesh_status, list_mesh_nodes
    )
    HAS_Q_FOLDER_MESH = True
except ImportError:
    HAS_Q_FOLDER_MESH = False

# Global Q-Folder mesh node
_q_mesh_node: 'QMeshNode' = None

def get_q_node() -> 'QMeshNode':
    """Get or create the global Q-Folder mesh node"""
    global _q_mesh_node
    if _q_mesh_node is None:
        _q_mesh_node = create_mesh_node(name=f"aria-{os.getpid()}")
    return _q_mesh_node


# Create qmesh app for Q-Folder distributed mesh
qmesh_app = typer.Typer(
    name="qmesh",
    help="Q-Folder Mesh Network - Distributed multi-directional folder communication",
) if typer else None

if qmesh_app:
    app.add_typer(qmesh_app, name="qmesh")
    
    @qmesh_app.command("start")
    def qmesh_start(
        name: str = typer.Option(None, "--name", "-n", help="Node name"),
        auto_connect: bool = typer.Option(True, "--auto-connect/--no-auto-connect", help="Auto-connect to peers"),
    ):
        """Start a Q-Folder mesh node in this terminal"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available. Install with: pip install aria-cli[full][/red]")
            return
        
        global _q_mesh_node
        
        if _q_mesh_node and _q_mesh_node._running:
            rprint(f"[yellow]Node already running: {_q_mesh_node.name} ({_q_mesh_node.id})[/yellow]")
            return
        
        # Create node
        node_name = name or f"aria-{os.getpid()}"
        _q_mesh_node = create_mesh_node(name=node_name)
        
        rprint(f"[green]✅ Created Q-Folder mesh node[/green]")
        rprint(f"   [cyan]ID:[/cyan]     {_q_mesh_node.id}")
        rprint(f"   [cyan]Name:[/cyan]   {_q_mesh_node.name}")
        rprint(f"   [cyan]Folder:[/cyan] {_q_mesh_node.folder_path}")
        
        if auto_connect:
            rprint("\n[dim]Discovering peers...[/dim]")
            peers = _q_mesh_node.discover_peers()
            rprint(f"   Found {len(peers)} peer(s)")
            
            if peers:
                connected = _q_mesh_node.auto_connect()
                rprint(f"   Connected to {connected} peer(s)")
        
        # Start background processing
        _q_mesh_node.start()
        rprint("\n[green]🔗 Node is running in background[/green]")
        rprint("[dim]Use 'aria qmesh status' to check status[/dim]")
        rprint("[dim]Use 'aria qmesh send <target> <message>' to send messages[/dim]")
    
    @qmesh_app.command("stop")
    def qmesh_stop():
        """Stop the local Q-Folder mesh node"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        global _q_mesh_node
        
        if not _q_mesh_node:
            rprint("[yellow]No node running[/yellow]")
            return
        
        _q_mesh_node.stop()
        rprint(f"[green]✅ Node stopped: {_q_mesh_node.name}[/green]")
        _q_mesh_node = None
    
    @qmesh_app.command("status")
    def qmesh_status(
        full: bool = typer.Option(False, "--full", "-f", help="Show full topology"),
    ):
        """Show Q-Folder mesh network status"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        # Get mesh-wide status
        mesh_status = get_mesh_status()
        
        # Main status table
        table = Table(title="🌐 Q-Folder Mesh Network Status")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Total Nodes", str(mesh_status["total_nodes"]))
        table.add_row("Active Nodes", str(mesh_status["active_nodes"]))
        table.add_row("Local Nodes", str(mesh_status["local_nodes"]))
        
        console.print(table)
        
        # Local node status
        global _q_mesh_node
        if _q_mesh_node:
            node_status = _q_mesh_node.get_status()
            
            local_table = Table(title="📟 Local Node")
            local_table.add_column("Property", style="cyan")
            local_table.add_column("Value", style="green")
            
            local_table.add_row("ID", node_status["id"])
            local_table.add_row("Name", node_status["name"])
            local_table.add_row("State", node_status["state"])
            local_table.add_row("Peers", f"{node_status['connected']}/{node_status['peers']}")
            local_table.add_row("Routes", str(node_status["routes"]))
            local_table.add_row("Messages Sent", str(node_status["metrics"]["messages_sent"]))
            local_table.add_row("Messages Received", str(node_status["metrics"]["messages_received"]))
            local_table.add_row("Messages Routed", str(node_status["metrics"]["messages_routed"]))
            
            console.print(local_table)
            
            # Port assignments
            if node_status["ports"]:
                port_table = Table(title="🔌 Port Assignments")
                port_table.add_column("Direction", style="blue")
                port_table.add_column("Connected Node", style="green")
                
                for port, peer_id in node_status["ports"].items():
                    port_table.add_row(port.upper(), peer_id)
                
                console.print(port_table)
        else:
            rprint("\n[yellow]No local node running. Start with: aria qmesh start[/yellow]")
        
        # Show all nodes if full mode
        if full and mesh_status["nodes"]:
            nodes_table = Table(title="📡 All Mesh Nodes")
            nodes_table.add_column("ID", style="dim")
            nodes_table.add_column("Name", style="cyan")
            nodes_table.add_column("Host", style="blue")
            nodes_table.add_column("State", style="green")
            nodes_table.add_column("Ports", style="magenta")
            
            for node in mesh_status["nodes"]:
                port_count = len(node.get("ports", {}))
                nodes_table.add_row(
                    node["id"],
                    node["name"],
                    node["host"],
                    node["state"],
                    str(port_count)
                )
            
            console.print(nodes_table)
    
    @qmesh_app.command("nodes")
    def qmesh_nodes():
        """List all nodes in the mesh network"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        nodes = list_mesh_nodes()
        
        if not nodes:
            rprint("[yellow]No nodes found in mesh[/yellow]")
            rprint("[dim]Start a node with: aria qmesh start[/dim]")
            return
        
        table = Table(title=f"📡 Mesh Nodes ({len(nodes)} total)")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="cyan")
        table.add_column("Host", style="blue")
        table.add_column("PID", style="dim")
        table.add_column("State", style="green")
        table.add_column("Capabilities", style="magenta")
        
        for node in nodes:
            state_icon = {
                "idle": "⏸️",
                "connected": "✅",
                "routing": "🔄",
                "discovering": "🔍",
                "offline": "❌",
            }.get(node.get("state", ""), "❓")
            
            caps = node.get("capabilities", [])
            caps_str = ", ".join(caps[:3])
            if len(caps) > 3:
                caps_str += f" +{len(caps)-3}"
            
            table.add_row(
                node["id"],
                node["name"],
                node["host"],
                str(node.get("pid", "?")),
                f"{state_icon} {node.get('state', 'unknown')}",
                caps_str
            )
        
        console.print(table)
    
    @qmesh_app.command("connect")
    def qmesh_connect(
        target: str = typer.Argument(..., help="Target node ID or name"),
        port: str = typer.Option("east", "--port", "-p", help="Port direction (north, south, east, west, up, down)"),
    ):
        """Connect to a peer node"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        global _q_mesh_node
        if not _q_mesh_node:
            rprint("[yellow]No local node running. Start with: aria qmesh start[/yellow]")
            return
        
        # Find target node
        nodes = list_mesh_nodes()
        target_node = next(
            (n for n in nodes if n["id"] == target or n["name"] == target),
            None
        )
        
        if not target_node:
            rprint(f"[red]Node not found: {target}[/red]")
            rprint("[dim]Use 'aria qmesh nodes' to list available nodes[/dim]")
            return
        
        # Parse port direction
        port_map = {
            "north": PortDirection.NORTH, "n": PortDirection.NORTH,
            "south": PortDirection.SOUTH, "s": PortDirection.SOUTH,
            "east": PortDirection.EAST, "e": PortDirection.EAST,
            "west": PortDirection.WEST, "w": PortDirection.WEST,
            "up": PortDirection.UP, "u": PortDirection.UP,
            "down": PortDirection.DOWN, "d": PortDirection.DOWN,
        }
        
        direction = port_map.get(port.lower(), PortDirection.EAST)
        
        from .q_folder_mesh import NodeInfo
        peer_info = NodeInfo.from_dict(target_node)
        
        success = _q_mesh_node.connect_to_peer(peer_info, direction)
        
        if success:
            rprint(f"[green]✅ Connecting to {target_node['name']} via {direction.value} port[/green]")
            rprint("[dim]Handshake in progress...[/dim]")
        else:
            rprint(f"[red]Failed to connect to {target}[/red]")
    
    @qmesh_app.command("send")
    def qmesh_send(
        target: str = typer.Argument(..., help="Target node ID or name (use 'all' for broadcast)"),
        message: str = typer.Argument(..., help="Message to send"),
        command: bool = typer.Option(False, "--command", "-c", help="Send as command instead of data"),
    ):
        """Send a message to another node (or broadcast to all)"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        global _q_mesh_node
        if not _q_mesh_node:
            rprint("[yellow]No local node running. Start with: aria qmesh start[/yellow]")
            return
        
        if target.lower() in ("all", "broadcast", "*"):
            # Broadcast
            msg_id = _q_mesh_node.broadcast_data({"message": message})
            rprint(f"[green]📢 Broadcast sent[/green] (ID: {msg_id})")
        else:
            # Find target
            nodes = list_mesh_nodes()
            target_node = next(
                (n for n in nodes if n["id"] == target or n["name"] == target),
                None
            )
            
            if not target_node:
                # Try sending anyway (might be routed)
                target_id = target
            else:
                target_id = target_node["id"]
            
            if command:
                msg_id = _q_mesh_node.send_command(target_id, message)
                rprint(f"[green]⚡ Command sent to {target}[/green] (ID: {msg_id})")
            else:
                msg_id = _q_mesh_node.send(target_id, message)
                rprint(f"[green]📨 Message sent to {target}[/green] (ID: {msg_id})")
    
    @qmesh_app.command("routes")
    def qmesh_routes():
        """Show routing table"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        global _q_mesh_node
        if not _q_mesh_node:
            rprint("[yellow]No local node running. Start with: aria qmesh start[/yellow]")
            return
        
        topology = _q_mesh_node.get_mesh_topology()
        
        # Routes table
        if topology["routes"]:
            table = Table(title="🗺️ Routing Table")
            table.add_column("Target", style="cyan")
            table.add_column("Next Hop", style="blue")
            table.add_column("Hops", style="green")
            table.add_column("Port", style="magenta")
            
            for route in topology["routes"]:
                table.add_row(
                    route["target"],
                    route["next_hop"],
                    str(route["hops"]),
                    route["port"].upper()
                )
            
            console.print(table)
        else:
            rprint("[yellow]No routes established yet[/yellow]")
            rprint("[dim]Connect to peers to build routing table[/dim]")
        
        # Peers table
        if topology["peers"]:
            peers_table = Table(title="🔗 Connected Peers")
            peers_table.add_column("ID", style="dim")
            peers_table.add_column("Name", style="cyan")
            peers_table.add_column("Port", style="blue")
            peers_table.add_column("State", style="green")
            peers_table.add_column("Sent", style="magenta")
            peers_table.add_column("Received", style="yellow")
            
            for peer in topology["peers"]:
                state_icon = "✅" if peer["state"] == "established" else "⏳"
                peers_table.add_row(
                    peer["id"],
                    peer["name"],
                    peer["port"].upper(),
                    f"{state_icon} {peer['state']}",
                    str(peer["messages_sent"]),
                    str(peer["messages_received"])
                )
            
            console.print(peers_table)
    
    @qmesh_app.command("topology")
    def qmesh_topology():
        """Visualize mesh topology"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        global _q_mesh_node
        if not _q_mesh_node:
            # Show global topology without local node
            nodes = list_mesh_nodes()
            rprint(f"\n[cyan]🌐 Q-Folder Mesh Topology ({len(nodes)} nodes)[/cyan]\n")
            
            for node in nodes:
                ports = node.get("ports", {})
                rprint(f"  📟 {node['name']} ({node['id']})")
                for port, peer in ports.items():
                    rprint(f"     └── {port.upper()} → {peer}")
            
            return
        
        topology = _q_mesh_node.get_mesh_topology()
        
        rprint("\n[cyan]🌐 Q-Folder Mesh Topology (from local node)[/cyan]\n")
        
        # ASCII visualization
        node_name = topology["self"]["name"]
        rprint(f"                    [cyan]NORTH[/cyan]")
        rprint(f"                      │")
        
        # Find neighbors
        north = next((p for p in topology["peers"] if p["port"] == "north"), None)
        south = next((p for p in topology["peers"] if p["port"] == "south"), None)
        east = next((p for p in topology["peers"] if p["port"] == "east"), None)
        west = next((p for p in topology["peers"] if p["port"] == "west"), None)
        
        north_name = north["name"] if north else "---"
        south_name = south["name"] if south else "---"
        east_name = east["name"] if east else "---"
        west_name = west["name"] if west else "---"
        
        rprint(f"                    [{north_name}]")
        rprint(f"                      │")
        rprint(f"  [cyan]WEST[/cyan] ─── [{west_name}] ─── [green][{node_name}][/green] ─── [{east_name}] ─── [cyan]EAST[/cyan]")
        rprint(f"                      │")
        rprint(f"                    [{south_name}]")
        rprint(f"                      │")
        rprint(f"                    [cyan]SOUTH[/cyan]")
        
        rprint(f"\n  [dim]Peers: {len(topology['peers'])} | Routes: {len(topology['routes'])}[/dim]")
    
    @qmesh_app.command("leapfrog")
    def qmesh_leapfrog(
        message: str = typer.Argument(..., help="Message to leapfrog through mesh"),
        hops: int = typer.Option(3, "--hops", "-h", help="Number of hops before destination"),
    ):
        """Send a message that leapfrogs through multiple nodes"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        global _q_mesh_node
        if not _q_mesh_node:
            rprint("[yellow]No local node running. Start with: aria qmesh start[/yellow]")
            return
        
        # Broadcast with leapfrog
        msg_id = _q_mesh_node.broadcast(
            payload={"message": message, "leapfrog": True, "requested_hops": hops},
            msg_type=MessageType.LEAPFROG
        )
        
        rprint(f"[green]🐸 Leapfrog message sent[/green] (ID: {msg_id})")
        rprint(f"[dim]Message will hop through up to {hops} nodes before stopping[/dim]")
    
    @qmesh_app.command("discover")
    def qmesh_discover():
        """Discover and list all peers in the mesh"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        global _q_mesh_node
        if not _q_mesh_node:
            _q_mesh_node = create_mesh_node(name=f"discovery-{os.getpid()}")
        
        with console.status("[cyan]Discovering peers...[/cyan]"):
            peers = _q_mesh_node.discover_peers()
        
        if not peers:
            rprint("[yellow]No peers found in mesh[/yellow]")
            rprint("[dim]Start nodes in other terminals with: aria qmesh start[/dim]")
            return
        
        table = Table(title=f"🔍 Discovered Peers ({len(peers)} found)")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="cyan")
        table.add_column("Host", style="blue")
        table.add_column("State", style="green")
        table.add_column("Stale", style="yellow")
        
        for peer in peers:
            stale = "⚠️ Yes" if peer.is_stale else "✅ No"
            table.add_row(
                peer.id,
                peer.name,
                peer.host,
                peer.state.value,
                stale
            )
        
        console.print(table)
        
        rprint("\n[dim]Connect with: aria qmesh connect <node_id>[/dim]")
    
    @qmesh_app.command("clean")
    def qmesh_clean():
        """Clean up stale nodes and old messages"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        mesh = QFolderMesh()
        cleaned = mesh.cleanup_stale_nodes()
        
        rprint(f"[green]🧹 Cleaned up {cleaned} stale node(s)[/green]")
    
    @qmesh_app.command("run")
    def qmesh_run(
        name: str = typer.Option(None, "--name", "-n", help="Node name"),
        auto_connect: bool = typer.Option(True, "--auto-connect/--no-auto-connect", help="Auto-connect to peers"),
    ):
        """Run a Q-Folder mesh node interactively (keeps running until Ctrl+C)"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        import time as time_module
        
        # Create node
        node_name = name or f"aria-{os.getpid()}"
        node = create_mesh_node(name=node_name)
        
        rprint(f"[green]✅ Q-Folder Mesh Node Started[/green]")
        rprint(f"   [cyan]ID:[/cyan]     {node.id}")
        rprint(f"   [cyan]Name:[/cyan]   {node.name}")
        rprint(f"   [cyan]Folder:[/cyan] {node.folder_path}")
        
        if auto_connect:
            rprint("\n[dim]Discovering peers...[/dim]")
            peers = node.discover_peers()
            rprint(f"   Found {len(peers)} peer(s)")
            
            if peers:
                connected = node.auto_connect()
                rprint(f"   Connected to {connected} peer(s)")
        
        # Start background processing
        node.start()
        
        rprint("\n[green]🔗 Node is running. Press Ctrl+C to stop.[/green]")
        rprint("[dim]Open other terminals and run 'aria qmesh run' to create mesh network[/dim]\n")
        
        try:
            while True:
                status = node.get_status()
                peers_connected = status['connected']
                peers_total = status['peers']
                routes = status['routes']
                sent = status['metrics']['messages_sent']
                recv = status['metrics']['messages_received']
                routed = status['metrics']['messages_routed']
                
                # Update display
                print(f"\r[{node.name}] Peers: {peers_connected}/{peers_total} | Routes: {routes} | Msgs: ↑{sent} ↓{recv} ↔{routed}  ", end="", flush=True)
                
                time_module.sleep(2)
        except KeyboardInterrupt:
            rprint("\n\n[yellow]Stopping node...[/yellow]")
            node.stop()
            rprint(f"[green]✅ Node {node.name} stopped[/green]")
    
    @qmesh_app.command("handshake")
    def qmesh_handshake(
        target: str = typer.Argument(..., help="Target node ID or name"),
    ):
        """Perform explicit handshake with a target node"""
        if not HAS_Q_FOLDER_MESH:
            rprint("[red]Q-Folder mesh not available[/red]")
            return
        
        # Find target node
        nodes = list_mesh_nodes()
        target_node = next(
            (n for n in nodes if n["id"] == target or n["name"] == target),
            None
        )
        
        if not target_node:
            rprint(f"[red]Node not found: {target}[/red]")
            rprint("[dim]Use 'aria qmesh nodes' to list available nodes[/dim]")
            return
        
        # Create temporary node for handshake
        node = create_mesh_node(name=f"handshake-{os.getpid()}")
        
        from .q_folder_mesh import NodeInfo
        peer_info = NodeInfo.from_dict(target_node)
        
        rprint(f"[cyan]🤝 Initiating handshake with {target_node['name']}...[/cyan]")
        
        # Connect via different ports
        for port in [PortDirection.EAST, PortDirection.NORTH, PortDirection.UP]:
            success = node.connect_to_peer(peer_info, port)
            if success:
                rprint(f"   [green]✅ Handshake sent via {port.value} port[/green]")
                break
        
        # Start node briefly to process handshake response
        node.start()
        import time as time_module
        time_module.sleep(3)
        
        # Check if connected
        status = node.get_status()
        if status['connected'] > 0:
            rprint(f"[green]✅ Handshake successful! Connected to {target_node['name']}[/green]")
        else:
            rprint(f"[yellow]⏳ Handshake pending - target node may need to be running[/yellow]")
        
        node.stop()


# =============================================================================
# Q-MESH COMPUTE COMMANDS (Distributed Pipeline Parallel Compute)
# =============================================================================

try:
    from .q_mesh_compute import (
        QComputeNode, ComputePattern, TaskPriority, TaskState,
        create_compute_node
    )
    HAS_COMPUTE = True
except ImportError:
    HAS_COMPUTE = False

# Global compute node
_compute_node: 'QComputeNode' = None

def get_compute_node() -> 'QComputeNode':
    """Get or create the global compute node"""
    global _compute_node
    if _compute_node is None:
        _compute_node = create_compute_node(name=f"compute-{os.getpid()}")
    return _compute_node


# Create compute app
compute_app = typer.Typer(
    name="compute",
    help="Q-Mesh Distributed Compute - Chained pipeline parallel compute across terminals",
) if typer else None

if compute_app:
    app.add_typer(compute_app, name="compute")
    
    @compute_app.command("run")
    def compute_run(
        command: str = typer.Argument(..., help="Shell command to execute"),
        target: str = typer.Option(None, "--target", "-t", help="Target node (default: local)"),
        wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for completion"),
    ):
        """Run a shell command (locally or on a remote node)"""
        if not HAS_COMPUTE:
            rprint("[red]Q-Mesh compute not available[/red]")
            return
        
        import asyncio
        
        node = get_compute_node()
        if not node._running:
            node.auto_connect()
            node.start()
        
        rprint(f"[cyan]⚡ Submitting task...[/cyan]")
        task_id = node.run_command(command, on_node=target)
        rprint(f"   Task ID: {task_id}")
        
        if target:
            rprint(f"   Target: {target}")
        
        if wait:
            rprint("[dim]Waiting for result...[/dim]")
            
            # Wait for result
            import time as time_module
            for _ in range(60):  # Max 60 seconds
                if task_id in node.completed_tasks:
                    result = node.completed_tasks[task_id]
                    break
                time_module.sleep(0.5)
            else:
                rprint("[yellow]⏳ Task still running (use --no-wait to submit without waiting)[/yellow]")
                return
            
            # Show result
            status_icon = "✅" if result.success else "❌"
            rprint(f"\n{status_icon} Task {result.state.value}")
            rprint(f"   Duration: {result.duration:.2f}s")
            rprint(f"   Exit code: {result.exit_code}")
            
            if result.output:
                rprint(f"\n[cyan]Output:[/cyan]")
                console.print(Panel(result.output.strip(), border_style="dim"))
            
            if result.error:
                rprint(f"\n[red]Error:[/red] {result.error}")
    
    @compute_app.command("scatter")
    def compute_scatter(
        command: str = typer.Argument(..., help="Command to scatter to all nodes"),
    ):
        """Scatter a command to ALL nodes in the mesh (parallel execution)"""
        if not HAS_COMPUTE:
            rprint("[red]Q-Mesh compute not available[/red]")
            return
        
        node = get_compute_node()
        if not node._running:
            node.auto_connect()
            node.start()
        
        task_ids = node.scatter(command)
        
        rprint(f"[green]📤 Scattered to {len(task_ids)} nodes[/green]")
        for i, task_id in enumerate(task_ids):
            rprint(f"   [{i+1}] {task_id}")
        
        rprint(f"\n[dim]Results will be collected in ~/.aria/q-mesh/nodes/{node.id}/results/[/dim]")
    
    @compute_app.command("pipeline")
    def compute_pipeline(
        name: str = typer.Argument(..., help="Pipeline name"),
        steps: List[str] = typer.Argument(..., help="Commands to execute in sequence"),
        pattern: str = typer.Option("chain", "--pattern", "-p", help="Pattern: chain, fan_out, map_reduce"),
    ):
        """Create a compute pipeline across the mesh"""
        if not HAS_COMPUTE:
            rprint("[red]Q-Mesh compute not available[/red]")
            return
        
        import asyncio
        
        pattern_map = {
            "chain": ComputePattern.CHAIN,
            "fan_out": ComputePattern.FAN_OUT,
            "fanout": ComputePattern.FAN_OUT,
            "parallel": ComputePattern.FAN_OUT,
            "map_reduce": ComputePattern.MAP_REDUCE,
            "mapreduce": ComputePattern.MAP_REDUCE,
        }
        
        compute_pattern = pattern_map.get(pattern.lower(), ComputePattern.CHAIN)
        
        node = get_compute_node()
        if not node._running:
            node.auto_connect()
            node.start()
        
        rprint(f"[cyan]🔗 Creating {compute_pattern.value} pipeline: {name}[/cyan]")
        rprint(f"   Steps: {len(steps)}")
        rprint(f"   Nodes available: {len(node.peers) + 1}")
        
        chain_id = node.pipeline(name=name, steps=steps, pattern=compute_pattern)
        rprint(f"   Chain ID: {chain_id}")
        
        rprint("\n[dim]Running pipeline...[/dim]")
        
        with console.status("[cyan]Executing...[/cyan]"):
            chain = asyncio.run(node.run_chain(chain_id))
        
        # Results
        status_icon = "✅" if chain.state == TaskState.COMPLETED else "❌"
        rprint(f"\n{status_icon} Pipeline {chain.state.value}")
        rprint(f"   Progress: {chain.progress * 100:.0f}%")
        
        # Show stage results
        table = Table(title="📊 Pipeline Results")
        table.add_column("Stage", style="cyan")
        table.add_column("Task", style="blue")
        table.add_column("Node", style="magenta")
        table.add_column("Status", style="green")
        table.add_column("Duration", style="yellow")
        
        for stage_idx, stage in enumerate(chain.stages):
            for task in stage:
                result = chain.results.get(task.id)
                if result:
                    status = "✅" if result.success else "❌"
                    duration = f"{result.duration:.2f}s"
                else:
                    status = "⏳"
                    duration = "-"
                
                table.add_row(
                    str(stage_idx),
                    task.name,
                    task.target_node or "local",
                    status,
                    duration
                )
        
        console.print(table)
    
    @compute_app.command("map-reduce")
    def compute_mapreduce(
        map_cmd: str = typer.Argument(..., help="Map command (run on each node)"),
        reduce_cmd: str = typer.Argument(..., help="Reduce command (aggregate results)"),
        nodes: int = typer.Option(None, "--nodes", "-n", help="Number of map tasks"),
    ):
        """Run a map-reduce computation across the mesh"""
        if not HAS_COMPUTE:
            rprint("[red]Q-Mesh compute not available[/red]")
            return
        
        import asyncio
        
        node = get_compute_node()
        if not node._running:
            node.auto_connect()
            node.start()
        
        num_nodes = nodes or (len(node.peers) + 1)
        map_commands = [map_cmd] * num_nodes
        
        rprint(f"[cyan]🗺️ Map-Reduce Job[/cyan]")
        rprint(f"   Map tasks: {num_nodes}")
        rprint(f"   Map command: {map_cmd[:50]}...")
        rprint(f"   Reduce command: {reduce_cmd[:50]}...")
        
        chain_id = node.map_reduce(map_commands, reduce_cmd)
        
        with console.status("[cyan]Running map-reduce...[/cyan]"):
            chain = asyncio.run(node.run_chain(chain_id))
        
        status_icon = "✅" if chain.state == TaskState.COMPLETED else "❌"
        rprint(f"\n{status_icon} Map-Reduce {chain.state.value}")
        
        # Show reduce result
        for task_id, result in chain.results.items():
            if "reduce" in chain.chains.get(chain_id, {}).get("name", ""):
                if result.output:
                    rprint(f"\n[cyan]Reduce Output:[/cyan]")
                    console.print(Panel(str(result.output)[:500], border_style="dim"))
    
    @compute_app.command("status")
    def compute_status():
        """Show compute node status"""
        if not HAS_COMPUTE:
            rprint("[red]Q-Mesh compute not available[/red]")
            return
        
        global _compute_node
        if not _compute_node:
            rprint("[yellow]No compute node running. Start with: aria compute run <command>[/yellow]")
            return
        
        status = _compute_node.get_compute_status()
        
        table = Table(title="⚡ Q-Mesh Compute Status")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Node ID", status["id"])
        table.add_row("Node Name", status["name"])
        table.add_row("State", status["state"])
        table.add_row("Connected Peers", f"{status['connected']}/{status['peers']}")
        table.add_row("Active Tasks", str(status["active_tasks"]))
        table.add_row("Queued Tasks", str(status["queued_tasks"]))
        table.add_row("Completed Tasks", str(status["completed_tasks"]))
        table.add_row("Compute Chains", str(status["chains"]))
        table.add_row("Max Concurrent", str(status["max_concurrent"]))
        
        console.print(table)
    
    @compute_app.command("chains")
    def compute_chains():
        """List all compute chains/pipelines"""
        if not HAS_COMPUTE:
            rprint("[red]Q-Mesh compute not available[/red]")
            return
        
        global _compute_node
        if not _compute_node:
            rprint("[yellow]No compute node running[/yellow]")
            return
        
        if not _compute_node.chains:
            rprint("[dim]No chains created yet[/dim]")
            return
        
        table = Table(title="🔗 Compute Chains")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="cyan")
        table.add_column("Pattern", style="blue")
        table.add_column("State", style="green")
        table.add_column("Progress", style="yellow")
        table.add_column("Tasks", style="magenta")
        
        for chain_id, chain in _compute_node.chains.items():
            state_icon = {
                TaskState.PENDING: "⏳",
                TaskState.RUNNING: "🔄",
                TaskState.COMPLETED: "✅",
                TaskState.FAILED: "❌",
            }.get(chain.state, "❓")
            
            table.add_row(
                chain_id,
                chain.name,
                chain.pattern.value,
                f"{state_icon} {chain.state.value}",
                f"{chain.progress * 100:.0f}%",
                f"{chain.completed_tasks}/{chain.total_tasks}"
            )
        
        console.print(table)
    
    @compute_app.command("demo")
    def compute_demo():
        """Run a demo of the distributed compute system"""
        if not HAS_COMPUTE:
            rprint("[red]Q-Mesh compute not available[/red]")
            return
        
        import asyncio
        from .q_mesh_compute import demo
        
        asyncio.run(demo())


# =============================================================================
# HYPERCUBE COMMANDS - 64-Directional Agent Mesh
# =============================================================================

# Check for hypercube module
try:
    from .q_hypercube_mesh import (
        HyperCubeOrchestrator, HyperAgent, HyperFolder,
        MergeStrategy, AgentState, ChainedRun,
        create_hypercube_mesh, demo_parallel_run, demo_chained_run
    )
    HAS_HYPERCUBE = True
except ImportError:
    HAS_HYPERCUBE = False


if typer:
    hypercube_app = typer.Typer(
        name="hypercube",
        help="64-Directional Hypercube Agent Mesh - Parallel Chained Runs",
    )
else:
    hypercube_app = None

if hypercube_app:
    app.add_typer(hypercube_app, name="hypercube")
    
    @hypercube_app.command("init")
    def hypercube_init():
        """Initialize 64-agent hypercube mesh folder structure"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        orch = create_hypercube_mesh()
        
        rprint(Panel.fit(
            f"[green]✅ 64-Agent Hypercube Mesh Initialized[/green]\n\n"
            f"[cyan]Root:[/cyan] {orch.mesh_root}\n"
            f"[cyan]Agents:[/cyan] 64 folders created (agent_01 - agent_64)\n"
            f"[cyan]Ports:[/cyan] Each agent has 64 input ports\n\n"
            f"[dim]Each agent can broadcast to all 64 agents simultaneously[/dim]",
            title="🔷 Hypercube Mesh",
            border_style="cyan"
        ))
    
    @hypercube_app.command("status")
    def hypercube_status():
        """Show hypercube mesh status"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        orch = create_hypercube_mesh()
        status = orch.get_status()
        
        # Count states
        state_counts = {}
        for agent_id, state in status["agent_states"].items():
            state_counts[state] = state_counts.get(state, 0) + 1
        
        table = Table(title="🔷 Hypercube Mesh Status")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Mesh Root", str(status["mesh_root"]))
        table.add_row("Total Agents", str(status["total_agents"]))
        table.add_row("Active Chains", str(status["active_chains"]))
        table.add_row("Completed Chains", str(status["completed_chains"]))
        
        for state, count in state_counts.items():
            table.add_row(f"Agents {state}", str(count))
        
        console.print(table)
    
    @hypercube_app.command("agents")
    def hypercube_agents():
        """List all 64 agents and their states"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        orch = create_hypercube_mesh()
        
        table = Table(title="🔷 64-Agent Hypercube Mesh")
        table.add_column("ID", style="dim", width=4)
        table.add_column("Folder", style="cyan")
        table.add_column("State", style="green")
        table.add_column("Ports", style="blue")
        
        for i in range(1, 65):
            agent = orch.agents[i]
            folder_name = f"agent_{i:02d}"
            state = agent.state.value
            ports = "64 ← → 64"  # All-to-all
            table.add_row(str(i), folder_name, state, ports)
        
        console.print(table)
        
        rprint("\n[dim]Each agent can send to/receive from all 64 agents simultaneously[/dim]")
    
    @hypercube_app.command("scatter")
    def hypercube_scatter(
        message: str = typer.Argument(..., help="Message to scatter to all agents"),
    ):
        """Scatter a message to all 64 agents"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        import asyncio
        
        orch = create_hypercube_mesh()
        
        rprint(f"[cyan]📤 Scattering to all 64 agents...[/cyan]")
        
        # Scatter echo task
        def work_gen(agent_id):
            from .q_hypercube_mesh import AgentWork
            return AgentWork(
                agent_id=agent_id,
                task_id=f"scatter_{agent_id:02d}",
                command="echo",
                task_type="echo",
                payload={"message": message, "from_user": True},
                chain_id="user_scatter",
                stage=0,
            )
        
        from .q_hypercube_mesh import MergeStrategy
        result = asyncio.run(orch.scatter_to_all(work_gen, MergeStrategy.ALL))
        
        rprint(f"\n[green]✅ Scattered to {result.total_agents} agents[/green]")
        rprint(f"   Successful: {result.successful_agents}")
        rprint(f"   Failed: {result.failed_agents}")
        rprint(f"   Success rate: {result.success_rate*100:.1f}%")
    
    @hypercube_app.command("parallel")
    def hypercube_parallel(
        command: str = typer.Argument(..., help="Command to run on all agents"),
        task_type: str = typer.Option("shell", "--type", "-t", help="Task type: shell, python, echo"),
    ):
        """Run a command in parallel across all 64 agents"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        import asyncio
        import time
        
        orch = create_hypercube_mesh()
        
        rprint(f"[cyan]🚀 Running in parallel across 64 agents...[/cyan]")
        rprint(f"   Command: {command}")
        rprint(f"   Type: {task_type}\n")
        
        def work_gen(agent_id):
            from .q_hypercube_mesh import AgentWork
            return AgentWork(
                agent_id=agent_id,
                task_id=f"parallel_{agent_id:02d}_{int(time.time())}",
                command=command,
                task_type=task_type,
                payload={"agent_id": agent_id},
                chain_id="parallel_run",
                stage=0,
            )
        
        from .q_hypercube_mesh import MergeStrategy
        start = time.time()
        result = asyncio.run(orch.scatter_to_all(work_gen, MergeStrategy.ALL))
        duration = time.time() - start
        
        rprint(f"[green]✅ Parallel execution complete in {duration:.3f}s[/green]")
        rprint(f"   Total: {result.total_agents} agents")
        rprint(f"   Successful: {result.successful_agents}")
        rprint(f"   Failed: {result.failed_agents}")
        
        # Show sample results
        if result.merged_output:
            rprint("\n[cyan]Sample outputs (first 3 agents):[/cyan]")
            for agent_id in range(1, 4):
                output = result.merged_output.get(agent_id, {})
                if isinstance(output, dict):
                    rprint(f"   Agent {agent_id:02d}: {json.dumps(output)[:80]}...")
                else:
                    rprint(f"   Agent {agent_id:02d}: {str(output)[:80]}...")
    
    @hypercube_app.command("chain")
    def hypercube_chain(
        stages: int = typer.Option(3, "--stages", "-s", help="Number of stages in chain"),
    ):
        """Run a multi-stage chained parallel run"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        import asyncio
        import time
        
        orch = create_hypercube_mesh()
        
        rprint(f"[cyan]⛓️ Running {stages}-stage chained parallel run...[/cyan]")
        rprint(f"   Each stage: 64 agents in parallel")
        rprint(f"   Between stages: merge → forward\n")
        
        # Build stage definitions
        stage_defs = []
        for i in range(stages):
            stage_defs.append({
                "name": f"Stage {i+1}",
                "command": f"result = {{'stage': {i}, 'agent': agent_id, 'value': agent_id * ({i}+1)}}",
                "task_type": "python",
                "merge_strategy": "all",
                "payload": {"stage_num": i},
            })
        
        start = time.time()
        chain = asyncio.run(orch.run_chain("user_chain", stage_defs))
        duration = time.time() - start
        
        rprint(f"\n[green]✅ Chained run complete in {duration:.3f}s[/green]")
        rprint(f"   Chain ID: {chain.id}")
        rprint(f"   Stages: {chain.total_stages}")
        rprint(f"   State: {chain.state.value}")
        
        # Show stage results
        rprint("\n[cyan]Stage Results:[/cyan]")
        for stage_num, stage_result in chain.stage_results.items():
            rprint(f"   Stage {stage_num + 1}: {stage_result.successful_agents}/64 successful")
    
    @hypercube_app.command("demo")
    def hypercube_demo():
        """Run demo of 64-directional hypercube mesh"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        import asyncio
        
        rprint(Panel.fit(
            "[bold cyan]64-DIRECTIONAL HYPERCUBE MESH DEMO[/bold cyan]\n\n"
            "This demo shows:\n"
            "1. Parallel scatter to all 64 agents\n"
            "2. Simultaneous execution across all agents\n"
            "3. Result merge and aggregation\n"
            "4. Multi-stage chained pipeline",
            title="🔷 Hypercube Demo",
            border_style="cyan"
        ))
        
        rprint("\n[cyan]Part 1: Parallel Run[/cyan]")
        asyncio.run(demo_parallel_run())
        
        rprint("\n[cyan]Part 2: Chained Run[/cyan]")
        asyncio.run(demo_chained_run())
        
        rprint("\n[green]✅ Demo complete![/green]")
    
    @hypercube_app.command("broadcast")
    def hypercube_broadcast(
        from_agent: int = typer.Argument(..., help="Source agent ID (1-64)"),
        message: str = typer.Argument(..., help="Message to broadcast"),
    ):
        """Broadcast from one agent to all 63 others"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        if not 1 <= from_agent <= 64:
            rprint("[red]Agent ID must be 1-64[/red]")
            return
        
        orch = create_hypercube_mesh()
        agent = orch.agents[from_agent]
        
        chain_id = agent.broadcast(
            payload={"message": message, "type": "user_broadcast"},
            chain_id=None,
            stage=0,
            requires_merge=True,
        )
        
        rprint(f"[green]✅ Broadcast sent from Agent {from_agent:02d} to all 63 agents[/green]")
        rprint(f"   Chain ID: {chain_id}")
        rprint(f"   Messages written: 63")
    
    @hypercube_app.command("topology")
    def hypercube_topology():
        """Show hypercube mesh topology visualization"""
        if not HAS_HYPERCUBE:
            rprint("[red]Hypercube mesh not available[/red]")
            return
        
        # ASCII visualization of 8x8 grid
        topology = """
┌───────────────────────────────────────────────────────────────────────────────┐
│                        64-DIRECTIONAL HYPERCUBE MESH                          │
│                                                                               │
│    ┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐  ┌────┐           │
│    │ 01 │══│ 02 │══│ 03 │══│ 04 │══│ 05 │══│ 06 │══│ 07 │══│ 08 │           │
│    └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘           │
│      ║║      ║║      ║║      ║║      ║║      ║║      ║║      ║║              │
│    ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐           │
│    │ 09 │══│ 10 │══│ 11 │══│ 12 │══│ 13 │══│ 14 │══│ 15 │══│ 16 │           │
│    └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘           │
│      ║║      ║║      ║║      ║║      ║║      ║║      ║║      ║║              │
│    ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐           │
│    │ 17 │══│ 18 │══│ 19 │══│ 20 │══│ 21 │══│ 22 │══│ 23 │══│ 24 │           │
│    └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘           │
│      ║║      ║║      ║║      ║║      ║║      ║║      ║║      ║║              │
│    ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐           │
│    │ 25 │══│ 26 │══│ 27 │══│ 28 │══│ 29 │══│ 30 │══│ 31 │══│ 32 │           │
│    └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘           │
│      ║║      ║║      ║║      ║║      ║║      ║║      ║║      ║║              │
│    ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐           │
│    │ 33 │══│ 34 │══│ 35 │══│ 36 │══│ 37 │══│ 38 │══│ 39 │══│ 40 │           │
│    └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘           │
│      ║║      ║║      ║║      ║║      ║║      ║║      ║║      ║║              │
│    ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐           │
│    │ 41 │══│ 42 │══│ 43 │══│ 44 │══│ 45 │══│ 46 │══│ 47 │══│ 48 │           │
│    └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘           │
│      ║║      ║║      ║║      ║║      ║║      ║║      ║║      ║║              │
│    ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐           │
│    │ 49 │══│ 50 │══│ 51 │══│ 52 │══│ 53 │══│ 54 │══│ 55 │══│ 56 │           │
│    └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘  └─┬┬─┘           │
│      ║║      ║║      ║║      ║║      ║║      ║║      ║║      ║║              │
│    ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐  ┌─┴┴─┐           │
│    │ 57 │══│ 58 │══│ 59 │══│ 60 │══│ 61 │══│ 62 │══│ 63 │══│ 64 │           │
│    └────┘  └────┘  └────┘  └────┘  └────┘  └────┘  └────┘  └────┘           │
│                                                                               │
│    ══ = Bidirectional port connection (each agent connects to all 64)       │
│    Every agent can broadcast to ALL other agents simultaneously              │
└───────────────────────────────────────────────────────────────────────────────┘
"""
        rprint(topology)
        
        rprint("\n[cyan]Execution Flow:[/cyan]")
        rprint("  1. Agent 1 broadcasts task → 64 inbox folders")
        rprint("  2. Agents 1-64 execute in PARALLEL")
        rprint("  3. Results MERGE at barrier")
        rprint("  4. Combined output → next stage (chained)")


# =============================================================================
# SYMBOLIC PROTOCOL COMMANDS (Q-SYMBOLIC G10QR)
# =============================================================================

# Try to import symbolic protocol
try:
    from .q_symbolic_protocol import (
        SymbolicProtocol,
        QDatabase,
        QExpansionEngine,
        G10QR,
        MicroMessage,
        SymbolicDictionary,
    )
    from .symbolic_hypercube import SymbolicHypercube, create_symbolic_cli
    HAS_SYMBOLIC = True
except ImportError:
    HAS_SYMBOLIC = False

if typer and HAS_SYMBOLIC:
    symbolic_app = typer.Typer(
        name="symbolic",
        help="🔷 Q-Symbolic Protocol - Ultra-Compact Agent Messaging",
        no_args_is_help=True,
    )
else:
    symbolic_app = None

if symbolic_app:
    app.add_typer(symbolic_app, name="symbolic")
    
    @symbolic_app.command("demo")
    def symbolic_demo():
        """Run Q-Symbolic Protocol demonstration"""
        if not HAS_SYMBOLIC:
            rprint("[red]Symbolic protocol not available[/red]")
            return
        
        mesh = SymbolicHypercube()
        mesh.demo()
    
    @symbolic_app.command("encode")
    def symbolic_encode(
        message: str = typer.Argument(..., help="Message to encode (JSON or text)"),
        format: str = typer.Option("g10qr", "-f", "--format", help="Format: full, symbolic, g10qr, micro"),
    ):
        """Encode a message using Q-Symbolic Protocol"""
        try:
            msg_dict = json.loads(message)
        except json.JSONDecodeError:
            # Treat as simple command
            msg_dict = {"action": "execute", "command": message}
        
        mesh = SymbolicHypercube()
        encoded = mesh.encode_message(msg_dict, format)
        
        rprint(f"\n[cyan]🔷 Encoded Message ({format.upper()}):[/cyan]")
        rprint(f"   Original: {encoded.original_size} bytes")
        rprint(f"   Compressed: {encoded.compressed_size} bytes")
        rprint(f"   Ratio: [green]{encoded.compression_ratio*100:.1f}% reduction[/green]")
        
        if format == "symbolic":
            rprint(f"   Content: [yellow]{encoded.raw_bytes.decode('utf-8')}[/yellow]")
        else:
            hex_preview = encoded.raw_bytes.hex()
            if len(hex_preview) > 60:
                hex_preview = hex_preview[:60] + "..."
            rprint(f"   Hex: [dim]{hex_preview}[/dim]")
    
    @symbolic_app.command("decode")
    def symbolic_decode(
        hex_data: str = typer.Argument(..., help="Hex-encoded message to decode"),
        format: str = typer.Option("g10qr", "-f", "--format", help="Format: symbolic, g10qr, micro"),
        expand: bool = typer.Option(True, "--expand/--no-expand", help="Run Q-layer expansion"),
    ):
        """Decode a symbolic message with Q-expansion"""
        from .symbolic_hypercube import SymbolicMessage
        
        mesh = SymbolicHypercube()
        
        # Convert hex to bytes
        try:
            raw_bytes = bytes.fromhex(hex_data)
        except ValueError:
            # Maybe it's already symbolic text
            raw_bytes = hex_data.encode('utf-8')
            format = "symbolic"
        
        symbolic_msg = SymbolicMessage(
            raw_bytes=raw_bytes,
            format=format,
            original_size=0,
            compressed_size=len(raw_bytes),
            source_agent=0,
            target_agent=0,
        )
        
        decoded = mesh.decode_message(symbolic_msg, expand=expand)
        
        rprint(f"\n[cyan]🔓 Decoded Message:[/cyan]")
        
        # Filter out internal fields for display
        display = {k: v for k, v in decoded.items() if not k.startswith("_")}
        rprint(f"   {json.dumps(display, indent=2)}")
        
        if expand and "_q_expansion" in decoded:
            exp = decoded["_q_expansion"]
            rprint(f"\n[cyan]🔄 Q-Layer Expansion:[/cyan]")
            rprint(f"   Layers: {exp.get('layers_traversed', 0)}")
            rprint(f"   Description: [green]{exp.get('description', '')}[/green]")
            rprint(f"   Ready: {exp.get('ready', False)}")
    
    @symbolic_app.command("stats")
    def symbolic_stats():
        """Show Q-Database statistics"""
        q_db = QDatabase()
        stats = q_db.get_stats()
        
        rprint("\n[cyan]📊 Q-Database Statistics:[/cyan]")
        rprint(f"   Version: {stats.get('version', 'unknown')}")
        rprint(f"   Base Symbols: {stats.get('base_symbols', 0)}")
        rprint(f"   Learned Symbols: {stats.get('learned_symbols', 0)}")
        rprint(f"   Total Encodings: {stats.get('total_encodings', 0)}")
        
        if stats.get('top_used'):
            rprint("\n[cyan]🔝 Top Used:[/cyan]")
            for term, count in stats['top_used'][:5]:
                rprint(f"   {term}: {count}")
    
    @symbolic_app.command("dictionary")
    def symbolic_dictionary():
        """Show symbolic substitution dictionary"""
        d = SymbolicDictionary()
        
        rprint("\n[cyan]📖 Symbolic Dictionary v" + d.VERSION + "[/cyan]")
        
        # Actions
        rprint("\n[yellow]Actions:[/yellow]")
        for word, symbol in list(d.ACTIONS.items())[:10]:
            rprint(f"   {word:12} → {symbol}")
        rprint(f"   ... and {len(d.ACTIONS) - 10} more")
        
        # Priorities
        rprint("\n[yellow]Priorities:[/yellow]")
        for word, symbol in d.PRIORITIES.items():
            rprint(f"   {word:12} → {symbol}")
        
        # Types
        rprint("\n[yellow]Types:[/yellow]")
        for word, symbol in d.TYPES.items():
            rprint(f"   {word:12} → {symbol}")
        
        # States
        rprint("\n[yellow]States:[/yellow]")
        for word, symbol in list(d.STATES.items())[:5]:
            rprint(f"   {word:12} → {symbol}")
        
        rprint("\n[dim]Use 'aria symbolic encode <msg>' to see compression in action[/dim]")
    
    @symbolic_app.command("parallel")
    def symbolic_parallel(
        command: str = typer.Argument("echo Hello from symbolic agent!", help="Command to run"),
        format: str = typer.Option("micro", "-f", "--format", help="Message format"),
    ):
        """Run command on all 64 agents with symbolic encoding"""
        import asyncio
        
        mesh = SymbolicHypercube()
        mesh.init()
        
        task = {
            "action": "execute",
            "type": "echo",
            "command": command,
        }
        
        with console.status("[cyan]Running on 64 agents...") as status:
            result = asyncio.run(mesh.run_parallel_symbolic(task, format))
        
        rprint(f"\n[green]✅ Parallel Execution Complete:[/green]")
        rprint(f"   Agents: {result['successful']}/{result['total_agents']}")
        rprint(f"   Time: {result['total_time']:.3f}s")
        rprint(f"   Format: {result['message_format']}")
        rprint(f"   Message Size: {result['message_size']} bytes")
        rprint(f"   Compression: [cyan]{result['compression_ratio']}[/cyan]")
    
    @symbolic_app.command("chain")
    def symbolic_chain(
        stages: int = typer.Option(3, "-s", "--stages", help="Number of stages"),
        format: str = typer.Option("g10qr", "-f", "--format", help="Message format"),
    ):
        """Run multi-stage chained pipeline with symbolic messaging"""
        import asyncio
        
        mesh = SymbolicHypercube()
        mesh.init()
        
        # Create stages
        stage_defs = []
        for i in range(stages):
            stage_defs.append({
                "action": "execute",
                "type": "echo",
                "command": f"Stage {i+1} on agent {{agent_id}}",
                "priority": "high" if i == 0 else "normal",
            })
        
        with console.status(f"[cyan]Running {stages}-stage symbolic chain...") as status:
            result = asyncio.run(mesh.run_chain_symbolic(stage_defs, format))
        
        rprint(f"\n[green]✅ Chained Pipeline Complete:[/green]")
        rprint(f"   Chain ID: {result['chain_id']}")
        rprint(f"   Stages: {result['total_stages']}")
        rprint(f"   Total Time: {result['total_time']:.3f}s")
        rprint(f"   Format: {result['message_format']}")
        
        # Stats
        stats = result.get('stats', {})
        if stats:
            rprint(f"\n[cyan]📊 Protocol Stats:[/cyan]")
            rprint(f"   Messages Encoded: {stats.get('messages_encoded', 0)}")
            rprint(f"   Overall Compression: {stats.get('overall_compression', 'N/A')}")
            rprint(f"   Q-Expansions: {stats.get('expansions_performed', 0)}")
    
    @symbolic_app.command("expand")
    def symbolic_expand(
        message: str = typer.Argument(..., help="Symbolic message to expand (e.g., '§X:T=P:P=H')"),
    ):
        """Expand a symbolic message through Q0-Q38 layers"""
        q_db = QDatabase()
        engine = QExpansionEngine(q_db)
        
        rprint(f"\n[cyan]🔄 Expanding through Q0-Q38 layers...[/cyan]")
        rprint(f"   Input: [yellow]{message}[/yellow]\n")
        
        result = engine.expand(message)
        
        # Show expansion path
        for layer_name in result["metadata"]["layers_traversed"]:
            layer_data = result["expansions"].get(layer_name, {})
            summary = str(layer_data)[:60] + "..." if len(str(layer_data)) > 60 else str(layer_data)
            rprint(f"   [dim]{layer_name}[/dim]: {summary}")
        
        # Final result
        final = result.get("final", {})
        rprint(f"\n[green]✅ Final Result:[/green]")
        rprint(f"   Description: {final.get('description', '')}")
        rprint(f"   Ready: {final.get('ready', False)}")
        rprint(f"   Layers Used: {final.get('layers_used', 0)}")
        
        if final.get("plan"):
            rprint(f"\n[cyan]📋 Execution Plan:[/cyan]")
            for key, value in final["plan"].items():
                rprint(f"   {key}: {value}")
    
    @symbolic_app.command("benchmark")
    def symbolic_benchmark(
        iterations: int = typer.Option(100, "-n", "--iterations", help="Number of iterations"),
    ):
        """Benchmark encoding/decoding performance"""
        import time
        
        protocol = SymbolicProtocol()
        
        # Test message
        message = {
            "action": "execute",
            "type": "python",
            "priority": "high",
            "agent_id": 42,
            "target_agent": 17,
            "chain_id": "test123",
            "stage": 3,
            "command": "result = agent_id * 2",
        }
        
        rprint(f"\n[cyan]⚡ Benchmarking {iterations} iterations...[/cyan]\n")
        
        formats = ["symbolic", "g10qr", "micro"]
        results = {}
        
        for fmt in formats:
            # Encode benchmark
            start = time.perf_counter()
            for _ in range(iterations):
                encoded = protocol.encode(message, fmt)
            encode_time = (time.perf_counter() - start) * 1000  # ms
            
            # Decode benchmark  
            start = time.perf_counter()
            for _ in range(iterations):
                decoded = protocol.decode(encoded, fmt, expand=False)
            decode_time = (time.perf_counter() - start) * 1000  # ms
            
            results[fmt] = {
                "encode_ms": encode_time,
                "decode_ms": decode_time,
                "size": len(encoded),
            }
        
        # Display results
        table = Table(title="Encoding Benchmark Results")
        table.add_column("Format", style="cyan")
        table.add_column("Size (bytes)", justify="right")
        table.add_column("Encode (ms)", justify="right")
        table.add_column("Decode (ms)", justify="right")
        table.add_column("Ops/sec", justify="right", style="green")
        
        for fmt, data in results.items():
            ops_per_sec = int(iterations / (data["encode_ms"] / 1000))
            table.add_row(
                fmt.upper(),
                str(data["size"]),
                f"{data['encode_ms']:.2f}",
                f"{data['decode_ms']:.2f}",
                f"{ops_per_sec:,}",
            )
        
        console.print(table)
        
        # Original size for comparison
        original_size = len(json.dumps(message))
        rprint(f"\n[dim]Original JSON size: {original_size} bytes[/dim]")


# =============================================================================
# QUINTILLION GENERATOR COMMANDS
# =============================================================================
try:
    from .quintillion_generator import QuintillionGenerator, GenerationMode
    HAS_QUINTILLION = True
except ImportError:
    HAS_QUINTILLION = False

if typer and HAS_QUINTILLION:
    quintillion_app = typer.Typer(
        name="quintillion",
        help="🌌 Quintillion Line Generator - Cosmic scale code generation via Q-Symbolic Expansion",
    )
else:
    quintillion_app = None

if quintillion_app:
    app.add_typer(quintillion_app, name="quintillion")

    @quintillion_app.command("demo")
    def quintillion_demo():
        """Run full quintillion generator demonstration"""
        from .quintillion_generator import demo
        demo()
    
    @quintillion_app.command("generate")
    def quintillion_generate(
        lines: int = typer.Option(100000, "-n", "--lines", help="Number of lines to generate"),
        pattern: str = typer.Option("function", "-p", "--pattern", help="Pattern: function, class, import, variable"),
        target_type: str = typer.Option("python", "-t", "--type", help="Type: python, javascript, data, cosmic"),
        q_depth: int = typer.Option(6, "-q", "--q-depth", help="Q-layer depth (0-38)"),
        output: Optional[str] = typer.Option(None, "-o", "--output", help="Output file (optional)"),
    ):
        """Generate lines using Q-Symbolic expansion"""
        generator = QuintillionGenerator(parallel_workers=4)
        
        rprint(f"\n[cyan]🌌 Quintillion Generator - Q{q_depth} Expansion[/cyan]")
        rprint(f"[dim]Pattern: {pattern} | Type: {target_type} | Target: {lines:,} lines[/dim]\n")
        
        seed = generator.create_seed(
            action="generate",
            pattern=pattern,
            target_type=target_type,
            q_depth=q_depth,
            context={"name": "generated_entity"}
        )
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Generating...", total=None)
            result = generator.generate_batch(seed, target_lines=lines)
            progress.update(task, completed=True)
        
        # Display results
        table = Table(title="Generation Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right", style="green")
        
        table.add_row("Lines Generated", f"{result.lines_generated:,}")
        table.add_row("Bytes Generated", f"{result.bytes_generated:,}")
        table.add_row("Seed Size", f"{result.seed_bytes} bytes")
        table.add_row("Expansion Ratio", f"{result.expansion_ratio:,.0f}x")
        table.add_row("Q-Layers Used", str(result.q_layers_used))
        table.add_row("Generation Time", f"{result.generation_time_ms:.2f}ms")
        table.add_row("Rate", f"{result.lines_generated / (result.generation_time_ms / 1000):,.0f} lines/sec")
        
        console.print(table)
        
        # Show sample
        rprint("\n[yellow]Sample Output (first 5 lines):[/yellow]")
        for line in result.sample_output.split("\n")[:5]:
            rprint(f"  [dim]{line[:80]}[/dim]")
        
        # Write to file if specified
        if output:
            with open(output, "w", encoding="utf-8") as f:
                for line in generator.generate_lines(seed, lines):
                    f.write(line)
            rprint(f"\n[green]✓ Output written to: {output}[/green]")
    
    @quintillion_app.command("cosmic")
    def quintillion_cosmic(
        q_depth: int = typer.Option(8, "-q", "--q-depth", help="Q-layer depth (0-38)"),
        pattern: str = typer.Option("universe", "-p", "--pattern", help="Pattern: universe, node, transaction"),
    ):
        """Generate cosmic-scale output using Q-expansion"""
        generator = QuintillionGenerator(parallel_workers=4)
        
        # Show theoretical capacity
        potential = generator.calculate_potential_lines(q_depth)
        rprint(f"\n[cyan]🌌 COSMIC SCALE GENERATION[/cyan]")
        rprint(f"[yellow]Theoretical Q{q_depth} capacity: {generator.format_large_number(potential)} lines[/yellow]")
        rprint(f"[dim]Practical limit applied for demo[/dim]\n")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Generating cosmic patterns...", total=None)
            result = generator.generate_cosmic(q_depth=q_depth, pattern=pattern)
            progress.update(task, completed=True)
        
        # Display results
        table = Table(title=f"Cosmic Generation Results (Q{q_depth})")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right", style="green")
        
        table.add_row("Lines Generated", f"{result.lines_generated:,}")
        table.add_row("Data Size", generator.format_large_number(result.bytes_generated))
        table.add_row("Expansion Ratio", f"{result.expansion_ratio:,.0f}x")
        table.add_row("Generation Time", f"{result.generation_time_ms:.2f}ms")
        table.add_row("Theoretical Capacity", generator.format_large_number(potential))
        
        console.print(table)
        
        # Show sample
        rprint("\n[yellow]Sample Cosmic Output:[/yellow]")
        for line in result.sample_output.split("\n")[:5]:
            rprint(f"  [magenta]{line[:80]}[/magenta]")
    
    @quintillion_app.command("capacity")
    def quintillion_capacity():
        """Show theoretical capacity at each Q-layer"""
        generator = QuintillionGenerator()
        
        rprint("\n[cyan]📊 QUINTILLION GENERATOR - THEORETICAL CAPACITY[/cyan]")
        rprint("[dim]Each Q-layer expands output by 10x[/dim]\n")
        
        table = Table(title="Q-Layer Expansion Capacity")
        table.add_column("Q-Layer", style="cyan", justify="center")
        table.add_column("Lines", justify="right", style="green")
        table.add_column("Scale", style="yellow")
        
        scale_names = {
            0: "1",
            3: "1 thousand",
            6: "1 million",
            9: "1 billion",
            12: "1 trillion",
            15: "1 quadrillion",
            18: "1 QUINTILLION",
            21: "1 sextillion",
            24: "1 septillion",
            27: "1 octillion",
            30: "1 nonillion",
            33: "1 decillion",
            36: "1 undecillion",
            38: "100 undecillion",
        }
        
        for q in [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 38]:
            potential = generator.calculate_potential_lines(q)
            formatted = generator.format_large_number(potential)
            scale = scale_names.get(q, "")
            
            # Highlight quintillion
            if q == 18:
                table.add_row(f"Q{q}", f"[bold green]{formatted}[/bold green]", f"[bold yellow]← {scale}[/bold yellow]")
            else:
                table.add_row(f"Q{q}", formatted, scale)
        
        console.print(table)
        
        rprint("\n[green]Key Insight:[/green] From a 16-byte seed, Q-expansion can generate:")
        rprint("  • Q6:  1 million lines of code")
        rprint("  • Q12: 1 trillion data records")
        rprint("  • Q18: 1 [bold]QUINTILLION[/bold] cosmic entities")
        rprint("  • Q38: 10^38 maximum theoretical output")
    
    @quintillion_app.command("stats")
    def quintillion_stats():
        """Show generator statistics"""
        generator = QuintillionGenerator()
        stats = generator.get_statistics()
        
        rprint("\n[cyan]📈 QUINTILLION GENERATOR STATISTICS[/cyan]\n")
        
        table = Table()
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        for key, value in stats.items():
            table.add_row(key.replace("_", " ").title(), str(value))
        
        console.print(table)
    
    @quintillion_app.command("benchmark")
    def quintillion_benchmark(
        lines: int = typer.Option(100000, "-n", "--lines", help="Lines to generate"),
        parallel: bool = typer.Option(True, "--parallel/--sequential", help="Use parallel generation"),
    ):
        """Benchmark generation performance"""
        import time
        
        generator = QuintillionGenerator(parallel_workers=4)
        
        rprint(f"\n[cyan]⚡ QUINTILLION GENERATOR BENCHMARK[/cyan]")
        rprint(f"[dim]Target: {lines:,} lines | Mode: {'Parallel' if parallel else 'Sequential'}[/dim]\n")
        
        patterns = [
            ("python", "function"),
            ("javascript", "class"),
            ("data", "json_object"),
            ("cosmic", "universe"),
        ]
        
        table = Table(title="Benchmark Results")
        table.add_column("Type", style="cyan")
        table.add_column("Pattern")
        table.add_column("Lines", justify="right")
        table.add_column("Size", justify="right")
        table.add_column("Time (ms)", justify="right")
        table.add_column("Rate (lines/sec)", justify="right", style="green")
        
        for target_type, pattern in patterns:
            seed = generator.create_seed(
                action="generate",
                pattern=pattern,
                target_type=target_type,
                q_depth=6,
            )
            
            if parallel:
                result = generator.generate_parallel(seed, lines)
            else:
                result = generator.generate_batch(seed, lines)
            
            rate = result.lines_generated / (result.generation_time_ms / 1000)
            table.add_row(
                target_type,
                pattern,
                f"{result.lines_generated:,}",
                generator.format_large_number(result.bytes_generated),
                f"{result.generation_time_ms:.1f}",
                f"{rate:,.0f}",
            )
        
        console.print(table)


# =============================================================================
# USB4 TOPOLOGY GENERATOR COMMANDS
# =============================================================================
try:
    from .usb4_topology_generator import USB4TopologyGenerator, USB4DeviceType, TunnelType
    HAS_USB4 = True
except ImportError:
    HAS_USB4 = False

if typer and HAS_USB4:
    usb4_app = typer.Typer(
        name="usb4",
        help="🔌 USB4 Topology Generator - Q-expansion for USB4/Thunderbolt networks",
    )
else:
    usb4_app = None

if usb4_app:
    app.add_typer(usb4_app, name="usb4")

    @usb4_app.command("demo")
    def usb4_demo():
        """Run full USB4 topology generator demonstration"""
        from .usb4_topology_generator import demo
        demo()
    
    @usb4_app.command("host")
    def usb4_host():
        """Show USB4 host controller information"""
        generator = USB4TopologyGenerator()
        host = generator.host_router
        
        rprint("\n[cyan]🔌 USB4 HOST CONTROLLER[/cyan]")
        
        table = Table(title="Intel Gen14 USB4 Controller")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Topology ID", ":".join(map(str, host.topology_id)))
        table.add_row("Manufacturer", host.manufacturer)
        table.add_row("Model", host.model)
        table.add_row("USB4 Version", host.usb4_version)
        table.add_row("Firmware", host.firmware_version)
        table.add_row("Domain ID", hex(host.domain_id))
        table.add_row("Vendor ID", hex(host.vendor_id))
        table.add_row("Product ID", hex(host.product_id))
        table.add_row("Revision", str(host.revision))
        table.add_row("DP Adapters", str(host.dp_adapters))
        table.add_row("PCIe Lanes", str(host.pcie_lanes))
        table.add_row("USB3 Ports", str(host.usb3_ports))
        table.add_row("Power Delivery", f"{host.power_delivery_watts}W")
        table.add_row("Tunnels", ", ".join(t.name for t in host.tunnels))
        
        console.print(table)
    
    @usb4_app.command("topology")
    def usb4_topology(
        depth: int = typer.Option(3, "-d", "--depth", help="Maximum tree depth"),
        children: int = typer.Option(4, "-c", "--children", help="Max children per node"),
        q_depth: int = typer.Option(4, "-q", "--q-depth", help="Q-expansion depth"),
    ):
        """Generate simulated USB4 topology tree"""
        generator = USB4TopologyGenerator()
        
        rprint(f"\n[cyan]🌳 GENERATING USB4 TOPOLOGY (Q{q_depth} Expansion)[/cyan]")
        rprint(f"[dim]Depth: {depth} | Max children: {children}[/dim]\n")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Generating topology...", total=None)
            root = generator.generate_topology_tree(
                max_depth=depth,
                max_children=children,
                q_depth=q_depth
            )
            progress.update(task, completed=True)
        
        rprint(generator.format_topology_tree(root))
        
        total = 1 + root.count_descendants()
        rprint(f"\n[green]✓ Total devices: {total}[/green]")
    
    @usb4_app.command("routes")
    def usb4_routes(
        depth: int = typer.Option(3, "-d", "--depth", help="Topology depth"),
        q_depth: int = typer.Option(4, "-q", "--q-depth", help="Q-expansion depth"),
        output: Optional[str] = typer.Option(None, "-o", "--output", help="Output file"),
    ):
        """Generate USB4 routing table"""
        generator = USB4TopologyGenerator()
        
        rprint(f"\n[cyan]📋 GENERATING USB4 ROUTING TABLE (Q{q_depth})[/cyan]\n")
        
        root = generator.generate_topology_tree(max_depth=depth, q_depth=q_depth)
        routes = list(generator.generate_routing_table(root, q_layer=q_depth))
        
        for route in routes[:10]:
            rprint(f"  [dim]{route}[/dim]")
        
        if len(routes) > 10:
            rprint(f"\n  [yellow]... {len(routes) - 10} more routes[/yellow]")
        
        rprint(f"\n[green]✓ Total routes: {len(routes)}[/green]")
        
        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write("\n".join(routes))
            rprint(f"[green]✓ Written to: {output}[/green]")
    
    @usb4_app.command("tunnels")
    def usb4_tunnels(
        count: int = typer.Option(10000, "-n", "--count", help="Number of tunnel configs"),
        q_depth: int = typer.Option(6, "-q", "--q-depth", help="Q-expansion depth"),
    ):
        """Generate USB4 tunnel configurations at Q-scale"""
        generator = USB4TopologyGenerator()
        
        rprint(f"\n[cyan]🚇 GENERATING USB4 TUNNEL CONFIGS (Q{q_depth})[/cyan]")
        rprint(f"[dim]Target: {count:,} configurations[/dim]\n")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Generating tunnels...", total=None)
            result = generator.generate_tunnel_configs(count=count, q_depth=q_depth)
            progress.update(task, completed=True)
        
        table = Table(title="Tunnel Generation Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right", style="green")
        
        rate = result.lines_generated / (result.generation_time_ms / 1000)
        table.add_row("Configs Generated", f"{result.lines_generated:,}")
        table.add_row("Data Size", f"{result.bytes_generated:,} bytes")
        table.add_row("Generation Time", f"{result.generation_time_ms:.2f}ms")
        table.add_row("Rate", f"{rate:,.0f} configs/sec")
        
        console.print(table)
        
        rprint("\n[yellow]Sample Tunnel Configs:[/yellow]")
        for line in result.sample_output.split("\n")[:5]:
            rprint(f"  [dim]{line}[/dim]")
    
    @usb4_app.command("devices")
    def usb4_devices(
        count: int = typer.Option(100, "-n", "--count", help="Number of devices to generate"),
        q_depth: int = typer.Option(6, "-q", "--q-depth", help="Q-expansion depth"),
        output: Optional[str] = typer.Option(None, "-o", "--output", help="Output JSON file"),
    ):
        """Generate simulated USB4 device enumeration"""
        import time
        generator = USB4TopologyGenerator()
        
        rprint(f"\n[cyan]📱 GENERATING USB4 DEVICE ENUMERATION (Q{q_depth})[/cyan]")
        rprint(f"[dim]Target: {count:,} devices[/dim]\n")
        
        start = time.perf_counter()
        devices = list(generator.generate_device_enumeration(count=count, q_depth=q_depth))
        elapsed = (time.perf_counter() - start) * 1000
        
        table = Table(title="Device Generation Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right", style="green")
        
        total_bytes = sum(len(d.encode()) for d in devices)
        table.add_row("Devices Generated", f"{len(devices):,}")
        table.add_row("Total Data", f"{total_bytes:,} bytes")
        table.add_row("Generation Time", f"{elapsed:.2f}ms")
        table.add_row("Rate", f"{len(devices) / (elapsed / 1000):,.0f} devices/sec")
        
        console.print(table)
        
        rprint("\n[yellow]Sample Devices:[/yellow]")
        for device_json in devices[:3]:
            device = json.loads(device_json)
            rprint(f"  [dim]{device['topology_id']} - {device['manufacturer']} {device['model']} ({device['device_type']})[/dim]")
        
        if output:
            with open(output, "w", encoding="utf-8") as f:
                f.write("[\n")
                f.write(",\n".join(devices))
                f.write("\n]")
            rprint(f"\n[green]✓ Written to: {output}[/green]")
    
    @usb4_app.command("stats")
    def usb4_stats():
        """Show USB4 topology generator statistics"""
        generator = USB4TopologyGenerator()
        stats = generator.get_statistics()
        
        rprint("\n[cyan]📊 USB4 TOPOLOGY GENERATOR STATISTICS[/cyan]\n")
        
        table = Table()
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        for key, value in stats.items():
            table.add_row(key.replace("_", " ").title(), str(value))
        
        console.print(table)
        
        rprint("\n[yellow]Q-Expansion Potential for USB4:[/yellow]")
        rprint("  Q3:  ~1,000 device topologies")
        rprint("  Q6:  ~1 million device configurations")
        rprint("  Q9:  ~1 billion routing entries")
        rprint("  Q12: ~1 trillion tunnel simulations")


# =============================================================================
# VPN + VM AUTOMATION COMMANDS
# =============================================================================
try:
    from .vpn_vm_automation import (
        VPNVMAutomation, PhoneLinkIntegration, VPNManager, VMManager,
        VPNProvider, VMPlatform, TermuxCommand
    )
    HAS_VPN_VM = True
except ImportError:
    HAS_VPN_VM = False

if typer and HAS_VPN_VM:
    vpnvm_app = typer.Typer(
        name="vpnvm",
        help="🔐 VPN + VM Automation - Phone Link, Termux, VPN, and VM integration",
    )
else:
    vpnvm_app = None

if vpnvm_app:
    app.add_typer(vpnvm_app, name="vpnvm")

    @vpnvm_app.command("demo")
    def vpnvm_demo():
        """Run full VPN + VM automation demonstration"""
        from .vpn_vm_automation import demo
        demo()
    
    @vpnvm_app.command("status")
    def vpnvm_status():
        """Show complete system status"""
        automation = VPNVMAutomation()
        status = automation.get_system_status()
        
        rprint("\n[cyan]📊 VPN + VM AUTOMATION STATUS[/cyan]")
        rprint(f"[dim]Session: {status['session_id']} | {status['timestamp']}[/dim]\n")
        
        # Phone Link
        table = Table(title="📱 Phone Link Status")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        phone = status["phone_link"]
        table.add_row("Phone Link Running", "✓" if phone.get("phone_link_running") else "✗")
        table.add_row("Device Connected", "✓" if phone.get("device_connected") else "✗")
        table.add_row("ADB Available", "✓" if phone.get("adb_available") else "✗")
        if phone.get("device_info"):
            table.add_row("Device Serial", phone["device_info"].get("serial", "N/A"))
        
        console.print(table)
        
        # VM Platforms
        rprint("\n[cyan]🖥️ VM Platforms:[/cyan]")
        for platform, available in status["vm_platforms"].items():
            icon = "[green]✓[/green]" if available else "[red]✗[/red]"
            rprint(f"  {icon} {platform}")
        
        # WSL
        if status["wsl_distros"]:
            rprint("\n[cyan]🐧 WSL Distributions:[/cyan]")
            for distro in status["wsl_distros"][:5]:
                default = " [yellow](default)[/yellow]" if distro.get("default") else ""
                rprint(f"  • {distro['name']} - {distro.get('state', 'Unknown')}{default}")
        
        # VPN
        vpn = status["vpn"]
        rprint(f"\n[cyan]🔒 VPN Status:[/cyan]")
        rprint(f"  WireGuard Installed: {'✓' if vpn.get('wireguard_installed') else '✗'}")
        if vpn.get("active_tunnels"):
            rprint(f"  Active Tunnels: {len(vpn['active_tunnels'])}")
        
        # USB4
        usb4 = status["usb4_host"]
        rprint(f"\n[cyan]🔌 USB4 Host:[/cyan]")
        rprint(f"  {usb4['manufacturer']} {usb4['model']} @ {usb4['topology_id']}")
    
    @vpnvm_app.command("phone")
    def vpnvm_phone():
        """Show connected phone details"""
        phone_link = PhoneLinkIntegration()
        device = phone_link.get_device_info()
        
        if not device:
            rprint("[red]✗ No phone connected via ADB[/red]")
            rprint("[dim]Make sure ADB is installed and device is connected[/dim]")
            return
        
        rprint("\n[cyan]📱 CONNECTED DEVICE[/cyan]\n")
        
        table = Table(title=device.name)
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Model", device.model)
        table.add_row("Android Version", device.android_version)
        table.add_row("IP Address", device.ip_address or "N/A")
        table.add_row("ADB Serial", device.adb_serial or "N/A")
        table.add_row("Battery", f"{device.battery_level}%")
        table.add_row("Termux Installed", "✓" if device.termux_installed else "✗")
        
        console.print(table)
    
    @vpnvm_app.command("termux")
    def vpnvm_termux(
        command: str = typer.Argument(..., help="Command to execute in Termux"),
        timeout: int = typer.Option(30, "-t", "--timeout", help="Timeout in seconds"),
    ):
        """Execute command in Termux on connected phone"""
        phone_link = PhoneLinkIntegration()
        
        rprint(f"\n[cyan]📱 Executing in Termux:[/cyan] {command}")
        
        termux_cmd = TermuxCommand(
            command=command,
            description=f"Execute: {command}",
            timeout_seconds=timeout
        )
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Executing...", total=None)
            result = phone_link.execute_termux_command(termux_cmd)
            progress.update(task, completed=True)
        
        if result.get("success"):
            rprint(f"\n[green]✓ Command executed in {result['execution_time_ms']:.2f}ms[/green]")
            if result.get("output"):
                rprint(f"\n[dim]{result['output']}[/dim]")
        else:
            rprint(f"\n[red]✗ Command failed: {result.get('error', 'Unknown error')}[/red]")
    
    @vpnvm_app.command("termux-setup")
    def vpnvm_termux_setup():
        """Setup Termux with SSH and essential tools"""
        phone_link = PhoneLinkIntegration()
        
        rprint("\n[cyan]📱 Setting up Termux...[/cyan]\n")
        
        commands = [
            ("pkg update -y", "Updating packages"),
            ("pkg upgrade -y", "Upgrading packages"),
            ("pkg install openssh git python nodejs -y", "Installing tools"),
            ("termux-setup-storage", "Setting up storage access"),
        ]
        
        for cmd, desc in commands:
            rprint(f"  [dim]→ {desc}...[/dim]")
            termux_cmd = TermuxCommand(command=cmd, description=desc, timeout_seconds=120)
            result = phone_link.execute_termux_command(termux_cmd)
            status = "[green]✓[/green]" if result.get("success") else "[red]✗[/red]"
            rprint(f"  {status} {desc}")
        
        rprint("\n[green]✓ Termux setup complete![/green]")
    
    @vpnvm_app.command("vpn-create")
    def vpnvm_vpn_create(
        name: str = typer.Option("aria-vpn", "-n", "--name", help="VPN config name"),
        server: str = typer.Option("vpn.example.com", "-s", "--server", help="VPN server"),
        port: int = typer.Option(51820, "-p", "--port", help="VPN port"),
        output: Optional[str] = typer.Option(None, "-o", "--output", help="Output config file"),
    ):
        """Create WireGuard VPN configuration"""
        vpn_manager = VPNManager()
        
        rprint(f"\n[cyan]🔒 Creating VPN Configuration: {name}[/cyan]\n")
        
        config = vpn_manager.create_vpn_config(
            provider=VPNProvider.WIREGUARD,
            name=name,
            server=server,
            port=port,
        )
        
        table = Table(title="VPN Configuration")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Name", config.name)
        table.add_row("Server", f"{config.server}:{config.port}")
        table.add_row("Address", config.address)
        table.add_row("DNS", ", ".join(config.dns))
        table.add_row("MTU", str(config.mtu))
        
        console.print(table)
        
        if output:
            with open(output, "w") as f:
                f.write(config.to_wireguard_conf())
            rprint(f"\n[green]✓ Config written to: {output}[/green]")
        else:
            rprint("\n[yellow]WireGuard Config:[/yellow]")
            rprint(f"[dim]{config.to_wireguard_conf()}[/dim]")
    
    @vpnvm_app.command("vpn-deploy")
    def vpnvm_vpn_deploy(
        target: str = typer.Argument(..., help="Target: 'termux', 'wsl', or distro name"),
        server: str = typer.Option("vpn.example.com", "-s", "--server", help="VPN server"),
    ):
        """Deploy VPN to Termux or WSL"""
        automation = VPNVMAutomation()
        
        rprint(f"\n[cyan]🔒 Deploying VPN to {target}...[/cyan]\n")
        
        vpn_config = automation.vpn_manager.create_vpn_config(
            name="aria-deploy",
            server=server,
            port=51820,
        )
        
        if target.lower() == "termux":
            result = automation.vpn_manager.deploy_to_termux(
                vpn_config,
                automation.phone_link
            )
        else:
            result = automation.vm_manager.deploy_wsl_with_vpn(
                distro=target if target.lower() != "wsl" else "Ubuntu",
                vpn_config=vpn_config
            )
        
        if result.get("success"):
            rprint(f"[green]✓ VPN deployed successfully![/green]")
        else:
            rprint(f"[red]✗ Deployment failed[/red]")
            for step in result.get("steps", [])[:5]:
                status = "[green]✓[/green]" if step.get("success") else "[red]✗[/red]"
                rprint(f"  {status} {step.get('action', step.get('command', 'Unknown'))[:50]}")
    
    @vpnvm_app.command("wsl")
    def vpnvm_wsl():
        """List WSL distributions"""
        vm_manager = VMManager()
        distros = vm_manager.list_wsl_distros()
        
        if not distros:
            rprint("[yellow]No WSL distributions found[/yellow]")
            return
        
        rprint("\n[cyan]🐧 WSL DISTRIBUTIONS[/cyan]\n")
        
        table = Table()
        table.add_column("Name", style="cyan")
        table.add_column("State", style="green")
        table.add_column("Version")
        table.add_column("Default")
        
        for distro in distros:
            table.add_row(
                distro["name"],
                distro.get("state", "Unknown"),
                distro.get("version", "2"),
                "✓" if distro.get("default") else ""
            )
        
        console.print(table)
    
    @vpnvm_app.command("wsl-exec")
    def vpnvm_wsl_exec(
        command: str = typer.Argument(..., help="Command to execute"),
        distro: str = typer.Option("Ubuntu", "-d", "--distro", help="WSL distro name"),
    ):
        """Execute command in WSL distro"""
        vm_manager = VMManager()
        
        rprint(f"\n[cyan]🐧 Executing in {distro}:[/cyan] {command}")
        
        result = vm_manager.execute_in_wsl(distro, command)
        
        if result.get("success"):
            rprint(f"\n[green]✓ Command executed[/green]")
            if result.get("stdout"):
                rprint(f"\n{result['stdout']}")
        else:
            rprint(f"\n[red]✗ Command failed: {result.get('error', 'Unknown')}[/red]")
    
    @vpnvm_app.command("docker")
    def vpnvm_docker():
        """List Docker containers"""
        vm_manager = VMManager()
        containers = vm_manager.list_docker_containers()
        
        if not containers:
            rprint("[yellow]No Docker containers found (or Docker not running)[/yellow]")
            return
        
        rprint("\n[cyan]🐳 DOCKER CONTAINERS[/cyan]\n")
        
        table = Table()
        table.add_column("Name", style="cyan")
        table.add_column("Image")
        table.add_column("Status", style="green")
        table.add_column("Ports")
        
        for container in containers[:10]:
            table.add_row(
                container.get("Names", "N/A"),
                container.get("Image", "N/A")[:30],
                container.get("Status", "Unknown")[:20],
                container.get("Ports", "")[:30]
            )
        
        console.print(table)
    
    @vpnvm_app.command("generate")
    def vpnvm_generate(
        count: int = typer.Option(10000, "-n", "--count", help="Configs to generate"),
        q_depth: int = typer.Option(6, "-q", "--q-depth", help="Q-expansion depth"),
    ):
        """Generate VPN and VM configs at Q-scale"""
        automation = VPNVMAutomation()
        
        rprint(f"\n[cyan]🌌 GENERATING CONFIGS AT Q{q_depth} SCALE[/cyan]")
        rprint(f"[dim]Target: {count:,} configurations each[/dim]\n")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Generating...", total=None)
            scripts = automation.generate_deployment_scripts(count=count, q_depth=q_depth)
            progress.update(task, completed=True)
        
        table = Table(title="Generation Results")
        table.add_column("Type", style="cyan")
        table.add_column("Count", justify="right")
        table.add_column("Size", justify="right")
        table.add_column("Time", justify="right")
        table.add_column("Rate", justify="right", style="green")
        
        for name, result in scripts.items():
            rate = result.lines_generated / (result.generation_time_ms / 1000)
            table.add_row(
                name.replace("_", " ").title(),
                f"{result.lines_generated:,}",
                f"{result.bytes_generated:,} bytes",
                f"{result.generation_time_ms:.1f}ms",
                f"{rate:,.0f}/sec"
            )
        
        console.print(table)
        
        # Show samples
        for name, result in scripts.items():
            rprint(f"\n[yellow]Sample {name}:[/yellow]")
            for line in result.sample_output.split("\n")[:2]:
                rprint(f"  [dim]{line}[/dim]")
    
    @vpnvm_app.command("setup")
    def vpnvm_setup(
        vpn_server: str = typer.Option("vpn.aria.io", "-s", "--server", help="VPN server"),
        wsl_distro: str = typer.Option("Ubuntu", "-d", "--distro", help="WSL distro"),
        deploy_phone: bool = typer.Option(True, "--phone/--no-phone", help="Deploy to phone"),
    ):
        """Full environment setup - VPN + WSL + Phone"""
        automation = VPNVMAutomation()
        
        rprint("\n[cyan]🚀 FULL ENVIRONMENT SETUP[/cyan]")
        rprint(f"[dim]VPN Server: {vpn_server} | WSL: {wsl_distro} | Phone: {deploy_phone}[/dim]\n")
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Setting up environment...", total=None)
            result = automation.setup_full_environment(
                vpn_server=vpn_server,
                wsl_distro=wsl_distro,
                deploy_to_phone=deploy_phone,
            )
            progress.update(task, completed=True)
        
        # Results
        if result.get("vpn_config"):
            rprint(f"\n[green]✓ VPN Config Created[/green]")
            rprint(f"  Server: {result['vpn_config']['server']}:{result['vpn_config']['port']}")
        
        if result.get("wsl_deployment"):
            status = "[green]✓[/green]" if result["wsl_deployment"].get("success") else "[red]✗[/red]"
            rprint(f"\n{status} WSL Deployment")
        
        if result.get("phone_deployment"):
            status = "[green]✓[/green]" if result["phone_deployment"].get("success") else "[red]✗[/red]"
            rprint(f"{status} Phone Deployment")
        
        # Connectivity
        if result.get("connectivity"):
            rprint("\n[cyan]🔗 Connectivity:[/cyan]")
            for check, passed in result["connectivity"].items():
                status = "[green]✓[/green]" if passed else "[red]✗[/red]"
                rprint(f"  {status} {check.replace('_', ' ').title()}")


# =============================================================================
# TAILSCALE MESH COMMANDS
# =============================================================================
try:
    from .tailscale_mesh import TailscaleMesh, MeshNode, MeshMessage, MessageType, create_mesh, demo as ts_demo
    HAS_TAILSCALE_MESH = True
except ImportError:
    HAS_TAILSCALE_MESH = False

if typer and HAS_TAILSCALE_MESH:
    tailscale_app = typer.Typer(
        name="tailscale",
        help="🌐 Tailscale Mesh - HTTP-based PC ↔ Phone network over Tailscale VPN",
    )
else:
    tailscale_app = None

if tailscale_app:
    app.add_typer(tailscale_app, name="tailscale")
    
    # Global mesh instance
    _tailscale_mesh: TailscaleMesh = None

    @tailscale_app.command("demo")
    def tailscale_demo():
        """Run Tailscale mesh demo"""
        ts_demo()

    @tailscale_app.command("serve")
    def tailscale_serve(
        name: str = typer.Option(None, "--name", "-n", help="Node name"),
        port: int = typer.Option(8765, "--port", "-p", help="Listen port"),
        device: str = typer.Option("pc", "--device", "-d", help="Device type: pc, phone, server"),
    ):
        """Start Tailscale mesh server (keeps running)"""
        global _tailscale_mesh
        
        rprint("\n[cyan]🌐 TAILSCALE MESH SERVER[/cyan]\n")
        
        _tailscale_mesh = create_mesh(name=name, port=port, device_type=device)
        
        table = Table(title="Local Node")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("ID", _tailscale_mesh.node_id)
        table.add_row("Name", _tailscale_mesh.name)
        table.add_row("Local IP", _tailscale_mesh.local_ip)
        table.add_row("Tailscale IP", _tailscale_mesh.tailscale_ip or "[yellow]Not detected[/yellow]")
        table.add_row("Port", str(_tailscale_mesh.port))
        table.add_row("Endpoint", f"http://{_tailscale_mesh.tailscale_ip or _tailscale_mesh.local_ip}:{port}")
        console.print(table)
        
        rprint("\n[green]✅ Server running! Waiting for connections...[/green]")
        rprint(f"\n[yellow]From another device, run:[/yellow]")
        rprint(f"   aria tailscale connect {_tailscale_mesh.tailscale_ip or _tailscale_mesh.local_ip}")
        
        rprint("\n[dim]Press Ctrl+C to stop[/dim]")
        
        import time as time_mod
        try:
            while True:
                time_mod.sleep(1)
        except KeyboardInterrupt:
            _tailscale_mesh.stop()
            rprint("\n[yellow]Server stopped[/yellow]")

    @tailscale_app.command("connect")
    def tailscale_connect(
        target: str = typer.Argument(..., help="Target IP or hostname"),
        port: int = typer.Option(8765, "--port", "-p", help="Target port"),
        name: str = typer.Option(None, "--name", "-n", help="Local node name"),
    ):
        """Connect to a peer node via Tailscale"""
        global _tailscale_mesh
        
        # Create local mesh if not running
        if _tailscale_mesh is None:
            _tailscale_mesh = create_mesh(name=name)
        
        rprint(f"\n[cyan]🔗 Connecting to {target}:{port}...[/cyan]")
        
        node = _tailscale_mesh.connect(target, port)
        
        if node:
            table = Table(title="Connected Node")
            table.add_column("Property", style="cyan")
            table.add_column("Value", style="green")
            table.add_row("ID", node.node_id)
            table.add_row("Name", node.name)
            table.add_row("IP", node.tailscale_ip or node.ip)
            table.add_row("Device", node.device_type)
            console.print(table)
        else:
            rprint("[red]❌ Connection failed[/red]")

    @tailscale_app.command("send")
    def tailscale_send(
        target: str = typer.Argument(..., help="Target node name or ID"),
        message: str = typer.Argument(..., help="Message to send"),
    ):
        """Send a message to a peer node"""
        global _tailscale_mesh
        
        if _tailscale_mesh is None:
            rprint("[red]❌ Mesh not running. Start with: aria tailscale serve[/red]")
            raise typer.Exit(1)
        
        if _tailscale_mesh.send(target, {"text": message}):
            rprint(f"[green]✅ Message sent to {target}[/green]")
        else:
            rprint(f"[red]❌ Failed to send to {target}[/red]")

    @tailscale_app.command("cmd")
    def tailscale_cmd(
        target: str = typer.Argument(..., help="Target node name or ID"),
        command: str = typer.Argument(..., help="Command to execute"),
    ):
        """Execute a command on a remote node"""
        global _tailscale_mesh
        
        if _tailscale_mesh is None:
            rprint("[red]❌ Mesh not running. Start with: aria tailscale serve[/red]")
            raise typer.Exit(1)
        
        rprint(f"[cyan]⚡ Sending command to {target}: {command}[/cyan]")
        
        if _tailscale_mesh.send(target, {"command": command}, MessageType.COMMAND):
            rprint(f"[green]✅ Command sent[/green]")
        else:
            rprint(f"[red]❌ Failed to send command[/red]")

    @tailscale_app.command("nodes")
    def tailscale_nodes():
        """List all nodes in the mesh"""
        global _tailscale_mesh
        
        if _tailscale_mesh is None:
            # Try to create mesh to get local info
            _tailscale_mesh = create_mesh()
        
        nodes = _tailscale_mesh.list_nodes()
        
        table = Table(title="Mesh Nodes")
        table.add_column("Name", style="cyan")
        table.add_column("ID", style="dim")
        table.add_column("Tailscale IP", style="green")
        table.add_column("Device", style="yellow")
        table.add_column("Status", style="white")
        
        for node in nodes:
            status = "[green]● Local[/green]" if node.is_local else (
                "[green]● Online[/green]" if node.is_alive else "[red]○ Offline[/red]"
            )
            table.add_row(
                node.name,
                node.node_id,
                node.tailscale_ip or node.ip,
                node.device_type,
                status,
            )
        
        console.print(table)

    @tailscale_app.command("status")
    def tailscale_status():
        """Show Tailscale mesh status"""
        global _tailscale_mesh
        
        if _tailscale_mesh is None:
            _tailscale_mesh = create_mesh()
        
        status = _tailscale_mesh.status()
        
        rprint("\n[cyan]🌐 TAILSCALE MESH STATUS[/cyan]\n")
        
        # Local node
        local = status["local"]
        table = Table(title="Local Node")
        table.add_column("Property", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("Name", local["name"])
        table.add_row("ID", local["node_id"])
        table.add_row("Tailscale IP", local["tailscale_ip"] or "[yellow]Not detected[/yellow]")
        table.add_row("Local IP", local["ip"])
        table.add_row("Port", str(local["port"]))
        console.print(table)
        
        # Peers
        if status["peers"]:
            import time as time_mod
            rprint(f"\n[cyan]Connected Peers: {len(status['peers'])}[/cyan]")
            for peer in status["peers"]:
                alive = "[green]●[/green]" if time_mod.time() - peer["last_seen"] < 30 else "[red]○[/red]"
                rprint(f"  {alive} {peer['name']} ({peer['tailscale_ip'] or peer['ip']})")
        else:
            rprint("\n[yellow]No connected peers[/yellow]")
        
        # Stats
        rprint(f"\n[cyan]Stats:[/cyan]")
        rprint(f"  Sent: {status['stats']['sent']}")
        rprint(f"  Received: {status['stats']['received']}")
        rprint(f"  Files: {status['stats'].get('files', 0)}")
        rprint(f"  Workflows: {status['stats'].get('workflows_triggered', 0)}")

    @tailscale_app.command("share")
    def tailscale_share(
        filepath: str = typer.Argument(..., help="File to share"),
        target: str = typer.Argument(..., help="Target node name"),
    ):
        """Share a file with another device"""
        global _tailscale_mesh
        
        if _tailscale_mesh is None:
            _tailscale_mesh = create_mesh()
        
        rprint(f"[cyan]📁 Sending {filepath} to {target}...[/cyan]")
        
        if _tailscale_mesh.send_file(target, filepath):
            rprint(f"[green]✅ File sent successfully[/green]")
        else:
            rprint(f"[red]❌ Failed to send file[/red]")

    @tailscale_app.command("files")
    def tailscale_files():
        """List shared and received files"""
        global _tailscale_mesh
        
        if _tailscale_mesh is None:
            _tailscale_mesh = create_mesh()
        
        # Shared files
        shared = _tailscale_mesh.list_shared_files()
        if shared:
            table = Table(title="Shared Files (~/aria/tailscale-mesh/shared/)")
            table.add_column("Name", style="cyan")
            table.add_column("Size", style="green")
            for f in shared:
                table.add_row(f["name"], f"{f['size']:,} bytes")
            console.print(table)
        else:
            rprint("[yellow]No shared files[/yellow]")
        
        # Inbox files
        inbox_dir = _tailscale_mesh.inbox_dir
        inbox_files = list(inbox_dir.iterdir()) if inbox_dir.exists() else []
        if inbox_files:
            table = Table(title="Received Files (~/aria/tailscale-mesh/inbox/)")
            table.add_column("Name", style="cyan")
            table.add_column("Size", style="green")
            for f in inbox_files:
                if f.is_file():
                    table.add_row(f.name, f"{f.stat().st_size:,} bytes")
            console.print(table)
        else:
            rprint("[yellow]No received files[/yellow]")

    @tailscale_app.command("workflow")
    def tailscale_workflow(
        action: str = typer.Argument("list", help="Action: list, add, remove"),
        name: str = typer.Option(None, "--name", "-n", help="Workflow name"),
        trigger: str = typer.Option(None, "--trigger", "-t", help="Trigger type: file_received, message_received"),
        filter_source: str = typer.Option(None, "--source", "-s", help="Filter by source device"),
        filter_ext: str = typer.Option(None, "--ext", "-e", help="Filter by file extension"),
        forward_to: str = typer.Option(None, "--forward", "-f", help="Forward files to device"),
        run_cmd: str = typer.Option(None, "--cmd", "-c", help="Run command on trigger"),
    ):
        """Manage workflow automation rules
        
        Examples:
          aria tailscale workflow list
          aria tailscale workflow add -n "Photo backup" -t file_received -e .jpg -f pc2
          aria tailscale workflow add -n "Notify" -t file_received -c "echo File received: ${filename}"
        """
        global _tailscale_mesh
        from .tailscale_mesh import WorkflowRule
        
        if _tailscale_mesh is None:
            _tailscale_mesh = create_mesh()
        
        if action == "list":
            workflows = list(_tailscale_mesh.workflows.values())
            if workflows:
                table = Table(title="Workflow Rules")
                table.add_column("Name", style="cyan")
                table.add_column("Trigger", style="yellow")
                table.add_column("Filter", style="dim")
                table.add_column("Actions", style="green")
                table.add_column("Status")
                
                for w in workflows:
                    filters = ", ".join(f"{k}={v}" for k, v in w.trigger_filter.items()) or "-"
                    actions = ", ".join(a.get("type", "?") for a in w.actions)
                    status = "[green]✓ Enabled[/green]" if w.enabled else "[red]✗ Disabled[/red]"
                    table.add_row(w.name, w.trigger_type, filters, actions, status)
                console.print(table)
            else:
                rprint("[yellow]No workflow rules configured[/yellow]")
                rprint("\nCreate one with:")
                rprint("  aria tailscale workflow add -n 'My Rule' -t file_received -f other_device")
        
        elif action == "add":
            if not name or not trigger:
                rprint("[red]❌ Name and trigger required[/red]")
                rprint("Example: aria tailscale workflow add -n 'Backup' -t file_received -f pc2")
                raise typer.Exit(1)
            
            # Build filter
            trigger_filter = {}
            if filter_source:
                trigger_filter["source"] = filter_source
            if filter_ext:
                trigger_filter["ext"] = filter_ext
            
            # Build actions
            actions = []
            if forward_to:
                actions.append({"type": "forward", "target": forward_to})
            if run_cmd:
                actions.append({"type": "command", "command": run_cmd})
            if not actions:
                actions.append({"type": "notify", "text": f"Workflow '{name}' triggered"})
            
            import uuid
            rule = WorkflowRule(
                rule_id=str(uuid.uuid4())[:8],
                name=name,
                trigger_type=trigger,
                trigger_filter=trigger_filter,
                actions=actions,
            )
            _tailscale_mesh.add_workflow(rule)
            rprint(f"[green]✅ Workflow '{name}' created[/green]")
        
        elif action == "remove":
            if not name:
                rprint("[red]❌ Workflow name required[/red]")
                raise typer.Exit(1)
            # Find by name
            for rule_id, rule in list(_tailscale_mesh.workflows.items()):
                if rule.name.lower() == name.lower():
                    _tailscale_mesh.remove_workflow(rule_id)
                    rprint(f"[green]✅ Workflow '{name}' removed[/green]")
                    return
            rprint(f"[red]❌ Workflow '{name}' not found[/red]")


# =========================================================================
# Network Scanner Commands - aria network ...
# =========================================================================

try:
    from .network_scanner import NetworkScanner, quick_scan as network_quick_scan, find_mesh_servers
    HAS_NETWORK_SCANNER = True
except ImportError:
    HAS_NETWORK_SCANNER = False

network_app = typer.Typer(
    name="network",
    help="Network discovery and scanning tools",
) if typer else None

if network_app and app:
    app.add_typer(network_app, name="network")
    
    @network_app.command("scan")
    def network_scan(
        target: Optional[str] = typer.Argument(None, help="IP range or network (e.g., 192.168.1.0/24)"),
        ports: bool = typer.Option(True, "--ports/--no-ports", help="Scan common ports"),
        tailscale: bool = typer.Option(True, "--tailscale/--no-tailscale", help="Include Tailscale peers"),
        timeout: float = typer.Option(1.0, "--timeout", "-t", help="Ping timeout in seconds"),
    ):
        """Scan local network for devices
        
        Examples:
          aria network scan
          aria network scan 192.168.1.0/24
          aria network scan --no-ports
        """
        if not HAS_NETWORK_SCANNER:
            rprint("[red]Network scanner module not available[/red]")
            return
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task("Scanning network...", total=None)
            scanner = NetworkScanner(timeout=timeout)
            result = scanner.full_scan(network=target, scan_ports=ports, include_tailscale=tailscale)
        
        # Display results
        table = Table(title=f"Network Scan: {result.network}")
        table.add_column("IP Address", style="cyan")
        table.add_column("Hostname", style="white")
        table.add_column("Type", style="magenta")
        table.add_column("Ports", style="green")
        table.add_column("Tailscale", style="yellow")
        
        for device in result.devices:
            ports_str = ", ".join(str(p.port) for p in device.open_ports[:5])
            if len(device.open_ports) > 5:
                ports_str += f" (+{len(device.open_ports)-5})"
            
            ts_str = f"[green]✓[/green] {device.tailscale_name}" if device.is_tailscale else "[dim]-[/dim]"
            
            table.add_row(
                device.ip,
                device.hostname or "-",
                device.device_type.value if device.device_type else "unknown",
                ports_str or "-",
                ts_str,
            )
        
        console.print(table)
        console.print(f"\n[dim]Scanned in {result.scan_time:.2f}s | {result.alive_hosts}/{result.total_hosts} hosts up[/dim]")
    
    @network_app.command("discover")
    def network_discover():
        """Quick discover devices on local network"""
        if not HAS_NETWORK_SCANNER:
            rprint("[red]Network scanner module not available[/red]")
            return
        
        rprint("[cyan]🔍 Discovering local network...[/cyan]")
        result = network_quick_scan()
        
        for device in result.devices[:20]:  # Limit output
            ts = f" (Tailscale: {device.tailscale_name})" if device.is_tailscale else ""
            rprint(f"  • {device.ip} - {device.hostname or 'unknown'}{ts}")
        
        rprint(f"\n[green]Found {len(result.devices)} devices[/green]")
    
    @network_app.command("mesh-servers")
    def network_mesh_servers():
        """Find ARIA mesh servers on network"""
        if not HAS_NETWORK_SCANNER:
            rprint("[red]Network scanner module not available[/red]")
            return
        
        rprint("[cyan]🔍 Searching for ARIA mesh servers...[/cyan]")
        servers = find_mesh_servers()
        
        if servers:
            table = Table(title="ARIA Mesh Servers")
            table.add_column("Address", style="cyan")
            table.add_column("Port", style="yellow")
            table.add_column("Source", style="dim")
            
            for ip, port, source in servers:
                table.add_row(ip, str(port), source)
            console.print(table)
        else:
            rprint("[yellow]No ARIA mesh servers found[/yellow]")


# =========================================================================
# Device Monitor Commands - aria monitor ...
# =========================================================================

try:
    from .device_monitor import DeviceMonitor, quick_status, top_processes
    HAS_MONITOR = True
except ImportError:
    HAS_MONITOR = False

monitor_app = typer.Typer(
    name="monitor",
    help="System monitoring and performance tracking",
) if typer else None

if monitor_app and app:
    app.add_typer(monitor_app, name="monitor")
    
    @monitor_app.command("status")
    def monitor_status():
        """Show current system status"""
        if not HAS_MONITOR:
            rprint("[red]Monitor module not available (pip install psutil)[/red]")
            return
        
        status = quick_status()
        
        panel_content = f"""
[cyan]CPU:[/cyan] {status['cpu']}
[cyan]Memory:[/cyan] {status['memory']}
[cyan]Disk:[/cyan] {status['disk']}
[cyan]Network:[/cyan] ↑ {status['network']['upload']} / ↓ {status['network']['download']}
[cyan]Uptime:[/cyan] {status['uptime_hours']} hours
[cyan]Processes:[/cyan] {status['process_count']}
[cyan]Status:[/cyan] {'[green]✓ Healthy[/green]' if status['status'] == 'healthy' else '[yellow]⚠ Stressed[/yellow]'}
        """
        console.print(Panel(panel_content.strip(), title="System Status", border_style="cyan"))
    
    @monitor_app.command("top")
    def monitor_top(
        count: int = typer.Option(10, "--count", "-n", help="Number of processes to show"),
        sort: str = typer.Option("memory", "--sort", "-s", help="Sort by: memory, cpu, name"),
    ):
        """Show top processes by resource usage"""
        if not HAS_MONITOR:
            rprint("[red]Monitor module not available (pip install psutil)[/red]")
            return
        
        monitor = DeviceMonitor()
        processes = monitor.get_top_processes(n=count, sort_by=sort)
        
        table = Table(title=f"Top {count} Processes (sorted by {sort})")
        table.add_column("PID", style="dim")
        table.add_column("Name", style="cyan")
        table.add_column("CPU %", style="yellow")
        table.add_column("Memory %", style="magenta")
        table.add_column("Memory", style="green")
        table.add_column("Threads", style="dim")
        
        for p in processes:
            table.add_row(
                str(p.pid),
                p.name[:20],
                f"{p.cpu_percent:.1f}%",
                f"{p.memory_percent:.1f}%",
                f"{p.memory_mb:.0f} MB",
                str(p.threads),
            )
        
        console.print(table)
    
    @monitor_app.command("watch")
    def monitor_watch(
        interval: float = typer.Option(2.0, "--interval", "-i", help="Update interval in seconds"),
    ):
        """Watch system metrics in real-time"""
        if not HAS_MONITOR:
            rprint("[red]Monitor module not available (pip install psutil)[/red]")
            return
        
        import time
        monitor = DeviceMonitor()
        
        rprint("[cyan]Watching system metrics (Ctrl+C to stop)...[/cyan]\n")
        try:
            while True:
                metrics = monitor.get_metrics()
                speed = monitor.get_network_speed()
                
                print(f"\r[{time.strftime('%H:%M:%S')}] "
                      f"CPU: {metrics.cpu_percent:5.1f}% | "
                      f"MEM: {metrics.memory_percent:5.1f}% | "
                      f"DISK: {metrics.disk_percent:5.1f}% | "
                      f"NET: ↑{speed['upload']/1024:6.1f} KB/s ↓{speed['download']/1024:6.1f} KB/s",
                      end="", flush=True)
                time.sleep(interval)
        except KeyboardInterrupt:
            print("\n[Stopped]")


# =========================================================================
# Compression Commands - aria compress ...
# =========================================================================

try:
    from .compression_tools import CompressionEngine, Algorithm, benchmark_data, best_algorithm
    HAS_COMPRESSION = True
except ImportError:
    HAS_COMPRESSION = False

compress_app = typer.Typer(
    name="compress",
    help="Compression tools and benchmarking",
) if typer else None

if compress_app and app:
    app.add_typer(compress_app, name="compress")
    
    @compress_app.command("file")
    def compress_file(
        filepath: Path = typer.Argument(..., help="File to compress"),
        algorithm: str = typer.Option("gzip", "--algo", "-a", help="Algorithm: gzip, lzma, lz4, zstd, brotli"),
        output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    ):
        """Compress a file
        
        Examples:
          aria compress file mydata.json
          aria compress file mydata.json --algo zstd
          aria compress file large.bin -a lz4 -o large.lz4
        """
        if not HAS_COMPRESSION:
            rprint("[red]Compression module not available[/red]")
            return
        
        if not filepath.exists():
            rprint(f"[red]File not found: {filepath}[/red]")
            return
        
        engine = CompressionEngine()
        algo = Algorithm(algorithm)
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task(f"Compressing with {algorithm}...", total=None)
            result = engine.compress_file(filepath, output, algo)
        
        if result.success:
            rprint(f"[green]✅ Compressed successfully[/green]")
            rprint(f"  Original: {result.original_size:,} bytes")
            rprint(f"  Compressed: {result.compressed_size:,} bytes")
            rprint(f"  Ratio: {result.ratio:.2%} ({result.savings_percent:.1f}% saved)")
            rprint(f"  Time: {result.time_seconds:.2f}s")
        else:
            rprint(f"[red]❌ Compression failed: {result.error}[/red]")
    
    @compress_app.command("decompress")
    def compress_decompress(
        filepath: Path = typer.Argument(..., help="File to decompress"),
        output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file path"),
    ):
        """Decompress a file"""
        if not HAS_COMPRESSION:
            rprint("[red]Compression module not available[/red]")
            return
        
        if not filepath.exists():
            rprint(f"[red]File not found: {filepath}[/red]")
            return
        
        engine = CompressionEngine()
        
        try:
            engine.decompress_file(filepath, output)
            rprint(f"[green]✅ Decompressed successfully[/green]")
        except Exception as e:
            rprint(f"[red]❌ Decompression failed: {e}[/red]")
    
    @compress_app.command("benchmark")
    def compress_benchmark(
        filepath: Optional[Path] = typer.Argument(None, help="File to benchmark (uses sample data if not provided)"),
    ):
        """Benchmark compression algorithms"""
        if not HAS_COMPRESSION:
            rprint("[red]Compression module not available[/red]")
            return
        
        engine = CompressionEngine()
        
        if filepath and filepath.exists():
            with open(filepath, "rb") as f:
                data = f.read(10 * 1024 * 1024)  # Max 10MB sample
            rprint(f"[cyan]Benchmarking with {len(data):,} bytes from {filepath}[/cyan]")
        else:
            # Generate sample data
            import random
            data = bytes([random.randint(0, 255) for _ in range(100 * 1024)])
            rprint(f"[cyan]Benchmarking with {len(data):,} bytes of random data[/cyan]")
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task("Running benchmarks...", total=None)
            result = engine.benchmark(data)
        
        table = Table(title="Compression Benchmark")
        table.add_column("Algorithm", style="cyan")
        table.add_column("Ratio", style="green")
        table.add_column("Savings", style="yellow")
        table.add_column("Time", style="dim")
        table.add_column("Speed", style="magenta")
        table.add_column("Status")
        
        for r in result.results:
            status = "[green]✓[/green]" if r.success else f"[red]✗ {r.error}[/red]"
            is_best_ratio = result.best_ratio and r.algorithm == result.best_ratio.algorithm
            is_best_speed = result.best_speed and r.algorithm == result.best_speed.algorithm
            
            algo_name = r.algorithm
            if is_best_ratio:
                algo_name += " [green]★[/green]"
            if is_best_speed:
                algo_name += " [yellow]⚡[/yellow]"
            
            table.add_row(
                algo_name,
                f"{r.ratio:.2%}",
                f"{r.savings_percent:.1f}%",
                f"{r.time_seconds:.3f}s",
                f"{r.original_size / (1024*1024) / max(r.time_seconds, 0.001):.1f} MB/s",
                status,
            )
        
        console.print(table)
        console.print("\n[dim]★ = best ratio | ⚡ = fastest[/dim]")


# =========================================================================
# Security Scanner Commands - aria security ...
# =========================================================================

try:
    from .security_scanner import SecurityScanner, Severity, quick_scan as security_quick_scan
    HAS_SECURITY = True
except ImportError:
    HAS_SECURITY = False

security_app = typer.Typer(
    name="security",
    help="Security scanning and vulnerability detection",
) if typer else None

if security_app and app:
    app.add_typer(security_app, name="security")
    
    @security_app.command("scan")
    def security_scan(
        path: Path = typer.Argument(".", help="Directory to scan"),
        recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Scan recursively"),
    ):
        """Scan code for security issues
        
        Examples:
          aria security scan
          aria security scan ./src
          aria security scan . --no-recursive
        """
        if not HAS_SECURITY:
            rprint("[red]Security scanner module not available[/red]")
            return
        
        if not path.exists():
            rprint(f"[red]Path not found: {path}[/red]")
            return
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task("Scanning for security issues...", total=None)
            scanner = SecurityScanner()
            result = scanner.scan_directory(path, recursive=recursive)
        
        # Summary
        console.print(Panel(
            f"[cyan]Files scanned:[/cyan] {result.files_scanned}\n"
            f"[cyan]Scan time:[/cyan] {result.scan_time:.2f}s\n"
            f"[red]Critical:[/red] {result.critical_count}\n"
            f"[yellow]High:[/yellow] {result.high_count}\n"
            f"[cyan]Total findings:[/cyan] {len(result.findings)}",
            title="Security Scan Results",
            border_style="red" if result.critical_count > 0 else "green",
        ))
        
        # Show findings
        if result.findings:
            table = Table(title="Security Findings")
            table.add_column("Severity", style="cyan")
            table.add_column("Type", style="dim")
            table.add_column("Title", style="white")
            table.add_column("File", style="yellow")
            table.add_column("Line", style="dim")
            
            for f in result.findings[:50]:  # Limit output
                sev_color = {
                    Severity.CRITICAL: "red",
                    Severity.HIGH: "yellow",
                    Severity.MEDIUM: "cyan",
                    Severity.LOW: "dim",
                    Severity.INFO: "dim",
                }.get(f.severity, "white")
                
                table.add_row(
                    f"[{sev_color}]{f.severity.value.upper()}[/{sev_color}]",
                    f.type.value,
                    f.title[:40],
                    Path(f.file_path).name if f.file_path else "-",
                    str(f.line_number) if f.line_number else "-",
                )
            
            console.print(table)
            
            if len(result.findings) > 50:
                rprint(f"\n[dim]Showing 50 of {len(result.findings)} findings[/dim]")
        else:
            rprint("\n[green]✅ No security issues found![/green]")
    
    @security_app.command("secrets")
    def security_secrets(
        path: Path = typer.Argument(".", help="Directory to scan for secrets"),
    ):
        """Scan for hardcoded secrets and credentials"""
        if not HAS_SECURITY:
            rprint("[red]Security scanner module not available[/red]")
            return
        
        if not path.exists():
            rprint(f"[red]Path not found: {path}[/red]")
            return
        
        scanner = SecurityScanner()
        result = scanner.scan_directory(path)
        
        # Filter to secrets only
        secrets = [f for f in result.findings if f.type.value == "secret"]
        
        if secrets:
            rprint(f"\n[red]⚠️ Found {len(secrets)} potential secrets![/red]\n")
            for s in secrets:
                rprint(f"[red]•[/red] {s.title}")
                rprint(f"  [dim]File: {s.file_path}:{s.line_number}[/dim]")
                if s.recommendation:
                    rprint(f"  [cyan]Fix: {s.recommendation}[/cyan]")
                rprint()
        else:
            rprint("[green]✅ No secrets found![/green]")


# =========================================================================
# Sync Engine Commands - aria sync ...
# =========================================================================

try:
    from .sync_engine import SyncEngine, SyncProfile, SyncDirection, ConflictResolution
    HAS_SYNC = True
except ImportError:
    HAS_SYNC = False

sync_app = typer.Typer(
    name="sync",
    help="File synchronization and backup tools",
) if typer else None

if sync_app and app:
    app.add_typer(sync_app, name="sync")
    
    @sync_app.command("run")
    def sync_run(
        source: Path = typer.Argument(..., help="Source directory"),
        destination: Path = typer.Argument(..., help="Destination directory"),
        bidirectional: bool = typer.Option(False, "--bidirectional", "-b", help="Two-way sync"),
        delete: bool = typer.Option(False, "--delete", "-d", help="Delete orphan files in destination"),
        dry_run: bool = typer.Option(False, "--dry-run", "-n", help="Preview changes without applying"),
    ):
        """Sync directories
        
        Examples:
          aria sync run ~/Documents ~/Backup/Documents
          aria sync run ~/Projects ~/Backup --bidirectional
          aria sync run ~/src ~/dest --delete --dry-run
        """
        if not HAS_SYNC:
            rprint("[red]Sync engine module not available[/red]")
            return
        
        if not source.exists():
            rprint(f"[red]Source not found: {source}[/red]")
            return
        
        direction = SyncDirection.BIDIRECTIONAL if bidirectional else SyncDirection.SOURCE_TO_DEST
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task("Syncing files...", total=None)
            engine = SyncEngine()
            result = engine.sync(
                str(source), str(destination),
                direction=direction,
                delete_orphans=delete,
                dry_run=dry_run,
            )
        
        action = "Would sync" if dry_run else "Synced"
        console.print(Panel(
            f"[cyan]{action} in {result.duration:.2f}s[/cyan]\n"
            f"[green]Copied:[/green] {result.files_copied}\n"
            f"[yellow]Updated:[/yellow] {result.files_updated}\n"
            f"[red]Deleted:[/red] {result.files_deleted}\n"
            f"[dim]Skipped:[/dim] {result.files_skipped}\n"
            f"[cyan]Data transferred:[/cyan] {result.bytes_transferred / (1024*1024):.2f} MB",
            title="Sync Result" + (" (Dry Run)" if dry_run else ""),
            border_style="green" if result.success else "red",
        ))
        
        if result.errors:
            rprint("\n[red]Errors:[/red]")
            for err in result.errors[:10]:
                rprint(f"  • {err}")
    
    @sync_app.command("preview")
    def sync_preview(
        source: Path = typer.Argument(..., help="Source directory"),
        destination: Path = typer.Argument(..., help="Destination directory"),
    ):
        """Preview sync changes without applying"""
        if not HAS_SYNC:
            rprint("[red]Sync engine module not available[/red]")
            return
        
        from .sync_engine import preview_sync
        
        changes = preview_sync(str(source), str(destination))
        
        if changes:
            table = Table(title="Pending Sync Changes")
            table.add_column("Action", style="cyan")
            table.add_column("File", style="white")
            table.add_column("Reason", style="dim")
            
            for c in changes[:50]:
                action_color = {
                    "copy": "green",
                    "update": "yellow",
                    "delete": "red",
                    "conflict": "magenta",
                }.get(c["action"], "white")
                
                file_path = c["source"]["relative_path"] if c["source"] else c["dest"]["relative_path"]
                table.add_row(
                    f"[{action_color}]{c['action'].upper()}[/{action_color}]",
                    file_path,
                    c["reason"],
                )
            
            console.print(table)
            
            if len(changes) > 50:
                rprint(f"\n[dim]Showing 50 of {len(changes)} changes[/dim]")
        else:
            rprint("[green]✅ Directories are in sync![/green]")
    
    @sync_app.command("profiles")
    def sync_profiles(
        action: str = typer.Argument("list", help="Action: list, add, remove"),
        name: str = typer.Option(None, "--name", "-n", help="Profile name"),
        source: Optional[Path] = typer.Option(None, "--source", "-s", help="Source directory"),
        destination: Optional[Path] = typer.Option(None, "--dest", "-d", help="Destination directory"),
    ):
        """Manage sync profiles
        
        Examples:
          aria sync profiles list
          aria sync profiles add -n backup -s ~/Documents -d /mnt/backup
        """
        if not HAS_SYNC:
            rprint("[red]Sync engine module not available[/red]")
            return
        
        engine = SyncEngine()
        
        if action == "list":
            profiles = engine.list_profiles()
            if profiles:
                table = Table(title="Sync Profiles")
                table.add_column("Name", style="cyan")
                table.add_column("Source", style="white")
                table.add_column("Destination", style="white")
                table.add_column("Direction", style="yellow")
                
                for p_name in profiles:
                    profile = engine.load_profile(p_name)
                    if profile:
                        table.add_row(
                            profile.name,
                            profile.source,
                            profile.destination,
                            profile.direction.value,
                        )
                console.print(table)
            else:
                rprint("[yellow]No sync profiles saved[/yellow]")
        
        elif action == "add":
            if not all([name, source, destination]):
                rprint("[red]Name, source, and destination required[/red]")
                return
            
            profile = SyncProfile(name=name, source=str(source), destination=str(destination))
            engine.save_profile(profile)
            rprint(f"[green]✅ Profile '{name}' saved[/green]")
        
        elif action == "remove":
            if not name:
                rprint("[red]Profile name required[/red]")
                return
            
            if engine.delete_profile(name):
                rprint(f"[green]✅ Profile '{name}' removed[/green]")
            else:
                rprint(f"[red]Profile '{name}' not found[/red]")


# =========================================================================
# QR Code Commands - aria qr ...
# =========================================================================

try:
    from .qr_connect import (
        QRGenerator, MeshConnectionInfo, QRFormat, ConnectionType,
        generate_mesh_qr, print_mesh_qr, save_mesh_qr
    )
    HAS_QR = True
except ImportError:
    HAS_QR = False

qr_app = typer.Typer(
    name="qr",
    help="QR code generation for mesh network connections",
) if typer else None

if qr_app and app:
    app.add_typer(qr_app, name="qr")
    
    @qr_app.command("generate")
    def qr_generate(
        host: str = typer.Argument(..., help="Host address (IP or hostname)"),
        port: int = typer.Option(8765, "--port", "-p", help="Port number"),
        name: str = typer.Option("", "--name", "-n", help="Friendly name"),
        tailscale: str = typer.Option("", "--tailscale", "-t", help="Tailscale IP if available"),
        output: str = typer.Option("terminal", "--output", "-o", help="Output: terminal, png, svg"),
        save: Optional[Path] = typer.Option(None, "--save", "-s", help="Save to file"),
    ):
        """Generate QR code for mesh connection
        
        Examples:
          aria qr generate 192.168.1.100
          aria qr generate horus.tail12345.ts.net -p 8765 -n "Main PC"
          aria qr generate 100.64.0.1 --output png --save connection.png
        """
        if not HAS_QR:
            rprint("[red]QR code module not available. Install with: pip install qrcode[pil][/red]")
            return
        
        generator = QRGenerator()
        
        # Determine output format
        format_map = {
            "terminal": QRFormat.TERMINAL,
            "utf8": QRFormat.UTF8,
            "ascii": QRFormat.ASCII,
            "png": QRFormat.PNG,
            "svg": QRFormat.SVG,
        }
        qr_format = format_map.get(output.lower(), QRFormat.TERMINAL)
        
        result = generator.generate_mesh_qr(
            host=host,
            port=port,
            name=name or host,
            tailscale_ip=tailscale if tailscale else None,
            output_format=qr_format,
        )
        
        if result.success:
            if save:
                saved = generator.save_qr(result, str(save))
                if saved:
                    rprint(f"[green]✅ QR code saved to: {save}[/green]")
                else:
                    rprint("[red]Failed to save QR code[/red]")
            else:
                generator.print_qr(result, title=f"Mesh Connection: {name or host}")
        else:
            rprint(f"[red]Failed to generate QR: {result.error}[/red]")
    
    @qr_app.command("show")
    def qr_show(
        url: str = typer.Argument(..., help="URL or connection string to encode"),
        compact: bool = typer.Option(False, "--compact", "-c", help="Use compact UTF-8 rendering"),
    ):
        """Show QR code in terminal
        
        Examples:
          aria qr show "https://example.com"
          aria qr show "aria://connect?host=192.168.1.1&port=8765"
        """
        if not HAS_QR:
            rprint("[red]QR code module not available[/red]")
            return
        
        generator = QRGenerator()
        qr_format = QRFormat.UTF8 if compact else QRFormat.TERMINAL
        result = generator.generate_url_qr(url, qr_format)
        
        if result.success:
            generator.print_qr(result)
        else:
            rprint(f"[red]Failed to generate QR: {result.error}[/red]")
    
    @qr_app.command("mesh")
    def qr_mesh_auto(
        port: int = typer.Option(8765, "--port", "-p", help="Mesh server port"),
        include_tailscale: bool = typer.Option(True, "--tailscale/--no-tailscale", help="Include Tailscale IP"),
    ):
        """Auto-generate QR for local mesh server
        
        Automatically detects local IP and Tailscale addresses.
        
        Examples:
          aria qr mesh
          aria qr mesh --port 9000
          aria qr mesh --no-tailscale
        """
        if not HAS_QR:
            rprint("[red]QR code module not available[/red]")
            return
        
        import socket
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        
        # Try to get Tailscale IP
        tailscale_ip = None
        if include_tailscale:
            try:
                import subprocess
                result = subprocess.run(
                    ["tailscale", "ip", "-4"],
                    capture_output=True, text=True, timeout=5
                )
                if result.returncode == 0:
                    tailscale_ip = result.stdout.strip()
            except:
                pass
        
        generator = QRGenerator()
        result = generator.generate_mesh_qr(
            host=local_ip,
            port=port,
            name=hostname,
            tailscale_ip=tailscale_ip,
        )
        
        if result.success:
            info_lines = [
                f"[cyan]Host:[/cyan] {local_ip}",
                f"[cyan]Port:[/cyan] {port}",
                f"[cyan]Name:[/cyan] {hostname}",
            ]
            if tailscale_ip:
                info_lines.append(f"[cyan]Tailscale:[/cyan] {tailscale_ip}")
            
            console.print(Panel("\n".join(info_lines), title="Connection Info", border_style="blue"))
            generator.print_qr(result, title="Scan to Connect")
        else:
            rprint(f"[red]Failed: {result.error}[/red]")


# =========================================================================
# Daemon Scout Commands - aria daemon ...
# =========================================================================

try:
    from .daemon_scout import (
        ScoutDaemon, PeerIdentity, Peer, PeerState,
        create_identity, start_scout, discover_peers
    )
    HAS_SCOUT = True
except ImportError:
    HAS_SCOUT = False

daemon_app = typer.Typer(
    name="daemon",
    help="Mesh daemon for peer discovery and handshaking",
) if typer else None

# Global scout instance
_scout_instance: Optional["ScoutDaemon"] = None

if daemon_app and app:
    app.add_typer(daemon_app, name="daemon")
    
    @daemon_app.command("start")
    def daemon_start(
        name: str = typer.Option("", "--name", "-n", help="Node name (defaults to hostname)"),
        port: int = typer.Option(8766, "--port", "-p", help="Daemon port"),
        foreground: bool = typer.Option(False, "--foreground", "-f", help="Run in foreground"),
    ):
        """Start the scout daemon
        
        The daemon discovers and handshakes with other ARIA nodes.
        
        Examples:
          aria daemon start
          aria daemon start -n "MyPC" -p 8800
          aria daemon start --foreground
        """
        global _scout_instance
        
        if not HAS_SCOUT:
            rprint("[red]Scout daemon module not available[/red]")
            return
        
        import socket
        node_name = name or socket.gethostname()
        
        rprint(f"[cyan]Starting Scout Daemon...[/cyan]")
        rprint(f"  Name: {node_name}")
        rprint(f"  Port: {port}")
        
        identity = create_identity(node_name, port)
        scout = ScoutDaemon(identity, port)
        
        # Register callbacks
        scout.on_peer_discovered(lambda p: rprint(f"[green]📡 Discovered: {p.identity.name} ({p.identity.host})[/green]"))
        scout.on_peer_connected(lambda p: rprint(f"[cyan]🤝 Connected: {p.identity.name}[/cyan]"))
        scout.on_peer_disconnected(lambda p: rprint(f"[yellow]👋 Disconnected: {p.identity.name}[/yellow]"))
        
        scout.start()
        _scout_instance = scout
        
        rprint(f"[green]✅ Scout Daemon started (ID: {identity.peer_id})[/green]")
        
        if foreground:
            rprint("[dim]Press Ctrl+C to stop[/dim]")
            try:
                import time
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                scout.stop()
                rprint("\n[yellow]Daemon stopped[/yellow]")
    
    @daemon_app.command("stop")
    def daemon_stop():
        """Stop the scout daemon"""
        global _scout_instance
        
        if _scout_instance:
            _scout_instance.stop()
            _scout_instance = None
            rprint("[green]✅ Scout Daemon stopped[/green]")
        else:
            rprint("[yellow]No daemon running[/yellow]")
    
    @daemon_app.command("status")
    def daemon_status():
        """Show daemon status"""
        global _scout_instance
        
        if _scout_instance and _scout_instance._running:
            peers = _scout_instance.get_connected_peers()
            
            console.print(Panel(
                f"[green]● Running[/green]\n"
                f"[cyan]ID:[/cyan] {_scout_instance.identity.peer_id}\n"
                f"[cyan]Name:[/cyan] {_scout_instance.identity.name}\n"
                f"[cyan]Port:[/cyan] {_scout_instance.port}\n"
                f"[cyan]Connected Peers:[/cyan] {len(peers)}",
                title="Scout Daemon Status",
                border_style="green",
            ))
        else:
            console.print(Panel(
                "[red]● Stopped[/red]\n"
                "[dim]Start with: aria daemon start[/dim]",
                title="Scout Daemon Status",
                border_style="red",
            ))
    
    @daemon_app.command("discover")
    def daemon_discover(
        timeout: float = typer.Option(5.0, "--timeout", "-t", help="Discovery timeout in seconds"),
    ):
        """Discover peers on the network
        
        Examples:
          aria daemon discover
          aria daemon discover -t 10
        """
        if not HAS_SCOUT:
            rprint("[red]Scout daemon module not available[/red]")
            return
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task(f"Scanning for {timeout}s...", total=None)
            peers = discover_peers(timeout)
        
        if peers:
            table = Table(title="Discovered Peers")
            table.add_column("Name", style="cyan")
            table.add_column("Host", style="white")
            table.add_column("Port", style="yellow")
            table.add_column("Method", style="dim")
            table.add_column("Tailscale", style="green")
            
            for peer in peers:
                table.add_row(
                    peer.identity.name,
                    peer.identity.host,
                    str(peer.identity.port),
                    peer.discovery_method.value,
                    "✓" if peer.is_tailscale else "",
                )
            
            console.print(table)
        else:
            rprint("[yellow]No peers discovered[/yellow]")
    
    @daemon_app.command("peers")
    def daemon_peers(
        all_peers: bool = typer.Option(False, "--all", "-a", help="Show all peers (including disconnected)"),
    ):
        """List known peers"""
        global _scout_instance
        
        if not _scout_instance:
            if not HAS_SCOUT:
                rprint("[red]Scout daemon module not available[/red]")
                return
            
            # Create temp daemon to load saved peers
            identity = create_identity("temp")
            _scout_instance = ScoutDaemon(identity)
        
        peers = list(_scout_instance.peers.values())
        
        if not all_peers:
            peers = [p for p in peers if p.state in [PeerState.CONNECTED, PeerState.AUTHENTICATED]]
        
        if peers:
            table = Table(title="Known Peers")
            table.add_column("Name", style="cyan")
            table.add_column("Host", style="white")
            table.add_column("State", style="yellow")
            table.add_column("Last Seen", style="dim")
            table.add_column("Latency", style="green")
            
            for peer in sorted(peers, key=lambda p: p.last_seen, reverse=True):
                state_colors = {
                    PeerState.CONNECTED: "green",
                    PeerState.AUTHENTICATED: "cyan",
                    PeerState.DISCONNECTED: "yellow",
                    PeerState.FAILED: "red",
                }
                state_color = state_colors.get(peer.state, "white")
                
                # Format last seen
                from datetime import datetime
                last_seen = datetime.fromtimestamp(peer.last_seen).strftime("%H:%M:%S")
                
                table.add_row(
                    peer.identity.name,
                    peer.address,
                    f"[{state_color}]{peer.state.value}[/{state_color}]",
                    last_seen,
                    f"{peer.latency_ms:.1f}ms" if peer.latency_ms > 0 else "-",
                )
            
            console.print(table)
        else:
            rprint("[yellow]No peers found. Run 'aria daemon discover' first.[/yellow]")
    
    @daemon_app.command("connect")
    def daemon_connect(
        host: str = typer.Argument(..., help="Host address to connect to"),
        port: int = typer.Option(8766, "--port", "-p", help="Port number"),
    ):
        """Manually connect to a peer
        
        Examples:
          aria daemon connect 192.168.1.100
          aria daemon connect 100.64.0.5 -p 8800
        """
        global _scout_instance
        
        if not HAS_SCOUT:
            rprint("[red]Scout daemon module not available[/red]")
            return
        
        if not _scout_instance:
            identity = create_identity("temp_client")
            _scout_instance = ScoutDaemon(identity)
        
        rprint(f"[cyan]Connecting to {host}:{port}...[/cyan]")
        
        peer = _scout_instance.add_peer_manual(host, port)
        result = _scout_instance.handshake(peer)
        
        from .daemon_scout import HandshakeResult
        if result == HandshakeResult.SUCCESS:
            rprint(f"[green]✅ Connected to {peer.identity.name}[/green]")
            rprint(f"  Latency: {peer.latency_ms:.1f}ms")
        else:
            rprint(f"[red]❌ Connection failed: {result.value}[/red]")


# =========================================================================
# Bluetooth Commands - aria bluetooth ...
# =========================================================================

try:
    from .bluetooth_mesh import (
        BluetoothManager, BluetoothDevice, DeviceType, ConnectionState,
        scan_devices, connect_by_name, list_paired, get_audio_devices
    )
    HAS_BLUETOOTH = True
except ImportError:
    HAS_BLUETOOTH = False

bluetooth_app = typer.Typer(
    name="bluetooth",
    help="Bluetooth device management and mesh integration",
) if typer else None

# Global bluetooth manager
_bt_manager: Optional["BluetoothManager"] = None

def _get_bt_manager() -> "BluetoothManager":
    global _bt_manager
    if _bt_manager is None:
        _bt_manager = BluetoothManager()
    return _bt_manager

if bluetooth_app and app:
    app.add_typer(bluetooth_app, name="bluetooth")
    
    @bluetooth_app.command("scan")
    def bt_scan(
        duration: float = typer.Option(10.0, "--duration", "-d", help="Scan duration in seconds"),
        ble: bool = typer.Option(True, "--ble/--no-ble", help="Scan for BLE devices"),
        classic: bool = typer.Option(True, "--classic/--no-classic", help="Scan for classic devices"),
    ):
        """Scan for Bluetooth devices
        
        Discovers nearby Bluetooth devices including:
        - Headphones, earbuds, speakers
        - Apple Watch, smartwatches
        - Ray-Ban Meta glasses
        - Phones, tablets, computers
        
        Examples:
          aria bluetooth scan
          aria bluetooth scan -d 30
          aria bluetooth scan --ble --no-classic
        """
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            rprint("[dim]Install with: pip install bleak[/dim]")
            return
        
        import asyncio
        manager = _get_bt_manager()
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task(f"Scanning for {duration}s...", total=None)
            result = asyncio.run(
                manager.scan(duration, ble=ble, classic=classic)
            )
        
        if result.devices:
            table = Table(title=f"Discovered Devices ({len(result.devices)})")
            table.add_column("Name", style="cyan")
            table.add_column("Type", style="yellow")
            table.add_column("Address", style="dim")
            table.add_column("Signal", style="green")
            table.add_column("State", style="white")
            
            # Sort by signal strength
            sorted_devices = sorted(result.devices, key=lambda d: d.rssi, reverse=True)
            
            for device in sorted_devices:
                type_emoji = {
                    DeviceType.HEADPHONES: "🎧",
                    DeviceType.EARBUDS: "🎵",
                    DeviceType.SPEAKER: "🔊",
                    DeviceType.SMARTWATCH: "⌚",
                    DeviceType.SMART_GLASSES: "👓",
                    DeviceType.PHONE_IOS: "📱",
                    DeviceType.PHONE_ANDROID: "📱",
                    DeviceType.LAPTOP: "💻",
                    DeviceType.DESKTOP: "🖥️",
                    DeviceType.CHROMEBOOK: "💻",
                }.get(device.device_type, "📶")
                
                state_color = {
                    ConnectionState.CONNECTED: "green",
                    ConnectionState.PAIRED: "cyan",
                    ConnectionState.DISCONNECTED: "yellow",
                }.get(device.state, "white")
                
                table.add_row(
                    f"{type_emoji} {device.display_name}",
                    device.device_type.value.replace("_", " ").title(),
                    device.address[:17] + "..." if len(device.address) > 20 else device.address,
                    f"{device.rssi} dBm ({device.signal_strength})" if device.rssi else "-",
                    f"[{state_color}]{device.state.value}[/{state_color}]",
                )
            
            console.print(table)
            
            if result.errors:
                rprint("\n[yellow]Warnings:[/yellow]")
                for err in result.errors:
                    rprint(f"  [dim]{err}[/dim]")
        else:
            rprint("[yellow]No devices found[/yellow]")
            if result.errors:
                for err in result.errors:
                    rprint(f"[dim]{err}[/dim]")
    
    @bluetooth_app.command("connect")
    def bt_connect(
        name: str = typer.Argument(..., help="Device name or address to connect"),
    ):
        """Connect to a Bluetooth device
        
        Examples:
          aria bluetooth connect "AirPods Pro"
          aria bluetooth connect "Apple Watch"
          aria bluetooth connect "Ray-Ban"
        """
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            return
        
        import asyncio
        manager = _get_bt_manager()
        
        # Find device
        device = manager.get_device_by_name(name)
        
        if not device:
            rprint(f"[yellow]Device '{name}' not found in cache, scanning...[/yellow]")
            asyncio.run(manager.scan(5.0))
            device = manager.get_device_by_name(name)
        
        if not device:
            rprint(f"[red]Device '{name}' not found[/red]")
            rprint("[dim]Try running 'aria bluetooth scan' first[/dim]")
            return
        
        rprint(f"[cyan]Connecting to {device.display_name}...[/cyan]")
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            progress.add_task("Connecting...", total=None)
            result = asyncio.run(manager.connect(device))
        
        if result.success:
            rprint(f"[green]✅ Connected to {device.display_name}[/green]")
            if result.connected_profiles:
                profiles = ", ".join(p.value.upper() for p in result.connected_profiles)
                rprint(f"  [dim]Profiles: {profiles}[/dim]")
            rprint(f"  [dim]Latency: {result.latency_ms:.1f}ms[/dim]")
        else:
            rprint(f"[red]❌ Failed to connect: {result.error}[/red]")
    
    @bluetooth_app.command("disconnect")
    def bt_disconnect(
        name: str = typer.Argument(..., help="Device name to disconnect"),
    ):
        """Disconnect from a Bluetooth device"""
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            return
        
        import asyncio
        manager = _get_bt_manager()
        device = manager.get_device_by_name(name)
        
        if not device:
            rprint(f"[red]Device '{name}' not found[/red]")
            return
        
        success = asyncio.run(manager.disconnect(device))
        
        if success:
            rprint(f"[green]✅ Disconnected from {device.display_name}[/green]")
        else:
            rprint(f"[red]Failed to disconnect[/red]")
    
    @bluetooth_app.command("pair")
    def bt_pair(
        name: str = typer.Argument(..., help="Device name to pair with"),
        pin: str = typer.Option("", "--pin", "-p", help="Pairing PIN if required"),
    ):
        """Pair with a Bluetooth device
        
        Examples:
          aria bluetooth pair "AirPods Pro"
          aria bluetooth pair "Keyboard" --pin 1234
        """
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            return
        
        import asyncio
        manager = _get_bt_manager()
        
        device = manager.get_device_by_name(name)
        if not device:
            rprint(f"[yellow]Scanning for '{name}'...[/yellow]")
            asyncio.run(manager.scan(5.0))
            device = manager.get_device_by_name(name)
        
        if not device:
            rprint(f"[red]Device '{name}' not found[/red]")
            return
        
        rprint(f"[cyan]Pairing with {device.display_name}...[/cyan]")
        rprint("[dim]Check device for pairing prompt[/dim]")
        
        success = asyncio.run(manager.pair(device, pin))
        
        if success:
            rprint(f"[green]✅ Paired with {device.display_name}[/green]")
        else:
            rprint(f"[red]Pairing failed[/red]")
    
    @bluetooth_app.command("list")
    def bt_list(
        connected_only: bool = typer.Option(False, "--connected", "-c", help="Show only connected"),
        paired_only: bool = typer.Option(False, "--paired", "-p", help="Show only paired"),
        device_type: str = typer.Option("", "--type", "-t", help="Filter by type: headphones, watch, glasses, phone"),
    ):
        """List known Bluetooth devices
        
        Examples:
          aria bluetooth list
          aria bluetooth list --connected
          aria bluetooth list --type headphones
        """
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            return
        
        manager = _get_bt_manager()
        
        if connected_only:
            devices = manager.get_connected()
        elif paired_only:
            devices = manager.get_paired()
        elif device_type:
            type_map = {
                "headphones": DeviceType.HEADPHONES,
                "earbuds": DeviceType.EARBUDS,
                "speaker": DeviceType.SPEAKER,
                "watch": DeviceType.SMARTWATCH,
                "smartwatch": DeviceType.SMARTWATCH,
                "glasses": DeviceType.SMART_GLASSES,
                "phone": DeviceType.PHONE_IOS,
                "iphone": DeviceType.PHONE_IOS,
                "android": DeviceType.PHONE_ANDROID,
                "laptop": DeviceType.LAPTOP,
                "desktop": DeviceType.DESKTOP,
                "chromebook": DeviceType.CHROMEBOOK,
            }
            dt = type_map.get(device_type.lower())
            if dt:
                devices = manager.get_by_type(dt)
            else:
                devices = list(manager.devices.values())
        else:
            devices = list(manager.devices.values())
        
        if devices:
            table = Table(title="Bluetooth Devices")
            table.add_column("Name", style="cyan")
            table.add_column("Type", style="yellow")
            table.add_column("State", style="white")
            table.add_column("Paired", style="green")
            table.add_column("Mesh", style="magenta")
            
            for device in sorted(devices, key=lambda d: d.last_seen, reverse=True):
                state_color = {
                    ConnectionState.CONNECTED: "green",
                    ConnectionState.PAIRED: "cyan",
                }.get(device.state, "dim")
                
                table.add_row(
                    device.display_name,
                    device.device_type.value.replace("_", " ").title(),
                    f"[{state_color}]{device.state.value}[/{state_color}]",
                    "✓" if device.paired else "",
                    "✓" if device.mesh_enabled else "",
                )
            
            console.print(table)
        else:
            rprint("[yellow]No devices found[/yellow]")
            rprint("[dim]Run 'aria bluetooth scan' to discover devices[/dim]")
    
    @bluetooth_app.command("audio")
    def bt_audio(
        action: str = typer.Argument("list", help="Action: list, route"),
        device: str = typer.Option("", "--device", "-d", help="Device name for routing"),
    ):
        """Manage Bluetooth audio devices
        
        Examples:
          aria bluetooth audio list
          aria bluetooth audio route -d "AirPods Pro"
        """
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            return
        
        manager = _get_bt_manager()
        
        if action == "list":
            audio_devices = get_audio_devices()
            
            if audio_devices:
                table = Table(title="Audio Devices")
                table.add_column("Name", style="cyan")
                table.add_column("Type", style="yellow")
                table.add_column("State", style="white")
                table.add_column("Signal", style="green")
                
                for dev in audio_devices:
                    state_color = "green" if dev.state == ConnectionState.CONNECTED else "dim"
                    table.add_row(
                        dev.display_name,
                        dev.device_type.value,
                        f"[{state_color}]{dev.state.value}[/{state_color}]",
                        f"{dev.rssi} dBm" if dev.rssi else "-",
                    )
                
                console.print(table)
            else:
                rprint("[yellow]No audio devices found[/yellow]")
        
        elif action == "route":
            if not device:
                rprint("[red]Device name required: --device 'Name'[/red]")
                return
            
            # On Windows, use PowerShell to route audio
            if sys.platform == "win32":
                rprint(f"[cyan]Routing audio to {device}...[/cyan]")
                rprint("[dim]Use Windows Sound Settings to complete audio routing[/dim]")
            else:
                rprint("[yellow]Audio routing requires platform-specific tools[/yellow]")
    
    @bluetooth_app.command("mesh")
    def bt_mesh(
        action: str = typer.Argument("status", help="Action: status, enable, disable"),
        device: str = typer.Option("", "--device", "-d", help="Device name"),
    ):
        """Manage Bluetooth mesh for devices
        
        Enable mesh networking to sync data across devices.
        
        Examples:
          aria bluetooth mesh status
          aria bluetooth mesh enable -d "Apple Watch"
        """
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            return
        
        manager = _get_bt_manager()
        
        if action == "status":
            mesh_devices = [d for d in manager.devices.values() if d.mesh_enabled]
            
            if mesh_devices:
                console.print(Panel(
                    f"[green]Mesh Enabled:[/green] {len(mesh_devices)} devices\n" +
                    "\n".join(f"  • {d.display_name}" for d in mesh_devices),
                    title="Bluetooth Mesh Status",
                    border_style="magenta",
                ))
            else:
                rprint("[yellow]No devices have mesh enabled[/yellow]")
                rprint("[dim]Enable with: aria bluetooth mesh enable -d 'Device Name'[/dim]")
        
        elif action == "enable":
            if not device:
                rprint("[red]Device name required[/red]")
                return
            
            dev = manager.get_device_by_name(device)
            if dev:
                manager.enable_mesh(dev)
                rprint(f"[green]✅ Mesh enabled for {dev.display_name}[/green]")
            else:
                rprint(f"[red]Device '{device}' not found[/red]")
        
        elif action == "disable":
            if not device:
                rprint("[red]Device name required[/red]")
                return
            
            dev = manager.get_device_by_name(device)
            if dev:
                dev.mesh_enabled = False
                manager._save_devices()
                rprint(f"[green]✅ Mesh disabled for {dev.display_name}[/green]")
            else:
                rprint(f"[red]Device '{device}' not found[/red]")
    
    @bluetooth_app.command("forget")
    def bt_forget(
        name: str = typer.Argument(..., help="Device name to forget"),
    ):
        """Forget a paired device"""
        if not HAS_BLUETOOTH:
            rprint("[red]Bluetooth module not available[/red]")
            return
        
        manager = _get_bt_manager()
        device = manager.get_device_by_name(name)
        
        if not device:
            rprint(f"[red]Device '{name}' not found[/red]")
            return
        
        if Confirm.ask(f"Forget [cyan]{device.display_name}[/cyan]?"):
            if manager.forget(device):
                rprint(f"[green]✅ Device forgotten[/green]")
            else:
                rprint("[red]Failed to forget device[/red]")


def main():
    """Main entry point"""
    # Ensure UTF-8 output
    if sys.platform == 'win32':
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    
    if app:
        app()
    else:
        # Fallback for minimal install
        print("ARIA CLI v1.0.8")
        print("Install with: pip install aria-cli[full]")
        print("\nRunning minimal mode...")
        cli = AriaCLI(output_format=OutputFormat.PLAIN, use_llm=False)
        cli.interactive_mode()


if __name__ == "__main__":
    main()
