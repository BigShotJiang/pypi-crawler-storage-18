"""
ARIA Q-Hypercube Mesh Network v1.0.0

64-Directional Fully-Connected Agent Mesh System

Architecture:
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │                    64-DIRECTIONAL HYPERCUBE MESH                            │
  │                                                                             │
  │    ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐     │
  │    │ A01 │◄─►│ A02 │◄─►│ A03 │◄─►│ A04 │◄─►│ ... │◄─►│ A63 │◄─►│ A64 │     │
  │    └──┬──┘   └──┬──┘   └──┬──┘   └──┬──┘   └──┬──┘   └──┬──┘   └──┬──┘     │
  │       │         │         │         │         │         │         │         │
  │       └─────────┴─────────┴─────────┴─────────┴─────────┴─────────┘         │
  │              ALL AGENTS CONNECTED TO ALL AGENTS                              │
  └─────────────────────────────────────────────────────────────────────────────┘

Execution Flow:
  1. Agent 1 broadcasts task to ALL 64 folders simultaneously
  2. Agents 1-64 work in PARALLEL on their assigned work
  3. Results MERGE at synchronization barrier
  4. Combined output forms CHAINED PARALLEL result
  5. Next stage begins (if multi-stage pipeline)

Key Concepts:
  - HyperFolder: A folder with 64 directional ports (p01-p64)
  - HyperAgent: An agent occupying one folder slot
  - Broadcast: One agent → All 64 folders simultaneously
  - ParallelRun: All agents execute in parallel
  - MergeBarrier: Synchronization point for combining results
  - ChainedParallel: Multi-stage parallel→merge pipelines
"""

import asyncio
import json
import os
import time
import uuid
import shutil
from pathlib import Path
from typing import Optional, List, Dict, Any, Set, Tuple, Callable, Union
from dataclasses import dataclass, field
from enum import Enum, auto
from datetime import datetime
from collections import defaultdict
import queue
import socket
import threading
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed

# =============================================================================
# CONSTANTS
# =============================================================================

HYPERCUBE_DIMENSION = 64  # 64-directional mesh
MAX_AGENTS = 64
DEFAULT_MESH_ROOT = Path.home() / ".aria" / "hypercube"
MESSAGE_EXPIRY_SECONDS = 600  # 10 minutes for parallel ops
HEARTBEAT_INTERVAL = 2.0  # Fast heartbeats for parallel sync
MERGE_TIMEOUT = 300.0  # 5 minutes max wait for merge
PARALLEL_WORKERS = 64  # Max parallel workers


# =============================================================================
# ENUMS
# =============================================================================

class HyperPort(Enum):
    """64 directional ports - each agent has direct path to all others"""
    # Generate P01 through P64
    P01 = "p01"; P02 = "p02"; P03 = "p03"; P04 = "p04"
    P05 = "p05"; P06 = "p06"; P07 = "p07"; P08 = "p08"
    P09 = "p09"; P10 = "p10"; P11 = "p11"; P12 = "p12"
    P13 = "p13"; P14 = "p14"; P15 = "p15"; P16 = "p16"
    P17 = "p17"; P18 = "p18"; P19 = "p19"; P20 = "p20"
    P21 = "p21"; P22 = "p22"; P23 = "p23"; P24 = "p24"
    P25 = "p25"; P26 = "p26"; P27 = "p27"; P28 = "p28"
    P29 = "p29"; P30 = "p30"; P31 = "p31"; P32 = "p32"
    P33 = "p33"; P34 = "p34"; P35 = "p35"; P36 = "p36"
    P37 = "p37"; P38 = "p38"; P39 = "p39"; P40 = "p40"
    P41 = "p41"; P42 = "p42"; P43 = "p43"; P44 = "p44"
    P45 = "p45"; P46 = "p46"; P47 = "p47"; P48 = "p48"
    P49 = "p49"; P50 = "p50"; P51 = "p51"; P52 = "p52"
    P53 = "p53"; P54 = "p54"; P55 = "p55"; P56 = "p56"
    P57 = "p57"; P58 = "p58"; P59 = "p59"; P60 = "p60"
    P61 = "p61"; P62 = "p62"; P63 = "p63"; P64 = "p64"
    
    # Special ports
    BROADCAST = "broadcast"    # All directions at once
    SELF = "self"              # Local processing
    MERGE = "merge"            # Result aggregation
    
    @classmethod
    def get_port(cls, num: int) -> 'HyperPort':
        """Get port by number (1-64)"""
        return cls(f"p{num:02d}")
    
    @classmethod
    def all_numbered(cls) -> List['HyperPort']:
        """Get all 64 numbered ports"""
        return [cls.get_port(i) for i in range(1, 65)]


class AgentState(Enum):
    """State of a hypercube agent"""
    IDLE = "idle"
    RECEIVING = "receiving"
    PROCESSING = "processing"
    BROADCASTING = "broadcasting"
    WAITING_MERGE = "waiting_merge"
    MERGING = "merging"
    COMPLETED = "completed"
    ERROR = "error"


class MergeStrategy(Enum):
    """How to combine parallel results"""
    CONCAT = "concat"          # Concatenate all outputs
    REDUCE = "reduce"          # Apply reducer function
    VOTE = "vote"              # Majority voting
    FIRST = "first"            # First to complete
    BEST = "best"              # Best by metric
    ALL = "all"                # Collect all results
    TREE = "tree"              # Hierarchical merge


class ChainStage(Enum):
    """Stage in a chained parallel run"""
    SCATTER = "scatter"        # Distribute to all agents
    PARALLEL = "parallel"      # All agents work simultaneously
    BARRIER = "barrier"        # Wait for all to complete
    MERGE = "merge"            # Combine results
    FORWARD = "forward"        # Pass to next stage


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class HyperMessage:
    """A message in the hypercube mesh"""
    id: str
    source_agent: int          # Agent number (1-64)
    target_agents: List[int]   # Target agent numbers (empty = broadcast all)
    port: HyperPort
    payload: Dict[str, Any]
    timestamp: float
    stage_id: Optional[str] = None     # For chained runs
    chain_id: Optional[str] = None     # For multi-stage chains
    sequence: int = 0                   # Order in chain
    requires_merge: bool = False
    merge_strategy: MergeStrategy = MergeStrategy.ALL
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "source_agent": self.source_agent,
            "target_agents": self.target_agents,
            "port": self.port.value,
            "payload": self.payload,
            "timestamp": self.timestamp,
            "stage_id": self.stage_id,
            "chain_id": self.chain_id,
            "sequence": self.sequence,
            "requires_merge": self.requires_merge,
            "merge_strategy": self.merge_strategy.value,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'HyperMessage':
        return cls(
            id=data["id"],
            source_agent=data["source_agent"],
            target_agents=data.get("target_agents", []),
            port=HyperPort(data["port"]),
            payload=data["payload"],
            timestamp=data["timestamp"],
            stage_id=data.get("stage_id"),
            chain_id=data.get("chain_id"),
            sequence=data.get("sequence", 0),
            requires_merge=data.get("requires_merge", False),
            merge_strategy=MergeStrategy(data.get("merge_strategy", "all")),
        )
    
    @property
    def is_broadcast(self) -> bool:
        return len(self.target_agents) == 0 or self.port == HyperPort.BROADCAST
    
    @property
    def is_expired(self) -> bool:
        return (time.time() - self.timestamp) > MESSAGE_EXPIRY_SECONDS


@dataclass
class AgentWork:
    """Work unit assigned to an agent"""
    agent_id: int
    task_id: str
    command: str
    task_type: str            # "shell", "python", "function", "agent"
    payload: Dict[str, Any]
    chain_id: Optional[str]
    stage: int
    timeout: float = 300.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "task_id": self.task_id,
            "command": self.command,
            "task_type": self.task_type,
            "payload": self.payload,
            "chain_id": self.chain_id,
            "stage": self.stage,
            "timeout": self.timeout,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentWork':
        return cls(
            agent_id=data["agent_id"],
            task_id=data["task_id"],
            command=data["command"],
            task_type=data["task_type"],
            payload=data["payload"],
            chain_id=data.get("chain_id"),
            stage=data.get("stage", 0),
            timeout=data.get("timeout", 300.0),
        )


@dataclass
class AgentResult:
    """Result from an agent's work"""
    agent_id: int
    task_id: str
    success: bool
    output: Any
    error: Optional[str]
    started_at: float
    completed_at: float
    metrics: Dict[str, float] = field(default_factory=dict)
    
    @property
    def duration(self) -> float:
        return self.completed_at - self.started_at
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "task_id": self.task_id,
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "duration": self.duration,
            "metrics": self.metrics,
        }


@dataclass
class MergedResult:
    """Combined result from parallel agents"""
    chain_id: str
    stage: int
    merge_strategy: MergeStrategy
    agent_results: List[AgentResult]
    merged_output: Any
    total_agents: int
    successful_agents: int
    failed_agents: int
    merge_time: float
    
    @property
    def success_rate(self) -> float:
        if self.total_agents == 0:
            return 0.0
        return self.successful_agents / self.total_agents
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "chain_id": self.chain_id,
            "stage": self.stage,
            "merge_strategy": self.merge_strategy.value,
            "agent_results": [r.to_dict() for r in self.agent_results],
            "merged_output": self.merged_output,
            "total_agents": self.total_agents,
            "successful_agents": self.successful_agents,
            "failed_agents": self.failed_agents,
            "success_rate": self.success_rate,
            "merge_time": self.merge_time,
        }


@dataclass
class ChainedRun:
    """A multi-stage chained parallel run"""
    id: str
    name: str
    stages: List[Dict[str, Any]]   # Stage definitions
    current_stage: int
    state: AgentState
    created_at: float
    completed_at: Optional[float]
    stage_results: Dict[int, MergedResult]  # stage_num -> merged result
    
    @property
    def total_stages(self) -> int:
        return len(self.stages)
    
    @property
    def is_complete(self) -> bool:
        return self.current_stage >= self.total_stages
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "stages": self.stages,
            "current_stage": self.current_stage,
            "total_stages": self.total_stages,
            "state": self.state.value,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "stage_results": {k: v.to_dict() for k, v in self.stage_results.items()},
            "is_complete": self.is_complete,
        }


# =============================================================================
# HYPER FOLDER CLASS
# =============================================================================

class HyperFolder:
    """
    A 64-directional folder for agent communication.
    
    Structure:
      agent_XX/
        ├── inbox/           # Incoming messages from other agents
        │   ├── p01/        # From agent 01
        │   ├── p02/        # From agent 02
        │   └── ...         # Up to p64
        ├── outbox/          # Outgoing messages
        │   ├── broadcast/  # To all agents
        │   └── direct/     # To specific agents
        ├── work/            # Current work items
        ├── results/         # Completed work results
        ├── merge/           # Merge staging area
        └── state.json       # Agent state
    """
    
    def __init__(self, agent_id: int, root_path: Path):
        if not 1 <= agent_id <= 64:
            raise ValueError(f"Agent ID must be 1-64, got {agent_id}")
        
        self.agent_id = agent_id
        self.root = root_path
        self.path = root_path / f"agent_{agent_id:02d}"
        self._setup_structure()
    
    def _setup_structure(self) -> None:
        """Create the 64-port folder structure"""
        # Main directories
        (self.path / "inbox").mkdir(parents=True, exist_ok=True)
        (self.path / "outbox" / "broadcast").mkdir(parents=True, exist_ok=True)
        (self.path / "outbox" / "direct").mkdir(parents=True, exist_ok=True)
        (self.path / "work").mkdir(parents=True, exist_ok=True)
        (self.path / "results").mkdir(parents=True, exist_ok=True)
        (self.path / "merge").mkdir(parents=True, exist_ok=True)
        
        # Create 64 inbox ports (from each other agent)
        for i in range(1, 65):
            (self.path / "inbox" / f"p{i:02d}").mkdir(exist_ok=True)
    
    @property
    def inbox(self) -> Path:
        return self.path / "inbox"
    
    @property
    def outbox(self) -> Path:
        return self.path / "outbox"
    
    @property
    def work(self) -> Path:
        return self.path / "work"
    
    @property
    def results(self) -> Path:
        return self.path / "results"
    
    @property
    def merge(self) -> Path:
        return self.path / "merge"
    
    def inbox_port(self, from_agent: int) -> Path:
        """Get inbox port for messages from a specific agent"""
        return self.inbox / f"p{from_agent:02d}"
    
    def write_to_agent(self, target_agent: int, msg: HyperMessage) -> Path:
        """Write a message to another agent's inbox"""
        target_folder = self.root / f"agent_{target_agent:02d}" / "inbox" / f"p{self.agent_id:02d}"
        target_folder.mkdir(parents=True, exist_ok=True)
        
        filename = f"{msg.timestamp:.6f}_{msg.id}.json"
        filepath = target_folder / filename
        
        with open(filepath, 'w') as f:
            json.dump(msg.to_dict(), f, indent=2)
        
        return filepath
    
    def broadcast_to_all(self, msg: HyperMessage) -> List[Path]:
        """Write a message to ALL other agents' inboxes"""
        paths = []
        for target in range(1, 65):
            if target != self.agent_id:
                path = self.write_to_agent(target, msg)
                paths.append(path)
        return paths
    
    def read_all_inbox(self, limit_per_port: int = 100) -> List[Tuple[HyperMessage, Path, int]]:
        """Read all messages from all 64 inbox ports"""
        messages = []
        
        for port_num in range(1, 65):
            port_path = self.inbox / f"p{port_num:02d}"
            if not port_path.exists():
                continue
            
            for filepath in sorted(port_path.glob("*.json"))[:limit_per_port]:
                try:
                    with open(filepath, 'r') as f:
                        data = json.load(f)
                    msg = HyperMessage.from_dict(data)
                    if not msg.is_expired:
                        messages.append((msg, filepath, port_num))
                except Exception as e:
                    print(f"Error reading {filepath}: {e}")
        
        return messages
    
    def save_work(self, work: AgentWork) -> Path:
        """Save a work item"""
        filepath = self.work / f"{work.task_id}.json"
        with open(filepath, 'w') as f:
            json.dump(work.to_dict(), f, indent=2)
        return filepath
    
    def save_result(self, result: AgentResult) -> Path:
        """Save a result"""
        filepath = self.results / f"{result.task_id}.json"
        with open(filepath, 'w') as f:
            json.dump(result.to_dict(), f, indent=2)
        return filepath
    
    def delete_message(self, filepath: Path) -> None:
        """Delete a processed message"""
        if filepath.exists():
            filepath.unlink()
    
    def get_state(self) -> Dict[str, Any]:
        """Get agent state from state.json"""
        state_file = self.path / "state.json"
        if state_file.exists():
            with open(state_file, 'r') as f:
                return json.load(f)
        return {"state": AgentState.IDLE.value, "last_update": time.time()}
    
    def set_state(self, state: AgentState, extra: Dict[str, Any] = None) -> None:
        """Update agent state"""
        data = {
            "state": state.value,
            "last_update": time.time(),
            **(extra or {})
        }
        state_file = self.path / "state.json"
        with open(state_file, 'w') as f:
            json.dump(data, f, indent=2)


# =============================================================================
# HYPER AGENT CLASS
# =============================================================================

class HyperAgent:
    """
    A 64-directional agent in the hypercube mesh.
    
    Each agent can:
      - Broadcast to all 64 folders simultaneously
      - Receive from all 64 agents
      - Work in parallel with other agents
      - Participate in merge operations
      - Chain results to next stage
    """
    
    def __init__(
        self,
        agent_id: int,
        mesh_root: Optional[Path] = None,
        executor: Optional[Callable] = None,
    ):
        if not 1 <= agent_id <= 64:
            raise ValueError(f"Agent ID must be 1-64, got {agent_id}")
        
        self.agent_id = agent_id
        self.mesh_root = mesh_root or DEFAULT_MESH_ROOT
        self.folder = HyperFolder(agent_id, self.mesh_root)
        self.state = AgentState.IDLE
        self.executor = executor or self._default_executor
        
        # Task handlers
        self.task_handlers: Dict[str, Callable] = {}
        self._register_default_handlers()
        
        # Running state
        self._running = False
        self._worker_thread: Optional[threading.Thread] = None
        
        # Metrics
        self.metrics = {
            "messages_sent": 0,
            "messages_received": 0,
            "tasks_completed": 0,
            "tasks_failed": 0,
            "broadcasts": 0,
        }
    
    def _register_default_handlers(self) -> None:
        """Register default task handlers"""
        self.task_handlers["echo"] = self._handle_echo
        self.task_handlers["shell"] = self._handle_shell
        self.task_handlers["python"] = self._handle_python
        self.task_handlers["sleep"] = self._handle_sleep
    
    async def _handle_echo(self, work: AgentWork) -> Any:
        """Echo handler - returns payload"""
        return {
            "echo": work.payload,
            "agent": self.agent_id,
            "timestamp": time.time(),
        }
    
    async def _handle_shell(self, work: AgentWork) -> Any:
        """Execute shell command"""
        proc = await asyncio.create_subprocess_shell(
            work.command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=work.timeout)
        return {
            "stdout": stdout.decode() if stdout else "",
            "stderr": stderr.decode() if stderr else "",
            "returncode": proc.returncode,
        }
    
    async def _handle_python(self, work: AgentWork) -> Any:
        """Execute Python code"""
        namespace = {"payload": work.payload, "result": None, "agent_id": self.agent_id}
        exec(work.command, namespace)
        return namespace.get("result")
    
    async def _handle_sleep(self, work: AgentWork) -> Any:
        """Sleep for testing parallel execution"""
        duration = work.payload.get("duration", 1.0)
        await asyncio.sleep(duration)
        return {"slept": duration, "agent": self.agent_id}
    
    async def _default_executor(self, work: AgentWork) -> AgentResult:
        """Default work executor"""
        started = time.time()
        
        try:
            handler = self.task_handlers.get(work.task_type, self._handle_echo)
            output = await handler(work)
            
            return AgentResult(
                agent_id=self.agent_id,
                task_id=work.task_id,
                success=True,
                output=output,
                error=None,
                started_at=started,
                completed_at=time.time(),
            )
        except Exception as e:
            return AgentResult(
                agent_id=self.agent_id,
                task_id=work.task_id,
                success=False,
                output=None,
                error=str(e),
                started_at=started,
                completed_at=time.time(),
            )
    
    # =========================================================================
    # MESSAGING
    # =========================================================================
    
    def broadcast(
        self,
        payload: Dict[str, Any],
        chain_id: Optional[str] = None,
        stage: int = 0,
        requires_merge: bool = True,
        merge_strategy: MergeStrategy = MergeStrategy.ALL,
    ) -> str:
        """Broadcast a message to ALL 64 agents"""
        msg_id = str(uuid.uuid4())[:12]
        
        msg = HyperMessage(
            id=msg_id,
            source_agent=self.agent_id,
            target_agents=[],  # Empty = broadcast
            port=HyperPort.BROADCAST,
            payload=payload,
            timestamp=time.time(),
            chain_id=chain_id or str(uuid.uuid4())[:8],
            stage_id=f"stage_{stage}",
            sequence=stage,
            requires_merge=requires_merge,
            merge_strategy=merge_strategy,
        )
        
        # Write to all 64 agents
        self.folder.broadcast_to_all(msg)
        self.metrics["broadcasts"] += 1
        self.metrics["messages_sent"] += 63  # All except self
        
        return msg.chain_id
    
    def send_to(self, target_agent: int, payload: Dict[str, Any], **kwargs) -> str:
        """Send message to a specific agent"""
        msg_id = str(uuid.uuid4())[:12]
        
        msg = HyperMessage(
            id=msg_id,
            source_agent=self.agent_id,
            target_agents=[target_agent],
            port=HyperPort.get_port(target_agent),
            payload=payload,
            timestamp=time.time(),
            chain_id=kwargs.get("chain_id"),
            stage_id=kwargs.get("stage_id"),
            sequence=kwargs.get("sequence", 0),
            requires_merge=kwargs.get("requires_merge", False),
            merge_strategy=kwargs.get("merge_strategy", MergeStrategy.ALL),
        )
        
        self.folder.write_to_agent(target_agent, msg)
        self.metrics["messages_sent"] += 1
        
        return msg_id
    
    def receive_all(self) -> List[Tuple[HyperMessage, Path, int]]:
        """Receive all pending messages from all 64 ports"""
        messages = self.folder.read_all_inbox()
        self.metrics["messages_received"] += len(messages)
        return messages
    
    # =========================================================================
    # WORK EXECUTION
    # =========================================================================
    
    async def execute_work(self, work: AgentWork) -> AgentResult:
        """Execute a work item"""
        self.state = AgentState.PROCESSING
        self.folder.set_state(self.state, {"task_id": work.task_id})
        
        result = await self.executor(work)
        
        # Save result
        self.folder.save_result(result)
        
        if result.success:
            self.metrics["tasks_completed"] += 1
        else:
            self.metrics["tasks_failed"] += 1
        
        self.state = AgentState.IDLE
        self.folder.set_state(self.state)
        
        return result
    
    # =========================================================================
    # LIFECYCLE
    # =========================================================================
    
    def start(self) -> None:
        """Start the agent worker loop"""
        if self._running:
            return
        
        self._running = True
        self.state = AgentState.IDLE
        self.folder.set_state(self.state)
    
    def stop(self) -> None:
        """Stop the agent"""
        self._running = False
        self.state = AgentState.IDLE
        self.folder.set_state(self.state)
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent info"""
        return {
            "agent_id": self.agent_id,
            "state": self.state.value,
            "path": str(self.folder.path),
            "metrics": self.metrics,
        }


# =============================================================================
# HYPERCUBE ORCHESTRATOR
# =============================================================================

class HyperCubeOrchestrator:
    """
    Orchestrates 64 agents in a fully-connected hypercube mesh.
    
    Manages:
      - All 64 agent folders
      - Parallel task distribution
      - Merge barriers
      - Chained pipeline runs
    """
    
    def __init__(self, mesh_root: Optional[Path] = None):
        self.mesh_root = mesh_root or DEFAULT_MESH_ROOT
        self.mesh_root.mkdir(parents=True, exist_ok=True)
        
        # Create all 64 agent folders
        self.agents: Dict[int, HyperAgent] = {}
        self._init_all_agents()
        
        # Chains tracking
        self.chains: Dict[str, ChainedRun] = {}
        
        # Parallel execution
        self.thread_pool = ThreadPoolExecutor(max_workers=PARALLEL_WORKERS)
    
    def _init_all_agents(self) -> None:
        """Initialize all 64 agent folders"""
        for i in range(1, 65):
            self.agents[i] = HyperAgent(i, self.mesh_root)
    
    # =========================================================================
    # PARALLEL EXECUTION
    # =========================================================================
    
    async def scatter_to_all(
        self,
        work_generator: Callable[[int], AgentWork],
        merge_strategy: MergeStrategy = MergeStrategy.ALL,
        chain_id: Optional[str] = None,
    ) -> MergedResult:
        """
        Scatter work to all 64 agents and collect results.
        
        Args:
            work_generator: Function that takes agent_id (1-64) and returns AgentWork
            merge_strategy: How to combine results
            chain_id: Chain ID for multi-stage pipelines
        
        Returns:
            MergedResult with all agent outputs
        """
        chain_id = chain_id or str(uuid.uuid4())[:8]
        
        # Generate work for all 64 agents
        work_items = [work_generator(i) for i in range(1, 65)]
        
        # Execute all in parallel
        results = await self._execute_parallel(work_items)
        
        # Merge results
        merged = self._merge_results(chain_id, 0, merge_strategy, results)
        
        return merged
    
    async def _execute_parallel(self, work_items: List[AgentWork]) -> List[AgentResult]:
        """Execute work items in parallel across agents"""
        tasks = []
        
        for work in work_items:
            agent = self.agents.get(work.agent_id)
            if agent:
                tasks.append(agent.execute_work(work))
        
        # Run all concurrently
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Convert exceptions to failed results
        final_results = []
        for i, r in enumerate(results):
            if isinstance(r, Exception):
                final_results.append(AgentResult(
                    agent_id=work_items[i].agent_id,
                    task_id=work_items[i].task_id,
                    success=False,
                    output=None,
                    error=str(r),
                    started_at=time.time(),
                    completed_at=time.time(),
                ))
            else:
                final_results.append(r)
        
        return final_results
    
    def _merge_results(
        self,
        chain_id: str,
        stage: int,
        strategy: MergeStrategy,
        results: List[AgentResult],
    ) -> MergedResult:
        """Merge results from parallel agents"""
        merge_start = time.time()
        
        successful = [r for r in results if r.success]
        failed = [r for r in results if not r.success]
        
        # Apply merge strategy
        if strategy == MergeStrategy.CONCAT:
            merged_output = [r.output for r in successful]
        elif strategy == MergeStrategy.FIRST:
            merged_output = successful[0].output if successful else None
        elif strategy == MergeStrategy.ALL:
            merged_output = {r.agent_id: r.output for r in results}
        elif strategy == MergeStrategy.REDUCE:
            # Sum numeric outputs, concat strings
            outputs = [r.output for r in successful if r.output is not None]
            if outputs and isinstance(outputs[0], (int, float)):
                merged_output = sum(outputs)
            elif outputs and isinstance(outputs[0], str):
                merged_output = "".join(outputs)
            else:
                merged_output = outputs
        elif strategy == MergeStrategy.VOTE:
            # Majority voting
            from collections import Counter
            outputs = [str(r.output) for r in successful]
            if outputs:
                counter = Counter(outputs)
                merged_output = counter.most_common(1)[0][0]
            else:
                merged_output = None
        else:
            merged_output = {r.agent_id: r.output for r in results}
        
        return MergedResult(
            chain_id=chain_id,
            stage=stage,
            merge_strategy=strategy,
            agent_results=results,
            merged_output=merged_output,
            total_agents=len(results),
            successful_agents=len(successful),
            failed_agents=len(failed),
            merge_time=time.time() - merge_start,
        )
    
    # =========================================================================
    # CHAINED PARALLEL RUNS
    # =========================================================================
    
    async def run_chain(
        self,
        name: str,
        stages: List[Dict[str, Any]],
    ) -> ChainedRun:
        """
        Execute a multi-stage chained parallel run.
        
        Each stage:
          1. Scatters work to all 64 agents
          2. Waits for all to complete (barrier)
          3. Merges results
          4. Passes merged result to next stage
        
        Args:
            name: Chain name
            stages: List of stage definitions, each with:
                - command: Command to execute
                - task_type: Type of task
                - merge_strategy: How to merge
                - payload_transform: Optional function to transform payload
        
        Returns:
            ChainedRun with all stage results
        """
        chain_id = str(uuid.uuid4())[:8]
        
        chain = ChainedRun(
            id=chain_id,
            name=name,
            stages=stages,
            current_stage=0,
            state=AgentState.PROCESSING,
            created_at=time.time(),
            completed_at=None,
            stage_results={},
        )
        
        self.chains[chain_id] = chain
        
        # Previous stage output (starts as None, then carries forward)
        previous_output = None
        
        for stage_num, stage_def in enumerate(stages):
            chain.current_stage = stage_num
            
            # Generate work for this stage
            def work_gen(agent_id: int, stage_def=stage_def, stage_num=stage_num, prev=previous_output) -> AgentWork:
                payload = stage_def.get("payload", {}).copy()
                payload["previous_stage_output"] = prev
                payload["stage_number"] = stage_num
                
                return AgentWork(
                    agent_id=agent_id,
                    task_id=f"{chain_id}_s{stage_num}_a{agent_id:02d}",
                    command=stage_def.get("command", "echo"),
                    task_type=stage_def.get("task_type", "echo"),
                    payload=payload,
                    chain_id=chain_id,
                    stage=stage_num,
                    timeout=stage_def.get("timeout", 300.0),
                )
            
            # Execute this stage in parallel
            merge_strategy = MergeStrategy(stage_def.get("merge_strategy", "all"))
            result = await self.scatter_to_all(work_gen, merge_strategy, chain_id)
            
            # Store stage result
            chain.stage_results[stage_num] = result
            
            # Pass output to next stage
            previous_output = result.merged_output
        
        # Complete
        chain.state = AgentState.COMPLETED
        chain.completed_at = time.time()
        
        return chain
    
    # =========================================================================
    # STATUS & INFO
    # =========================================================================
    
    def get_status(self) -> Dict[str, Any]:
        """Get orchestrator status"""
        agent_states = {}
        for i, agent in self.agents.items():
            agent_states[i] = agent.state.value
        
        return {
            "mesh_root": str(self.mesh_root),
            "total_agents": 64,
            "agent_states": agent_states,
            "active_chains": len([c for c in self.chains.values() if c.state == AgentState.PROCESSING]),
            "completed_chains": len([c for c in self.chains.values() if c.state == AgentState.COMPLETED]),
        }
    
    def get_chain(self, chain_id: str) -> Optional[ChainedRun]:
        """Get a chain by ID"""
        return self.chains.get(chain_id)


# =============================================================================
# CLI INTEGRATION
# =============================================================================

def create_hypercube_mesh(root: Optional[Path] = None) -> HyperCubeOrchestrator:
    """Create a new 64-agent hypercube mesh"""
    return HyperCubeOrchestrator(root)


async def demo_parallel_run():
    """Demo: Parallel run across 64 agents"""
    print("\n" + "="*70)
    print("  64-DIRECTIONAL HYPERCUBE MESH - PARALLEL AGENT RUN")
    print("="*70 + "\n")
    
    # Create orchestrator
    orch = create_hypercube_mesh()
    print(f"✓ Created hypercube mesh at: {orch.mesh_root}")
    print(f"✓ Initialized 64 agent folders\n")
    
    # Define work generator: each agent echoes its ID
    def work_gen(agent_id: int) -> AgentWork:
        return AgentWork(
            agent_id=agent_id,
            task_id=f"demo_{agent_id:02d}",
            command="echo",
            task_type="echo",
            payload={"agent": agent_id, "message": f"Hello from Agent {agent_id:02d}"},
            chain_id="demo",
            stage=0,
        )
    
    print("📤 Broadcasting work to all 64 agents...")
    start = time.time()
    
    # Scatter to all 64 and merge
    result = await orch.scatter_to_all(work_gen, MergeStrategy.ALL)
    
    duration = time.time() - start
    print(f"✓ Parallel execution complete in {duration:.3f}s\n")
    
    print(f"📊 Results:")
    print(f"   Total agents: {result.total_agents}")
    print(f"   Successful: {result.successful_agents}")
    print(f"   Failed: {result.failed_agents}")
    print(f"   Success rate: {result.success_rate*100:.1f}%")
    print(f"   Merge time: {result.merge_time*1000:.2f}ms\n")
    
    # Show sample outputs
    print("📝 Sample outputs (first 5 agents):")
    for agent_id in range(1, 6):
        output = result.merged_output.get(agent_id, {})
        if isinstance(output, dict) and "echo" in output:
            msg = output["echo"].get("message", "N/A")
            print(f"   Agent {agent_id:02d}: {msg}")
    
    return result


async def demo_chained_run():
    """Demo: Chained parallel run with multiple stages"""
    print("\n" + "="*70)
    print("  CHAINED PARALLEL RUN - MULTI-STAGE PIPELINE")
    print("="*70 + "\n")
    
    orch = create_hypercube_mesh()
    
    # Define 3-stage pipeline
    stages = [
        {
            "name": "Stage 1: Generate",
            "command": "result = {'value': agent_id * 2}",
            "task_type": "python",
            "merge_strategy": "all",
            "payload": {},
        },
        {
            "name": "Stage 2: Transform",
            "command": "result = {'transformed': payload.get('stage_number', 0) + agent_id}",
            "task_type": "python",
            "merge_strategy": "all",
            "payload": {},
        },
        {
            "name": "Stage 3: Aggregate",
            "task_type": "echo",
            "command": "echo",
            "merge_strategy": "all",
            "payload": {"final": True},
        },
    ]
    
    print(f"📋 Running 3-stage chained pipeline...")
    print(f"   Stage 1: Generate (64 parallel)")
    print(f"   Stage 2: Transform (64 parallel)")  
    print(f"   Stage 3: Aggregate (64 parallel)")
    print()
    
    start = time.time()
    chain = await orch.run_chain("demo_chain", stages)
    duration = time.time() - start
    
    print(f"✓ Chain completed in {duration:.3f}s\n")
    
    print(f"📊 Chain Results:")
    print(f"   Chain ID: {chain.id}")
    print(f"   Name: {chain.name}")
    print(f"   Total stages: {chain.total_stages}")
    print(f"   State: {chain.state.value}")
    print()
    
    for stage_num, stage_result in chain.stage_results.items():
        print(f"   Stage {stage_num + 1}: {stages[stage_num].get('name', 'Unknown')}")
        print(f"      Success: {stage_result.successful_agents}/64")
        print(f"      Merge strategy: {stage_result.merge_strategy.value}")
    
    return chain


if __name__ == "__main__":
    print("\n🔷 ARIA Q-Hypercube Mesh - 64-Directional Agent System\n")
    
    # Run demos
    asyncio.run(demo_parallel_run())
    asyncio.run(demo_chained_run())
