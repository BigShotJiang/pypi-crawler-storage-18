"""
pytde - Python parser for legacy Tableau Data Extract (TDE) files.

This package provides functionality to read TDE files and convert them
to pandas DataFrames.
"""

from .parser import (
    TDEParser,
    TDEHeader,
    BlockInfo,
    ColumnEntry,
    ExtractColumn,
    read_tde,
    read_tde_metadata,
    TDE_MAGIC,
    DATA_BLOCK_MARKER,
    INDEX_BLOCK_MARKER,
)

__version__ = "0.1.0"
__author__ = "Ron Reiter"

__all__ = [
    "TDEParser",
    "TDEHeader",
    "BlockInfo",
    "ColumnEntry",
    "ExtractColumn",
    "read_tde",
    "read_tde_metadata",
    "TDE_MAGIC",
    "DATA_BLOCK_MARKER",
    "INDEX_BLOCK_MARKER",
]
