import os
import signal
import subprocess
import sys
import tempfile
import time

import dill

from sylriekit.Constants import Constants


_WEBSITE_PROTECTED_ATTRS = {
    "HOST", "PORT", "WORKERS", "TIMEOUT"
}


class Website(metaclass=Constants.protect_class_meta(_WEBSITE_PROTECTED_ATTRS, "WEBSITE_CONFIG_LOCKED")):

    HOST = "127.0.0.1"
    PORT = 5000
    WORKERS = 4
    TIMEOUT = 30

    _URL_PROCESSOR = None
    _RENDERER = None
    _PROCESS = None
    _PID_FILE = None

    @classmethod
    def load_config(cls, config: dict):
        cls._check_config_lock()
        api_keys = config["api_key"]
        env_variables = config["env"]
        if "Website" in config.keys():
            website_config = config["Website"]
            cls.HOST = website_config.get("HOST", cls.HOST)
            cls.PORT = website_config.get("PORT", cls.PORT)
            cls.WORKERS = website_config.get("WORKERS", cls.WORKERS)
            cls.TIMEOUT = website_config.get("TIMEOUT", cls.TIMEOUT)
            cls._PID_FILE = website_config.get("PID_FILE", cls._PID_FILE)

    @classmethod
    def url_processing(cls, func=None):
        def decorator(f):
            cls._URL_PROCESSOR = f
            return f
        if func is not None:
            return decorator(func)
        return decorator

    @classmethod
    def render(cls, func=None):
        def decorator(f):
            cls._RENDERER = f
            return f
        if func is not None:
            return decorator(func)
        return decorator

    @classmethod
    def status(cls) -> dict:
        pid = cls._get_running_pid()
        if pid is None:
            return {
                "running": False,
                "pid": None,
                "host": cls.HOST,
                "port": cls.PORT
            }

        if cls._is_process_alive(pid):
            return {
                "running": True,
                "pid": pid,
                "host": cls.HOST,
                "port": cls.PORT
            }

        cls._cleanup_pid_file()
        return {
            "running": False,
            "pid": None,
            "host": cls.HOST,
            "port": cls.PORT
        }

    @classmethod
    def start(cls) -> dict:
        status = cls.status()
        if status["running"]:
            return {
                "success": False,
                "message": f"Website already running on PID {status['pid']}",
                "pid": status["pid"]
            }

        if cls._URL_PROCESSOR is None:
            return {
                "success": False,
                "message": "No URL processor registered. Use @Website.url_processing() decorator.",
                "pid": None
            }

        server_data = {
            "host": cls.HOST,
            "port": cls.PORT,
            "workers": cls.WORKERS,
            "timeout": cls.TIMEOUT,
            "url_processor": cls._URL_PROCESSOR,
            "renderer": cls._RENDERER,
            "pid_file": cls._get_pid_file_path()
        }

        data_file = tempfile.NamedTemporaryFile(
            mode="wb",
            suffix=".pkl",
            delete=False
        )
        dill.dump(server_data, data_file)
        data_file.close()

        server_script = cls._generate_server_script()

        script_file = tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".py",
            delete=False,
            encoding="utf-8"
        )
        script_file.write(server_script)
        script_file.close()

        if sys.platform == "win32":
            creationflags = (
                subprocess.CREATE_NEW_PROCESS_GROUP |
                subprocess.DETACHED_PROCESS |
                subprocess.CREATE_NO_WINDOW
            )
            process = subprocess.Popen(
                [sys.executable, script_file.name, data_file.name],
                creationflags=creationflags,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )
        else:
            process = subprocess.Popen(
                [sys.executable, script_file.name, data_file.name],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL
            )

        time.sleep(1.5)

        if cls._is_process_alive(process.pid):
            return {
                "success": True,
                "message": f"Website started on {cls.HOST}:{cls.PORT}",
                "pid": process.pid
            }

        return {
            "success": False,
            "message": "Failed to start website server",
            "pid": None
        }

    @classmethod
    def stop(cls) -> dict:
        status = cls.status()
        if not status["running"]:
            return {
                "success": False,
                "message": "No website is currently running",
                "pid": None
            }

        pid = status["pid"]

        try:
            if sys.platform == "win32":
                import subprocess
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(pid)],
                    capture_output=True
                )
            else:
                os.kill(pid, signal.SIGTERM)

                for _ in range(10):
                    time.sleep(0.5)
                    if not cls._is_process_alive(pid):
                        break

                if cls._is_process_alive(pid):
                    os.kill(pid, signal.SIGKILL)

            cls._cleanup_pid_file()
            cls._PROCESS = None

            return {
                "success": True,
                "message": f"Website stopped (PID {pid})",
                "pid": pid
            }
        except ProcessLookupError:
            cls._cleanup_pid_file()
            return {
                "success": True,
                "message": "Website process already terminated",
                "pid": pid
            }
        except PermissionError:
            return {
                "success": False,
                "message": f"Permission denied to stop process {pid}",
                "pid": pid
            }

    @classmethod
    def reboot(cls) -> dict:
        stop_result = cls.stop()

        time.sleep(1)

        start_result = cls.start()

        return {
            "success": start_result["success"],
            "message": f"Reboot: {stop_result['message']} -> {start_result['message']}",
            "pid": start_result["pid"]
        }

    @classmethod
    def lock_config(cls):
        cls._check_config_lock()
        Constants.define("WEBSITE_CONFIG_LOCKED", True)

    ### PRIVATE UTILITIES START
    @classmethod
    def _check_config_lock(cls):
        if Constants.get("WEBSITE_CONFIG_LOCKED", False):
            raise PermissionError("Config is locked and cannot be modified")

    @classmethod
    def _get_pid_file_path(cls) -> str:
        if cls._PID_FILE:
            return cls._PID_FILE
        return os.path.join(os.getcwd(), ".sylriekit_website.pid")

    @classmethod
    def _get_running_pid(cls):
        pid_file = cls._get_pid_file_path()
        if not os.path.exists(pid_file):
            return None
        try:
            with open(pid_file, "r") as f:
                return int(f.read().strip())
        except (ValueError, IOError):
            return None

    @classmethod
    def _save_pid(cls, pid: int):
        pid_file = cls._get_pid_file_path()
        with open(pid_file, "w") as f:
            f.write(str(pid))

    @classmethod
    def _cleanup_pid_file(cls):
        pid_file = cls._get_pid_file_path()
        if os.path.exists(pid_file):
            os.remove(pid_file)

    @classmethod
    def _is_process_alive(cls, pid: int) -> bool:
        try:
            if sys.platform == "win32":
                result = subprocess.run(
                    ["tasklist", "/FI", f"PID eq {pid}", "/NH"],
                    capture_output=True,
                    text=True
                )
                return str(pid) in result.stdout
            else:
                os.kill(pid, 0)
                return True
        except (OSError, ProcessLookupError):
            return False

    @staticmethod
    def _generate_server_script() -> str:
        return '''
import os
import sys
import traceback

import dill

def run_server(data_file_path):
    log_file = data_file_path + ".log"
    
    try:
        with open(data_file_path, "rb") as f:
            data = dill.load(f)

        host = data["host"]
        port = data["port"]
        workers = data["workers"]
        timeout = data["timeout"]
        url_processor = data["url_processor"]
        renderer = data["renderer"]
        pid_file = data["pid_file"]

        with open(pid_file, "w") as f:
            f.write(str(os.getpid()))

        try:
            os.remove(data_file_path)
        except:
            pass

        from flask import Flask, request, Response

        app = Flask(__name__)

        @app.route("/", defaults={"path": ""})
        @app.route("/<path:path>")
        def catch_all(path):
            try:
                request_data = {
                    "path": f"/{path}",
                    "method": request.method,
                    "remote_addr": request.remote_addr,
                    "args": dict(request.args),
                    "headers": dict(request.headers),
                    "data": request.get_data(as_text=True),
                    "json": request.get_json(silent=True),
                    "form": dict(request.form),
                    "cookies": dict(request.cookies)
                }

                result = url_processor(request_data)

                if renderer is not None:
                    result = renderer(result)

                if isinstance(result, Response):
                    return result
                if isinstance(result, dict):
                    return result
                if isinstance(result, tuple):
                    return result
                return str(result)
            except Exception as e:
                with open(log_file, "a") as f:
                    f.write(f"Request error: {e}\\n")
                    f.write(traceback.format_exc() + "\\n")
                raise

        try:
            from gunicorn.app.base import BaseApplication

            class GunicornApp(BaseApplication):
                def __init__(self, application, options=None):
                    self.options = options or {}
                    self.application = application
                    super().__init__()

                def load_config(self):
                    for key, value in self.options.items():
                        if key in self.cfg.settings and value is not None:
                            self.cfg.set(key.lower(), value)

                def load(self):
                    return self.application

            options = {
                "bind": f"{host}:{port}",
                "workers": workers,
                "timeout": timeout
            }
            GunicornApp(app, options).run()
        except ImportError:
            app.run(host=host, port=port, debug=False, use_reloader=False)
    except Exception as e:
        with open(log_file, "a") as f:
            f.write(f"Startup error: {e}\\n")
            f.write(traceback.format_exc() + "\\n")
        raise

if __name__ == "__main__":
    run_server(sys.argv[1])
'''
    ### PRIVATE UTILITIES END

