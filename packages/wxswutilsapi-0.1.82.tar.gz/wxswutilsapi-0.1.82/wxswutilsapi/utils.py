import ast
import base64
import json
import re
import zlib
import os
import numpy as np

def predict_to_chartdata(data):
    try:
        labels = []
        xs = []
        ys = {}

        # 解析数据
        for entry in data:
            if entry['used'] == '1':
                predict_data = entry['predict']
                if isinstance(predict_data, str):
                    predict_list =  ast.literal_eval(predict_data)
                else:
                    predict_list = predict_data 
                xs.append(entry['time'])  # 记录时间戳
                for predict in predict_list:
                    component = predict['component']
                    value = predict['value']

                    # 添加到labels
                    if component not in labels:
                        labels.append(component)
                        ys[component] = []

                    # 按组件存储数值
                    ys[component].append(value)

        # 构建ys为嵌套数组
        ys_list = [ys[label] for label in labels]

        # 生成最终的结构
        result = {
            'labels': labels,
            'xs': xs,
            'ys': ys_list
        }

        return result
    except Exception as e:
        raise ValueError(f"Unexpected error in predict_to_chartdata:{str(e)}") from e
        
def predict_average(data,resultIsObject = False):
    try:
        # 初始化用于存储每个物质的值
        values = {}

        # 解析数据
        for entry in data:
            if entry['used'] == '1':
                predict_data = entry['predict']
                # 检查 predict_data 是否为字符串，如果是则转换
                if isinstance(predict_data, str):
                    predict_list = ast.literal_eval(predict_data)
                else:
                    predict_list = predict_data 
                for predict in predict_list:
                    component = predict['component']
                    value = predict['value']

                    # 如果物质还没有出现在values中，初始化为空列表
                    if component not in values:
                        values[component] = []

                    # 将该物质的值添加到列表中
                    values[component].append(value)

        average_result = None
        # 计算去掉两个最大和两个最小值后的平均值
        if resultIsObject is False:
            average_result = []
        else:
            average_result = {}

        for component, component_values in values.items():
            # 对该物质的值进行排序
            sorted_values = sorted(component_values)

            # 确保有足够的值去掉两个最大和两个最小
            if len(sorted_values) > 4:
                trimmed_values = sorted_values[2:-2]  # 去掉两个最大和两个最小
            else:
                trimmed_values = sorted_values  # 如果值不足 4 个，不做裁剪

            # 计算平均值
            avg_value = np.mean(trimmed_values)
            if resultIsObject is False:
                average_result.append({'component': component, 'value': avg_value})
            else:
                average_result[component] = avg_value

        return average_result
    except Exception as e:
        raise ValueError(f"Unexpected error in predict_average:{str(e)}") from e
    
def is_number(value):
    try:
        if isinstance(value, (int, float)):
            return True
        if isinstance(value, str):
            # 使用正则表达式检查是否为数字
            return bool(re.match(r'^-?\d+(\.\d+)?$', value))
        return False
    except Exception as e:
        raise ValueError(f"Unexpected error in is_number:{str(e)}") from e
    
def spectrum_sum(data, group_size):
    try:
        grouped_data = []  # 用来存放分组后的数据
        group = []  # 当前正在处理的分组
        ids = []  # 用来记录当前分组的 id
        merged_spectrum = []  # 用来合并当前分组的 Spectrum_Array
    
        for item in data:
            if len(group) < group_size:
                # 添加当前项到当前分组
                group.append(item)
                ids.append(item['id'])
                spectrum_array = eval(item['Spectrum_Array'])  # 将字符串转为列表
                
                # 合并当前 Spectrum_Array
                if not merged_spectrum:
                    merged_spectrum = spectrum_array
                else:
                    merged_spectrum = [x + y for x, y in zip(merged_spectrum, spectrum_array)]
            
            # 当分组满了时，保存分组结果，并重置用于下一组的变量
            if len(group) == group_size:
                grouped_data.append({
                    'Spectrum_Array': merged_spectrum,
                    'time': group[0]['time'],  # 假设同一组的时间相同
                    'ids': ids,
                    'filter_time': group[0]['filter_time'],
                    'plate_id':group[0]['plate_id'] if "plate_id" in group[0] else ""
                })
                # 清空当前分组，用于处理下一个分组
                group = []
                ids = []
                merged_spectrum = []
    
        # 处理最后剩余的不足 group_size 的数据，如果有就删除
        if group:
            # 如果最后一组的长度不足 group_size，则删除它
            if len(group) < group_size:
                return grouped_data  # 直接返回，最后一组将被忽略
    
        return grouped_data
    except Exception as e:
        raise ValueError(f"Unexpected error in spectrum_sum:{str(e)}") from e
    
def spectrum_sum_mydb(data, group_size, time, check_round=False):
    try:
        grouped_data = []

        if check_round:
            # 按轮次分组处理
            round_groups = {}
            for item in data:
                round_num = item.get("round_num", 0)
                round_groups.setdefault(round_num, []).append(item)

            for round_num, items in round_groups.items():
                group = []
                ids = []
                merged_spectrum = []

                for item in items:
                    if len(group) < group_size:
                        group.append({k: v for k, v in item.items() if k != 'Spectrum_Array'})
                        ids.append(item['id'])
                        spectrum_array = item['Spectrum_Array']

                        if isinstance(spectrum_array, str):
                            spectrum_array = json.loads(spectrum_array)
                        if spectrum_array and not isinstance(spectrum_array[0], (int, float)):
                            spectrum_array = [float(x) for x in spectrum_array]

                        if not merged_spectrum:
                            merged_spectrum = spectrum_array
                        else:
                            merged_spectrum = [x + y for x, y in zip(merged_spectrum, spectrum_array)]

                    if len(group) == group_size:
                        grouped_data.append({
                            'Spectrum_Array': merged_spectrum,
                            'time': group[0]['time'],
                            'ids': ids,
                            'filter_time': time,
                            'plate_id': group[0].get('plate_id', ''),
                            'round_num': round_num
                        })
                        group = []
                        ids = []
                        merged_spectrum = []

                # 丢弃不足 group_size 的数据
                if group and len(group) < group_size:
                    continue

        else:
            # 原始逻辑
            group = []
            ids = []
            merged_spectrum = []

            for item in data:
                if len(group) < group_size:
                    group.append({k: v for k, v in item.items() if k != 'Spectrum_Array'})
                    ids.append(item['id'])
                    spectrum_array = item['Spectrum_Array']

                    if isinstance(spectrum_array, str):
                        spectrum_array = json.loads(spectrum_array)
                    if spectrum_array and not isinstance(spectrum_array[0], (int, float)):
                        spectrum_array = [float(x) for x in spectrum_array]

                    if not merged_spectrum:
                        merged_spectrum = spectrum_array
                    else:
                        merged_spectrum = [x + y for x, y in zip(merged_spectrum, spectrum_array)]

                if len(group) == group_size:
                    grouped_data.append({
                        'Spectrum_Array': merged_spectrum,
                        'time': group[0]['time'],
                        'ids': ids,
                        'filter_time': time,
                        'plate_id': group[0].get('plate_id', '')
                    })
                    group = []
                    ids = []
                    merged_spectrum = []

            if group and len(group) < group_size:
                return grouped_data

        return grouped_data

    except Exception as e:
        raise ValueError(f"Unexpected error in spectrum_sum: {str(e)}") from e
    
def spectrum_and_sum(data, group_size):
    try:
        """
        按指定组长度分组并计算 Spectrum_Array 的和。
    
        :param data: List[Dict], 原始数据列表。
        :param group_size: int, 每组的长度。
        :return: List[Dict], 分组计算后的结果列表。
        """
        if group_size <= 0:
            raise ValueError("group_and_sum: group_size 必须是正整数")

        result = []

        # 按组长度分组并计算
        for i in range(0, len(data) - group_size + 1, group_size):
            group = data[i:i + group_size]
            # 按 Spectrum_Array 累加
            combined_spectrum = [
                sum(values) for values in zip(
                    *(ast.literal_eval(item["Spectrum_Array"]) for item in group)
                )
            ]
            result.append({
                "Spectrum_Array": combined_spectrum,
                "time": group[0]["time"],
                "ids": [item["id"] for item in group]
            })

        return result
    except Exception as e:
        raise ValueError(f"Unexpected error in spectrum_and_sum:{str(e)}") from e
    
def send_zip(data):
    try:
        return base64.b64encode(
                    zlib.compress(json.dumps(data).encode('utf-8'))).decode('utf-8')
    except Exception as e:
        raise ValueError(f"Unexpected error in send_zip:{str(e)}") from e

def send_unzip(data):
    try:
        # 尝试解码base64数据
        decoded_data = base64.b64decode(data)
    except base64.binascii.Error as e:
        raise ValueError(f"Base64 decoding failed: {str(e)}") from e
    
    try:
        # 尝试解压缩数据
        decompressed_data = zlib.decompress(decoded_data)
    except zlib.error as e:
        raise ValueError(f"Zlib decompression failed: {str(e)}") from e
    
    try:
        # 尝试将解压缩后的数据解析为JSON
        return json.loads(decompressed_data.decode('utf-8'))
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON decoding failed: {str(e)}") from e
    except UnicodeDecodeError as e:
        raise ValueError(f"UTF-8 decoding failed: {str(e)}") from e
    
def create_unique_filename(folder_path, base_name, suffix):
    try:
        file_name = f"{base_name}{suffix}"
        file_path = os.path.join(folder_path, file_name)
        counter = 1

        while os.path.exists(file_path):
            file_name = f"{base_name}({counter}){suffix}"
            file_path = os.path.join(folder_path, file_name)
            counter += 1

        return file_name
    except Exception as e:
        raise ValueError(f"Error creating unique filename: {str(e)}") from e

def ensure_directory_existence(file_path):
    try:
        directory = os.path.dirname(file_path)
        if not os.path.exists(directory):
            os.makedirs(directory)
    except OSError as e:
        raise ValueError(f"Error ensuring directory existence: {str(e)}") from e
    
def writeFile(filePath, fileName, data, suffix='.wxsw'):
    try:
        fileName = create_unique_filename(filePath, fileName, suffix)
        ensure_directory_existence(os.path.join(filePath, fileName))
        data_json = json.dumps(data, ensure_ascii=False)
        
        with open(os.path.join(filePath, fileName), 'w', encoding='utf-8') as file:
            file.write(data_json)
        return fileName
    except json.JSONEncodeError as e:
        raise ValueError(f"JSON encoding failed: {str(e)}") from e
    except IOError as e:
        raise ValueError(f"File writing failed: {str(e)}") from e
    except Exception as e:
        raise ValueError(f"Unexpected error in writeFile: {str(e)}") from e

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
WebSocket 中间服务器客户端封装（带 owner_id + info）

功能：
- 长连接中间服务器： ws://SERVER/ws/{client_id}?owner_id=xxx
- 连接成功后立刻发送一条 type=register, info={...} 的注册消息（可选）
- 收到 type=task 的消息时：
    - 调用本地业务接口（例如 http://127.0.0.1:56882 + /api-single/project）
    - 把结果通过 WebSocket 发送 type=response 消息（带 msgId、result）
- 定时发送心跳 type=heartbeat
"""

import json
import time
import threading
import traceback
from typing import Dict, Any, Optional

import requests
from websocket import (
    create_connection,
    WebSocketConnectionClosedException,
    WebSocketTimeoutException,
)  # pip install websocket-client

import logging

logger = logging.getLogger(__name__)


class WsMiddleClient:
    def __init__(
        self,
        client_id: str,
        business_base_url: str,
        owner_id: str,
        middle_ws_base: str = "ws://127.0.0.1:8000/ws",
        heartbeat_interval: float = 10.0,
        reconnect_interval: float = 2.0,
        request_timeout: float = 15.0,
        info: Optional[Dict[str, Any]] = None,
    ):
        """
        :param client_id: 本客户端在中间服务器的 ID（要跟 ws 路径一致）
        :param business_base_url: 本地业务接口基地址，例如 "http://127.0.0.1:56882"
        :param owner_id: 该客户端所属的 owner 标识（任意字符串，需和调用 HTTP 接口时的 owner_id 保持一致）
        :param middle_ws_base: 中间服务器 ws 前缀，例如 "ws://127.0.0.1:8000/ws"
        :param heartbeat_interval: 心跳间隔秒数
        :param reconnect_interval: 断线后重连间隔秒数
        :param request_timeout: 调用本地业务接口的超时时间
        :param info: 客户端自定义信息，会通过 type=register 发给中间服务器，用于 /api-common/clients 展示
        """
        self.client_id = client_id
        self.business_base_url = business_base_url.rstrip("/")
        self.owner_id = owner_id
        self.info = info or {}

        # 关键：带上 owner_id 作为 query 参数，和服务端约定保持一致
        # ws://SERVER/ws/{client_id}?owner_id=xxx
        base = middle_ws_base.rstrip("/")
        self.middle_ws_url = f"{base}/{client_id}?owner_id={owner_id}"

        self.heartbeat_interval = heartbeat_interval
        self.reconnect_interval = reconnect_interval
        self.request_timeout = request_timeout

        self._thread: Optional[threading.Thread] = None
        self._stop_flag = False

    # ========== 外部只需要调用这个方法启动即可 ==========

    def start(self):
        """
        启动后台线程，自动连接中间服务器并开始收任务
        """
        if self._thread and self._thread.is_alive():
            logger.info("WsMiddleClient 已经在运行，无需重复启动")
            return

        self._stop_flag = False
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info(
            f"WsMiddleClient 启动：client_id={self.client_id}, "
            f"owner_id={self.owner_id}, "
            f"middle_ws_url={self.middle_ws_url}, "
            f"business_base_url={self.business_base_url}, "
            f"info={self.info}"
        )

    def stop(self):
        """
        停止客户端（可选）
        """
        self._stop_flag = True

    # ========== 内部实现 ==========

    def _loop(self):
        """整体循环：负责重连"""
        while not self._stop_flag:
            ws = None
            try:
                logger.info(f"[WS] 尝试连接中间服务器: {self.middle_ws_url}")
                ws = create_connection(self.middle_ws_url, timeout=10)
                logger.info("[WS] 连接中间服务器成功")

                # ✅ 连上之后发一条注册消息，告诉服务器我的 info
                if self.info:
                    try:
                        reg_msg = {"type": "register", "info": self.info}
                        ws.send(json.dumps(reg_msg, ensure_ascii=False))
                        logger.info(f"[WS] 已发送注册信息: {self.info}")
                    except Exception as e:
                        logger.error(f"[WS] 发送注册信息失败: {e}")
                        # 这里一般不强制断开，看需求

                self._run(ws)
            except WebSocketConnectionClosedException:
                logger.warning("[WS] 连接被关闭，准备重连...")
            except Exception as e:
                logger.error(f"[WS] 异常: {e}")
                traceback.print_exc()
            finally:
                if ws is not None:
                    try:
                        ws.close()
                    except Exception:
                        pass

            # 断线后稍等一会再重连
            if not self._stop_flag:
                time.sleep(self.reconnect_interval)

        logger.info("WsMiddleClient 已停止主循环")

    def _run(self, ws):
        """连接成功后的循环：心跳 + 接收任务"""
        last_heartbeat = time.time()

        while not self._stop_flag:
            # 1. 定时发送心跳
            now = time.time()
            if now - last_heartbeat > self.heartbeat_interval:
                hb = {"type": "heartbeat", "ts": now}
                try:
                    ws.send(json.dumps(hb))
                    # logger.debug("[WS] 已发送心跳")
                except Exception as e:
                    logger.error(f"[WS] 发送心跳失败: {e}")
                    # 出问题让外层重连
                    raise
                last_heartbeat = now

            # 2. 阻塞等待服务器消息
            try:
                raw = ws.recv()  # 如果连接断开会抛异常
            except WebSocketTimeoutException:
                # 只是超时没收到消息，很正常，继续下一轮循环即可
                continue
            except Exception as e:
                logger.error(f"[WS] 接收消息失败: {e}")
                raise

            if not raw:
                continue

            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                logger.warning(f"[WS] 收到非法 JSON: {raw}")
                continue

            msg_type = data.get("type")
            if msg_type == "task":
                self._handle_task(ws, data)
            elif msg_type in ("heartbeat_ack", None):
                # 心跳回应或服务端其它无关消息，先忽略
                pass
            else:
                logger.info(f"[WS] 收到未知类型消息: {data}")

    def _handle_task(self, ws, data: Dict[str, Any]):
        """
        处理从中间服务器收到的一条任务消息:
        {
          "type": "task",
          "msgId": "...",
          "from": "...",
          "to": "123456",
          "api": "/api-single/project",
          "method": "GET",
          "params": {...},
          "ts": ...
        }
        """
        msg_id = data.get("msgId")
        api = data.get("api")
        method = data.get("method", "GET")
        params = data.get("params") or {}

        logger.info(
            f"[TASK] msgId={msg_id}, api={api}, method={method}, params={params}"
        )

        success, status_code, body, error = self._call_local_api(api, method, params)

        result = {
            "success": success,
            "statusCode": status_code,
            "data": body,
            "error": error,
        }

        resp_msg = {
            "type": "response",
            "msgId": msg_id,
            "result": result,
        }

        try:
            ws.send(json.dumps(resp_msg, ensure_ascii=False))
            logger.info(
                f"[RESP] 已回传结果: msgId={msg_id}, success={success}, status={status_code}"
            )
        except Exception as e:
            logger.error(f"[RESP] 回传结果失败: {e}")
            # 这里抛异常让外层重连也可以，看你需求
            # raise

    def _call_local_api(self, api: str, method: str, params: Dict[str, Any]):
        """
        调用本地业务接口，例如 /api-single/project
        返回: (success: bool, status_code: int, body: Any, error: Optional[str])
        """
        # 支持完整 URL 或相对路径
        if isinstance(api, str) and api.startswith(("http://", "https://")):
            url = api
        else:
            url = self.business_base_url + api

        m = (method or "GET").upper()
        try:
            if m == "GET":
                r = requests.get(url, params=params, timeout=self.request_timeout)
            else:
                r = requests.request(m, url, json=params, timeout=self.request_timeout)

            try:
                body = r.json()
            except Exception:
                body = r.text

            return r.ok, r.status_code, body, None
        except Exception as e:
            logger.error(
                f"[LOCAL_API] 调用本地接口异常: {e}, url={url}, params={params}"
            )
            return False, 500, None, str(e)


# ========== 给 app.py 用的简单封装函数 ==========


def start_ws_middle_client(
    client_id: str,
    business_base_url: str,
    owner_id: str,
    middle_ws_base: str = "ws://127.0.0.1:8000/ws",
    info: Optional[Dict[str, Any]] = None,
):
    """
    提供给 app.py 调用的简易封装：
    在后台启动一个 WsMiddleClient，自动连中间服务器并开始收任务。

    用法：
        from ws_middle_client import start_ws_middle_client

        start_ws_middle_client(
            client_id="123456",
            business_base_url=f"http://{Config.HOST}:{Config.PORT}",
            owner_id="userA",
            info={
                "name": "采集客户端 A",
                "version": "1.0.3",
                "host": "10.0.0.5",
                "tags": ["生产环境", "windows"],
            },
        )
    """
    print(
        f"[WS] 启动中间服务器客户端: "
        f"client_id={client_id}, owner_id={owner_id}, "
        f"business_base_url={business_base_url}, middle_ws_base={middle_ws_base}, "
        f"info={info}"
    )
    client = WsMiddleClient(
        client_id=client_id,
        business_base_url=business_base_url,
        owner_id=owner_id,
        middle_ws_base=middle_ws_base,
        info=info,
    )
    client.start()
    return client  # 如果你后面想 stop，可以保存这个 client