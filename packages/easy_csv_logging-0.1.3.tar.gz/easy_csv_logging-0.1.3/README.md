how it works is that it is two functions oneto write to log and another to view log in terminal


log(*args)
This functions takes in values. Then these values get stored in csv_log.csv and in a more readable way in csv_log.txt


It has two more special cases.
One where there is 0 arguments then it adds an row where each colum has no values
One where there is 1 arguments then it fills in value under column 0 with the name  "_____".

Else arguments will be interprited as pairs of column_name,value. Where name is always first
The row will be filled based on these pairs.



#All of these are valid:



log("a",1,"b",3) 
log("2")
log()
log()
log()
log("patrik",999)
log("patrik",999)
log("patrik",999)
log("patrik","999öööööööö")
log("29999")
log("29999")
log("29999")
log()
log()
log()
log((2,2),(3,3),(4,4))
log(["2",2],["3",3],["4",4])
log([("2",2),("3",3),("4",4)])

This code will write this to csv_log.txt in the directory of the script where the module is called from. 
| _____:          | a: 1.0  | b: 3.0  | patrik:              | 2:      | 3:      | 4:      |
| _____: 2.0      | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik: 999.0        | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik: 999.0        | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik: 999.0        | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik: 999öööööööö  | 2:      | 3:      | 4:      |
| _____: 29999.0  | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____: 29999.0  | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____: 29999.0  | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik:              | 2:      | 3:      | 4:      |
| _____:          | a:      | b:      | patrik:              | 2: 2.0  | 3: 3.0  | 4: 4.0  |
| _____:          | a:      | b:      | patrik:              | 2: 2.0  | 3: 3.0  | 4: 4.0  |
| _____:          | a:      | b:      | patrik:              | 2: 2.0  | 3: 3.0  | 4: 4.0  |

csv_log.txt:

_____,a,b,patrik,2,3,4
,1.0,3.0,,,,
2.0,,,,,,
,,,,,,
,,,,,,
,,,,,,
,,,999.0,,,
,,,999.0,,,
,,,999.0,,,
,,,999öööööööö,,,
29999.0,,,,,,
29999.0,,,,,,
29999.0,,,,,,
,,,,,,
,,,,,,
,,,,,,
,,,,2.0,3.0,4.0
,,,,2.0,3.0,4.0
,,,,2,3,4





