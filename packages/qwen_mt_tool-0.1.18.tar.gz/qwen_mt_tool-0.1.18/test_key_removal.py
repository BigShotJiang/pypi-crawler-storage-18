
import sys
import os

# Add src to path
sys.path.insert(0, os.path.abspath("src"))

from qwen_mt_tool.cli import KeyPool, translate_text
import logging
from unittest.mock import MagicMock, patch
from openai import APIStatusError

# Setup logging to see output
logging.basicConfig(level=logging.INFO)

def test_key_removal():
    keys = ["invalid_key", "valid_key", "another_valid_key"]
    pool = KeyPool(keys)
    
    # Mocking OpenAI client and chat.completions.create
    with patch('qwen_mt_tool.cli.OpenAI') as MockOpenAI:
        mock_client = MockOpenAI.return_value
        
        def side_effect(model, messages, extra_body):
            # Get the api_key used for this call from the MockOpenAI call args
            # call_args format: ((arg1, ...), {kwarg1: val1, ...})
            # MockOpenAI is the class, so MockOpenAI() call is where kwargs are.
            call_args_list = MockOpenAI.call_args_list
            # Get the key from the most recent call
            used_key = call_args_list[-1].kwargs.get('api_key')
            print(f"DEBUG: API call with key: {used_key}")
            
            if used_key == "invalid_key":
                print("DEBUG: Triggering mock 401 error")
                # Create a mock 401 error
                mock_response = MagicMock()
                mock_response.status_code = 401
                raise APIStatusError("Unauthorized", response=mock_response, body=None)
            else:
                print(f"DEBUG: Returning success for key: {used_key}")
                # Return a valid response
                mock_completion = MagicMock()
                mock_completion.choices = [MagicMock(message=MagicMock(content="Translated content"))]
                mock_completion.usage = MagicMock(prompt_tokens=10, completion_tokens=10, total_tokens=20)
                return mock_completion

        mock_client.chat.completions.create.side_effect = side_effect
        
        print(f"Initial keys: {pool.keys}")
        
        # This call should encounter "invalid_key", remove it, and retry
        content, usage = translate_text("Hello", pool)
        
        print(f"Final keys: {pool.keys}")
        
        assert "invalid_key" not in pool.keys
        assert len(pool.keys) == 2
        assert content == "Translated content"
        print("Test passed!")

if __name__ == "__main__":
    test_key_removal()
