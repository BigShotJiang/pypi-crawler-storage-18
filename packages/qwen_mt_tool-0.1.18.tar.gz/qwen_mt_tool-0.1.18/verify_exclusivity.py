
import sys
import os
import threading
import time
from queue import Queue

# Add src to path
sys.path.insert(0, os.path.abspath("src"))

from qwen_mt_tool.cli import KeyPool
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)

def test_exclusivity():
    keys = ["key1", "key2"]
    pool = KeyPool(keys, qps=10) # High QPS to speed up test
    
    in_use = {k: False for k in keys}
    lock = threading.Lock()
    errors = []

    def worker(worker_id):
        for _ in range(5):
            with pool.acquire() as key:
                if key is None:
                    continue
                
                with lock:
                    if in_use[key]:
                        errors.append(f"Worker {worker_id}: Key {key} is already in use!")
                    in_use[key] = True
                
                print(f"Worker {worker_id} acquired {key}")
                time.sleep(0.1) # Simulate work
                
                with lock:
                    in_use[key] = False
                
                print(f"Worker {worker_id} released {key}")

    threads = []
    for i in range(10): # 10 workers for 2 keys
        t = threading.Thread(target=worker, args=(i,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    if errors:
        for err in errors:
            print(err)
        print("FAILED: Exclusivity broken!")
    else:
        print("PASSED: Exclusivity maintained!")

if __name__ == "__main__":
    test_exclusivity()
