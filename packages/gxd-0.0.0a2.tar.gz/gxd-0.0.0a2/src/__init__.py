# src/gxd/__init__.py
__version__ = "0.0.0a2"
