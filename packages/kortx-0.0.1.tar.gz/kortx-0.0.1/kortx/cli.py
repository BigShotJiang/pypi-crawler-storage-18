def main():
    print("Kortx CLI ativo 🚀")