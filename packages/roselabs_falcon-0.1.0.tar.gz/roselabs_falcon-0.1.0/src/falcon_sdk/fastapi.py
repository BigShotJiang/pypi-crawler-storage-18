"""
FastAPI middleware for Falcon error tracking.

Example:
    >>> from fastapi import FastAPI
    >>> from falcon_sdk import init
    >>> from falcon_sdk.fastapi import FalconMiddleware
    >>>
    >>> falcon = init(api_key="fk_xxx", app_name="my-app")
    >>> app = FastAPI()
    >>> app.add_middleware(FalconMiddleware, falcon=falcon)
    >>>
    >>> # Or use the convenience function:
    >>> from falcon_sdk.fastapi import instrument_fastapi
    >>> instrument_fastapi(app, falcon)
"""

from __future__ import annotations

import time
from typing import Any, Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

from .client import Falcon


class FalconMiddleware(BaseHTTPMiddleware):
    """
    FastAPI/Starlette middleware that captures unhandled exceptions.

    Usage:
        app.add_middleware(FalconMiddleware, falcon=falcon_instance)
    """

    def __init__(self, app: ASGIApp, falcon: Falcon) -> None:
        super().__init__(app)
        self.falcon = falcon

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        start_time = time.time()

        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            # Capture the exception with request context
            await self.falcon.capture_exception_async(
                exc,
                context=_build_request_context(request, start_time),
                level="error",
            )
            # Re-raise so FastAPI's exception handlers can process it
            raise


def instrument_fastapi(app: ASGIApp, falcon: Falcon) -> None:
    """
    Convenience function to add Falcon middleware to a FastAPI app.

    Args:
        app: The FastAPI application instance
        falcon: The Falcon SDK instance

    Example:
        >>> from fastapi import FastAPI
        >>> from falcon_sdk import init
        >>> from falcon_sdk.fastapi import instrument_fastapi
        >>>
        >>> app = FastAPI()
        >>> falcon = init(api_key="fk_xxx", app_name="my-app")
        >>> instrument_fastapi(app, falcon)
    """
    app.add_middleware(FalconMiddleware, falcon=falcon)  # type: ignore


def create_exception_handler(falcon: Falcon):
    """
    Create a FastAPI exception handler that reports to Falcon.

    Use this if you want to handle specific exception types while still
    reporting them to Falcon.

    Example:
        >>> from fastapi import FastAPI, HTTPException
        >>> from falcon_sdk import init
        >>> from falcon_sdk.fastapi import create_exception_handler
        >>>
        >>> app = FastAPI()
        >>> falcon = init(api_key="fk_xxx", app_name="my-app")
        >>>
        >>> @app.exception_handler(Exception)
        >>> async def handle_exception(request, exc):
        ...     handler = create_exception_handler(falcon)
        ...     return await handler(request, exc)
    """

    async def exception_handler(request: Request, exc: Exception) -> Response:
        from starlette.responses import JSONResponse

        # Capture to Falcon
        await falcon.capture_exception_async(
            exc,
            context=_build_request_context(request),
            level="error",
        )

        # Return a generic error response
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"},
        )

    return exception_handler


def _build_request_context(
    request: Request, start_time: float | None = None
) -> dict[str, Any]:
    """Build context dict from a Starlette/FastAPI request."""
    context: dict[str, Any] = {
        "request": {
            "method": request.method,
            "url": str(request.url),
            "path": request.url.path,
            "query_string": request.url.query,
            "headers": _sanitize_headers(dict(request.headers)),
            "client": request.client.host if request.client else None,
        }
    }

    if start_time:
        context["duration_ms"] = round((time.time() - start_time) * 1000, 2)

    # Add path parameters if available
    if hasattr(request, "path_params") and request.path_params:
        context["request"]["path_params"] = dict(request.path_params)

    return context


def _sanitize_headers(headers: dict[str, str]) -> dict[str, str]:
    """Remove sensitive headers before sending to Falcon."""
    sensitive = {
        "authorization",
        "cookie",
        "x-api-key",
        "x-auth-token",
        "x-access-token",
    }
    return {
        k: "[REDACTED]" if k.lower() in sensitive else v for k, v in headers.items()
    }
