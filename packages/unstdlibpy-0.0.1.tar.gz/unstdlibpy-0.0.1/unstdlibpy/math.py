
from include._math import sqrt, log, pi, sin, cos, tan, exp, acos

__all__ = ["hypotenuse", "logarithm", "exponential", "trigonometric_functions",
           "degrees_to_radians", "radians_to_degrees", "pythagorean_theorem",
           "area_of_circle", "circumference_of_circle", "factorial",
           "combinations", "permutations", "quadratic_formula", "mean",
           "median", "mode", "standard_deviation", "variance",
           "distance_between_points", "slope_of_line", "midpoint_of_line",
           "circle_equation", "linear_equation", "geometric_mean",
           "harmonic_mean", "fibonacci", "is_prime", "prime_factors",
           "lcm", "gcd", "quadratic_sequence", "arithmetic_sequence",
           "geometric_sequence", "sum_of_squares", "sum_of_cubes",
           "binomial_coefficient", "distance_formula", "midpoint_formula",
           "slope_formula", "herons_formula", "law_of_sines",
           "law_of_cosines", "arithmetic_mean", "weighted_mean",
           "quadratic_regression"]

def hypotenuse(a, b):
    """Calculate the hypotenuse of a right triangle given sides a and b."""
    return sqrt(a**2 + b**2)

def logarithm(x, base=10):
    """Calculate the logarithm of x to the given base."""
    if base == 'e':
        return log(x)
    return log(x, base)

def exponential(x):
    """Calculate the exponential of x."""
    return exp(x)

def trigonometric_functions(angle_rad):
    """Calculate the sine, cosine, and tangent of an angle in radians."""
    return {
        'sin': sin(angle_rad),
        'cos': cos(angle_rad),
        'tan': tan(angle_rad)
    }

def degrees_to_radians(degrees):
    """Convert degrees to radians."""
    return degrees * (pi / 180)

def radians_to_degrees(radians):
    """Convert radians to degrees."""
    return radians * (180 / pi)

def pythagorean_theorem(a, b):
    """Calculate the length of the hypotenuse using the Pythagorean theorem."""
    return sqrt(a**2 + b**2)

def area_of_circle(radius):
    """Calculate the area of a circle given its radius."""
    return pi * radius**2

def circumference_of_circle(radius):
    """Calculate the circumference of a circle given its radius."""
    return 2 * pi * radius

def factorial(n):
    """Calculate the factorial of a non-negative integer n."""
    if n < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    if n == 0 or n == 1:
        return 1
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result

def combinations(n, r):
    """Calculate the number of combinations of n items taken r at a time."""
    if r > n or n < 0 or r < 0:
        return 0
    return factorial(n) // (factorial(r) * factorial(n - r))

def permutations(n, r):
    """Calculate the number of permutations of n items taken r at a time."""
    if r > n or n < 0 or r < 0:
        return 0
    return factorial(n) // factorial(n - r)

def quadratic_formula(a, b, c):
    """Calculate the roots of a quadratic equation ax^2 + bx + c = 0."""
    discriminant = b**2 - 4*a*c
    if discriminant < 0:
        return None  # No real roots
    root1 = (-b + sqrt(discriminant)) / (2*a)
    root2 = (-b - sqrt(discriminant)) / (2*a)
    return (root1, root2)

def mean(numbers):
    """Calculate the mean of a list of numbers."""
    return sum(numbers) / len(numbers) if numbers else 0

def median(numbers):
    """Calculate the median of a list of numbers."""
    sorted_numbers = sorted(numbers)
    n = len(sorted_numbers)
    if n == 0:
        return 0
    mid = n // 2
    if n % 2 == 0:
        return (sorted_numbers[mid - 1] + sorted_numbers[mid]) / 2
    else:
        return sorted_numbers[mid]
    
def mode(numbers):
    """Calculate the mode of a list of numbers."""
    from collections import Counter
    if not numbers:
        return None
    count = Counter(numbers)
    max_count = max(count.values())
    modes = [k for k, v in count.items() if v == max_count]
    return modes if len(modes) > 1 else modes[0]

def standard_deviation(numbers):
    """Calculate the standard deviation of a list of numbers."""
    n = len(numbers)
    if n == 0:
        return 0
    mean_value = mean(numbers)
    variance = sum((x - mean_value) ** 2 for x in numbers) / n
    return sqrt(variance)

def variance(numbers):
    """Calculate the variance of a list of numbers."""
    n = len(numbers)
    if n == 0:
        return 0
    mean_value = mean(numbers)
    return sum((x - mean_value) ** 2 for x in numbers) / n

def distance_between_points(x1, y1, x2, y2):
    """Calculate the distance between two points (x1, y1) and (x2, y2)."""
    return sqrt((x2 - x1)**2 + (y2 - y1)**2)

def slope_of_line(x1, y1, x2, y2):
    """Calculate the slope of the line passing through points (x1, y1) and (x2, y2)."""
    if x2 - x1 == 0:
        raise ValueError("Slope is undefined for vertical lines.")
    return (y2 - y1) / (x2 - x1)

def midpoint_of_line(x1, y1, x2, y2):
    """Calculate the midpoint of the line segment between points (x1, y1) and (x2, y2)."""
    return ((x1 + x2) / 2, (y1 + y2) / 2)

def circle_equation(x, y, h, k, r):
    """Check if the point (x, y) lies on the circle with center (h, k) and radius r."""
    return (x - h)**2 + (y - k)**2 == r**2

def linear_equation(m, b, x):   
    """Calculate the y value of a linear equation y = mx + b for a given x."""
    return m * x + b

def geometric_mean(numbers):
    """Calculate the geometric mean of a list of numbers."""
    product = 1
    n = len(numbers)
    if n == 0:
        return 0
    for num in numbers:
        product *= num
    return product ** (1/n)

def harmonic_mean(numbers):
    """Calculate the harmonic mean of a list of numbers."""
    n = len(numbers)
    if n == 0:
        return 0
    reciprocal_sum = sum(1 / num for num in numbers if num != 0)
    if reciprocal_sum == 0:
        return 0
    return n / reciprocal_sum

def fibonacci(n):
    """Generate the first n Fibonacci numbers."""
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    fib_sequence = [0, 1]
    for i in range(2, n):
        next_fib = fib_sequence[-1] + fib_sequence[-2]
        fib_sequence.append(next_fib)
    return fib_sequence

def is_prime(num):
    """Check if a number is prime."""
    if num <= 1:
        return False
    for i in range(2, int(sqrt(num)) + 1):
        if num % i == 0:
            return False
    return True

def prime_factors(num):
    """Return the prime factors of a given number."""
    factors = []
    # Check for number of 2s that divide num
    while num % 2 == 0:
        factors.append(2)
        num //= 2
    # num must be odd at this point, so we can skip even numbers
    for i in range(3, int(sqrt(num)) + 1, 2):
        while num % i == 0:
            factors.append(i)
            num //= i
    # This condition is to check if num is a prime number greater than 2
    if num > 2:
        factors.append(num)
    return factors

def lcm(a, b):
    """Calculate the least common multiple of two numbers."""
    def gcd(x, y):
        while y:
            x, y = y, x % y
        return x
    return abs(a * b) // gcd(a, b)

def gcd(a, b):
    """Calculate the greatest common divisor of two numbers."""
    while b:
        a, b = b, a % b
    return abs(a)

def quadratic_sequence(n, a, b, c):
    """Generate the first n terms of a quadratic sequence defined by an^2 + bn + c."""
    return [a*i**2 + b*i + c for i in range(n)]

def arithmetic_sequence(n, a1, d):
    """Generate the first n terms of an arithmetic sequence with first term a1 and common difference d."""
    return [a1 + i*d for i in range(n)]

def geometric_sequence(n, a1, r):
    """Generate the first n terms of a geometric sequence with first term a1 and common ratio r."""
    return [a1 * r**i for i in range(n)]

def sum_of_squares(n):
    """Calculate the sum of squares of the first n natural numbers."""
    return sum(i**2 for i in range(1, n + 1))

def sum_of_cubes(n):
    """Calculate the sum of cubes of the first n natural numbers."""
    return sum(i**3 for i in range(1, n + 1))

def binomial_coefficient(n, k):
    """Calculate the binomial coefficient "n choose k"."""
    if k > n or n < 0 or k < 0:
        return 0
    return factorial(n) // (factorial(k) * factorial(n - k))

def distance_formula(x1, y1, x2, y2):
    """Calculate the distance between two points using the distance formula."""
    return sqrt((x2 - x1)**2 + (y2 - y1)**2)

def midpoint_formula(x1, y1, x2, y2):
    """Calculate the midpoint between two points using the midpoint formula."""
    return ((x1 + x2) / 2, (y1 + y2) / 2)

def slope_formula(x1, y1, x2, y2):
    """Calculate the slope of a line using the slope formula."""
    if x2 - x1 == 0:
        raise ValueError("Slope is undefined for vertical lines.")
    return (y2 - y1) / (x2 - x1)

def herons_formula(a, b, c):
    """Calculate the area of a triangle using Heron's formula given its side lengths a, b, and c."""
    s = (a + b + c) / 2
    return sqrt(s * (s - a) * (s - b) * (s - c))

def law_of_sines(a, A, b=None, B=None, c=None, C=None):
    """Calculate the missing side or angle using the Law of Sines."""
    if a and A and b is None and B:
        return (a * sin(B)) / sin(A)
    elif a and A and c is None and C:
        return (a * sin(C)) / sin(A)
    elif b and B and a is None and A:
        return (b * sin(A)) / sin(B)
    elif b and B and c is None and C:
        return (b * sin(C)) / sin(B)
    elif c and C and a is None and A:
        return (c * sin(A)) / sin(C)
    elif c and C and b is None and B:
        return (c * sin(B)) / sin(C)
    else:
        raise ValueError("Insufficient or incorrect parameters provided.")
    
def law_of_cosines(a=None, b=None, c=None, A=None, B=None, C=None):
    """Calculate the missing side or angle using the Law of Cosines."""
    if a and b and C is not None and c is None:
        return sqrt(a**2 + b**2 - 2*a*b*cos(C))
    elif a and c and B is not None and b is None:
        return sqrt(a**2 + c**2 - 2*a*c*cos(B))
    elif b and c and A is not None and a is None:
        return sqrt(b**2 + c**2 - 2*b*c*cos(A))
    elif a and b and c is not None and C is None:
        return acos((a**2 + b**2 - c**2) / (2*a*b))
    elif a and c and b is not None and B is None:
        return acos((a**2 + c**2 - b**2) / (2*a*c))
    elif b and c and a is not None and A is None:
        return acos((b**2 + c**2 - a**2) / (2*b*c))
    else:
        raise ValueError("Insufficient or incorrect parameters provided.")
    
def arithmetic_mean(numbers):
    """Calculate the arithmetic mean of a list of numbers."""
    return sum(numbers) / len(numbers) if numbers else 0

def weighted_mean(values, weights):
    """Calculate the weighted mean of a list of values with corresponding weights."""
    if len(values) != len(weights) or not values:
        return 0
    total_weight = sum(weights)
    if total_weight == 0:
        return 0
    return sum(v * w for v, w in zip(values, weights)) / total_weight

def quadratic_regression(x_values, y_values):
    """Perform quadratic regression on given x and y values."""
    n = len(x_values)
    if n != len(y_values) or n < 3:
        raise ValueError("Insufficient or mismatched data points for quadratic regression.")
    
    sum_x = sum(x_values)
    sum_y = sum(y_values)
    sum_x2 = sum(x**2 for x in x_values)
    sum_x3 = sum(x**3 for x in x_values)
    sum_x4 = sum(x**4 for x in x_values)
    sum_xy = sum(x*y for x, y in zip(x_values, y_values))
    sum_x2y = sum((x**2)*y for x, y in zip(x_values, y_values))
    
    # Set up the system of equations
    A = [
        [n,      sum_x,   sum_x2],
        [sum_x,  sum_x2,  sum_x3],
        [sum_x2, sum_x3,  sum_x4]
    ]
    
    B = [sum_y, sum_xy, sum_x2y]
    
    # Solve the system using Cramer's rule or any other method
    def determinant(matrix):
        return (matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1]) -
                matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0]) +
                matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]))
    
    D = determinant(A)
    
    if D == 0:
        raise ValueError("The system of equations has no unique solution.")
    
    # Calculate determinants for a, b, c
    A_a = [B, [A[1][1], A[1][2]], [A[2][1], A[2][2]]]
    A_b = [[A[0][0], B[0], A[0][2]], [A[1][0], B[1], A[1][2]], [A[2][0], B[2], A[2][2]]]
    A_c = [[A[0][0], A[0][1], B[0]], [A[1][0], A[1][1], B[1]], [A[2][0], A[2][1], B[2]]]

def determinant_2x2(matrix):
    return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]

