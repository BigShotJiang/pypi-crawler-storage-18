
import math, random

__version__ = "0.0.1"
