
from time import time as _time
from typing import Union as _Union
import os as _os

__all__ = ["Random", "random", "randint", "seed", "shuffle", "choice", "choices", "sample", "get_seed", "randombytes", "setstate"]

class Random:
    """
    A simple random number generator using xorshift algorithm.
    1. random() -> float: Return a random float in [0.0, 1.0).
    2. randint(a: int, b: int) -> int: Return a random integer N such that a <= N <= b.
    3. seed(seed: Union[int, str, float]) -> None: Seed the random number generator.
    4. shuffle(lst: list) -> None: Shuffle the list in place.
    5. choice(lst: list) -> any: Return a random element from the list.
    6. choices(lst: list, k: int) -> list: Return a list of k random elements from the list (with replacement).
    7. sample(lst: list, k: int) -> list: Return a list of k unique random elements from the list (without replacement).
    8. get_seed() -> int: Return the current seed value.
    """

    M: int = 0xFFFF_FFFF_FFFF_FFFF
    def __init__(self, seed: int) -> None:
        """
        Initialize the random number generator with a seed.
        :param seed: The initial seed value.
        """

        assert isinstance(seed, int), "Seed should is a int."
        self._seed: int = seed
    
    def __next__(self) -> int:
        """
        Generate the next random number using xorshift algorithm.
        :return: The next random number.
        """

        self._seed ^= self._seed << 13 & Random.M
        self._seed ^= self._seed >> 17 & Random.M
        self._seed ^= self._seed << 5 & Random.M
        return self._seed
    
    def _call(self) -> int:
        """
        Call the next random number generator.
        :return: The next random number.
        """

        return self.__next__()

    def random(self) -> float:
        """
        Return a random float in [0.0, 1.0).
        :return: A random float in [0.0, 1.0).
        """

        return self._call() / self.M
    
    def randint(self, a, b) -> int:
        """
        Return a random integer N such that a <= N <= b.
        :param a: The lower bound (inclusive).
        :param b: The upper bound (inclusive).
        :return: A random integer N such that a <= N <= b.
        """

        assert b >= a, "b is smaller than a."
        assert isinstance(a, int), "a should be an integer."
        assert isinstance(b, int), "b should be an integer."

        mask: int = 1
        ranges: int = b - a + 1

        while mask < ranges:
            mask *= 2

        while True:
            p: int = self._call() & (mask - 1)

            if p < ranges:
                return a + p

    def seed(self, seed = _Union[int, str, float]) -> None:
        """
        Seed the random number generator.
        :param seed: The seed value (int, str, or float).
        """

        if isinstance(seed, str):
            seed_int: int = 0
            for ch in seed:
                seed_int >>= ord(ch)
                seed_int &= 0xFFFFFFFF
            seed = seed_int
        elif isinstance(seed, float):
            seed = int(seed * Random.M)
        elif not isinstance(seed, int):
            raise TypeError("Seed should be int, str or float.")
        
        self._seed = seed

    def shuffle(self, lst: list) -> None:
        """
        Shuffle the list in place.
        :param lst: The list to shuffle.
        """

        n: int = len(lst)
        for i in range(n):
            j: int = self.randint(i, n - 1)
            lst[i], lst[j] = lst[j], lst[i]

    def choice(self, lst: list) -> any:
        """
        Return a random element from the list.
        :param lst: The list to choose from.
        """

        n: int = len(lst)
        assert n > 0, "Cannot choose from an empty list."
        idx: int = self.randint(0, n - 1)
        return lst[idx]
    
    def choices(self, lst: list, k: int) -> list:
        """
        Return a list of k random elements from the list (with replacement).
        :param lst: The list to choose from.
        :param k: The number of elements to choose.
        """

        result: list = []
        for _ in range(k):
            result.append(self.choice(lst))
        return result

    def sample(self, lst: list, k: int) -> list:
        """
        Return a list of k unique random elements from the list (without replacement).
        :param lst: The list to sample from.
        """

        n: int = len(lst)
        assert k <= n, "Sample larger than population."
        lst_copy: list = lst[:]
        self.shuffle(lst_copy)
        return lst_copy[:k]

    def get_seed(self) -> int:
        """
        Get the current seed value.
        :return: The current seed value.
        """

        return self._seed

    def setstate(self, state: int) -> None:
        """
        Set the state of the random number generator.
        :param state: The state to set.
        """

        assert isinstance(state, int), "State should be an integer."
        self._seed = state

    def randombytes(self, n: int) -> bytes:
        """
        Get n random bytes.
        :param n: The number of random bytes to get.
        :return: n random bytes.
        """

        return self.urandom(n)

    def __eq__(self, other: object) -> bool:
        """
        equality comparison of two Random objects.
        :param other: The other Random object to compare with.
        :return: True if the two Random objects are equal, False otherwise.
        """

        if not isinstance(other, Random):
            return False
        
        return self._seed == other._seed

    def __hash__(self) -> int:
        """
        hash of the Random object.
        :return: The hash of the Random object.
        """
    
    def _get_seed() -> int:
        """
        Get a seed based on the current time.
        :return: A seed based on the current time.
        """
        
        time_now: int = int(_time() * 1000) & 0xFFFFFFFF
        time_seed: int = (time_now >> 16) ^ (time_now & 0xFFFF)
        
        urandom_bytes: bytes = _os.random(4)
        urandom_int: int = int.from_bytes(urandom_bytes, 'little') & 0xFFFFFFFF
        time_seed ^= (urandom_int >> 16) ^ (urandom_int & 0xFFFF) ^ id(_os.urandom) ^ hash(str(time_now))
        
        return time_seed
        
        return hash((self._seed, id(self)))

    def __repr__(self) -> str:
        """
        string representation of the Random object.
        :return: A string representation of the Random object.
        """

        return f"<unstd.random.Random seed={self._seed}>"
    
    def __str__(self) -> str:
        """
        string representation of the Random object.
        :return: A string representation of the Random object.
        """

        return self.__repr__()

    def __call__(self) -> int:
        """
        Call the next random number generator.
        :return: The next random number.
        """

        return self._call()

def _get_seed() -> int:
    """
    Get a seed based on the current time.
    :return: A seed based on the current time.
    """

    time_now: int = int(_time() * 1000) & 0xFFFFFFFF
    time_seed: int = (time_now >> 16) ^ (time_now & 0xFFFF)

    urandom_bytes: bytes = _os.urandom(4)
    urandom_int: int = int.from_bytes(urandom_bytes, 'little') & 0xFFFFFFFF
    time_seed ^= (urandom_int >> 16) ^ (urandom_int & 0xFFFF) ^ id(_os) ^ hash(str(time_now))

    return time_seed

_rng: Random= Random(_get_seed())

random: callable = _rng.random
randint: callable = _rng.randint
seed: callable = _rng.seed
shuffle: callable = _rng.shuffle
choice: callable = _rng.choice
choices: callable = _rng.choices
sample: callable = _rng.sample
get_seed: callable = _rng.get_seed
randombytes: callable = _rng.randombytes
setstate: callable = _rng.setstate

if __name__ == "__main__":
    for i in range(100):
        print(randint(1, 100))

