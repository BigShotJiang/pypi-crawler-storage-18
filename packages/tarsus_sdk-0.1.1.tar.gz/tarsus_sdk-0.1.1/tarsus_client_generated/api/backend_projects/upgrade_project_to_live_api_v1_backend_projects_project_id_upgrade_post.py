from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.project_out import ProjectOut
from ...models.upgrade_project_request import UpgradeProjectRequest
from ...types import Response


def _get_kwargs(
    project_id: str,
    *,
    body: UpgradeProjectRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/backend/projects/{project_id}/upgrade".format(
            project_id=quote(str(project_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | ProjectOut | None:
    if response.status_code == 200:
        response_200 = ProjectOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | ProjectOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: UpgradeProjectRequest,
) -> Response[HTTPValidationError | ProjectOut]:
    """Upgrade Project To Live

     Upgrade a free project to live (paid) status.
    Requires payment method to be set up.
    Creates Stripe subscription for the project.

    Args:
        project_id (str):
        body (UpgradeProjectRequest): Request model for upgrading a project to live.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectOut]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: UpgradeProjectRequest,
) -> HTTPValidationError | ProjectOut | None:
    """Upgrade Project To Live

     Upgrade a free project to live (paid) status.
    Requires payment method to be set up.
    Creates Stripe subscription for the project.

    Args:
        project_id (str):
        body (UpgradeProjectRequest): Request model for upgrading a project to live.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectOut
    """

    return sync_detailed(
        project_id=project_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: UpgradeProjectRequest,
) -> Response[HTTPValidationError | ProjectOut]:
    """Upgrade Project To Live

     Upgrade a free project to live (paid) status.
    Requires payment method to be set up.
    Creates Stripe subscription for the project.

    Args:
        project_id (str):
        body (UpgradeProjectRequest): Request model for upgrading a project to live.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ProjectOut]
    """

    kwargs = _get_kwargs(
        project_id=project_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str,
    *,
    client: AuthenticatedClient,
    body: UpgradeProjectRequest,
) -> HTTPValidationError | ProjectOut | None:
    """Upgrade Project To Live

     Upgrade a free project to live (paid) status.
    Requires payment method to be set up.
    Creates Stripe subscription for the project.

    Args:
        project_id (str):
        body (UpgradeProjectRequest): Request model for upgrading a project to live.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ProjectOut
    """

    return (
        await asyncio_detailed(
            project_id=project_id,
            client=client,
            body=body,
        )
    ).parsed
