from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar(
    "T",
    bound="SetProjectPaymentMethodApiV1BackendProjectsProjectIdPaymentMethodPutPaymentMethodData",
)


@_attrs_define
class SetProjectPaymentMethodApiV1BackendProjectsProjectIdPaymentMethodPutPaymentMethodData:
    """ """

    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        set_project_payment_method_api_v1_backend_projects_project_id_payment_method_put_payment_method_data = cls()

        set_project_payment_method_api_v1_backend_projects_project_id_payment_method_put_payment_method_data.additional_properties = d
        return set_project_payment_method_api_v1_backend_projects_project_id_payment_method_put_payment_method_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
