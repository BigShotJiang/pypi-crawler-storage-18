"""Exception classes for dotpop."""

from typing import Optional


class DotpopError(Exception):
    """Base exception for all dotpop errors."""
    
    def __init__(self, message: str, file: Optional[str] = None, line: Optional[int] = None):
        self.message = message
        self.file = file
        self.line = line
        
        full_message = message
        if file:
            full_message = f"{file}"
            if line is not None:
                full_message += f":{line}"
            full_message += f": {message}"
        
        super().__init__(full_message)


class ParseError(DotpopError):
    """Error during parsing."""
    pass


class ValidationError(DotpopError):
    """Error during validation."""
    pass


class ResolutionError(DotpopError):
    """Error during variable resolution."""
    pass


class IncludeError(DotpopError):
    """Error during file inclusion."""
    pass


class CircularIncludeError(IncludeError):
    """Circular include detected."""
    pass


class ConditionError(DotpopError):
    """Error in conditional logic."""
    pass


class TypeError_(DotpopError):
    """Type conversion error."""
    pass


class ImmutableVariableError(DotpopError):
    """Attempted to modify an immutable variable."""
    pass


class ModificationError(DotpopError):
    """Error during variable modification."""
    pass
