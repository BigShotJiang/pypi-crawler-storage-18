"""Variable interpolation and resolution."""

import re
import random
from typing import Dict, Optional, Set

from .exceptions import ResolutionError


class Resolver:
    """Resolves variable interpolations and handles defaults."""
    
    # ${VAR} or ${VAR:-default}
    INTERPOLATION_PATTERN = re.compile(r'\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}')
    
    # ${VAR[index]} for list access
    LIST_INDEX_PATTERN = re.compile(r'\$\{([A-Za-z_][A-Za-z0-9_]*)\[(-?\d+)\]\}')
    
    # Functions: rand(), rand(max), rand(min,max)
    FUNCTION_PATTERN = re.compile(r'\$\{([a-z_]+)\(([^)]*)\)\}')
    
    def __init__(self, env: Dict[str, str], use_os_env: bool = True):
        self.env = env.copy()
        self.use_os_env = use_os_env
        
        # Merge OS environment if requested
        if use_os_env:
            import os
            for key, value in os.environ.items():
                if key not in self.env:
                    self.env[key] = value
    
    def resolve(self, value: str, key: str = None, file: str = None, line: int = None) -> str:
        """Resolve all interpolations in a value."""
        
        # Track variables we're resolving to detect cycles
        resolving = set()
        return self._resolve_recursive(value, key, resolving, file, line)
    
    def _resolve_recursive(
        self,
        value: str,
        key: Optional[str],
        resolving: Set[str],
        file: str = None,
        line: int = None
    ) -> str:
        """Recursively resolve interpolations."""
        
        if key and key in resolving:
            cycle = " -> ".join(resolving) + f" -> {key}"
            raise ResolutionError(f"Circular reference detected: {cycle}", file, line)
        
        if key:
            resolving.add(key)
        
        # First, resolve functions
        value = self._resolve_functions(value, file, line)
        
        # Then, resolve list indexing
        value = self._resolve_list_indexing(value, resolving, file, line)
        
        # Finally, resolve variable interpolations
        def replacer(match):
            var_name = match.group(1)
            default = match.group(2)
            
            # If referencing self with a default, use the default
            if var_name == key and default is not None:
                return default
            
            # Check if variable exists
            if var_name in self.env:
                var_value = self.env[var_name]
                # Recursively resolve the variable's value
                return self._resolve_recursive(var_value, var_name, resolving.copy(), file, line)
            elif default is not None:
                # Use default value
                return default
            else:
                # Variable not found and no default
                raise ResolutionError(
                    f"Undefined variable: ${{{var_name}}}",
                    file,
                    line
                )
        
        try:
            resolved = self.INTERPOLATION_PATTERN.sub(replacer, value)
            return resolved
        except ResolutionError:
            raise
        except Exception as e:
            raise ResolutionError(f"Error resolving value: {e}", file, line)
    
    def _resolve_functions(self, value: str, file: str = None, line: int = None) -> str:
        """Resolve function calls."""
        
        def function_replacer(match):
            func_name = match.group(1)
            args_str = match.group(2).strip()
            
            if func_name == "rand":
                return self._call_rand(args_str, file, line)
            else:
                raise ResolutionError(
                    f"Unknown function: {func_name}()",
                    file,
                    line
                )
        
        return self.FUNCTION_PATTERN.sub(function_replacer, value)
    
    def _call_rand(self, args_str: str, file: str = None, line: int = None) -> str:
        """Call rand() function with various argument patterns."""
        
        if not args_str:
            # rand() - random float [0.0, 1.0)
            return str(random.random())
        
        args = [arg.strip() for arg in args_str.split(',')]
        
        try:
            if len(args) == 1:
                # rand(max) - random int [0, max)
                max_val = int(args[0])
                return str(random.randint(0, max_val - 1))
            elif len(args) == 2:
                # rand(min, max) - random int [min, max)
                min_val = int(args[0])
                max_val = int(args[1])
                if min_val >= max_val:
                    raise ResolutionError(
                        f"rand(min, max): min must be less than max (got {min_val}, {max_val})",
                        file,
                        line
                    )
                return str(random.randint(min_val, max_val - 1))
            else:
                raise ResolutionError(
                    f"rand() takes 0, 1, or 2 arguments, got {len(args)}",
                    file,
                    line
                )
        except ValueError as e:
            raise ResolutionError(
                f"Invalid arguments for rand(): {e}",
                file,
                line
            )
    
    def _resolve_list_indexing(
        self,
        value: str,
        resolving: Set[str],
        file: str = None,
        line: int = None
    ) -> str:
        """Resolve list indexing like ${VAR[0]}."""
        
        def list_replacer(match):
            var_name = match.group(1)
            index = int(match.group(2))
            
            if var_name not in self.env:
                raise ResolutionError(
                    f"Undefined variable for list access: {var_name}",
                    file,
                    line
                )
            
            # Get the resolved value
            var_value = self._resolve_recursive(
                self.env[var_name],
                var_name,
                resolving.copy(),
                file,
                line
            )
            
            # Parse as list (comma-separated)
            items = [item.strip() for item in var_value.split(',')]
            
            try:
                return items[index]
            except IndexError:
                raise ResolutionError(
                    f"List index out of range: {var_name}[{index}] (list has {len(items)} items)",
                    file,
                    line
                )
        
        return self.LIST_INDEX_PATTERN.sub(list_replacer, value)
    
    def resolve_all(self, env: Dict[str, str], file: str = None) -> Dict[str, str]:
        """Resolve all values in an environment dictionary."""
        resolved = {}
        
        for key, value in env.items():
            try:
                resolved[key] = self.resolve(value, key, file)
            except ResolutionError:
                raise
        
        return resolved
