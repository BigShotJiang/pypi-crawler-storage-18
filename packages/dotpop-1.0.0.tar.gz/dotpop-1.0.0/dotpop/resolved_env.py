"""ResolvedEnv class to hold parsed and resolved environment variables."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .exceptions import ImmutableVariableError, ModificationError
from .types import convert_type
from .validators import validate_value


@dataclass
class SourceInfo:
    """Information about where a variable was defined."""
    file: str
    line: int


@dataclass
class ResolvedEnv:
    """Container for resolved environment variables."""
    
    values: Dict[str, str] = field(default_factory=dict)
    """Resolved string values"""
    
    typed: Dict[str, Any] = field(default_factory=dict)
    """Typed values (after type conversion)"""
    
    sources: Dict[str, SourceInfo] = field(default_factory=dict)
    """Source file and line for each variable"""
    
    warnings: List[str] = field(default_factory=list)
    """Any warnings generated during loading"""
    
    _types: Dict[str, str] = field(default_factory=dict)
    """Type information for each variable"""
    
    _validators: Dict[str, Dict[str, str]] = field(default_factory=dict)
    """Validator information for each variable"""
    
    _mutable_vars: Set[str] = field(default_factory=set)
    """Variables that can be modified (appeared in conditionals)"""
    
    _conditional_vars: Set[str] = field(default_factory=set)
    """Variables used in conditional expressions"""
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get a typed value, with optional default."""
        return self.typed.get(key, default)
    
    def get_str(self, key: str, default: str = None) -> Optional[str]:
        """Get a string value, with optional default."""
        return self.values.get(key, default)
    
    def __getitem__(self, key: str) -> Any:
        """Get a typed value by key."""
        return self.typed[key]
    
    def __contains__(self, key: str) -> bool:
        """Check if a key exists."""
        return key in self.values
    
    def keys(self):
        """Return all keys."""
        return self.values.keys()
    
    def items(self):
        """Return all typed items."""
        return self.typed.items()
    
    def set(self, key: str, value: Any, force: bool = False) -> None:
        """
        Set or modify a variable value with validation.
        
        Args:
            key: Variable name to set
            value: New value (will be converted to string first, then typed)
            force: If True, bypass mutability checks
        
        Raises:
            ImmutableVariableError: If variable is not mutable and force=False
            ModificationError: If validation or type conversion fails
        """
        if key not in self.values:
            raise ModificationError(f"Variable '{key}' does not exist. Cannot set undefined variables.")
        
        if not force and key not in self._mutable_vars:
            raise ImmutableVariableError(
                f"Variable '{key}' is immutable. It was not defined in a conditional block. "
                f"Use force=True to override, or make it appear in a conditional."
            )
        
        value_str = str(value)
        type_name = self._types.get(key, "str")
        
        try:
            typed_value = convert_type(
                value_str,
                type_name,
                key,
                self.sources[key].file,
                self.sources[key].line
            )
        except Exception as e:
            raise ModificationError(
                f"Failed to convert value for '{key}': {e}",
                self.sources[key].file,
                self.sources[key].line
            )
        
        if key in self._validators:
            try:
                validate_value(
                    key,
                    typed_value,
                    self._validators[key],
                    self.sources[key].file,
                    self.sources[key].line
                )
            except Exception as e:
                raise ModificationError(
                    f"Validation failed for '{key}': {e}",
                    self.sources[key].file,
                    self.sources[key].line
                )
        
        self.values[key] = value_str
        self.typed[key] = typed_value
    
    def set_conditional_var(self, key: str, value: Any) -> None:
        """
        Set a variable that appears in conditional expressions.
        This triggers re-evaluation logic if needed.
        
        Args:
            key: Variable name (must be in conditional_vars)
            value: New value
        
        Raises:
            ModificationError: If variable is not a conditional variable
        """
        if key not in self._conditional_vars:
            raise ModificationError(
                f"Variable '{key}' is not a conditional variable. "
                f"Only variables used in @if/@elif conditions can be set with this method. "
                f"Conditional variables: {', '.join(sorted(self._conditional_vars))}"
            )
        
        self.set(key, value, force=True)
    
    def is_mutable(self, key: str) -> bool:
        """Check if a variable can be modified."""
        return key in self._mutable_vars
    
    def is_conditional(self, key: str) -> bool:
        """Check if a variable is used in conditionals."""
        return key in self._conditional_vars
    
    def get_type(self, key: str) -> Optional[str]:
        """Get the type of a variable."""
        return self._types.get(key)
    
    def get_validators(self, key: str) -> Optional[Dict[str, str]]:
        """Get the validators for a variable."""
        return self._validators.get(key)
    
    def get_mutable_vars(self) -> Set[str]:
        """Get all mutable variables."""
        return self._mutable_vars.copy()
    
    def get_conditional_vars(self) -> Set[str]:
        """Get all conditional variables."""
        return self._conditional_vars.copy()
    
    def __repr__(self) -> str:
        return f"ResolvedEnv(keys={list(self.values.keys())})"
