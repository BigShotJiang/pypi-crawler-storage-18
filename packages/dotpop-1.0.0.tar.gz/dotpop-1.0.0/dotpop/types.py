"""Type conversion utilities."""

import json
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .exceptions import TypeError_


def convert_type(value: str, type_name: str, key: str, file: str = None, line: int = None) -> Any:
    """Convert string value to specified type."""
    
    try:
        if type_name == "str":
            return value
        
        elif type_name == "int":
            return int(value)
        
        elif type_name == "float":
            return float(value)
        
        elif type_name == "bool":
            lower = value.lower()
            if lower in ("true", "1", "yes", "on"):
                return True
            elif lower in ("false", "0", "no", "off", ""):
                return False
            else:
                raise ValueError(f"Cannot convert '{value}' to bool")
        
        elif type_name == "json":
            return json.loads(value)
        
        elif type_name == "list":
            # Split by comma, strip whitespace
            if not value:
                return []
            return [item.strip() for item in value.split(",")]
        
        elif type_name == "path":
            return Path(value)
        
        elif type_name == "url":
            # Allow empty URLs (for optional configurations)
            if not value or value.strip() == "":
                return ""
            
            # Validate URL structure
            result = urlparse(value)
            if not result.scheme or not result.netloc:
                raise ValueError(f"Invalid URL: {value}")
            return value
        
        else:
            raise TypeError_(f"Unknown type: {type_name}", file, line)
    
    except (ValueError, json.JSONDecodeError) as e:
        raise TypeError_(
            f"Cannot convert '{value}' to {type_name} for key '{key}': {e}",
            file,
            line
        )
