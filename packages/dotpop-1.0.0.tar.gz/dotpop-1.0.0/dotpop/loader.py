"""Main loader for .env and .dpop files."""

import os
from pathlib import Path
from typing import Dict, List, Optional, Set

from .conditions import ConditionEvaluator
from .exceptions import CircularIncludeError, ConditionError, IncludeError
from .parser import ParsedLine, parse_file, parse_string
from .resolved_env import ResolvedEnv, SourceInfo
from .resolver import Resolver
from .types import convert_type
from .validators import validate_value


class Loader:
    """Loads and processes .env and .dpop files."""
    
    def __init__(self, strict: bool = True, use_os_env: bool = True):
        self.strict = strict
        self.use_os_env = use_os_env
        self.included_files: Set[Path] = set()
        self.warnings: List[str] = []
    
    def load_file(self, path: Path, format: str = "auto") -> ResolvedEnv:
        """Load a single file."""
        
        if path.name == ".dpop" or path.name.startswith(".dpop."):
            format = "dpop"
        else:
            raise ValueError(
                f"Only .dpop or .dpop.* files are supported, got: {path.name}. "
                f"Examples: .dpop, .dpop.production, .dpop.database"
            )
        
        self.included_files = set()
        self.warnings = []
        
        raw_env = {}
        sources = {}
        types = {}
        validators_map = {}
        
        self._process_file(
            path,
            raw_env,
            sources,
            types,
            validators_map,
            format == "dpop"
        )
        
        resolver = Resolver(raw_env, self.use_os_env)
        resolved_values = resolver.resolve_all(raw_env, str(path))
        
        typed_values = {}
        for key, value in resolved_values.items():
            type_name = types.get(key, "str")
            source = sources[key]
            
            typed_value = convert_type(
                value,
                type_name,
                key,
                source.file,
                source.line
            )
            typed_values[key] = typed_value
            
            if key in validators_map:
                validate_value(
                    key,
                    typed_value,
                    validators_map[key],
                    source.file,
                    source.line
                )
        
        mutable_vars = set()
        conditional_vars = set()
        
        parsed_lines = parse_file(path)
        self._identify_conditional_vars(
            parsed_lines,
            mutable_vars,
            conditional_vars
        )
        
        resolved_env = ResolvedEnv(
            values=resolved_values,
            typed=typed_values,
            sources=sources,
            warnings=self.warnings
        )
        resolved_env._types = types
        resolved_env._validators = validators_map
        resolved_env._mutable_vars = mutable_vars
        resolved_env._conditional_vars = conditional_vars
        
        return resolved_env
    
    def load_string(self, text: str, format: str = "auto", file: str = "<string>") -> ResolvedEnv:
        """Load from a string."""
        
        if format in ("dotpop", "dpop"):
            format = "dpop"
        elif format == "auto":
            if "@include" in text or "@if" in text or (":" in text and "=" in text):
                format = "dpop"
            else:
                format = "env"
        
        self.included_files = set()
        self.warnings = []
        
        parsed_lines = parse_string(text, file)
        
        raw_env = {}
        sources = {}
        types = {}
        validators_map = {}
        
        self._process_lines(
            parsed_lines,
            Path(file).parent if file != "<string>" else Path.cwd(),
            raw_env,
            sources,
            types,
            validators_map,
            format == "dpop",
            file
        )
        
        resolver = Resolver(raw_env, self.use_os_env)
        resolved_values = resolver.resolve_all(raw_env, file)
        
        typed_values = {}
        for key, value in resolved_values.items():
            type_name = types.get(key, "str")
            source = sources[key]
            
            typed_value = convert_type(
                value,
                type_name,
                key,
                source.file,
                source.line
            )
            typed_values[key] = typed_value
            
            if key in validators_map:
                validate_value(
                    key,
                    typed_value,
                    validators_map[key],
                    source.file,
                    source.line
                )
        
        return ResolvedEnv(
            values=resolved_values,
            typed=typed_values,
            sources=sources,
            warnings=self.warnings
        )
    
    def _process_file(
        self,
        path: Path,
        raw_env: Dict[str, str],
        sources: Dict[str, SourceInfo],
        types: Dict[str, str],
        validators_map: Dict[str, Dict[str, str]],
        is_dpop: bool
    ):
        """Process a single file."""
        
        abs_path = path.resolve()
        if abs_path in self.included_files:
            raise CircularIncludeError(f"Circular include detected: {path}")
        
        self.included_files.add(abs_path)
        
        try:
            parsed_lines = parse_file(path)
            self._process_lines(
                parsed_lines,
                path.parent,
                raw_env,
                sources,
                types,
                validators_map,
                is_dpop,
                str(path)
            )
        finally:
            self.included_files.discard(abs_path)
    
    def _process_lines(
        self,
        parsed_lines: List[ParsedLine],
        base_dir: Path,
        raw_env: Dict[str, str],
        sources: Dict[str, SourceInfo],
        types: Dict[str, str],
        validators_map: Dict[str, Dict[str, str]],
        is_dpop: bool,
        current_file: str
    ):
        """Process parsed lines with condition and include support."""
        
        condition_stack = []
        skip_stack = [False]
        
        i = 0
        while i < len(parsed_lines):
            line = parsed_lines[i]
            
            current_skip = skip_stack[-1]
            
            if line.type == 'blank' or line.type == 'comment':
                i += 1
                continue
            
            elif line.type == 'if':
                if not is_dpop:
                    raise ConditionError(
                        "Conditions not allowed in .env files",
                        current_file,
                        line.line_number
                    )
                
                evaluator = ConditionEvaluator(raw_env)
                result = evaluator.evaluate(line.condition, current_file, line.line_number)
                
                condition_stack.append({'type': 'if', 'matched': result})
                skip_stack.append(current_skip or not result)
                
                i += 1
                continue
            
            elif line.type == 'elif':
                if not condition_stack:
                    raise ConditionError(
                        "@elif without matching @if",
                        current_file,
                        line.line_number
                    )
                
                current_block = condition_stack[-1]
                if current_block['type'] not in ('if', 'elif'):
                    raise ConditionError(
                        "@elif after @else",
                        current_file,
                        line.line_number
                    )
                
                evaluator = ConditionEvaluator(raw_env)
                result = evaluator.evaluate(line.condition, current_file, line.line_number)
                
                matched_before = current_block['matched']
                current_block['type'] = 'elif'
                current_block['matched'] = matched_before or result
                
                skip_stack[-1] = current_skip or matched_before or not result
                
                i += 1
                continue
            
            elif line.type == 'else':
                if not condition_stack:
                    raise ConditionError(
                        "@else without matching @if",
                        current_file,
                        line.line_number
                    )
                
                current_block = condition_stack[-1]
                if current_block['type'] == 'else':
                    raise ConditionError(
                        "Multiple @else blocks",
                        current_file,
                        line.line_number
                    )
                
                matched_before = current_block['matched']
                current_block['type'] = 'else'
                
                skip_stack[-1] = current_skip or matched_before
                
                i += 1
                continue
            
            elif line.type == 'end':
                if not condition_stack:
                    raise ConditionError(
                        "@end without matching @if",
                        current_file,
                        line.line_number
                    )
                
                condition_stack.pop()
                skip_stack.pop()
                
                i += 1
                continue
            
            elif line.type == 'include':
                if not is_dpop:
                    raise IncludeError(
                        "Includes not allowed in .env files",
                        current_file,
                        line.line_number
                    )
                
                if current_skip:
                    i += 1
                    continue
                
                include_path = base_dir / line.include_path
                
                resolver = Resolver(raw_env, self.use_os_env)
                resolved_path_str = resolver.resolve(
                    str(include_path),
                    None,
                    current_file,
                    line.line_number
                )
                include_path = Path(resolved_path_str)
                
                if not include_path.exists():
                    raise IncludeError(
                        f"Include file not found: {include_path}",
                        current_file,
                        line.line_number
                    )
                
                self._process_file(
                    include_path,
                    raw_env,
                    sources,
                    types,
                    validators_map,
                    is_dpop
                )
                
                i += 1
                continue
            
            elif line.type == 'assignment':
                if current_skip:
                    i += 1
                    continue
                
                should_set = line.override or line.key not in raw_env
                
                if should_set:
                    raw_env[line.key] = line.value
                    sources[line.key] = SourceInfo(current_file, line.line_number)
                    types[line.key] = line.type_name
                    
                    if line.validators:
                        validators_map[line.key] = line.validators
                
                i += 1
                continue
            
            i += 1
        
        if condition_stack:
            raise ConditionError(
                f"Unclosed condition block (missing @end)",
                current_file
            )
    
    def _identify_conditional_vars(
        self,
        parsed_lines: List[ParsedLine],
        mutable_vars: Set[str],
        conditional_vars: Set[str]
    ):
        """Identify variables that appear in conditionals and variables defined within conditional blocks."""
        import re
        
        in_conditional = False
        
        for line in parsed_lines:
            if line.type in ('if', 'elif'):
                in_conditional = True
                var_match = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)\s*[!=]=', line.condition)
                if var_match:
                    conditional_vars.add(var_match.group(1))
                defined_match = re.search(r'(?:not_)?defined\(([A-Za-z_][A-Za-z0-9_]*)\)', line.condition)
                if defined_match:
                    conditional_vars.add(defined_match.group(1))
            
            elif line.type == 'end':
                in_conditional = False
            
            elif line.type == 'assignment' and in_conditional:
                mutable_vars.add(line.key)


def load(
    path: str,
    format: str = "auto",
    strict: bool = True,
    use_os_env: bool = True
) -> ResolvedEnv:
    """
    Load environment variables from a file.
    
    Args:
        path: Path to the file
        format: File format ("auto", "env", "dpop", or "dotpop")
        strict: If True, raise errors on validation failures
        use_os_env: If True, merge with OS environment variables
    
    Returns:
        ResolvedEnv containing parsed and resolved variables
    """
    loader = Loader(strict=strict, use_os_env=use_os_env)
    return loader.load_file(Path(path), format=format)


def loads(
    text: str,
    format: str = "auto",
    strict: bool = True,
    use_os_env: bool = True,
    file: str = "<string>"
) -> ResolvedEnv:
    """
    Load environment variables from a string.
    
    Args:
        text: Text content to parse
        format: File format ("auto", "env", "dpop", or "dotpop")
        strict: If True, raise errors on validation failures
        use_os_env: If True, merge with OS environment variables
        file: Name to use for error messages
    
    Returns:
        ResolvedEnv containing parsed and resolved variables
    """
    loader = Loader(strict=strict, use_os_env=use_os_env)
    return loader.load_string(text, format=format, file=file)
