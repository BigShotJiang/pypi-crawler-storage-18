"""dotpop: dotenv++ parser with types, validation, and conditions."""

__version__ = "1.0.0"

from .loader import load, loads
from .resolved_env import ResolvedEnv
from .helpers import apply, export
from .exceptions import (
    DotpopError,
    ParseError,
    ValidationError,
    ResolutionError,
    IncludeError,
    CircularIncludeError,
    ConditionError,
    TypeError_,
    ImmutableVariableError,
    ModificationError
)

__all__ = [
    "load",
    "loads",
    "ResolvedEnv",
    "apply",
    "export",
    "DotpopError",
    "ParseError",
    "ValidationError",
    "ResolutionError",
    "IncludeError",
    "CircularIncludeError",
    "ConditionError",
    "TypeError_",
    "ImmutableVariableError",
    "ModificationError"
]
