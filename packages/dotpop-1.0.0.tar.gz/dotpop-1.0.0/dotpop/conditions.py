"""Condition evaluation engine."""

import re
from typing import Dict

from .exceptions import ConditionError


class ConditionEvaluator:
    """Evaluates conditional expressions."""
    
    # Patterns for condition parsing
    EQUALS_PATTERN = re.compile(r'^(.+?)\s*==\s*"([^"]*)"$')
    EQUALS_PATTERN_UNQUOTED = re.compile(r'^(.+?)\s*==\s*(.+)$')
    NOT_EQUALS_PATTERN = re.compile(r'^(.+?)\s*!=\s*"([^"]*)"$')
    NOT_EQUALS_PATTERN_UNQUOTED = re.compile(r'^(.+?)\s*!=\s*(.+)$')
    DEFINED_PATTERN = re.compile(r'^defined\(([A-Za-z_][A-Za-z0-9_]*)\)$')
    NOT_DEFINED_PATTERN = re.compile(r'^not_defined\(([A-Za-z_][A-Za-z0-9_]*)\)$')
    
    def __init__(self, env: Dict[str, str]):
        self.env = env
    
    def evaluate(self, condition: str, file: str = None, line: int = None) -> bool:
        """Evaluate a condition expression."""
        condition = condition.strip()
        
        # defined(VAR)
        match = self.DEFINED_PATTERN.match(condition)
        if match:
            var = match.group(1)
            return var in self.env
        
        # not_defined(VAR)
        match = self.NOT_DEFINED_PATTERN.match(condition)
        if match:
            var = match.group(1)
            return var not in self.env
        
        # VAR == "value"
        match = self.EQUALS_PATTERN.match(condition)
        if match:
            var = match.group(1).strip()
            expected = match.group(2)
            actual = self.env.get(var, "")
            return actual == expected
        
        # VAR == value (unquoted)
        match = self.EQUALS_PATTERN_UNQUOTED.match(condition)
        if match:
            var = match.group(1).strip()
            expected = match.group(2).strip()
            actual = self.env.get(var, "")
            return actual == expected
        
        # VAR != "value"
        match = self.NOT_EQUALS_PATTERN.match(condition)
        if match:
            var = match.group(1).strip()
            expected = match.group(2)
            actual = self.env.get(var, "")
            return actual != expected
        
        # VAR != value (unquoted)
        match = self.NOT_EQUALS_PATTERN_UNQUOTED.match(condition)
        if match:
            var = match.group(1).strip()
            expected = match.group(2).strip()
            actual = self.env.get(var, "")
            return actual != expected
        
        raise ConditionError(f"Invalid condition syntax: {condition}", file, line)
