"""Parser for .env and .dpop files."""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .exceptions import ParseError


@dataclass
class ParsedLine:
    """Represents a parsed line from the file."""
    type: str  # 'assignment', 'include', 'if', 'elif', 'else', 'end', 'comment', 'blank'
    key: Optional[str] = None
    value: Optional[str] = None
    type_name: Optional[str] = None
    validators: Optional[Dict[str, str]] = None
    condition: Optional[str] = None
    include_path: Optional[str] = None
    override: bool = False
    line_number: int = 0
    raw_line: str = ""


class Parser:
    """Parser for .env and .dpop files."""
    
    # Patterns
    COMMENT_PATTERN = re.compile(r'^\s*#')
    BLANK_PATTERN = re.compile(r'^\s*$')
    INCLUDE_PATTERN = re.compile(r'^\s*@include\s+"([^"]+)"')
    CONDITION_PATTERN = re.compile(r'^\s*@(if|elif)\s+(.+)')
    ELSE_PATTERN = re.compile(r'^\s*@else\s*$')
    END_PATTERN = re.compile(r'^\s*@end\s*$')
    
    # Assignment patterns
    OVERRIDE_PATTERN = re.compile(r'^\s*(!|@override\s+)(.+)')
    EXPORT_PATTERN = re.compile(r'^\s*export\s+(.+)')
    ASSIGNMENT_PATTERN = re.compile(
        r'^\s*([A-Za-z_][A-Za-z0-9_]*)'  # Key with optional leading whitespace
        r'(?::([a-z]+))?'              # Optional type
        r'\s*=\s*'                      # Equals
        r'(.*?)'                        # Value (non-greedy)
        r'(?:\s*\|\s*(.+))?$'          # Optional validators
    )
    
    def __init__(self, text: str, file: str = "<string>"):
        self.text = text
        self.file = file
        self.lines = text.splitlines()
    
    def parse(self) -> List[ParsedLine]:
        """Parse the entire file and return list of parsed lines."""
        parsed_lines = []
        
        for line_num, line in enumerate(self.lines, 1):
            parsed = self._parse_line(line, line_num)
            parsed_lines.append(parsed)
        
        return parsed_lines
    
    def _parse_line(self, line: str, line_num: int) -> ParsedLine:
        """Parse a single line."""
        
        # Comments
        if self.COMMENT_PATTERN.match(line):
            return ParsedLine(type='comment', line_number=line_num, raw_line=line)
        
        # Blank lines
        if self.BLANK_PATTERN.match(line):
            return ParsedLine(type='blank', line_number=line_num, raw_line=line)
        
        # @include
        include_match = self.INCLUDE_PATTERN.match(line)
        if include_match:
            return ParsedLine(
                type='include',
                include_path=include_match.group(1),
                line_number=line_num,
                raw_line=line
            )
        
        # @if / @elif
        condition_match = self.CONDITION_PATTERN.match(line)
        if condition_match:
            return ParsedLine(
                type=condition_match.group(1),  # 'if' or 'elif'
                condition=condition_match.group(2).strip(),
                line_number=line_num,
                raw_line=line
            )
        
        # @else
        if self.ELSE_PATTERN.match(line):
            return ParsedLine(type='else', line_number=line_num, raw_line=line)
        
        # @end
        if self.END_PATTERN.match(line):
            return ParsedLine(type='end', line_number=line_num, raw_line=line)
        
        # Override (!KEY=VALUE or @override KEY=VALUE)
        override_match = self.OVERRIDE_PATTERN.match(line)
        override = False
        if override_match:
            override = True
            line = override_match.group(2)
        
        # Export (optional)
        export_match = self.EXPORT_PATTERN.match(line)
        if export_match:
            line = export_match.group(1)
        
        # Assignment
        assignment_match = self.ASSIGNMENT_PATTERN.match(line)
        if assignment_match:
            key = assignment_match.group(1)
            type_name = assignment_match.group(2) or "str"
            raw_value = assignment_match.group(3)
            validators_str = assignment_match.group(4)
            
            # Parse value (handle quotes)
            value = self._parse_value(raw_value)
            
            # Parse validators
            validators = self._parse_validators(validators_str) if validators_str else {}
            
            return ParsedLine(
                type='assignment',
                key=key,
                value=value,
                type_name=type_name,
                validators=validators,
                override=override,
                line_number=line_num,
                raw_line=line
            )
        
        # If we get here, it's an invalid line
        raise ParseError(f"Invalid syntax: {line}", self.file, line_num)
    
    def _parse_value(self, raw_value: str) -> str:
        """Parse value, handling quotes."""
        raw_value = raw_value.strip()
        
        # Handle quoted strings
        if (raw_value.startswith('"') and raw_value.endswith('"')) or \
           (raw_value.startswith("'") and raw_value.endswith("'")):
            # Remove quotes and unescape
            value = raw_value[1:-1]
            value = value.replace('\\n', '\n')
            value = value.replace('\\t', '\t')
            value = value.replace('\\r', '\r')
            value = value.replace('\\"', '"')
            value = value.replace("\\'", "'")
            value = value.replace('\\\\', '\\')
            return value
        
        return raw_value
    
    def _parse_validators(self, validators_str: str) -> Dict[str, str]:
        """Parse validator chain."""
        validators = {}
        
        parts = [p.strip() for p in validators_str.split('|')]
        for part in parts:
            if '=' in part:
                name, value = part.split('=', 1)
                validators[name.strip()] = value.strip()
            else:
                # Flag validator (no value)
                validators[part] = ""
        
        return validators


def parse_file(path: Path) -> List[ParsedLine]:
    """Parse a file and return parsed lines."""
    try:
        text = path.read_text(encoding='utf-8')
        parser = Parser(text, str(path))
        return parser.parse()
    except FileNotFoundError:
        raise ParseError(f"File not found: {path}")
    except UnicodeDecodeError as e:
        raise ParseError(f"Cannot decode file: {e}", str(path))


def parse_string(text: str, file: str = "<string>") -> List[ParsedLine]:
    """Parse a string and return parsed lines."""
    parser = Parser(text, file)
    return parser.parse()
