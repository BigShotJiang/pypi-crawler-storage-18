"""
FastMCP SQLTools - A Model Context Protocol server for SQL operations.
"""

__version__ = "0.1.0"
