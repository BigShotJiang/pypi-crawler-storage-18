"""
Reminix SDK Core
"""

from .client import Client
from .config import ClientConfig
from .exceptions import (
    APIError,
    AuthenticationError,
    NetworkError,
    ReminixError,
)
from .operations.project import Project
from .utils.pagination import PaginatedResponse, collect_all, paginate_all
from .types import (
    Message,
    ToolCall,
    Context,
    Request,
    Response,
    MemoryStore,
    KnowledgeBase,
    ToolRegistry,
    AgentHandler,
    ToolHandler,
)

__all__ = [
    "Client",
    "ClientConfig",
    "ReminixError",
    "APIError",
    "AuthenticationError",
    "NetworkError",
    "Project",
    "PaginatedResponse",
    "paginate_all",
    "collect_all",
    # Handler types
    "Message",
    "ToolCall",
    "Context",
    "Request",
    "Response",
    "MemoryStore",
    "KnowledgeBase",
    "ToolRegistry",
    "AgentHandler",
    "ToolHandler",
]
