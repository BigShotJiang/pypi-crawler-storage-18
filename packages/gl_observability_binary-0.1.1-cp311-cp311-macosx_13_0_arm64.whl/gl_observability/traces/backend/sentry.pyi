from _typeshed import Incomplete
from opentelemetry.sdk.trace import TracerProvider
from typing import Any

class SentryBackendConfig:
    """Configuration object for Sentry initialization."""
    dsn: Incomplete
    environment: Incomplete
    release: Incomplete
    profiles_sample_rate: Incomplete
    send_default_pii: Incomplete
    disable_sentry_distributed_tracing: Incomplete
    additional_options: Incomplete
    def __init__(self, *, dsn: str | None = None, environment: str | None = None, release: str | None = None, profiles_sample_rate: float | None = None, send_default_pii: bool | None = None, disable_sentry_distributed_tracing: bool = False, **kwargs: Any) -> None:
        """Initializes the Sentry configuration object with the specified parameters.

        Args:
            dsn (str | None, optional): The Sentry Project DSN. Defaults to None.
            environment (str | None, optional): The environment for the Sentry project. Defaults to None.
            release (str | None, optional): The release version for the Sentry project. Defaults to None.
            profiles_sample_rate (float | None, optional): The sample rate for performance monitoring. Defaults to None.
            send_default_pii (bool | None, optional): Whether to send default Personally Identifiable Information (PII).
                Defaults to None.
            disable_sentry_distributed_tracing (bool, optional): Whether to disable distributed tracing for Sentry.
                Defaults to False.
            **kwargs: Additional keyword arguments to pass to sentry_sdk.init
        """

def init_sentry(config: SentryBackendConfig, tracer_provider: TracerProvider) -> None:
    """Initializes Sentry with OpenTelemetry for error tracking and performance monitoring.

    Initializes Sentry with the specified parameters.

    Args:
        config (SentryBackendConfig): The configuration object for Sentry initialization.
        tracer_provider (TracerProvider): The tracer provider to use.
    """
