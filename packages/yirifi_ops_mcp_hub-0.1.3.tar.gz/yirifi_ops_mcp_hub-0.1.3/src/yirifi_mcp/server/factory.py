"""Generic MCP server factory for any service catalog."""

from contextlib import asynccontextmanager
from typing import AsyncIterator

import httpx
import structlog
from fastmcp import FastMCP

from yirifi_mcp.catalog.base import ServiceCatalog
from yirifi_mcp.core.config import ServiceConfig
from yirifi_mcp.core.exceptions import (
    ActionNotFoundError,
    MissingPathParamError,
    UpstreamError,
)
from yirifi_mcp.core.environment_middleware import EnvironmentMiddleware
from yirifi_mcp.core.http_client import create_passthrough_client
from yirifi_mcp.core.openapi_utils import (
    fetch_openapi_spec,
    get_spec_info,
    patch_openapi_spec,
)
from yirifi_mcp.core.route_filters import filter_openapi_paths
from yirifi_mcp.core.tool_optimizer import optimize_component_descriptions
from yirifi_mcp.gateway.dynamic import DynamicGateway

logger = structlog.get_logger()


class MCPServerFactory:
    """Generic factory for creating MCP servers from any ServiceCatalog.

    This factory encapsulates the common logic for building MCP servers:
    - Fetching and filtering OpenAPI specs
    - Creating HTTP clients with authentication
    - Registering direct tools from OpenAPI
    - Adding gateway tools for dynamic API access
    - Managing resource lifecycle

    Example:
        >>> from yirifi_mcp.catalog.auth_service import AUTH_CATALOG
        >>> from yirifi_mcp.core.config import AuthServiceConfig
        >>>
        >>> factory = MCPServerFactory(AUTH_CATALOG, AuthServiceConfig())
        >>> async with factory.lifespan() as mcp:
        ...     mcp.run()

    Or using the build method:
        >>> factory = MCPServerFactory(AUTH_CATALOG, AuthServiceConfig())
        >>> mcp = await factory.build()
        >>> mcp.run()
    """

    def __init__(
        self,
        catalog: ServiceCatalog,
        config: ServiceConfig,
        *,
        gateway_prefix: str | None = None,
    ):
        """Initialize the factory with a catalog and config.

        Args:
            catalog: ServiceCatalog defining available endpoints
            config: ServiceConfig with connection and server settings
            gateway_prefix: Optional prefix for gateway tool names (default: derived from server_name)
        """
        self.catalog = catalog
        self.config = config
        self.gateway_prefix = gateway_prefix or self._derive_prefix(config.server_name)
        self._client: httpx.AsyncClient | None = None
        self._gateway: DynamicGateway | None = None

    @staticmethod
    def _derive_prefix(server_name: str) -> str:
        """Derive gateway prefix from server name.

        Examples:
            yirifi-auth -> auth
            my-cool-service -> my_cool_service
        """
        # Remove common prefixes
        name = server_name.lower()
        for prefix in ("yirifi-", "mcp-", "service-"):
            if name.startswith(prefix):
                name = name[len(prefix) :]
                break
        # Replace hyphens with underscores
        return name.replace("-", "_")

    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[FastMCP]:
        """Async context manager for resource lifecycle.

        Ensures HTTP client is properly closed when server exits.

        Yields:
            Configured FastMCP server instance
        """
        try:
            mcp = await self.build()
            yield mcp
        finally:
            if self._client:
                await self._client.aclose()
                self._client = None
                logger.debug("http_client_closed", server=self.config.server_name)

    async def build(self) -> FastMCP:
        """Build the MCP server instance.

        Returns:
            Configured FastMCP server with direct tools and gateway
        """
        logger.info(
            "building_mcp_server",
            server_name=self.config.server_name,
            base_url=self.config.base_url,
        )

        # Fetch and convert OpenAPI spec
        # Some services require auth even for swagger endpoint
        static_api_key = getattr(self.config, "api_key", None) or ""
        spec = await fetch_openapi_spec(
            base_url=self.config.base_url,
            openapi_path=self.config.openapi_path,
            api_key=static_api_key,
        )
        spec = patch_openapi_spec(spec, self.config.base_url)

        # Generate route maps from catalog and filter spec
        route_maps = self.catalog.to_route_maps()
        filtered_spec = filter_openapi_paths(spec, route_maps)
        spec_info = get_spec_info(filtered_spec)

        logger.info(
            "spec_filtered",
            server=self.config.server_name,
            endpoints=spec_info["endpoints_count"],
            direct_tools=self.catalog.direct_count,
            gateway_actions=self.catalog.gateway_count,
        )

        # Get base URL from spec (may include /api/v1 prefix)
        api_base_url = filtered_spec.get("servers", [{}])[0].get(
            "url", self.config.base_url
        )

        # Create HTTP client with passthrough authentication
        # The client uses PassthroughAuth to inject X-API-Key from context variable
        # For STDIO transport, static_api_key is used as fallback
        static_api_key = getattr(self.config, "api_key", None) or ""
        self._client = create_passthrough_client(
            base_url=api_base_url,
            timeout=self.config.request_timeout,
            connect_timeout=self.config.connect_timeout,
            static_api_key=static_api_key,
        )

        # Create MCP server from filtered OpenAPI spec
        mcp = FastMCP.from_openapi(
            openapi_spec=filtered_spec,
            client=self._client,
            name=self.config.server_name,
            mcp_component_fn=optimize_component_descriptions,
        )

        # Add environment middleware to wrap all tool responses
        # This ensures AI agents always know which database (DEV/UAT/PRD) they're operating against
        mcp.add_middleware(EnvironmentMiddleware(self.config))

        # Add gateway tools for dynamic API access
        # Pass config for environment context in responses
        self._gateway = DynamicGateway(self._client, self.catalog, config=self.config)
        self._register_gateway_tools(mcp)

        # Log final stats
        stats = self.catalog.get_stats()
        logger.info(
            "mcp_server_built",
            server_name=self.config.server_name,
            direct_tools=stats["direct"],
            gateway_actions=stats["gateway"],
            high_risk_actions=stats["high_risk"],
        )

        return mcp

    def _register_gateway_tools(self, mcp: FastMCP) -> None:
        """Register gateway tools on the MCP server.

        Creates two tools:
        - {prefix}_api_catalog: Lists available actions
        - {prefix}_api_call: Executes any action dynamically

        Args:
            mcp: FastMCP server instance
        """
        gateway = self._gateway
        prefix = self.gateway_prefix

        # Create catalog tool
        @mcp.tool(name=f"{prefix}_api_catalog")
        async def api_catalog() -> dict:
            f"""List all available {prefix} API actions.
            Use with {prefix}_api_call to execute any action.
            """
            return await gateway.catalog()

        # Create call tool
        @mcp.tool(name=f"{prefix}_api_call")
        async def api_call(
            action: str,
            path_params: dict | None = None,
            query_params: dict | None = None,
            body: dict | None = None,
        ) -> dict:
            f"""Execute any {prefix} API action dynamically.

            Args:
                action: Action name from {prefix}_api_catalog (e.g., "get_user_list", "delete_role_detail")
                path_params: URL path parameters (e.g., {{"user_id": 1}})
                query_params: Query string parameters
                body: Request body for POST/PUT/PATCH

            Returns:
                API response as dict
            """
            try:
                return await gateway.call(action, path_params, query_params, body)
            except ActionNotFoundError as e:
                return {
                    "error": str(e),
                    "available_actions": e.available[:20],
                }
            except MissingPathParamError as e:
                return {
                    "error": str(e),
                    "required_params": e.params,
                    "path": e.path,
                }
            except UpstreamError as e:
                return {
                    "error": f"HTTP {e.status_code}",
                    "detail": e.detail,
                }
            except Exception as e:
                logger.exception("gateway_error", action=action, server=self.config.server_name)
                return {"error": str(e)}
