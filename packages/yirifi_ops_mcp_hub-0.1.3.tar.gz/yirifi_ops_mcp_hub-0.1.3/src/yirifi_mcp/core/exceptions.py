"""Custom exception hierarchy for MCP Hub."""


class MCPHubError(Exception):
    """Base exception for all MCP Hub errors."""

    pass


class ConfigurationError(MCPHubError):
    """Configuration/environment errors."""

    pass


class OpenAPIError(MCPHubError):
    """OpenAPI spec fetch/parse errors."""

    pass


class CatalogError(MCPHubError):
    """Catalog definition errors."""

    pass


class GatewayError(MCPHubError):
    """Gateway execution errors."""

    pass


class ActionNotFoundError(GatewayError):
    """Unknown action requested."""

    def __init__(self, action: str, available: list[str]):
        self.action = action
        self.available = available
        super().__init__(f"Unknown action: {action}")


class MissingPathParamError(GatewayError):
    """Required path parameter not provided."""

    def __init__(self, params: list[str], path: str):
        self.params = params
        self.path = path
        super().__init__(f"Missing path parameters {params} for {path}")


class UpstreamError(GatewayError):
    """Error from upstream service."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail[:200]}")
