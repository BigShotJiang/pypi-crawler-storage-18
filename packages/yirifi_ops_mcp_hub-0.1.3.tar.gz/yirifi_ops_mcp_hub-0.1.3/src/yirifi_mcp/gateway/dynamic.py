"""Dynamic gateway for executing catalog actions."""

import re
from typing import TYPE_CHECKING

import httpx
import structlog

from yirifi_mcp.catalog.base import ServiceCatalog
from yirifi_mcp.core.exceptions import (
    ActionNotFoundError,
    GatewayError,
    MissingPathParamError,
    UpstreamError,
)
from yirifi_mcp.core.response_wrapper import is_mutation_method, wrap_response

from .base import BaseGateway

if TYPE_CHECKING:
    from yirifi_mcp.core.config import ServiceConfig

logger = structlog.get_logger()


class DynamicGateway(BaseGateway):
    """Gateway that executes actions from a service catalog.

    This gateway provides dynamic access to API endpoints defined
    in a ServiceCatalog. It handles path parameter substitution,
    HTTP method selection, and error handling.

    Example:
        >>> from yirifi_mcp.catalog.auth_service import AUTH_CATALOG
        >>> gateway = DynamicGateway(http_client, AUTH_CATALOG)
        >>> await gateway.call("delete_user_detail", path_params={"user_id": 123})
    """

    def __init__(
        self,
        client: httpx.AsyncClient,
        catalog: ServiceCatalog,
        config: "ServiceConfig | None" = None,
    ):
        """Initialize gateway with HTTP client and service catalog.

        Args:
            client: Configured httpx.AsyncClient for API requests
            catalog: ServiceCatalog defining available endpoints
            config: Optional service config for environment context in responses
        """
        super().__init__(client)
        self._catalog = catalog
        self._config = config
        # Use catalog's built-in method for gateway catalog
        self._api_catalog = catalog.to_gateway_catalog()

    async def catalog(self) -> dict:
        """Return available actions as {name: description} with environment context.

        Returns:
            Dict with environment metadata and action mappings
        """
        actions = {name: info["desc"] for name, info in self._api_catalog.items()}

        # Wrap with environment context if config available
        if self._config:
            return wrap_response(actions, self._config, is_mutation=False)
        return actions

    async def call(
        self,
        action: str,
        path_params: dict | None = None,
        query_params: dict | None = None,
        body: dict | None = None,
    ) -> dict:
        """Execute an action from the catalog.

        Args:
            action: Action name from catalog()
            path_params: URL path parameters (e.g., {"user_id": 123})
            query_params: Query string parameters
            body: Request body for POST/PUT/PATCH

        Returns:
            API response as dict

        Raises:
            ActionNotFoundError: Unknown action name
            MissingPathParamError: Required path param not provided
            UpstreamError: HTTP error from upstream service
            GatewayError: Other gateway errors
        """
        # Validate action exists
        if action not in self._api_catalog:
            logger.warning("action_not_found", action=action)
            raise ActionNotFoundError(action, list(self._api_catalog.keys()))

        endpoint = self._api_catalog[action]
        method = endpoint["method"]
        path = endpoint["path"]

        # Substitute path parameters
        if path_params:
            for key, value in path_params.items():
                path = path.replace(f"{{{key}}}", str(value))

        # Check for unsubstituted path params
        missing = re.findall(r"\{(\w+)\}", path)
        if missing:
            logger.warning(
                "missing_path_params",
                action=action,
                missing=missing,
                path=endpoint["path"],
            )
            raise MissingPathParamError(missing, endpoint["path"])

        # Execute request
        logger.debug(
            "gateway_call",
            action=action,
            method=method,
            path=path,
            has_body=body is not None,
        )

        try:
            response = await self.client.request(
                method=method,
                url=path,
                params=query_params,
                json=body if method in ("POST", "PUT", "PATCH") else None,
            )
            response.raise_for_status()

            # Handle empty responses
            if response.status_code == 204 or not response.content:
                result = {"success": True, "status_code": response.status_code}
            else:
                result = response.json()

            # Wrap with environment context if config available
            if self._config:
                return wrap_response(
                    result,
                    self._config,
                    is_mutation=is_mutation_method(method),
                )
            return result

        except httpx.HTTPStatusError as e:
            logger.error(
                "upstream_error",
                action=action,
                status_code=e.response.status_code,
                detail=e.response.text[:200],
            )
            raise UpstreamError(e.response.status_code, e.response.text[:500])

        except httpx.RequestError as e:
            logger.error("request_error", action=action, error=str(e))
            raise GatewayError(f"Request failed: {e}")

    def get_action_info(self, action: str) -> dict | None:
        """Get detailed info about an action.

        Args:
            action: Action name

        Returns:
            Dict with method, path, desc, risk_level or None if not found
        """
        return self._api_catalog.get(action)

    def get_high_risk_actions(self) -> list[str]:
        """Get list of high-risk action names.

        Returns:
            List of action names with risk_level="high"
        """
        return [
            name
            for name, info in self._api_catalog.items()
            if info.get("risk_level") == "high"
        ]
