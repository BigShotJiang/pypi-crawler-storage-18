# Secure Run (sr)

Encrypt Python files and run them securely using OpenSSL.

## Install
```bash
pip install secure-run