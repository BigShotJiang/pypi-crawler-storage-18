"""
DAP4MKB CLI - Точка входа командной строки
Запуск: dap4mkb start | init | config
"""

import os
import sys
import click
from pathlib import Path

# Директория конфигурации: ~/.dap
DAP_HOME = Path.home() / ".dap"


@click.group()
@click.version_option(version="0.1.1", prog_name="dap4mkb")
def main():
    """DataAudit Platform - аудит и аналитика данных для МКБ"""
    pass


@main.command()
@click.option("--force", is_flag=True, help="Перезаписать существующую конфигурацию")
def init(force: bool):
    """Инициализация DAP: создание ~/.dap, базы данных, конфигурации"""
    import subprocess
    
    click.echo("Инициализация DAP Platform...")
    
    # Создаём директорию
    if DAP_HOME.exists() and not force:
        click.echo(f"Директория {DAP_HOME} уже существует. Используйте --force для перезаписи.")
        return
    
    DAP_HOME.mkdir(exist_ok=True)
    click.echo(f"OK Создана директория: {DAP_HOME}")
    
    # Создаём конфиг DAP UI
    config_file = DAP_HOME / "config.env"
    if not config_file.exists() or force:
        config_content = """# DAP Platform Configuration
# Режим разработки (без LDAP)
DAP_DEV_MODE=true

# Сервер (хост и порты)
DAP_HOST=127.0.0.1
DAP_UI_PORT=8000
DAP_BI_PORT=8088

# База данных (SQLite по умолчанию)
DAP_DATABASE_URL=sqlite:///${DAP_HOME}/dap.db

# LDAP (для production)
# LDAP_SERVER=ldaps://ad.mcb.ru:636
# LDAP_BASE_DN=DC=mcb,DC=ru
# LDAP_BIND_USER=
# LDAP_BIND_PASSWORD=

# SMTP (для уведомлений)
# SMTP_SERVER=mail.mcb.ru
# SMTP_PORT=587
# SMTP_USER=
# SMTP_PASSWORD=
"""
        config_file.write_text(config_content, encoding="utf-8")
        click.echo(f"OK Создан конфиг: {config_file}")
    
    # Создаём директорию и конфиг Superset
    superset_dir = DAP_HOME / "superset"
    superset_dir.mkdir(exist_ok=True)
    superset_config = superset_dir / "superset_config.py"
    
    if not superset_config.exists() or force:
        superset_config_content = '''import sys

# Oracle compatibility: make oracledb work as cx_Oracle
try:
    import oracledb
    oracledb.version = "8.3.0"
    sys.modules["cx_Oracle"] = oracledb
except ImportError:
    pass

import os
from pathlib import Path
from flask_appbuilder.security.manager import AUTH_DB

DAP_HOME = Path.home() / ".dap"
SUPERSET_HOME = DAP_HOME / "superset"

SQLALCHEMY_DATABASE_URI = f"sqlite:///{SUPERSET_HOME}/superset.db"
SECRET_KEY = "dap-bi-local-dev-key"

AUTH_TYPE = AUTH_DB
SECURITY_PASSWORD_HASH = "pbkdf2:sha256"

WTF_CSRF_ENABLED = False

RESULTS_BACKEND = None
CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}
DATA_CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}
FILTER_STATE_CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}
EXPLORE_FORM_DATA_CACHE_CONFIG = {"CACHE_TYPE": "SimpleCache"}

BABEL_DEFAULT_LOCALE = "ru"

APP_NAME = "DAP Analytics"
APP_ICON = "/static/assets/images/dap_logo.png"
FAVICONS = [{"href": "/static/assets/images/dap_favicon.png"}]
LOGO_TOOLTIP = "DAP Analytics"

from superset.utils.log import AbstractEventLogger
class NoOpEventLogger(AbstractEventLogger):
    def log(self, *args, **kwargs):
        pass
EVENT_LOGGER = NoOpEventLogger()
'''
        superset_config.write_text(superset_config_content, encoding="utf-8")
        click.echo(f"OK Создан конфиг Superset: {superset_config}")
    
    # Настраиваем окружение для Superset
    bi_env = os.environ.copy()
    bi_env["FLASK_APP"] = "superset"
    bi_env["SUPERSET_CONFIG_PATH"] = str(superset_config)
    
    # Проверяем, установлен ли dap-bi
    try:
        import superset
        click.echo("OK DAP BI (Superset) найден")
    except ImportError:
        click.echo("DAP BI не установлен. Установите: pip install dap-bi")
        click.echo("")
        click.echo("DAP UI готов к запуску!")
        click.echo("   Запустите: python -m dap4mkb.cli start --no-bi")
        return
    
    # Копируем готовую базу данных из шаблона
    superset_db = superset_dir / "superset.db"
    if not superset_db.exists() or force:
        click.echo("Копирование базы данных Superset...")
        
        # Ищем шаблон в пакете
        import importlib.resources
        try:
            # Python 3.9+
            template_path = importlib.resources.files("dap4mkb") / "data" / "superset_template.db"
            if hasattr(template_path, 'read_bytes'):
                superset_db.write_bytes(template_path.read_bytes())
                click.echo("OK База данных Superset создана из шаблона")
            else:
                # Fallback for older Python
                import shutil
                with importlib.resources.as_file(template_path) as src:
                    shutil.copy(src, superset_db)
                click.echo("OK База данных Superset создана из шаблона")
        except Exception as e:
            click.echo(f"Ошибка копирования шаблона: {e}")
            click.echo("Создание базы данных программно...")
            # Fallback: create database programmatically
            os.environ['SUPERSET_CONFIG_PATH'] = str(superset_config)
            from superset.app import create_app
            from superset.extensions import db
            from flask_appbuilder.security.sqla.models import User, Role
            from werkzeug.security import generate_password_hash
            
            app = create_app()
            with app.app_context():
                db.create_all()
                admin_role = db.session.query(Role).filter_by(name='Admin').first()
                if not admin_role:
                    admin_role = Role(name='Admin')
                    db.session.add(admin_role)
                    db.session.commit()
                user = db.session.query(User).filter_by(username='admin').first()
                if not user:
                    user = User()
                    user.username = 'admin'
                    user.email = 'admin@dap.local'
                    user.first_name = 'Admin'
                    user.last_name = 'User'
                    user.password = generate_password_hash('admin123')
                    user.active = True
                    user.roles = [admin_role]
                    db.session.add(user)
                    db.session.commit()
            click.echo("OK База данных Superset создана программно")
    else:
        click.echo(f"OK База данных Superset уже существует: {superset_db}")
    
    click.echo("")
    click.echo("DAP Platform готов к запуску!")
    click.echo("   Запустите: python -m dap4mkb.cli start")


@main.command()
@click.option("--host", default="127.0.0.1", help="Хост для запуска")
@click.option("--port", default=8000, help="Порт DAP UI")
@click.option("--bi-port", default=8088, help="Порт DAP BI")
@click.option("--no-bi", is_flag=True, help="Запустить только UI без BI")
@click.option("--reload", is_flag=True, help="Авто-перезагрузка при изменениях (dev)")
def start(host: str, port: int, bi_port: int, no_bi: bool, reload: bool):
    """Запуск DAP Platform (UI + BI)"""
    import subprocess
    import time
    
    # Загружаем конфиг
    config_file = DAP_HOME / "config.env"
    if config_file.exists():
        from dotenv import load_dotenv
        load_dotenv(config_file)
    
    # Устанавливаем переменные
    os.environ.setdefault("DAP_DEV_MODE", "true")
    os.environ.setdefault("DAP_HOME", str(DAP_HOME))
    
    # Superset config
    superset_config = DAP_HOME / "superset" / "superset_config.py"
    if superset_config.exists():
        os.environ["SUPERSET_CONFIG_PATH"] = str(superset_config)
    os.environ["FLASK_APP"] = "superset"
    
    click.echo("=" * 50)
    click.echo("  DAP Platform")
    click.echo("=" * 50)
    click.echo(f"  UI:  http://{host}:{port}")
    if not no_bi:
        click.echo(f"  BI:  http://{host}:{bi_port}")
    click.echo("=" * 50)
    click.echo("")
    click.echo("  Login: admin / admin123")
    click.echo("  Ctrl+C to stop")
    click.echo("")
    
    processes = []
    
    try:
        # Запускаем DAP BI (Superset)
        if not no_bi:
            bi_env = os.environ.copy()
            bi_env["FLASK_APP"] = "superset"
            if superset_config.exists():
                bi_env["SUPERSET_CONFIG_PATH"] = str(superset_config)
            
            bi_cmd = f'"{sys.executable}" -m flask run -h {host} -p {bi_port}'
            bi_process = subprocess.Popen(bi_cmd, env=bi_env, shell=True)
            processes.append(bi_process)
            click.echo(f"[BI] Started on port {bi_port}")
            time.sleep(3)
        
        # Запускаем DAP UI (FastAPI)
        import uvicorn
        click.echo(f"[UI] Starting on port {port}...")
        uvicorn.run(
            "dap4mkb.server:app",
            host=host,
            port=port,
            reload=reload,
        )
        
    except KeyboardInterrupt:
        click.echo("\n\nStopping services...")
    finally:
        for proc in processes:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
        click.echo("All services stopped.")


@main.group()
def config():
    """Управление конфигурацией"""
    pass


@config.command("show")
def config_show():
    """Показать текущую конфигурацию"""
    config_file = DAP_HOME / "config.env"
    
    if not config_file.exists():
        click.echo("Config not found. Run: python -m dap4mkb.cli init")
        return
    
    click.echo(f"File: {config_file}")
    click.echo("-" * 40)
    click.echo(config_file.read_text(encoding="utf-8"))


@config.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key: str, value: str):
    """Установить параметр конфигурации"""
    config_file = DAP_HOME / "config.env"
    
    if not config_file.exists():
        click.echo("Config not found. Run: python -m dap4mkb.cli init")
        return
    
    lines = config_file.read_text(encoding="utf-8").splitlines()
    key_upper = key.upper()
    found = False
    
    for i, line in enumerate(lines):
        if line.startswith(f"{key_upper}=") or line.startswith(f"# {key_upper}="):
            lines[i] = f"{key_upper}={value}"
            found = True
            break
    
    if not found:
        lines.append(f"{key_upper}={value}")
    
    config_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    click.echo(f"OK {key_upper}={value}")


if __name__ == "__main__":
    main()