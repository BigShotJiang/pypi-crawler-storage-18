
__version__ = "0.7.3"
__banner__ = \
"""
# badldap %s 
# Original Author: Tamas Jos (@skelsec)
# Current Maintainer: Baptiste Crépin (baptiste@cravaterouge.com)
""" % __version__
