# Changelog

All notable changes to this project will be documented in this file.

## 0.1.0a2 - 2025-02-20

### Changed
- Relaxed runtime dependency pins to prevent adopter dependency downgrades.
- Added clearer vibegate.yaml schema validation remediation guidance.

## 0.1.0a3 - 2025-02-25

### Added
- Config profiles with deterministic merge order.
- Plugin SDK with entry-point discovery for checks and emitters.

## 0.1.0a1 - 2025-02-18

### Added
- Initial alpha release of VibeGate with deterministic gating CLI, evidence ledger, and fix pack output.
