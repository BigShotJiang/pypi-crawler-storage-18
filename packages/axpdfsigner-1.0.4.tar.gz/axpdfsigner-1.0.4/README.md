# AxPdfSigner

**Professional PDF Digital Signature SDK for Python**

[![License](https://img.shields.io/badge/license-Commercial-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.7+-blue.svg)](https://www.python.org/downloads/)
[![Platform](https://img.shields.io/badge/platform-Windows-lightgrey.svg)](https://www.microsoft.com/windows)

**Product by [Axonate Tech](https://axonatetech.com/)**

---

## Overview

AxPdfSigner is an enterprise-grade Python SDK for digitally signing PDF documents with X.509 certificates. Built with pure Python implementation, it provides a clean, intuitive interface for advanced PDF signing operations.

## Features

✅ **Digital Signatures** - Sign PDFs with X.509 certificates (PFX/P12)  
✅ **Long-Term Validation (LTV)** - Embed validation information for long-term verification  
✅ **RFC 3161 Timestamping** - Add trusted timestamps to signatures  
✅ **Custom Appearance** - Fully customizable signature appearance  
✅ **Multi-Page Signing** - Sign single or multiple pages  
✅ **Invisible Signatures** - Support for invisible digital signatures  
✅ **PDF Metadata** - Control document title, author, subject, keywords  
✅ **Certificate Locking** - Lock PDF after signing to prevent modifications  
✅ **Batch Processing** - Sign multiple documents efficiently  
✅ **Pure Python** - No external dependencies except pythonnet

## Installation

```bash
pip install AxPdfSigner-1.0.0-py3-none-any.whl
```

### Requirements

- Python 3.7 or higher
- Windows operating system
- pythonnet package (installed automatically)

## Quick Start

### Basic Usage

```python
from AxPdfSigner import PdfSigner, SignatureConfig

# Create signer instance
signer = PdfSigner()

# Configure signature
config = SignatureConfig(
    input_pdf="document.pdf",
    output_pdf="signed_document.pdf",
    pfx_path="certificate.pfx",
    pfx_password="your_password"
)

# Sign the document
signer.sign(config)
```

### Advanced Usage

```python
from AxPdfSigner import PdfSigner, SignatureConfig

# Advanced configuration
config = SignatureConfig(
    input_pdf="contract.pdf",
    output_pdf="signed_contract.pdf",
    pfx_path="company_cert.pfx",
    pfx_password="secure_password",
    
    # Signature details
    reason="Contract Approval",
    location="New York, USA",
    custom_text="Approved by Legal Department",
    signer_name="John Doe",
    
    # Position and appearance
    coordinates="100,100,300,150",  # x1,y1,x2,y2
    pages="1,3,5",  # Sign specific pages
    
    # Security features
    enable_ltv=True,
    enable_timestamp=True,
    lock_pdf=True,
    
    # PDF metadata
    title="Employment Contract",
    author="HR Department",
    subject="Contract Signing",
    keywords="contract,employment,legal"
)

signer = PdfSigner()
signer.sign(config)
```

### Batch Signing

```python
from AxPdfSigner import PdfSigner, SignatureConfig

configs = []
for i in range(1, 11):
    config = SignatureConfig(
        input_pdf=f"document_{i}.pdf",
        output_pdf=f"signed_{i}.pdf",
        pfx_path="certificate.pfx",
        pfx_password="password"
    )
    configs.append(config)

signer = PdfSigner()
results = signer.sign_batch(configs)

print(f"Success: {len(results['success'])}")
print(f"Failed: {len(results['failed'])}")
```

## Configuration Parameters

### Required Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `input_pdf` | str | Path to input PDF file |
| `output_pdf` | str | Path to output signed PDF |
| `pfx_path` | str | Path to PFX/P12 certificate |
| `pfx_password` | str | Certificate password |

### Optional Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pages` | str | "1" | Pages to sign: "1", "1,3,5", "1-5", "all" |
| `field_name` | str | "Signature1" | Signature field name |
| `reason` | str | "Document Signing" | Reason for signing |
| `location` | str | "" | Location of signing |
| `custom_text` | str | "" | Custom text in signature |
| `signer_name` | str | "" | Override signer name (from cert CN) |
| `coordinates` | str | "100,100,300,150" | Position: "x1,y1,x2,y2" |
| `enable_ltv` | bool | True | Enable Long-Term Validation |
| `enable_timestamp` | bool | True | Enable RFC 3161 timestamp |
| `disable_green_tick` | bool | False | Disable green tick in Adobe |
| `lock_pdf` | bool | True | Lock PDF after signing |
| `include_subject` | bool | False | Include certificate subject DN |
| `invisible_signature` | bool | False | Make signature invisible |
| `fast_method` | bool | True | Use fast signing method |
| `title` | str | "" | PDF document title |
| `author` | str | "" | PDF document author |
| `subject` | str | "" | PDF document subject |
| `keywords` | str | "" | PDF document keywords |

## Error Handling

```python
from AxPdfSigner import PdfSigner, SignatureConfig, SignatureException

try:
    signer = PdfSigner()
    config = SignatureConfig(...)
    signer.sign(config)
    print("✓ Document signed successfully")
    
except SignatureException as e:
    print(f"✗ Signature error: {e}")
    
except Exception as e:
    print(f"✗ Unexpected error: {e}")
```

## API Reference

### PdfSigner Class

#### Methods

- `sign(config: SignatureConfig) -> bool`  
  Sign a single PDF document

- `sign_batch(configs: List[SignatureConfig]) -> dict`  
  Sign multiple PDF documents in batch

- `get_version() -> str` (static)  
  Get SDK version

- `validate_certificate(pfx_path: str, pfx_password: str) -> dict` (static)  
  Validate a PFX certificate

### SignatureConfig Class

Dataclass containing all signature configuration parameters.

### SignatureException Class

Exception raised for signature-related errors.

## System Requirements

- **OS**: Windows 7/8/10/11, Windows Server 2012+
- **Python**: 3.7, 3.8, 3.9, 3.10, 3.11, 3.12
- **RAM**: 512 MB minimum
- **Disk**: 50 MB for installation

## License

This is commercial software. See LICENSE file for details.

## Support

For technical support, bug reports, or feature requests:

- **Website**: [https://axonatetech.com/](https://axonatetech.com/)
- **Email**: support@axonatetech.com
- **Documentation**: [https://axonatetech.com/docs](https://axonatetech.com/docs)

## About

**Product by Axonate Tech**  
Website: [https://axonatetech.com/](https://axonatetech.com/)

AxPdfSigner is a professional PDF digital signature solution designed for enterprise applications. Built with pure Python implementation, it provides reliable and secure PDF signing capabilities.

---

**© 2025 Axonate Tech. All rights reserved.**
