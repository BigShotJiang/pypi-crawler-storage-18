"""
Path utility functions.

Contains helpers for path expansion and resolution.
"""
from __future__ import annotations
from pathlib import Path
import os


def expand_path(path_str: str) -> Path:
    """
    Expand environment variables and ~ in a path string.

    Supports:
    - Environment variables: $VAR, ${VAR}
    - Home directory: ~, ~/path

    Args:
        path_str: Path string that may contain variables

    Returns:
        Path object with variables expanded
    """
    expanded = os.path.expandvars(path_str)  # $VAR, ${VAR}
    expanded = os.path.expanduser(expanded)   # ~
    return Path(expanded)
