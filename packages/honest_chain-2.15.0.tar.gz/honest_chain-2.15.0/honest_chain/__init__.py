"""
HONEST CHAIN SDK v2.0 - Quantum-Ready
=====================================

Make AI Honest to God.

The logical foundation for AI transparency: inner == outer.
Bitcoin-anchored, formally verified, quantum-safe.

Features:
    - Quantum-safe cryptographic identity (SHA3-256)
    - DID-style agent identifiers (did:hc:...)
    - Digital signatures on all decisions
    - Bitcoin anchoring for permanence

Usage:
    from honest_chain import HonestChain, RiskLevel

    hc = HonestChain(agent_id="my-agent")

    # Get agent DID
    print(hc.did)  # did:hc:abc123...

    # Log decisions (automatically signed)
    hc.decide(
        action="Approved request",
        reasoning="All criteria met",
        risk_level=RiskLevel.LOW
    )
    assert hc.verify()

Copyright (c) 2025 Stellanium Ltd. All rights reserved.
Licensed under MIT License. See LICENSE file.
AOAI™ and HONEST CHAIN™ are trademarks of Stellanium Ltd.
"""

__version__ = "2.15.0"
__author__ = "Stellanium Ltd"
__email__ = "admin@stellanium.io"
__license__ = "MIT"

# Minimum secure version - versions below this are deprecated
_MIN_SECURE_VERSION = "2.14.0"

# Security: Max response size for PyPI check (10KB)
_MAX_PYPI_RESPONSE = 10 * 1024


def _check_version():
    """
    Check for updates and warn about outdated versions.

    Security hardening (v2.15.0):
    - Opt-in via HONEST_CHAIN_CHECK_UPDATES=1 (disabled by default)
    - Response size limited to 10KB
    - SSL certificate validation enforced
    - Strict JSON parsing with size limits
    - Errors logged to ~/.honest_chain/.version_check.log
    """
    import warnings
    import os
    from packaging.version import Version

    current = Version(__version__)
    min_secure = Version(_MIN_SECURE_VERSION)

    # Block outdated versions (always runs)
    if current < min_secure:
        warnings.warn(
            f"SECURITY WARNING: honest-chain {__version__} is outdated and insecure. "
            f"Upgrade immediately: pip install --upgrade honest-chain",
            DeprecationWarning,
            stacklevel=3
        )
        return

    # PyPI check is OPT-IN only (security: no network by default)
    if os.environ.get("HONEST_CHAIN_CHECK_UPDATES", "").strip() != "1":
        return

    try:
        import urllib.request
        import ssl
        import json
        from pathlib import Path
        import time

        # Cache check - only check once per day
        cache_dir = Path.home() / ".honest_chain"
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_file = cache_dir / ".version_cache"
        log_file = cache_dir / ".version_check.log"

        if cache_file.exists():
            cache_age = time.time() - cache_file.stat().st_mtime
            if cache_age < 86400:  # 24 hours (was 1 hour)
                cached = cache_file.read_text().strip()
                if cached and Version(cached) > current:
                    warnings.warn(
                        f"honest-chain {cached} available (you have {__version__}). "
                        f"Upgrade: pip install --upgrade honest-chain",
                        UserWarning,
                        stacklevel=3
                    )
                return

        # Security: Create SSL context with certificate verification
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = True
        ssl_context.verify_mode = ssl.CERT_REQUIRED

        # Fetch latest version from PyPI
        req = urllib.request.Request(
            "https://pypi.org/pypi/honest-chain/json",
            headers={
                "Accept": "application/json",
                "User-Agent": f"honest-chain/{__version__}"
            }
        )

        with urllib.request.urlopen(req, timeout=2, context=ssl_context) as resp:
            # Security: Limit response size to prevent DoS
            content_length = resp.headers.get("Content-Length")
            if content_length and int(content_length) > _MAX_PYPI_RESPONSE:
                raise ValueError(f"Response too large: {content_length} bytes")

            # Read with size limit
            raw_data = resp.read(_MAX_PYPI_RESPONSE + 1)
            if len(raw_data) > _MAX_PYPI_RESPONSE:
                raise ValueError(f"Response exceeded {_MAX_PYPI_RESPONSE} bytes")

            data = json.loads(raw_data.decode("utf-8"))

            # Security: Validate response structure
            if not isinstance(data, dict) or "info" not in data:
                raise ValueError("Invalid PyPI response structure")

            latest = data["info"].get("version", "")
            if not latest or not isinstance(latest, str) or len(latest) > 20:
                raise ValueError("Invalid version string in response")

            # Validate version format
            Version(latest)  # Raises if invalid

            cache_file.write_text(latest)

            if Version(latest) > current:
                warnings.warn(
                    f"honest-chain {latest} available (you have {__version__}). "
                    f"Upgrade: pip install --upgrade honest-chain",
                    UserWarning,
                    stacklevel=3
                )

    except Exception as e:
        # Security: Log errors instead of silently swallowing
        try:
            from datetime import datetime
            with open(log_file, "a") as f:
                f.write(f"{datetime.now().isoformat()} - Version check failed: {type(e).__name__}: {e}\n")
        except Exception:
            pass  # Can't even log - truly give up


# Run version check on import (opt-in only)
_check_version()

# Core
from honest_chain.core import (
    HonestChain,
    DecisionRecord,
    Actor,
    ActorType,
    RiskLevel,
    log_decision,
)

# Quantum-ready identity
from honest_chain.identity import (
    AgentIdentity,
    Signature,
    HashCommitment,
    KeyMaterial,
    SignatureAlgorithm,
)

# Bitcoin anchoring
from honest_chain.bitcoin import (
    BitcoinAnchorService,
    BitcoinAnchor,
    AnchorMethod,
    AOAIGroundTruth,
    create_bitcoin_anchor_callback,
)

# P2P network
from honest_chain.p2p import (
    AOAINode,
    MessageType,
    Message,
    Peer,
    create_anchor_callback,
)

__all__ = [
    # Core
    "HonestChain",
    "DecisionRecord",
    "Actor",
    "ActorType",
    "RiskLevel",
    "log_decision",
    # Identity (NEW)
    "AgentIdentity",
    "Signature",
    "HashCommitment",
    "KeyMaterial",
    "SignatureAlgorithm",
    # Bitcoin
    "BitcoinAnchorService",
    "BitcoinAnchor",
    "AnchorMethod",
    "AOAIGroundTruth",
    "create_bitcoin_anchor_callback",
    # P2P
    "AOAINode",
    "MessageType",
    "Message",
    "Peer",
    "create_anchor_callback",
    # Meta
    "__version__",
]
