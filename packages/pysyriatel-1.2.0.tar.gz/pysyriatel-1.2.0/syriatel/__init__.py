"""
Syriatel Cash API Python Library

A professional Python library for interacting with the Syriatel Cash API.
Supports both async and sync operations.
"""

from .client import SyriatelCashClient, SyriatelCashClientSync
from .models import Transaction
from .exceptions import (
    SyriatelCashError,
    InvalidTokenError,
    SubscriptionExpiredError,
    FetchFailedError,
    NotAuthorizedError,
    ServerMaintenanceError,
    NetworkError,
    GSMNotFoundError,
    VerificationRequiredError,
    VerificationFailedError,
    PINInvalidError,
    LoginFailedError,
)

__version__ = "1.2.0"
__all__ = [
    "SyriatelCashClient",
    "SyriatelCashClientSync",
    "Transaction",
    "SyriatelCashError",
    "InvalidTokenError",
    "SubscriptionExpiredError",
    "FetchFailedError",
    "NotAuthorizedError",
    "ServerMaintenanceError",
    "NetworkError",
    "GSMNotFoundError",
    "VerificationRequiredError",
    "VerificationFailedError",
    "PINInvalidError",
    "LoginFailedError",
]
