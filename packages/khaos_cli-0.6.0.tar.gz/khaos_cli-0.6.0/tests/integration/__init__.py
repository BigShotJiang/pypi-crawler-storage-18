"""Integration tests using testcontainers."""
