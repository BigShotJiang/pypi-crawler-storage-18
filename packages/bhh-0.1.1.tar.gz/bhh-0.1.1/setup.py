from setuptools import setup, find_packages

setup(
    name="bhh",
    version="0.1.1",
    packages=find_packages(),
    description="BHH - A Hash Library for You",
    author="Aria",
    author_email="aria.karami94713@gmail.com",
)
