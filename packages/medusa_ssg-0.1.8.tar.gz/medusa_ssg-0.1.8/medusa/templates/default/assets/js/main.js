console.log('Medusa ready');
