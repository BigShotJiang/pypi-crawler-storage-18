"""
IncludeCPP Project Interface with CodeMaker
Professional visual system design and planning tool

Features:
- Modern dark frameless window with custom controls
- Interactive node-based mindmap canvas
- Pan/zoom navigation with smooth animations
- Connectable nodes with bezier curves
- Full context menu system
- File management for .ma maps
- Auto-save functionality
"""

import sys
import json
import math
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Tuple, Any, Set
from dataclasses import dataclass, field, asdict
from datetime import datetime

try:
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QFrame, QSplitter, QTreeWidget, QTreeWidgetItem,
        QGraphicsView, QGraphicsScene, QGraphicsItem, QGraphicsRectItem,
        QGraphicsTextItem, QGraphicsLineItem, QGraphicsEllipseItem,
        QMenu, QInputDialog, QMessageBox, QGraphicsDropShadowEffect,
        QScrollArea, QSizePolicy, QGraphicsPathItem, QToolBar, QStatusBar,
        QGraphicsProxyWidget, QLineEdit, QTextEdit, QDialog, QDialogButtonBox,
        QFormLayout, QComboBox, QSpinBox, QColorDialog, QGraphicsPolygonItem,
        QToolButton, QWidgetAction, QSlider, QProgressBar
    )
    from PyQt6.QtCore import (
        Qt, QRectF, QPointF, QTimer, QPropertyAnimation, QEasingCurve,
        pyqtSignal, QObject, QLineF, QSize, QParallelAnimationGroup,
        QSequentialAnimationGroup, pyqtProperty, QVariantAnimation
    )
    from PyQt6.QtGui import (
        QFont, QColor, QPen, QBrush, QPainter, QPainterPath,
        QLinearGradient, QRadialGradient, QCursor, QWheelEvent,
        QMouseEvent, QKeyEvent, QTransform, QPolygonF, QFontMetrics,
        QPalette, QPixmap, QIcon, QAction
    )
    PYQT_AVAILABLE = True
except ImportError:
    PYQT_AVAILABLE = False


# ============================================================================
# Constants & Theme
# ============================================================================

THEME = {
    'bg_dark': '#0d0d0d',
    'bg_primary': '#1a1a1a',
    'bg_secondary': '#252525',
    'bg_tertiary': '#2d2d2d',
    'bg_hover': '#3d3d3d',
    'border': '#3d3d3d',
    'border_light': '#4d4d4d',
    'text_primary': '#e0e0e0',
    'text_secondary': '#a0a0a0',
    'text_muted': '#666666',
    'accent_blue': '#4a9eff',
    'accent_green': '#50c878',
    'accent_orange': '#ff9800',
    'accent_purple': '#e040fb',
    'accent_red': '#ff5555',
    'accent_cyan': '#00bcd4',
    'accent_yellow': '#ffeb3b',
    'success': '#4caf50',
    'warning': '#ff9800',
    'error': '#f44336',
    'shadow': 'rgba(0, 0, 0, 0.4)',
}

NODE_TYPES = {
    'class': {
        'color': '#4a9eff',
        'icon': 'C',
        'gradient_start': '#5aaeff',
        'gradient_end': '#3a8eef',
        'label': 'Class'
    },
    'function': {
        'color': '#50c878',
        'icon': 'fn',
        'gradient_start': '#60d888',
        'gradient_end': '#40b868',
        'label': 'Function'
    },
    'definition': {
        'color': '#ff9800',
        'icon': 'D',
        'gradient_start': '#ffa820',
        'gradient_end': '#e08800',
        'label': 'Definition'
    },
    'object': {
        'color': '#e040fb',
        'icon': 'O',
        'gradient_start': '#f050ff',
        'gradient_end': '#c030db',
        'label': 'Object'
    },
    'interface': {
        'color': '#00bcd4',
        'icon': 'I',
        'gradient_start': '#20cce4',
        'gradient_end': '#00acc4',
        'label': 'Interface'
    },
    'enum': {
        'color': '#ffeb3b',
        'icon': 'E',
        'gradient_start': '#fff34b',
        'gradient_end': '#e0cc2b',
        'label': 'Enum'
    },
    'struct': {
        'color': '#9c27b0',
        'icon': 'S',
        'gradient_start': '#ac37c0',
        'gradient_end': '#8c17a0',
        'label': 'Struct'
    },
    'namespace': {
        'color': '#607d8b',
        'icon': 'N',
        'gradient_start': '#708d9b',
        'gradient_end': '#506d7b',
        'label': 'Namespace'
    }
}


# ============================================================================
# Data Structures
# ============================================================================

@dataclass
class NodeData:
    """Data for a visual node in the CodeMaker"""
    id: str
    node_type: str
    name: str
    description: str = ""
    x: float = 0.0
    y: float = 0.0
    width: float = 200.0
    height: float = 100.0
    color: str = ""
    connections: List[str] = field(default_factory=list)
    properties: Dict[str, str] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())[:8]
        if not self.color:
            self.color = NODE_TYPES.get(self.node_type, {}).get('color', '#4a9eff')
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()


@dataclass
class ConnectionData:
    """Data for a connection between nodes"""
    id: str
    start_node_id: str
    end_node_id: str
    label: str = ""
    color: str = "#4a9eff"
    style: str = "solid"  # solid, dashed, dotted


@dataclass
class MapData:
    """Data for a complete mindmap file"""
    name: str
    description: str = ""
    nodes: List[NodeData] = field(default_factory=list)
    connections: List[ConnectionData] = field(default_factory=list)
    viewport_x: float = 0.0
    viewport_y: float = 0.0
    viewport_zoom: float = 1.0
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()

    def to_dict(self) -> dict:
        return {
            'name': self.name,
            'description': self.description,
            'nodes': [asdict(n) for n in self.nodes],
            'connections': [asdict(c) for c in self.connections],
            'viewport_x': self.viewport_x,
            'viewport_y': self.viewport_y,
            'viewport_zoom': self.viewport_zoom,
            'created_at': self.created_at,
            'updated_at': datetime.now().isoformat()
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'MapData':
        nodes = [NodeData(**n) for n in data.get('nodes', [])]
        connections = [ConnectionData(**c) for c in data.get('connections', [])]
        return cls(
            name=data.get('name', 'Untitled'),
            description=data.get('description', ''),
            nodes=nodes,
            connections=connections,
            viewport_x=data.get('viewport_x', 0.0),
            viewport_y=data.get('viewport_y', 0.0),
            viewport_zoom=data.get('viewport_zoom', 1.0),
            created_at=data.get('created_at', ''),
            updated_at=data.get('updated_at', '')
        )


if PYQT_AVAILABLE:

    # ========================================================================
    # Animated Button with Sophisticated Hover Effects
    # ========================================================================

    class AnimatedButton(QPushButton):
        """Modern animated button with gradient hover effects"""

        def __init__(self, text: str, icon_text: str = "", accent_color: str = None, parent=None):
            super().__init__(parent)
            self._text = text
            self._icon_text = icon_text
            self._accent = QColor(accent_color or THEME['accent_blue'])
            self._hover_progress = 0.0
            self._pressed = False

            self.setText(f"  {icon_text}  {text}" if icon_text else f"  {text}")
            self.setMinimumHeight(44)
            self.setCursor(Qt.CursorShape.PointingHandCursor)
            self.setFont(QFont("Segoe UI", 11))

            # Animation
            self._animation = QVariantAnimation(self)
            self._animation.setDuration(150)
            self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
            self._animation.valueChanged.connect(self._update_hover)

            self._update_style()

        def _update_hover(self, value):
            self._hover_progress = value
            self._update_style()

        def _update_style(self):
            progress = self._hover_progress

            bg_base = QColor(THEME['bg_tertiary'])
            bg_hover = self._accent.darker(140)

            r = int(bg_base.red() + (bg_hover.red() - bg_base.red()) * progress)
            g = int(bg_base.green() + (bg_hover.green() - bg_base.green()) * progress)
            b = int(bg_base.blue() + (bg_hover.blue() - bg_base.blue()) * progress)

            bg_color = f"rgb({r}, {g}, {b})"

            border_color = self._accent.name() if progress > 0.3 else THEME['border']

            if self._pressed:
                bg_color = self._accent.name()
                border_color = self._accent.lighter(120).name()

            glow = int(10 * progress)

            self.setStyleSheet(f'''
                QPushButton {{
                    background-color: {bg_color};
                    border: 1px solid {border_color};
                    border-radius: 8px;
                    color: {THEME['text_primary']};
                    padding: 10px 16px;
                    text-align: left;
                    font-weight: 500;
                }}
            ''')

        def enterEvent(self, event):
            self._animation.setStartValue(self._hover_progress)
            self._animation.setEndValue(1.0)
            self._animation.start()
            super().enterEvent(event)

        def leaveEvent(self, event):
            self._animation.setStartValue(self._hover_progress)
            self._animation.setEndValue(0.0)
            self._animation.start()
            super().leaveEvent(event)

        def mousePressEvent(self, event):
            self._pressed = True
            self._update_style()
            super().mousePressEvent(event)

        def mouseReleaseEvent(self, event):
            self._pressed = False
            self._update_style()
            super().mouseReleaseEvent(event)


    # ========================================================================
    # Visual Node with Professional Design
    # ========================================================================

    class VisualNode(QGraphicsRectItem):
        """A professional visual node with gradients, shadows, and animations"""

        def __init__(self, node_data: NodeData, parent=None):
            super().__init__(parent)
            self.node_data = node_data
            self.connections: List['ConnectionLine'] = []
            self._hover = False
            self._selected = False
            self._resize_handle_size = 12

            # Setup geometry
            self.setRect(0, 0, node_data.width, node_data.height)
            self.setPos(node_data.x, node_data.y)

            # Enable interactions
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable)
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable)
            self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges)
            self.setAcceptHoverEvents(True)
            self.setZValue(1)

            # Get theme for node type
            self.node_theme = NODE_TYPES.get(node_data.node_type, NODE_TYPES['class'])
            self.base_color = QColor(self.node_theme['color'])

            self._create_visual_elements()
            self._apply_shadow()

        def _create_visual_elements(self):
            """Create all visual elements for the node"""
            rect = self.rect()
            w, h = rect.width(), rect.height()

            # Main body gradient
            gradient = QLinearGradient(0, 0, 0, h)
            gradient.setColorAt(0, QColor(self.node_theme['gradient_start']))
            gradient.setColorAt(0.3, QColor(self.node_theme['color']))
            gradient.setColorAt(1, QColor(self.node_theme['gradient_end']))

            self.setBrush(QBrush(gradient))
            self.setPen(QPen(self.base_color.darker(120), 2))

            # Header bar
            self.header = QGraphicsRectItem(0, 0, w, 32, self)
            header_gradient = QLinearGradient(0, 0, 0, 32)
            header_gradient.setColorAt(0, QColor(255, 255, 255, 30))
            header_gradient.setColorAt(1, QColor(0, 0, 0, 30))
            self.header.setBrush(QBrush(header_gradient))
            self.header.setPen(Qt.PenStyle.NoPen)

            # Icon badge
            icon_size = 26
            self.icon_bg = QGraphicsEllipseItem(8, 4, icon_size, icon_size, self)
            self.icon_bg.setBrush(QBrush(QColor(THEME['bg_dark'])))
            self.icon_bg.setPen(QPen(self.base_color.lighter(120), 1.5))

            # Icon text
            icon_text = self.node_theme['icon']
            self.icon_label = QGraphicsTextItem(icon_text, self)
            self.icon_label.setDefaultTextColor(self.base_color.lighter(130))
            icon_font = QFont("Consolas", 10, QFont.Weight.Bold)
            self.icon_label.setFont(icon_font)
            icon_rect = self.icon_label.boundingRect()
            self.icon_label.setPos(
                8 + (icon_size - icon_rect.width()) / 2,
                4 + (icon_size - icon_rect.height()) / 2
            )

            # Name label
            self.name_label = QGraphicsTextItem(self.node_data.name, self)
            self.name_label.setDefaultTextColor(QColor("#ffffff"))
            self.name_label.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
            self.name_label.setPos(40, 6)

            # Type label
            type_text = self.node_theme['label'].upper()
            self.type_label = QGraphicsTextItem(type_text, self)
            self.type_label.setDefaultTextColor(QColor(255, 255, 255, 150))
            self.type_label.setFont(QFont("Segoe UI", 8))
            type_rect = self.type_label.boundingRect()
            self.type_label.setPos(w - type_rect.width() - 10, 10)

            # Description area (below header)
            if self.node_data.description:
                desc_text = self.node_data.description[:80]
                if len(self.node_data.description) > 80:
                    desc_text += "..."
                self.desc_label = QGraphicsTextItem(desc_text, self)
                self.desc_label.setDefaultTextColor(QColor(255, 255, 255, 180))
                self.desc_label.setFont(QFont("Segoe UI", 9))
                self.desc_label.setTextWidth(w - 20)
                self.desc_label.setPos(10, 38)

            # Connection points (circles on edges)
            point_size = 10
            self.connection_points = []

            # Right center
            right_point = QGraphicsEllipseItem(
                w - point_size/2, h/2 - point_size/2,
                point_size, point_size, self
            )
            right_point.setBrush(QBrush(QColor(THEME['bg_dark'])))
            right_point.setPen(QPen(self.base_color, 2))
            right_point.setZValue(2)
            self.connection_points.append(('right', right_point))

            # Left center
            left_point = QGraphicsEllipseItem(
                -point_size/2, h/2 - point_size/2,
                point_size, point_size, self
            )
            left_point.setBrush(QBrush(QColor(THEME['bg_dark'])))
            left_point.setPen(QPen(self.base_color, 2))
            left_point.setZValue(2)
            self.connection_points.append(('left', left_point))

            # Bottom decoration line
            self.bottom_line = QGraphicsRectItem(10, h - 4, w - 20, 2, self)
            self.bottom_line.setBrush(QBrush(self.base_color.lighter(130)))
            self.bottom_line.setPen(Qt.PenStyle.NoPen)

        def _apply_shadow(self):
            """Apply drop shadow effect"""
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(25)
            shadow.setColor(QColor(0, 0, 0, 120))
            shadow.setOffset(4, 4)
            self.setGraphicsEffect(shadow)

        def itemChange(self, change, value):
            """Handle position changes"""
            if change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
                pos = self.pos()
                self.node_data.x = pos.x()
                self.node_data.y = pos.y()
                self.node_data.updated_at = datetime.now().isoformat()
                for conn in self.connections:
                    conn.update_path()
            elif change == QGraphicsItem.GraphicsItemChange.ItemSelectedHasChanged:
                self._selected = value
                self._update_visual_state()
            return super().itemChange(change, value)

        def _update_visual_state(self):
            """Update visual appearance based on state"""
            if self._selected:
                pen_width = 3
                pen_color = self.base_color.lighter(150)
            elif self._hover:
                pen_width = 2.5
                pen_color = self.base_color.lighter(130)
            else:
                pen_width = 2
                pen_color = self.base_color.darker(120)

            self.setPen(QPen(pen_color, pen_width))

        def get_connection_point(self, side: str) -> QPointF:
            """Get the connection point position for a side"""
            rect = self.sceneBoundingRect()
            if side == 'right':
                return QPointF(rect.right(), rect.center().y())
            elif side == 'left':
                return QPointF(rect.left(), rect.center().y())
            elif side == 'top':
                return QPointF(rect.center().x(), rect.top())
            elif side == 'bottom':
                return QPointF(rect.center().x(), rect.bottom())
            return rect.center()

        def get_nearest_connection_point(self, target: QPointF) -> Tuple[str, QPointF]:
            """Get the nearest connection point to a target"""
            sides = ['left', 'right', 'top', 'bottom']
            min_dist = float('inf')
            nearest = ('right', self.get_connection_point('right'))

            for side in sides:
                point = self.get_connection_point(side)
                dist = (point.x() - target.x())**2 + (point.y() - target.y())**2
                if dist < min_dist:
                    min_dist = dist
                    nearest = (side, point)

            return nearest

        def hoverEnterEvent(self, event):
            self._hover = True
            self._update_visual_state()
            super().hoverEnterEvent(event)

        def hoverLeaveEvent(self, event):
            self._hover = False
            self._update_visual_state()
            super().hoverLeaveEvent(event)

        def update_name(self, name: str):
            """Update the displayed name"""
            self.node_data.name = name
            self.name_label.setPlainText(name)
            self.node_data.updated_at = datetime.now().isoformat()

        def update_description(self, desc: str):
            """Update the description"""
            self.node_data.description = desc
            if hasattr(self, 'desc_label'):
                display_text = desc[:80] + "..." if len(desc) > 80 else desc
                self.desc_label.setPlainText(display_text)
            self.node_data.updated_at = datetime.now().isoformat()


    # ========================================================================
    # Connection Line with Bezier Curves and Arrows
    # ========================================================================

    class ConnectionLine(QGraphicsPathItem):
        """A sophisticated connection line with bezier curves and arrow head"""

        def __init__(self, start_node: VisualNode, end_node: VisualNode,
                     connection_data: ConnectionData = None, parent=None):
            super().__init__(parent)
            self.start_node = start_node
            self.end_node = end_node

            if connection_data:
                self.connection_data = connection_data
            else:
                self.connection_data = ConnectionData(
                    id=str(uuid.uuid4())[:8],
                    start_node_id=start_node.node_data.id,
                    end_node_id=end_node.node_data.id
                )

            # Add to nodes' connection lists
            start_node.connections.append(self)
            end_node.connections.append(self)

            # Style
            self.line_color = QColor(self.connection_data.color)
            self._hover = False
            self._setup_style()
            self.setZValue(0)
            self.setAcceptHoverEvents(True)

            # Arrow head
            self.arrow_head = QGraphicsPolygonItem(self)
            self.arrow_head.setBrush(QBrush(self.line_color))
            self.arrow_head.setPen(Qt.PenStyle.NoPen)

            # Label (optional)
            self.label_item = None
            if self.connection_data.label:
                self._create_label()

            self.update_path()

        def _setup_style(self):
            """Setup pen style based on connection data"""
            pen = QPen(self.line_color, 2.5)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)

            if self.connection_data.style == 'dashed':
                pen.setStyle(Qt.PenStyle.DashLine)
            elif self.connection_data.style == 'dotted':
                pen.setStyle(Qt.PenStyle.DotLine)
            else:
                pen.setStyle(Qt.PenStyle.SolidLine)

            self.setPen(pen)

        def _create_label(self):
            """Create label for the connection"""
            self.label_item = QGraphicsTextItem(self.connection_data.label, self)
            self.label_item.setDefaultTextColor(QColor(THEME['text_secondary']))
            self.label_item.setFont(QFont("Segoe UI", 9))

        def update_path(self):
            """Update the bezier curve path"""
            # Find optimal connection points
            end_center = self.end_node.sceneBoundingRect().center()
            start_side, start_point = self.start_node.get_nearest_connection_point(end_center)

            start_center = self.start_node.sceneBoundingRect().center()
            end_side, end_point = self.end_node.get_nearest_connection_point(start_center)

            # Calculate control points for smooth bezier curve
            dx = end_point.x() - start_point.x()
            dy = end_point.y() - start_point.y()
            dist = math.sqrt(dx*dx + dy*dy)
            tension = min(dist * 0.4, 150)

            # Direction vectors based on sides
            def get_direction(side):
                if side == 'right':
                    return QPointF(1, 0)
                elif side == 'left':
                    return QPointF(-1, 0)
                elif side == 'top':
                    return QPointF(0, -1)
                else:
                    return QPointF(0, 1)

            start_dir = get_direction(start_side)
            end_dir = get_direction(end_side)

            ctrl1 = QPointF(
                start_point.x() + start_dir.x() * tension,
                start_point.y() + start_dir.y() * tension
            )
            ctrl2 = QPointF(
                end_point.x() + end_dir.x() * tension,
                end_point.y() + end_dir.y() * tension
            )

            # Create path
            path = QPainterPath()
            path.moveTo(start_point)
            path.cubicTo(ctrl1, ctrl2, end_point)
            self.setPath(path)

            # Update arrow head
            self._update_arrow(end_point, ctrl2)

            # Update label position
            if self.label_item:
                mid_point = path.pointAtPercent(0.5)
                label_rect = self.label_item.boundingRect()
                self.label_item.setPos(
                    mid_point.x() - label_rect.width() / 2,
                    mid_point.y() - label_rect.height() / 2
                )

        def _update_arrow(self, tip: QPointF, control: QPointF):
            """Update arrow head at the end of the line"""
            # Calculate arrow direction
            dx = tip.x() - control.x()
            dy = tip.y() - control.y()
            length = math.sqrt(dx*dx + dy*dy)

            if length > 0:
                dx /= length
                dy /= length

            arrow_size = 12
            angle = math.pi / 6  # 30 degrees

            # Arrow points
            p1 = tip
            p2 = QPointF(
                tip.x() - arrow_size * (dx * math.cos(angle) - dy * math.sin(angle)),
                tip.y() - arrow_size * (dy * math.cos(angle) + dx * math.sin(angle))
            )
            p3 = QPointF(
                tip.x() - arrow_size * (dx * math.cos(angle) + dy * math.sin(angle)),
                tip.y() - arrow_size * (dy * math.cos(angle) - dx * math.sin(angle))
            )

            self.arrow_head.setPolygon(QPolygonF([p1, p2, p3]))

        def hoverEnterEvent(self, event):
            self._hover = True
            pen = self.pen()
            pen.setWidth(4)
            pen.setColor(self.line_color.lighter(130))
            self.setPen(pen)
            self.arrow_head.setBrush(QBrush(self.line_color.lighter(130)))
            super().hoverEnterEvent(event)

        def hoverLeaveEvent(self, event):
            self._hover = False
            self._setup_style()
            self.arrow_head.setBrush(QBrush(self.line_color))
            super().hoverLeaveEvent(event)

        def remove(self):
            """Remove this connection"""
            if self in self.start_node.connections:
                self.start_node.connections.remove(self)
            if self in self.end_node.connections:
                self.end_node.connections.remove(self)


    # ========================================================================
    # Node Properties Dialog
    # ========================================================================

    class NodePropertiesDialog(QDialog):
        """Dialog for editing node properties"""

        def __init__(self, node: VisualNode, parent=None):
            super().__init__(parent)
            self.node = node
            self.setWindowTitle("Node Properties")
            self.setMinimumSize(400, 300)
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

            self._setup_ui()

        def _setup_ui(self):
            # Container
            container = QFrame(self)
            container.setStyleSheet(f'''
                QFrame {{
                    background-color: {THEME['bg_secondary']};
                    border: 1px solid {THEME['border']};
                    border-radius: 12px;
                }}
                QLabel {{
                    color: {THEME['text_primary']};
                    font-size: 12px;
                }}
                QLineEdit, QTextEdit {{
                    background-color: {THEME['bg_tertiary']};
                    border: 1px solid {THEME['border']};
                    border-radius: 6px;
                    padding: 8px;
                    color: {THEME['text_primary']};
                    font-size: 12px;
                }}
                QLineEdit:focus, QTextEdit:focus {{
                    border: 1px solid {THEME['accent_blue']};
                }}
            ''')

            main_layout = QVBoxLayout(self)
            main_layout.setContentsMargins(0, 0, 0, 0)
            main_layout.addWidget(container)

            layout = QVBoxLayout(container)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(16)

            # Header
            header = QLabel("Edit Node")
            header.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
            header.setStyleSheet(f'color: {THEME["accent_blue"]};')
            layout.addWidget(header)

            # Form
            form = QFormLayout()
            form.setSpacing(12)

            self.name_edit = QLineEdit(self.node.node_data.name)
            form.addRow("Name:", self.name_edit)

            self.desc_edit = QTextEdit()
            self.desc_edit.setPlainText(self.node.node_data.description)
            self.desc_edit.setMaximumHeight(100)
            form.addRow("Description:", self.desc_edit)

            layout.addLayout(form)

            # Buttons
            btn_layout = QHBoxLayout()
            btn_layout.addStretch()

            cancel_btn = QPushButton("Cancel")
            cancel_btn.setStyleSheet(f'''
                QPushButton {{
                    background-color: {THEME['bg_tertiary']};
                    border: 1px solid {THEME['border']};
                    border-radius: 6px;
                    padding: 10px 24px;
                    color: {THEME['text_primary']};
                }}
                QPushButton:hover {{
                    background-color: {THEME['bg_hover']};
                }}
            ''')
            cancel_btn.clicked.connect(self.reject)
            btn_layout.addWidget(cancel_btn)

            save_btn = QPushButton("Save")
            save_btn.setStyleSheet(f'''
                QPushButton {{
                    background-color: {THEME['accent_blue']};
                    border: none;
                    border-radius: 6px;
                    padding: 10px 24px;
                    color: white;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: {QColor(THEME['accent_blue']).lighter(110).name()};
                }}
            ''')
            save_btn.clicked.connect(self.accept)
            btn_layout.addWidget(save_btn)

            layout.addLayout(btn_layout)

        def get_values(self) -> Tuple[str, str]:
            return self.name_edit.text(), self.desc_edit.toPlainText()


    # ========================================================================
    # CodeMaker Canvas
    # ========================================================================

    class CodeMakerCanvas(QGraphicsView):
        """Professional interactive canvas with smooth pan/zoom"""

        node_count_changed = pyqtSignal(int)
        connection_count_changed = pyqtSignal(int)
        status_message = pyqtSignal(str)

        def __init__(self, parent=None):
            super().__init__(parent)

            self.scene = QGraphicsScene(self)
            self.scene.setSceneRect(-10000, -10000, 20000, 20000)
            self.setScene(self.scene)

            # Rendering
            self.setRenderHint(QPainter.RenderHint.Antialiasing)
            self.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            self.setRenderHint(QPainter.RenderHint.TextAntialiasing)
            self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.FullViewportUpdate)
            self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
            self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
            self.setDragMode(QGraphicsView.DragMode.NoDrag)
            self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

            # State
            self._panning = False
            self._pan_start = QPointF()
            self._zoom_level = 1.0
            self._connecting_mode = False
            self._connect_start_node: Optional[VisualNode] = None
            self._temp_line: Optional[QGraphicsLineItem] = None

            self.nodes: Dict[str, VisualNode] = {}
            self.connections: List[ConnectionLine] = []

            self._draw_background()
            self._apply_style()

        def _apply_style(self):
            self.setStyleSheet(f'''
                QGraphicsView {{
                    border: none;
                    background-color: {THEME['bg_dark']};
                }}
            ''')

        def _draw_background(self):
            """Draw professional grid background"""
            # Minor grid
            minor_pen = QPen(QColor(THEME['bg_secondary']), 0.5)
            minor_size = 25
            for x in range(-10000, 10000, minor_size):
                line = self.scene.addLine(x, -10000, x, 10000, minor_pen)
                line.setZValue(-100)
            for y in range(-10000, 10000, minor_size):
                line = self.scene.addLine(-10000, y, 10000, y, minor_pen)
                line.setZValue(-100)

            # Major grid
            major_pen = QPen(QColor(THEME['bg_tertiary']), 1)
            major_size = 100
            for x in range(-10000, 10000, major_size):
                line = self.scene.addLine(x, -10000, x, 10000, major_pen)
                line.setZValue(-99)
            for y in range(-10000, 10000, major_size):
                line = self.scene.addLine(-10000, y, 10000, y, major_pen)
                line.setZValue(-99)

            # Center cross
            center_pen = QPen(QColor(THEME['accent_blue']).darker(200), 2)
            self.scene.addLine(-50, 0, 50, 0, center_pen).setZValue(-98)
            self.scene.addLine(0, -50, 0, 50, center_pen).setZValue(-98)

        def add_node(self, node_type: str, name: str, x: float = None, y: float = None) -> VisualNode:
            """Add a new node to the canvas"""
            if x is None:
                x = self.mapToScene(self.viewport().rect().center()).x() - 100
            if y is None:
                y = self.mapToScene(self.viewport().rect().center()).y() - 50

            node_data = NodeData(
                id=str(uuid.uuid4())[:8],
                node_type=node_type,
                name=name,
                x=x,
                y=y
            )

            visual_node = VisualNode(node_data)
            self.scene.addItem(visual_node)
            self.nodes[node_data.id] = visual_node

            self.node_count_changed.emit(len(self.nodes))
            self.status_message.emit(f"Created {node_type}: {name}")

            return visual_node

        def connect_nodes(self, start: VisualNode, end: VisualNode,
                         label: str = "", style: str = "solid") -> Optional[ConnectionLine]:
            """Create a connection between nodes"""
            if start == end:
                return None

            # Check for duplicate
            for conn in self.connections:
                if (conn.start_node == start and conn.end_node == end) or \
                   (conn.start_node == end and conn.end_node == start):
                    self.status_message.emit("Connection already exists")
                    return None

            conn_data = ConnectionData(
                id=str(uuid.uuid4())[:8],
                start_node_id=start.node_data.id,
                end_node_id=end.node_data.id,
                label=label,
                style=style
            )

            connection = ConnectionLine(start, end, conn_data)
            self.scene.addItem(connection)
            self.connections.append(connection)

            # Update node data
            if end.node_data.id not in start.node_data.connections:
                start.node_data.connections.append(end.node_data.id)
            if start.node_data.id not in end.node_data.connections:
                end.node_data.connections.append(start.node_data.id)

            self.connection_count_changed.emit(len(self.connections))
            self.status_message.emit(f"Connected: {start.node_data.name} -> {end.node_data.name}")

            return connection

        def delete_node(self, node: VisualNode):
            """Delete a node and its connections"""
            # Remove all connections
            for conn in list(node.connections):
                self.delete_connection(conn)

            # Remove from dict
            if node.node_data.id in self.nodes:
                del self.nodes[node.node_data.id]

            self.scene.removeItem(node)
            self.node_count_changed.emit(len(self.nodes))
            self.status_message.emit(f"Deleted: {node.node_data.name}")

        def delete_connection(self, conn: ConnectionLine):
            """Delete a connection"""
            if conn in self.connections:
                self.connections.remove(conn)
            conn.remove()
            self.scene.removeItem(conn)
            self.connection_count_changed.emit(len(self.connections))

        def get_map_data(self) -> MapData:
            """Export current state to MapData"""
            transform = self.transform()
            center = self.mapToScene(self.viewport().rect().center())

            return MapData(
                name="Untitled",
                nodes=[n.node_data for n in self.nodes.values()],
                connections=[c.connection_data for c in self.connections],
                viewport_x=center.x(),
                viewport_y=center.y(),
                viewport_zoom=self._zoom_level
            )

        def load_map_data(self, map_data: MapData):
            """Load map from MapData"""
            self.clear_all()

            # Create nodes
            for node_data in map_data.nodes:
                visual_node = VisualNode(node_data)
                self.scene.addItem(visual_node)
                self.nodes[node_data.id] = visual_node

            # Create connections
            for conn_data in map_data.connections:
                if conn_data.start_node_id in self.nodes and conn_data.end_node_id in self.nodes:
                    start = self.nodes[conn_data.start_node_id]
                    end = self.nodes[conn_data.end_node_id]
                    connection = ConnectionLine(start, end, conn_data)
                    self.scene.addItem(connection)
                    self.connections.append(connection)

            # Restore viewport
            self._zoom_level = map_data.viewport_zoom
            self.resetTransform()
            self.scale(self._zoom_level, self._zoom_level)
            self.centerOn(map_data.viewport_x, map_data.viewport_y)

            self.node_count_changed.emit(len(self.nodes))
            self.connection_count_changed.emit(len(self.connections))

        def clear_all(self):
            """Clear canvas"""
            for conn in list(self.connections):
                conn.remove()
                self.scene.removeItem(conn)
            for node in list(self.nodes.values()):
                self.scene.removeItem(node)

            self.nodes.clear()
            self.connections.clear()

            self.node_count_changed.emit(0)
            self.connection_count_changed.emit(0)

        def start_connection_mode(self, start_node: VisualNode):
            """Start connection mode from a node"""
            self._connecting_mode = True
            self._connect_start_node = start_node
            self.setCursor(Qt.CursorShape.CrossCursor)
            self.status_message.emit("Click on another node to connect (ESC to cancel)")

        def cancel_connection_mode(self):
            """Cancel connection mode"""
            self._connecting_mode = False
            self._connect_start_node = None
            if self._temp_line:
                self.scene.removeItem(self._temp_line)
                self._temp_line = None
            self.setCursor(Qt.CursorShape.ArrowCursor)
            self.status_message.emit("Connection cancelled")

        def wheelEvent(self, event: QWheelEvent):
            """Smooth zoom with wheel"""
            factor = 1.1

            if event.angleDelta().y() > 0:
                if self._zoom_level < 3.0:
                    self._zoom_level *= factor
                    self.scale(factor, factor)
            else:
                if self._zoom_level > 0.2:
                    self._zoom_level /= factor
                    self.scale(1/factor, 1/factor)

        def mousePressEvent(self, event: QMouseEvent):
            if event.button() == Qt.MouseButton.MiddleButton:
                self._panning = True
                self._pan_start = event.position()
                self.setCursor(Qt.CursorShape.ClosedHandCursor)
            elif self._connecting_mode and event.button() == Qt.MouseButton.LeftButton:
                scene_pos = self.mapToScene(event.pos())
                item = self.scene.itemAt(scene_pos, self.transform())

                target_node = self._find_node_at(item)
                if target_node and target_node != self._connect_start_node:
                    self.connect_nodes(self._connect_start_node, target_node)
                    self.cancel_connection_mode()
                elif not target_node:
                    self.cancel_connection_mode()
            else:
                super().mousePressEvent(event)

        def mouseMoveEvent(self, event: QMouseEvent):
            if self._panning:
                delta = event.position() - self._pan_start
                self._pan_start = event.position()
                self.horizontalScrollBar().setValue(
                    int(self.horizontalScrollBar().value() - delta.x())
                )
                self.verticalScrollBar().setValue(
                    int(self.verticalScrollBar().value() - delta.y())
                )
            elif self._connecting_mode and self._connect_start_node:
                scene_pos = self.mapToScene(event.pos())
                start = self._connect_start_node.get_connection_point('right')

                if not self._temp_line:
                    self._temp_line = self.scene.addLine(
                        start.x(), start.y(), scene_pos.x(), scene_pos.y(),
                        QPen(QColor(THEME['accent_blue']), 2, Qt.PenStyle.DashLine)
                    )
                else:
                    self._temp_line.setLine(start.x(), start.y(), scene_pos.x(), scene_pos.y())
            else:
                super().mouseMoveEvent(event)

        def mouseReleaseEvent(self, event: QMouseEvent):
            if event.button() == Qt.MouseButton.MiddleButton:
                self._panning = False
                self.setCursor(Qt.CursorShape.ArrowCursor)
            else:
                super().mouseReleaseEvent(event)

        def keyPressEvent(self, event: QKeyEvent):
            if event.key() == Qt.Key.Key_Escape:
                if self._connecting_mode:
                    self.cancel_connection_mode()
                else:
                    self.scene.clearSelection()
            elif event.key() == Qt.Key.Key_Delete:
                for item in self.scene.selectedItems():
                    if isinstance(item, VisualNode):
                        self.delete_node(item)
            else:
                super().keyPressEvent(event)

        def _find_node_at(self, item) -> Optional[VisualNode]:
            """Find the VisualNode for an item"""
            if isinstance(item, VisualNode):
                return item
            elif item:
                parent = item.parentItem()
                while parent:
                    if isinstance(parent, VisualNode):
                        return parent
                    parent = parent.parentItem()
            return None

        def contextMenuEvent(self, event):
            """Professional context menu"""
            scene_pos = self.mapToScene(event.pos())
            item = self.scene.itemAt(scene_pos, self.transform())
            node = self._find_node_at(item)

            menu = QMenu(self)
            menu.setStyleSheet(f'''
                QMenu {{
                    background-color: {THEME['bg_secondary']};
                    border: 1px solid {THEME['border']};
                    border-radius: 8px;
                    padding: 8px;
                }}
                QMenu::item {{
                    background-color: transparent;
                    padding: 10px 24px 10px 16px;
                    color: {THEME['text_primary']};
                    border-radius: 4px;
                    margin: 2px 4px;
                }}
                QMenu::item:selected {{
                    background-color: {THEME['accent_blue']};
                }}
                QMenu::separator {{
                    height: 1px;
                    background: {THEME['border']};
                    margin: 6px 8px;
                }}
                QMenu::icon {{
                    padding-left: 8px;
                }}
            ''')

            if node:
                # Node context menu
                props_action = menu.addAction("Properties...")
                rename_action = menu.addAction("Rename")
                menu.addSeparator()
                connect_action = menu.addAction("Connect to...")
                menu.addSeparator()
                delete_action = menu.addAction("Delete")

                action = menu.exec(event.globalPos())

                if action == props_action:
                    dialog = NodePropertiesDialog(node, self)
                    if dialog.exec() == QDialog.DialogCode.Accepted:
                        name, desc = dialog.get_values()
                        if name:
                            node.update_name(name)
                        node.update_description(desc)

                elif action == rename_action:
                    name, ok = QInputDialog.getText(
                        self, "Rename", "New name:", text=node.node_data.name
                    )
                    if ok and name:
                        node.update_name(name)

                elif action == connect_action:
                    self.start_connection_mode(node)

                elif action == delete_action:
                    self.delete_node(node)

            else:
                # Canvas context menu - create nodes
                create_menu = menu.addMenu("New...")

                for node_type, config in NODE_TYPES.items():
                    action = create_menu.addAction(f"{config['icon']}  {config['label']}")
                    action.setData(node_type)

                menu.addSeparator()
                center_action = menu.addAction("Center View")
                reset_zoom_action = menu.addAction("Reset Zoom")

                action = menu.exec(event.globalPos())

                if action and action.data():
                    node_type = action.data()
                    name, ok = QInputDialog.getText(
                        self, f"New {NODE_TYPES[node_type]['label']}", "Name:"
                    )
                    if ok and name:
                        self.add_node(node_type, name, scene_pos.x(), scene_pos.y())

                elif action == center_action:
                    self.centerOn(0, 0)

                elif action == reset_zoom_action:
                    self._zoom_level = 1.0
                    self.resetTransform()


    # ========================================================================
    # File Tree Panel
    # ========================================================================

    class FileTreePanel(QFrame):
        """Professional file tree for .ma map files"""

        file_selected = pyqtSignal(str)
        file_created = pyqtSignal(str)
        file_deleted = pyqtSignal(str)

        def __init__(self, project_path: Path, parent=None):
            super().__init__(parent)
            self.project_path = project_path
            self.maps_dir = project_path / ".includecpp" / "maps"
            self.maps_dir.mkdir(parents=True, exist_ok=True)

            self._setup_ui()
            self._load_files()

        def _setup_ui(self):
            self.setStyleSheet(f'''
                QFrame {{
                    background-color: {THEME['bg_primary']};
                    border-right: 1px solid {THEME['border']};
                }}
            ''')

            layout = QVBoxLayout(self)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(0)

            # Header
            header = QFrame()
            header.setFixedHeight(48)
            header.setStyleSheet(f'''
                QFrame {{
                    background-color: {THEME['bg_secondary']};
                    border-bottom: 1px solid {THEME['border']};
                }}
            ''')

            header_layout = QHBoxLayout(header)
            header_layout.setContentsMargins(16, 0, 12, 0)

            title = QLabel("Maps")
            title.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
            title.setStyleSheet(f'color: {THEME["text_primary"]};')
            header_layout.addWidget(title)

            header_layout.addStretch()

            new_btn = QPushButton("+")
            new_btn.setFixedSize(28, 28)
            new_btn.setStyleSheet(f'''
                QPushButton {{
                    background-color: {THEME['accent_blue']};
                    border: none;
                    border-radius: 14px;
                    color: white;
                    font-size: 18px;
                    font-weight: bold;
                }}
                QPushButton:hover {{
                    background-color: {QColor(THEME['accent_blue']).lighter(115).name()};
                }}
                QPushButton:pressed {{
                    background-color: {QColor(THEME['accent_blue']).darker(110).name()};
                }}
            ''')
            new_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            new_btn.setToolTip("Create new map")
            new_btn.clicked.connect(self._create_new)
            header_layout.addWidget(new_btn)

            layout.addWidget(header)

            # Tree widget
            self.tree = QTreeWidget()
            self.tree.setHeaderHidden(True)
            self.tree.setIndentation(0)
            self.tree.setAnimated(True)
            self.tree.setStyleSheet(f'''
                QTreeWidget {{
                    background-color: {THEME['bg_primary']};
                    border: none;
                    color: {THEME['text_primary']};
                    font-size: 12px;
                    outline: none;
                }}
                QTreeWidget::item {{
                    padding: 12px 16px;
                    border-bottom: 1px solid {THEME['bg_secondary']};
                }}
                QTreeWidget::item:selected {{
                    background-color: {THEME['accent_blue']}40;
                    border-left: 3px solid {THEME['accent_blue']};
                }}
                QTreeWidget::item:hover:!selected {{
                    background-color: {THEME['bg_tertiary']};
                }}
            ''')
            self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
            self.tree.customContextMenuRequested.connect(self._context_menu)
            self.tree.itemDoubleClicked.connect(self._on_double_click)
            layout.addWidget(self.tree)

        def _load_files(self):
            """Load .ma files"""
            self.tree.clear()

            for file_path in sorted(self.maps_dir.glob("*.ma")):
                item = QTreeWidgetItem([f"  {file_path.stem}"])
                item.setData(0, Qt.ItemDataRole.UserRole, str(file_path))
                item.setToolTip(0, file_path.name)
                self.tree.addTopLevelItem(item)

        def _create_new(self):
            """Create new map file"""
            name, ok = QInputDialog.getText(self, "New Map", "Map name:")
            if ok and name:
                safe_name = name.replace(" ", "_").replace("/", "_")
                file_path = self.maps_dir / f"{safe_name}.ma"

                map_data = MapData(name=name)
                file_path.write_text(json.dumps(map_data.to_dict(), indent=2))

                self._load_files()
                self.file_created.emit(str(file_path))

        def _on_double_click(self, item, column):
            file_path = item.data(0, Qt.ItemDataRole.UserRole)
            if file_path:
                self.file_selected.emit(file_path)

        def _context_menu(self, pos):
            item = self.tree.itemAt(pos)
            if not item:
                return

            file_path = item.data(0, Qt.ItemDataRole.UserRole)

            menu = QMenu(self)
            menu.setStyleSheet(f'''
                QMenu {{
                    background-color: {THEME['bg_secondary']};
                    border: 1px solid {THEME['border']};
                    border-radius: 8px;
                    padding: 4px;
                }}
                QMenu::item {{
                    padding: 10px 20px;
                    color: {THEME['text_primary']};
                    border-radius: 4px;
                    margin: 2px;
                }}
                QMenu::item:selected {{
                    background-color: {THEME['accent_blue']};
                }}
            ''')

            open_action = menu.addAction("Open")
            menu.addSeparator()
            rename_action = menu.addAction("Rename")
            clear_action = menu.addAction("Clear Contents")
            menu.addSeparator()
            delete_action = menu.addAction("Delete")
            delete_action.setProperty("danger", True)

            action = menu.exec(self.tree.mapToGlobal(pos))

            if action == open_action:
                self.file_selected.emit(file_path)

            elif action == rename_action:
                old_name = Path(file_path).stem
                new_name, ok = QInputDialog.getText(
                    self, "Rename", "New name:", text=old_name
                )
                if ok and new_name and new_name != old_name:
                    new_path = self.maps_dir / f"{new_name}.ma"
                    Path(file_path).rename(new_path)
                    self._load_files()

            elif action == clear_action:
                map_data = MapData(name=Path(file_path).stem)
                Path(file_path).write_text(json.dumps(map_data.to_dict(), indent=2))
                self.file_selected.emit(file_path)

            elif action == delete_action:
                reply = QMessageBox.question(
                    self, "Delete Map",
                    f"Are you sure you want to delete '{Path(file_path).stem}'?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                if reply == QMessageBox.StandardButton.Yes:
                    Path(file_path).unlink()
                    self._load_files()
                    self.file_deleted.emit(file_path)


    # ========================================================================
    # Main Project Window
    # ========================================================================

    class ProjectWindow(QMainWindow):
        """Professional project interface main window"""

        def __init__(self, project_path: str = None):
            super().__init__()

            self.project_path = Path(project_path) if project_path else Path.cwd()
            self.current_file: Optional[str] = None
            self._drag_pos = None
            self._auto_save_timer = QTimer(self)
            self._auto_save_timer.timeout.connect(self._auto_save)
            self._auto_save_timer.start(30000)  # Auto-save every 30s

            self._setup_window()
            self._setup_ui()

        def _setup_window(self):
            self.setWindowTitle("IncludeCPP - Project Overview")
            self.setMinimumSize(1400, 900)
            self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
            self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        def _setup_ui(self):
            # Main container
            container = QWidget()
            container.setStyleSheet(f'''
                QWidget {{
                    background-color: {THEME['bg_primary']};
                    border-radius: 12px;
                }}
            ''')
            self.setCentralWidget(container)

            main_layout = QVBoxLayout(container)
            main_layout.setContentsMargins(0, 0, 0, 0)
            main_layout.setSpacing(0)

            # Title bar
            main_layout.addWidget(self._create_title_bar())

            # Content
            content = QWidget()
            content_layout = QHBoxLayout(content)
            content_layout.setContentsMargins(0, 0, 0, 0)
            content_layout.setSpacing(0)

            # Sidebar
            content_layout.addWidget(self._create_sidebar())

            # Main area
            self.main_stack = QWidget()
            self.main_stack.setStyleSheet(f'background-color: {THEME["bg_dark"]};')
            self.main_stack_layout = QVBoxLayout(self.main_stack)
            self.main_stack_layout.setContentsMargins(0, 0, 0, 0)
            content_layout.addWidget(self.main_stack, 1)

            main_layout.addWidget(content, 1)

            # Status bar
            main_layout.addWidget(self._create_status_bar())

        def _create_title_bar(self) -> QFrame:
            bar = QFrame()
            bar.setFixedHeight(52)
            bar.setStyleSheet(f'''
                QFrame {{
                    background-color: {THEME['bg_secondary']};
                    border-top-left-radius: 12px;
                    border-top-right-radius: 12px;
                    border-bottom: 1px solid {THEME['border']};
                }}
            ''')

            layout = QHBoxLayout(bar)
            layout.setContentsMargins(20, 0, 16, 0)

            # Logo
            logo = QLabel("IncludeCPP")
            logo.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
            logo.setStyleSheet(f'color: {THEME["accent_blue"]};')
            layout.addWidget(logo)

            # Separator
            sep = QLabel("|")
            sep.setStyleSheet(f'color: {THEME["border"]}; margin: 0 12px;')
            layout.addWidget(sep)

            # Title
            self.title_label = QLabel("Project Overview")
            self.title_label.setFont(QFont("Segoe UI", 11))
            self.title_label.setStyleSheet(f'color: {THEME["text_secondary"]};')
            layout.addWidget(self.title_label)

            layout.addStretch()

            # Window controls
            for text, color, action in [
                ("_", THEME['bg_hover'], self.showMinimized),
                ("[]", THEME['bg_hover'], self._toggle_maximize),
                ("X", THEME['accent_red'], self.close)
            ]:
                btn = QPushButton(text)
                btn.setFixedSize(40, 32)
                btn.setStyleSheet(f'''
                    QPushButton {{
                        background-color: transparent;
                        border: none;
                        border-radius: 6px;
                        color: {THEME['text_secondary']};
                        font-size: 13px;
                        font-weight: bold;
                    }}
                    QPushButton:hover {{
                        background-color: {color};
                        color: {THEME['text_primary']};
                    }}
                ''')
                btn.setCursor(Qt.CursorShape.PointingHandCursor)
                btn.clicked.connect(action)
                layout.addWidget(btn)

            return bar

        def _create_sidebar(self) -> QFrame:
            sidebar = QFrame()
            sidebar.setFixedWidth(240)
            sidebar.setStyleSheet(f'''
                QFrame {{
                    background-color: {THEME['bg_primary']};
                    border-right: 1px solid {THEME['border']};
                }}
            ''')

            layout = QVBoxLayout(sidebar)
            layout.setContentsMargins(16, 20, 16, 20)
            layout.setSpacing(8)

            # Section label
            section = QLabel("TOOLS")
            section.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            section.setStyleSheet(f'color: {THEME["text_muted"]}; letter-spacing: 1px;')
            layout.addWidget(section)

            layout.addSpacing(8)

            # Navigation buttons
            codemaker_btn = AnimatedButton("CodeMaker", "#", THEME['accent_blue'])
            codemaker_btn.clicked.connect(self._show_codemaker)
            layout.addWidget(codemaker_btn)

            layout.addStretch()

            # Project info
            info_frame = QFrame()
            info_frame.setStyleSheet(f'''
                QFrame {{
                    background-color: {THEME['bg_secondary']};
                    border-radius: 8px;
                    padding: 12px;
                }}
            ''')
            info_layout = QVBoxLayout(info_frame)
            info_layout.setContentsMargins(12, 12, 12, 12)
            info_layout.setSpacing(4)

            proj_label = QLabel("PROJECT")
            proj_label.setFont(QFont("Segoe UI", 8))
            proj_label.setStyleSheet(f'color: {THEME["text_muted"]};')
            info_layout.addWidget(proj_label)

            proj_name = QLabel(self.project_path.name)
            proj_name.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
            proj_name.setStyleSheet(f'color: {THEME["text_primary"]};')
            proj_name.setWordWrap(True)
            info_layout.addWidget(proj_name)

            layout.addWidget(info_frame)

            return sidebar

        def _create_status_bar(self) -> QFrame:
            bar = QFrame()
            bar.setFixedHeight(28)
            bar.setStyleSheet(f'''
                QFrame {{
                    background-color: {THEME['bg_secondary']};
                    border-bottom-left-radius: 12px;
                    border-bottom-right-radius: 12px;
                    border-top: 1px solid {THEME['border']};
                }}
            ''')

            layout = QHBoxLayout(bar)
            layout.setContentsMargins(16, 0, 16, 0)

            self.status_label = QLabel("Ready")
            self.status_label.setFont(QFont("Segoe UI", 9))
            self.status_label.setStyleSheet(f'color: {THEME["text_muted"]};')
            layout.addWidget(self.status_label)

            layout.addStretch()

            self.node_count_label = QLabel("Nodes: 0")
            self.node_count_label.setStyleSheet(f'color: {THEME["text_muted"]}; margin-right: 16px;')
            layout.addWidget(self.node_count_label)

            self.connection_count_label = QLabel("Connections: 0")
            self.connection_count_label.setStyleSheet(f'color: {THEME["text_muted"]};')
            layout.addWidget(self.connection_count_label)

            return bar

        def _show_codemaker(self):
            """Display CodeMaker interface"""
            # Clear previous
            while self.main_stack_layout.count():
                item = self.main_stack_layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()

            self.title_label.setText("CodeMaker")

            # Layout
            codemaker = QWidget()
            codemaker_layout = QHBoxLayout(codemaker)
            codemaker_layout.setContentsMargins(0, 0, 0, 0)
            codemaker_layout.setSpacing(0)

            # File tree
            self.file_tree = FileTreePanel(self.project_path)
            self.file_tree.setFixedWidth(220)
            self.file_tree.file_selected.connect(self._load_map)
            codemaker_layout.addWidget(self.file_tree)

            # Canvas
            self.canvas = CodeMakerCanvas()
            self.canvas.node_count_changed.connect(
                lambda n: self.node_count_label.setText(f"Nodes: {n}")
            )
            self.canvas.connection_count_changed.connect(
                lambda n: self.connection_count_label.setText(f"Connections: {n}")
            )
            self.canvas.status_message.connect(
                lambda msg: self.status_label.setText(msg)
            )
            codemaker_layout.addWidget(self.canvas, 1)

            self.main_stack_layout.addWidget(codemaker)

        def _load_map(self, file_path: str):
            """Load a map file"""
            try:
                data = json.loads(Path(file_path).read_text())
                map_data = MapData.from_dict(data)
                self.canvas.load_map_data(map_data)
                self.current_file = file_path
                self.title_label.setText(f"CodeMaker - {map_data.name}")
                self.status_label.setText(f"Loaded: {Path(file_path).stem}")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to load map: {e}")

        def _save_current(self):
            """Save current map"""
            if self.current_file and hasattr(self, 'canvas'):
                try:
                    map_data = self.canvas.get_map_data()
                    map_data.name = Path(self.current_file).stem
                    Path(self.current_file).write_text(
                        json.dumps(map_data.to_dict(), indent=2)
                    )
                    self.status_label.setText(f"Saved: {map_data.name}")
                except Exception as e:
                    self.status_label.setText(f"Save failed: {e}")

        def _auto_save(self):
            """Auto-save callback"""
            if self.current_file and hasattr(self, 'canvas'):
                self._save_current()

        def _toggle_maximize(self):
            if self.isMaximized():
                self.showNormal()
            else:
                self.showMaximized()

        def mousePressEvent(self, event):
            if event.button() == Qt.MouseButton.LeftButton and event.position().y() < 52:
                self._drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()

        def mouseMoveEvent(self, event):
            if event.buttons() == Qt.MouseButton.LeftButton and self._drag_pos:
                self.move(event.globalPosition().toPoint() - self._drag_pos)

        def mouseReleaseEvent(self, event):
            self._drag_pos = None

        def closeEvent(self, event):
            self._save_current()
            super().closeEvent(event)


    def show_project(project_path: str = None) -> Tuple[bool, str]:
        """Launch the project interface"""
        if not PYQT_AVAILABLE:
            return False, "PyQt6 not installed. Run: pip install PyQt6"

        app = QApplication.instance()
        if not app:
            app = QApplication(sys.argv)

        window = ProjectWindow(project_path)
        window.show()
        window._show_codemaker()

        app.exec()
        return True, "Project closed"


else:
    def show_project(project_path: str = None) -> Tuple[bool, str]:
        return False, "PyQt6 not installed. Run: pip install PyQt6"


if __name__ == '__main__':
    success, msg = show_project()
    if not success:
        print(msg)
