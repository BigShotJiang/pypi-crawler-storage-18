"""
Send custom email function.
"""

import asyncio
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, To

from apexsaas.exceptions import ApexEmailError, ApexValidationError


async def send_email(
    to_email: str,
    to_name: str = None,
    subject: str = None,
    html_content: str = None,
    sendgrid_api_key: str = None,
    from_email: str = None,
    from_name: str = "Apex",
    text_content: str = None
) -> dict:
    """
    Send custom email (async).
    
    Args:
        to_email: Recipient email address
        to_name: Recipient name (optional, defaults to email prefix)
        subject: Email subject
        html_content: HTML email content
        sendgrid_api_key: SendGrid API key
        from_email: Sender email address
        from_name: Sender name (default: "Apex")
        text_content: Optional plain text content (defaults to HTML stripped)
    
    Returns:
        dict with success status and message details
    
    Raises:
        ApexValidationError: If required parameters are missing
        ApexEmailError: If SendGrid API call fails
    """
    if not to_email:
        raise ApexValidationError("to_email is required")
    if not subject:
        raise ApexValidationError("subject is required")
    if not html_content:
        raise ApexValidationError("html_content is required")
    if not sendgrid_api_key:
        raise ApexValidationError("sendgrid_api_key is required")
    if not from_email:
        raise ApexValidationError("from_email is required")
    
    # Default to_name to email prefix if not provided
    if not to_name:
        to_name = to_email.split('@')[0]
    
    try:
        # Create message
        message = Mail(
            from_email=(from_email, from_name),
            to_emails=To(to_email),
            subject=subject,
            html_content=html_content,
            plain_text_content=text_content or html_content  # Fallback to HTML if no text
        )
        
        # Send email (run in thread to avoid blocking)
        def _send():
            client = SendGridAPIClient(api_key=sendgrid_api_key)
            return client.send(message)
        
        response = await asyncio.to_thread(_send)
        
        # Check response
        if response.status_code not in [200, 201, 202]:
            error_msg = f"SendGrid API error: {response.status_code}"
            # Try to extract error message from response body
            try:
                if hasattr(response, 'body') and response.body:
                    import json
                    error_data = json.loads(response.body)
                    if 'errors' in error_data and len(error_data['errors']) > 0:
                        error_msg = error_data['errors'][0].get('message', error_msg)
            except:
                pass
            return {
                'success': False,
                'message': error_msg,
                'status_code': response.status_code
            }
        
        return {
            'success': True,
            'message_id': response.headers.get('X-Message-Id', 'unknown'),
            'message': f'Email sent successfully to {to_email}'
        }
    
    except Exception as e:
        if isinstance(e, (ApexValidationError, ApexEmailError)):
            raise
        
        # Extract error message from SendGrid exception
        error_msg = str(e)
        if hasattr(e, 'body'):
            try:
                import json
                error_data = json.loads(e.body)
                if 'errors' in error_data and len(error_data['errors']) > 0:
                    error_msg = error_data['errors'][0].get('message', error_msg)
            except:
                pass
        
        # Return error dict instead of raising exception
        return {
            'success': False,
            'message': f'Failed to send email: {error_msg}',
            'error': error_msg
        }


def send_email_sync(
    to_email: str,
    to_name: str = None,
    subject: str = None,
    html_content: str = None,
    sendgrid_api_key: str = None,
    from_email: str = None,
    from_name: str = "Apex",
    text_content: str = None
) -> dict:
    """Sync wrapper for send_email."""
    from apexsaas.core.utils.async_runner import run_async
    try:
        result = run_async(send_email(
            to_email=to_email,
            to_name=to_name,
            subject=subject,
            html_content=html_content,
            sendgrid_api_key=sendgrid_api_key,
            from_email=from_email,
            from_name=from_name,
            text_content=text_content
        ))
        return result
    except Exception as e:
        error_msg = str(e)
        if hasattr(e, 'body'):
            try:
                import json
                error_data = json.loads(e.body)
                if 'errors' in error_data and len(error_data['errors']) > 0:
                    error_msg = error_data['errors'][0].get('message', error_msg)
            except:
                pass
        return {
            'success': False,
            'message': f'Failed to send email: {error_msg}',
            'error': error_msg
        }
