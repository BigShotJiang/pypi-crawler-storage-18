"""
Send password reset email function.
"""

import asyncio
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail, To

from apexsaas.exceptions import ApexEmailError, ApexValidationError
from apexsaas.email._templates import get_reset_template


async def send_reset_email(
    to_email: str,
    to_name: str,
    reset_url: str,
    sendgrid_api_key: str,
    from_email: str,
    from_name: str = "Apex"
) -> dict:
    """
    Send password reset email (async).
    
    Args:
        to_email: Recipient email address
        to_name: Recipient name
        reset_url: URL for password reset
        sendgrid_api_key: SendGrid API key
        from_email: Sender email address
        from_name: Sender name (default: "Apex")
    
    Returns:
        dict with success status and message details
    
    Raises:
        ApexValidationError: If required parameters are missing
        ApexEmailError: If SendGrid API call fails
    """
    if not to_email or not to_name:
        raise ApexValidationError("to_email and to_name are required")
    if not reset_url:
        raise ApexValidationError("reset_url is required")
    if not sendgrid_api_key:
        raise ApexValidationError("sendgrid_api_key is required")
    if not from_email:
        raise ApexValidationError("from_email is required")
    
    try:
        # Get HTML template
        html_content = get_reset_template(reset_url, to_name)
        
        # Create message
        message = Mail(
            from_email=(from_email, from_name),
            to_emails=To(to_email),
            subject="Reset Your Password",
            html_content=html_content,
            plain_text_content=f"Reset your password by visiting: {reset_url}"
        )
        
        # Send email (run in thread to avoid blocking)
        def _send():
            client = SendGridAPIClient(api_key=sendgrid_api_key)
            return client.send(message)
        
        response = await asyncio.to_thread(_send)
        
        # Check response
        if response.status_code not in [200, 201, 202]:
            error_msg = f"SendGrid API error: {response.status_code}"
            # Try to extract error message from response body
            try:
                if hasattr(response, 'body') and response.body:
                    import json
                    error_data = json.loads(response.body)
                    if 'errors' in error_data and len(error_data['errors']) > 0:
                        error_msg = error_data['errors'][0].get('message', error_msg)
            except:
                pass
            return {
                'success': False,
                'message': error_msg,
                'status_code': response.status_code
            }
        
        return {
            'success': True,
            'message_id': response.headers.get('X-Message-Id', 'unknown'),
            'message': f'Password reset email sent successfully to {to_email}'
        }
    
    except Exception as e:
        if isinstance(e, (ApexValidationError, ApexEmailError)):
            raise
        
        # Extract error message from SendGrid exception
        error_msg = str(e)
        if hasattr(e, 'body'):
            try:
                import json
                error_data = json.loads(e.body)
                if 'errors' in error_data and len(error_data['errors']) > 0:
                    error_msg = error_data['errors'][0].get('message', error_msg)
            except:
                pass
        
        # Return error dict instead of raising exception
        return {
            'success': False,
            'message': f'Failed to send reset email: {error_msg}',
            'error': error_msg
        }


def send_reset_email_sync(
    to_email: str,
    to_name: str,
    reset_url: str,
    sendgrid_api_key: str,
    from_email: str,
    from_name: str = "Apex"
) -> dict:
    """Sync wrapper for send_reset_email."""
    from apexsaas.core.utils.async_runner import run_async
    try:
        result = run_async(send_reset_email(
            to_email=to_email,
            to_name=to_name,
            reset_url=reset_url,
            sendgrid_api_key=sendgrid_api_key,
            from_email=from_email,
            from_name=from_name
        ))
        return result
    except Exception as e:
        error_msg = str(e)
        if hasattr(e, 'body'):
            try:
                import json
                error_data = json.loads(e.body)
                if 'errors' in error_data and len(error_data['errors']) > 0:
                    error_msg = error_data['errors'][0].get('message', error_msg)
            except:
                pass
        return {
            'success': False,
            'message': f'Failed to send reset email: {error_msg}',
            'error': error_msg
        }
