import json
import logging
import re
from enum import Enum
from functools import cached_property
from typing import Annotated, Any, Literal

from pydantic import (
    ConfigDict,
    Field,
    StringConstraints,
    create_model,
    field_validator,
    model_validator,
)
from pydantic.json_schema import DEFAULT_REF_TEMPLATE, GenerateJsonSchema, JsonSchemaMode

try:
    import pandas as pd
    import redshift_connector

    from toucan_connectors.redshift.utils import build_database_model_extraction_query, types_map

    CONNECTOR_OK = True

except ImportError as exc:  # pragma: no cover
    logging.getLogger(__name__).warning(f"Missing dependencies for {__name__}: {exc}")
    CONNECTOR_OK = False

from toucan_connectors.common import ConnectorStatus
from toucan_connectors.pagination import build_pagination_info
from toucan_connectors.sql_query_helper import SqlQueryHelper
from toucan_connectors.toucan_connector import (
    DataSlice,
    DiscoverableConnector,
    PlainJsonSecretStr,
    TableInfo,
    ToucanConnector,
    ToucanDataSource,
    strlist_to_enum,
)

_LOGGER = logging.getLogger(__name__)


DESCRIBE_QUERY = """SELECT * FROM ({column}) AS q LIMIT 0;"""

DEFAULT_DATABASE = "dev"

ORDERED_KEYS = [
    "type",
    "name",
    "host",
    "port",
    "default_database",
    "authentication_method",
    "user",
    "password",
    "cluster_identifier",
    "db_user",
    "connect_timeout",
    "access_key_id",
    "secret_access_key",
    "session_token",
    "profile",
    "region",
    "enable_tcp_keepalive",
]


class AuthenticationMethod(str, Enum):
    DB_CREDENTIALS = "db_credentials"
    AWS_CREDENTIALS = "aws_credentials"
    AWS_PROFILE = "aws_profile"


class AuthenticationMethodError(str, Enum):
    DB_CREDENTIALS = f"User & Password are required for {AuthenticationMethod.DB_CREDENTIALS}"
    AWS_CREDENTIALS = f"AccessKeyId, SecretAccessKey & db_user are required for {AuthenticationMethod.AWS_CREDENTIALS}"
    AWS_PROFILE = f"Profile & db_user are required for {AuthenticationMethod.AWS_PROFILE}"
    UNKNOWN = "Unknown AuthenticationMethod"


class RedshiftDataSource(ToucanDataSource):
    database: str = Field(DEFAULT_DATABASE, description="The name of the database you want to query")
    query: Annotated[str, StringConstraints(min_length=1)] = Field(  # type: ignore[call-overload]
        None,
        description="You can write a custom query against your "
        "database here. It will take precedence over "
        "the table parameter",
        widget="sql",
    )
    query_object: dict[str, Any] = Field(  # type: ignore[call-overload]
        None,
        description="An object describing a simple select query, this field is used internally",
        **{"ui.hidden": True},
    )
    language: str = Field("sql", **{"ui.hidden": True})  # type: ignore[call-overload]

    @classmethod
    def get_form(cls, connector: "RedshiftConnector", current_config: dict[str, Any]):
        """
        Method to retrieve the form with a current config
        Once the connector is set, we are able to give suggestions for the `database` field
        """
        default_db = current_config.get("database", DEFAULT_DATABASE)
        return create_model(
            "FormSchema",
            database=strlist_to_enum("database", connector._list_db_names(), default_db),
            __base__=cls,
        ).model_json_schema()


class RedshiftConnector(ToucanConnector, DiscoverableConnector, data_source_model=RedshiftDataSource):
    authentication_method: AuthenticationMethod = Field(  # type: ignore[call-overload]
        None,
        title="Authentication Method",
        description="The authentication mechanism that will be used to connect to your redshift data source",
        **{"ui": {"checkbox": False}},
    )
    host: str = Field(..., description="The hostname of the Amazon Redshift cluster")
    port: int = Field(5439, description="The listening port of your Redshift Database")
    default_database: str = Field(DEFAULT_DATABASE, description="The name of the database instance to connect to")
    user: str | None = Field(
        None, description="The username to use for authentication with the Amazon Redshift cluster"
    )
    password: PlainJsonSecretStr | None = Field(
        None, description="The password to use for authentication with the Amazon Redshift cluster"
    )

    db_user: str | None = Field(None, description="The user ID to use with Amazon Redshift")
    cluster_identifier: str | None = Field(None, description="The cluster identifier of the Amazon Redshift cluster")

    connect_timeout: int | None = Field(
        None,
        title="Connection timeout",
        description="You can set a connection timeout in seconds here, i.e. the maximum length of "
        "time you want to wait for the server to respond. None by default",
    )
    # True by default to match redshift_connector kwargs syntax
    enable_tcp_keepalive: bool = Field(
        True,
        title="Enable TCP keep-alive",
        description="You may disable TCP keep-alive by unticking this option. Disabling might be "
        "required for long-running queries or if you are behind a firewall",
    )

    access_key_id: str | None = Field(None, description="The access key id of your aws account.")
    secret_access_key: PlainJsonSecretStr | None = Field(None, description="The secret access key of your aws account.")
    session_token: str | None = Field(None, description="Your session token")
    profile: str | None = Field(None, description="AWS profile")
    region: str | None = Field(None, description="The region in which there is your aws account.")

    model_config = ConfigDict(ignored_types=(cached_property,))

    @classmethod
    def model_json_schema(
        cls,
        by_alias: bool = True,
        ref_template: str = DEFAULT_REF_TEMPLATE,
        # mypy misinterprets type as the ToucanConnector.type field rather than the type keyword
        schema_generator: type[GenerateJsonSchema] = GenerateJsonSchema,  # type:ignore[valid-type]
        mode: JsonSchemaMode = "validation",
        *,
        union_format: Literal["any_of", "primitive_type_array"] = "any_of",
    ) -> dict[str, Any]:
        schema = super().model_json_schema(
            by_alias=by_alias,
            ref_template=ref_template,
            schema_generator=schema_generator,
            mode=mode,
            union_format=union_format,
        )
        schema["properties"] = {k: schema["properties"][k] for k in ORDERED_KEYS}
        return schema

    @field_validator("host")
    @classmethod
    def host_validator(cls, v):
        return re.sub(r"^https?://", "", v)

    @model_validator(mode="after")
    def check_requirements(self):
        if self.authentication_method == AuthenticationMethod.DB_CREDENTIALS.value:
            # TODO: Partial check due to missing context in some operations (Missing: password)
            if self.user is None:
                raise ValueError(AuthenticationMethodError.DB_CREDENTIALS.value)
        elif self.authentication_method == AuthenticationMethod.AWS_CREDENTIALS.value:
            # TODO: Partial check due to missing context in some operations (Missing: secret_access_key)
            if self.access_key_id is None or self.db_user is None:
                raise ValueError(AuthenticationMethodError.AWS_CREDENTIALS.value)
        elif self.authentication_method == AuthenticationMethod.AWS_PROFILE.value:
            if self.profile is None or self.db_user is None:
                raise ValueError(AuthenticationMethodError.AWS_PROFILE.value)
        else:
            raise ValueError(AuthenticationMethodError.UNKNOWN.value)
        return self

    def _get_connection_params(self, database) -> dict[str, Any]:
        con_params = {
            "database": database,
            "host": self.host,
            "port": self.port,
            "timeout": self.connect_timeout,
            "cluster_identifier": self.cluster_identifier,
            "tcp_keepalive": self.enable_tcp_keepalive,
        }
        if self.authentication_method == AuthenticationMethod.DB_CREDENTIALS.value:
            con_params["user"] = self.user
            con_params["password"] = self.password.get_secret_value() if self.password else None
        elif self.authentication_method == AuthenticationMethod.AWS_CREDENTIALS.value:
            con_params["iam"] = True
            con_params["db_user"] = self.db_user
            con_params["access_key_id"] = self.access_key_id
            con_params["secret_access_key"] = (
                self.secret_access_key.get_secret_value() if self.secret_access_key else None
            )
            con_params["session_token"] = self.session_token
            con_params["region"] = self.region
        elif self.authentication_method == AuthenticationMethod.AWS_PROFILE.value:
            con_params["iam"] = True
            con_params["db_user"] = self.db_user
            con_params["profile"] = self.profile
            con_params["region"] = self.region
        return {k: v for k, v in con_params.items() if v is not None}

    def _get_connection(self, database: str | None) -> "redshift_connector.Connection":
        """Establish a connection to an Amazon Redshift cluster."""
        con = redshift_connector.connect(
            **self._get_connection_params(
                database=database if database else None,
            ),
        )
        con.autocommit = True  # see https://stackoverflow.com/q/22019154
        con.paramstyle = "pyformat"
        return con

    def _retrieve_data(
        self,
        datasource: RedshiftDataSource,
        get_row_count: bool = False,
        offset: int | None = None,
        limit: int | None = None,
    ) -> "pd.DataFrame":
        if get_row_count:
            prepared_query, prepared_query_parameters = SqlQueryHelper.prepare_count_query(
                datasource.query, datasource.parameters
            )
        else:
            prepared_query, prepared_query_parameters = SqlQueryHelper.prepare_limit_query(
                datasource.query, datasource.parameters, offset, limit
            )
        with self._get_connection(database=datasource.database).cursor() as cursor:
            cursor.execute(prepared_query, prepared_query_parameters)
            result: pd.DataFrame = cursor.fetch_dataframe()
            if result is None:
                result = pd.DataFrame()
        return result

    def get_slice(
        self,
        data_source: RedshiftDataSource,
        permissions: dict[str, Any] | None = None,
        offset: int = 0,
        limit: int | None = None,
        get_row_count: bool | None = False,
    ) -> DataSlice:
        """
        Method to retrieve a part of the data as a pandas dataframe
        and the total size filtered with permissions
        - offset is the index of the starting row
        - limit is the number of pages to retrieve
        Exemple: if offset = 5 and limit = 10 then 10 results are expected from 6th row
        """
        df: pd.DataFrame = self._retrieve_data(data_source, False, offset, limit)
        total_returned_rows = len(df) if df is not None else 0

        run_count_request = get_row_count and SqlQueryHelper.count_query_needed(data_source.query)

        if run_count_request:
            df_count: pd.DataFrame = self._retrieve_data(data_source, True)
            total_rows = df_count.total_rows[0] if df_count is not None and len(df_count.total_rows) > 0 else 0
        else:
            total_rows = total_returned_rows

        return DataSlice(
            df,
            pagination_info=build_pagination_info(
                offset=offset,
                limit=limit,
                total_rows=total_rows,
                retrieved_rows=total_returned_rows,
            ),
        )

    @staticmethod
    def _get_details(index: int, status: bool):
        checks = [
            "Hostname resolved",
            "Port opened",
            "Authenticated",
            "Default Database connection",
        ]
        ok_checks = [(c, True) for i, c in enumerate(checks) if i < index]
        new_check = (checks[index], status)
        not_validated_checks = [(c, False) for i, c in enumerate(checks) if i > index]
        return ok_checks + [new_check] + not_validated_checks

    def get_status(self) -> ConnectorStatus:
        # Check hostname
        try:
            self.check_hostname(self.host)
        except Exception as e:
            return ConnectorStatus(status=False, details=self._get_details(0, False), error=str(e))
        # Check port
        try:
            self.check_port(self.host, self.port)
        except Exception as e:
            return ConnectorStatus(status=False, details=self._get_details(1, False), error=str(e))

        # Basic db query
        try:
            redshift_connector.connect(
                **self._get_connection_params(database=self.default_database),
            )
        except (Exception, redshift_connector.OperationalError) as e:
            return ConnectorStatus(status=False, details=self._get_details(3, False), error=str(e))

        return ConnectorStatus(status=True, details=self._get_details(3, True), error=None)

    def describe(self, data_source: RedshiftDataSource) -> dict[str, Any]:
        with self._get_connection(database=data_source.database).cursor() as cursor:
            cursor.execute(DESCRIBE_QUERY.format(column=data_source.query.replace(";", "")))
            res = cursor.description
        return {col[0].decode("utf-8") if isinstance(col[0], bytes) else col[0]: types_map.get(col[1]) for col in res}

    def _list_tables_info(
        self, *, database_name: str, schema_name: str | None, table_name: str | None, exclude_columns: bool
    ) -> list[Any]:
        with self._get_connection(database=database_name).cursor() as cursor:
            query = build_database_model_extraction_query(
                db_name=database_name, schema_name=schema_name, table_name=table_name
            )

            results = cursor.execute(query).fetchall()
            sanitized_results = [
                (r[0].rstrip(), r[1].rstrip(), r[2].rstrip(), r[3].rstrip(), json.loads(r[4])) for r in results
            ]
            return sanitized_results

    def get_model(
        self,
        db_name: str | None = None,
        schema_name: str | None = None,
        table_name: str | None = None,
        exclude_columns: bool = False,
    ) -> list[TableInfo]:
        """Retrieves the database tree structure using current connection"""
        available_dbs = self._list_db_names() if db_name is None else [db_name]
        databases_tree: list[TableInfo] = []
        for db in available_dbs:
            try:
                databases_tree += self._list_tables_info(
                    database_name=db, schema_name=schema_name, table_name=table_name, exclude_columns=exclude_columns
                )
            except (redshift_connector.OperationalError, redshift_connector.ProgrammingError) as exc:
                _LOGGER.warning(f"An error occured when retrieving table info for database {db}: {exc}", exc_info=exc)
        return DiscoverableConnector.format_db_model(databases_tree)

    def get_model_with_info(
        self,
        db_name: str | None = None,
        schema_name: str | None = None,
        table_name: str | None = None,
        exclude_columns: bool = False,
    ) -> tuple[list[TableInfo], dict]:
        """Retrieves the database tree structure using current connection"""
        available_dbs = self._list_db_names() if db_name is None else [db_name]
        databases_tree: list[tuple] = []
        failed_databases = []
        for db in available_dbs:
            try:
                databases_tree += self._list_tables_info(
                    database_name=db, schema_name=schema_name, table_name=table_name, exclude_columns=exclude_columns
                )
            except (redshift_connector.OperationalError, redshift_connector.ProgrammingError):
                failed_databases.append(db)

        tables_info = DiscoverableConnector.format_db_model(databases_tree)
        metadata = {}
        if failed_databases:
            metadata["info"] = {"Could not reach databases": failed_databases}
        return (tables_info, metadata)

    def _list_db_names(self) -> list[str]:
        with self._get_connection(database=self.default_database).cursor() as cursor:
            # redshift has a weird system db called padb_harvest duplicating the content of 'dev' database
            cursor.execute(
                """select datname from pg_database where datistemplate = false AND datname NOT IN """
                """('padb_harvest', 'awsdatacatalog', 'sys:internal');"""
            )
            return [db_name for (db_name,) in cursor.fetchall()]
