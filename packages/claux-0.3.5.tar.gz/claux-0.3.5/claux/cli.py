"""
Main CLI entry point for Claux.

Token-efficient AI automation toolkit with TOON inter-agent communication.
"""

import os
import sys
import typer

from claux import __version__
from claux.commands import (
    agents,
    mcp,
    init,
    status,
    backup,
    wizard,
    lang,
    interactive,
    doctor,
    upgrade,
    stats,
)
from claux.i18n import t, get_language
from claux.core.updater import (
    check_for_updates,
    background_auto_update,
    check_needs_restart,
    restart_claux,
    clear_restart_flag,
)

# Fix Windows console encoding for UTF-8 support
if os.name == "nt":
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)  # UTF-8
    except Exception:
        pass

# Ensure Python's stdout uses UTF-8 encoding
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


# Create main app
app = typer.Typer(
    name="claux",
    help="Claux - Token-efficient AI automation with TOON protocol",
    no_args_is_help=False,  # Allow interactive mode
    invoke_without_command=True,
)


# Register subcommands
app.add_typer(agents.app, name="agents")
app.add_typer(mcp.app, name="mcp")
app.add_typer(init.app, name="init")
app.add_typer(status.app, name="status")
app.add_typer(backup.app, name="backup")
app.add_typer(wizard.app, name="wizard")
app.add_typer(lang.app, name="lang")
app.add_typer(interactive.app, name="menu")
app.add_typer(doctor.app, name="doctor")
app.add_typer(upgrade.app, name="upgrade")
app.add_typer(stats.app, name="stats")


@app.callback()
def main(ctx: typer.Context):
    """
    Claux - Token-efficient AI automation with TOON protocol.

    Run without arguments to launch interactive mode.
    Use --help to see available commands.
    """
    # Check if restart is needed after background update
    needs_restart, new_version = check_needs_restart()
    if needs_restart:
        from rich.console import Console

        console = Console()

        console.print(f"\n[green]✨ {t('cli.upgrade.auto_update_success')}[/green]")
        console.print(f"[green]   Version: {new_version}[/green]\n")

        if typer.confirm(t("cli.upgrade.restart_confirm"), default=True):
            console.print(f"[cyan]{t('cli.upgrade.restarting')}[/cyan]")
            clear_restart_flag()
            restart_claux()
        else:
            console.print(f"\n[yellow]{t('cli.upgrade.restart_later')}[/yellow]\n")
            clear_restart_flag()

    # Trigger auto-update if enabled
    from claux.core.user_config import get_config

    config = get_config()

    if config.get("updates.auto_update", False):
        background_auto_update()
    else:
        # Silent check for updates (current behavior)
        _check_for_updates_silently()

    # If no subcommand is invoked, launch interactive mode
    if ctx.invoked_subcommand is None:
        from claux.commands.interactive import menu

        menu()


def _check_for_updates_silently():
    """
    Check for updates silently and show notification if available.
    Uses cache to avoid checking more than once per day.
    """
    try:
        has_update, latest_version, _ = check_for_updates(use_cache=True)

        if has_update and latest_version:
            # Show subtle notification
            typer.echo(f"\n💡 {t('cli.upgrade.notification', version=latest_version)}")
            typer.echo(f"   {t('cli.upgrade.notification_hint')}\n")
    except Exception:
        # Silently ignore any errors during update check
        pass


@app.command()
def version():
    """Show version information."""
    typer.echo(t("cli.version.title", version=__version__))
    typer.echo(
        t(
            "cli.version.python",
            python_version=f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        )
    )
    typer.echo(t("cli.version.location", location=__file__))
    typer.echo(f"\nLanguage: {get_language()}")


if __name__ == "__main__":
    app()
