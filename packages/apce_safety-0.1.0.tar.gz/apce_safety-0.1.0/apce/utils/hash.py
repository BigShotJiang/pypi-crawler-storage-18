"""Hash utilities."""
from ..core import compute_hash

