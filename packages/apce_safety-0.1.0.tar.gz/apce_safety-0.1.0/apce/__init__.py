"""
APCE - Attention Provenance & Conservation Engine
==================================================

Runtime verification for transformer models using conservation laws.

Quick Start:
    from apce import APCEVerifier, verify
    from apce.wrappers import ClaudeWrapper, GPTWrapper, LlamaWrapper
    from apce.compliance import Watermarker
    
    # Verify attention weights directly
    result = verify(attention_matrix)
    print(f"Valid: {result.is_valid}")
    
    # Wrap API models with verification
    claude = ClaudeWrapper(api_key="...")
    response = claude.chat([{"role": "user", "content": "Hello"}])
    print(response.provenance.merkle_root)
    
    # Full verification with local models
    llama = LlamaWrapper(model_name="meta-llama/Llama-2-7b-chat-hf")
    result = llama.chat([{"role": "user", "content": "Hello"}])
    print(f"Conservation valid: {result.analysis.is_valid}")
    
    # EU AI Act watermarking
    wm = Watermarker(model_id="gpt-4")
    marked = wm.watermark_text("AI response...")

License: Apache 2.0
Author: Rafael Velado (raf@atomic-trust.com)
Website: https://atomic-trust.com
"""

__version__ = "0.1.0"
__author__ = "Rafael Velado"
__email__ = "raf@atomic-trust.com"

from .core import (
    # Main classes
    APCEVerifier,
    VerificationMode,
    ManifoldAnalysis,
    ProvenanceBundle,
    ConservationSignal,
    SecurityViolation,
    
    # Convenience functions
    verify,
    is_valid,
    compute_hash,
    
    # Constants
    KAPPA,
    DETECTION_THRESHOLD,
)

# Wrapper base (for subclassing)
from .wrappers.base import APCEWrapper, VerifiedResponse

__all__ = [
    # Version
    "__version__",
    
    # Core verification
    "APCEVerifier",
    "VerificationMode",
    "ManifoldAnalysis",
    "ProvenanceBundle",
    "ConservationSignal",
    "SecurityViolation",
    
    # Base wrapper
    "APCEWrapper",
    "VerifiedResponse",
    
    # Functions
    "verify",
    "is_valid",
    "compute_hash",
    
    # Constants
    "KAPPA",
    "DETECTION_THRESHOLD",
]
