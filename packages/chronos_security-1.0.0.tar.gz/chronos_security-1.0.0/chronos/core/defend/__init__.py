"""
CHRONOS Defend Module
====================

AST-based cryptographic code scanning and analysis with automated migration planning.
Post-quantum cryptography migration engine with liboqs integration.
Quantum-secure data vault with hybrid encryption and geographic distribution.
"""

from chronos.core.defend.code_scanner import (
    CodeScanner,
    CryptoAlgorithm,
    RiskLevel,
    MigrationSuggestion,
    CodeLocation,
    CryptoUsage,
    Dependency,
    MigrationPlan as CodeScannerMigrationPlan,
    ScanResult,
    DependencyNode,
    CryptoPatternDetector,
    analyze_project,
)

from chronos.core.defend.pqc_migrator import (
    PQCAlgorithm,
    ClassicalAlgorithm,
    MigrationMode,
    MigrationStatus,
    PerformanceMetric,
    KeyPair,
    PerformanceBenchmark,
    MigrationSnapshot,
    MigrationPlan as PQCMigrationPlan,
    KyberMigrator,
    DilithiumMigrator,
    HybridMigrator,
    MigrationRollback,
    PQCMigrator,
    analyze_migration_feasibility,
)

from chronos.core.defend.quantum_vault import (
    # Main Classes
    QuantumVault,
    HybridEncryption,
    ShamirSecretSharing,
    TimeLockCryptography,
    CloudShardDistribution,
    AlgorithmAgility,
    VaultAuditingSystem,
    # Enums
    VaultAlgorithm,
    CloudProvider,
    VaultOperationType,
    VaultStatus,
    IntegrityStatus,
    # Data Classes
    KeyPair as VaultKeyPair,
    ShamirShard,
    TimeLock,
    VaultAuditLog,
    EncryptedData,
    VaultMetrics,
    # Utility Functions
    create_vault,
    analyze_vault_security,
)

__all__ = [
    # Code Scanner
    "CodeScanner",
    "CryptoAlgorithm",
    "RiskLevel",
    "MigrationSuggestion",
    "CodeLocation",
    "CryptoUsage",
    "Dependency",
    "CodeScannerMigrationPlan",
    "ScanResult",
    "DependencyNode",
    "CryptoPatternDetector",
    "analyze_project",
    # PQC Migrator
    "PQCAlgorithm",
    "ClassicalAlgorithm",
    "MigrationMode",
    "MigrationStatus",
    "PerformanceMetric",
    "KeyPair",
    "PerformanceBenchmark",
    "MigrationSnapshot",
    "PQCMigrationPlan",
    "KyberMigrator",
    "DilithiumMigrator",
    "HybridMigrator",
    "MigrationRollback",
    "PQCMigrator",
    "analyze_migration_feasibility",
    # Quantum Vault - Main Classes
    "QuantumVault",
    "HybridEncryption",
    "ShamirSecretSharing",
    "TimeLockCryptography",
    "CloudShardDistribution",
    "AlgorithmAgility",
    "VaultAuditingSystem",
    # Quantum Vault - Enums
    "VaultAlgorithm",
    "CloudProvider",
    "VaultOperationType",
    "VaultStatus",
    "IntegrityStatus",
    # Quantum Vault - Data Classes
    "VaultKeyPair",
    "ShamirShard",
    "TimeLock",
    "VaultAuditLog",
    "EncryptedData",
    "VaultMetrics",
    # Quantum Vault - Utilities
    "create_vault",
    "analyze_vault_security",
]
