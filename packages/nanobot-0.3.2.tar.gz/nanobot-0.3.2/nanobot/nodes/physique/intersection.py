"""
IntersectionNode - Turn at intersections

Priority 2: Explore side passages.

If a side sees significantly more space than front, turn toward it.
"""

from typing import Optional
from ...core.node import Node, Decision, Action
from ...core.sensors import SensorData
from ...config import RobotConfig


# Threshold for "blocked"
BLOCKED = RobotConfig.PASSAGE_THRESHOLD  # ~0.69m

# Ratio to detect intersection (side must see this much more than front)
INTERSECTION_RATIO = 1.4


class IntersectionNode(Node):
    """
    Turn at intersections.

    Detection: front >= BLOCKED AND side >= front * INTERSECTION_RATIO
    Action: TURN toward side passage until front >= BLOCKED
    """

    def __init__(self):
        super().__init__("INTERSECTION", priority=2)
        self.state = "IDLE"  # IDLE, TURNING
        self.turn_direction = None
        self.tick_count = 0

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        front = sensors.front or 1.0
        left = sensors.left or 0.5
        right = sensors.right or 0.5
        left_front = sensors.left_front or left
        right_front = sensors.right_front or right

        # === Continue turning ===
        if self.state == "TURNING":
            self.tick_count += 1

            # Minimum 4 ticks before checking if front is clear
            # (need to actually turn before stopping)
            min_done = self.tick_count >= 4
            front_clear = front >= BLOCKED
            timeout = self.tick_count >= 20

            if timeout or (min_done and front_clear):
                self.state = "IDLE"
                self.tick_count = 0
                self.turn_direction = None
                return None  # Let other nodes decide

            dir_name = "L" if self.turn_direction == Action.TURN_LEFT else "R"
            return Decision(
                action=self.turn_direction,
                speed=0.5,
                reason=f"INTER_{dir_name} {self.tick_count}/20 L={left:.1f} LF={left_front:.1f} F={front:.1f} RF={right_front:.1f} R={right:.1f}",
                score=85
            )

        # === Only check if front is clear (WallNode handles blocked front) ===
        if front < BLOCKED:
            return None

        # === Check for intersection ===
        max_left = max(left, left_front)
        max_right = max(right, right_front)
        side_max = max(max_left, max_right)

        # Not an intersection if side doesn't see much more than front
        if side_max < front * INTERSECTION_RATIO:
            return None

        # === Turn toward the better side ===
        if max_left >= max_right:
            self.turn_direction = Action.TURN_LEFT
        else:
            self.turn_direction = Action.TURN_RIGHT

        self.state = "TURNING"
        self.tick_count = 0

        dir_name = "L" if self.turn_direction == Action.TURN_LEFT else "R"
        return Decision(
            action=self.turn_direction,
            speed=0.5,
            reason=f"INTER_{dir_name} L={left:.1f} LF={left_front:.1f} F={front:.1f} RF={right_front:.1f} R={right:.1f}",
            score=85
        )

    def reset(self):
        self.state = "IDLE"
        self.turn_direction = None
        self.tick_count = 0
