"""
ForwardNode - Default forward movement

Priority 3: Lowest priority - default behavior.

If nothing else triggers, go forward with speed adapted to distance.
"""

from typing import Optional
from ...core.node import Node, Decision, Action
from ...core.sensors import SensorData


class ForwardNode(Node):
    """
    Default forward movement.

    Always returns FORWARD with speed based on front distance:
    - front > 1.5m: speed 1.0 (fast)
    - front > 1.0m: speed 0.7 (normal)
    - front <= 1.0m: speed 0.5 (slow)
    """

    def __init__(self):
        super().__init__("FORWARD", priority=3)

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        front = sensors.front or 1.0
        left = sensors.left or 0.5
        right = sensors.right or 0.5
        left_front = sensors.left_front or left
        right_front = sensors.right_front or right

        # Speed based on front distance
        if front > 1.5:
            speed = 1.0
        elif front > 1.0:
            speed = 0.7
        else:
            speed = 0.5

        return Decision(
            action=Action.FORWARD,
            speed=speed,
            reason=f"FWD L={left:.1f} LF={left_front:.1f} F={front:.1f} RF={right_front:.1f} R={right:.1f}",
            score=50
        )

    def reset(self):
        pass
