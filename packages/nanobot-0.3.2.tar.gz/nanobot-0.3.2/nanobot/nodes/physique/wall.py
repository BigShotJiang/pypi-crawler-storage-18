"""
WallNode - Turn when wall ahead

Priority 1: React to obstacles.

If front is blocked, turn toward the sensor with most space.
"""

from typing import Optional
from ...core.node import Node, Decision, Action
from ...core.sensors import SensorData
from ...config import RobotConfig


# Threshold for "blocked"
BLOCKED = RobotConfig.PASSAGE_THRESHOLD  # ~0.69m


class WallNode(Node):
    """
    Turn when wall ahead.

    Detection: front < BLOCKED
    Action: TURN toward max sensor until front >= BLOCKED
    """

    def __init__(self):
        super().__init__("WALL", priority=1)
        self.state = "IDLE"  # IDLE, TURNING
        self.turn_direction = None
        self.tick_count = 0

    def evaluate(self, sensors: SensorData) -> Optional[Decision]:
        if not sensors.is_valid():
            return None

        front = sensors.front or 1.0
        left = sensors.left or 0.5
        right = sensors.right or 0.5
        left_front = sensors.left_front or left
        right_front = sensors.right_front or right

        # === Continue turning ===
        if self.state == "TURNING":
            self.tick_count += 1
            front_clear = front >= BLOCKED
            timeout = self.tick_count >= 20

            if front_clear or timeout:
                self.state = "IDLE"
                self.tick_count = 0
                self.turn_direction = None
                return None  # Let other nodes decide

            dir_name = "L" if self.turn_direction == Action.TURN_LEFT else "R"
            return Decision(
                action=self.turn_direction,
                speed=0.5,
                reason=f"TURN_{dir_name} {self.tick_count}/20 L={left:.1f} LF={left_front:.1f} F={front:.1f} RF={right_front:.1f} R={right:.1f}",
                score=90
            )

        # === Only activate if front is blocked ===
        if front >= BLOCKED:
            return None

        # === Find direction with most space ===
        sensor_values = {
            "left": left,
            "left_front": left_front,
            "right_front": right_front,
            "right": right,
        }
        max_sensor = max(sensor_values, key=sensor_values.get)

        # Turn toward the best side
        if max_sensor in ["left", "left_front"]:
            self.turn_direction = Action.TURN_LEFT
        else:
            self.turn_direction = Action.TURN_RIGHT

        self.state = "TURNING"
        self.tick_count = 0

        dir_name = "L" if self.turn_direction == Action.TURN_LEFT else "R"
        return Decision(
            action=self.turn_direction,
            speed=0.5,
            reason=f"WALL_{dir_name} L={left:.1f} LF={left_front:.1f} F={front:.1f} RF={right_front:.1f} R={right:.1f} -> {max_sensor}",
            score=90
        )

    def reset(self):
        self.state = "IDLE"
        self.turn_direction = None
        self.tick_count = 0
