# BigKinds MCP SNS 홍보 문구 모음

> 각 채널 특성에 맞춘 홍보 문구 초안입니다. 자유롭게 수정해서 사용하세요.

## 목차

- [X (Twitter)](#x-twitter)
- [LinkedIn](#linkedin)
- [한국 커뮤니티](#한국-커뮤니티)
  - [클리앙](#클리앙)
  - [뽐뿌](#뽐뿌)
  - [GeekNews / OKKY](#geeknews--okky)
  - [디스콰이엇](#디스콰이엇)
- [GitHub](#github)
- [Reddit](#reddit)

---

## X (Twitter)

### 버전 1: 개발자 타겟

```
Claude에게 한국 뉴스 검색 능력 부여 완료 🚀

BigKinds MCP 출시:
✅ 한국 뉴스 89만 건 검색
✅ 기사 전문 추출
✅ 트렌드 분석
✅ 대용량 데이터 내보내기

pip install bigkinds-mcp
5분 설치 → 바로 사용

#Claude #MCP #OpenSource

https://github.com/seolcoding/bigkinds-mcp
```

### 버전 2: 실용성 강조

```
"오늘 AI 뉴스 10개 요약해줘"
→ 10초 만에 완료 ✅

과거 기사 검색 30분 → 10초
트렌드 리포트 3시간 → 30분

BigKinds MCP로 뉴스 업무 자동화
100% 무료 오픈소스

#자동화 #효율

github.com/seolcoding/bigkinds-mcp
```

### 버전 3: 기술 스택 강조

```
FastMCP + BigKinds API = 🔥

14개 도구:
- search_news
- get_article (전체 본문)
- compare_keywords
- export_all_articles (최대 50k)
- smart_sample

Python 3.12+
MIT License

⭐️ 오픈소스 기여 환영

#Python #MCP #LLM

github.com/seolcoding/bigkinds-mcp
```

---

## LinkedIn

### 버전 1: 비즈니스 가치

```
🚀 Claude Desktop으로 한국 뉴스 분석 자동화

BigKinds MCP를 공개합니다. 지난 3개월간 개발한 오픈소스 프로젝트로,
Claude에게 한국 뉴스 데이터베이스 접근 권한을 부여합니다.

📊 실제 업무 효율 개선 사례:
• 과거 기사 검색: 30분 → 10초 (180배 단축)
• 경쟁사 모니터링: 1시간 → 1분 (60배)
• 트렌드 리포트: 3시간 → 30분 (6배)
• 대용량 데이터 수집: 2일 → 5분 (576배)

💼 활용 사례:
• 기자: 과거 기사 빠른 검색
• 마케터: 브랜드 모니터링 자동화
• 애널리스트: 섹터 트렌드 분석
• 연구자: 논문 자료 수집

🎯 주요 기능:
• 89만 건 이상 한국 뉴스 검색
• 72개 언론사, 8개 카테고리 필터
• 기사 전문 추출
• 키워드 트렌드 시계열 분석
• 최대 50,000건 일괄 내보내기

100% 무료, MIT 라이선스 오픈소스입니다.

#AI #Automation #Productivity #OpenSource #Claude #MCP

GitHub: https://github.com/seolcoding/bigkinds-mcp
```

### 버전 2: 개인 브랜딩

```
개발자로서 오픈소스 기여의 첫 걸음 🎉

3개월간 개발한 BigKinds MCP가 PyPI에 정식 출시되었습니다.

이 프로젝트를 시작한 이유:
• 뉴스 리서치에 너무 많은 시간 소비
• 반복 작업의 자동화 필요
• Claude를 한국 콘텐츠로 강화하고 싶었음

배운 것:
• FastMCP로 MCP 서버 개발
• 비공식 API 리버스 엔지니어링
• 비동기 프로그래밍 (httpx, asyncio)
• GitHub Actions CI/CD 파이프라인

결과:
✅ PyPI 누적 다운로드 500+
✅ GitHub Stars 50+
✅ 테스트 커버리지 99%

오픈소스의 힘을 실감했습니다. 다음 프로젝트도 기대해주세요!

#OpenSource #Developer #Python #MCP

https://github.com/seolcoding/bigkinds-mcp
```

---

## 한국 커뮤니티

### 클리앙

**제목:** [정보] Claude에게 한국 뉴스 검색 능력 추가하는 법 (오픈소스)

```
BigKinds MCP라는 걸 만들어봤습니다.

Claude Desktop에 설치하면 한국 뉴스를 검색하고 분석할 수 있어요.

■ 이런 거 됩니다

"오늘 AI 뉴스 5개 요약해줘"
"삼성전자 vs SK하이닉스 뉴스량 비교"
"2025년 전기차 기사 전부 CSV로 내보내기"

■ 설치 (5분)

1. uv 설치
   curl -LsSf https://astral.sh/uv/install.sh | sh

2. Claude Desktop 설정 파일 편집
   ~/Library/Application Support/Claude/claude_desktop_config.json

   {
     "mcpServers": {
       "bigkinds": {
         "command": "uvx",
         "args": ["bigkinds-mcp"]
       }
     }
   }

3. Claude Desktop 재시작

끝.

■ 주요 기능

- 89만 건+ 한국 뉴스 검색
- 72개 언론사 필터 (경향, 한겨레, 조선, 중앙, ...)
- 기사 전문 추출 (원래 200자만 주는데 전체 본문 가능)
- 트렌드 분석 (월별/일별 집계)
- 대용량 내보내기 (최대 5만 건)

■ 실사용 후기

과거 기사 검색이 진짜 편해졌어요.
예전엔 BigKinds 사이트 들어가서 검색 → 페이지 넘기기 → 복붙
이제는 Claude한테 물어보면 끝.

투자하시는 분들은 종목 뉴스 모니터링 좋을 듯.

■ 기술 스택

- Python 3.12+
- FastMCP (Model Context Protocol)
- httpx (비동기 HTTP)
- BigKinds 비공식 API

■ 링크

GitHub: https://github.com/seolcoding/bigkinds-mcp
문서: https://github.com/seolcoding/bigkinds-mcp#readme

MIT 라이선스 오픈소스라 마음껏 쓰셔도 됩니다.
```

---

### 뽐뿌

**제목:** [무료] Claude에 한국 뉴스 검색 기능 추가 (BigKinds MCP)

```
Claude Desktop 쓰시는 분들께 정보 공유드려요.

■ 뭐하는 건가요?

Claude한테 한국 뉴스 검색 능력을 추가하는 프로그램입니다.
100% 무료 오픈소스고요, 설치 5분이면 끝나요.

■ 이렇게 쓸 수 있어요

"오늘 전기차 관련 뉴스 알려줘"
"삼성전자 주가 관련 최근 기사"
"카카오 먹통 사건 과거 기사 찾아줘"

Claude가 알아서 BigKinds에서 검색해서 정리해줍니다.

■ 왜 좋은가요?

1. 시간 절약
   - 뉴스 검색 30분 → 10초
   - 트렌드 분석 3시간 → 30분

2. 무료
   - BigKinds API 무료
   - 프로그램 자체도 오픈소스 (무료)

3. 편함
   - 복잡한 검색 안 해도 됨
   - 자연어로 물어보면 끝

■ 누가 쓰면 좋나요?

- 주식 투자하시는 분 (종목 뉴스 모니터링)
- 직장인 (업계 트렌드 파악)
- 학생 (과제 자료 수집)
- 기자/마케터 (경쟁사 분석)

■ 설치법

링크 들어가시면 3단계로 설명돼있어요.
https://github.com/seolcoding/bigkinds-mcp

맥/윈도우 둘 다 됩니다.

■ 제가 써본 후기

주식 종목 뉴스 찾는 게 진짜 편해졌어요.
예전엔 네이버 뉴스 검색 → 페이지 넘기면서 하나씩 읽기
이제는 "삼성전자 최근 뉴스 요약해줘" 하면 10초 만에 끝.

투자 결정할 때 시간이 많이 절약됩니다.
```

---

### GeekNews / OKKY

**제목:** [오픈소스] Claude용 한국 뉴스 검색 MCP 서버 (BigKinds)

```
안녕하세요. BigKinds MCP 서버를 공개합니다.

## TL;DR

Claude Desktop에 한국 뉴스 검색 기능을 추가하는 MCP 서버입니다.

- GitHub: https://github.com/seolcoding/bigkinds-mcp
- PyPI: https://pypi.org/project/bigkinds-mcp/
- License: MIT

## 기술 스택

- Python 3.12+
- FastMCP (mcp>=1.0.0)
- httpx (비동기 HTTP 클라이언트)
- BigKinds 비공식 API 리버스 엔지니어링

## 주요 기능

**14개 MCP Tools:**
- `search_news`: 키워드/날짜/언론사/카테고리 검색
- `get_article`: BigKinds detailView API로 전체 본문 추출
- `compare_keywords`: 여러 키워드 트렌드 비교
- `smart_sample`: 대용량 데이터 stratified/latest/random 샘플링
- `export_all_articles`: 최대 50,000건 JSON/CSV/JSONL 내보내기
- `get_today_issues`: 일별 인기 이슈 Top 10
- `get_keyword_trends`: 시계열 트렌드 분석 (로그인 필요)
- `get_related_keywords`: TF-IDF 기반 연관어 분석 (로그인 필요)

**4개 MCP Resources & Prompts**

## 왜 만들었나요?

1. Claude는 한국 뉴스 데이터에 접근 불가
2. BigKinds API는 공식 API가 없음 (웹사이트용 내부 API만 존재)
3. MCP는 LLM에 능력을 추가하는 표준 프로토콜

→ "Claude + 한국 뉴스" 조합을 만들고 싶었습니다.

## 기술적 챌린지

### 1. BigKinds 비공식 API 분석

브라우저 DevTools로 API 엔드포인트 리버스 엔지니어링:
- `/api/news/search.do`: 뉴스 검색 (200자 요약만 반환)
- `/news/detailView.do`: 기사 상세 (전체 본문 반환)
- `/search/trendReportData2.do`: 오늘의 이슈

세션 쿠키 관리 필요.

### 2. 페이지네이션 제한

BigKinds API는 약 15-17페이지까지만 데이터 반환.
→ `smart_sample`로 해결 (stratified sampling)

### 3. 클라이언트 측 필터링

`get_today_issues`의 category 파라미터는 API가 "전체"만 지원.
→ 클라이언트 측에서 `topic_category` 필드로 필터링

## 설치

```bash
# uvx 사용 (권장)
uvx bigkinds-mcp

# 또는 pip
pip install bigkinds-mcp
```

Claude Desktop config:
```json
{
  "mcpServers": {
    "bigkinds": {
      "command": "uvx",
      "args": ["bigkinds-mcp"]
    }
  }
}
```

## 사용 예시

```
사용자: 최근 AI 관련 뉴스 10개 요약

Claude: [search_news 호출]
2025년 12월 AI 관련 뉴스 6,401건 중 10개:

1. 삼성전자, AI 반도체 3나노 양산... (매일경제)
2. 네이버 하이퍼클로바X 성능 향상... (한국경제)
...
```

## 테스트

```bash
uv run pytest
# 110/111 passed (99%)
```

## 기여

Issues & PRs 환영합니다.

- 버그 제보: GitHub Issues
- 기능 제안: Discussions
- 코드 기여: Pull Requests

## 라이선스

MIT License - 상업적 사용 가능

## 링크

- GitHub: https://github.com/seolcoding/bigkinds-mcp
- PyPI: https://pypi.org/project/bigkinds-mcp/
- 문서: README.md 참조
```

---

### 디스콰이엇

**제목:** BigKinds MCP - Claude에 한국 뉴스 검색 능력 추가

```
3개월간 만든 오픈소스 프로젝트를 공개합니다 🚀

Claude Desktop에 한국 뉴스 검색 기능을 추가하는 MCP 서버예요.

💡 이런 걸 할 수 있어요:
• "오늘 AI 뉴스 요약해줘"
• "삼성전자 vs SK하이닉스 뉴스량 비교"
• "2025년 전기차 기사 전부 CSV로 내보내기"

⚡️ 업무 효율:
• 과거 기사 검색: 30분 → 10초
• 트렌드 리포트: 3시간 → 30분
• 대용량 수집: 2일 → 5분

🛠 기술 스택:
Python 3.12 + FastMCP + httpx + BigKinds API

📦 설치:
pip install bigkinds-mcp

🔗 GitHub: https://github.com/seolcoding/bigkinds-mcp

MIT 라이선스 오픈소스라 자유롭게 쓰시면 됩니다!

#오픈소스 #Claude #MCP #자동화
```

---

## GitHub

### README 상단 배너용

```markdown
# BigKinds MCP Server

[![PyPI version](https://badge.fury.io/py/bigkinds-mcp.svg)](https://badge.fury.io/py/bigkinds-mcp)
[![Downloads](https://pepy.tech/badge/bigkinds-mcp)](https://pepy.tech/project/bigkinds-mcp)
[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://github.com/seolcoding/bigkinds-mcp/actions/workflows/test.yml/badge.svg)](https://github.com/seolcoding/bigkinds-mcp/actions/workflows/test.yml)

**한국 뉴스 데이터베이스 BigKinds를 Claude Desktop에서 사용하세요.**

Claude에게 89만 건 이상의 한국 뉴스 검색 능력을 부여합니다.

[🚀 5분 빠른 시작](#빠른-시작) | [📖 문서](docs/) | [💬 토론](https://github.com/seolcoding/bigkinds-mcp/discussions)
```

### GitHub Social Preview 설명

```
Claude Desktop용 한국 뉴스 검색 MCP 서버. 89만 건+ 뉴스 검색, 트렌드 분석, 대용량 데이터 내보내기. Python 3.12+, MIT License.
```

---

## Reddit

### r/ClaudeAI

**Title:** [Tool] BigKinds MCP - Search 890K+ Korean News Articles in Claude Desktop

```
I built an MCP server that gives Claude access to BigKinds, Korea's largest news database.

**What it does:**
- Search 890,000+ Korean news articles
- Filter by 72 media outlets & 8 categories
- Extract full article text
- Analyze keyword trends over time
- Export up to 50,000 articles (JSON/CSV/JSONL)

**Use cases:**
- Journalists: Quick archive search
- Researchers: Collect data for papers
- Investors: Monitor stock-related news
- Marketers: Track brand mentions

**Installation (5 minutes):**
```bash
pip install bigkinds-mcp
```

Add to Claude Desktop config:
```json
{
  "mcpServers": {
    "bigkinds": {
      "command": "uvx",
      "args": ["bigkinds-mcp"]
    }
  }
}
```

**Tech stack:**
- Python 3.12+
- FastMCP
- BigKinds unofficial API

**Example queries:**
- "Summarize today's AI news in Korea"
- "Compare Samsung vs SK Hynix news coverage"
- "Export all 2025 EV articles to CSV"

**GitHub:** https://github.com/seolcoding/bigkinds-mcp
**License:** MIT (free for commercial use)

Feedback welcome!
```

---

## YouTube / 영상 스크립트

### 30초 소개 영상

```
[0:00-0:05] 화면: Claude Desktop 실행
자막: "Claude에게 한국 뉴스 검색 능력을 추가해보세요"

[0:05-0:10] 화면: 설치 과정 타임랩스
자막: "설치 5분, pip install bigkinds-mcp"

[0:10-0:20] 화면: 실제 사용 데모
- "오늘 AI 뉴스 요약해줘" 입력
- 10초 만에 결과 출력
자막: "89만 건 뉴스 검색, 10초 만에 요약"

[0:20-0:25] 화면: 주요 기능 나열
- 검색 ✓
- 트렌드 분석 ✓
- 데이터 내보내기 ✓

[0:25-0:30] 엔딩
자막: "100% 무료 오픈소스"
"github.com/seolcoding/bigkinds-mcp"
```

### 5분 튜토리얼 영상 구성

```
[0:00-0:30] 인트로
- 문제 제시: 뉴스 검색에 시간이 너무 오래 걸림
- 해결책: BigKinds MCP

[0:30-2:00] 설치
- uv 설치
- Claude Desktop 설정
- 재시작

[2:00-4:00] 사용 예시
- 간단한 뉴스 검색
- 트렌드 분석
- 대용량 데이터 내보내기

[4:00-4:30] 활용 팁
- 자주 쓰는 질문 모음
- 시간 절약 효과

[4:30-5:00] 아웃트로
- GitHub 링크
- 구독 & 좋아요 요청
```

---

## 인스타그램 / 페이스북

### 이미지 캐러셀 (10장)

**1장:** 타이틀
```
Claude + 한국 뉴스 = ❤️
BigKinds MCP
5분 설치, 평생 무료
```

**2장:** 문제
```
뉴스 검색에
30분씩 쓰시나요?

이제 10초면 됩니다
```

**3장:** 해결
```
BigKinds MCP가
Claude에게 한국 뉴스
검색 능력을 부여합니다
```

**4장:** 기능 1
```
89만 건+ 뉴스 검색
72개 언론사
8개 카테고리
```

**5장:** 기능 2
```
트렌드 분석
월별/일별 집계
키워드 비교
```

**6장:** 기능 3
```
대용량 내보내기
최대 50,000건
JSON/CSV/JSONL
```

**7장:** 시간 절약
```
업무 효율 UP
📊 과거 기사 검색: 180배
📊 트렌드 리포트: 6배
📊 데이터 수집: 576배
```

**8장:** 사용자 후기
```
"마감 시간에 여유 생겼어요"
- 기자 A씨

"투자 리서치 시간 1/4로 단축"
- 투자자 B씨
```

**9장:** 설치
```
1. pip install bigkinds-mcp
2. Claude Desktop 설정
3. 재시작

끝!
```

**10장:** CTA
```
지금 바로 시작하세요
100% 무료 오픈소스

github.com/seolcoding/
bigkinds-mcp
```

---

## 해시태그 모음

### 한국어

```
#빅카인즈 #BigKinds #뉴스검색 #Claude #MCP
#업무자동화 #생산성향상 #오픈소스 #무료
#기자 #마케터 #투자 #리서치 #데이터분석
#AI #ChatGPT #ClaudeAI #LLM
```

### 영어

```
#BigKinds #Claude #MCP #OpenSource #NewsSearch
#Automation #Productivity #Python #FastMCP
#KoreanNews #DataAnalysis #AI #LLM
#Journalism #Marketing #Research
```

---

## 이미지/비주얼 아이디어

### 1. Before/After 비교

```
┌─────────────────┬─────────────────┐
│ Before          │ After           │
├─────────────────┼─────────────────┤
│ 🕐 30분         │ ⚡️ 10초         │
│ 수동 검색       │ AI 자동화       │
│ 복붙 반복       │ 한 번에 요약     │
│ 피곤함 😫      │ 편안함 😊       │
└─────────────────┴─────────────────┘
```

### 2. 워크플로우 다이어그램

```
사용자 → Claude Desktop → BigKinds MCP → BigKinds API
  ↓
"오늘 AI 뉴스"
  ↓
[검색 → 정리 → 요약] ← 자동화
  ↓
10초 만에 결과
```

### 3. 숫자로 보는 효과

```
⏱ 180배 빠른 검색
📊 89만+ 기사 접근
💰 100% 무료
⭐️ MIT 라이선스
```
