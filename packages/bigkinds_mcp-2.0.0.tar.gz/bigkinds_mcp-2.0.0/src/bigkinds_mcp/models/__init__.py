"""MCP Models and Schemas."""
