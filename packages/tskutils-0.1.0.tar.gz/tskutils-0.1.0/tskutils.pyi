from tskit import TreeSequence
from numpy.typing import NDArray
from numpy import uint32

class RvIbdAnalyzer:
    def __init__(self, ts: TreeSequence) -> 'RvIbdAnalyzer': ...

    def calc_rv_sharing(self, max_freq: int)-> NDArray[uint32]: ...

    def calc_ibd_sharing(self, max_time: float)-> NDArray[uint32]: ...
