use ndarray::Array2;
use std::mem::swap;
use tskit::prelude::StreamingIterator;
use tskit::{TreeFlags, TreeSequence, TskitError};

pub(crate) fn get_rv_sharing_matrix(
    ts: &TreeSequence,
    max_freq: usize,
) -> Result<Array2<u32>, TskitError> {
    let nsam = ts.num_samples().as_usize();
    let mut mat: Array2<u32> = Array2::zeros((nsam, nsam));

    let mut tree_iter = ts.tree_iterator(TreeFlags::default().sample_lists())?;

    let mut samples_with_variant = vec![];

    // NOTE: the mutation table of treesequnce is sorted by site ID (i.e. by positiion)
    for mutation in ts.mutations().iter() {
        samples_with_variant.clear();
        if let Some(tree) = tree_iter.next() {
            for sample in tree.samples(mutation.node)? {
                samples_with_variant.push(sample.as_usize());
                if samples_with_variant.len() > max_freq {
                    break;
                }
            }
        } else {
            break;
        }
        for i in 1..samples_with_variant.len() {
            for j in 0..i {
                let mut ii = samples_with_variant[i];
                let mut jj = samples_with_variant[j];
                if ii < jj {
                    swap(&mut ii, &mut jj);
                }
                mat[(ii, jj)] += 1;
            }
        }
    }
    Ok(mat)
}
