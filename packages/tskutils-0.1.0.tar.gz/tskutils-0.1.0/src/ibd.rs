use std::mem::swap;

use ndarray::Array2;
use tskit::bindings as bd;
use tskit::{self, TreeSequence};

#[derive(Copy, Clone)]
struct SampleNodeAncSeg {
    left: u32,
    right: u32,
    sample_node: usize,
}

pub(crate) fn get_ibd_sharing_matrix(ts: &TreeSequence, max_time: f64) -> Array2<u32> {
    let nsam = ts.num_samples().as_usize();
    let nnodes = ts.nodes().num_rows().as_usize();
    let mut mat = Array2::<u32>::zeros((nsam, nsam));

    let seqlen = unsafe { bd::tsk_treeseq_get_sequence_length(ts.as_ptr()) as u32 };

    let mut anc_map: Vec<Vec<SampleNodeAncSeg>> = (0..nnodes)
        .filter(|node_id| {
            ts.nodes().time(*node_id as i32).unwrap_or(f64::MAX.into()) < max_time as f64
        })
        .map(|n| {
            if n < nsam {
                vec![SampleNodeAncSeg {
                    left: 0,
                    right: seqlen,
                    sample_node: n,
                }]
            } else {
                vec![]
            }
        })
        .collect();

    let mut queue: Vec<SampleNodeAncSeg> = vec![];

    // edges (p, c, left, right) are sorted
    // - Sort by parent's time first, then child and then left
    for edge in ts.edges().iter() {
        let child = edge.child.as_usize();
        let parent = edge.parent.as_usize();
        let left = f64::from(edge.left) as u32;
        let right = f64::from(edge.right) as u32;

        if ts.nodes().time(parent as i32).unwrap_or(f64::MAX.into()) >= max_time {
            break;
        }

        for s in anc_map[child].iter() {
            let tmp_seg = SampleNodeAncSeg {
                left: (left).max(s.left),
                right: (right).min(s.right),
                sample_node: s.sample_node,
            };
            if tmp_seg.left < tmp_seg.right {
                queue.push(tmp_seg);
            }
        }
        for seg0 in anc_map[parent].iter() {
            for seg1 in queue.iter() {
                let ibd_left = seg0.left.max(seg1.left);
                let ibd_right = seg0.right.min(seg1.right);
                if (seg0.sample_node != seg1.sample_node) && (ibd_left < ibd_right) {
                    let mut id1 = seg0.sample_node;
                    let mut id2 = seg1.sample_node;
                    if id1 < id2 {
                        swap(&mut id1, &mut id2);
                    }
                    let ibd_length = ibd_right - ibd_left;
                    mat[(id1, id2)] += ibd_length;
                }
            }
        }

        anc_map[parent].extend_from_slice(&queue);
        queue.clear();
    }
    mat
}
