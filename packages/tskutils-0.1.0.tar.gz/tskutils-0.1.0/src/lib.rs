use pyo3::prelude::*;
mod ibd;
mod rv;

/// A Python module implemented in Rust.
#[pymodule]
mod tskutils {
    use numpy::{PyArray1, PyArray2, PyArrayMethods};
    use pyo3::{exceptions::PyValueError, prelude::*};
    use tskit::{TreeSequence, TreeSequenceFlags, prelude::*};

    use crate::{ibd::get_ibd_sharing_matrix, rv::get_rv_sharing_matrix};

    macro_rules! to_slice {
        ($x:ident) => {
            let $x = $x.readonly();
            let $x = $x.as_slice()?;
        };
    }
    fn convert_py2rs_treesequence(ts: Bound<'_, PyAny>) -> PyResult<TreeSequence> {
        // get arrays from python treesequende
        let seqlen: f64 = ts.getattr("sequence_length")?.extract()?;
        let nodes_flags: Bound<'_, PyArray1<u32>> = ts.getattr("nodes_flags")?.extract()?;
        let nodes_time: Bound<'_, PyArray1<f64>> = ts.getattr("nodes_time")?.extract()?;
        let edges_parent: Bound<'_, PyArray1<i32>> = ts.getattr("edges_parent")?.extract()?;
        let edges_child: Bound<'_, PyArray1<i32>> = ts.getattr("edges_child")?.extract()?;
        let edges_left: Bound<'_, PyArray1<f64>> = ts.getattr("edges_left")?.extract()?;
        let edges_right: Bound<'_, PyArray1<f64>> = ts.getattr("edges_right")?.extract()?;
        let sites_position: Bound<'_, PyArray1<f64>> = ts.getattr("sites_position")?.extract()?;
        let mutations_site: Bound<'_, PyArray1<i32>> = ts.getattr("mutations_site")?.extract()?;
        let mutations_node: Bound<'_, PyArray1<i32>> = ts.getattr("mutations_node")?.extract()?;
        let mutations_parent: Bound<'_, PyArray1<i32>> =
            ts.getattr("mutations_parent")?.extract()?;
        let mutations_time: Bound<'_, PyArray1<f64>> = ts.getattr("mutations_time")?.extract()?;

        // convert pyarray to slice
        to_slice!(nodes_flags);
        to_slice!(nodes_time);
        to_slice!(edges_parent);
        to_slice!(edges_child);
        to_slice!(edges_left);
        to_slice!(edges_right);
        to_slice!(mutations_site);
        to_slice!(mutations_node);
        to_slice!(mutations_parent);
        to_slice!(mutations_time);

        // create a table collection in rust
        let mut tables = tskit::TableCollection::new(seqlen).map_err(|e| {
            PyValueError::new_err(format!("Fail to create tskit table collection: {e:?}"))
        })?;

        // add nodes
        for (flags, time) in nodes_flags.iter().zip(nodes_time.iter()) {
            tables
                .add_node(*flags, *time, PopulationId::NULL, IndividualId::NULL)
                .map_err(|e| PyValueError::new_err(format!("Fail to add nodes: {e:?}")))?;
        }

        // add edges
        for (((left, right), parent), child) in edges_left
            .iter()
            .zip(edges_right)
            .zip(edges_parent)
            .zip(edges_child)
        {
            tables
                .add_edge(*left, *right, *parent, *child)
                .map_err(|e| PyValueError::new_err(format!("Fail to add edges: {e:?}")))?;
        }

        // add sites
        to_slice!(sites_position);
        for pos in sites_position {
            tables
                .add_site(*pos, None)
                .map_err(|e| PyValueError::new_err(format!("Fail to add sites: {e:?}")))?;
        }

        // add_mutation
        for (((site, parent), node), time) in mutations_site
            .iter()
            .zip(mutations_parent)
            .zip(mutations_node)
            .zip(mutations_time)
        {
            tables
                .add_mutation(*site, *node, *parent, *time, None)
                .map_err(|e| PyValueError::new_err(format!("Fail to add mutations: {e:?}")))?;
        }

        tables
            .build_index()
            .map_err(|e| PyValueError::new_err(format!("Fail to build index: {e:?}")))?;

        let ts = tables
            .tree_sequence(TreeSequenceFlags::default())
            .map_err(|e| {
                PyValueError::new_err(format!(
                    "Fail to convert table collections to treesequence: {e:?}"
                ))
            })?;

        Ok(ts)
    }

    #[pyclass]
    struct RvIbdAnalyzer {
        ts: TreeSequence,
    }

    #[pymethods]
    impl RvIbdAnalyzer {
        #[new]
        fn new(ts: Bound<'_, PyAny>) -> PyResult<Self> {
            let ts = convert_py2rs_treesequence(ts)?;
            Ok(Self { ts })
        }

        fn calc_rv_sharing(slf: PyRef<'_, Self>, max_freq: usize) -> PyResult<Py<PyArray2<u32>>> {
            let py = slf.py();
            let arr = get_rv_sharing_matrix(&slf.ts, max_freq).map_err(|e| {
                PyValueError::new_err(format!("Error in calculating rv sharing: {e:?}"))
            })?;
            Ok(PyArray2::from_owned_array(py, arr).unbind())
        }

        fn calc_ibd_sharing(slf: PyRef<'_, Self>, max_time: f64) -> PyResult<Py<PyArray2<u32>>> {
            let py = slf.py();
            let arr = get_ibd_sharing_matrix(&slf.ts, max_time);
            Ok(PyArray2::from_owned_array(py, arr).unbind())
        }
    }
}
