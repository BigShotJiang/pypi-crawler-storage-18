import msprime
import tskit 
import tskutils
import matplotlib
matplotlib.use("module://matplotlib-backend-wezterm")
import matplotlib.pyplot as plt

ts = msprime.sim_ancestry(
    100,
    population_size=1000,
    sequence_length=100_000_000,
    recombination_rate=1e-8,
    discrete_genome=True,
    random_seed=1,
)
ts_mut = msprime.sim_mutations(ts, rate=1e-8, random_seed=1)


assert type(ts) is tskit.TreeSequence

analyzer = tskutils.RvIbdAnalyzer(ts_mut)

rv_mat = analyzer.calc_rv_sharing(max_freq=3)
ibd_mat =  analyzer.calc_ibd_sharing( max_time=10.0)


fig, axes = plt.subplots(ncols=2, figsize=(10, 5), constrained_layout=True)
ax = axes[0]
ax.imshow(rv_mat, cmap='Blues', aspect='auto')
ax = axes[1]
ax.imshow(ibd_mat, cmap='Blues', aspect='auto')
plt.show()
