# Notes on compilation and distribution

```sh
# build dependencies
docker run -it ubuntu:22.04 bash
apt update
apt install python3-pip python3-venv clang cmake pkg-config build-essential curl -y
pip3 install maturin numpy tskit ziglang uv
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source "$HOME/.cargo/env"

# add tool chains
rustup target add aarch64-unknown-linux-gnu
rustup target add x86_64-unknown-linux-gnu
rustup target add aarch64-apple-darwin
rustup target add x86_64-apple-darwin

# build different wheels
maturin build --release --zig --target x86_64-unknown-linux-gnu 
maturin build --release --zig --target aarch64-unknown-linux-gnu 
maturin build --release --zig --target x86_64-apple-darwin
maturin build --release --zig --target aarch64-apple-darwin 

# build source distribution
uv build --sdist
# this will generate following wheels under target/wheels
# - tskutils-0.1.0-cp38-cp38-macosx_10_12_x86_64.whl
# - thskutils-0.1.0-cp38-cp38-macosx_11_0_arm64.whl
# - tskutils-0.1.0-cp38-cp38-manylinux_2_17_aarch64.manylinux2014_aarch64.whl
# - tskutils-0.1.0-cp38-cp38-manylinux_2_17_x86_64.manylinux2014_x86_64.whl

# distribute wheels and source code to pypi
uv publish target/wheels/*.whl
uv publish dist/tskutils-0.1.0.tar.gz
```
