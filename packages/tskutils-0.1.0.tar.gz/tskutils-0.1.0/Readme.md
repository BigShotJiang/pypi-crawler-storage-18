# tskutils

This is an early version. This package includes a PyO3-based Python extension
that provides additional utilities for working with the tskit TreeSequence
object.


