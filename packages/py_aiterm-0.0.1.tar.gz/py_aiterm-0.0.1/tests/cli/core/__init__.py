# CLI core tests package
