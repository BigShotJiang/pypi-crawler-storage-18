"""
Tests for wittrans

SPDX-FileCopyrightText: 2024 Jiri Grönroos <jiri.gronroos@iki.fi>

SPDX-License-Identifier: AGPL-3.0-or-later
"""

import sys

import pytest

from wittrans.functions import parse_arguments


def test_parse_arguments_source_flag(monkeypatch):
    """Test that -s/--source flag is parsed correctly."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "-s"])
    args = parse_arguments()

    assert args.search_term == "test"
    assert args.language_code == "fi"
    assert args.source is True
    assert args.translation is False


def test_parse_arguments_translation_flag(monkeypatch):
    """Test that -t/--translation flag is parsed correctly."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "-t"])
    args = parse_arguments()

    assert args.search_term == "test"
    assert args.language_code == "fi"
    assert args.source is False
    assert args.translation is True


def test_parse_arguments_whole_word_flag(monkeypatch):
    """Test that -w/--whole-word flag is parsed correctly."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "-w"])
    args = parse_arguments()

    assert args.search_term == "test"
    assert args.language_code == "fi"
    assert args.whole_word is True


def test_parse_arguments_combined_flags(monkeypatch):
    """Test combining multiple flags."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "-s", "-w", "-i"])
    args = parse_arguments()

    assert args.search_term == "test"
    assert args.language_code == "fi"
    assert args.source is True
    assert args.translation is False
    assert args.whole_word is True
    assert args.indicate is True


def test_parse_arguments_source_and_translation_exclusive(monkeypatch, capsys):
    """Test that -s and -t cannot be used together."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "-s", "-t"])

    with pytest.raises(SystemExit) as exc_info:
        parse_arguments()

    # Exit with error code 2 (argument parsing error)
    assert exc_info.value.code == 2

    # Check that error message is printed
    captured = capsys.readouterr()
    assert (
        "cannot be used together" in captured.err.lower()
        or "cannot be used together" in captured.out.lower()
    )


def test_parse_arguments_long_form_source(monkeypatch):
    """Test --source long form flag."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "--source"])
    args = parse_arguments()

    assert args.source is True
    assert args.translation is False


def test_parse_arguments_long_form_translation(monkeypatch):
    """Test --translation long form flag."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "--translation"])
    args = parse_arguments()

    assert args.source is False
    assert args.translation is True


def test_parse_arguments_long_form_whole_word(monkeypatch):
    """Test --whole-word long form flag."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi", "--whole-word"])
    args = parse_arguments()

    assert args.whole_word is True


def test_parse_arguments_defaults(monkeypatch):
    """Test that default values are correct when no flags are provided."""
    monkeypatch.setattr(sys, "argv", ["wittrans", "test", "fi"])
    args = parse_arguments()

    assert args.search_term == "test"
    assert args.language_code == "fi"
    assert args.source is False  # Default: search both
    assert args.translation is False  # Default: search both
    assert args.whole_word is False  # Default: partial matching
    assert args.indicate is False
    assert args.no_flatpak is False
    assert args.all is False


def test_parse_arguments_options(monkeypatch):
    """Test options together (except mutually exclusive ones)."""
    monkeypatch.setattr(
        sys,
        "argv",
        ["wittrans", "Monday", "en", "-s", "-w", "-i", "--no-flatpak", "-o", "tsv"],
    )
    args = parse_arguments()

    assert args.search_term == "Monday"
    assert args.language_code == "en"
    assert args.source is True
    assert args.translation is False
    assert args.whole_word is True
    assert args.indicate is True
    assert args.no_flatpak is True
    assert args.output == "tsv"
    assert args.all is False


def test_parse_arguments_translation_with_output(monkeypatch):
    """Test translation flag with TSV output."""
    monkeypatch.setattr(
        sys,
        "argv",
        ["wittrans", "terve", "fi", "-t", "-o", "tsv", "--output-file", "output.tsv"],
    )
    args = parse_arguments()

    assert args.search_term == "terve"
    assert args.language_code == "fi"
    assert args.source is False
    assert args.translation is True
    assert args.output == "tsv"
    assert args.output_file == "output.tsv"
    assert args.all is False
