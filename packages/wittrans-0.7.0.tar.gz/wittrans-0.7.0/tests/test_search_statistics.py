"""
Tests for wittrans

SPDX-FileCopyrightText: 2024 Jiri Grönroos <jiri.gronroos@iki.fi>

SPDX-License-Identifier: AGPL-3.0-or-later
"""

import pytest

from wittrans.functions import SearchStatistics


class TestSearchStatistics:
    """Tests for SearchStatistics NamedTuple."""

    def test_search_statistics_creation(self):
        """Test creating a SearchStatistics object."""
        stats = SearchStatistics(
            directories_searched=10,
            mo_files_found=250,
            total_matches=500,
            search_duration_seconds=1.23,
        )

        assert stats.directories_searched == 10
        assert stats.mo_files_found == 250
        assert stats.total_matches == 500
        assert stats.search_duration_seconds == 1.23

    def test_search_statistics_zero_values(self):
        """Test SearchStatistics with zero values."""
        stats = SearchStatistics(
            directories_searched=0,
            mo_files_found=0,
            total_matches=0,
            search_duration_seconds=0.0,
        )

        assert stats.directories_searched == 0
        assert stats.mo_files_found == 0
        assert stats.total_matches == 0
        assert stats.search_duration_seconds == 0.0

    def test_search_statistics_immutability(self):
        """Test that SearchStatistics is immutable (NamedTuple behavior)."""
        stats = SearchStatistics(
            directories_searched=5,
            mo_files_found=100,
            total_matches=200,
            search_duration_seconds=0.5,
        )

        with pytest.raises(AttributeError):
            stats.directories_searched = 10  # type: ignore[misc]

    def test_search_statistics_tuple_unpacking(self):
        """Test that SearchStatistics can be unpacked like a tuple."""
        stats = SearchStatistics(
            directories_searched=3,
            mo_files_found=50,
            total_matches=75,
            search_duration_seconds=2.5,
        )

        dirs, mo_files, matches, duration = stats

        assert dirs == 3
        assert mo_files == 50
        assert matches == 75
        assert duration == 2.5

    def test_search_statistics_equality(self):
        """Test SearchStatistics equality comparison."""
        stats1 = SearchStatistics(
            directories_searched=5,
            mo_files_found=100,
            total_matches=200,
            search_duration_seconds=1.5,
        )
        stats2 = SearchStatistics(
            directories_searched=5,
            mo_files_found=100,
            total_matches=200,
            search_duration_seconds=1.5,
        )
        stats3 = SearchStatistics(
            directories_searched=5,
            mo_files_found=100,
            total_matches=201,
            search_duration_seconds=1.5,
        )

        assert stats1 == stats2
        assert stats1 != stats3

    def test_search_statistics_large_values(self):
        """Test SearchStatistics with large values."""
        stats = SearchStatistics(
            directories_searched=1000,
            mo_files_found=50000,
            total_matches=1000000,
            search_duration_seconds=500.5,
        )

        assert stats.directories_searched == 1000
        assert stats.mo_files_found == 50000
        assert stats.total_matches == 1000000
        assert stats.search_duration_seconds == 500.5

    def test_search_statistics_duration_precision(self):
        """Test that search duration supports fractional seconds."""
        stats = SearchStatistics(
            directories_searched=1,
            mo_files_found=10,
            total_matches=20,
            search_duration_seconds=0.12345,
        )

        assert stats.search_duration_seconds == pytest.approx(0.12345, rel=1e-9)

    def test_search_statistics_access_by_index(self):
        """Test accessing SearchStatistics fields by index."""
        stats = SearchStatistics(
            directories_searched=7,
            mo_files_found=140,
            total_matches=280,
            search_duration_seconds=3.14,
        )

        assert stats[0] == 7
        assert stats[1] == 140
        assert stats[2] == 280
        assert stats[3] == 3.14

    def test_search_statistics_fields_attribute(self):
        """Test that SearchStatistics has _fields attribute (NamedTuple)."""
        assert hasattr(SearchStatistics, "_fields")
        assert SearchStatistics._fields == (
            "directories_searched",
            "mo_files_found",
            "total_matches",
            "search_duration_seconds",
        )

    def test_search_statistics_repr(self):
        """Test SearchStatistics string representation."""
        stats = SearchStatistics(
            directories_searched=2,
            mo_files_found=20,
            total_matches=40,
            search_duration_seconds=1.0,
        )

        repr_str = repr(stats)
        assert "SearchStatistics" in repr_str
        assert "directories_searched=2" in repr_str
        assert "mo_files_found=20" in repr_str
        assert "total_matches=40" in repr_str
        assert "search_duration_seconds=1.0" in repr_str
