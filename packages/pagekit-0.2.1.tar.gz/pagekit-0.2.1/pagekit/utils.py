import os
import requests
import contextvars
import logging
from fastapi.templating import Jinja2Templates

from cachetools import cached, TTLCache
from jinja2 import Environment, BaseLoader, TemplateNotFound, FileSystemLoader
from jinja2_lucide import LucideExtension
from .config import settings


# --- Caching ---
# Cache for Gitea API responses, 5 minute TTL
cache = TTLCache(maxsize=1024, ttl=300)

# --- Gitea Interaction ---
def get_gitea_file_meta(org: str, repo: str, path: str, repo_url: str, token: str | None):
    """
    Fetches file metadata from Gitea's contents API.
    If the path has no extension, it attempts to resolve it by checking for
    '.html' and then '.md' extensions.
    """
    if not repo_url:
        raise ValueError("GITEA_URL environment variable is not set.")

    session = requests.Session()
    if token:
        session.headers["Authorization"] = f"token {token}"
        
    # Create a cache key based on org, repo, and path
    cache_key = (org, repo, path)

    # Check if the result is already in the cache
    if cache_key in cache:
        return cache[cache_key]

    def _fetch(file_path):
        api_url = f"{repo_url}/api/v1/repos/{org}/{repo}/contents/{file_path}"
        if settings.DEBUG:
            print(f"Fetching URL '{api_url}'")
            logging.info(f"Fetching URL: {api_url}")
        try:
            response = session.get(api_url)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"requests exceptions '{e}'")
            return None

    if "." not in os.path.basename(path):
        # Try .html first
        meta = _fetch(f"{path}.html")
        if meta:
            cache[cache_key] = meta
            return meta
        # Try .md next
        meta = _fetch(f"{path}.md")
        if meta:
            cache[cache_key] = meta
            return meta
        
    
    
    # Fallback to original path or if it had an extension
    meta = _fetch(path)
    cache[cache_key] = meta
    return meta

def get_gitea_raw_content(download_url: str, token: str | None):
    """Fetches the raw text content of a file from Gitea."""
    try:
        logging.info(f"downloading file from Gitea: {download_url}")
        session = requests.Session()
        if token:
            session.headers["Authorization"] = f"token {token}"

        response = session.get(download_url)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        logging.error(f"Error downloading file from Gitea: {e}")
        return None

# --- Custom Jinja2 Loader for Gitea ---
class GiteaLoader(FileSystemLoader):
    def __init__(self, searchpath, encoding='utf-8', org: str=None, repo: str=None, repo_url: str = None, token: str | None = None):
        self.org = org
        self.repo = repo
        self.repo_url = repo_url
        self.token = token
        super().__init__(searchpath, encoding)

    def get_source(self, environment, template):
        # The loader should look for specific files, no content negotiation needed here.
        # Re-implementing the direct fetch logic to avoid caching issues with negotiation.
        api_url = f"{self.repo_url}/api/v1/repos/{self.org}/{self.repo}/contents/{template}"
        session = requests.Session()
        if self.token:
            session.headers["Authorization"] = f"token {self.token}"

        try:
            response = session.get(api_url)
            response.raise_for_status()
            file_meta = response.json()

            if not file_meta or "download_url" not in file_meta:
                raise TemplateNotFound(template)

            source = get_gitea_raw_content(file_meta["download_url"], self.token)
            if source is None:
                raise TemplateNotFound(template)

        except Exception as e:
            try:
                source, template, uptodate = super().get_source(environment, "layouts/page.html")

                if source is None:
                    raise TemplateNotFound(template)
            except TemplateNotFound as e:
                if settings.DEBUG:
                    logging.info(f"Template not found: {self.org}/{self.repo}/{e.name}")
                raise e


        return source, template, lambda: True


class GiteaJinja2Templates(Jinja2Templates):
    def _create_env(self, directory: str, **env_options) -> Environment:
        # The 'directory' argument is ignored, as we load from Gitea
        org = env_options.pop("org", None)
        repo = env_options.pop("repo", None)
        repo_url = env_options.pop("repo_url", None)
        token = env_options.pop("token", None)

        env = Environment(loader=GiteaLoader(searchpath=directory, org=org, repo=repo, repo_url=repo_url, token=token), extensions=[LucideExtension])
        return env