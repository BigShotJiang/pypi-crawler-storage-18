import os
import requests
import frontmatter
import markdown
import mimetypes
import logging
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, StreamingResponse, FileResponse
from fastapi.templating import Jinja2Templates

from jinja2 import TemplateNotFound
from jinja2_lucide import LucideExtension

from pagekit.config import settings
from pagekit.utils import get_gitea_file_meta, get_gitea_raw_content, GiteaJinja2Templates


# --- FastAPI Setup ---
app = FastAPI()


# --- Request Handling ---
@app.get("/{path:path}")
async def serve_site(request: Request, path: str):
    """
    Serves content based on the configured APP_MODE.
    - repo: From a Gitea repository based on the request's hostname.
    - local: From the local filesystem.
    - platform: From a user-specific repository (Not Implemented).
    """
    host = request.headers.get("host", "").split(":")[0]
    template_name = path if path else "index"

    if not template_name.endswith(".md"):
        template_name = f"{template_name}.md"

    content_type, _ = mimetypes.guess_type(template_name)
    
    # --- Local Mode ---
    if settings.APP_MODE == "local":
        layout_templates = Jinja2Templates(directory=os.path.join(settings.LOCAL_CONTENT_DIR, "templates"), extensions=[LucideExtension]) 
        content_templates = Jinja2Templates(directory=os.path.join(settings.LOCAL_CONTENT_DIR, "."), extensions=[LucideExtension]) 
        
        try:
            raw_content = content_templates.get_template(template_name)

            if raw_content:            
                raw_content = raw_content.render()
                
            if content_type == "text/markdown":
                
                yaml_content = frontmatter.loads(raw_content)
                md_content = markdown.Markdown(extensions=["toc"])
                html_content = md_content.convert(yaml_content.content)      

                template_context = {"request": request, "content": html_content, "toc": md_content.toc_tokens}  
                template_context.update(yaml_content.metadata)

                template_name = yaml_content.metadata.get("layout", "layouts/default.html")
            else:
                template_context = {"request": request, "content": raw_content}                


            return layout_templates.TemplateResponse(
                template_name,
                template_context,
            )
            
        except TemplateNotFound as e:
            return HTMLResponse(content=f"Template '{e.name}' not found.", status_code=404)
        except Exception as e:
            return HTMLResponse(content=f"Error processing file: {e}", status_code=500)            

    # --- Repo Mode ---
    elif settings.APP_MODE == "repo":
        if "." not in host or host.startswith("localhost"):
            return HTMLResponse(content="Invalid hostname.", status_code=400)

        host_parts = host.split(".")
        if len(host_parts) > 4: # subdomain.org.pages.domain.com
            repo = host_parts[0]
            org = host_parts[1]
        else: # org.pages.domain.com
            org = host_parts[0]
            repo = settings.DEFAULT_REPO

        repo_url = settings.REPO_URL
        token = settings.REPO_TOKEN

        templates = GiteaJinja2Templates(directory="templates", org=org, repo=repo, repo_url=repo_url, token=token)

        try:
            file_meta = get_gitea_file_meta(org, repo, template_name, repo_url, token)
        except ValueError as e:
            return HTMLResponse(content=str(e), status_code=500)

        if not file_meta or "download_url" not in file_meta:
            return HTMLResponse(content=f"File not found in repository '{org}/{repo}/{path}'", status_code=404)

        resolved_filepath = file_meta.get("path")
        content_type, _ = mimetypes.guess_type(resolved_filepath)
        content_type = content_type or "application/octet-stream"

        if content_type == "text/markdown":
            try:
                raw_content = get_gitea_raw_content(file_meta["download_url"], token)
                if raw_content is None:
                    return HTMLResponse(content="Could not retrieve file content.", status_code=500)
                
                post = frontmatter.loads(raw_content)
                md = markdown.Markdown(extensions=["toc"])
                html_content = md.convert(post.content)            

                template_context = {"request": request, "content": html_content, "toc": md.toc_tokens}
                template_context.update(post.metadata)
                template_context.setdefault("title", "Gitea Page")

                template_name = post.metadata.get("layout", "layouts/page.html")
                
                return templates.TemplateResponse(
                    template_name,
                    template_context,
                )
            except TemplateNotFound as e:
                if settings.DEBUG:
                    logging.info(f"Template not found: {org}/{repo}/{e.name}")
                return HTMLResponse(content=f"Template '{e.name}' not found in repo '{org}/{repo}'.", status_code=404)
            except Exception as e:
                return HTMLResponse(content=f"Error processing file: {e}", status_code=500)

        else: # Stream other file types directly
            try:
                headers = {"Authorization": f"token {token}"} if token else {}
                gitea_response = requests.get(file_meta["download_url"], stream=True, headers=headers)
                gitea_response.raise_for_status()
                return StreamingResponse(
                    gitea_response.iter_content(chunk_size=8192),
                    media_type=content_type,
                )
            except requests.exceptions.RequestException as e:
                return HTMLResponse(content=f"Error streaming file: {e}", status_code=500)
    
    else:
        return HTMLResponse(content=f"Invalid APP_MODE '{settings.APP_MODE}'.", status_code=500)


# --- Main ---
if __name__ == "__main__":
    import uvicorn
    logging.basicConfig(level=logging.DEBUG, format="%(levelname)s:     %(message)s")
    logging.info(f"Starting PageKit server in '{settings.APP_MODE}' mode...")
    if settings.APP_MODE == 'repo':
        logging.info(f"REPO_URL: {settings.REPO_URL}")
        logging.info(f"DEFAULT_REPO: {settings.DEFAULT_REPO}")
        logging.info("REPO_TOKEN: " + ("Set" if settings.REPO_TOKEN else "Not Set"))
    elif settings.APP_MODE == 'local':
        logging.info(f"LOCAL_CONTENT_DIR: {settings.LOCAL_CONTENT_DIR}")

    logging.info(f"Debug mode is {'on' if settings.DEBUG else 'off'}")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True, log_level=logging.DEBUG)