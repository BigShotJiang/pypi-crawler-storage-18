from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    APP_MODE: str = "local" # repo, local, platform
    REPO_URL: str
    REPO_TOKEN: str
    DEFAULT_REPO: str = "pagekit"
    DEBUG: bool = False
    
    # Platform mode
    DATABASE_URL: str | None = None
    
    # Local mode
    LOCAL_CONTENT_DIR: str | None = ""


settings = Settings()
