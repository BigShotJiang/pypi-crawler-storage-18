#!/usr/bin/env python
# coding: utf-8

import os
from io import BytesIO
from typing import Optional, List, Dict, Any
import pickle

from basedir import basedir
from dotenv import load_dotenv

from langchain_openai import OpenAIEmbeddings
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct

from cachetools import cached, TTLCache

from google.cloud.storage.bucket import Bucket
from athenah_ai.libs.google.storage import GCPStorageClient
from athenah_ai.logger import logger
from athenah_ai.config import config

load_dotenv()

cache = TTLCache(maxsize=100, ttl=3600)


class VectorStore(object):
    storage_type: str = "local"  # local or gcs
    _client: Optional[QdrantClient] = None
    _embedder: Optional[OpenAIEmbeddings] = None
    _collection_name: str = ""

    def __init__(cls, storage_type: str) -> None:
        cls.storage_type = storage_type
        cls._embedder = OpenAIEmbeddings(
            openai_api_key=config.llm.openai_api_key,
            model=config.indexer.embedding_model,
            chunk_size=config.text_processing.indexer_chunk_size,
        )

    def load(cls, name: str, dir: str = "dist", version: str = "v1") -> QdrantClient:
        """Load Qdrant client and return it."""
        cls._collection_name = f"{name}_{version}".replace("-", "_")

        if cls.storage_type == "local":
            logger.debug("LOADING LOCAL QDRANT")
            cls._client = cls.load_local(dir, name, version)
            return cls._client

        if cls.storage_type == "gcs":
            logger.debug("LOADING GCS QDRANT")
            try:
                cls._client = cls.load_local(dir, name, version)
                return cls._client
            except Exception:
                cls.storage_client: GCPStorageClient = GCPStorageClient().add_client()
                cls.bucket: Bucket = cls.storage_client.init_bucket(
                    config.indexer.gcp_index_bucket
                )
                cls._client = cls.load_gcs(name, version, dir)
                return cls._client

    def load_local(cls, dir: str, name: str, version: str) -> QdrantClient:
        """Load local Qdrant collection."""
        cls.base_path: str = os.path.join(basedir, dir)
        cls.name_version_path: str = os.path.join(cls.base_path, f"{name}-{version}")

        # Initialize Qdrant client with local persistence
        cls._client = QdrantClient(path=cls.name_version_path)

        try:
            # Check if collection exists
            collection_info = cls._client.get_collection(cls._collection_name)
            logger.info(
                f"Loaded collection {cls._collection_name} with {collection_info.points_count} points"
            )
        except Exception:
            logger.warning(f"Collection {cls._collection_name} not found in local storage")

        return cls._client

    @cached(cache)
    def load_gcs(cls, name: str, version: str, dir: str = "dist") -> QdrantClient:
        """Load Qdrant collection from GCS."""
        # Download collection data from GCS
        blob = cls.bucket.blob(f"{name}/{version}/collection.pkl")
        data_bytes = blob.download_as_bytes()
        collection_data = pickle.loads(data_bytes)

        # Create local client
        cls.base_path: str = os.path.join(basedir, dir)
        cls.name_version_path: str = os.path.join(cls.base_path, f"{name}-{version}")
        cls._client = QdrantClient(path=cls.name_version_path)

        # Recreate collection
        from qdrant_client.models import VectorParams

        try:
            cls._client.get_collection(cls._collection_name)
            logger.debug(f"Collection {cls._collection_name} already exists")
        except Exception:
            cls._client.create_collection(
                collection_name=cls._collection_name,
                vectors_config=VectorParams(
                    size=collection_data["vector_size"],
                    distance=collection_data["distance"],
                ),
            )

            # Restore points
            points = [
                PointStruct(
                    id=point_data["id"],
                    vector=point_data["vector"],
                    payload=point_data["payload"],
                )
                for point_data in collection_data["points"]
            ]

            # Batch upsert
            batch_size = 100
            for i in range(0, len(points), batch_size):
                batch = points[i : i + batch_size]
                cls._client.upsert(collection_name=cls._collection_name, points=batch)

            logger.info(
                f"Loaded collection {cls._collection_name} from GCS with {len(points)} points"
            )

        return cls._client

    def save_to_gcs(cls, name: str, version: str) -> bool:
        """Save Qdrant collection to GCS."""
        try:
            cls.storage_client: GCPStorageClient = GCPStorageClient().add_client()
            cls.bucket: Bucket = cls.storage_client.init_bucket(
                config.indexer.gcp_index_bucket
            )

            if not cls._client:
                logger.error("No Qdrant client to save")
                return False

            # Get collection info
            collection_info = cls._client.get_collection(cls._collection_name)

            # Scroll through all points
            points_data = []
            scroll_result = cls._client.scroll(
                collection_name=cls._collection_name,
                limit=10000,
                with_payload=True,
                with_vectors=True,
            )
            points_data.extend(scroll_result[0])

            next_offset = scroll_result[1]
            while next_offset is not None:
                scroll_result = cls._client.scroll(
                    collection_name=cls._collection_name,
                    limit=10000,
                    offset=next_offset,
                    with_payload=True,
                    with_vectors=True,
                )
                points_data.extend(scroll_result[0])
                next_offset = scroll_result[1]

            # Serialize collection data
            collection_data = {
                "collection_name": cls._collection_name,
                "vector_size": collection_info.config.params.vectors.size,
                "distance": collection_info.config.params.vectors.distance,
                "points": [
                    {
                        "id": point.id,
                        "vector": point.vector,
                        "payload": point.payload,
                    }
                    for point in points_data
                ],
            }

            # Upload to GCS
            blob = cls.bucket.blob(f"{name}/{version}/collection.pkl")
            data_bytes = pickle.dumps(collection_data)
            blob.upload_from_string(data_bytes)

            logger.info(
                f"Saved collection {cls._collection_name} to GCS with {len(points_data)} points"
            )
            return True
        except Exception as e:
            logger.error(f"Failed to save Qdrant collection: {e}")
            return False

    def get_collection_info(cls) -> Dict[str, Any]:
        """Get collection statistics."""
        if not cls._client:
            return {"exists": False}

        try:
            collection_info = cls._client.get_collection(cls._collection_name)
            return {
                "exists": True,
                "points_count": collection_info.points_count,
                "vectors_count": collection_info.vectors_count,
                "collection_name": cls._collection_name,
            }
        except Exception:
            return {"exists": False}
