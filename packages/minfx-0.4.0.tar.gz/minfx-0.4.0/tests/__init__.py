# Tests package for minfx 
