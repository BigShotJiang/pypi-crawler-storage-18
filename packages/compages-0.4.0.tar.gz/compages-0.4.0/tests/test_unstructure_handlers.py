import re
from dataclasses import dataclass, field
from types import UnionType
from typing import Any, NamedTuple

import pytest
from compages import (
    AsBool,
    AsBytes,
    AsDataclassToDict,
    AsDataclassToList,
    AsDict,
    AsFloat,
    AsInt,
    AsList,
    AsNamedTupleToDict,
    AsNamedTupleToList,
    AsNone,
    AsStr,
    AsTuple,
    AsUnion,
    DataclassBase,
    NamedTupleBase,
    StructLikeOptions,
    UnstructureHandler,
    Unstructurer,
    UnstructurerContext,
    UnstructuringError,
)
from compages.path import DictKey, DictValue, ListElem, StructField, UnionVariant


# TODO (#5): duplicate
def assert_exception_matches(exc, reference_exc):
    assert isinstance(exc, UnstructuringError)
    assert re.match(reference_exc.message, exc.message)
    assert len(exc.inner_errors) == len(reference_exc.inner_errors)
    for (inner_path, inner_exc), (ref_path, ref_exc) in zip(
        exc.inner_errors, reference_exc.inner_errors, strict=True
    ):
        assert inner_path == ref_path
        assert_exception_matches(inner_exc, ref_exc)


def test_unstructure_as_none():
    unstructurer = Unstructurer({type(None): AsNone()})
    assert unstructurer.unstructure_as(type(None), None) is None


def test_unstructure_as_float():
    unstructurer = Unstructurer({float: AsFloat()})
    assert unstructurer.unstructure_as(float, 1.5) == 1.5


def test_unstructure_as_bool():
    unstructurer = Unstructurer({bool: AsBool()})
    assert unstructurer.unstructure_as(bool, True) is True
    assert unstructurer.unstructure_as(bool, False) is False


def test_unstructure_as_str():
    unstructurer = Unstructurer({str: AsStr()})
    assert unstructurer.unstructure_as(str, "abc") == "abc"


def test_unstructure_as_bytes():
    unstructurer = Unstructurer({bytes: AsBytes()})
    assert unstructurer.unstructure_as(bytes, b"abc") == b"abc"


def test_unstructure_as_int():
    unstructurer = Unstructurer({int: AsInt()})
    assert unstructurer.unstructure_as(int, 1) == 1

    # Specifically test that a boolean is not accepted,
    # even though it is a subclass of int in Python.
    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(int, True)
    expected = UnstructuringError("The value must be of type `int`")
    assert_exception_matches(exc.value, expected)


def test_unstructure_as_union():
    unstructurer = Unstructurer(
        {
            UnionType: AsUnion(),
            int: AsInt(),
            str: AsStr(),
        }
    )
    assert unstructurer.unstructure_as(int | str, "a") == "a"
    assert unstructurer.unstructure_as(int | str, 1) == 1

    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(int | str, 1.2)
    expected = UnstructuringError(
        r"Cannot unstructure as int | str",
        [
            (UnionVariant(int), UnstructuringError("The value must be of type `int`")),
            (UnionVariant(str), UnstructuringError("The value must be of type `str`")),
        ],
    )
    assert_exception_matches(exc.value, expected)


def test_unstructure_as_tuple():
    unstructurer = Unstructurer(
        {
            tuple: AsTuple(),
            int: AsInt(),
            str: AsStr(),
        }
    )

    assert unstructurer.unstructure_as(tuple[()], ()) == []
    assert unstructurer.unstructure_as(tuple[int, str], (1, "a")) == [1, "a"]
    assert unstructurer.unstructure_as(tuple[int, ...], (1, 2, 3)) == [1, 2, 3]

    with pytest.raises(UnstructuringError) as exc:
        AsTuple().unstructure(UnstructurerContext(None, tuple[int, str], None), {"x": 1, "y": "a"})
    expected = UnstructuringError("Can only unstructure a Sequence as a tuple")
    assert_exception_matches(exc.value, expected)

    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(tuple[int, str, int], (1, "a"))
    expected = UnstructuringError("Not enough elements to unstructure as a tuple: got 2, need 3")
    assert_exception_matches(exc.value, expected)

    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(tuple[int], (1, "a"))
    expected = UnstructuringError("Too many elements to unstructure as a tuple: got 2, need 1")
    assert_exception_matches(exc.value, expected)

    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(tuple[int, str], (1, 1.2))
    expected = UnstructuringError(
        r"Cannot unstructure as tuple\[int, str\]",
        [(ListElem(1), UnstructuringError("The value must be of type `str`"))],
    )
    assert_exception_matches(exc.value, expected)


def test_unstructure_as_unqualified_tuple():
    unstructurer = Unstructurer({tuple: AsTuple(), Any: AsInt()})
    # Unstructuring a an unqualified tuple calls a handler for `Any` for its elements
    assert unstructurer.unstructure_as(tuple, (1, 2)) == [1, 2]


def test_unstructure_as_list():
    unstructurer = Unstructurer({list: AsList(), int: AsInt()})

    assert unstructurer.unstructure_as(list[int], [1, 2, 3]) == [1, 2, 3]

    with pytest.raises(UnstructuringError) as exc:
        AsList().unstructure(UnstructurerContext(None, list[int], None), {"x": 1, "y": "a"})
    expected = UnstructuringError("Can only unstructure a Sequence as a list")
    assert_exception_matches(exc.value, expected)

    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(list[int], [1, "a"])
    expected = UnstructuringError(
        r"Cannot unstructure as list\[int\]",
        [(ListElem(1), UnstructuringError("The value must be of type `int`"))],
    )
    assert_exception_matches(exc.value, expected)


def test_unstructure_as_unqualified_list():
    unstructurer = Unstructurer({list: AsList(), Any: AsInt()})
    # Unstructuring a an unqualified list calls a handler for `Any` for its elements
    assert unstructurer.unstructure_as(list, [1, 2]) == [1, 2]


def test_unstructure_as_dict():
    unstructurer = Unstructurer(
        {
            dict: AsDict(),
            int: AsInt(),
            str: AsStr(),
        }
    )

    assert unstructurer.unstructure_as(dict[int, str], {1: "a", 2: "b"}) == {1: "a", 2: "b"}

    with pytest.raises(UnstructuringError) as exc:
        AsDict().unstructure(UnstructurerContext(None, dict[int, str], None), [(1, "a"), (2, "b")])
    expected = UnstructuringError("Can only unstructure a Mapping as a dict")
    assert_exception_matches(exc.value, expected)

    # Error structuring a key
    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(dict[int, str], {"a": "b", 2: "c"})
    expected = UnstructuringError(
        r"Cannot unstructure as dict\[int, str\]",
        [(DictKey("a"), UnstructuringError("The value must be of type `int`"))],
    )
    assert_exception_matches(exc.value, expected)

    # Error structuring a value
    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(dict[int, str], {1: "a", 2: 3})
    expected = UnstructuringError(
        r"Cannot unstructure as dict\[int, str\]",
        [(DictValue(2), UnstructuringError("The value must be of type `str`"))],
    )
    assert_exception_matches(exc.value, expected)


def test_unstructure_as_unqualified_dict():
    unstructurer = Unstructurer({dict: AsDict(), Any: AsInt()})
    # Unstructuring a an unqualified dict calls a handler for `Any` for its elements
    assert unstructurer.unstructure_as(dict, {1: 2}) == {1: 2}


def test_unstructure_as_dataclass_to_dict():
    unstructurer = Unstructurer(
        {
            int: AsInt(),
            str: AsStr(),
            DataclassBase: AsDataclassToDict(
                StructLikeOptions(to_unstructured_name=lambda name, _metadata: name + "_")
            ),
        },
    )

    @dataclass
    class Container:
        x: int
        y: str
        z: str

    assert unstructurer.unstructure_as(Container, Container(x=1, y="a", z="b")) == {
        "x_": 1,
        "y_": "a",
        "z_": "b",
    }

    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(Container, Container(x=1, y=2, z="b"))
    expected = UnstructuringError(
        "Failed to unstructure to a dict as",
        [(StructField("y"), UnstructuringError("The value must be of type `str`"))],
    )
    assert_exception_matches(exc.value, expected)


def test_unstructure_as_dataclass_to_dict_invalid_handler():
    unstructurer = Unstructurer(
        {
            int: AsInt(),
            str: AsDataclassToDict(),
        },
    )

    message = (
        "Failed to fetch field metadata for the value `1`: Expected a dataclass, got <class 'str'>"
    )
    with pytest.raises(UnstructuringError, match=message):
        unstructurer.unstructure_as(str, "1")


def test_unstructure_as_dataclass_to_dict_skip_defaults():
    # Badly behaving classes that raise an error on comparison,
    # so the unstructurer will have to process that when we're comparing
    # `z=A()` with the default `B()`

    class A:  # noqa: PLW1641
        def __eq__(self, other):
            if not isinstance(other, A):
                raise TypeError("type mismatch")
            return True

    class B:
        def __eq__(self, other):
            if not isinstance(other, A):
                raise TypeError("type mismatch")
            return True

        # Have to define this to be able to use it as a default in a dataclass
        def __hash__(self):
            return 1

    b = B()

    @dataclass
    class Container:
        x: int
        y: str = "b"
        z: A | B = b
        w: str = field(default_factory=lambda: "c")

    class ToA(UnstructureHandler):
        def simple_unstructure(self, _val):
            return "A"

    class ToB(UnstructureHandler):
        def simple_unstructure(self, _val):
            return "B"

    unstructurer = Unstructurer(
        {
            UnionType: AsUnion(),
            A: ToA(),
            B: ToB(),
            int: AsInt(),
            str: AsStr(),
            DataclassBase: AsDataclassToDict(),
        },
    )

    # `y` will not be present in the results since its value is equal to the default one
    assert unstructurer.unstructure_as(Container, Container(x=1, y="b", z=A(), w="c")) == {
        "x": 1,
        "z": "A",
    }


def test_unstructure_as_dataclass_to_list():
    unstructurer = Unstructurer(
        {
            int: AsInt(),
            str: AsStr(),
            DataclassBase: AsDataclassToList(),
        },
    )

    @dataclass
    class Container:
        x: int
        y: str
        z: str

    assert unstructurer.unstructure_as(Container, Container(x=1, y="a", z="b")) == [1, "a", "b"]

    with pytest.raises(UnstructuringError) as exc:
        unstructurer.unstructure_as(Container, Container(x=1, y=2, z="b"))
    expected = UnstructuringError(
        "Failed to unstructure to a list as",
        [(StructField("y"), UnstructuringError("The value must be of type `str`"))],
    )
    assert_exception_matches(exc.value, expected)


def test_unstructure_as_dataclass_to_list_invalid_handler():
    unstructurer = Unstructurer(
        {
            int: AsInt(),
            str: AsDataclassToList(),
        },
    )

    message = (
        "Failed to fetch field metadata for the value `1`: Expected a dataclass, got <class 'str'>"
    )
    with pytest.raises(UnstructuringError, match=message):
        unstructurer.unstructure_as(str, "1")


def test_unstructure_as_named_tuple_to_dict():
    unstructurer = Unstructurer(
        {
            int: AsInt(),
            str: AsStr(),
            NamedTupleBase: AsNamedTupleToDict(
                StructLikeOptions(to_unstructured_name=lambda name, _metadata: name + "_")
            ),
        },
    )

    class Container(NamedTuple):
        x: int
        y: str = "default"

    assert unstructurer.unstructure_as(Container, Container(x=1, y="default")) == {"x_": 1}
    assert unstructurer.unstructure_as(Container, Container(x=1, y="a")) == {"x_": 1, "y_": "a"}


def test_structure_as_named_tuple_to_list():
    unstructurer = Unstructurer(
        {
            int: AsInt(),
            str: AsStr(),
            NamedTupleBase: AsNamedTupleToList(),
        },
    )

    class Container(NamedTuple):
        x: int
        y: str = "default"

    assert unstructurer.unstructure_as(Container, Container(x=1, y="default")) == [1]
    assert unstructurer.unstructure_as(Container, Container(x=1, y="a")) == [1, "a"]
