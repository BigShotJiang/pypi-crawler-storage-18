---
applyTo: "**"
---

個人のタスク管理リポジトリ。基本は他人に共有せず自分の頭の整理のために使う。マークダウンを使ってタスク管理する。

AtlassianAccountId: "5cbd9f1396f23e0e771753b7"
AtlassianUserName: "Tomokatsu Iguchi"
