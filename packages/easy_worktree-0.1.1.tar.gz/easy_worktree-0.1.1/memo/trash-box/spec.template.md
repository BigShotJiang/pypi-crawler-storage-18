# 用語登録システム 内部仕様書

## 概要

用語とその定義を登録・管理するシステムの内部仕様書

## データモデル

### 用語エンティティ

- id: string (UUID)
- term: string (用語名)
- definition: string (定義)
- category: string (カテゴリ)
- created_at: datetime
- updated_at: datetime

## 機能仕様

- [ ] 用語登録ページ
  - [ ] 一覧テーブル
    - [ ] API:
      - [ ] GET /api/terms - 用語一覧取得
        - [ ] クエリパラメータ: page, limit, category, search
        - [ ] レスポンス: { data: Term[], total: number, page: number }
      - [ ] DELETE /api/terms/:id - 用語削除
        - [ ] パラメータ: id (UUID)
        - [ ] レスポンス: { success: boolean, message: string }
    - [ ] Front:
      - [ ] テーブルコンポーネント実装
      - [ ] ページネーション機能
      - [ ] 検索・フィルタ機能
      - [ ] 削除確認ダイアログ
      - [ ] ローディング状態表示
  - [ ] 詳細
    - [ ] API:
      - [ ] GET /api/terms/:id - 用語詳細取得
        - [ ] パラメータ: id (UUID)
        - [ ] レスポンス: Term
      - [ ] POST /api/terms - 新規用語作成
        - [ ] リクエストボディ: { term, definition, category }
        - [ ] バリデーション: 必須項目チェック、文字数制限
      - [ ] PUT /api/terms/:id - 用語更新
        - [ ] パラメータ: id (UUID)
        - [ ] リクエストボディ: { term, definition, category }
    - [ ] Front:
      - [ ] 詳細表示コンポーネント
      - [ ] 編集フォームコンポーネント
      - [ ] バリデーション機能
      - [ ] 保存・キャンセル機能
      - [ ] エラーハンドリング

## バリデーション仕様

- [ ] 用語名: 必須、1-100 文字
- [ ] 定義: 必須、1-1000 文字
- [ ] カテゴリ: 必須、選択肢から選択

## エラーハンドリング

- [ ] 400 Bad Request: バリデーションエラー
- [ ] 404 Not Found: 用語が存在しない
- [ ] 500 Internal Server Error: サーバーエラー

## テスト仕様

- [ ] 単体テスト
  - [ ] API エンドポイントテスト
  - [ ] フロントエンドコンポーネントテスト
- [ ] 結合テスト
  - [ ] CRUD 操作の動作確認
  - [ ] エラーケースの動作確認
