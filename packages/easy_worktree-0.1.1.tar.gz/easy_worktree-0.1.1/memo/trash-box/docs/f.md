仕様ドリブン開発するためのプロンプト運用方法メモ
- docs/tasks/{YYYY-MM-dd}-{project_name}/instruction.md: 内部仕様（作りたい機能の実装リストを作る）
- docs/tasks/{YYYY-MM-dd}-{project_name}/memo.md: 実装途中メモ（どこまで作ったとか、どうやって作ったとか）


あくまで生産性を上げるために利用するもので、見返さないしキレイなドキュメントを書くことが目的ではない
- 実装したい差分の指示だけ書く。既存機能の説明などは不要。


```sh
spec new
# docs/tasks/2025-06-04-new-file-translation-design/instruction.md

```
