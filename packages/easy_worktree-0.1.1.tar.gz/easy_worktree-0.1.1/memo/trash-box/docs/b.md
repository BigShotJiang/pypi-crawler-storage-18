```mermaid
erDiagram
    TRANSLATION_FILE {
        varchar id PK
        varchar document_type "enum(pptx,docx)"
        varchar source_s3uri
        varchar source_preview_s3uri
        varchar title
        varchar source_language
        varchar target_language
        varchar organization_id FK
        varchar created_by FK
        timestamp created_at
        timestamp updated_at
    }

    TRANSLATION_FILE_PREPROCESS {
        varchar id PK
        varchar translation_file_id FK
        varchar model
        varchar sentence_json_version
        varchar organization_id FK
        varchar created_by FK
        timestamp created_at
        timestamp updated_at
    }

    TRANSLATION_FILE ||--o{ TRANSLATION_FILE_PREPROCESS : contains

    TRANSLATION_FILE_SENTENCE {
        varchar id PK
        varchar translation_file_preprocess_id FK
        int sentence_number
        int file_page_number
        text original_text
        text translated_text
        text translated_modifed_text "nullable 人手で修正した場合のテキスト"
        varchar organization_id FK
        timestamp created_at
        timestamp updated_at
    }

    TRANSLATION_FILE_PREPROCESS ||--o{ TRANSLATION_FILE_SENTENCE : contains
```
