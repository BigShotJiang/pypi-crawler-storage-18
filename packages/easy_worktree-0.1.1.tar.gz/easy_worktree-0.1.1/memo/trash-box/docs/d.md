```mermaid
erDiagram
    TRANSLATION_DATASET {
        varchar id PK
        varchar dataset_type "enum(pptx,docx)"
        varchar title
        varchar source_s3uri
        varchar target_s3uri
        varchar source_language
        varchar target_language
        varchar organization_id FK
        varchar created_by FK
        timestamp created_at
        timestamp updated_at
    }

    TRANSLATION_DATASET_ITEM {
        varchar id PK
        varchar translation_dataset_id FK
        varchar organization_id FK
        varchar item_type "enum(term,sentence)"
        binary ja_term "日本語"
        binary en_term "英語"
        timestamp created_at
        timestamp updated_at
    }
```
