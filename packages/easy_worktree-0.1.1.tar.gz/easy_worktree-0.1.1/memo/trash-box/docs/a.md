React の `/translate-pptx` の 既存 page component に新しい機能を追加したい。

現状は pptx をアップロードして翻訳されたpptxをダウンロードするだけの機能。
追加したいのはpptxをアップロード後に、pptx内の日本語１行ごとがどのように英語に翻訳されるかを表示・編集できる中間画面を作成したい。ExcelのようなテーブルUIで２列表示。左が日本語、右が英語の列。ユーザーが確認・編集後、「これで翻訳する」ボタンを押すことで翻訳されるようにしたい。

[注意]

- /kaijin-web/front/src/pages/page.tsx のみ参照・編集して
- /kaijin-web/front/src/api/gen 以下は自動生成ファイルなので参照・編集しないでください
