sweagent run \
  --config ../tmp/kaijin-web/sweagent-config.yaml \
  --env.repo.path=. \
  --problem_statement.path=../tmp/kaijin-web/a.md \
  --actions.apply_patch_locally=True
