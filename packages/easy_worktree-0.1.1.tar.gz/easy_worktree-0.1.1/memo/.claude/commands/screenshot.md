---
description: スクリーンショットを撮影する
---

# スクリーンショット撮影コマンド

このコマンドは、指定されたHTMLファイルのスクリーンショットを撮影し、同じディレクトリに保存します。

## 使用方法

```
/screenshot <htmlファイルのパス>
```

## 指示

{{#context}}
あなたはPlaywright MCPを使用して、指定されたHTMLファイルのスクリーンショットを撮影するタスクを実行します。

1. 与えられたパスのHTMLファイルを読み込みます
2. Playwright MCPを使用してHTMLファイルのスクリーンショットを撮影します
3. スクリーンショットを元のHTMLファイルと同じディレクトリに保存します
4. ファイル名は元のHTMLファイル名に "-screenshot.png" を付けたものにします

### MCP実行コード

```javascript
const path = require('path');
const fs = require('fs');
const playwright = require('playwright');

async function captureScreenshot(htmlFilePath) {
  // HTMLファイルの絶対パスを取得
  const absoluteHtmlPath = path.resolve(htmlFilePath);
  
  // HTMLファイルが存在するか確認
  if (!fs.existsSync(absoluteHtmlPath)) {
    throw new Error(`HTMLファイルが見つかりません: ${absoluteHtmlPath}`);
  }
  
  // スクリーンショットのファイルパスを生成
  const htmlDir = path.dirname(absoluteHtmlPath);
  const htmlBaseName = path.basename(absoluteHtmlPath, '.html');
  const screenshotPath = path.join(htmlDir, `${htmlBaseName}-screenshot.png`);
  
  // Playwrightを初期化
  const browser = await playwright.chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();
  
  try {
    // HTMLファイルをロード
    await page.goto(`file://${absoluteHtmlPath}`);
    
    // スクリーンショットを撮影
    await page.screenshot({ path: screenshotPath, fullPage: true });
    
    console.log(`スクリーンショットを保存しました: ${screenshotPath}`);
    
    return screenshotPath;
  } finally {
    // ブラウザを閉じる
    await browser.close();
  }
}

// メイン実行関数
async function main() {
  const htmlFilePath = process.argv[2];
  
  if (!htmlFilePath) {
    console.error('HTMLファイルのパスを指定してください');
    process.exit(1);
  }
  
  try {
    const screenshotPath = await captureScreenshot(htmlFilePath);
    return { success: true, message: `スクリーンショット撮影成功: ${screenshotPath}` };
  } catch (error) {
    console.error('エラー:', error.message);
    return { success: false, message: `スクリーンショット撮影失敗: ${error.message}` };
  }
}

module.exports = { main };
```

### 出力と対応

スクリーンショットが正常に撮影された場合は、成功メッセージと保存されたファイルのパスを返してください。
エラーが発生した場合は、失敗の理由を説明してください。

{{/context}}