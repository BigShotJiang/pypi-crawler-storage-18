# easy-worktree Hooks

This directory contains hook scripts for easy-worktree (wt command).

## What is wt command?

`wt` is a CLI tool for easily managing Git worktrees. When working on multiple branches simultaneously, you can create and manage independent directories (worktrees) for each branch.

### Basic Usage

```bash
# Clone a repository
wt clone <repository_url>

# Create a new worktree (new branch)
wt add <work_name>

# Create a worktree from an existing branch
wt add <work_name> <existing_branch_name>

# Create an alias (use "current" alias to switch between tasks)
wt add <work_name> --alias current

# List worktrees
wt list

# Remove a worktree
wt rm <work_name>
```

For more details, see https://github.com/igtm/easy-worktree

## What are Aliases?

Aliases are symbolic links to worktrees. By pointing the same alias name to different worktrees, you can switch between multiple branches using a fixed path.

### Smart Use of Aliases

**Using with VSCode Workspace**

By opening a fixed alias like `current` as a VSCode workspace, you can switch worktrees without needing to reopen VSCode.

```bash
# First task
wt add feature-a --alias current
code current  # Open current in VSCode

# Switch to another task (VSCode stays open)
wt add feature-b --alias current
# The current alias now points to feature-b
```

Benefits of using aliases:
- VSCode workspace settings are preserved
- Extension settings and window layouts are maintained
- No need to reopen the editor when switching branches

## post-add Hook

The `post-add` hook is a script that runs automatically after creating a worktree.

### Use Cases

- Install dependencies (npm install, pip install, etc.)
- Copy configuration files (.env files, etc.)
- Initialize directories
- Create VSCode workspaces

### Available Environment Variables

- `WT_WORKTREE_PATH`: Path to the created worktree
- `WT_WORKTREE_NAME`: Name of the worktree
- `WT_BASE_DIR`: Path to the main repository directory
- `WT_BRANCH`: Branch name
- `WT_ACTION`: Action name (always "add")

### About post-add.local

`post-add.local` is for personal local hooks. This file is included in `.gitignore`, so it won't be committed to the repository. Use `post-add` for hooks you want to share with the team, and `post-add.local` for your personal settings.

`post-add.local` is automatically executed only when `post-add` exists.
