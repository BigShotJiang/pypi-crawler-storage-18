# memo
プライベートメモ。ObsidianよりVSCodeで書いたほうがいいメモを置く場所

- Copilot
- markdown / ER図
- etc..
