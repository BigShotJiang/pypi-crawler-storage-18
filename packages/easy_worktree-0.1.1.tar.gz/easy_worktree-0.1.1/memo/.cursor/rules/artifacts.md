# Web アプリ作成 & Playwright テストモード

このチャットモードでは、ユーザーの要望に応じた Web アプリケーション（HTML、CSS、JavaScript）を作成し、Playwright MCP を使用してブラウザで開いてテストします。

## 技術スタック

作成する Web アプリケーションは以下の技術スタックを使用します：

- **スタイル**: Tailwind CSS
- **フォント**: Google Fonts (Noto Sans JP)
- **アイコン**: Font Awesome

## HTML テンプレート構造

```html
<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{アプリのタイトル}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link
      href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <style>
      {カスタムのスタイルはここに}
    </style>
  </head>
  <body>
    {アプリのコンテンツはここに}
    <script>
      {
        カスタムのJavaScriptはここに;
      }
    </script>
  </body>
</html>
```

## 作業フロー

このモードでは以下の手順で作業を進めます：

1. **要件理解**: ユーザーの要望を詳しく聞き、作成する Web アプリの機能と仕様を明確にする
2. **HTML ファイル作成**: 上記のテンプレートを使用して Web アプリを `artifacts/` フォルダに作成
3. **Playwright 起動**: 作成した HTML ファイルをブラウザで開く
4. **初期画面確認**: スクリーンショットを撮影してレイアウトや見た目を確認
5. **改善提案**: 必要に応じて機能の改善や追加機能を提案

## 対応可能な Web アプリ例

- タスク管理アプリ
- カウンターアプリ
- 計算機
- ToDo リスト
- 簡単なゲーム
- フォーム入力
- データ可視化
- レスポンシブなランディングページ
- その他インタラクティブな Web アプリケーション

## ファイル構造

HTML ファイルは以下の構造で管理します：

```
artifacts/
├── [プロジェクト名]/
│   ├── index.html          # メインのHTMLファイル
│   └── screenshot.png      # 初期画面のスクリーンショット
```

## Playwright MCP でのテスト

作成した Web アプリに対して以下の確認を実行します：

- **初期画面の表示確認**: デフォルトの画面サイズでの表示をスクリーンショット撮影

### スクリーンショット撮影

初期表示のスクリーンショットを `artifacts/[プロジェクト名]/screenshot.png` に保存します。

**注意**: モバイル表示のテストは実施しません。デスクトップ表示の確認のみ行います。

### Playwright での撮影手順

1. **ブラウザ起動とページ読み込み**
   - 作成した HTML ファイルを開く
   - 初期表示のスクリーンショット撮影
   - `screenshot.png` として保存

## 注意事項

- 作成する Web アプリは単一の HTML ファイルで完結するものとします
- 外部 API は使用せず、フロントエンドのみで完結する機能に限定します
- セキュリティ上の理由により、ローカルストレージやクッキーの使用は最小限にします
- モバイルフレンドリーなレスポンシブデザインを心がけます
- 初期画面のスクリーンショットを `screenshot.png` として保存します

