---
marp: true
theme: gaia
header: "**Irhub翻訳プロジェクト** __開発記録__"
footer: "LLMを使った翻訳システムの課題と解決策"
---

# LLM を使った Irhub ファイル翻訳での苦労

> 翻訳特化 API から LLM への移行で直面した技術的課題と解決策

---

# Irhub翻訳機能の説明

- 独自エディタ上での翻訳
- ファイル翻訳(pptx,docx)

<center>
<img src="img/irhub-file.png" width="65%">
</center>

---

## 📈 翻訳ロジックの経緯

### Phase 1: 翻訳特化 API

- **Amazon Translate** → 初期実装、基本的な翻訳
- **Google Translate** → 翻訳モデルの精度向上

### Phase 2: LLM 活用（主にこれ）

- **Claude** → 文脈理解と専門用語対応
- **Gemini (Multimodal)** → 過去 PDF を参考にした翻訳

---

# LLM の呼び出し方と実装

- **JSON mode**での構造化出力
- 分割し並列で API 呼び出し

```json
{
  "1": "私は野球が好きです",
  "2": "明日は晴れです",
  "3": "LLMは便利です"
}
```
```json
{
  "1": "I like baseball.",
  "2": "Tomorrow will be sunny.",
  "3": "LLMs are useful."
}
```

---

# Super LLM Client

- litellm/VertexAIのラッパー
- **JSON mode**での構造化出力 Pydanticのモデルで型付け
- リトライ＆リトライ毎にパラメタを変えられる
- マルチモーダル対応
- Tracing

---

## 📈 訳し方の指示

- **用語集** → 固有名詞・サービス名など
- **学習データ** → 過去資料PDFをMultimodal

<center>
<img src="img/term.png" width="50%">
</center>

---

## 📄 PPTX/DOCX 処理の特殊対応

- スタイル都合で入れてくる改行の検知(MeCab)
- フォントの変換
- disclaimer の挿入

---

## ⚠️ 出力不安定性

- JSON 壊れ
- DSQ(429 エラー)

### 📊 評価の困難

- **人手評価**コストと時間
- 学習データの踏襲

<center>
<img src="img/429.png" width="50%">
</center>

---

## 🔄 トレース

- Datadog APM Custom Metrics
- **APM トレース**: OpenTelemetry + OpenLLMetry
- 暗号化とロギング/トレーシング

<center>
<img src="img/ddtrace.png" width="60%">
</center>

---

## 🤖 LLM 主導のエラー処理フロー

- エラーの管理とトリアージ
  - **Error Tracking** → **Case Management** → **Jira**
- 自動 PR 作成
  - **Lambda(LLM Coder)** → **PR**

<center>
<img src="img/case-management.png" width="60%">
</center>

---

# 開発における LLM の活用

- figma自動実装(MCP) 専用chatmode
- Gemini Canvasによる新機能モック作成
- 問題特定/仕様作成補助(非機能要件)/ドキュメント化/タスクリスト作成
  - モノレポとの相性 ⭕️
- **Snapshot テスト**
- **Storybook**
- etc..

---

# まとめと今後の展望

- **GitHub Copilot/Cursor**がなければなし得なかった開発速度(少人数開発)
- **ここ 1 年の LLM の成長**が著しく、翻訳品質が劇的向上
- 課題
  - LLM 安定性
  - 質の向上・評価
  - pptx/docx 自動スタイル調整

---

# おわり

**ご質問・ディスカッションをお待ちしています！**
