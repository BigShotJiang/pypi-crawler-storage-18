## BHH - A Library for You

## Version: 0.3.4
---

## License
This project is licensed under the BHAP License - see the [LICENSE](LICENSE.txt) file for details.

---

⚠️ Note: To install this library, requests libraries version 2.0.0 or higher and Pillow version 10.0.0 or higher must be installed ⚠️

---

## Features:

🎮 Create your own simple games

🔒 Hash your passwords with both random and chosen salts

🌐 Add a search engine to your app

💻 Install libraries from PyPI

---

## Installation:

pip install bhh

---

## Usage:

```python

import bhh

print(bhh.hash_password("mypassword"))
print(bhh.verify_password("mypassword", "stored_hash"))
print(bhh.hash_password_with_salt("mypassword", "mysalt")) # ⚠️ Note: The format is salt bytes ⚠️
print(bhh.install_from_pypi("requests"))
print(bhh.search_web("Python Tkinter", "YOUR_BING_API_KEY", 5))
print(bhh.create_game_window("up.png", "down.png", "left.png", "right.png", "circle.png", "My Game", "white"))
