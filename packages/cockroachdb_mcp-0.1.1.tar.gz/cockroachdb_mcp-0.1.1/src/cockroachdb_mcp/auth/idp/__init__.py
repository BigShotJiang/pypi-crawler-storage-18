"""CockroachDB MCP IdP adapters."""
