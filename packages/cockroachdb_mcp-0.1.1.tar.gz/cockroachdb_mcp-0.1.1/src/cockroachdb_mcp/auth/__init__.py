"""CockroachDB MCP authentication."""
