"""CockroachDB MCP utilities."""
