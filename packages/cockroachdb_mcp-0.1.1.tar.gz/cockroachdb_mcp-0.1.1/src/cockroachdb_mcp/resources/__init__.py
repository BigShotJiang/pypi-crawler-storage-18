"""CockroachDB MCP resources."""
