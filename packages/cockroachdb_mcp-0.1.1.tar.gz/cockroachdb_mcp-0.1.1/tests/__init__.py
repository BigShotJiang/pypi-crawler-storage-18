"""CockroachDB MCP tests."""
