import base64
from django.template.loader import render_to_string
from turbopdf.core import generate_pdf_from_string
import os
import turbopdf

class BaseFormAssembler:
    def __init__(self, context=None):
        self.context = context or {}
        self.components = []
        self.img_base = self._get_img_base()

    def _get_img_base(self):
        turbopdf_path = os.path.dirname(turbopdf.__file__)
        img_dir = os.path.join(turbopdf_path, 'img')
        img_dir = img_dir.replace('\\', '/')
        return f'file:///{img_dir}'
    
    # ✅ NUEVO MÉTODO: carga fuentes Roboto embebidas (no toca img_base)
    def _get_font_css(self):
        """Devuelve CSS con Roboto embebido en base64 (sin dependencia de SO)"""
        try:
            turbopdf_path = os.path.dirname(turbopdf.__file__)
            font_path = os.path.join(turbopdf_path, 'fonts', 'Roboto-Regular.ttf')
            bold_path = os.path.join(turbopdf_path, 'fonts', 'Roboto-Bold.ttf')
            
            if not os.path.isfile(font_path):
                raise FileNotFoundError(f"Fuente no encontrada: {font_path}")
            if not os.path.isfile(bold_path):
                raise FileNotFoundError(f"Fuente no encontrada: {bold_path}")

            with open(font_path, 'rb') as f:
                regular_b64 = base64.b64encode(f.read()).decode('utf-8')
            with open(bold_path, 'rb') as f:
                bold_b64 = base64.b64encode(f.read()).decode('utf-8')

            return f"""
                @font-face {{
                    font-family: 'Roboto';
                    src: url(data:font/truetype;charset=utf-8;base64,{regular_b64}) format('truetype');
                    font-weight: normal;
                    font-style: normal;
                }}
                @font-face {{
                    font-family: 'Roboto';
                    src: url(data:font/truetype;charset=utf-8;base64,{bold_b64}) format('truetype');
                    font-weight: bold;
                    font-style: normal;
                }}
                body {{
                    font-family: 'Roboto', sans-serif;
                }}
                """
        except Exception as e:
            print(f"[TURBOPDF] ⚠️ Fallback a fuente estándar (error: {e})")
            return "body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }"
        
    def add_component(self, template_name, extra_context=None, wrapper_html=None):
        """
        Agrega un componente al ensamblador.
        
        Args:
            template_name (str): Nombre del template (ej: 'fila_dos.html')
            extra_context (dict): Contexto adicional para el template
            wrapper_html (str): HTML envolvente (ej: '<div style="...">...</div>')
        """
        full_context = {
            **self.context,
            'img_base': self.img_base,
            **(extra_context or {})
        }
        
        rendered = render_to_string(f'sistema/{template_name}', full_context)
        
        if wrapper_html:
            # Si hay wrapper, insertar el componente dentro
            rendered = wrapper_html.replace('{{component}}', rendered)
        
        self.components.append(rendered)
        return self  # Para encadenamiento

    def add_raw_html(self, html):
        """Agrega HTML crudo (útil para divs de página, saltos, etc.)"""
        self.components.append(html)
        return self

    def build(self):
        html_completo = "\n".join(self.components)
        
        # ✅ Obtener CSS de fuentes (nuevo)
        font_css = self._get_font_css()
        
        # ✅ Construir contexto para style.html
        head_context = {
            **self.context,
            'img_base': self._get_img_base(),
            'font_css': font_css  # ← pasa el CSS dinámico
        }
        
        head = render_to_string('sistema/style.html', head_context)

        html_final = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Documento PDF</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            {head}
        </head>
        <body>
            {html_completo}
        </body>
        </html>
        """
        return generate_pdf_from_string(html_final)