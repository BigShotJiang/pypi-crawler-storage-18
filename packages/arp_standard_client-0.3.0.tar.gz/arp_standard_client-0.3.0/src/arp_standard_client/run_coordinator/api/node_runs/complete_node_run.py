from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from arp_standard_model import ErrorEnvelope
from arp_standard_model import NodeRunCompleteRequest
from typing import cast



def _get_kwargs(
    node_run_id: str,
    *,
    body: NodeRunCompleteRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/node-runs/{node_run_id}:complete".format(node_run_id=quote(str(node_run_id), safe=""),),
    }

    _kwargs["json"] = body.model_dump(exclude_none=True)


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | ErrorEnvelope:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 401:
        response_401 = ErrorEnvelope.model_validate(response.json())



        return response_401

    if response.status_code == 403:
        response_403 = ErrorEnvelope.model_validate(response.json())



        return response_403

    response_default = ErrorEnvelope.model_validate(response.json())



    return response_default



def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | ErrorEnvelope]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    node_run_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: NodeRunCompleteRequest,

) -> Response[Any | ErrorEnvelope]:
    """ Complete a NodeRun (composite completion)

    Args:
        node_run_id (str):
        body (NodeRunCompleteRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ErrorEnvelope]
     """


    kwargs = _get_kwargs(
        node_run_id=node_run_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    node_run_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: NodeRunCompleteRequest,

) -> Any | ErrorEnvelope | None:
    """ Complete a NodeRun (composite completion)

    Args:
        node_run_id (str):
        body (NodeRunCompleteRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ErrorEnvelope
     """


    return sync_detailed(
        node_run_id=node_run_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    node_run_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: NodeRunCompleteRequest,

) -> Response[Any | ErrorEnvelope]:
    """ Complete a NodeRun (composite completion)

    Args:
        node_run_id (str):
        body (NodeRunCompleteRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ErrorEnvelope]
     """


    kwargs = _get_kwargs(
        node_run_id=node_run_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    node_run_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: NodeRunCompleteRequest,

) -> Any | ErrorEnvelope | None:
    """ Complete a NodeRun (composite completion)

    Args:
        node_run_id (str):
        body (NodeRunCompleteRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ErrorEnvelope
     """


    return (await asyncio_detailed(
        node_run_id=node_run_id,
client=client,
body=body,

    )).parsed
