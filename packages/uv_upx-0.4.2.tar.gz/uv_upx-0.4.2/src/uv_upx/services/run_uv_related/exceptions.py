class UnresolvedDependencyError(Exception):
    pass
