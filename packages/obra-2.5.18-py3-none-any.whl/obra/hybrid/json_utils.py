"""Utilities for extracting JSON payloads from LLM responses."""

from __future__ import annotations

import re
from typing import Optional


def extract_json_payload(text: str) -> Optional[str]:
    """Extract a JSON object/array from a mixed response.

    Returns the first plausible JSON payload as a string, or None if not found.
    """
    trimmed = text.strip()
    if not trimmed:
        return None

    code_block = re.search(r"```(?:json)?\s*(.*?)```", trimmed, re.DOTALL)
    if code_block:
        candidate = code_block.group(1).strip()
        if candidate:
            return candidate

    for opener, closer in (("{", "}"), ("[", "]")):
        start = trimmed.find(opener)
        end = trimmed.rfind(closer)
        if start != -1 and end != -1 and end > start:
            return trimmed[start : end + 1].strip()

    return None
