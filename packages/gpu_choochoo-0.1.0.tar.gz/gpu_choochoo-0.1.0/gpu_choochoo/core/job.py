class Job:
    def __init__(
        self,
        job_id,
        arrival_time,
        gpus_required,
        duration_sec,
        vram_required_gb,
        gpu_type_required='ANY',
        priority=0.5,
        preferred_gpu_types=None,
        acceptable_gpu_types=None,
        min_vram_per_gpu=None
    ):
        # --- Requirements (Static, from Job Trace) ---
        self.job_id = job_id
        self.arrival_time = float(arrival_time)    # Time job enters the queue (t)

        self.gpus_required = int(gpus_required)
        self.duration_sec = float(duration_sec) # Wall time limit / Estimated duration (critical for Backfilling)
        self.vram_required_gb = float(vram_required_gb)

        self.gpu_type_required = gpu_type_required # e.g., 'A100', 'H100', 'ANY'
        self.preferred_gpu_types = list(preferred_gpu_types or [])
        if acceptable_gpu_types is None:
            if gpu_type_required and gpu_type_required != 'ANY':
                self.acceptable_gpu_types = [gpu_type_required]
            else:
                self.acceptable_gpu_types = []
        else:
            self.acceptable_gpu_types = list(acceptable_gpu_types)
        self.min_vram_per_gpu = float(min_vram_per_gpu) if min_vram_per_gpu is not None else None
        self.priority = float(priority)  # Job priority (0.1 = low, 0.5 = normal, 1.0 = critical)

        # --- Lifecycle Metrics (Dynamic, updated by the Simulator) ---
        self.start_time = None
        self.completion_time = None
        self.assigned_node_id = None
        self.is_running = False

    def get_time_remaining(self, current_time):
        """Calculates the time left until completion, assuming start_time is set."""
        if not self.is_running:
            return self.duration_sec # Or raise an error
            
        time_elapsed = current_time - self.start_time
        return max(0, self.duration_sec - time_elapsed)

    def get_wait_time(self, current_time):
        """Calculates the time spent in the queue or total wait time if started."""
        if self.start_time is not None:
            return self.start_time - self.arrival_time
        return current_time - self.arrival_time

    def start(self, current_time, node_id):
        """Marks the job as running and sets key timestamps."""
        self.start_time = current_time
        self.completion_time = current_time + self.duration_sec
        self.assigned_node_id = node_id
        self.is_running = True
        
    def __repr__(self):
        """Clean representation for debugging."""
        status = "Running" if self.is_running else "Pending"
        pref = self.gpu_type_required if self.gpu_type_required != 'ANY' else (self.preferred_gpu_types[0] if self.preferred_gpu_types else 'ANY')
        return (
            f"Job({self.job_id}, {status}, {self.gpus_required}xGPU, "
            f"{self.vram_required_gb} GB VRAM, Preferred: {pref}, Priority: {self.priority:.2f})"
        )
