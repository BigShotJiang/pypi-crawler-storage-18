class Node:
    def __init__(self, node_id, gpu_type, total_gpus, total_vram_gb):
        # --- Static Capacity ---
        self.node_id = node_id
        self.gpu_type = gpu_type         
        self.total_gpus = total_gpus     
        self.total_vram_gb = total_vram_gb 
        self.vram_per_gpu = (total_vram_gb / total_gpus) if total_gpus else 0
        
        # --- Dynamic State ---
        self.free_gpus = total_gpus
        self.free_vram_gb = total_vram_gb
        
        # Key: Job ID, Value: Job Object. Tracks what is running on this node.
        self.running_jobs = {} 

    def check_feasibility(self, job):
        """Checks if the node has capacity for the job."""
        node_type_ok = True
        if job.acceptable_gpu_types:
            node_type_ok = self.gpu_type in job.acceptable_gpu_types
        elif job.gpu_type_required != 'ANY' and job.gpu_type_required != self.gpu_type:
            node_type_ok = False

        if not node_type_ok:
            return False
            
        if job.gpus_required > self.free_gpus:
            return False
            
        # Simplification: assuming VRAM required per job is a total limit for the job
        if job.vram_required_gb > self.free_vram_gb:
            return False

        if job.min_vram_per_gpu is not None and self.vram_per_gpu < job.min_vram_per_gpu:
            return False
            
        return True

    def allocate(self, job):
        """Allocates resources to the job."""
        if not self.check_feasibility(job):
            raise ValueError(f"Cannot allocate {job.job_id} to {self.node_id}: insufficient resources.")

        self.free_gpus -= job.gpus_required
        self.free_vram_gb -= job.vram_required_gb
        self.running_jobs[job.job_id] = job
        return True
        
    def deallocate(self, job):
        """Frees resources when a job completes."""
        if job.job_id not in self.running_jobs:
            raise ValueError(f"Job {job.job_id} not found on node {self.node_id}")

        self.free_gpus += job.gpus_required
        self.free_vram_gb += job.vram_required_gb
        del self.running_jobs[job.job_id]
        
    def __repr__(self):
        return (f"Node({self.node_id}, {self.gpu_type}, "
                f"Free: {self.free_gpus}/{self.total_gpus} GPUs)")
