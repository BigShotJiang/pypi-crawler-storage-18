class Cluster:
    def __init__(self, nodes_list):
        self.nodes = {node.node_id: node for node in nodes_list}
        self.pending_queue = [] 
        self.completed_jobs = [] 
        self.current_time = 0.0 # Unit is seconds (as determined previously)
        self.job_trace = {}     # Dictionary to hold the future job arrivals (from trace file)

    def process_arrivals(self):
        """Moves jobs from the trace into the pending queue if their time has come."""
        # Find all jobs in the trace scheduled to arrive by the current time
        arrivals = [job_id for job_id, job in self.job_trace.items() 
                    if job.arrival_time <= self.current_time]
        
        for job_id in arrivals:
            job = self.job_trace.pop(job_id)
            self.pending_queue.append(job)
            
        # Re-sort queue by arrival time (FIFO default)
        self.pending_queue.sort(key=lambda j: j.arrival_time)


    def advance_time(self, time_increment):
        """Advances simulation time."""
        self.current_time += time_increment

    def get_earliest_completion_time(self):
        """Finds the time of the next resource-releasing event."""
        min_completion = float('inf')
        for node in self.nodes.values():
            for job in node.running_jobs.values():
                min_completion = min(min_completion, job.completion_time)
        return min_completion
        
    def get_state_for_rl_agent(self):
        """
        Generates the fixed-size RL observation S_t. 
        (Implementation goes here using the arrays defined previously)
        """
        # Placeholder for the actual state encoding logic
        state_vector = {
            'time': self.current_time, # Will be converted to normalized time-relative features
            'nodes': [n.free_gpus for n in self.nodes.values()],
            'queue_size': len(self.pending_queue)
        }
        return state_vector

    def nodes_have_running_jobs(self):
        """Check if any job is still running across all nodes."""
        return any(len(node.running_jobs) > 0 for node in self.nodes.values())