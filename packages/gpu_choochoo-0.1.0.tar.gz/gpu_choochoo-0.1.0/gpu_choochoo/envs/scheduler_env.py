import gymnasium as gym
from gymnasium import spaces
import numpy as np
from copy import deepcopy

from ..core.node import Node
from ..core.cluster import Cluster
from ..core.job import Job


class GPUSchedulerEnv(gym.Env):
    """
    Gymnasium environment for GPU scheduling.

    The agent selects which job from the pending queue to schedule at each decision point.
    The environment advances time to the next event after each action.

    Observation Space:
        - Node states (free GPUs, free VRAM per node)
        - Queue states (job requirements for top N jobs, including priority)
        - Current simulation time

    Action Space:
        - Discrete(max_queue_size + 1): Select job index from queue to schedule
          - 0: No-op (don't schedule anything)
          - 1 to max_queue_size: Schedule job at index (0-indexed in queue)

    Reward:
        Configurable reward types:
        - 'utilization': Delta in utilization
        - 'wait_time': Penalty for wait time increase
        - 'mixed': Balanced utilization and wait time
        - 'sparse_priority': Priority-weighted wait penalty + terminal utilization
    """

    metadata = {'render_modes': ['human', 'ansi']}

    def __init__(
        self,
        nodes_config,
        job_trace_data,
        max_queue_obs=10,
        max_nodes=10,
        reward_type='sparse_priority',
        alpha=0.5,
        verbose=False,
        max_steps=2000,
        schedule_interval=60.0
    ):
        """
        Args:
            nodes_config: List of Node objects or dict configs
            job_trace_data: List of job dictionaries
            max_queue_obs: Maximum number of queue jobs to include in observation
            max_nodes: Maximum number of nodes in observation space
            reward_type: 'utilization', 'wait_time', 'mixed', or 'sparse_priority'
            alpha: scaling coefficient for 'mixed' or 'sparse_priority' reward types such that reward = alpha * utilization_reward + (1-alpha) * wait_time_reward
            verbose: Print scheduling decisions
            max_steps: Maximum scheduling decisions per episode
            schedule_interval: Time between scheduling decisions (seconds)
        """
        super().__init__()

        self.nodes_config = nodes_config
        self.job_trace_data = job_trace_data
        self.max_queue_obs = max_queue_obs
        self.max_nodes = max_nodes
        self.reward_type = reward_type
        self.alpha = alpha
        if self.reward_type in ['mixed', 'sparse_priority'] and not self.alpha:
            raise ValueError("Must define alpha for 'mixed' or 'sparse_priority' reward types")

        self.verbose = verbose
        self.max_steps = max_steps
        self.schedule_interval = schedule_interval

        # Initialize cluster and state
        self.cluster = None
        self.event_queue = []
        self.total_gpu_time = 0
        self.used_gpu_time = 0
        self.last_time = 0
        self.steps = 0

        # Define action space: 0 = no-op, 1-N = schedule job at index
        self.action_space = spaces.Discrete(max_queue_obs + 1)

        # Define observation space
        self.observation_space = spaces.Dict({
            # Node features: [free_gpus, total_gpus, free_vram, total_vram] per node
            'nodes': spaces.Box(
                low=0, high=1000,
                shape=(max_nodes, 4),
                dtype=np.float32
            ),
            # Queue features: [gpus_req, vram_req, duration, gpu_type_encoding, wait_time, priority] per job
            'queue': spaces.Box(
                low=0, high=100000,
                shape=(max_queue_obs, 6),
                dtype=np.float32
            ),
            # Running jobs per node: [gpus_used, vram_used, time_remaining, num_jobs] per node
            'running_jobs_per_node': spaces.Box(
                low=0, high=100000,
                shape=(max_nodes, 4),
                dtype=np.float32
            ),
            # Running jobs details: [node_idx, gpus_req, vram_req, time_remaining] per job
            # Max running jobs = max_nodes * max GPUs per node (assume max 16 GPUs/node)
            'running_jobs': spaces.Box(
                low=0, high=100000,
                shape=(max_nodes * 16, 4),
                dtype=np.float32
            ),
            # Scalar features
            'queue_size': spaces.Box(low=0, high=1000, shape=(1,), dtype=np.int32),
            'num_nodes': spaces.Box(low=0, high=max_nodes, shape=(1,), dtype=np.int32),
            'num_running': spaces.Box(low=0, high=1000, shape=(1,), dtype=np.int32),
        })

    def reset(self, seed=None, options=None):
        """Reset the environment to initial state."""
        super().reset(seed=seed)

        # Create fresh cluster
        if isinstance(self.nodes_config[0], Node):
            nodes = [Node(n.node_id, n.gpu_type, n.total_gpus, n.total_vram_gb)
                    for n in self.nodes_config]
        else:
            nodes = [Node(**config) for config in self.nodes_config]

        self.cluster = Cluster(nodes)

        # Load job trace and filter out infeasible jobs
        feasible_jobs = 0
        infeasible_jobs = 0

        for job_data in self.job_trace_data:
            job = Job(**job_data)

            # Check if job can ever be scheduled on any node
            can_schedule = False
            for node in self.cluster.nodes.values():
                type_match = True
                if job.acceptable_gpu_types:
                    type_match = node.gpu_type in job.acceptable_gpu_types
                elif job.gpu_type_required not in ('ANY', None):
                    type_match = job.gpu_type_required == node.gpu_type

                per_gpu_vram_ok = True
                if job.min_vram_per_gpu is not None:
                    per_gpu_vram_ok = node.vram_per_gpu >= job.min_vram_per_gpu

                if (job.gpus_required <= node.total_gpus and
                    job.vram_required_gb <= node.total_vram_gb and
                    type_match and per_gpu_vram_ok):
                    can_schedule = True
                    break

            if can_schedule:
                self.cluster.job_trace[job.job_id] = job
                feasible_jobs += 1
            else:
                infeasible_jobs += 1
                if self.verbose:
                    print(f"WARNING: Skipping infeasible job {job.job_id}: "
                          f"{job.gpus_required} GPUs, {job.vram_required_gb:.1f} GB VRAM, "
                          f"type={job.gpu_type_required}")

        if infeasible_jobs > 0 and self.verbose:
            print(f"Filtered {infeasible_jobs} infeasible jobs, kept {feasible_jobs}")

        # Initialize event queue with arrivals
        self.event_queue = []
        for job_id, job in self.cluster.job_trace.items():
            self.event_queue.append((job.arrival_time, 'ARRIVAL', job_id))
        self.event_queue.sort(key=lambda x: x[0])

        # Reset metrics
        self.total_gpu_time = 0
        self.used_gpu_time = 0
        self.last_time = 0
        self.cluster.current_time = 0.0
        self.steps = 0

        # Process initial arrivals at t=0
        self._process_arrivals()

        observation = self._get_observation()
        info = self._get_info()

        return observation, info

    def step(self, action):
        """
        Execute one scheduling decision and advance by schedule_interval.

        Args:
            action: Integer in [0, max_queue_obs]
                - 0: No-op
                - 1+: Schedule job at index (action - 1) from queue

        Returns:
            observation, reward, terminated, truncated, info
        """
        # Increment step counter
        self.steps += 1

        # Record metrics before action
        prev_utilization = self._compute_current_utilization()
        prev_wait_time = self._compute_total_wait_time()

        # Execute scheduling action
        scheduled = self._execute_action(action)

        # Advance simulation by one scheduling interval
        self._advance_by_time_interval()

        # Compute reward
        reward = self._compute_reward(prev_utilization, prev_wait_time, scheduled)

        # Check if episode is done
        terminated = self._is_terminated()
        truncated = self.steps >= self.max_steps

        observation = self._get_observation()
        info = self._get_info()
        info['scheduled'] = scheduled

        return observation, reward, terminated, truncated, info

    def _execute_action(self, action):
        """
        Execute the scheduling action.

        Args:
            action: 0 for no-op, 1+ for scheduling job at index (action-1)

        Returns:
            bool: True if a job was successfully scheduled
        """
        if action == 0 or not self.cluster.pending_queue:
            if self.verbose:
                print(f"[{self.cluster.current_time:.1f}s] ACTION: No-op")
            return False

        # Map action to queue index (action 1 = index 0)
        job_index = action - 1

        if job_index >= len(self.cluster.pending_queue):
            if self.verbose:
                print(f"[{self.cluster.current_time:.1f}s] ACTION: Invalid job index {job_index}")
            return False

        job = self.cluster.pending_queue[job_index]

        # Find best placement for this job
        best_node = self._find_best_placement(job)

        if best_node is None:
            if self.verbose:
                print(f"[{self.cluster.current_time:.1f}s] ACTION: Cannot schedule {job.job_id} (insufficient resources)")
            return False

        # Execute schedule
        self.cluster.pending_queue.remove(job)
        best_node.allocate(job)
        job.start(self.cluster.current_time, best_node.node_id)

        if self.verbose:
            print(f"[{self.cluster.current_time:.1f}s] ACTION: Scheduled {job.job_id} on {best_node.node_id}")
            print(f"  Node Status: {best_node.free_gpus}/{best_node.total_gpus} GPUs free")

        return True

    def _find_best_placement(self, job):
        """Find the best-fit node for a job (same logic as heuristic)."""
        best_node = None
        best_score = (float('inf'), float('inf'))
        preference_rank = {gpu_type: idx for idx, gpu_type in enumerate(job.preferred_gpu_types)}

        for node in self.cluster.nodes.values():
            if node.check_feasibility(job):
                fragmentation = node.free_gpus - job.gpus_required
                pref_score = preference_rank.get(node.gpu_type, len(preference_rank))
                candidate = (pref_score, fragmentation)
                if candidate < best_score:
                    best_score = candidate
                    best_node = node

        return best_node

    def _advance_by_time_interval(self):
        """
        Advance to next event OR schedule_interval, whichever comes first.

        This hybrid approach:
        - Stops at events when they occur (event-driven)
        - Makes periodic decisions when no events (synchronous)
        - Bounds total steps while not missing opportunities
        """
        # Calculate target time (end of scheduling interval)
        target_time = self.cluster.current_time + self.schedule_interval

        # Check if there's an event before the interval ends
        if self.event_queue:
            next_event_time, event_type, event_data = self.event_queue[0]

            if next_event_time <= target_time:
                # Event occurs before interval ends - stop at event
                self.event_queue.pop(0)

                # Advance to event time
                self.cluster.current_time = next_event_time
                self._update_utilization_metrics()

                # Handle completions at this time
                self._handle_completion_events()

                # Handle arrival event
                if event_type == 'ARRIVAL':
                    self._handle_arrival_event(event_data)

                return  # Return control to agent at event time

        # No events before interval end - check for job completions
        # Find if any job completes before target_time
        earliest_completion = float('inf')
        if self.cluster.nodes_have_running_jobs():
            earliest_completion = self.cluster.get_earliest_completion_time()

        if earliest_completion <= target_time:
            # Job completes before interval - stop at completion
            self.cluster.current_time = earliest_completion
            self._update_utilization_metrics()
            self._handle_completion_events()
            return

        # No events - advance full interval
        self.cluster.current_time = target_time
        self._update_utilization_metrics()
        self._handle_completion_events()

    def _process_arrivals(self):
        """Process all job arrivals at current time."""
        arrivals = [job_id for job_id, job in self.cluster.job_trace.items()
                   if job.arrival_time <= self.cluster.current_time]

        for job_id in arrivals:
            job = self.cluster.job_trace.pop(job_id)
            self.cluster.pending_queue.append(job)

        self.cluster.pending_queue.sort(key=lambda j: j.arrival_time)

    def _handle_arrival_event(self, job_id):
        """Handle a job arrival."""
        if job_id in self.cluster.job_trace:
            job = self.cluster.job_trace.pop(job_id)
            self.cluster.pending_queue.append(job)
            self.cluster.pending_queue.sort(key=lambda j: j.arrival_time)

            if self.verbose:
                print(f"[{self.cluster.current_time:.1f}s] EVENT: {job_id} arrived")

    def _handle_completion_events(self):
        """Handle all job completions at or before current time."""
        for node in self.cluster.nodes.values():
            completed_jobs = []

            for job_id, job in list(node.running_jobs.items()):
                if self.cluster.current_time >= job.completion_time:
                    completed_jobs.append(job)

            for job in completed_jobs:
                node.deallocate(job)
                job.is_running = False
                self.cluster.completed_jobs.append(job)

                if self.verbose:
                    print(f"[{self.cluster.current_time:.1f}s] EVENT: {job.job_id} completed")

    def _update_utilization_metrics(self):
        """Update GPU utilization metrics."""
        time_delta = self.cluster.current_time - self.last_time

        if time_delta > 0:
            # Calculate total and used GPU-time for this interval
            total_gpus = sum(node.total_gpus for node in self.cluster.nodes.values())
            used_gpus = sum(node.total_gpus - node.free_gpus
                          for node in self.cluster.nodes.values())

            self.total_gpu_time += total_gpus * time_delta
            self.used_gpu_time += used_gpus * time_delta

        self.last_time = self.cluster.current_time

    def _compute_current_utilization(self):
        """Compute current GPU utilization percentage."""
        if self.total_gpu_time == 0:
            return 0.0
        return (self.used_gpu_time / self.total_gpu_time) * 100

    def _compute_total_wait_time(self):
        """Compute total wait time for all jobs in queue."""
        total_wait = 0
        for job in self.cluster.pending_queue:
            total_wait += job.get_wait_time(self.cluster.current_time)
        return total_wait

    def _compute_priority_weighted_wait_time(self):
        """Compute priority-weighted wait time for all jobs in queue."""
        weighted_wait = 0
        for job in self.cluster.pending_queue:
            wait_time = job.get_wait_time(self.cluster.current_time)
            weighted_wait += job.priority * wait_time
        return weighted_wait

    def _compute_reward(self, prev_utilization, prev_wait_time, scheduled):
        """
        Compute reward based on configured reward type.

        Args:
            prev_utilization: Utilization before action
            prev_wait_time: Total wait time before action
            scheduled: Whether a job was scheduled
        """
        if self.reward_type == 'utilization':
            # Reward for increasing utilization
            curr_utilization = self._compute_current_utilization()
            reward = (curr_utilization - prev_utilization) * 10

        elif self.reward_type == 'wait_time':
            # Penalty for job wait time
            curr_wait_time = self._compute_total_wait_time()
            reward = -(curr_wait_time - prev_wait_time) / 100

        elif self.reward_type == 'mixed':
            # Balanced reward
            util_delta = self._compute_current_utilization() - prev_utilization
            wait_delta = self._compute_total_wait_time() - prev_wait_time
            reward = util_delta * 5 - wait_delta

        elif self.reward_type == 'sparse_priority':
            # Sparse reward with priority-weighted wait time penalty
            reward = 0.0

            # Priority-weighted wait penalty (dense signal)
            if len(self.cluster.pending_queue) > 0:
                weighted_wait = self._compute_priority_weighted_wait_time()
                # Normalize by 1 hour, cap at -50.0
                wait_penalty = -min(weighted_wait / 3600, 50.0)
                reward += wait_penalty

            # Large terminal reward for final utilization (sparse signal)
            if self._is_terminated():
                final_util = self._compute_current_utilization()
                print(final_util)
                reward += final_util  # 0-100, dominates wait penalty
                print(reward)

        else:
            reward = 0.0

        # Small bonus for successful scheduling (not for sparse_priority)
        if scheduled and self.reward_type != 'sparse_priority':
            reward += 0.1

        return float(reward)

    def _is_terminated(self):
        """Check if episode is complete (all jobs finished)."""
        no_pending = len(self.cluster.pending_queue) == 0
        no_trace = len(self.cluster.job_trace) == 0
        no_running = not self.cluster.nodes_have_running_jobs()

        return no_pending and no_trace and no_running

    def _get_observation(self):
        """Construct observation dictionary."""
        # Node features: [free_gpus, total_gpus, free_vram, total_vram]
        nodes_array = np.zeros((self.max_nodes, 4), dtype=np.float32)
        for i, node in enumerate(list(self.cluster.nodes.values())[:self.max_nodes]):
            nodes_array[i] = [
                node.free_gpus,
                node.total_gpus,
                node.free_vram_gb,
                node.total_vram_gb
            ]

        # Queue features: [gpus_req, vram_req, duration, gpu_type, wait_time, priority]
        queue_array = np.zeros((self.max_queue_obs, 6), dtype=np.float32)
        for i, job in enumerate(self.cluster.pending_queue[:self.max_queue_obs]):
            gpu_type_indicator = job.gpu_type_required
            if gpu_type_indicator in (None, 'ANY') and job.preferred_gpu_types:
                gpu_type_indicator = job.preferred_gpu_types[0]
            gpu_type_encoding = self._encode_gpu_type(gpu_type_indicator)
            wait_time = job.get_wait_time(self.cluster.current_time)
            queue_array[i] = [
                job.gpus_required,
                job.vram_required_gb,
                job.duration_sec,
                gpu_type_encoding,
                wait_time,
                job.priority
            ]

        # Running jobs per node: [gpus_used, vram_used, time_remaining, num_jobs]
        running_per_node = np.zeros((self.max_nodes, 4), dtype=np.float32)
        node_list = list(self.cluster.nodes.values())[:self.max_nodes]

        for i, node in enumerate(node_list):
            gpus_used = node.total_gpus - node.free_gpus
            vram_used = node.total_vram_gb - node.free_vram_gb
            num_jobs = len(node.running_jobs)

            # Find minimum time remaining across all jobs on this node
            min_time_remaining = float('inf')
            if node.running_jobs:
                for job in node.running_jobs.values():
                    time_remaining = job.get_time_remaining(self.cluster.current_time)
                    min_time_remaining = min(min_time_remaining, time_remaining)

            if min_time_remaining == float('inf'):
                min_time_remaining = 0

            running_per_node[i] = [
                gpus_used,
                vram_used,
                min_time_remaining,
                num_jobs
            ]

        # Running jobs details: [node_idx, gpus_req, vram_req, time_remaining]
        max_running = self.max_nodes * 16
        running_jobs_array = np.zeros((max_running, 4), dtype=np.float32)

        job_idx = 0
        for node_idx, node in enumerate(node_list):
            for job in node.running_jobs.values():
                if job_idx >= max_running:
                    break

                time_remaining = job.get_time_remaining(self.cluster.current_time)
                running_jobs_array[job_idx] = [
                    node_idx,
                    job.gpus_required,
                    job.vram_required_gb,
                    time_remaining
                ]
                job_idx += 1

        total_running = job_idx

        return {
            'nodes': nodes_array,
            'queue': queue_array,
            'running_jobs_per_node': running_per_node,
            'running_jobs': running_jobs_array,
            'queue_size': np.array([len(self.cluster.pending_queue)], dtype=np.int32),
            'num_nodes': np.array([len(self.cluster.nodes)], dtype=np.int32),
            'num_running': np.array([total_running], dtype=np.int32),
        }

    def _encode_gpu_type(self, gpu_type):
        """Encode GPU type as integer."""
        encoding = {
            'ANY': 0,
            'V100': 1,
            'A100': 2,
            'A100-40GB': 2,
            'A100-80GB': 3,
            'H100': 4,
        }
        return encoding.get(gpu_type, 0)

    def _get_info(self):
        """Return additional information."""
        return {
            'current_time': self.cluster.current_time,
            'utilization': self._compute_current_utilization(),
            'queue_size': len(self.cluster.pending_queue),
            'completed_jobs': len(self.cluster.completed_jobs),
            'total_jobs': len(self.job_trace_data),
        }

    def render(self, mode='human'):
        """Render the environment state."""
        if mode == 'human':
            print(f"\n{'='*60}")
            print(f"Time: {self.cluster.current_time:.1f}s")
            print(f"Utilization: {self._compute_current_utilization():.2f}%")
            print(f"Queue Size: {len(self.cluster.pending_queue)}")
            print(f"Completed: {len(self.cluster.completed_jobs)}/{len(self.job_trace_data)}")
            print(f"{'='*60}\n")
