from gpu_choochoo.envs.scheduler_env import GPUSchedulerEnv


def test_job_prefers_high_tier_and_enforces_min_vram():
    """Jobs with preferred/acceptable GPU types and min VRAM should respect those constraints."""
    nodes_config = [
        {
            "node_id": "Node-H100",
            "gpu_type": "H100",
            "total_gpus": 8,
            "total_vram_gb": 640.0,  # 80 GB per GPU
        },
        {
            "node_id": "Node-A100-40",
            "gpu_type": "A100-40GB",
            "total_gpus": 8,
            "total_vram_gb": 320.0,  # 40 GB per GPU
        },
    ]
    job_trace = [
        {
            "job_id": "J-pref",
            "arrival_time": 0.0,
            "gpus_required": 4,
            "vram_required_gb": 280.0,
            "duration_sec": 3600,
            "gpu_type_required": "ANY",
            "preferred_gpu_types": ["H100", "A100-80GB"],
            "acceptable_gpu_types": ["H100", "A100-80GB"],
            "min_vram_per_gpu": 70.0,
            "priority": 0.5,
        }
    ]

    env = GPUSchedulerEnv(
        nodes_config=nodes_config,
        job_trace_data=job_trace,
        max_queue_obs=5,
        max_nodes=2,
        reward_type="utilization",
        schedule_interval=60.0,
    )

    env.reset()
    job = env.cluster.pending_queue[0]

    # Low-tier node should fail feasibility due to per-GPU VRAM and acceptable type list.
    low_tier_node = env.cluster.nodes["Node-A100-40"]
    assert not low_tier_node.check_feasibility(job)

    # High-tier node should satisfy the constraints and be chosen by placement logic.
    high_tier_node = env.cluster.nodes["Node-H100"]
    assert high_tier_node.check_feasibility(job)
    chosen_node = env._find_best_placement(job)
    assert chosen_node.node_id == "Node-H100"
