"""
Benchmark baseline schedulers on diverse realistic scenarios.

This establishes proper baselines by evaluating:
- EASY Backfilling
- Shortest Job First (SJF)
- Pure FCFS

On the same distribution of scenarios that RL agents will train on.
"""

import numpy as np
from gpu_choochoo.core.node import Node
from gpu_choochoo.core.cluster import Cluster
from gpu_choochoo.schedulers.heuristic import (
    BestFitBackfillScheduler,
    ShortestJobFirstScheduler,
    PureFCFSScheduler
)
from gpu_choochoo.simulation.driver import SimulatorDriver
from gpu_choochoo.simulation.workload import RealisticWorkloadGenerator
from gpu_choochoo.wrappers.multi_scenario_wrapper import create_test_scenarios


def run_baseline_on_scenario(scheduler_class, scenario, verbose=False):
    """Run a baseline scheduler on a single scenario."""
    # Create fresh cluster
    nodes = [
        Node(
            node['node_id'],
            node['gpu_type'],
            node['total_gpus'],
            node['total_vram_gb']
        )
        for node in scenario['nodes']
    ]
    cluster = Cluster(nodes)

    # Create scheduler
    scheduler = scheduler_class(cluster)

    # Filter infeasible jobs (same as gym env does)
    feasible_jobs = []
    for job_data in scenario['jobs']:
        job_gpus = int(job_data['gpus_required'])
        job_vram = float(job_data['vram_required_gb'])
        job_type = job_data['gpu_type_required']

        # Check if job can fit on any node
        can_schedule = False
        for node in nodes:
            if (job_gpus <= node.total_gpus and
                job_vram <= node.total_vram_gb and
                (job_type == 'ANY' or job_type == node.gpu_type)):
                can_schedule = True
                break

        if can_schedule:
            feasible_jobs.append(job_data)

    if not feasible_jobs:
        return None  # No feasible jobs in scenario

    # Run simulation
    driver = SimulatorDriver(cluster, scheduler, feasible_jobs)

    # Suppress print statements
    if not verbose:
        import sys
        import io
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()

    try:
        driver.run_simulation()
    finally:
        if not verbose:
            sys.stdout = old_stdout

    # Extract metrics
    total_gpu_hours = sum(
        node.total_gpus * cluster.current_time / 3600
        for node in cluster.nodes.values()
    )

    used_gpu_hours = sum(
        job.gpus_required * job.duration_sec / 3600
        for job in cluster.completed_jobs
    )

    utilization = (used_gpu_hours / total_gpu_hours * 100) if total_gpu_hours > 0 else 0

    avg_wait_time = (
        sum(job.get_wait_time(job.completion_time) for job in cluster.completed_jobs) /
        len(cluster.completed_jobs)
    ) if cluster.completed_jobs else 0

    return {
        'utilization': utilization,
        'avg_wait_time': avg_wait_time,
        'completed_jobs': len(cluster.completed_jobs),
        'total_jobs': len(feasible_jobs),
        'simulation_time': cluster.current_time / 3600,  # hours
        'total_gpu_hours': total_gpu_hours,
        'used_gpu_hours': used_gpu_hours
    }


def benchmark_scheduler(scheduler_class, scheduler_name, scenarios, verbose=False):
    """Benchmark a scheduler across multiple scenarios."""
    print(f"\n{'='*70}")
    print(f"Benchmarking: {scheduler_name}")
    print(f"{'='*70}")

    results_by_difficulty = {'easy': [], 'medium': [], 'hard': [], 'all': []}

    for i, scenario in enumerate(scenarios):
        if verbose:
            print(f"\nScenario {i+1}/{len(scenarios)}...")

        result = run_baseline_on_scenario(scheduler_class, scenario, verbose=False)

        if result is None:
            continue

        difficulty = scenario['metadata']['difficulty']
        result['difficulty'] = difficulty
        result['scenario_idx'] = i

        results_by_difficulty['all'].append(result)
        results_by_difficulty[difficulty].append(result)

        if verbose or (i+1) % 5 == 0:
            print(f"  Scenario {i+1}: {difficulty:6s} - "
                  f"Util={result['utilization']:5.1f}%, "
                  f"Jobs={result['completed_jobs']}/{result['total_jobs']}")

    # Aggregate statistics
    print(f"\n{scheduler_name} Results:")
    print(f"{'='*70}")

    for difficulty in ['easy', 'medium', 'hard', 'all']:
        results = results_by_difficulty[difficulty]

        if not results:
            continue

        utils = [r['utilization'] for r in results]
        waits = [r['avg_wait_time'] for r in results]

        print(f"\n{difficulty.upper()}:")
        print(f"  Scenarios: {len(results)}")
        print(f"  Utilization: {np.mean(utils):.2f}% ± {np.std(utils):.2f}%")
        print(f"  Range: [{np.min(utils):.1f}%, {np.max(utils):.1f}%]")
        print(f"  Median: {np.median(utils):.2f}%")
        print(f"  Avg Wait Time: {np.mean(waits)/60:.1f} minutes")

    return results_by_difficulty


def main():
    """Run comprehensive baseline benchmark."""
    print("="*70)
    print("BASELINE SCHEDULER BENCHMARK ON REALISTIC SCENARIOS")
    print("="*70)

    # Generate diverse test scenarios
    print("\nGenerating test scenarios...")
    generator = RealisticWorkloadGenerator(seed=42)

    scenarios = []
    num_per_difficulty = 10

    for difficulty in ['easy', 'medium', 'hard']:
        for i in range(num_per_difficulty):
            scenario = generator.generate_scenario(difficulty, seed=42+i)
            scenarios.append(scenario)

    print(f"Created {len(scenarios)} scenarios:")
    print(f"  Easy: {num_per_difficulty}")
    print(f"  Medium: {num_per_difficulty}")
    print(f"  Hard: {num_per_difficulty}")

    # Benchmark each scheduler
    schedulers = [
        (BestFitBackfillScheduler, "EASY Backfilling"),
        (ShortestJobFirstScheduler, "Shortest Job First"),
        (PureFCFSScheduler, "Pure FCFS")
    ]

    all_results = {}

    for scheduler_class, scheduler_name in schedulers:
        results = benchmark_scheduler(
            scheduler_class,
            scheduler_name,
            scenarios,
            verbose=False
        )
        all_results[scheduler_name] = results

    # Final comparison
    print(f"\n{'='*70}")
    print("BASELINE COMPARISON SUMMARY")
    print(f"{'='*70}")

    print(f"\n{'Scheduler':<25} | {'Overall':<12} | {'Easy':<12} | {'Medium':<12} | {'Hard':<12}")
    print("-"*90)

    for scheduler_name in ["EASY Backfilling", "Shortest Job First", "Pure FCFS"]:
        results = all_results[scheduler_name]

        overall = np.mean([r['utilization'] for r in results['all']])
        easy = np.mean([r['utilization'] for r in results['easy']]) if results['easy'] else 0
        medium = np.mean([r['utilization'] for r in results['medium']]) if results['medium'] else 0
        hard = np.mean([r['utilization'] for r in results['hard']]) if results['hard'] else 0

        print(f"{scheduler_name:<25} | {overall:5.2f}% ± {np.std([r['utilization'] for r in results['all']]):4.2f} | "
              f"{easy:5.2f}% ± {np.std([r['utilization'] for r in results['easy']]):4.2f} | "
              f"{medium:5.2f}% ± {np.std([r['utilization'] for r in results['medium']]):4.2f} | "
              f"{hard:5.2f}% ± {np.std([r['utilization'] for r in results['hard']]):4.2f}")

    # Determine target
    best_overall = max(
        np.mean([r['utilization'] for r in results['all']])
        for results in all_results.values()
    )

    print(f"\n{'='*70}")
    print(f"TARGET FOR RL AGENT: Beat {best_overall:.2f}% average utilization")
    print(f"{'='*70}")

    # Save results
    import json
    with open('baseline_results.json', 'w') as f:
        # Convert to JSON-serializable format
        serializable_results = {}
        for scheduler_name, results in all_results.items():
            serializable_results[scheduler_name] = {
                difficulty: [
                    {k: float(v) if isinstance(v, (np.floating, float)) else v
                     for k, v in r.items()}
                    for r in result_list
                ]
                for difficulty, result_list in results.items()
            }
        json.dump(serializable_results, f, indent=2)

    print("\nResults saved to baseline_results.json")


if __name__ == "__main__":
    main()
