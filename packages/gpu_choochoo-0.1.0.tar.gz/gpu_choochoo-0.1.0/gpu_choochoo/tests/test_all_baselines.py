from gpu_choochoo.core.node import Node
from gpu_choochoo.core.cluster import Cluster
from gpu_choochoo.schedulers.heuristic import BestFitBackfillScheduler, PureFCFSScheduler, ShortestJobFirstScheduler
from gpu_choochoo.simulation.driver import SimulatorDriver

# --- Setup Data ---
# 1. Cluster Nodes
NODES = [
    Node("Node-A100-01", "A100", 8, 320.0), # 8x A100
    Node("Node-H100-01", "H100", 4, 160.0), # 4x H100
]

# 2. Sample Job Trace
JOB_TRACE_DATA = [
    {
        "job_id": "J01",
        "arrival_time": "0.0",
        "gpus_required": "4",
        "vram_required_gb": "160.0",
        "duration_sec": "7200",
        "gpu_type_required": "A100"
    },
    {
        "job_id": "J02",
        "arrival_time": "10.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "300",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J03",
        "arrival_time": "20.0",
        "gpus_required": "8",
        "vram_required_gb": "320.0",
        "duration_sec": "1800",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J04",
        "arrival_time": "30.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "60",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J05",
        "arrival_time": "60.0",
        "gpus_required": "4",
        "vram_required_gb": "160.0",
        "duration_sec": "3600",
        "gpu_type_required": "H100"
    },
    {
        "job_id": "J06",
        "arrival_time": "90.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "600",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J07",
        "arrival_time": "120.0",
        "gpus_required": "5",
        "vram_required_gb": "200.0",
        "duration_sec": "900",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J08",
        "arrival_time": "150.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "120",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J09",
        "arrival_time": "180.0",
        "gpus_required": "3",
        "vram_required_gb": "120.0",
        "duration_sec": "1800",
        "gpu_type_required": "A100"
    },
    {
        "job_id": "J10",
        "arrival_time": "240.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "60",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J11",
        "arrival_time": "300.0",
        "gpus_required": "2",
        "vram_required_gb": "80.0",
        "duration_sec": "300",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J12",
        "arrival_time": "600.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "14400",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J13",
        "arrival_time": "900.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "60",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J14",
        "arrival_time": "1200.0",
        "gpus_required": "8",
        "vram_required_gb": "320.0",
        "duration_sec": "3600",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J15",
        "arrival_time": "1800.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "120",
        "gpu_type_required": "ANY"
    },
    {
        "job_id": "J16",
        "arrival_time": "3600.0",
        "gpus_required": "1",
        "vram_required_gb": "40.0",
        "duration_sec": "300",
        "gpu_type_required": "ANY"
    }
]


def run_scheduler_test(scheduler_name, scheduler_class):
    """Run simulation with specified scheduler"""
    print(f"\n{'='*60}")
    print(f"Testing: {scheduler_name}")
    print(f"{'='*60}\n")

    # Create fresh cluster and scheduler instances
    nodes = [
        Node("Node-A100-01", "A100", 8, 320.0),
        Node("Node-H100-01", "H100", 4, 160.0),
    ]
    cluster = Cluster(nodes)
    scheduler = scheduler_class(cluster)
    driver = SimulatorDriver(cluster, scheduler, JOB_TRACE_DATA)
    driver.run_simulation()

def test_best_fit_backfill_runs():
    run_scheduler_test("BestFit", BestFitBackfillScheduler)

def test_fcfs_runs():
    run_scheduler_test("FCFS", PureFCFSScheduler)

def test_sjf_runs():
    run_scheduler_test("SJF", ShortestJobFirstScheduler)

if __name__ == "__main__":
    # Test all three schedulers
    schedulers = [
        ("EASY Backfilling (BestFit + Backfill)", BestFitBackfillScheduler),
        ("Pure FCFS (No Backfilling)", PureFCFSScheduler),
        ("Shortest Job First (SJF)", ShortestJobFirstScheduler),
    ]



