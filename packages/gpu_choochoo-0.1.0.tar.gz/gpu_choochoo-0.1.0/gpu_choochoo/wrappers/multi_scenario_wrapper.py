"""
Multi-Scenario Wrapper for GPU Scheduler Environment

Enables training on diverse scenarios to improve RL agent generalization.
Uses realistic workload generator for statistically valid scenarios.
"""

import gymnasium as gym
import numpy as np
from typing import List, Dict, Optional
from ..envs.scheduler_env import GPUSchedulerEnv
from ..simulation.workload import RealisticWorkloadGenerator


class MultiScenarioWrapper(gym.Wrapper):
    """
    Wrapper that samples from multiple scenarios each episode.

    Forces agent to learn general scheduling policy rather than
    overfitting to a single cluster/workload configuration.
    """

    def __init__(
        self,
        scenarios: List[Dict],
        max_queue_obs: int = 20,
        max_nodes: int = 10,
        reward_type: str = 'mixed',
        verbose: bool = False,
        scenario_sampling: str = 'uniform',
        curriculum_episodes: int = 1000,
        max_steps: int = 2000,
        schedule_interval: float = 60.0,
        seed: int = 42
    ):
        """
        Args:
            scenarios: List of dicts with 'nodes', 'jobs', optional 'metadata'
            max_queue_obs: Max queue size in observation
            max_nodes: Max nodes in observation
            reward_type: Reward function type
            verbose: Print debug info
            scenario_sampling: 'uniform', 'curriculum', or 'difficulty-weighted'
            curriculum_episodes: Episodes to complete curriculum (if using)
            max_steps: Maximum steps per episode (fallback if can't estimate from scenario)
            schedule_interval: Time between scheduling decisions in seconds
            seed: Seed for the PRNG
        """
        self.scenarios = scenarios
        self.scenario_sampling = scenario_sampling
        self.curriculum_episodes = curriculum_episodes
        self.current_scenario_idx = 0
        self.episode_count = 0

        # Initialize RNG
        self.rng = np.random.default_rng(seed)

        # Validate scenarios
        self._validate_scenarios(max_nodes, max_queue_obs)

        # Compute difficulty scores for weighted sampling
        self._compute_difficulty_scores()

        # Create base environment
        base_env = GPUSchedulerEnv(
            nodes_config=scenarios[0]['nodes'],
            job_trace_data=scenarios[0]['jobs'],
            max_queue_obs=max_queue_obs,
            max_nodes=max_nodes,
            reward_type=reward_type,
            verbose=verbose
        )

        super().__init__(base_env)

        # Store config
        self.max_queue_obs = max_queue_obs
        self.max_nodes = max_nodes
        self.reward_type = reward_type
        self.verbose = verbose
        self.max_steps = max_steps
        self.schedule_interval = schedule_interval

        # Statistics tracking
        self.scenario_episodes = [0] * len(scenarios)
        self.scenario_rewards = [[] for _ in scenarios]

    def _validate_scenarios(self, max_nodes: int, max_queue_obs: int):
        """Ensure all scenarios fit in observation space."""
        for i, scenario in enumerate(self.scenarios):
            num_nodes = len(scenario['nodes'])
            if num_nodes > max_nodes:
                raise ValueError(
                    f"Scenario {i} has {num_nodes} nodes, max_nodes={max_nodes}"
                )

    def _compute_difficulty_scores(self):
        """Compute difficulty score for each scenario."""
        self.difficulty_scores = []

        for scenario in self.scenarios:
            # Use metadata if available
            if 'metadata' in scenario and 'difficulty' in scenario['metadata']:
                diff = scenario['metadata']['difficulty']
                score = {'easy': 0.3, 'medium': 0.6, 'hard': 1.0}.get(diff, 0.5)
            elif 'metadata' in scenario and 'load_factor' in scenario['metadata']:
                # Use load factor as proxy for difficulty
                load_factor = scenario['metadata']['load_factor']
                score = min(load_factor, 2.0) / 2.0  # Normalize to [0, 1]
            else:
                # Estimate from job count and cluster size
                num_jobs = len(scenario['jobs'])
                num_gpus = sum(n['total_gpus'] for n in scenario['nodes'])
                score = min(num_jobs / (num_gpus * 3), 1.0)

            self.difficulty_scores.append(score)

    def _sample_scenario_uniform(self) -> int:
        """Sample scenario uniformly at random."""
        return self.rng.integers(0, len(self.scenarios))

    def _sample_scenario_curriculum(self) -> int:
        """Sample scenario with curriculum learning."""
        # Progress through curriculum based on episode count
        progress = min(1.0, self.episode_count / self.curriculum_episodes)

        # Target difficulty increases with progress
        target_difficulty = progress

        # Find scenarios within difficulty range
        tolerance = 0.3
        candidates = []
        for i, score in enumerate(self.difficulty_scores):
            if abs(score - target_difficulty) <= tolerance:
                candidates.append(i)

        if not candidates:
            # Fallback: pick closest difficulty
            distances = [abs(score - target_difficulty)
                        for score in self.difficulty_scores]
            return int(np.argmin(distances))

        return self.rng.choice(candidates)

    def _sample_scenario_difficulty_weighted(self) -> int:
        """Sample with preference for underexplored difficulties."""
        # Weight by inverse episode count to balance exploration
        weights = []
        for i, count in enumerate(self.scenario_episodes):
            # Avoid division by zero
            weight = 1.0 / (count + 1)
            weights.append(weight)

        weights = np.array(weights)
        weights /= weights.sum()

        return self.rng.choice(len(self.scenarios), p=weights)

    def _sample_scenario(self) -> int:
        """Sample scenario based on configured strategy."""
        if self.scenario_sampling == 'uniform':
            return self._sample_scenario_uniform()
        elif self.scenario_sampling == 'curriculum':
            return self._sample_scenario_curriculum()
        elif self.scenario_sampling == 'difficulty-weighted':
            return self._sample_scenario_difficulty_weighted()
        else:
            return self._sample_scenario_uniform()

    def reset(self, **kwargs):
        """Reset with new scenario."""
        # Sample new scenario
        self.current_scenario_idx = self._sample_scenario()
        scenario = self.scenarios[self.current_scenario_idx]

        # Track statistics
        self.scenario_episodes[self.current_scenario_idx] += 1
        self.episode_count += 1

        if self.verbose:
            metadata = scenario.get('metadata', {})
            difficulty = metadata.get('difficulty', 'unknown')
            load = metadata.get('load_factor', 0)

            print(f"\n[Episode {self.episode_count}] Scenario {self.current_scenario_idx}")
            print(f"  Difficulty: {difficulty}, Load Factor: {load:.2f}")
            print(f"  Nodes: {len(scenario['nodes'])}, Jobs: {len(scenario['jobs'])}")

        # Compute adaptive max_steps based on scenario duration
        # Estimate duration from metadata or job trace
        if 'metadata' in scenario and 'duration_sec' in scenario['metadata']:
            duration_sec = scenario['metadata']['duration_sec']
        elif scenario['jobs']:
            # Estimate: last arrival + longest duration
            last_arrival = max(float(job['arrival_time']) for job in scenario['jobs'])
            max_duration = max(float(job['duration_sec']) for job in scenario['jobs'])
            duration_sec = last_arrival + max_duration
        else:
            duration_sec = 0

        # Calculate steps needed: duration / schedule_interval
        if duration_sec > 0:
            estimated_steps = int(duration_sec / self.schedule_interval) + 10  # +10 buffer
            adaptive_max_steps = max(self.max_steps, estimated_steps)
        else:
            adaptive_max_steps = self.max_steps

        if self.verbose:
            num_jobs = len(scenario['jobs'])
            print(f"  Duration: {duration_sec/3600:.1f}hrs, Adaptive max_steps: {adaptive_max_steps} ({num_jobs} jobs)")

        # Create new environment
        self.env = GPUSchedulerEnv(
            nodes_config=scenario['nodes'],
            job_trace_data=scenario['jobs'],
            max_queue_obs=self.max_queue_obs,
            max_nodes=self.max_nodes,
            reward_type=self.reward_type,
            verbose=self.verbose,
            max_steps=adaptive_max_steps,
            schedule_interval=self.schedule_interval
        )

        return self.env.reset(**kwargs)

    def step(self, action):
        """Step and track episode reward."""
        obs, reward, terminated, truncated, info = self.env.step(action)

        # Track scenario performance
        if not hasattr(self, '_episode_reward'):
            self._episode_reward = 0
        self._episode_reward += reward

        if terminated or truncated:
            self.scenario_rewards[self.current_scenario_idx].append(
                self._episode_reward
            )
            self._episode_reward = 0

        return obs, reward, terminated, truncated, info

    def get_scenario_info(self) -> Dict:
        """Return current scenario information."""
        scenario = self.scenarios[self.current_scenario_idx]
        return {
            'scenario_idx': self.current_scenario_idx,
            'num_nodes': len(scenario['nodes']),
            'num_jobs': len(scenario['jobs']),
            'total_scenarios': len(self.scenarios),
            'difficulty': scenario.get('metadata', {}).get('difficulty', 'unknown'),
            'load_factor': scenario.get('metadata', {}).get('load_factor', 0.0)
        }

    def get_training_statistics(self) -> Dict:
        """Return training statistics across scenarios."""
        stats = {
            'total_episodes': self.episode_count,
            'scenarios': []
        }

        for i, (episodes, rewards) in enumerate(
            zip(self.scenario_episodes, self.scenario_rewards)
        ):
            scenario_stats = {
                'scenario_idx': i,
                'episodes': episodes,
                'difficulty': self.scenarios[i].get('metadata', {}).get('difficulty', 'unknown'),
                'avg_reward': np.mean(rewards) if rewards else 0.0,
                'std_reward': np.std(rewards) if rewards else 0.0
            }
            stats['scenarios'].append(scenario_stats)

        return stats


def create_diverse_training_env(
    num_scenarios: int = 30,
    difficulty_distribution: str = 'balanced',
    seed: Optional[int] = 42,
    **env_kwargs
) -> MultiScenarioWrapper:
    """
    Create multi-scenario environment with realistic workloads.

    Args:
        num_scenarios: Total scenarios to generate
        difficulty_distribution: 'balanced', 'easy-heavy', 'hard-heavy', 'curriculum'
        seed: Random seed
        **env_kwargs: Additional arguments for GPUSchedulerEnv

    Returns:
        MultiScenarioWrapper ready for training
    """
    generator = RealisticWorkloadGenerator(seed=seed)

    # Generate scenarios based on distribution
    scenarios = []

    if difficulty_distribution == 'balanced':
        # Equal distribution across difficulties
        for _ in range(num_scenarios // 3):
            scenarios.append(generator.generate_scenario('easy'))
        for _ in range(num_scenarios // 3):
            scenarios.append(generator.generate_scenario('medium'))
        for _ in range(num_scenarios - 2 * (num_scenarios // 3)):
            scenarios.append(generator.generate_scenario('hard'))

    elif difficulty_distribution == 'curriculum':
        # Ordered easy → medium → hard for curriculum learning
        for _ in range(num_scenarios // 3):
            scenarios.append(generator.generate_scenario('easy'))
        for _ in range(num_scenarios // 3):
            scenarios.append(generator.generate_scenario('medium'))
        for _ in range(num_scenarios - 2 * (num_scenarios // 3)):
            scenarios.append(generator.generate_scenario('hard'))

    elif difficulty_distribution == 'easy-heavy':
        # More easy scenarios for initial training
        for _ in range(num_scenarios // 2):
            scenarios.append(generator.generate_scenario('easy'))
        for _ in range(num_scenarios // 4):
            scenarios.append(generator.generate_scenario('medium'))
        for _ in range(num_scenarios - num_scenarios // 2 - num_scenarios // 4):
            scenarios.append(generator.generate_scenario('hard'))

    elif difficulty_distribution == 'hard-heavy':
        # Challenging distribution
        for _ in range(num_scenarios // 4):
            scenarios.append(generator.generate_scenario('easy'))
        for _ in range(num_scenarios // 4):
            scenarios.append(generator.generate_scenario('medium'))
        for _ in range(num_scenarios - 2 * (num_scenarios // 4)):
            scenarios.append(generator.generate_scenario('hard'))

    else:
        raise ValueError(f"Unknown distribution: {difficulty_distribution}")

    # Default environment parameters
    default_env_kwargs = {
        'max_queue_obs': 20,
        'max_nodes': 10,
        'reward_type': 'mixed',
        'verbose': False,
        'scenario_sampling': 'curriculum' if difficulty_distribution == 'curriculum' else 'uniform'
    }
    default_env_kwargs.update(env_kwargs)

    # Create wrapper
    env = MultiScenarioWrapper(scenarios=scenarios, **default_env_kwargs)

    return env


def create_test_scenarios(
    num_scenarios: int = 10,
    seed: Optional[int] = 123
) -> List[Dict]:
    """
    Create held-out test scenarios for evaluating generalization.

    Args:
        num_scenarios: Number of test scenarios
        seed: Different seed from training

    Returns:
        List of test scenarios
    """
    generator = RealisticWorkloadGenerator(seed=seed)

    test_scenarios = []
    for _ in range(num_scenarios):
        # Mix of difficulties
        difficulty = np.random.choice(['easy', 'medium', 'hard'])
        test_scenarios.append(generator.generate_scenario(difficulty))

    return test_scenarios
