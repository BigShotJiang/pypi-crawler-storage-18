class BestFitBackfillScheduler:
    def __init__(self, cluster):
        self.cluster = cluster

    def _find_best_placement(self, job):
        """
        Finds the Best-Fit node for the job.
        Returns: (Node object, can_run_now: bool)
        """
        best_node = None
        min_fragmentation_score = float('inf')
        
        # Iterate over all nodes in the cluster
        for node in self.cluster.nodes.values():
            if node.check_feasibility(job):
                # Fragmentation Score: Remaining Free GPUs after allocation
                # We want to minimize this score to leave the largest possible contiguous block.
                
                # Note: We must also consider VRAM, but for simplicity, we focus on GPU count first.
                fragmentation_score = node.free_gpus - job.gpus_required
                
                if fragmentation_score < min_fragmentation_score:
                    min_fragmentation_score = fragmentation_score
                    best_node = node
                    
        can_run_now = best_node is not None
        return best_node, can_run_now
    
    def _calculate_guaranteed_start_time2(self, hoq_job, target_node):
        """
        Calculates the earliest time the target node can satisfy the HoQ job.
        Requires the target_node to be the Best-Fit placement found previously.
        """
        if not target_node:
            # If no node in the entire cluster can satisfy the HoQ job (e.g., requires 16 GPUs but max is 8)
            return float('inf') 
            
        blocking_completion_time = self.cluster.current_time
        current_blocking_gpus = target_node.total_gpus - target_node.free_gpus
        
        # Check if the currently running jobs are blocking the HoQ job.
        # We need to find when enough jobs finish to free up the resources needed by hoq_job.
        
        # 1. Calculate how many GPUs must be released to satisfy the HoQ
        gpus_to_free = hoq_job.gpus_required - target_node.free_gpus
        
        # 2. Sort the running jobs on the target node by completion time (earliest first)
        running_jobs_on_target = sorted(
            target_node.running_jobs.values(), 
            key=lambda j: j.completion_time
        )
        
        # 3. Iterate through jobs until enough GPUs are freed
        freed_gpus = 0
        for running_job in running_jobs_on_target:
            if freed_gpus >= gpus_to_free:
                break # We have enough GPUs freed
            
            freed_gpus += running_job.gpus_required
            
            # The GST is determined by the completion time of the *last* job needed to free up resources
            blocking_completion_time = max(blocking_completion_time, running_job.completion_time)
            
        return blocking_completion_time
    
    def _calculate_guaranteed_start_time(self, hoq_job, target_node):
        """
        Calculates the earliest time the target node can satisfy the HoQ job.
        Requires the target_node to be the Best-Fit placement found previously.
        """
        if not target_node:
            return float('inf') 
            
        # 1. Calculate how many MORE GPUs must be released to satisfy the HoQ
        gpus_to_free = hoq_job.gpus_required - target_node.free_gpus
        
        # If resources are already sufficient, GST is now.
        if gpus_to_free <= 0:
            return self.cluster.current_time
            
        blocking_completion_time = self.cluster.current_time
        
        # 2. Sort running jobs on the target node by completion time (earliest first)
        running_jobs_on_target = sorted(
            target_node.running_jobs.values(), 
            key=lambda j: j.completion_time
        )
        
        # 3. Iterate through jobs until enough GPUs are freed
        freed_gpus = 0
        
        # We need to ensure we only count GPUs from jobs that will actually finish
        # and release the capacity needed.
        
        for running_job in running_jobs_on_target:
            
            # The job must release capacity on the *target* node.
            
            # We are interested in the completion time of the job that pushes us over the required threshold.
            
            # Check for the total free capacity after this job completes
            freed_gpus += running_job.gpus_required
            
            # This is the critical check: Has the *cumulative* capacity freed up met the requirement?
            if freed_gpus >= gpus_to_free:
                # The GST is the completion time of this last required job
                blocking_completion_time = max(blocking_completion_time, running_job.completion_time)
                # Since the list is sorted by completion time, this is the time we must wait until.
                return blocking_completion_time
            
            # If we are still short, we update the blocking time to the completion time of the current job,
            # as we need to wait for it before proceeding to the next.
            blocking_completion_time = max(blocking_completion_time, running_job.completion_time)
            
        # If we loop through all jobs and still haven't freed enough capacity:
        if freed_gpus < gpus_to_free:
            return float('inf') # The HoQ job can never run.

        return blocking_completion_time

    def _execute_schedule(self, job, node):
        """
        Executes the placement decision: removes job from queue, allocates on node, updates time.
        """
        # 1. Remove job from the pending queue
        self.cluster.pending_queue.remove(job) 
        
        # 2. Allocate resources on the chosen node
        node.allocate(job)
        
        # 3. Update job lifecycle metrics
        job.start(self.cluster.current_time, node.node_id)
        
        print(f"[{self.cluster.current_time:.1f}s] SCHEDULED: {job.job_id} on {node.node_id} (Duration: {job.duration_sec/3600:.1f}hrs)")
        print(f"\tNode Status: {node.free_gpus}/{node.total_gpus} GPUs free.")
        
    def schedule_step(self):
        """Main entry point for the scheduling decision."""
        # 1. Check if HoQ job can run immediately
        # 2. If not, calculate HoQ's Guaranteed Start Time (GST)
        # 3. Look for Backfill Candidates that don't violate the GST
        # 4. If a job is selected, find the Best-Fit node and allocate it.
        
        scheduled_job_id = None # Track which job (if any) was scheduled
        
        # --- Step 1: Identify the Highest Priority (HoQ) Job ---
        if not self.cluster.pending_queue:
            return scheduled_job_id # Nothing to schedule
            
        hoq_job = self.cluster.pending_queue[0]
        
        # --- Step 2: Calculate Placement and GST ---
        best_hoq_placement, hoq_can_run_now = self._find_best_placement(hoq_job)
        
        if hoq_can_run_now:
            # Schedule HoQ immediately and return
            self._execute_schedule(hoq_job, best_hoq_placement)
            return hoq_job.job_id
            
        # If HoQ cannot run, calculate its Guaranteed Start Time (GST)
        gst = self._calculate_guaranteed_start_time(hoq_job, best_hoq_placement)
        
        # --- Step 3: Backfilling Loop ---
        # Look for the first job (after HoQ) that satisfies the Backfill condition
        for candidate_job in self.cluster.pending_queue[1:]:
            
            placement, can_run_now = self._find_best_placement(candidate_job)
            
            if can_run_now:
                # Check Backfill Condition: Completion Time <= GST
                completion_time = self.cluster.current_time + candidate_job.duration_sec
                
                if completion_time <= gst:
                    # Backfill Job Found! Execute schedule and return
                    self._execute_schedule(candidate_job, placement)
                    return candidate_job.job_id
        
        # If no job was scheduled, return None (No-Op action in RL terms)
        return scheduled_job_id


class PureFCFSScheduler:
    """
    Pure First-Come-First-Served (FCFS) scheduler.
    No backfilling - only schedules the Head-of-Queue job if resources are available.
    """
    def __init__(self, cluster):
        self.cluster = cluster

    def _find_best_placement(self, job):
        """
        Finds the Best-Fit node for the job.
        Returns: (Node object, can_run_now: bool)
        """
        best_node = None
        min_fragmentation_score = float('inf')

        for node in self.cluster.nodes.values():
            if node.check_feasibility(job):
                fragmentation_score = node.free_gpus - job.gpus_required

                if fragmentation_score < min_fragmentation_score:
                    min_fragmentation_score = fragmentation_score
                    best_node = node

        can_run_now = best_node is not None
        return best_node, can_run_now

    def _execute_schedule(self, job, node):
        """
        Executes the placement decision: removes job from queue, allocates on node, updates time.
        """
        self.cluster.pending_queue.remove(job)
        node.allocate(job)
        job.start(self.cluster.current_time, node.node_id)

        print(f"[{self.cluster.current_time:.1f}s] SCHEDULED: {job.job_id} on {node.node_id} (Duration: {job.duration_sec/3600:.1f}hrs)")
        print(f"\tNode Status: {node.free_gpus}/{node.total_gpus} GPUs free.")

    def schedule_step(self):
        """
        Pure FCFS: Only schedule the Head-of-Queue job if it can run now.
        No backfilling allowed.
        """
        if not self.cluster.pending_queue:
            return None

        hoq_job = self.cluster.pending_queue[0]
        best_placement, can_run_now = self._find_best_placement(hoq_job)

        if can_run_now:
            self._execute_schedule(hoq_job, best_placement)
            return hoq_job.job_id

        # HoQ cannot run - do nothing (strict FCFS, no backfilling)
        return None


class ShortestJobFirstScheduler:
    """
    Shortest Job First (SJF) scheduler.
    Schedules the job with the shortest duration that can run immediately.
    """
    def __init__(self, cluster):
        self.cluster = cluster

    def _find_best_placement(self, job):
        """
        Finds the Best-Fit node for the job.
        Returns: (Node object, can_run_now: bool)
        """
        best_node = None
        min_fragmentation_score = float('inf')

        for node in self.cluster.nodes.values():
            if node.check_feasibility(job):
                fragmentation_score = node.free_gpus - job.gpus_required

                if fragmentation_score < min_fragmentation_score:
                    min_fragmentation_score = fragmentation_score
                    best_node = node

        can_run_now = best_node is not None
        return best_node, can_run_now

    def _execute_schedule(self, job, node):
        """
        Executes the placement decision: removes job from queue, allocates on node, updates time.
        """
        self.cluster.pending_queue.remove(job)
        node.allocate(job)
        job.start(self.cluster.current_time, node.node_id)

        print(f"[{self.cluster.current_time:.1f}s] SCHEDULED: {job.job_id} on {node.node_id} (Duration: {job.duration_sec/3600:.1f}hrs)")
        print(f"\tNode Status: {node.free_gpus}/{node.total_gpus} GPUs free.")

    def schedule_step(self):
        """
        SJF: Schedule the shortest job that can run immediately.
        """
        if not self.cluster.pending_queue:
            return None

        # Find all jobs that can run right now and select the shortest one
        runnable_jobs = []
        for job in self.cluster.pending_queue:
            placement, can_run_now = self._find_best_placement(job)
            if can_run_now:
                runnable_jobs.append((job, placement))

        if not runnable_jobs:
            return None

        # Select the job with shortest duration
        shortest_job, best_placement = min(runnable_jobs, key=lambda x: x[0].duration_sec)

        self._execute_schedule(shortest_job, best_placement)
        return shortest_job.job_id