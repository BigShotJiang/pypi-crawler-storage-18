from collections import deque
from ..core.job import Job

class SimulatorDriver:
    def __init__(self, cluster, scheduler, job_trace_data):
        self.cluster = cluster
        self.scheduler = scheduler
        
        # Priority Queue to store future events (Time, Type, Data)
        # Type: 'ARRIVAL', 'COMPLETION', 'SCHEDULER_CHECK'
        self.event_queue = deque() 
        
        # Load the trace data and initialize the first arrivals
        self._initialize_events(job_trace_data)

    def _initialize_events(self, job_trace_data):
        """Initializes the cluster and loads all job arrivals into the event queue."""
        
        # Store all jobs in the cluster's trace dictionary first
        for job_data in job_trace_data:
            job = Job(**job_data) # Assuming job_data is a dictionary matching Job.__init__
            self.cluster.job_trace[job.job_id] = job
            
            # Schedule the arrival event for each job
            # Format: (time, event_type, job_id)
            self.event_queue.append((job.arrival_time, 'ARRIVAL', job.job_id))
            
        # Sort events by time
        self.event_queue = deque(sorted(self.event_queue, key=lambda x: x[0]))
    
    def _handle_arrival_event(self, job_id):
        """Handles a job entering the pending queue."""
        job = self.cluster.job_trace.pop(job_id)
        self.cluster.pending_queue.append(job)
        
        # FIFO ordering is maintained
        self.cluster.pending_queue.sort(key=lambda j: j.arrival_time)
        print(f"[{self.cluster.current_time:.1f}s] EVENT: {job_id} ARRIVED. Queue size: {len(self.cluster.pending_queue)}")

    def _handle_completion_events(self):
        """Checks for and processes all jobs that completed at or before the current time."""
        jobs_completed = False
        
        for node in self.cluster.nodes.values():
            jobs_to_finalize = [] # List to hold Job objects that finished
            
            # 1. Gather all jobs that have completed (Iterate over a copy)
            for job_id, job in list(node.running_jobs.items()):
                if self.cluster.current_time >= job.completion_time:
                    jobs_to_finalize.append(job)
            
            # 2. Process Finalization and Removal
            for job in jobs_to_finalize:
                
                print(f"[{self.cluster.current_time:.1f}s] EVENT: {job.job_id} COMPLETED on {node.node_id}.")
                
                # Deallocate resources (This removes the job from node.running_jobs)
                # Ensure node.deallocate only takes the job object and uses job.job_id internally.
                node.deallocate(job) 
                
                # Finalize job data
                job.is_running = False
                self.cluster.completed_jobs.append(job)
                jobs_completed = True
                
        return jobs_completed

    def _trigger_scheduler(self):
        """Calls the scheduler to make a decision."""
        
        # The scheduler handles the core logic (Best-Fit, Backfilling)
        scheduled_job_id = self.scheduler.schedule_step()
        
        if scheduled_job_id:
            # Re-check completions since scheduling a job might free up a slot 
            # for a new completion to be the next event.
            self._handle_completion_events()
        else:
            print(f"[{self.cluster.current_time:.1f}s] SCHEDULER: No job scheduled (No-Op).")

    def log_final_metrics(self):
        """Calculates and prints the final utilization and latency metrics."""
        
        # 1. Calculate Total Available GPU Hours
        total_gpu_hours = 0
        for node in self.cluster.nodes.values():
            # (Total GPUs * Total Simulation Duration) / Seconds per Hour
            total_gpu_hours += (node.total_gpus * self.cluster.current_time) / 3600
            
        # 2. Calculate Used GPU Hours
        used_gpu_hours = 0
        total_wait_time = 0
        
        for job in self.cluster.completed_jobs:
            used_gpu_hours += (job.gpus_required * job.duration_sec) / 3600
            total_wait_time += job.get_wait_time(job.completion_time) # Wait time is start_time - arrival_time

        # 3. Calculate Final Metrics
        utilization = (used_gpu_hours / total_gpu_hours) * 100 if total_gpu_hours > 0 else 0
        avg_wait_time = total_wait_time / len(self.cluster.completed_jobs) if self.cluster.completed_jobs else 0
        
        print("\n--- SCHEDULER PERFORMANCE REPORT ---")
        print(f"Total Simulation Time: {self.cluster.current_time / 3600:.2f} hours")
        print(f"Total Available GPU Hours: {total_gpu_hours:.2f}")
        print(f"Total Used GPU Hours: {used_gpu_hours:.2f}")
        print(f"---------------------------------------------------")
        print(f"Final GPU Utilization: {utilization:.2f}%")
        print(f"Average Job Wait Time: {avg_wait_time:.1f} seconds")
        print("---------------------------------------------------")

    def run_simulation(self):
        """Main simulation loop."""
        
        # Start a periodic check, which is necessary to handle the HoQ job being blocked
        # (Though primarily event-driven, a periodic check can trigger the scheduler 
        # after a job arrives but before the next completion).
        # self.event_queue.appendleft((self.cluster.current_time, 'SCHEDULER_CHECK', None))

        while self.event_queue or self.cluster.nodes_have_running_jobs():
            
            # --- Step 1: Process Next Event ---
            if not self.event_queue:
                # If only running jobs remain, advance time to the earliest completion
                next_time = self.cluster.get_earliest_completion_time()
                time_increment = next_time - self.cluster.current_time
                self.cluster.advance_time(time_increment)
                self._handle_completion_events()
            else:
                # Pop the earliest event
                next_time, event_type, event_data = self.event_queue.popleft()

                # Advance time to the event time
                time_increment = next_time - self.cluster.current_time
                if time_increment > 0:
                    self.cluster.advance_time(time_increment)

                # Handle events that might have occurred during the time advance (Job Completions)
                self._handle_completion_events()

                # --- Step 2: Handle Event Type ---
                if event_type == 'ARRIVAL':
                    self._handle_arrival_event(event_data)
            
            # After any significant event (Arrival or Completion), trigger the scheduler
            self._trigger_scheduler()
            
            # Update the event queue for future completions if new jobs were scheduled
            self._handle_completion_events()
            
        print("\n--- Simulation Complete ---")
        self.log_final_metrics()