"""
Realistic Workload Generator for GPU Scheduling

Generates statistically realistic ML/AI training workloads based on:
- Poisson arrivals with time-varying rate (business hours effect)
- Power-law job sizes (many small, few large)
- Log-normal durations (heavy-tailed, correlated with size)
- Realistic GPU type preferences, VRAM requirements, and per-tier constraints
"""

import numpy as np
from typing import List, Dict, Optional, Tuple

# Default catalog that describes the GPU tiers we know how to sample.
# Each entry specifies the per-GPU VRAM capacity, a loose performance score
# (used for ordering preferences), and the base probability of seeing that
# tier inside a heterogeneous cluster.
DEFAULT_GPU_CATALOG = {
    'V100': {'vram_gb': 32, 'performance_score': 0.7, 'base_probability': 0.15},
    'A100-40GB': {'vram_gb': 40, 'performance_score': 1.0, 'base_probability': 0.45},
    'A100-80GB': {'vram_gb': 80, 'performance_score': 1.15, 'base_probability': 0.25},
    'H100': {'vram_gb': 80, 'performance_score': 1.4, 'base_probability': 0.15},
}


class RealisticWorkloadGenerator:
    """
    Generate realistic ML/AI GPU workload traces.

    Based on characteristics observed in production ML clusters:
    - Non-homogeneous Poisson arrivals
    - Power-law distributed job sizes
    - Log-normal durations with size correlation
    - Burst periods and job families
    """

    def __init__(self, seed: Optional[int] = None, gpu_catalog: Optional[Dict[str, Dict]] = None):
        """
        Args:
            seed: Random seed for reproducibility
            gpu_catalog: Optional override for GPU catalog metadata
        """
        if seed is not None:
            np.random.seed(seed)
        self.rng = np.random.default_rng(seed)
        self.gpu_catalog = gpu_catalog or DEFAULT_GPU_CATALOG.copy()

    def _catalog_items(self, gpu_catalog: Optional[Dict[str, Dict]] = None):
        """Return catalog names and normalized sampling weights."""
        catalog = gpu_catalog or self.gpu_catalog
        gpu_types = list(catalog.keys())
        names = list(catalog.keys())
        weights = np.array([catalog[name].get('base_probability', 1.0) for name in names], dtype=float)
        if weights.sum() == 0:
            weights = np.ones_like(weights)
        weights /= weights.sum()
        return names, weights, catalog

    def _time_varying_rate(self, t: float, base_rate: float = 0.01) -> float:
        """
        Compute time-varying arrival rate λ(t) for non-homogeneous Poisson process.

        Models:
        - Business hours effect (9am-5pm higher load)
        - Overnight low activity
        - Weekend reduction

        Args:
            t: Time in seconds from start
            base_rate: Base arrival rate (jobs/second)

        Returns:
            λ(t): Instantaneous arrival rate at time t
        """
        # Convert to hour of day (0-24)
        hour = (t / 3600) % 24

        # Business hours multiplier (9am-5pm)
        if 9 <= hour < 17:
            time_multiplier = 2.5  # Peak hours
        elif 7 <= hour < 9 or 17 <= hour < 20:
            time_multiplier = 1.5  # Shoulder hours
        else:
            time_multiplier = 0.5  # Off-hours

        return base_rate * time_multiplier

    def generate_poisson_arrivals(
        self,
        duration_sec: float,
        base_rate: float = 0.01,
        use_time_varying: bool = True
    ) -> np.ndarray:
        """
        Generate job arrival times using Poisson process.

        Args:
            duration_sec: Total time window
            base_rate: Average arrival rate (jobs/second)
            use_time_varying: Use time-varying rate λ(t)

        Returns:
            Array of arrival times (sorted)
        """
        if not use_time_varying:
            # Homogeneous Poisson: exponential inter-arrival times
            num_jobs = self.rng.poisson(base_rate * duration_sec)
            arrivals = self.rng.uniform(0, duration_sec, num_jobs)
            return np.sort(arrivals)

        # Non-homogeneous Poisson using thinning algorithm
        # 1. Generate with max rate
        max_rate = base_rate * 3.0  # Upper bound on λ(t)
        num_candidates = self.rng.poisson(max_rate * duration_sec)
        candidate_times = self.rng.uniform(0, duration_sec, num_candidates)

        # 2. Accept with probability λ(t) / max_rate
        arrivals = []
        for t in candidate_times:
            rate_t = self._time_varying_rate(t, base_rate)
            if self.rng.random() < (rate_t / max_rate):
                arrivals.append(t)

        return np.sort(np.array(arrivals))

    def generate_burst_arrivals(
        self,
        duration_sec: float,
        num_bursts: int = 3,
        jobs_per_burst: Tuple[int, int] = (5, 15),
        burst_spread_sec: float = 300
    ) -> np.ndarray:
        """
        Generate burst arrivals (researcher submitting batch of jobs).

        Args:
            duration_sec: Total time window
            num_bursts: Number of burst events
            jobs_per_burst: (min, max) jobs in each burst
            burst_spread_sec: Time spread within burst (std dev)

        Returns:
            Array of arrival times
        """
        burst_centers = self.rng.uniform(0, duration_sec, num_bursts)

        arrivals = []
        for center in burst_centers:
            num_jobs = self.rng.integers(jobs_per_burst[0], jobs_per_burst[1])
            # Jobs arrive around center with some spread
            times = self.rng.normal(center, burst_spread_sec, num_jobs)
            times = np.clip(times, 0, duration_sec)
            arrivals.extend(times)

        return np.sort(np.array(arrivals))

    def sample_job_size_powerlaw(
        self,
        min_gpus: int = 1,
        max_gpus: int = 16,
        alpha: float = 2.5
    ) -> int:
        """
        Sample number of GPUs from power-law distribution.

        P(k GPUs) ∝ k^(-α)

        Realistic for ML workloads: many small jobs, few large multi-GPU jobs.

        Args:
            min_gpus: Minimum GPUs
            max_gpus: Maximum GPUs
            alpha: Power-law exponent (2-3 typical)

        Returns:
            Number of GPUs
        """
        # Generate power-law using inverse CDF method
        k_values = np.arange(min_gpus, max_gpus + 1)
        probabilities = k_values ** (-alpha)
        probabilities /= probabilities.sum()

        return self.rng.choice(k_values, p=probabilities)

    def sample_duration_lognormal(
        self,
        num_gpus: int,
        base_mu: float = 7.0,
        base_sigma: float = 1.5,
        size_correlation: float = 0.3
    ) -> float:
        """
        Sample job duration from log-normal distribution.

        Duration ~ LogNormal(μ, σ) where μ increases with job size.

        Args:
            num_gpus: Number of GPUs (affects mean duration)
            base_mu: Base log-mean
            base_sigma: Log-std deviation
            size_correlation: How much larger jobs run longer

        Returns:
            Duration in seconds
        """
        # Larger jobs tend to run longer (correlation)
        mu = base_mu + size_correlation * np.log(num_gpus)

        duration = self.rng.lognormal(mu, base_sigma)

        # Clip to reasonable range (1 min to 48 hours)
        return np.clip(duration, 60, 48 * 3600)

    def _select_gpu_preferences(
        self,
        num_gpus: int,
        gpu_catalog: Optional[Dict[str, Dict]] = None
    ) -> Tuple[str, List[str], List[str], float]:
        """
        Select GPU preferences for a job based on requested GPU count.

        Returns:
            hard_requirement: Either 'ANY' or a strict GPU type name.
            preferred_types: Ordered preference list (best → fallback).
            acceptable_types: All GPU types the job can run on.
            min_vram_per_gpu: Minimum VRAM per GPU the job expects.
        """
        _, _, catalog = self._catalog_items(gpu_catalog)
        ordered = sorted(catalog.items(), key=lambda item: item[1]['performance_score'])
        performance_sorted = [name for name, _ in ordered]

        if num_gpus <= 2:
            preferred = performance_sorted[:2]
            strict_chance = 0.05
            vram_multiplier = 0.6
        elif num_gpus <= 4:
            preferred = performance_sorted[1:]
            strict_chance = 0.15
            vram_multiplier = 0.75
        else:
            preferred = list(reversed(performance_sorted))
            strict_chance = 0.35
            vram_multiplier = 0.9

        preferred = list(dict.fromkeys(preferred))

        # Always add a fallback list that still respects VRAM needs.
        highest_pref = preferred[0]
        min_vram_needed = catalog[highest_pref]['vram_gb'] * vram_multiplier
        acceptable = [name for name, meta in catalog.items()
                      if meta['vram_gb'] >= min_vram_needed]
        if not acceptable:
            acceptable = list(catalog.keys())

        hard_requirement = 'ANY'
        if self.rng.random() < strict_chance:
            hard_requirement = highest_pref

        return hard_requirement, preferred, acceptable, min_vram_needed

    def compute_vram_requirement(
        self,
        num_gpus: int,
        base_vram_per_gpu: float = 40.0,
        variance: float = 0.2
    ) -> float:
        """
        Compute VRAM requirement with realistic variance.

        Not all jobs fully utilize VRAM.

        Args:
            num_gpus: Number of GPUs
            base_vram_per_gpu: Base VRAM per GPU (GB)
            variance: Relative variance in utilization

        Returns:
            Total VRAM requirement (GB)
        """
        # Base requirement
        base_vram = num_gpus * base_vram_per_gpu

        # Add variance (some jobs don't use full VRAM)
        utilization = self.rng.normal(0.85, variance)
        utilization = np.clip(utilization, 0.3, 1.0)

        return base_vram * utilization

    def sample_priority(
        self,
        num_gpus: int
    ) -> float:
        """
        Sample job priority based on realistic distributions.

        Priority correlates weakly with job size (larger jobs slightly
        more likely to be high priority).

        Distribution:
        - 70% normal priority (0.5)
        - 20% high priority (0.7-1.0)
        - 10% low priority (0.1-0.4)

        Args:
            num_gpus: Number of GPUs (used for correlation)

        Returns:
            Priority value (0.1 = low, 0.5 = normal, 1.0 = critical)
        """
        rand = self.rng.random()

        if rand < 0.7:
            # Normal priority
            priority = 0.5
        elif rand < 0.9:
            # High priority
            priority = self.rng.uniform(0.7, 1.0)
        else:
            # Low priority
            priority = self.rng.uniform(0.1, 0.4)

        # Larger jobs slightly more likely to be high priority
        if num_gpus >= 8:
            priority = min(1.0, priority + 0.1)

        return priority

    def generate_job_trace(
        self,
        duration_sec: float = 86400,  # 24 hours default
        base_arrival_rate: float = 0.005,  # ~0.3 jobs/min
        min_gpus: int = 1,
        max_gpus: int = 16,
        include_bursts: bool = True,
        num_bursts: int = 3,
        gpu_catalog: Optional[Dict[str, Dict]] = None,
        gpu_types: List[str] = None,
        base_duration_mu: float = 7.0,  # ~20 min mean
        duration_sigma: float = 1.5,
        size_correlation: float = 0.3,
        vram_per_gpu: float = 40.0
    ) -> List[Dict]:
        """
        Generate complete realistic job trace.

        Args:
            duration_sec: Time window for arrivals
            base_arrival_rate: Average Poisson rate
            min_gpus, max_gpus: GPU range
            include_bursts: Add burst arrivals
            num_bursts: Number of burst events
            gpu_types: Deprecated. Prefer gpu_catalog for richer metadata.
            gpu_catalog: GPU catalog describing each tier
            base_duration_mu: Base log-mean for duration
            duration_sigma: Log-std for duration
            size_correlation: Correlation between size and duration
            vram_per_gpu: VRAM per GPU baseline

        Returns:
            List of job dictionaries including GPU preferences
        """
        if gpu_catalog is None and gpu_types is not None:
            # Backwards compatibility: derive catalog entries from the provided list.
            gpu_catalog = {
                gpu_type: {
                    'vram_gb': vram_per_gpu,
                    'performance_score': 1.0 + 0.1 * idx,
                    'base_probability': 1.0
                }
                for idx, gpu_type in enumerate(gpu_types)
            }
        catalog = gpu_catalog or self.gpu_catalog

        # Generate arrival times
        poisson_arrivals = self.generate_poisson_arrivals(
            duration_sec, base_arrival_rate, use_time_varying=True
        )

        if include_bursts:
            burst_arrivals = self.generate_burst_arrivals(
                duration_sec, num_bursts=num_bursts
            )
            all_arrivals = np.concatenate([poisson_arrivals, burst_arrivals])
            all_arrivals = np.sort(all_arrivals)
        else:
            all_arrivals = poisson_arrivals

        # Generate jobs
        jobs = []
        for i, arrival_time in enumerate(all_arrivals):
            # Sample job characteristics with correlations
            num_gpus = self.sample_job_size_powerlaw(min_gpus, max_gpus)
            duration = self.sample_duration_lognormal(
                num_gpus, base_duration_mu, duration_sigma, size_correlation
            )
            hard_type, preferred_types, acceptable_types, min_vram_gpu = self._select_gpu_preferences(
                num_gpus, catalog
            )
            gpu_type = hard_type if hard_type != 'ANY' else self.rng.choice(preferred_types)
            vram_req = self.compute_vram_requirement(num_gpus, vram_per_gpu)
            priority = self.sample_priority(num_gpus)

            jobs.append({
                'job_id': f'J{i+1:04d}',
                'arrival_time': str(arrival_time),
                'gpus_required': str(num_gpus),
                'vram_required_gb': str(vram_req),
                'duration_sec': str(int(duration)),
                'gpu_type_required': hard_type,
                'preferred_gpu_types': preferred_types,
                'acceptable_gpu_types': acceptable_types,
                'min_vram_per_gpu': min_vram_gpu,
                'priority': str(priority)
            })

        return jobs

    def generate_cluster_config(
        self,
        num_nodes: int = 4,
        gpu_types: List[str] = None,
        gpus_per_node_range: Tuple[int, int] = (4, 8),
        vram_per_gpu: float = 40.0,
        heterogeneous: bool = True
    ) -> List[Dict]:
        """
        Generate realistic cluster configuration.

        Args:
            num_nodes: Number of nodes
            gpu_types: Legacy list of GPU types (deprecated)
            gpu_catalog: GPU catalog describing tiers to sample
            gpus_per_node_range: (min, max) GPUs per node
            vram_per_gpu: VRAM per GPU
            heterogeneous: Mix different GPU types

        Returns:
            List of node configuration dicts
        """
        if gpu_catalog is None and gpu_types is not None:
            gpu_catalog = {
                gpu_type: {
                    'vram_gb': vram_per_gpu,
                    'performance_score': 1.0 + 0.1 * idx,
                    'base_probability': 1.0
                }
                for idx, gpu_type in enumerate(gpu_types)
            }
        catalog = gpu_catalog or self.gpu_catalog
        names, weights, _ = self._catalog_items(catalog)

        nodes = []
        for i in range(num_nodes):
            # Select GPU type
            if heterogeneous:
                gpu_type = self.rng.choice(names, p=weights)
            else:
                gpu_type = names[0]

            # Sample number of GPUs
            num_gpus = self.rng.integers(
                gpus_per_node_range[0],
                gpus_per_node_range[1] + 1
            )

            per_gpu_vram = catalog[gpu_type]['vram_gb']
            total_vram = num_gpus * per_gpu_vram

            nodes.append({
                'node_id': f'Node-{gpu_type}-{i:02d}',
                'gpu_type': gpu_type,
                'total_gpus': num_gpus,
                'total_vram_gb': total_vram
            })

        return nodes

    def compute_load_factor(
        self,
        job_trace: List[Dict],
        cluster_config: List[Dict],
        duration_sec: float
    ) -> float:
        """
        Compute offered load / cluster capacity.

        Load factor > 1 means oversubscribed (will have queueing).

        Args:
            job_trace: List of jobs
            cluster_config: List of nodes
            duration_sec: Time window

        Returns:
            Load factor (dimensionless)
        """
        # Total cluster GPU-hours
        total_gpus = sum(node['total_gpus'] for node in cluster_config)
        cluster_capacity = total_gpus * (duration_sec / 3600)

        # Total demand GPU-hours
        total_demand = sum(
            int(job['gpus_required']) * (float(job['duration_sec']) / 3600)
            for job in job_trace
        )

        return total_demand / cluster_capacity if cluster_capacity > 0 else float('inf')

    def generate_scenario(
        self,
        difficulty: str = 'medium',
        seed: Optional[int] = None
    ) -> Dict:
        """
        Generate complete scenario (cluster + trace) with difficulty level.

        Args:
            difficulty: 'easy', 'medium', 'hard'
            seed: Random seed

        Returns:
            Dict with 'nodes', 'jobs', and 'metadata'
        """
        if seed is not None:
            self.rng = np.random.default_rng(seed)

        if difficulty == 'easy':
            # Low load, small cluster, fewer jobs
            nodes = self.generate_cluster_config(num_nodes=2, gpus_per_node_range=(4, 8))
            max_node_gpus = max(n['total_gpus'] for n in nodes)
            jobs = self.generate_job_trace(
                duration_sec=14400,  # 4 hours
                base_arrival_rate=0.002,  # Low rate
                max_gpus=min(8, max_node_gpus),  # Don't exceed cluster capacity
                include_bursts=False
            )

        elif difficulty == 'medium':
            # Moderate load, medium cluster
            nodes = self.generate_cluster_config(num_nodes=4, gpus_per_node_range=(4, 8))
            max_node_gpus = max(n['total_gpus'] for n in nodes)
            jobs = self.generate_job_trace(
                duration_sec=28800,  # 8 hours
                base_arrival_rate=0.004,
                max_gpus=min(12, max_node_gpus),  # Don't exceed cluster capacity
                include_bursts=True,
                num_bursts=2
            )

        elif difficulty == 'hard':
            # High load, large cluster, many jobs with bursts
            nodes = self.generate_cluster_config(num_nodes=8, gpus_per_node_range=(4, 16))
            max_node_gpus = max(n['total_gpus'] for n in nodes)
            jobs = self.generate_job_trace(
                duration_sec=86400,  # 24 hours
                base_arrival_rate=0.006,
                max_gpus=min(16, max_node_gpus),  # Don't exceed cluster capacity
                include_bursts=True,
                num_bursts=5
            )

        else:
            raise ValueError(f"Unknown difficulty: {difficulty}")

        # Compute metadata
        duration_sec = 0
        if jobs:
            duration_sec = max(
                float(job['arrival_time']) + float(job['duration_sec'])
                for job in jobs
            )
        load_factor = self.compute_load_factor(jobs, nodes, duration_sec)

        return {
            'nodes': nodes,
            'jobs': jobs,
            'metadata': {
                'difficulty': difficulty,
                'num_nodes': len(nodes),
                'num_jobs': len(jobs),
                'duration_sec': duration_sec,
                'load_factor': load_factor
            }
        }
