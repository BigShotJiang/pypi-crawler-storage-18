"""Cloud API integration for semantic conflict detection"""

import requests
from typing import List, Dict, Any, Optional
from rich.console import Console

from .config import get_api_key
from .deduper import DuplicateMatch

console = Console()


def check_semantic_conflicts(
    duplicates: List[DuplicateMatch],
    api_url: str = "https://console.chunkops.ai"
) -> List[Dict[str, Any]]:
    """
    Send duplicate hashes to ChunkOps Cloud for semantic conflict detection
    
    Args:
        duplicates: List of duplicate matches found locally
        api_url: ChunkOps API URL
    
    Returns:
        List of semantic conflicts detected
    """
    api_key = get_api_key()
    
    if not api_key:
        return []
    
    # Prepare payload
    payload = {
        "duplicates": [
            {
                "file_a": d.file_a,
                "file_b": d.file_b,
                "chunk_a_preview": d.chunk_a_preview[:500],
                "chunk_b_preview": d.chunk_b_preview[:500],
                "similarity": d.similarity,
                "type": d.type
            }
            for d in duplicates
        ]
    }
    
    try:
        response = requests.post(
            f"{api_url}/api/v1/cli/check-conflicts",
            json=payload,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            },
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            return data.get("conflicts", [])
        elif response.status_code == 401:
            console.print("[yellow]⚠️[/yellow] Authentication expired. Run 'chunkops login' to re-authenticate.")
            return []
        else:
            console.print(f"[yellow]⚠️[/yellow] Cloud check failed: {response.status_code}")
            return []
            
    except requests.exceptions.RequestException as e:
        console.print(f"[yellow]⚠️[/yellow] Could not connect to ChunkOps Cloud: {e}")
        return []


def get_conflict_summary(conflicts: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Get summary of conflicts"""
    if not conflicts:
        return {
            "total": 0,
            "critical": 0,
            "warnings": 0
        }
    
    critical = sum(1 for c in conflicts if c.get("severity") == "critical")
    warnings = len(conflicts) - critical
    
    return {
        "total": len(conflicts),
        "critical": critical,
        "warnings": warnings
    }

