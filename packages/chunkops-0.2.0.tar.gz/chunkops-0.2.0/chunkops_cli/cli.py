"""ChunkOps CLI - Production-Grade B2B DevTools CLI"""

import json
import os
import sys
import hashlib
from datetime import datetime
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table import Table
from rich import box
from rich.markdown import Markdown

from chunkops_cli.extractor import PDFExtractor, Chunk
from chunkops_cli.deduper import Deduplicator, DuplicateMatch
from chunkops_cli.config import (
    ChunkOpsConfig, load_config, save_config, get_config_path
)
from chunkops_cli.auth import login, check_auth, get_api_key
from chunkops_cli.cloud import check_semantic_conflicts, get_conflict_summary

app = typer.Typer(
    name="chunkops",
    help="ChunkOps - The CI/CD Pipeline for RAG. Detect conflicts before they become hallucinations.",
    add_completion=False,
)
console = Console()


def find_documents(directory: str) -> List[str]:
    """Find all PDF and Markdown files in a directory"""
    files = []
    path = Path(directory)
    
    if not path.exists():
        console.print(f"[red]❌[/red] Directory '{directory}' does not exist")
        sys.exit(1)
    
    if not path.is_dir():
        console.print(f"[red]❌[/red] '{directory}' is not a directory")
        sys.exit(1)
    
    for ext in ["*.pdf", "*.md", "*.txt"]:
        for file_path in path.rglob(ext):
            files.append(str(file_path))
    
    return sorted(files)


def compute_file_hash(file_path: str) -> str:
    """Compute MD5 hash of file"""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


@app.command()
def init(
    docs_path: str = typer.Option(
        "./data",
        "--docs-path",
        "-d",
        help="Path to documents directory"
    ),
    output_path: str = typer.Option(
        "./chunkops-reports",
        "--output-path",
        "-o",
        help="Path for output reports"
    ),
):
    """Initialize ChunkOps in your project. Creates chunkops.yaml config file."""
    console.print("\n[bold cyan]🚀 ChunkOps Setup[/bold cyan]\n")
    
    # Check if config already exists
    config_path = get_config_path()
    if config_path.exists():
        console.print(f"[yellow]⚠️[/yellow] Config file already exists at: {config_path}")
        overwrite = typer.confirm("Overwrite existing config?", default=False)
        if not overwrite:
            console.print("[dim]Cancelled.[/dim]")
            return
    
    # Detect documents
    console.print(f"[dim]Scanning for documents in: {docs_path}[/dim]")
    docs = find_documents(docs_path)
    
    if docs:
        console.print(f"[green]✓[/green] Found [bold]{len(docs)}[/bold] document(s)")
    else:
        console.print(f"[yellow]⚠️[/yellow] No documents found in: {docs_path}")
        console.print("[dim]You can change this path later in chunkops.yaml[/dim]")
    
    # Create config
    config = ChunkOpsConfig(
        docs_path=docs_path,
        output_path=output_path,
    )
    
    config_path = save_config(config)
    
    console.print(f"\n[green]✅[/green] [bold]Configuration created![/bold]")
    console.print(f"Config file: [cyan]{config_path}[/cyan]\n")
    
    console.print(Panel(
        "[bold]Next steps:[/bold]\n\n"
        "1. Run [cyan]chunkops scan[/cyan] to analyze your documents\n"
        "2. Run [cyan]chunkops login[/cyan] to enable cloud conflict detection\n"
        "3. Add [cyan]chunkops ci[/cyan] to your CI/CD pipeline",
        title="🎯 Ready to Go",
        border_style="green"
    ))


@app.command()
def scan(
    path: Optional[str] = typer.Argument(None, help="Path to documents (overrides config)"),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="Output JSON file path"),
    verbose: bool = typer.Option(False, "-v", "--verbose", help="Verbose output"),
    ci_mode: bool = typer.Option(False, "--ci", help="CI mode (JSON only, no colors)"),
):
    """
    Scan documents for duplicates and conflicts.
    
    Level 1 (Free): Exact duplicates and empty files
    Level 2 (Cloud): Semantic conflicts (requires authentication)
    """
    # Load config
    config = load_config() or ChunkOpsConfig()
    
    # Override with CLI args
    scan_path = path or config.docs_path
    output_file = output or os.path.join(config.output_path, "scan-report.json")
    
    # CI mode: disable colors and use JSON output
    if ci_mode:
        console = Console(force_terminal=False, no_color=True)
    else:
        console.print("\n[bold cyan]ChunkOps CLI[/bold cyan] - Duplicate Detection\n")
    
    # Find documents
    with console.status("[bold yellow]🔍[/bold yellow] Finding documents...", spinner="dots"):
        files = find_documents(scan_path)
    
    if not files:
        console.print("[red]❌[/red] No documents found. Exiting.")
        sys.exit(1)
    
    if not ci_mode:
        console.print(f"[green]✓[/green] Found [bold]{len(files)}[/bold] document(s)\n")
    
    # Level 1: Exact duplicates (MD5 hash)
    if not ci_mode:
        console.print("[bold yellow]⚡[/bold yellow] Analyzing [bold]{}[/bold] documents...".format(len(files)))
    
    file_hashes = {}
    exact_duplicates = []
    empty_files = []
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        disable=ci_mode
    ) as progress:
        task = progress.add_task("Checking for exact duplicates...", total=len(files))
        
        for file_path in files:
            try:
                file_size = os.path.getsize(file_path)
                
                if file_size == 0:
                    empty_files.append(file_path)
                    progress.advance(task)
                    continue
                
                file_hash = compute_file_hash(file_path)
                
                if file_hash in file_hashes:
                    exact_duplicates.append({
                        "file_a": file_hashes[file_hash],
                        "file_b": file_path,
                        "hash": file_hash
                    })
                else:
                    file_hashes[file_hash] = file_path
                
                progress.advance(task)
            except Exception as e:
                if verbose:
                    console.print(f"[red]✗[/red] Error processing {file_path}: {e}")
                progress.advance(task)
                continue
    
    # Extract chunks for semantic analysis
    extractor = PDFExtractor()
    all_chunks = []
    
    if not ci_mode:
        console.print(f"[green]✓[/green] Level 1 complete: [bold]{len(exact_duplicates)}[/bold] exact duplicate(s) found")
    
    # Level 2: Semantic duplicates (if enabled)
    semantic_duplicates = []
    conflicts = []
    
    if not ci_mode:
        console.print("[bold yellow]🔍[/bold yellow] Extracting semantic claims...")
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        disable=ci_mode
    ) as progress:
        task = progress.add_task("Processing documents...", total=len(files))
        
        for file_path in files:
            try:
                if file_path in empty_files:
                    progress.advance(task)
                    continue
                
                chunks = extractor.process_file(file_path)
                all_chunks.extend(chunks)
                progress.advance(task)
            except Exception as e:
                if verbose:
                    console.print(f"[red]✗[/red] Error processing {file_path}: {e}")
                progress.advance(task)
                continue
    
    if all_chunks:
        deduper = Deduplicator(
            exact_threshold=config.exact_threshold,
            near_threshold=config.near_threshold
        )
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            disable=ci_mode
        ) as progress:
            task = progress.add_task("Detecting semantic duplicates...", total=None)
            semantic_duplicates = deduper.find_duplicates(all_chunks)
            progress.update(task, completed=True)
    
    # Cloud conflict detection (teaser)
    if semantic_duplicates and check_auth():
        if not ci_mode:
            console.print(f"\n[yellow]Found {len(semantic_duplicates)} semantic duplicate(s). "
                         f"Sending hashes to ChunkOps Cloud to check for Semantic Conflicts...[/yellow]")
        
        conflicts = check_semantic_conflicts(semantic_duplicates, config.api_url)
    elif semantic_duplicates and not ci_mode:
        console.print(f"\n[yellow]Found {len(semantic_duplicates)} semantic duplicate(s). "
                     f"[bold]Run 'chunkops login' to check for Semantic Conflicts![/bold][/yellow]")
    
    # Generate report
    exact_count = len(exact_duplicates)
    near_count = len([d for d in semantic_duplicates if d.type == "NEAR_DUPLICATE"])
    conflict_summary = get_conflict_summary(conflicts)
    
    report = {
        "scan_date": datetime.utcnow().isoformat() + "Z",
        "total_files": len(files),
        "total_chunks": len(all_chunks),
        "empty_files": len(empty_files),
        "exact_duplicates": exact_count,
        "near_duplicates": near_count,
        "semantic_conflicts": conflict_summary["total"],
        "critical_conflicts": conflict_summary["critical"],
        "summary": {
            "valid_chunks": len(all_chunks) - exact_count,
            "exact_duplicates": exact_count,
            "near_duplicates": near_count,
            "conflicts": conflict_summary["total"]
        }
    }
    
    # Output results
    if ci_mode:
        # CI mode: JSON only
        print(json.dumps(report, indent=2))
        # Exit with error code if critical conflicts found
        if conflict_summary["critical"] > 0:
            sys.exit(1)
    else:
        # Interactive mode: Beautiful output
        display_results(report, exact_duplicates, semantic_duplicates, conflicts, output_file)
    
    # Save report
    os.makedirs(os.path.dirname(output_file) if os.path.dirname(output_file) else ".", exist_ok=True)
    with open(output_file, 'w') as f:
        json.dump(report, f, indent=2)
    
    if not ci_mode:
        console.print(f"\n[dim]Report saved to: {output_file}[/dim]")


def display_results(report: dict, exact_dups: List, semantic_dups: List, conflicts: List, output_file: str):
    """Display beautiful results table"""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="bold")
    table.add_column()
    
    table.add_row("📄 Files scanned:", str(report["total_files"]))
    table.add_row("📝 Total chunks:", str(report["total_chunks"]))
    
    if report["empty_files"] > 0:
        table.add_row("⚠️  Empty files:", f"[yellow]{report['empty_files']}[/yellow]")
    
    if report["exact_duplicates"] > 0:
        saved_kb = report["exact_duplicates"] * 10  # Estimate
        table.add_row("⚠️  Exact duplicates:", 
                     f"[yellow]{report['exact_duplicates']}[/yellow] (Saved ~{saved_kb}KB)")
    
    if report["near_duplicates"] > 0:
        table.add_row("🟡 Near duplicates:", f"[yellow]{report['near_duplicates']}[/yellow]")
    
    if report["semantic_conflicts"] > 0:
        table.add_row("🚨 Semantic conflicts:", 
                     f"[red]{report['semantic_conflicts']}[/red] "
                     f"([bold red]{report['critical_conflicts']}[/bold red] critical)")
        console.print("\n[bold red]⚠️  Critical conflicts detected![/bold red]")
        console.print("Run 'chunkops login' to resolve conflicts in the dashboard.\n")
    elif report["near_duplicates"] > 0:
        console.print("\n[yellow]💡 Tip:[/yellow] Run 'chunkops login' to enable semantic conflict detection")
    
    console.print("\n[bold]Summary:[/bold]")
    console.print(table)
    
    if report["summary"]["valid_chunks"] > 0:
        console.print(f"\n[green]✅[/green] [bold]{report['summary']['valid_chunks']} Chunks Validated[/bold]")


@app.command()
def auth(
    api_key: Optional[str] = typer.Option(None, "--api-key", help="API key (skip browser)"),
):
    """Authenticate with ChunkOps Cloud. Opens browser for OAuth flow."""
    if api_key:
        from chunkops_cli.auth import save_api_key
        save_api_key(api_key)
        console.print("\n[green]✅[/green] API key saved!")
        return
    
    login()


@app.command()
def login(
    api_key: Optional[str] = typer.Option(None, "--api-key", help="API key (skip browser)"),
):
    """Alias for 'chunkops auth'. Authenticate with ChunkOps Cloud."""
    auth(api_key=api_key)


@app.command()
def ci(
    path: Optional[str] = typer.Argument(None, help="Path to documents (overrides config)"),
    output: Optional[str] = typer.Option(None, "-o", "--output", help="Output JSON file path"),
    fail_on_critical: bool = typer.Option(True, "--fail-on-critical/--no-fail-on-critical", help="Exit 1 on critical conflicts"),
):
    """
    CI/CD mode: Run silently, output JSON, exit with error code on failures.
    
    Designed for GitHub Actions / GitLab CI. Exits with code 1 if critical conflicts found.
    """
    scan(path=path, output=output, ci_mode=True, verbose=False)
    
    # Load report to check for critical conflicts
    config = load_config() or ChunkOpsConfig()
    output_file = output or os.path.join(config.output_path, "scan-report.json")
    
    try:
        with open(output_file, 'r') as f:
            report = json.load(f)
        
        if fail_on_critical and report.get("critical_conflicts", 0) > 0:
            sys.exit(1)
    except Exception:
        pass


@app.command()
def version():
    """Show version information"""
    console.print("chunkops 0.2.0")


def main():
    """Main entry point for Typer"""
    app()


if __name__ == "__main__":
    main()
