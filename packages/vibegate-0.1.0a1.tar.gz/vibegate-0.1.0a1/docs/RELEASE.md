# Release Checklist

Use this checklist to prepare and publish a VibeGate release. Replace placeholder values as needed.

## Local validation

```bash
python -m pip install -e ".[dev]"
pytest
ruff check .
ruff format --check .
pyright .
python -m vibegate.cli check .
```

## Build artifacts

```bash
python -m pip install -U build twine
python -m build
twine check dist/*
```

## TestPyPI publish

```bash
python -m pip install -U twine
TWINE_USERNAME=__token__ \
TWINE_PASSWORD=YOUR_TESTPYPI_TOKEN \
python -m twine upload --repository testpypi dist/*
```

Verify TestPyPI install:

```bash
python -m pip install -i https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple vibegate==<VERSION>
python -m vibegate.cli --help
```

## PyPI publish

```bash
python -m pip install -U twine
TWINE_USERNAME=__token__ \
TWINE_PASSWORD=YOUR_PYPI_TOKEN \
python -m twine upload dist/*
```

## Git tag + GitHub Release

```bash
git tag -a v<VERSION> -m "v<VERSION>"
git push origin v<VERSION>
```

1. Create a GitHub Release for `v<VERSION>`.
2. Paste the relevant CHANGELOG notes.
3. Attach the sdist/wheel artifacts from `dist/` if desired.
