# Changelog

All notable changes to this project will be documented in this file.

## 0.1.0a1 - 2025-02-18

### Added
- Initial alpha release of VibeGate with deterministic gating CLI, evidence ledger, and fix pack output.
