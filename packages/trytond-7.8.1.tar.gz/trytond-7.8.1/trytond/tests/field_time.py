# This file is part of Tryton.  The COPYRIGHT file at the top level of
# this repository contains the full copyright notices and license terms.

import datetime

from trytond.model import ModelSQL, fields
from trytond.pool import Pool


class Time(ModelSQL):
    __name__ = 'test.time'
    time = fields.Time(string='Time', help='Test time', required=False)


class TimeDefault(ModelSQL):
    __name__ = 'test.time_default'
    time = fields.Time(string='Time', help='Test time', required=False)

    @staticmethod
    def default_time():
        return datetime.time(16, 30)


class TimeRequired(ModelSQL):
    __name__ = 'test.time_required'
    time = fields.Time(string='Time', help='Test time', required=True)


class TimeFormat(ModelSQL):
    __name__ = 'test.time_format'
    time = fields.Time(string='Time', format='%H:%M')


class TimePrecision(ModelSQL):
    __name__ = 'test.time_precision'
    time = fields.Time(string="Time", format="%H:%M:%S.%f")


def register(module):
    Pool.register(
        Time,
        TimeDefault,
        TimeRequired,
        TimeFormat,
        TimePrecision,
        module=module, type_='model')
