"""Main BLE client for Storz & Bickel devices."""

import asyncio
import logging
from typing import TYPE_CHECKING

from bleak import BleakClient, BleakScanner

from storzandbickel_ble.device import BaseDevice
from storzandbickel_ble.exceptions import (
    ConnectionError,
    DeviceNotFoundError,
    TimeoutError,
)
from storzandbickel_ble.models import DeviceInfo, DeviceType
from storzandbickel_ble.protocol import (
    CONNECTION_TIMEOUT,
    DEVICE_NAME_CRAFTY,
    DEVICE_NAME_VENTY,
    DEVICE_NAME_VOLCANO,
)

if TYPE_CHECKING:
    pass

_LOGGER = logging.getLogger(__name__)


class StorzBickelClient:
    """Main client for discovering and connecting to Storz & Bickel devices."""

    def __init__(self) -> None:
        """Initialize the client."""
        self._scanner: BleakScanner | None = None

    @staticmethod
    def _detect_device_type(name: str) -> DeviceType | None:
        """Detect device type from name.

        Args:
            name: Device name

        Returns:
            DeviceType or None if unknown
        """
        name_upper = name.upper()
        # Check for specific device names first
        if DEVICE_NAME_VOLCANO in name_upper:
            return DeviceType.VOLCANO
        if DEVICE_NAME_VENTY in name_upper:
            return DeviceType.VENTY
        if DEVICE_NAME_CRAFTY in name_upper:
            return DeviceType.CRAFTY
        # Generic "STORZ&BICKEL" name - try to detect by connecting
        # For now, assume Crafty if it's a generic Storz & Bickel device
        if "STORZ" in name_upper and "BICKEL" in name_upper:
            # This is likely a Crafty+ (most common with generic name)
            return DeviceType.CRAFTY
        return None

    async def scan(
        self,
        timeout: float = 10.0,
        device_type: DeviceType | None = None,
    ) -> list[DeviceInfo]:
        """Scan for Storz & Bickel devices.

        Args:
            timeout: Scan timeout in seconds
            device_type: Optional device type filter

        Returns:
            List of discovered devices
        """
        _LOGGER.debug("Starting BLE scan (timeout: %s)", timeout)
        devices: list[DeviceInfo] = []

        try:
            discovered: list = []

            def detection_callback(device: object, advertisement_data: object) -> None:
                """Callback for device detection."""
                _LOGGER.debug(
                    "Discovered device: %s (%s)",
                    getattr(device, "name", None) or "Unknown",
                    getattr(device, "address", "Unknown"),
                )
                discovered.append(device)

            scanner = BleakScanner(detection_callback=detection_callback)
            await scanner.start()
            await asyncio.sleep(timeout)
            await scanner.stop()

            _LOGGER.debug(
                "Scan complete, processing %d discovered devices", len(discovered)
            )

            # Deduplicate by address
            seen_addresses: set[str] = set()

            for device in discovered:
                if device.name is None:
                    _LOGGER.debug("Skipping device %s (no name)", device.address)
                    continue

                # Skip duplicates
                if device.address in seen_addresses:
                    continue
                seen_addresses.add(device.address)

                detected_type = self._detect_device_type(device.name)
                if detected_type is None:
                    _LOGGER.debug(
                        "Skipping device %s (%s) - not a Storz & Bickel device",
                        device.name,
                        device.address,
                    )
                    continue

                if device_type is not None and detected_type != device_type:
                    continue

                device_info = DeviceInfo(
                    name=device.name,
                    address=device.address,
                    device_type=detected_type,
                    rssi=device.rssi if hasattr(device, "rssi") else None,
                )
                devices.append(device_info)
                _LOGGER.debug(
                    "Found device: %s (%s, %s)",
                    device.name,
                    device.address,
                    detected_type.name,
                )

        except Exception as e:
            _LOGGER.error("Error during scan: %s", e, exc_info=True)

        _LOGGER.debug("Scan complete, found %d devices", len(devices))
        return devices

    async def find_device(
        self,
        address: str | None = None,
        name: str | None = None,
        device_type: DeviceType | None = None,
        timeout: float = 10.0,
    ) -> DeviceInfo:
        """Find a specific device by address or name.

        Args:
            address: MAC address (e.g., "XX:XX:XX:XX:XX:XX")
            name: Device name
            device_type: Optional device type filter
            timeout: Scan timeout in seconds

        Returns:
            DeviceInfo for the found device

        Raises:
            DeviceNotFoundError: If device not found
        """
        if address:
            # Try to find by address directly
            try:
                discovered: list = []

                def detection_callback(
                    device: object, advertisement_data: object
                ) -> None:
                    """Callback for device detection."""
                    discovered.append(device)

                scanner = BleakScanner(detection_callback=detection_callback)
                await scanner.start()
                await asyncio.sleep(2.0)  # Brief scan
                await scanner.stop()

                for device in discovered:
                    if device.address.upper() == address.upper():
                        if device.name is None:
                            continue
                        detected_type = self._detect_device_type(device.name)
                        if detected_type is None:
                            continue
                        if device_type is not None and detected_type != device_type:
                            continue

                        return DeviceInfo(
                            name=device.name,
                            address=device.address,
                            device_type=detected_type,
                            rssi=device.rssi if hasattr(device, "rssi") else None,
                        )
            except Exception as e:
                _LOGGER.warning("Error scanning for address %s: %s", address, e)

        # Fall back to full scan
        devices = await self.scan(timeout=timeout, device_type=device_type)

        if address:
            for device in devices:
                if device.address.upper() == address.upper():
                    return device
            msg = f"Device with address {address} not found"
            raise DeviceNotFoundError(msg)

        if name:
            for device in devices:
                if name.upper() in device.name.upper():
                    return device
            msg = f"Device with name containing '{name}' not found"
            raise DeviceNotFoundError(msg)

        if devices:
            return devices[0]

        msg = "No Storz & Bickel devices found"
        raise DeviceNotFoundError(msg)

    async def connect_device(
        self,
        device_info: DeviceInfo,
        timeout: float = CONNECTION_TIMEOUT,
    ) -> BaseDevice:
        """Connect to a device.

        Args:
            device_info: Device information from discovery
            timeout: Connection timeout in seconds

        Returns:
            Connected device instance

        Raises:
            ConnectionError: If connection fails
            DeviceNotFoundError: If device type is unknown
        """
        _LOGGER.debug(
            "Connecting to device: %s (%s)",
            device_info.name,
            device_info.address,
        )

        try:
            # Create BleakClient
            client = BleakClient(device_info.address, timeout=timeout)

            # Connect
            await asyncio.wait_for(client.connect(), timeout=timeout)

            # Create appropriate device instance
            # Import here to avoid circular imports
            device: BaseDevice
            if device_info.device_type == DeviceType.VOLCANO:
                from storzandbickel_ble.volcano import VolcanoDevice

                device = VolcanoDevice(
                    device_info.address,
                    client=client,
                    name=device_info.name,
                )
            elif device_info.device_type == DeviceType.VENTY:
                from storzandbickel_ble.venty import VentyDevice

                device = VentyDevice(
                    device_info.address,
                    client=client,
                    name=device_info.name,
                )
            elif device_info.device_type == DeviceType.CRAFTY:
                from storzandbickel_ble.crafty import CraftyDevice

                device = CraftyDevice(
                    device_info.address,
                    client=client,
                    name=device_info.name,
                )
            else:
                await client.disconnect()
                msg = f"Unknown device type: {device_info.device_type}"
                raise DeviceNotFoundError(msg)

            # Initialize device connection
            await device.connect()

            _LOGGER.info(
                "Successfully connected to %s (%s)",
                device_info.name,
                device_info.address,
            )

            return device

        except asyncio.TimeoutError as e:
            msg = f"Connection timeout after {timeout}s"
            raise TimeoutError(msg) from e
        except Exception as e:
            msg = f"Failed to connect: {e}"
            raise ConnectionError(msg) from e

    async def connect_by_address(
        self,
        address: str,
        timeout: float = CONNECTION_TIMEOUT,
    ) -> BaseDevice:
        """Connect to a device by MAC address.

        Args:
            address: MAC address (e.g., "XX:XX:XX:XX:XX:XX")
            timeout: Connection timeout in seconds

        Returns:
            Connected device instance

        Raises:
            DeviceNotFoundError: If device not found
            ConnectionError: If connection fails
        """
        device_info = await self.find_device(address=address, timeout=timeout)
        return await self.connect_device(device_info, timeout=timeout)

    async def connect_by_name(
        self,
        name: str,
        device_type: DeviceType | None = None,
        timeout: float = CONNECTION_TIMEOUT,
    ) -> BaseDevice:
        """Connect to a device by name.

        Args:
            name: Device name (partial match supported)
            device_type: Optional device type filter
            timeout: Connection timeout in seconds

        Returns:
            Connected device instance

        Raises:
            DeviceNotFoundError: If device not found
            ConnectionError: If connection fails
        """
        device_info = await self.find_device(
            name=name,
            device_type=device_type,
            timeout=timeout,
        )
        return await self.connect_device(device_info, timeout=timeout)
