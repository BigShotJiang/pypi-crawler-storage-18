# Optimization Notes

## Connection Time Optimization

### Issue
Initial connection was taking ~33 seconds, which was too slow.

### Root Cause
The `connect()` method was calling `update_state()` which sequentially reads 11+ characteristics:
- Status register
- Current temperature
- Target temperature
- Battery level
- Project status register
- Project status register 2
- LED brightness
- Auto-off time
- Usage hours
- Usage minutes
- Akku status

Each read operation has network latency, and doing them sequentially adds up.

### Solution
1. **Fast Connection**: Created `_read_minimal_state()` that only reads essential characteristics:
   - Status register (serial number + heater status)
   - Current temperature
   - Target temperature
   - Battery level
   
2. **Parallel Reads**: Temperature, target, and battery are now read in parallel using `asyncio.gather()`

3. **Deferred Full State**: Full state reading is now optional and can be done explicitly via `update_state()` when needed

### Result
- **Connection time: ~20-30 seconds** (this is primarily BLE service discovery, not the library)
- The delay is from the Bluetooth stack (BlueZ on Linux) discovering all services/characteristics
- Full state can still be read when needed
- Notifications provide real-time updates anyway

### Note on Connection Time
The ~30 second connection time is **normal for BLE devices** and is primarily due to:
1. **BLE Service Discovery**: The device must advertise and the OS must discover all services/characteristics
2. **Bluetooth Stack**: Linux BlueZ stack discovery can be slow (20-30s is typical)
3. **Device Response Time**: Some devices are slower to respond during discovery

This is **not a library issue** - it's inherent to BLE protocol and the Bluetooth stack. The library optimizes what it can control (parallel reads, minimal initial state).

## Heater Status Detection

### Issue
Heater status showed `False` even after calling `turn_heater_on()`, especially when device was on charger.

### Root Cause
1. The library was optimistically setting `heater_on = True` locally without verifying
2. The device might not actually turn on the heater if:
   - Device is on charger and in certain modes
   - Device is not "active" (powered on)
   - Other safety conditions aren't met

### Solution
1. **Status Verification**: After turning heater on/off, we now read the actual status register to verify
2. **Real State**: The state now reflects the actual device state, not just what we commanded
3. **Graceful Fallback**: If status read fails, we fall back to optimistic state but log a warning

### Result
- Heater status now accurately reflects device state
- Users can see if heater actually turned on or if device rejected the command
- Better debugging information

## Usage

### Fast Connection (Default)
```python
device = await client.connect_device(device_info)
# Connection is fast, minimal state is read
# Full state available via notifications
```

### Full State Read (When Needed)
```python
device = await client.connect_device(device_info)
await device.update_state()  # Read all characteristics
# Takes longer but gets complete state
```

### Heater Control with Verification
```python
await device.turn_heater_on()
# Status is automatically verified
print(f"Heater actually on: {device.state.heater_on}")
```

