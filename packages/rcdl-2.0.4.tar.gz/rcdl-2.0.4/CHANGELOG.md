# Changelog

---
## [Unreleased]
## Added
- Migrate scripts to migrate from pre-v2 folder structure to v2+. fodler structure and db
- Print info of videos to download, already downloaded, etc... at the end of command `refresh`
## Fixed
- Log info of db status
- SQL Command bug preventing full execution of `dlsf`
---

## [2.0.0] - 2025-12-25
## Added
- Renamed the project from `cdl` to `rcdl` !
- new command `refresh` to update video to be downloaded without starting the download
## Changed
- default file creation changed (see config.py)
- progress ETA improved
- replaced .csv cache with `sqlite3` DB
- `refresh` functionnality removed from `dlsf`
## Fixed
- Fix multiple bugs

## [1.6.2] - 2025-12-21
### Fixed
- fix empty '' ss duration

## [1.6.0] - 2025-11-01
### Added
- Discovery command: search tags for posts with tag
- Tag and Max_page aoption arg

## [1.5.1] - 2025-10-21
### Added
- Fuse part videos with cdl fuse command. Warning: delete part videos that are succesfully fused.
- preset selection in settings.json
- data gatehring of fuse performance in .cache/fuse.csv
- progress info for fuse command
### Changed
- Instead of deleting fused file, rename to .mv_oldfilename.mp4

## [1.4.1] - 2025-10-20
### Added
- Updated parser to extract .m4v video too
### Fixed
- Fixed crash when looking for already downloaded posts and error index in .cache/ is missing
- Fixed issue when video is not written in cache, still check if video not in paths

## [1.4.0] - 2025-10-17
### Added
- custom yt-dlp flags in "yt_dlp_args" in settings.json. aria2 call live here
### Fixed
- fix bug when initialisation wrote default settings despite file already existing

## [1.3.1] - 2025-10-04
### Added
- use aria2 as external downloader in yt-dlp
- add --version flag
- show log file in terminal with command cdl log
- added DEBUG flag --debug, no functionnality yet
- add support for kemono
### Changed
- Python version required now is >= 3.12 instead of >= 3.13
- Progress class to track progress, now also give an estimated time remaining
- Progress eta is now in HH:MM:SS format
- change log file location
### Fixed
- fix empty title bug
- fix an issue when multiples URLS where in a post, it only checked if the first post had been downloaded and not all urls before skipping download

## [1.0.0] - 2025-10-03
### Added
- initial release of the project