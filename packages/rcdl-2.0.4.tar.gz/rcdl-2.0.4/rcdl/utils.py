# utils.py

import time

import click


class Progress:
    def __init__(self, total: int):
        self.total = total
        self.current = 0

        self.last_time = time.time()
        self.times = []

    def update(self, ignore=False):
        now = time.time()
        if not ignore:
            self.times.append(now - self.last_time)
        self.last_time = now
        self.current += 1

    @property
    def eta(self) -> float:
        if len(self.times) == 0:
            return 0.0
        avrg_time = sum(self.times) / len(self.times)
        return (self.total - self.current) * avrg_time

    @property
    def pourcent(self) -> float:
        return self.current / self.total if self.total else 0.0


def echo(text: str):
    click.echo(text)


def echoc(text: str, color: str):
    click.echo(click.style(text, fg=color))
