# LLM Editor

A CLI tool to edit files using LLMs.

## Installation

```bash
pip install llm-editor
```
or, if you are installing from git directly
```bash
git@github.com:gptabhinav/llm-editor.git
pip install .
```

## Configuration

You can configure the tool using a YAML file.

### YAML Configuration

Run the following command to generate a default configuration file at `~/.llm-editor/config.yaml`:

```bash
edit --init-config
```

Then edit the file to add your API key:

```yaml
llm:
  provider: openai
  api_key: "your-api-key"
  model: "gpt-4o"

app:
  backup_enabled: true
  backup_suffix: ".backup"
```

## Usage

### 1. Using Prompt Tags (Scripting Mode)

Add your instructions directly to the file using `<tag>` markers.

**Example `input.txt`:**

```text
<tag> start_prompt
Convert the following Python code to JavaScript.
<tag> end_prompt

def greet(name):
    print(f"Hello, {name}!")

greet("World")
```

Run the tool:

```bash
edit input.txt
```

### 2. Interactive Mode

If the input file does not contain prompt tags, the tool will open your default text editor (configured via `$EDITOR`). You can type your instructions there, save, and close the editor to proceed.

![Interactive Mode Workflow](assets/sample_worflow1.gif)

### 3. Chat Mode

You can start an interactive chat session about your files using the `--chat` flag. This is useful for asking questions, getting explanations, or discussing potential changes without modifying the files directly.

**Single File:**
```bash
edit file.py --chat
```

**Multiple Files:**
You can pass multiple files to load them all into the chat context.
```bash
edit file1.py file2.py --chat
```

**Directories & Patterns:**
You can also pass directories or glob patterns to load multiple files at once.
```bash
# Load all files in a directory (recursive)
edit src/ --chat

# Load all Python files using glob pattern
# (Use quotes to ensure the tool handles the pattern matching)
edit "src/**/*.py" --chat
```

### Options

- `--outfile <path>`: Write output to a specific file (input file is preserved).
- `--inplace`: Overwrite the input file directly (skips backup).
- `--init-config`: Initialize the configuration file.
- `--chat`: Start an interactive chat session about the file(s).

## Usage Tracking & Costs

The tool automatically tracks token usage and estimates costs for each operation.

Logs are stored in `~/.llm-editor/logs/usage.log` and contain:
- Timestamp
- Model used
- Token counts (Input/Output/Total)
- Estimated cost (USD)

Example log entry:
```text
--- Usage Report (2023-10-27T10:00:00.123456) ---
Model: gpt-4o
Input Tokens:  150
Output Tokens: 50
Total Tokens:  200
Estimated Cost: $0.001250
------------------------------
```
