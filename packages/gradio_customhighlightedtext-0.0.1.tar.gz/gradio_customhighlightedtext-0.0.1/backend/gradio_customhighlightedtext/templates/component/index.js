import * as e from "../../../../../assets/svelte/svelte_internal_client.js";
import "../../../../../assets/svelte/svelte_internal_flags_legacy.js";
import { getContext as Je, untrack as Qe, createEventDispatcher as Fe, onMount as $e, tick as et } from "../../../../../assets/svelte/svelte_svelte.js";
import "../../../../../assets/svelte/svelte_motion.js";
const qe = [
  "red",
  "green",
  "blue",
  "yellow",
  "purple",
  "teal",
  "orange",
  "cyan",
  "lime",
  "pink"
], tt = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Te = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
}, je = tt.reduce((m, { color: t, primary: s, secondary: r }) => ({
  ...m,
  [t]: {
    primary: Te[t][s],
    secondary: Te[t][r]
  }
}), {}), Ye = (m) => qe[m % qe.length], rt = "GRADIO_ROOT", lt = typeof window < "u", at = [
  "elem_id",
  "elem_classes",
  "visible",
  "interactive",
  "server_fns",
  "server",
  "id",
  "target",
  "theme_mode",
  "version",
  "root",
  "autoscroll",
  "max_file_size",
  "formatter",
  "client",
  "load_component",
  "scale",
  "min_width",
  "theme",
  "padding",
  "loading_status",
  "label",
  "show_label",
  "validation_error",
  "show_progress",
  "api_prefix",
  "container",
  "attached_events"
];
class ot {
  load_component;
  #e = e.state(e.proxy({}));
  get shared() {
    return e.get(this.#e);
  }
  set shared(t) {
    e.set(this.#e, t, !0);
  }
  #t = e.state(e.proxy({}));
  get props() {
    return e.get(this.#t);
  }
  set props(t) {
    e.set(this.#t, t, !0);
  }
  #r = e.state(e.proxy({}));
  get i18n() {
    return e.get(this.#r);
  }
  set i18n(t) {
    e.set(this.#r, t, !0);
  }
  dispatcher;
  last_update = null;
  shared_props = at;
  constructor(t, s) {
    for (const l in t.shared_props)
      this.shared[l] = t.shared_props[l];
    for (const l in t.props)
      this.props[l] = t.props[l];
    if (s)
      for (const l in s)
        this.props[l] === void 0 && (this.props[l] = s[l]);
    if (this.i18n = this.props.i18n, this.load_component = this.shared.load_component, !lt || t.props?.__GRADIO_BROWSER_TEST__) return;
    const { register: r, dispatcher: i } = Je(rt);
    r(t.shared_props.id, this.set_data.bind(this), this.get_data.bind(this)), this.dispatcher = i, e.user_effect(() => {
      for (const l in t.shared_props)
        this.shared[l] = t.shared_props[l];
      for (const l in t.props)
        this.props[l] = t.props[l];
      r(t.shared_props.id, this.set_data.bind(this), this.get_data.bind(this)), Qe(() => {
        this.shared.id = t.shared_props.id;
      });
    });
  }
  dispatch(t, s) {
    this.dispatcher(this.shared.id, t, s);
  }
  async get_data() {
    return e.snapshot(this.props);
  }
  update(t) {
    this.set_data(t);
  }
  set_data(t) {
    for (const s in t)
      if (this.shared_props.includes(s)) {
        const r = s;
        this.shared[r] = t[r];
        continue;
      } else
        this.props[s] = t[s];
  }
}
function Ae(m, t, s) {
  if (!s) {
    var r = document.createElement("canvas");
    s = r.getContext("2d");
  }
  s.fillStyle = m, s.fillRect(0, 0, 1, 1);
  const [i, l, g] = s.getImageData(0, 0, 1, 1).data;
  return s.clearRect(0, 0, 1, 1), `rgba(${i}, ${l}, ${g}, ${255 / t})`;
}
function Me(m, t, s, r) {
  for (const i in m) {
    const l = m[i].trim();
    l in je ? t[i] = je[l] : t[i] = {
      primary: s ? Ae(m[i], 1, r) : m[i],
      secondary: s ? Ae(m[i], 0.5, r) : m[i]
    };
  }
}
function Ge(m, t) {
  let s = [], r = null, i = null;
  for (const l of m)
    i === l.class_or_confidence ? r = r ? r + l.token : l.token : (r !== null && s.push({
      token: r,
      class_or_confidence: i
    }), r = l.token, i = l.class_or_confidence);
  return r !== null && s.push({
    token: r,
    class_or_confidence: i
  }), s;
}
var st = e.from_html('<div class="category-label svelte-9e1q9t"> </div>'), nt = e.from_html('<div class="category-legend svelte-9e1q9t" data-testid="highlighted-text:category-legend"></div>'), it = e.from_html('&nbsp; <span class="label svelte-9e1q9t"> </span>', 1), ct = e.from_html("<span><span> </span> <!></span>"), dt = e.from_html("<br/>"), ht = e.from_html("<!> <!>", 1), vt = e.from_html('<!> <div class="textfield svelte-9e1q9t"></div>', 1), ft = e.from_html('<div class="color-legend svelte-9e1q9t" data-testid="highlighted-text:color-legend"><span>-1</span> <span>0</span> <span>+1</span></div>'), gt = e.from_html('<span class="textspan score-text svelte-9e1q9t"><span class="text svelte-9e1q9t"> </span></span>'), pt = e.from_html('<!> <div class="textfield svelte-9e1q9t" data-testid="highlighted-text:textfield"></div>', 1), ut = e.from_html('<div class="container svelte-9e1q9t"><!></div>');
function _t(m, t) {
  e.push(t, !1);
  const s = typeof document < "u";
  let r = e.prop(t, "value", 24, () => []), i = e.prop(t, "show_legend", 8, !1), l = e.prop(t, "show_inline_category", 8, !0), g = e.prop(t, "color_map", 28, () => ({})), v = e.prop(t, "selectable", 8, !1), Z, d = e.mutable_source({}), p = e.mutable_source("");
  function c(a) {
    return a.split(`
`);
  }
  const M = Fe();
  let w = e.mutable_source();
  function L(a) {
    e.set(p, a);
  }
  function Y() {
    e.set(p, "");
  }
  e.legacy_pre_effect(
    () => (e.deep_read_state(g()), e.deep_read_state(r()), e.get(d), Me),
    () => {
      if (g() || g({}), r().length > 0) {
        for (let a of r())
          if (a.class_or_confidence !== null)
            if (typeof a.class_or_confidence == "string") {
              if (e.set(w, "categories"), !(a.class_or_confidence in g())) {
                let q = Ye(Object.keys(g()).length);
                g(g()[a.class_or_confidence] = q, !0);
              }
            } else
              e.set(w, "scores");
      }
      e.set(d, {}), Me(g(), e.get(d), s, Z);
    }
  ), e.legacy_pre_effect_reset(), e.init();
  var N = ut(), X = e.child(N);
  {
    var W = (a) => {
      var q = vt(), y = e.first_child(q);
      {
        var u = (S) => {
          var f = nt();
          e.each(
            f,
            5,
            () => (e.get(d), e.untrack(() => Object.entries(e.get(d)))),
            e.index,
            (se, te) => {
              var z = e.derived(() => e.to_array(e.get(te), 2));
              let n = () => e.get(z)[0], C = () => e.get(z)[1];
              var V = st(), k = e.child(V, !0);
              e.reset(V), e.template_effect(() => {
                e.set_style(V, (C(), e.untrack(() => "background-color:" + C().secondary))), e.set_text(k, n());
              }), e.event("mouseover", V, () => L(n())), e.event("focus", V, () => L(n())), e.event("mouseout", V, () => Y()), e.event("blur", V, () => Y()), e.append(se, V);
            }
          ), e.reset(f), e.append(S, f);
        };
        e.if(y, (S) => {
          i() && S(u);
        });
      }
      var F = e.sibling(y, 2);
      e.each(F, 5, r, e.index, (S, f, se) => {
        var te = e.comment(), z = e.first_child(te);
        e.each(
          z,
          1,
          () => (e.get(f), e.untrack(() => c(e.get(f).token))),
          e.index,
          (n, C, V) => {
            var k = ht(), O = e.first_child(k);
            {
              var I = (H) => {
                var o = ct();
                let j, h;
                var x = e.child(o);
                let A;
                var E = e.child(x, !0);
                e.reset(x);
                var U = e.sibling(x, 2);
                {
                  var J = (T) => {
                    var re = it(), ie = e.sibling(e.first_child(re));
                    let G;
                    var le = e.child(ie, !0);
                    e.reset(ie), e.template_effect(() => {
                      G = e.set_style(ie, "", G, {
                        "background-color": (e.get(f), e.get(p), e.get(d), e.untrack(() => e.get(f).class_or_confidence === null || e.get(p) && e.get(p) !== e.get(f).class_or_confidence ? "" : e.get(d)[e.get(f).class_or_confidence].primary))
                      }), e.set_text(le, (e.get(f), e.untrack(() => e.get(f).class_or_confidence)));
                    }), e.append(T, re);
                  };
                  e.if(U, (T) => {
                    e.deep_read_state(i()), e.deep_read_state(l()), e.get(f), e.untrack(() => !i() && l() && e.get(f).class_or_confidence !== null) && T(J);
                  });
                }
                e.reset(o), e.template_effect(() => {
                  j = e.set_class(o, 1, "textspan svelte-9e1q9t", null, j, {
                    "no-cat": e.get(f).class_or_confidence === null || e.get(p) && e.get(p) !== e.get(f).class_or_confidence,
                    hl: e.get(f).class_or_confidence !== null,
                    selectable: v()
                  }), h = e.set_style(o, "", h, {
                    "background-color": (e.get(f), e.get(p), e.get(d), e.untrack(() => e.get(f).class_or_confidence === null || e.get(p) && e.get(p) !== e.get(f).class_or_confidence ? "" : e.get(d)[e.get(f).class_or_confidence].secondary))
                  }), A = e.set_class(x, 1, "text svelte-9e1q9t", null, A, {
                    "no-label": e.get(f).class_or_confidence === null || !e.get(d)[e.get(f).class_or_confidence]
                  }), e.set_text(E, e.get(C));
                }), e.event("click", o, () => {
                  M("select", {
                    index: se,
                    value: [e.get(f).token, e.get(f).class_or_confidence]
                  });
                }), e.append(H, o);
              };
              e.if(O, (H) => {
                e.get(C) !== "" && H(I);
              });
            }
            var b = e.sibling(O, 2);
            {
              var _ = (H) => {
                var o = dt();
                e.append(H, o);
              };
              e.if(b, (H) => {
                e.get(f), e.untrack(() => V < c(e.get(f).token).length - 1) && H(_);
              });
            }
            e.append(n, k);
          }
        ), e.append(S, te);
      }), e.reset(F), e.append(a, q);
    }, B = (a) => {
      var q = pt(), y = e.first_child(q);
      {
        var u = (S) => {
          var f = ft();
          e.append(S, f);
        };
        e.if(y, (S) => {
          i() && S(u);
        });
      }
      var F = e.sibling(y, 2);
      e.each(F, 5, r, e.index, (S, f) => {
        const se = e.derived_safe_equal(() => (e.get(f), e.untrack(() => typeof e.get(f).class_or_confidence == "string" ? parseInt(e.get(f).class_or_confidence) : e.get(f).class_or_confidence)));
        var te = gt(), z = e.child(te), n = e.child(z, !0);
        e.reset(z), e.reset(te), e.template_effect(() => {
          e.set_style(te, "background-color: rgba(" + (e.get(se) && e.get(se) < 0 ? "128, 90, 213," + -e.get(se) : "239, 68, 60," + e.get(se)) + ")"), e.set_text(n, (e.get(f), e.untrack(() => e.get(f).token)));
        }), e.append(S, te);
      }), e.reset(F), e.append(a, q);
    };
    e.if(X, (a) => {
      e.get(w) === "categories" ? a(W) : a(B, !1);
    });
  }
  e.reset(N), e.append(m, N), e.pop();
}
var mt = e.from_html('<input class="label-input svelte-140gujv" type="text" placeholder="label"/>'), wt = e.from_html('<input class="label-input svelte-140gujv" type="number" step="0.1"/>');
function Se(m, t) {
  e.push(t, !1);
  let s = e.prop(t, "value", 12), r = e.prop(t, "category", 8), i = e.prop(t, "active", 8), l = e.prop(t, "labelToEdit", 12), g = e.prop(t, "indexOfLabel", 8), v = e.prop(t, "text", 8), Z = e.prop(t, "handleValueChange", 8), d = e.prop(t, "isScoresMode", 8, !1), p = e.prop(t, "_color_map", 8), c = e.mutable_source(r());
  function M(B) {
    let a = B.target;
    a && e.set(c, a.value);
  }
  function w(B, a, q) {
    let y = B.target;
    s([
      ...s().slice(0, a),
      {
        token: q,
        class_or_confidence: y.value === "" ? null : d() ? Number(y.value) : y.value
      },
      ...s().slice(a + 1)
    ]), Z()();
  }
  function L(B) {
    let a = B.target;
    a && a.placeholder && (a.placeholder = "");
  }
  e.init();
  var Y = e.comment(), N = e.first_child(Y);
  {
    var X = (B) => {
      var a = mt();
      e.remove_input_defaults(a), e.autofocus(a, !0);
      let q;
      e.template_effect(
        (y) => {
          e.set_attribute(a, "id", `label-input-${g()}`), e.set_value(a, r()), q = e.set_style(a, "", q, y);
        },
        [
          () => ({
            "background-color": (e.deep_read_state(r()), e.deep_read_state(i()), e.deep_read_state(p()), e.untrack(() => r() === null || i() && i() !== r() ? "" : p()[r()].primary)),
            width: (e.get(c), e.untrack(() => e.get(c) ? e.get(c).toString()?.length + 4 + "ch" : "8ch"))
          })
        ]
      ), e.event("input", a, M), e.event("blur", a, (y) => w(y, g(), v())), e.event("keydown", a, (y) => {
        y.key === "Enter" && (w(y, g(), v()), l(-1));
      }), e.event("focus", a, L), e.append(B, a);
    }, W = (B) => {
      var a = wt();
      e.remove_input_defaults(a), e.autofocus(a, !0);
      let q;
      e.template_effect(() => {
        q = e.set_style(
          a,
          "background-color: rgba(" + (typeof r() == "number" && r() < 0 ? "128, 90, 213," + -r() : "239, 68, 60," + r()) + ")",
          q,
          { width: "7ch" }
        ), e.set_value(a, r());
      }), e.event("input", a, M), e.event("blur", a, (y) => w(y, g(), v())), e.event("keydown", a, (y) => {
        y.key === "Enter" && (w(y, g(), v()), l(-1));
      }), e.append(B, a);
    };
    e.if(N, (B) => {
      d() ? B(W, !1) : B(X);
    });
  }
  e.append(m, Y), e.pop();
}
var xt = e.from_html('<div role="button" aria-roledescription="Categories of highlighted text. Hover to see text with this class_or_confidence highlighted." tabindex="0" class="class_or_confidence-label svelte-8wk1fz"> </div>'), kt = e.from_html('<div class="class_or_confidence-legend svelte-8wk1fz" data-testid="highlighted-text:class_or_confidence-legend"><!></div>'), bt = e.from_html('<span class="label svelte-8wk1fz" role="button" tabindex="0"> </span>'), yt = e.from_html("&nbsp; <!>", 1), Ct = e.from_html('<span class="label-clear-button svelte-8wk1fz" role="button" aria-roledescription="Remove label from text" tabindex="0">×</span>'), Mt = e.from_html('<span class="text-class_or_confidence-container svelte-8wk1fz"><span role="button" tabindex="0"><span role="button" tabindex="0"> </span> <!> <!></span> <!></span>'), Lt = e.from_html("<br/>"), Bt = e.from_html("<!> <!>", 1), zt = e.from_html('<!> <div class="textfield svelte-8wk1fz"></div>', 1), Vt = e.from_html('<div class="color-legend svelte-8wk1fz" data-testid="highlighted-text:color-legend"><span>-1</span> <span>0</span> <span>+1</span></div>'), Ht = e.from_html('<span class="label-clear-button svelte-8wk1fz" role="button" aria-roledescription="Remove label from text" tabindex="0">×</span>'), Zt = e.from_html('<span class="score-text-container svelte-8wk1fz"><span role="button" tabindex="0"><span class="text svelte-8wk1fz"> </span> <!></span> <!></span>'), qt = e.from_html('<!> <div class="textfield svelte-8wk1fz" data-testid="highlighted-text:textfield"></div>', 1), Tt = e.from_html('<div class="container svelte-8wk1fz"><!></div>');
function jt(m, t) {
  e.push(t, !1);
  var s = this && this.__awaiter || function(n, C, V, k) {
    function O(I) {
      return I instanceof V ? I : new V(function(b) {
        b(I);
      });
    }
    return new (V || (V = Promise))(function(I, b) {
      function _(j) {
        try {
          o(k.next(j));
        } catch (h) {
          b(h);
        }
      }
      function H(j) {
        try {
          o(k.throw(j));
        } catch (h) {
          b(h);
        }
      }
      function o(j) {
        j.done ? I(j.value) : O(j.value).then(_, H);
      }
      o((k = k.apply(n, C || [])).next());
    });
  }, r = this && this.__rest || function(n, C) {
    var V = {};
    for (var k in n) Object.prototype.hasOwnProperty.call(n, k) && C.indexOf(k) < 0 && (V[k] = n[k]);
    if (n != null && typeof Object.getOwnPropertySymbols == "function") for (var O = 0, k = Object.getOwnPropertySymbols(n); O < k.length; O++)
      C.indexOf(k[O]) < 0 && Object.prototype.propertyIsEnumerable.call(n, k[O]) && (V[k[O]] = n[k[O]]);
    return V;
  };
  const i = typeof document < "u";
  let l = e.prop(t, "value", 28, () => []), g = e.prop(t, "show_legend", 8, !1), v = e.prop(t, "color_map", 28, () => ({})), Z = e.prop(t, "selectable", 8, !1), d = e.mutable_source(-1), p, c = e.mutable_source({}), M = e.mutable_source(""), w, L = e.mutable_source(-1);
  $e(() => {
    const n = () => {
      w = window.getSelection(), F(), window.removeEventListener("mouseup", n);
    };
    window.addEventListener("mousedown", () => {
      window.addEventListener("mouseup", n);
    });
  });
  function Y(n, C) {
    return s(this, void 0, void 0, function* () {
      var V;
      if (w?.toString() && e.get(d) !== -1 && l()[e.get(d)].token.toString().includes(w.toString())) {
        const k = /* @__PURE__ */ Symbol(), O = l()[e.get(d)].token, [I, b, _] = [
          O.substring(0, n),
          O.substring(n, C),
          O.substring(C)
        ];
        let H = [
          ...l().slice(0, e.get(d)),
          { token: I, class_or_confidence: null },
          {
            token: b,
            class_or_confidence: e.get(a) === "scores" ? 1 : "label",
            flag: k
          },
          // add a temp flag to the new highlighted text element
          { token: _, class_or_confidence: null },
          ...l().slice(e.get(d) + 1)
        ];
        e.set(L, H.findIndex(({ flag: o }) => o === k)), H = H.filter((o) => o.token !== ""), l(H.map((o) => {
          var { flag: j } = o, h = r(o, ["flag"]);
          return h;
        })), B(), (V = document.getElementById(`label-input-${e.get(L)}`)) === null || V === void 0 || V.focus();
      }
    });
  }
  const N = Fe();
  function X(n) {
    return n.split(`
`);
  }
  function W(n) {
    var C;
    !l() || n < 0 || n >= l().length || (l(l()[n].class_or_confidence = null, !0), l(Ge(l())), B(), (C = window.getSelection()) === null || C === void 0 || C.empty());
  }
  function B() {
    N("change", l()), e.set(L, -1), g() && (v({}), e.set(c, {}));
  }
  let a = e.mutable_source();
  function q(n) {
    e.set(M, n);
  }
  function y() {
    e.set(M, "");
  }
  function u(n) {
    return s(this, void 0, void 0, function* () {
      w = window.getSelection(), n.key === "Enter" && F();
    });
  }
  function F() {
    if (w && w?.toString() !== "") {
      const n = w.getRangeAt(0).startOffset, C = w.getRangeAt(0).endOffset;
      Y(n, C);
    }
  }
  function S(n, C, V) {
    N("select", { index: n, value: [C, V] });
  }
  e.legacy_pre_effect(
    () => (e.deep_read_state(v()), e.deep_read_state(l()), e.get(c), Me),
    () => {
      if (v() || v({}), l().length > 0) {
        for (let n of l())
          if (n.class_or_confidence !== null)
            if (typeof n.class_or_confidence == "string") {
              if (e.set(a, "categories"), !(n.class_or_confidence in v())) {
                let C = Ye(Object.keys(v()).length);
                v(v()[n.class_or_confidence] = C, !0);
              }
            } else
              e.set(a, "scores");
      }
      e.set(c, {}), Me(v(), e.get(c), i, p);
    }
  ), e.legacy_pre_effect_reset(), e.init();
  var f = Tt(), se = e.child(f);
  {
    var te = (n) => {
      var C = zt(), V = e.first_child(C);
      {
        var k = (I) => {
          var b = kt(), _ = e.child(b);
          {
            var H = (o) => {
              var j = e.comment(), h = e.first_child(j);
              e.each(
                h,
                1,
                () => (e.get(c), e.untrack(() => Object.entries(e.get(c)))),
                e.index,
                (x, A) => {
                  var E = e.derived(() => e.to_array(e.get(A), 2));
                  let U = () => e.get(E)[0], J = () => e.get(E)[1];
                  var T = xt(), re = e.child(T, !0);
                  e.reset(T), e.template_effect(() => {
                    e.set_style(T, (J(), e.untrack(() => "background-color:" + J().secondary))), e.set_text(re, U());
                  }), e.event("mouseover", T, () => q(U())), e.event("focus", T, () => q(U())), e.event("mouseout", T, () => y()), e.event("blur", T, () => y()), e.append(x, T);
                }
              ), e.append(o, j);
            };
            e.if(_, (o) => {
              e.get(c) && o(H);
            });
          }
          e.reset(b), e.append(I, b);
        };
        e.if(V, (I) => {
          g() && I(k);
        });
      }
      var O = e.sibling(V, 2);
      e.each(O, 5, l, e.index, (I, b, _) => {
        let H = () => e.get(b).token, o = () => e.get(b).class_or_confidence;
        var j = e.comment(), h = e.first_child(j);
        e.each(h, 1, () => (H(), e.untrack(() => X(H()))), e.index, (x, A, E) => {
          var U = Bt(), J = e.first_child(U);
          {
            var T = (G) => {
              var le = Mt(), Q = e.child(le);
              let xe, ke;
              var he = e.child(Q);
              let be;
              var R = e.child(he, !0);
              e.reset(he);
              var P = e.sibling(he, 2);
              {
                var $ = (K) => {
                  var D = bt();
                  e.set_attribute(D, "id", `label-tag-${_}`);
                  let oe;
                  var ve = e.child(D, !0);
                  e.reset(D), e.template_effect(() => {
                    oe = e.set_style(D, "", oe, {
                      "background-color": (o(), e.get(M), e.get(c), e.untrack(() => o() === null || e.get(M) && e.get(M) !== o() ? "" : e.get(c)[o()].primary))
                    }), e.set_text(ve, o());
                  }), e.event("click", D, () => e.set(L, _)), e.event("keydown", D, () => e.set(L, _)), e.append(K, D);
                };
                e.if(P, (K) => {
                  !g() && o() !== null && e.get(L) !== _ && K($);
                });
              }
              var ce = e.sibling(P, 2);
              {
                var ee = (K) => {
                  var D = yt(), oe = e.sibling(e.first_child(D));
                  Se(oe, {
                    get labelToEdit() {
                      return e.get(L);
                    },
                    get category() {
                      return o();
                    },
                    get active() {
                      return e.get(M);
                    },
                    get _color_map() {
                      return e.get(c);
                    },
                    indexOfLabel: _,
                    get text() {
                      return H();
                    },
                    handleValueChange: B,
                    get value() {
                      return l();
                    },
                    set value(ve) {
                      l(ve);
                    },
                    $$legacy: !0
                  }), e.append(K, D);
                };
                e.if(ce, (K) => {
                  e.get(L) === _ && o() !== null && K(ee);
                });
              }
              e.reset(Q);
              var ae = e.sibling(Q, 2);
              {
                var de = (K) => {
                  var D = Ct();
                  e.event("click", D, () => W(_)), e.event("keydown", D, (oe) => {
                    oe.key === "Enter" && W(_);
                  }), e.append(K, D);
                };
                e.if(ae, (K) => {
                  o() !== null && K(de);
                });
              }
              e.reset(le), e.template_effect(() => {
                xe = e.set_class(Q, 1, "textspan svelte-8wk1fz", null, xe, {
                  "no-cat": o() === null || e.get(M) && e.get(M) !== o(),
                  hl: o() !== null,
                  selectable: Z()
                }), ke = e.set_style(Q, "", ke, {
                  "background-color": (o(), e.get(M), e.get(c), e.untrack(() => o() === null || e.get(M) && e.get(M) !== o() ? "" : o() && e.get(c)[o()] ? e.get(c)[o()].secondary : ""))
                }), be = e.set_class(he, 1, "text svelte-8wk1fz", null, be, { "no-label": o() === null }), e.set_text(R, e.get(A));
              }), e.event("keydown", he, (K) => u(K)), e.event("focus", he, () => e.set(d, _)), e.event("mouseover", he, () => e.set(d, _)), e.event("click", he, () => e.set(L, _)), e.event("click", Q, () => {
                o() !== null && S(_, H(), o());
              }), e.event("keydown", Q, (K) => {
                o() !== null ? (e.set(L, _), S(_, H(), o())) : u(K);
              }), e.event("focus", Q, () => e.set(d, _)), e.event("mouseover", Q, () => e.set(d, _)), e.append(G, le);
            };
            e.if(J, (G) => {
              e.get(A) !== "" && G(T);
            });
          }
          var re = e.sibling(J, 2);
          {
            var ie = (G) => {
              var le = Lt();
              e.append(G, le);
            };
            e.if(re, (G) => {
              H(), e.untrack(() => E < X(H()).length - 1) && G(ie);
            });
          }
          e.append(x, U);
        }), e.append(I, j);
      }), e.reset(O), e.append(n, C);
    }, z = (n) => {
      var C = qt(), V = e.first_child(C);
      {
        var k = (I) => {
          var b = Vt();
          e.append(I, b);
        };
        e.if(V, (I) => {
          g() && I(k);
        });
      }
      var O = e.sibling(V, 2);
      e.each(O, 5, l, e.index, (I, b, _) => {
        let H = () => e.get(b).token, o = () => e.get(b).class_or_confidence;
        const j = e.derived_safe_equal(() => (o(), e.untrack(() => typeof o() == "string" ? parseInt(o()) : o())));
        var h = Zt(), x = e.child(h);
        let A;
        var E = e.child(x), U = e.child(E, !0);
        e.reset(E);
        var J = e.sibling(E, 2);
        {
          var T = (G) => {
            Se(G, {
              get labelToEdit() {
                return e.get(L);
              },
              get _color_map() {
                return e.get(c);
              },
              get category() {
                return o();
              },
              get active() {
                return e.get(M);
              },
              indexOfLabel: _,
              get text() {
                return H();
              },
              handleValueChange: B,
              isScoresMode: !0,
              get value() {
                return l();
              },
              set value(le) {
                l(le);
              },
              $$legacy: !0
            });
          };
          e.if(J, (G) => {
            o() && e.get(L) === _ && G(T);
          });
        }
        e.reset(x);
        var re = e.sibling(x, 2);
        {
          var ie = (G) => {
            var le = Ht();
            e.event("click", le, () => W(_)), e.event("keydown", le, (Q) => {
              Q.key === "Enter" && W(_);
            }), e.append(G, le);
          };
          e.if(re, (G) => {
            o() && e.get(d) === _ && G(ie);
          });
        }
        e.reset(h), e.template_effect(() => {
          A = e.set_class(x, 1, "textspan score-text svelte-8wk1fz", null, A, {
            "no-cat": o() === null || e.get(M) && e.get(M) !== o(),
            hl: o() !== null
          }), e.set_style(x, "background-color: rgba(" + (e.get(j) && e.get(j) < 0 ? "128, 90, 213," + -e.get(j) : "239, 68, 60," + e.get(j)) + ")"), e.set_text(U, H());
        }), e.event("mouseover", x, () => e.set(d, _)), e.event("focus", x, () => e.set(d, _)), e.event("click", x, () => e.set(L, _)), e.event("keydown", x, (G) => {
          G.key === "Enter" && e.set(L, _);
        }), e.append(I, h);
      }), e.reset(O), e.append(n, C);
    };
    e.if(se, (n) => {
      e.get(a) === "categories" ? n(te) : n(z, !1);
    });
  }
  e.reset(f), e.append(m, f), e.pop();
}
var At = e.from_svg('<svg class="resize-handle svelte-1vi3m5m" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 10 10"><line x1="1" y1="9" x2="9" y2="1" stroke="gray" stroke-width="0.5" class="svelte-1vi3m5m"></line><line x1="5" y1="9" x2="9" y2="5" stroke="gray" stroke-width="0.5" class="svelte-1vi3m5m"></line></svg>'), St = e.from_html("<!> <!>", 1), Et = e.from_html('<div class="placeholder svelte-1vi3m5m"></div>'), Rt = e.from_html("<!> <!>", 1);
function Ee(m, t) {
  e.push(t, !1);
  let s = e.prop(t, "height", 8, void 0), r = e.prop(t, "min_height", 8, void 0), i = e.prop(t, "max_height", 8, void 0), l = e.prop(t, "width", 8, void 0), g = e.prop(t, "elem_id", 8, ""), v = e.prop(t, "elem_classes", 24, () => []), Z = e.prop(t, "variant", 8, "solid"), d = e.prop(t, "border_mode", 8, "base"), p = e.prop(t, "padding", 8, !0), c = e.prop(t, "type", 8, "normal"), M = e.prop(t, "test_id", 8, void 0), w = e.prop(t, "explicit_call", 8, !1), L = e.prop(t, "container", 8, !0), Y = e.prop(t, "visible", 8, !0), N = e.prop(t, "allow_overflow", 8, !0), X = e.prop(t, "overflow_behavior", 8, "auto"), W = e.prop(t, "scale", 8, null), B = e.prop(t, "min_width", 8, 0), a = e.prop(t, "flex", 12, !1), q = e.prop(t, "resizable", 8, !1), y = e.prop(t, "rtl", 8, !1), u = e.prop(t, "fullscreen", 12, !1), F = e.mutable_source(u()), S = e.mutable_source(), f = c() === "fieldset" ? "fieldset" : "div", se = e.mutable_source(0), te = e.mutable_source(0), z = e.mutable_source(null);
  function n(b) {
    u() && b.key === "Escape" && u(!1);
  }
  const C = (b) => {
    if (b !== void 0) {
      if (typeof b == "number")
        return b + "px";
      if (typeof b == "string")
        return b;
    }
  }, V = (b) => {
    let _ = b.clientY;
    const H = (j) => {
      const h = j.clientY - _;
      _ = j.clientY, e.mutate(S, e.get(S).style.height = `${e.get(S).offsetHeight + h}px`);
    }, o = () => {
      window.removeEventListener("mousemove", H), window.removeEventListener("mouseup", o);
    };
    window.addEventListener("mousemove", H), window.addEventListener("mouseup", o);
  };
  e.legacy_pre_effect(
    () => (e.deep_read_state(u()), e.get(F), e.get(S)),
    () => {
      u() !== e.get(F) && (e.set(F, u()), u() ? (e.set(z, e.get(S).getBoundingClientRect()), e.set(se, e.get(S).offsetHeight), e.set(te, e.get(S).offsetWidth), window.addEventListener("keydown", n)) : (e.set(z, null), window.removeEventListener("keydown", n)));
    }
  ), e.legacy_pre_effect(() => e.deep_read_state(Y()), () => {
    Y() || a(!1);
  }), e.legacy_pre_effect_reset(), e.init();
  var k = e.comment(), O = e.first_child(k);
  {
    var I = (b) => {
      var _ = Rt(), H = e.first_child(_);
      e.element(H, () => f, !1, (h, x) => {
        e.bind_this(h, (T) => e.set(S, T), () => e.get(S)), e.attribute_effect(
          h,
          (T, re) => ({
            "data-testid": M(),
            id: g(),
            class: `block ${T ?? ""}`,
            dir: y() ? "rtl" : "ltr",
            style: "",
            [e.CLASS]: {
              hidden: Y() === "hidden",
              padded: p(),
              flex: a(),
              border_focus: d() === "focus",
              border_contrast: d() === "contrast",
              "hide-container": !w() && !L(),
              fullscreen: u(),
              animating: u() && e.get(z) !== null,
              "auto-margin": W() === null
            },
            [e.STYLE]: re
          }),
          [
            () => (e.deep_read_state(v()), e.untrack(() => v()?.join(" ") || "")),
            () => ({
              height: (e.deep_read_state(u()), e.deep_read_state(s()), e.untrack(() => u() ? void 0 : C(s()))),
              "min-height": (e.deep_read_state(u()), e.deep_read_state(r()), e.untrack(() => u() ? void 0 : C(r()))),
              "max-height": (e.deep_read_state(u()), e.deep_read_state(i()), e.untrack(() => u() ? void 0 : C(i()))),
              "--start-top": (e.get(z), e.untrack(() => e.get(z) ? `${e.get(z).top}px` : "0px")),
              "--start-left": (e.get(z), e.untrack(() => e.get(z) ? `${e.get(z).left}px` : "0px")),
              "--start-width": (e.get(z), e.untrack(() => e.get(z) ? `${e.get(z).width}px` : "0px")),
              "--start-height": (e.get(z), e.untrack(() => e.get(z) ? `${e.get(z).height}px` : "0px")),
              width: (e.deep_read_state(u()), e.deep_read_state(l()), e.untrack(() => u() ? void 0 : typeof l() == "number" ? `calc(min(${l()}px, 100%))` : C(l()))),
              "border-style": Z(),
              overflow: N() ? X() : "hidden",
              "flex-grow": W(),
              "min-width": `calc(min(${B()}px, 100%))`,
              "border-width": "var(--block-border-width)"
            })
          ],
          void 0,
          void 0,
          "svelte-1vi3m5m"
        );
        var A = St(), E = e.first_child(A);
        e.slot(E, t, "default", {}, null);
        var U = e.sibling(E, 2);
        {
          var J = (T) => {
            var re = At();
            e.event("mousedown", re, V), e.append(T, re);
          };
          e.if(U, (T) => {
            q() && T(J);
          });
        }
        e.append(x, A);
      });
      var o = e.sibling(H, 2);
      {
        var j = (h) => {
          var x = Et();
          let A;
          e.template_effect(() => A = e.set_style(x, "", A, {
            height: e.get(se) + "px",
            width: e.get(te) + "px"
          })), e.append(h, x);
        };
        e.if(o, (h) => {
          u() && h(j);
        });
      }
      e.append(b, _);
    };
    e.if(O, (b) => {
      (Y() === !0 || Y() === "hidden") && b(I);
    });
  }
  e.append(m, k), e.pop();
}
e.from_html('<span data-testid="block-info"><!></span> <!>', 1);
var Ot = e.from_html('<label for="" data-testid="block-label"><span class="svelte-om2lfw"><!></span> </label>');
function Re(m, t) {
  let s = e.prop(t, "label", 8, null), r = e.prop(t, "Icon", 8), i = e.prop(t, "show_label", 8, !0), l = e.prop(t, "disable", 8, !1), g = e.prop(t, "float", 8, !0), v = e.prop(t, "rtl", 8, !1);
  var Z = Ot();
  let d;
  var p = e.child(Z), c = e.child(p);
  r()(c, {}), e.reset(p);
  var M = e.sibling(p);
  e.reset(Z), e.template_effect(() => {
    e.set_attribute(Z, "dir", v() ? "rtl" : "ltr"), d = e.set_class(Z, 1, "svelte-om2lfw", null, d, {
      hide: !i(),
      "sr-only": !i(),
      float: g(),
      "hide-label": l()
    }), e.set_text(M, ` ${s() ?? ""}`), Z.dir = Z.dir;
  }), e.append(m, Z);
}
e.from_html("<a><!></a>");
e.from_html('<span class="svelte-1k3q6xg"> </span>');
e.from_html("<button><!> <div><!> <!></div></button>");
var It = e.from_html('<div aria-label="Empty value"><div class="icon svelte-3uavfq"><!></div></div>');
function Oe(m, t) {
  e.push(t, !1);
  const s = e.mutable_source();
  let r = e.prop(t, "size", 8, "small"), i = e.prop(t, "unpadded_box", 8, !1), l = e.mutable_source();
  function g(c) {
    var M;
    if (!c) return !1;
    const { height: w } = c.getBoundingClientRect(), { height: L } = ((M = c.parentElement) === null || M === void 0 ? void 0 : M.getBoundingClientRect()) || { height: w };
    return w > L + 2;
  }
  e.legacy_pre_effect(() => e.get(l), () => {
    e.set(s, g(e.get(l)));
  }), e.legacy_pre_effect_reset();
  var v = It();
  let Z;
  var d = e.child(v), p = e.child(d);
  e.slot(p, t, "default", {}, null), e.reset(d), e.reset(v), e.bind_this(v, (c) => e.set(l, c), () => e.get(l)), e.template_effect(() => Z = e.set_class(v, 1, "empty svelte-3uavfq", null, Z, {
    small: r() === "small",
    large: r() === "large",
    unpadded_box: i(),
    small_parent: e.get(s)
  })), e.append(m, v), e.pop();
}
e.from_html('<div class="svelte-muhn75"><!></div>');
e.from_html('<h2 class="svelte-z8manb"> </h2>');
e.from_html('<p class="svelte-z8manb"> </p>');
e.from_html("<!> <!>", 1);
e.from_html('<span class="or svelte-z8manb"> </span> ', 1);
e.from_html(" <!>", 1);
e.from_html('<div class="wrap svelte-z8manb"><span><!></span> <!></div>');
e.from_html("<div><!></div>");
e.from_html('<button aria-label="Upload file"><!></button>');
e.from_html('<button aria-label="Record audio"><!></button>');
e.from_html('<button aria-label="Capture from camera"><!></button>');
e.from_html('<button aria-label="Paste from clipboard"><!></button>');
e.from_html('<span class="source-selection svelte-qbs9ew" data-testid="source-select"><!> <!> <!> <!></span>');
var Ft = e.from_html("<div><!> <!></div>");
function Yt(m, t) {
  e.push(t, !1);
  let s = e.prop(t, "top_panel", 8, !0), r = e.prop(t, "display_top_corner", 8, !1), i = e.prop(t, "show_background", 8, !0), l = e.prop(t, "buttons", 8, null), g = e.prop(t, "on_custom_button_click", 8, null);
  e.init();
  var v = Ft(), Z = e.child(v);
  e.slot(Z, t, "default", {}, null);
  var d = e.sibling(Z, 2);
  {
    var p = (c) => {
      var M = e.comment(), w = e.first_child(M);
      e.each(w, 1, l, e.index, (L, Y) => {
        var N = e.comment(), X = e.first_child(N);
        {
          var W = (B) => {
            CustomButton(B, {
              get button() {
                return e.get(Y);
              },
              on_click: (a) => {
                g() && g()(a);
              }
            });
          };
          e.if(X, (B) => {
            typeof e.get(Y) != "string" && B(W);
          });
        }
        e.append(L, N);
      }), e.append(c, M);
    };
    e.if(d, (c) => {
      l() && c(p);
    });
  }
  e.reset(v), e.template_effect(() => e.set_class(v, 1, `icon-button-wrapper ${s() ? "top-panel" : ""} ${r() ? "display-top-corner" : "hide-top-corner"} ${i() ? "" : "no-background"}`, "svelte-x2hd75")), e.append(m, v), e.pop();
}
e.from_html('<span class="custom-button-label svelte-if1k8y"> </span>');
e.from_html('<button class="custom-button svelte-if1k8y"><!></button>');
e.from_svg('<svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="19" x2="12" y2="5"></line><polyline points="5 12 12 5 19 12"></polyline></svg>');
e.from_svg('<svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="12px" height="24px" fill="currentColor" stroke-width="1.5" viewBox="0 0 12 24"><path d="M9 6L3 12L9 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" stroke-width="1.5" viewBox="0 0 24 24" color="currentColor"><path stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" d="M21.044 5.704a.6.6 0 0 1 .956.483v11.626a.6.6 0 0 1-.956.483l-7.889-5.813a.6.6 0 0 1 0-.966l7.89-5.813ZM10.044 5.704a.6.6 0 0 1 .956.483v11.626a.6.6 0 0 1-.956.483l-7.888-5.813a.6.6 0 0 1 0-.966l7.888-5.813Z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 32 32"><path d="M28.828 3.172a4.094 4.094 0 0 0-5.656 0L4.05 22.292A6.954 6.954 0 0 0 2 27.242V30h2.756a6.952 6.952 0 0 0 4.95-2.05L28.828 8.829a3.999 3.999 0 0 0 0-5.657zM10.91 18.26l2.829 2.829l-2.122 2.121l-2.828-2.828zm-2.619 8.276A4.966 4.966 0 0 1 4.756 28H4v-.759a4.967 4.967 0 0 1 1.464-3.535l1.91-1.91l2.829 2.828zM27.415 7.414l-12.261 12.26l-2.829-2.828l12.262-12.26a2.047 2.047 0 0 1 2.828 0a2 2 0 0 1 0 2.828z" fill="currentColor"></path><path d="M6.5 15a3.5 3.5 0 0 1-2.475-5.974l3.5-3.5a1.502 1.502 0 0 0 0-2.121a1.537 1.537 0 0 0-2.121 0L3.415 5.394L2 3.98l1.99-1.988a3.585 3.585 0 0 1 4.95 0a3.504 3.504 0 0 1 0 4.949L5.439 10.44a1.502 1.502 0 0 0 0 2.121a1.537 1.537 0 0 0 2.122 0l4.024-4.024L13 9.95l-4.025 4.024A3.475 3.475 0 0 1 6.5 15z" fill="currentColor"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M2.753 2.933a.75.75 0 0 1 .814-.68l3.043.272c2.157.205 4.224.452 5.922.732c1.66.273 3.073.594 3.844.983c.197.1.412.233.578.415c.176.192.352.506.28.9c-.067.356-.304.59-.487.729a3.001 3.001 0 0 1-.695.369c-1.02.404-2.952.79-5.984 1.169c-1.442.18-2.489.357-3.214.522c.205.045.43.089.674.132c.992.174 2.241.323 3.568.437a31.21 31.21 0 0 1 3.016.398c.46.087.893.186 1.261.296c.352.105.707.236.971.412c.13.086.304.225.42.437a.988.988 0 0 1 .063.141A1.75 1.75 0 0 0 14.5 12.25v.158c-.758.154-1.743.302-2.986.444c-2.124.243-3.409.55-4.117.859c-.296.128-.442.236-.508.3c.026.037.073.094.156.17c.15.138.369.29.65.45c.56.316 1.282.61 1.979.838l2.637.814a.75.75 0 1 1-.443 1.433l-2.655-.819c-.754-.247-1.58-.578-2.257-.96a5.082 5.082 0 0 1-.924-.65c-.255-.233-.513-.544-.62-.935c-.12-.441-.016-.88.274-1.244c.261-.328.656-.574 1.113-.773c.92-.4 2.387-.727 4.545-.974c1.366-.156 2.354-.313 3.041-.462a16.007 16.007 0 0 0-.552-.114a29.716 29.716 0 0 0-2.865-.378c-1.352-.116-2.649-.27-3.7-.454c-.524-.092-1-.194-1.395-.307c-.376-.106-.75-.241-1.021-.426a1.186 1.186 0 0 1-.43-.49a.934.934 0 0 1 .059-.873c.13-.213.32-.352.472-.442a3.23 3.23 0 0 1 .559-.251c.807-.287 2.222-.562 4.37-.83c2.695-.338 4.377-.666 5.295-.962c-.638-.21-1.623-.427-2.89-.635c-1.65-.273-3.679-.515-5.816-.718l-3.038-.272a.75.75 0 0 1-.68-.814M17 12.25a.75.75 0 0 0-1.5 0v4.19l-.72-.72a.75.75 0 1 0-1.06 1.06l2 2a.75.75 0 0 0 1.06 0l2-2a.75.75 0 1 0-1.06-1.06l-.72.72z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></rect><line x1="2" y1="9" x2="22" y2="9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></line><line x1="7" y1="2" x2="7" y2="6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></line><line x1="17" y1="2" x2="17" y2="6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" fill="none"></line></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-camera"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path><circle cx="12" cy="13" r="4"></circle></svg>');
e.from_svg('<svg viewBox="0 0 32 32"><path d="M28.828 3.172a4.094 4.094 0 0 0-5.656 0L4.05 22.292A6.954 6.954 0 0 0 2 27.242V30h2.756a6.952 6.952 0 0 0 4.95-2.05L28.828 8.829a3.999 3.999 0 0 0 0-5.657zM10.91 18.26l2.829 2.829l-2.122 2.121l-2.828-2.828zm-2.619 8.276A4.966 4.966 0 0 1 4.756 28H4v-.759a4.967 4.967 0 0 1 1.464-3.535l1.91-1.91l2.829 2.828zM27.415 7.414l-12.261 12.26l-2.829-2.828l12.262-12.26a2.047 2.047 0 0 1 2.828 0a2 2 0 0 1 0 2.828z" fill="currentColor"></path><path d="M6.5 15a3.5 3.5 0 0 1-2.475-5.974l3.5-3.5a1.502 1.502 0 0 0 0-2.121a1.537 1.537 0 0 0-2.121 0L3.415 5.394L2 3.98l1.99-1.988a3.585 3.585 0 0 1 4.95 0a3.504 3.504 0 0 1 0 4.949L5.439 10.44a1.502 1.502 0 0 0 0 2.121a1.537 1.537 0 0 0 2.122 0l4.024-4.024L13 9.95l-4.025 4.024A3.475 3.475 0 0 1 6.5 15z" fill="currentColor"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M17.74 30L16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84Z"></path><path fill="currentColor" d="M8 10h16v2H8zm0 6h10v2H8z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M5 13L9 17L19 7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6L8 10L12 6"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-circle"><circle cx="12" cy="12" r="10"></circle></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" stroke="currentColor" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"><g transform="matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"><path d="M18,6L6.087,17.913" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></g><path d="M4.364,4.364L19.636,19.636" style="fill:none;fill-rule:nonzero;stroke-width:2px;"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-closed-caption"><rect x="2" y="6" width="20" height="12" rx="2" ry="2"></rect><text x="12" y="15" font-family="sans-serif" font-size="8" font-weight="bold" fill="currentColor" stroke="none" text-anchor="middle">CC</text></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 32 32"><path fill="currentColor" d="m31 16l-7 7l-1.41-1.41L28.17 16l-5.58-5.59L24 9l7 7zM1 16l7-7l1.41 1.41L3.83 16l5.58 5.59L8 23l-7-7zm11.42 9.484L17.64 6l1.932.517L14.352 26z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 32 32"><circle cx="10" cy="12" r="2" fill="currentColor"></circle><circle cx="16" cy="9" r="2" fill="currentColor"></circle><circle cx="22" cy="12" r="2" fill="currentColor"></circle><circle cx="23" cy="18" r="2" fill="currentColor"></circle><circle cx="19" cy="23" r="2" fill="currentColor"></circle><path fill="currentColor" d="M16.54 2A14 14 0 0 0 2 16a4.82 4.82 0 0 0 6.09 4.65l1.12-.31a3 3 0 0 1 3.79 2.9V27a3 3 0 0 0 3 3a14 14 0 0 0 14-14.54A14.05 14.05 0 0 0 16.54 2Zm8.11 22.31A11.93 11.93 0 0 1 16 28a1 1 0 0 1-1-1v-3.76a5 5 0 0 0-5-5a5.07 5.07 0 0 0-1.33.18l-1.12.31A2.82 2.82 0 0 1 4 16A12 12 0 0 1 16.47 4A12.18 12.18 0 0 1 28 15.53a11.89 11.89 0 0 1-3.35 8.79Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M12 22q-2.05 0-3.875-.788t-3.187-2.15t-2.15-3.187T2 12q0-2.075.813-3.9t2.2-3.175T8.25 2.788T12.2 2q2 0 3.775.688t3.113 1.9t2.125 2.875T22 11.05q0 2.875-1.75 4.413T16 17h-1.85q-.225 0-.312.125t-.088.275q0 .3.375.863t.375 1.287q0 1.25-.687 1.85T12 22m-5.5-9q.65 0 1.075-.425T8 11.5t-.425-1.075T6.5 10t-1.075.425T5 11.5t.425 1.075T6.5 13m3-4q.65 0 1.075-.425T11 7.5t-.425-1.075T9.5 6t-1.075.425T8 7.5t.425 1.075T9.5 9m5 0q.65 0 1.075-.425T16 7.5t-.425-1.075T14.5 6t-1.075.425T13 7.5t.425 1.075T14.5 9m3 4q.65 0 1.075-.425T19 11.5t-.425-1.075T17.5 10t-1.075.425T16 11.5t.425 1.075T17.5 13"></path></svg>');
e.from_svg('<svg id="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="100%" height="100%"><path d="M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z" fill="currentColor"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 33 33" color="currentColor" aria-hidden="true" width="100%" height="100%"><path fill="currentColor" d="M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"></path><path fill="currentColor" d="M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 256 256"><path fill="currentColor" d="M240 192a8 8 0 0 1-8 8h-32v32a8 8 0 0 1-16 0v-32H64a8 8 0 0 1-8-8V72H24a8 8 0 0 1 0-16h32V24a8 8 0 0 1 16 0v160h160a8 8 0 0 1 8 8M96 72h88v88a8 8 0 0 0 16 0V64a8 8 0 0 0-8-8H96a8 8 0 0 0 0 16"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 32 32"><path fill="currentColor" d="M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"></path></svg>');
e.from_svg('<svg class="dropdown-arrow svelte-vpa7j" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 18 18"><path d="M5 8l4 4 4-4z"></path></svg>');
e.from_svg('<svg class="dropdown-arrow svelte-75qyoe" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 18 18"><circle cx="9" cy="9" r="8" class="circle svelte-75qyoe"></circle><path d="M5 8l4 4 4-4z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><g fill="none"><path fill="currentColor" d="m5.505 11.41l.53.53l-.53-.53ZM3 14.952h-.75H3ZM9.048 21v.75V21ZM11.41 5.505l-.53-.53l.53.53Zm1.831 12.34a.75.75 0 0 0 1.06-1.061l-1.06 1.06ZM7.216 9.697a.75.75 0 1 0-1.06 1.061l1.06-1.06Zm10.749 2.362l-5.905 5.905l1.06 1.06l5.905-5.904l-1.06-1.06Zm-11.93-.12l5.905-5.905l-1.06-1.06l-5.905 5.904l1.06 1.06Zm0 6.025c-.85-.85-1.433-1.436-1.812-1.933c-.367-.481-.473-.79-.473-1.08h-1.5c0 .749.312 1.375.78 1.99c.455.596 1.125 1.263 1.945 2.083l1.06-1.06Zm-1.06-7.086c-.82.82-1.49 1.488-1.945 2.084c-.468.614-.78 1.24-.78 1.99h1.5c0-.29.106-.6.473-1.08c.38-.498.962-1.083 1.812-1.933l-1.06-1.06Zm7.085 7.086c-.85.85-1.435 1.433-1.933 1.813c-.48.366-.79.472-1.08.472v1.5c.75 0 1.376-.312 1.99-.78c.596-.455 1.264-1.125 2.084-1.945l-1.06-1.06Zm-7.085 1.06c.82.82 1.487 1.49 2.084 1.945c.614.468 1.24.78 1.989.78v-1.5c-.29 0-.599-.106-1.08-.473c-.497-.38-1.083-.962-1.933-1.812l-1.06 1.06Zm12.99-12.99c.85.85 1.433 1.436 1.813 1.933c.366.481.472.79.472 1.08h1.5c0-.749-.312-1.375-.78-1.99c-.455-.596-1.125-1.263-1.945-2.083l-1.06 1.06Zm1.06 7.086c.82-.82 1.49-1.488 1.945-2.084c.468-.614.78-1.24.78-1.99h-1.5c0 .29-.106.6-.473 1.08c-.38.498-.962 1.083-1.812 1.933l1.06 1.06Zm0-8.146c-.82-.82-1.487-1.49-2.084-1.945c-.614-.468-1.24-.78-1.989-.78v1.5c.29 0 .599.106 1.08.473c.497.38 1.083.962 1.933 1.812l1.06-1.06Zm-7.085 1.06c.85-.85 1.435-1.433 1.933-1.812c.48-.367.79-.473 1.08-.473v-1.5c-.75 0-1.376.312-1.99.78c-.596.455-1.264 1.125-2.084 1.945l1.06 1.06Zm2.362 10.749L7.216 9.698l-1.06 1.061l7.085 7.085l1.06-1.06Z"></path><path stroke="currentColor" stroke-linecap="round" stroke-width="1.5" d="M9 21h12"></path></g></svg>');
e.from_svg('<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M21.03 2.97a3.578 3.578 0 0 0-5.06 0L14 4.94l-.013-.013a1.75 1.75 0 0 0-2.475 0l-.585.586a1.75 1.75 0 0 0 0 2.475l.012.012l-6.78 6.78a2.25 2.25 0 0 0-.659 1.592v.687l-1.28 2.347c-.836 1.533.841 3.21 2.374 2.375l2.347-1.28h.688a2.25 2.25 0 0 0 1.59-.66L16 13.061l.012.012a1.75 1.75 0 0 0 2.475 0l.586-.585a1.75 1.75 0 0 0 0-2.475L19.061 10l1.97-1.97a3.578 3.578 0 0 0 0-5.06ZM12 9.061l2.94 2.94l-6.78 6.78a.75.75 0 0 1-.531.22H6.75a.75.75 0 0 0-.359.09l-2.515 1.373a.234.234 0 0 1-.159.032a.264.264 0 0 1-.138-.075a.264.264 0 0 1-.075-.138a.234.234 0 0 1 .033-.158l1.372-2.515A.75.75 0 0 0 5 17.25v-.878a.75.75 0 0 1 .22-.53L12 9.06Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" fill="currentColor" stroke-width="1.5" viewBox="0 0 24 24" color="currentColor"><path stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" d="M2.956 5.704A.6.6 0 0 0 2 6.187v11.626a.6.6 0 0 0 .956.483l7.889-5.813a.6.6 0 0 0 0-.966l-7.89-5.813ZM13.956 5.704a.6.6 0 0 0-.956.483v11.626a.6.6 0 0 0 .956.483l7.889-5.813a.6.6 0 0 0 0-.966l-7.89-5.813Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-file"><path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path><polyline points="13 2 13 9 20 9"></polyline></svg>');
e.from_svg('<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z"></path></svg>');
e.from_svg('<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-image"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 256 256"><path fill="currentColor" d="M200 32h-36.26a47.92 47.92 0 0 0-71.48 0H56a16 16 0 0 0-16 16v168a16 16 0 0 0 16 16h144a16 16 0 0 0 16-16V48a16 16 0 0 0-16-16m-72 0a32 32 0 0 1 32 32H96a32 32 0 0 1 32-32m72 184H56V48h26.75A47.9 47.9 0 0 0 80 64v8a8 8 0 0 0 8 8h80a8 8 0 0 0 8-8v-8a47.9 47.9 0 0 0-2.75-16H200Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--mdi" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24"><path fill="currentColor" d="M5 3h2v2H5v5a2 2 0 0 1-2 2a2 2 0 0 1 2 2v5h2v2H5c-1.07-.27-2-.9-2-2v-4a2 2 0 0 0-2-2H0v-2h1a2 2 0 0 0 2-2V5a2 2 0 0 1 2-2m14 0a2 2 0 0 1 2 2v4a2 2 0 0 0 2 2h1v2h-1a2 2 0 0 0-2 2v4a2 2 0 0 1-2 2h-2v-2h2v-5a2 2 0 0 1 2-2a2 2 0 0 1-2-2V5h-2V3h2m-7 12a1 1 0 0 1 1 1a1 1 0 0 1-1 1a1 1 0 0 1-1-1a1 1 0 0 1 1-1m-4 0a1 1 0 0 1 1 1a1 1 0 0 1-1 1a1 1 0 0 1-1-1a1 1 0 0 1 1-1m8 0a1 1 0 0 1 1 1a1 1 0 0 1-1 1a1 1 0 0 1-1-1a1 1 0 0 1 1-1Z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.35327 10.9495L6.77663 15.158C7.12221 15.4229 7.50051 15.5553 7.91154 15.5553C8.32258 15.5553 8.70126 15.4229 9.0476 15.158L14.471 10.9495" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"></path><path d="M7.23461 11.4324C7.23406 11.432 7.2335 11.4316 7.23295 11.4312L1.81496 7.2268C1.81471 7.22661 1.81446 7.22641 1.8142 7.22621C1.52269 6.99826 1.39429 6.73321 1.39429 6.37014C1.39429 6.00782 1.52236 5.74301 1.81325 5.51507C1.8136 5.5148 1.81394 5.51453 1.81428 5.51426L7.2331 1.30812C7.45645 1.13785 7.67632 1.06653 7.91159 1.06653C8.14692 1.06653 8.36622 1.13787 8.58861 1.30787C8.58915 1.30828 8.58969 1.30869 8.59023 1.30911L14.0082 5.51462C14.0085 5.51485 14.0088 5.51507 14.0091 5.51529C14.3008 5.74345 14.4289 6.00823 14.4289 6.37014C14.4289 6.73356 14.3006 6.99862 14.01 7.22634C14.0096 7.22662 14.0093 7.22689 14.0089 7.22717L8.59007 11.4322C8.36672 11.6024 8.14686 11.6738 7.91159 11.6738C7.67628 11.6738 7.45699 11.6024 7.23461 11.4324Z" stroke="currentColor" stroke-width="1.5"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M4 2H2v26a2 2 0 0 0 2 2h26v-2H4v-3h22v-8H4v-4h14V5H4Zm20 17v4H4v-4ZM16 7v4H4V7Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-maximize" width="100%" height="100%"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-mic"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-minimize" width="100%" height="100%"><path d="M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-music"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path d="M2 12.026c0 5.146 3.867 9.387 8.847 9.96c.735.085 1.447-.228 1.97-.753a1.68 1.68 0 0 0 0-2.372c-.523-.525-.95-1.307-.555-1.934c1.576-2.508 9.738 3.251 9.738-4.9C22 6.488 17.523 2 12 2S2 6.489 2 12.026Z"></path><circle cx="17.5" cy="11.5" r=".75"></circle><circle cx="6.5" cy="11.5" r=".75"></circle><path d="M10.335 7a.75.75 0 1 1-1.5 0a.75.75 0 0 1 1.5 0Zm4.915 0a.75.75 0 1 1-1.5 0a.75.75 0 0 1 1.5 0Z"></path></g></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M10.05 23q-.75 0-1.4-.337T7.575 21.7l-5.9-8.65q-.2-.3-.175-.65t.3-.6q.475-.475 1.125-.55t1.175.3L7 13.575V4q0-.425.288-.712T8 3t.713.288T9 4v11.5q0 .6-.537.888t-1.038-.063l-2.125-1.5l3.925 5.725q.125.2.35.325t.475.125H17q.825 0 1.413-.587T19 19V5q0-.425.288-.712T20 4t.713.288T21 5v14q0 1.65-1.175 2.825T17 23zM12 1q.425 0 .713.288T13 2v9q0 .425-.288.713T12 12t-.712-.288T11 11V2q0-.425.288-.712T12 1m4 1q.425 0 .713.288T17 3v8q0 .425-.288.713T16 12t-.712-.288T15 11V3q0-.425.288-.712T16 2m-3.85 14.5"></path></svg>');
e.from_svg('<svg fill="currentColor" width="100%" height="100%" viewBox="0 0 1920 1920" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M1752.768 221.109C1532.646.986 1174.283.986 954.161 221.109l-838.588 838.588c-154.052 154.165-154.052 404.894 0 558.946 149.534 149.421 409.976 149.308 559.059 0l758.738-758.626c87.982-88.094 87.982-231.417 0-319.51-88.32-88.208-231.642-87.982-319.51 0l-638.796 638.908 79.85 79.849 638.795-638.908c43.934-43.821 115.539-43.934 159.812 0 43.934 44.047 43.934 115.877 0 159.812l-758.739 758.625c-110.23 110.118-289.355 110.005-399.36 0-110.118-110.117-110.005-289.242 0-399.247l838.588-838.588c175.963-175.962 462.382-176.188 638.909 0 176.075 176.188 176.075 462.833 0 638.908l-798.607 798.72 79.849 79.85 798.607-798.72c220.01-220.123 220.01-578.485 0-798.607" fill-rule="evenodd"></path></g></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><circle cx="20" cy="4" r="2" fill="currentColor"></circle><circle cx="8" cy="16" r="2" fill="currentColor"></circle><circle cx="28" cy="12" r="2" fill="currentColor"></circle><circle cx="11" cy="7" r="2" fill="currentColor"></circle><circle cx="16" cy="24" r="2" fill="currentColor"></circle><path fill="currentColor" d="M30 3.413L28.586 2L4 26.585V2H2v26a2 2 0 0 0 2 2h26v-2H5.413Z"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 12H12M18 12H12M12 12V6M12 12V18" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-rotate-ccw" style="transform: rotateY(180deg);"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="100%" height="100%"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 1024 1024"><path fill="currentColor" d="M672 418H144c-17.7 0-32 14.3-32 32v414c0 17.7 14.3 32 32 32h528c17.7 0 32-14.3 32-32V450c0-17.7-14.3-32-32-32zm-44 402H188V494h440v326z"></path><path fill="currentColor" d="M819.3 328.5c-78.8-100.7-196-153.6-314.6-154.2l-.2-64c0-6.5-7.6-10.1-12.6-6.1l-128 101c-4 3.1-3.9 9.1 0 12.3L492 318.6c5.1 4 12.7.4 12.6-6.1v-63.9c12.9.1 25.9.9 38.8 2.5c42.1 5.2 82.1 18.2 119 38.7c38.1 21.2 71.2 49.7 98.4 84.3c27.1 34.7 46.7 73.7 58.1 115.8c11 40.7 14 82.7 8.9 124.8c-.7 5.4-1.4 10.8-2.4 16.1h74.9c14.8-103.6-11.3-213-81-302.3z"></path></svg>');
e.from_svg('<svg viewBox="0 0 22 24" width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M19.1168 12.1484C19.474 12.3581 19.9336 12.2384 20.1432 11.8811C20.3528 11.5238 20.2331 11.0643 19.8758 10.8547L19.1168 12.1484ZM6.94331 4.13656L6.55624 4.77902L6.56378 4.78344L6.94331 4.13656ZM5.92408 4.1598L5.50816 3.5357L5.50816 3.5357L5.92408 4.1598ZM5.51031 5.09156L4.76841 5.20151C4.77575 5.25101 4.78802 5.29965 4.80505 5.34671L5.51031 5.09156ZM7.12405 11.7567C7.26496 12.1462 7.69495 12.3477 8.08446 12.2068C8.47397 12.0659 8.67549 11.6359 8.53458 11.2464L7.12405 11.7567ZM19.8758 12.1484C20.2331 11.9388 20.3528 11.4793 20.1432 11.122C19.9336 10.7648 19.474 10.6451 19.1168 10.8547L19.8758 12.1484ZM6.94331 18.8666L6.56375 18.2196L6.55627 18.2241L6.94331 18.8666ZM5.92408 18.8433L5.50815 19.4674H5.50815L5.92408 18.8433ZM5.51031 17.9116L4.80505 17.6564C4.78802 17.7035 4.77575 17.7521 4.76841 17.8016L5.51031 17.9116ZM8.53458 11.7567C8.67549 11.3672 8.47397 10.9372 8.08446 10.7963C7.69495 10.6554 7.26496 10.8569 7.12405 11.2464L8.53458 11.7567ZM19.4963 12.2516C19.9105 12.2516 20.2463 11.9158 20.2463 11.5016C20.2463 11.0873 19.9105 10.7516 19.4963 10.7516V12.2516ZM7.82931 10.7516C7.4151 10.7516 7.07931 11.0873 7.07931 11.5016C7.07931 11.9158 7.4151 12.2516 7.82931 12.2516V10.7516ZM19.8758 10.8547L7.32284 3.48968L6.56378 4.78344L19.1168 12.1484L19.8758 10.8547ZM7.33035 3.49414C6.76609 3.15419 6.05633 3.17038 5.50816 3.5357L6.34 4.78391C6.40506 4.74055 6.4893 4.73863 6.55627 4.77898L7.33035 3.49414ZM5.50816 3.5357C4.95998 3.90102 4.67184 4.54987 4.76841 5.20151L6.25221 4.98161C6.24075 4.90427 6.27494 4.82727 6.34 4.78391L5.50816 3.5357ZM4.80505 5.34671L7.12405 11.7567L8.53458 11.2464L6.21558 4.83641L4.80505 5.34671ZM19.1168 10.8547L6.56378 18.2197L7.32284 19.5134L19.8758 12.1484L19.1168 10.8547ZM6.55627 18.2241C6.4893 18.2645 6.40506 18.2626 6.34 18.2192L5.50815 19.4674C6.05633 19.8327 6.76609 19.8489 7.33035 19.509L6.55627 18.2241ZM6.34 18.2192C6.27494 18.1759 6.24075 18.0988 6.25221 18.0215L4.76841 17.8016C4.67184 18.4532 4.95998 19.1021 5.50815 19.4674L6.34 18.2192ZM6.21558 18.1667L8.53458 11.7567L7.12405 11.2464L4.80505 17.6564L6.21558 18.1667ZM19.4963 10.7516H7.82931V12.2516H19.4963V10.7516Z" fill="currentColor"></path></g></svg>');
e.from_svg('<svg enable-background="new 0 0 32 32" height="20" width="20" viewBox="0 0 32 32" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="m30 8h-4.1c-.5-2.3-2.5-4-4.9-4s-4.4 1.7-4.9 4h-14.1v2h14.1c.5 2.3 2.5 4 4.9 4s4.4-1.7 4.9-4h4.1zm-9 4c-1.7 0-3-1.3-3-3s1.3-3 3-3 3 1.3 3 3-1.3 3-3 3z"></path><path d="m2 24h4.1c.5 2.3 2.5 4 4.9 4s4.4-1.7 4.9-4h14.1v-2h-14.1c-.5-2.3-2.5-4-4.9-4s-4.4 1.7-4.9 4h-4.1zm9-4c1.7 0 3 1.3 3 3s-1.3 3-3 3-3-1.3-3-3 1.3-3 3-3z"></path><path d="m0 0h32v32h-32z" fill="none"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit-2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" class="feather feather-square"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-table"><path d="M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18"></path></svg>');
var Gt = e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M12 15H5a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h5V5a1 1 0 0 0-1-1H3V2h6a3 3 0 0 1 3 3zM5 9a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h5V9zm15 14v2a1 1 0 0 0 1 1h5v-4h-5a1 1 0 0 0-1 1z"></path><path fill="currentColor" d="M2 30h28V2Zm26-2h-7a3 3 0 0 1-3-3v-2a3 3 0 0 1 3-3h5v-2a1 1 0 0 0-1-1h-6v-2h6a3 3 0 0 1 3 3Z"></path></svg>');
function ye(m) {
  var t = Gt();
  e.append(m, t);
}
e.from_svg(`<svg id="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" fill="currentColor" width="100%" height="100%"><defs><style>.cls-1 {
				fill: none;
			}</style></defs><rect x="12" y="12" width="2" height="12"></rect><rect x="18" y="12" width="2" height="12"></rect><path d="M4,6V8H6V28a2,2,0,0,0,2,2H24a2,2,0,0,0,2-2V8h2V6ZM8,28V8H24V28Z"></path><rect x="12" y="2" width="8" height="2"></rect><rect id="_Transparent_Rectangle_" data-name="&lt;Transparent Rectangle>" class="cls-1" width="32" height="32"></rect></svg>`);
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--carbon" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="0 0 32 32"><path fill="currentColor" d="M23 9.005h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v1H11v-1a2 2 0 0 0-2-2H3a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h4v20a2.002 2.002 0 0 0 2 2h4v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v1h-4v-9h4v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-6a2 2 0 0 0-2 2v1h-4v-9h4v1a2 2 0 0 0 2 2Zm0-6h6v4h-6Zm-14 4H3v-4h6Zm14 18h6v4h-6Zm0-11h6v4h-6Z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-scissors"><circle cx="6" cy="6" r="3"></circle><circle cx="6" cy="18" r="3"></circle><line x1="20" y1="4" x2="8.12" y2="15.88"></line><line x1="14.47" y1="14.48" x2="20" y2="20"></line><line x1="8.12" y1="8.12" x2="12" y2="12"></line></svg>');
e.from_svg('<svg aria-label="undo" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-rotate-ccw"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="90%" height="90%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-upload"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-video"><polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M12 16q1.875 0 3.188-1.312T16.5 11.5t-1.312-3.187T12 7T8.813 8.313T7.5 11.5t1.313 3.188T12 16m0-1.8q-1.125 0-1.912-.788T9.3 11.5t.788-1.912T12 8.8t1.913.788t.787 1.912t-.787 1.913T12 14.2m0 4.8q-3.65 0-6.65-2.037T1 11.5q1.35-3.425 4.35-5.462T12 4t6.65 2.038T23 11.5q-1.35 3.425-4.35 5.463T12 19"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="m19.8 22.6l-4.2-4.15q-.875.275-1.762.413T12 19q-3.775 0-6.725-2.087T1 11.5q.525-1.325 1.325-2.463T4.15 7L1.4 4.2l1.4-1.4l18.4 18.4zM12 16q.275 0 .513-.025t.512-.1l-5.4-5.4q-.075.275-.1.513T7.5 11.5q0 1.875 1.313 3.188T12 16m7.3.45l-3.175-3.15q.175-.425.275-.862t.1-.938q0-1.875-1.312-3.187T12 7q-.5 0-.937.1t-.863.3L7.65 4.85q1.025-.425 2.1-.637T12 4q3.775 0 6.725 2.088T23 11.5q-.575 1.475-1.513 2.738T19.3 16.45m-4.625-4.6l-3-3q.7-.125 1.288.113t1.012.687t.613 1.038t.087 1.162"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" color="currentColor"><title>Low volume</title><path d="M19.5 7.5C19.5 7.5 21 9 21 11.5C21 14 19.5 15.5 19.5 15.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M2 13.8571V10.1429C2 9.03829 2.89543 8.14286 4 8.14286H6.9C7.09569 8.14286 7.28708 8.08544 7.45046 7.97772L13.4495 4.02228C14.1144 3.5839 15 4.06075 15 4.85714V19.1429C15 19.9392 14.1144 20.4161 13.4495 19.9777L7.45046 16.0223C7.28708 15.9146 7.09569 15.8571 6.9 15.8571H4C2.89543 15.8571 2 14.9617 2 13.8571Z" stroke-width="1.5"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg" color="currentColor"><title>High volume</title><path d="M1 13.8571V10.1429C1 9.03829 1.89543 8.14286 3 8.14286H5.9C6.09569 8.14286 6.28708 8.08544 6.45046 7.97772L12.4495 4.02228C13.1144 3.5839 14 4.06075 14 4.85714V19.1429C14 19.9392 13.1144 20.4161 12.4495 19.9777L6.45046 16.0223C6.28708 15.9146 6.09569 15.8571 5.9 15.8571H3C1.89543 15.8571 1 14.9617 1 13.8571Z" stroke-width="1.5"></path><path d="M17.5 7.5C17.5 7.5 19 9 19 11.5C19 14 17.5 15.5 17.5 15.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M20.5 4.5C20.5 4.5 23 7 23 11.5C23 16 20.5 18.5 20.5 18.5" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" stroke-width="1.5" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" color="currentColor"><title>Muted volume</title><g clip-path="url(#clip0_3173_16686)"><path d="M18 14L20.0005 12M22 10L20.0005 12M20.0005 12L18 10M20.0005 12L22 14" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M2 13.8571V10.1429C2 9.03829 2.89543 8.14286 4 8.14286H6.9C7.09569 8.14286 7.28708 8.08544 7.45046 7.97772L13.4495 4.02228C14.1144 3.5839 15 4.06075 15 4.85714V19.1429C15 19.9392 14.1144 20.4161 13.4495 19.9777L7.45046 16.0223C7.28708 15.9146 7.09569 15.8571 6.9 15.8571H4C2.89543 15.8571 2 14.9617 2 13.8571Z" stroke-width="1.5"></path></g><defs><clipPath id="clip0_3173_16686"><rect width="24" height="24" fill="white"></rect></clipPath></defs></svg>');
e.from_svg('<svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke-linecap="round" stroke-linejoin="round"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="currentColor" d="M12 2c-4.963 0-9 4.038-9 9c0 3.328 1.82 6.232 4.513 7.79l-2.067 1.378A1 1 0 0 0 6 22h12a1 1 0 0 0 .555-1.832l-2.067-1.378C19.18 17.232 21 14.328 21 11c0-4.962-4.037-9-9-9zm0 16c-3.859 0-7-3.141-7-7c0-3.86 3.141-7 7-7s7 3.14 7 7c0 3.859-3.141 7-7 7z"></path><path fill="currentColor" d="M12 6c-2.757 0-5 2.243-5 5s2.243 5 5 5s5-2.243 5-5s-2.243-5-5-5zm0 8c-1.654 0-3-1.346-3-3s1.346-3 3-3s3 1.346 3 3s-1.346 3-3 3z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 50 50" class="svelte-nex6uu"><circle cx="25" cy="25" r="20" fill="none" stroke-width="3.0" stroke-linecap="round" stroke-dasharray="94.2477796076938 94.2477796076938" stroke-dashoffset="0" class="svelte-nex6uu"><animateTransform attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" repeatCount="indefinite" class="svelte-nex6uu"></animateTransform></circle></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 256 256"><path fill="currentColor" d="M144 120v88a8 8 0 0 1-8 8H48a8 8 0 0 1-8-8v-88a8 8 0 0 1 8-8h88a8 8 0 0 1 8 8m64 56a8 8 0 0 0-8 8v16h-24a8 8 0 0 0 0 16h24a16 16 0 0 0 16-16v-16a8 8 0 0 0-8-8m0-72a8 8 0 0 0-8 8v32a8 8 0 0 0 16 0v-32a8 8 0 0 0-8-8m-8-64h-16a8 8 0 0 0 0 16h16v16a8 8 0 0 0 16 0V56a16 16 0 0 0-16-16m-56 0h-32a8 8 0 0 0 0 16h32a8 8 0 0 0 0-16M48 88a8 8 0 0 0 8-8V56h16a8 8 0 0 0 0-16H56a16 16 0 0 0-16 16v24a8 8 0 0 0 8 8"></path></svg>');
e.from_svg('<svg width="100%" height="100%" stroke-width="1.5" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" color="currentColor"><path d="M19.1679 9C18.0247 6.46819 15.3006 4.5 11.9999 4.5C8.31459 4.5 5.05104 7.44668 4.54932 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M16 9H19.4C19.7314 9 20 8.73137 20 8.4V5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M4.88146 15C5.92458 17.5318 8.64874 19.5 12.0494 19.5C15.7347 19.5 18.9983 16.5533 19.5 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8.04932 15H4.64932C4.31795 15 4.04932 15.2686 4.04932 15.6V19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 20L12 4M12 20L7 15M12 20L17 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21l-4.343-4.343m0 0A8 8 0 1 0 5.343 5.343a8 8 0 0 0 11.314 11.314M11 8v6m-3-3h6"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21l-4.343-4.343m0 0A8 8 0 1 0 5.343 5.343a8 8 0 0 0 11.314 11.314M8 11h6"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="currentColor" d="M12.1 2a9.8 9.8 0 0 0-5.4 1.6l6.4 6.4a2.1 2.1 0 0 1 .2 3a2.1 2.1 0 0 1-3-.2L3.7 6.4A9.84 9.84 0 0 0 2 12.1a10.14 10.14 0 0 0 10.1 10.1a11 11 0 0 0 2.6-.3l6.7 6.7a5 5 0 0 0 7.1-7.1l-6.7-6.7a11 11 0 0 0 .3-2.6A10 10 0 0 0 12.1 2m8 10.1a7.6 7.6 0 0 1-.3 2.1l-.3 1.1l.8.8l6.7 6.7a2.88 2.88 0 0 1 .9 2.1A2.72 2.72 0 0 1 27 27a2.9 2.9 0 0 1-4.2 0l-6.7-6.7l-.8-.8l-1.1.3a7.6 7.6 0 0 1-2.1.3a8.27 8.27 0 0 1-5.7-2.3A7.63 7.63 0 0 1 4 12.1a8.3 8.3 0 0 1 .3-2.2l4.4 4.4a4.14 4.14 0 0 0 5.9.2a4.14 4.14 0 0 0-.2-5.9L10 4.2a6.5 6.5 0 0 1 2-.3a8.27 8.27 0 0 1 5.7 2.3a8.5 8.5 0 0 1 2.4 5.9"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="currentColor" d="M17.74 30L16 29l4-7h6a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h9v2H6a4 4 0 0 1-4-4V8a4 4 0 0 1 4-4h20a4 4 0 0 1 4 4v12a4 4 0 0 1-4 4h-4.84Z"></path><path fill="currentColor" d="M8 10h16v2H8zm0 6h10v2H8z"></path></svg>');
e.from_svg('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="currentColor" d="M19 10h7v2h-7zm0 5h7v2h-7zm0 5h7v2h-7z"></path><path fill="currentColor" d="M28 5H4a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h24a2.003 2.003 0 0 0 2-2V7a2 2 0 0 0-2-2M4 7h11v18H4Zm13 18V7h11l.002 18Z"></path></svg>');
var Pt = function(m, t, s, r) {
  function i(l) {
    return l instanceof s ? l : new s(function(g) {
      g(l);
    });
  }
  return new (s || (s = Promise))(function(l, g) {
    function v(p) {
      try {
        d(r.next(p));
      } catch (c) {
        g(c);
      }
    }
    function Z(p) {
      try {
        d(r.throw(p));
      } catch (c) {
        g(c);
      }
    }
    function d(p) {
      p.done ? l(p.value) : i(p.value).then(v, Z);
    }
    d((r = r.apply(m, t || [])).next());
  });
};
let Ce = [], Be = !1;
const Dt = typeof window < "u", Pe = Dt ? window.requestAnimationFrame : (m) => {
};
function Nt(m) {
  return Pt(this, arguments, void 0, function* (t, s = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && s !== !0)) {
      if (Ce.push(t), !Be) Be = !0;
      else return;
      yield et(), Pe(() => {
        let r = [0, 0];
        for (let i = 0; i < Ce.length; i++) {
          const g = Ce[i].getBoundingClientRect();
          (i === 0 || g.top + window.scrollY <= r[0]) && (r[0] = g.top + window.scrollY, r[1] = i);
        }
        window.scrollTo({ top: r[0] - 20, behavior: "smooth" }), Be = !1, Ce = [];
      });
    }
  });
}
var Ut = e.from_html('<div class="validation-error svelte-2b1o8r"> <button class="svelte-2b1o8r"><!></button></div>'), Wt = e.from_html('<div class="eta-bar svelte-2b1o8r"></div>'), Kt = e.from_html("<!> ", 1), Xt = e.from_html("<!> <!> <!> <!>", 1), Jt = e.from_html('<div class="progress-level svelte-2b1o8r"><div class="progress-level-inner svelte-2b1o8r"><!></div> <div class="progress-bar-wrap svelte-2b1o8r"><div class="progress-bar svelte-2b1o8r"></div></div></div>'), Qt = e.from_html('<p class="loading svelte-2b1o8r"> </p> <!>', 1), $t = e.from_html("<!> <div><!> <!></div> <!> <!>", 1), e0 = e.from_html('<div class="clear-status svelte-2b1o8r"><!></div> <span class="error svelte-2b1o8r"> </span> <!>', 1), t0 = e.from_html('<div data-testid="status-tracker"><!> <!></div>');
function Ie(m, t) {
  e.push(t, !0);
  let s = e.prop(t, "eta", 7, null), r = e.prop(t, "scroll_to_output", 3, !1), i = e.prop(t, "timer", 3, !0), l = e.prop(t, "show_progress", 3, "full"), g = e.prop(t, "message", 3, null), v = e.prop(t, "progress", 3, null), Z = e.prop(t, "variant", 3, "default"), d = e.prop(t, "loading_text", 3, "Loading..."), p = e.prop(t, "absolute", 3, !0), c = e.prop(t, "translucent", 3, !1), M = e.prop(t, "border", 3, !1), w = e.prop(t, "validation_error", 7, null), L = e.prop(t, "show_validation_error", 3, !0), Y = e.prop(t, "type", 3, null), N, X = !1, W = e.state(0), B = e.state(null), a = e.state(null), q = e.state(!1), y = e.state(null);
  const u = e.derived(() => Y() === "input" || !t.status || t.status === "complete" || l() === "hidden" || t.status == "streaming" || !!(L() && w()));
  let F = e.state(0);
  const S = e.derived(() => e.get(a) === null || e.get(a) <= 0 || !e.get(F) ? 0 : Math.min(e.get(F) / e.get(a), 1)), f = e.derived(() => e.get(F).toFixed(1));
  let se = e.derived(() => v() == null);
  function te() {
    Pe(() => {
      e.set(F, (performance.now() - e.get(W)) / 1e3), X && te();
    });
  }
  let z = e.derived(() => {
    let h = null;
    v() != null ? h = v().map((E) => {
      if (E.index != null && E.length != null)
        return E.index / E.length;
      if (E.progress != null)
        return E.progress;
    }) : h = null;
    let x, A = "";
    return h ? (x = h[h.length - 1], x === 0 ? A = "0" : A = "150ms") : x = void 0, {
      progress_level: h,
      last_progress_level: x,
      progress_bar_transition: A
    };
  });
  function n() {
    X || (e.set(B, e.set(y, null), !0), e.set(W, performance.now(), !0), X = !0, te());
  }
  function C() {
    e.set(B, e.set(y, null), !0), X && (X = !1);
  }
  e.user_effect(() => {
    t.status === "pending" ? n() : untrack(() => {
      C();
    });
  }), e.user_effect(() => {
    N && r() && (t.status === "pending" || t.status === "complete") && Nt(N, t.autoscroll);
  }), e.user_effect(() => {
    s() === null && s(e.get(B)), s() != null && e.get(B) !== s() && (e.set(a, (performance.now() - e.get(W)) / 1e3 + s()), e.set(y, e.get(a).toFixed(1), !0), e.set(B, s(), !0));
  });
  function V() {
    e.set(q, !1);
  }
  e.user_effect(() => {
    untrack(() => {
      V();
    }), t.status === "error" && g() && e.set(q, !0);
  });
  var k = t0();
  let O, I;
  var b = e.child(k);
  {
    var _ = (h) => {
      var x = Ut(), A = e.child(x), E = e.sibling(A), U = e.child(E);
      {
        let J = e.derived(() => t.i18n ? t.i18n("common.clear") : "Clear");
        IconButton(U, {
          Icon: Clear,
          get label() {
            return e.get(J);
          },
          disabled: !1,
          size: "x-small",
          background: "var(--background-fill-primary)",
          color: "var(--error-background-text)",
          border: "var(--border-color-primary)",
          onclick: () => w(null)
        });
      }
      e.reset(E), e.reset(x), e.template_effect(() => e.set_text(A, `${w() ?? ""} `)), e.append(h, x);
    };
    e.if(b, (h) => {
      w() && L() && h(_);
    });
  }
  var H = e.sibling(b, 2);
  {
    var o = (h) => {
      var x = $t(), A = e.first_child(x);
      {
        var E = (R) => {
          var P = Wt();
          let $;
          e.template_effect(() => $ = e.set_style(P, "", $, {
            transform: `translateX(${(e.get(S) || 0) * 100 - 100}%)`
          })), e.append(R, P);
        };
        e.if(A, (R) => {
          Z() === "default" && e.get(se) && l() === "full" && R(E);
        });
      }
      var U = e.sibling(A, 2);
      let J;
      var T = e.child(U);
      {
        var re = (R) => {
          var P = e.comment(), $ = e.first_child(P);
          e.each($, 17, v, e.index, (ce, ee) => {
            var ae = e.comment(), de = e.first_child(ae);
            {
              var K = (D) => {
                var oe = Kt(), ve = e.first_child(oe);
                {
                  var Le = (fe) => {
                    var pe = e.text();
                    e.template_effect((me, we) => e.set_text(pe, `${me ?? ""}/${we ?? ""}`), [
                      () => pretty_si(e.get(ee).index || 0),
                      () => pretty_si(e.get(ee).length)
                    ]), e.append(fe, pe);
                  }, ue = (fe) => {
                    var pe = e.text();
                    e.template_effect((me) => e.set_text(pe, me), [() => pretty_si(e.get(ee).index || 0)]), e.append(fe, pe);
                  };
                  e.if(ve, (fe) => {
                    e.get(ee).length != null ? fe(Le) : fe(ue, !1);
                  });
                }
                var _e = e.sibling(ve);
                e.template_effect(() => e.set_text(_e, ` ${e.get(ee).unit ?? ""} |  `)), e.append(D, oe);
              };
              e.if(de, (D) => {
                e.get(ee).index != null && D(K);
              });
            }
            e.append(ce, ae);
          }), e.append(R, P);
        }, ie = (R) => {
          var P = e.comment(), $ = e.first_child(P);
          {
            var ce = (ae) => {
              var de = e.text();
              e.template_effect(() => e.set_text(de, `queue: ${t.queue_position + 1}/${t.queue_size ?? ""} |`)), e.append(ae, de);
            }, ee = (ae) => {
              var de = e.comment(), K = e.first_child(de);
              {
                var D = (oe) => {
                  var ve = e.text("processing |");
                  e.append(oe, ve);
                };
                e.if(
                  K,
                  (oe) => {
                    t.queue_position === 0 && oe(D);
                  },
                  !0
                );
              }
              e.append(ae, de);
            };
            e.if(
              $,
              (ae) => {
                t.queue_position !== null && t.queue_size !== void 0 && t.queue_position >= 0 ? ae(ce) : ae(ee, !1);
              },
              !0
            );
          }
          e.append(R, P);
        };
        e.if(T, (R) => {
          v() ? R(re) : R(ie, !1);
        });
      }
      var G = e.sibling(T, 2);
      {
        var le = (R) => {
          var P = e.text();
          e.template_effect(() => e.set_text(P, `${e.get(f) ?? ""}${s() ? `/${e.get(y)}` : ""}s`)), e.append(R, P);
        };
        e.if(G, (R) => {
          i() && R(le);
        });
      }
      e.reset(U);
      var Q = e.sibling(U, 2);
      {
        var xe = (R) => {
          var P = Jt(), $ = e.child(P), ce = e.child($);
          {
            var ee = (D) => {
              var oe = e.comment(), ve = e.first_child(oe);
              e.each(ve, 17, v, e.index, (Le, ue, _e) => {
                var fe = e.comment(), pe = e.first_child(fe);
                {
                  var me = (we) => {
                    var ze = Xt(), Ve = e.first_child(ze);
                    {
                      var De = (ne) => {
                        var ge = e.text(" /");
                        e.append(ne, ge);
                      };
                      e.if(Ve, (ne) => {
                        _e !== 0 && ne(De);
                      });
                    }
                    var He = e.sibling(Ve, 2);
                    {
                      var Ne = (ne) => {
                        var ge = e.text();
                        e.template_effect(() => e.set_text(ge, e.get(ue).desc)), e.append(ne, ge);
                      };
                      e.if(He, (ne) => {
                        e.get(ue).desc != null && ne(Ne);
                      });
                    }
                    var Ze = e.sibling(He, 2);
                    {
                      var Ue = (ne) => {
                        var ge = e.text("-");
                        e.append(ne, ge);
                      };
                      e.if(Ze, (ne) => {
                        e.get(ue).desc != null && e.get(z).progress_level && e.get(z).progress_level[_e] != null && ne(Ue);
                      });
                    }
                    var We = e.sibling(Ze, 2);
                    {
                      var Ke = (ne) => {
                        var ge = e.text();
                        e.template_effect((Xe) => e.set_text(ge, `${Xe ?? ""}%`), [
                          () => (100 * (e.get(z).progress_level[_e] || 0)).toFixed(1)
                        ]), e.append(ne, ge);
                      };
                      e.if(We, (ne) => {
                        e.get(z).progress_level != null && ne(Ke);
                      });
                    }
                    e.append(we, ze);
                  };
                  e.if(pe, (we) => {
                    (e.get(ue).desc != null || e.get(z).progress_level && e.get(z).progress_level[_e] != null) && we(me);
                  });
                }
                e.append(Le, fe);
              }), e.append(D, oe);
            };
            e.if(ce, (D) => {
              v() != null && D(ee);
            });
          }
          e.reset($);
          var ae = e.sibling($, 2), de = e.child(ae);
          let K;
          e.reset(ae), e.reset(P), e.template_effect(() => K = e.set_style(de, "", K, {
            width: `${e.get(z).last_progress_level * 100}%`,
            transition: e.get(z).progress_bar_transition
          })), e.append(R, P);
        }, ke = (R) => {
          var P = e.comment(), $ = e.first_child(P);
          {
            var ce = (ee) => {
              {
                let ae = e.derived(() => Z() === "default");
                Loader(ee, {
                  get margin() {
                    return e.get(ae);
                  }
                });
              }
            };
            e.if(
              $,
              (ee) => {
                l() === "full" && ee(ce);
              },
              !0
            );
          }
          e.append(R, P);
        };
        e.if(Q, (R) => {
          e.get(z).last_progress_level != null ? R(xe) : R(ke, !1);
        });
      }
      var he = e.sibling(Q, 2);
      {
        var be = (R) => {
          var P = Qt(), $ = e.first_child(P), ce = e.child($, !0);
          e.reset($);
          var ee = e.sibling($, 2);
          e.slot(ee, t, "additional-loading-text", {}, null), e.template_effect(() => e.set_text(ce, d())), e.append(R, P);
        };
        e.if(he, (R) => {
          i() || R(be);
        });
      }
      e.template_effect(() => J = e.set_class(U, 1, "progress-text svelte-2b1o8r", null, J, {
        "meta-text-center": Z() === "center",
        "meta-text": Z() === "default"
      })), e.append(h, x);
    }, j = (h) => {
      var x = e.comment(), A = e.first_child(x);
      {
        var E = (U) => {
          var J = e0(), T = e.first_child(J), re = e.child(T);
          {
            let Q = e.derived(() => t.i18n("common.clear"));
            IconButton(re, {
              Icon: Clear,
              get label() {
                return e.get(Q);
              },
              disabled: !1,
              $$events: {
                click: () => {
                  t.on_clear_status?.();
                }
              }
            });
          }
          e.reset(T);
          var ie = e.sibling(T, 2), G = e.child(ie, !0);
          e.reset(ie);
          var le = e.sibling(ie, 2);
          e.slot(le, t, "error", {}, null), e.template_effect((Q) => e.set_text(G, Q), [() => t.i18n("common.error")]), e.append(U, J);
        };
        e.if(
          A,
          (U) => {
            t.status === "error" && U(E);
          },
          !0
        );
      }
      e.append(h, x);
    };
    e.if(H, (h) => {
      t.status === "pending" ? h(o) : h(j, !1);
    });
  }
  e.reset(k), e.bind_this(k, (h) => N = h, () => N), e.template_effect(() => {
    O = e.set_class(k, 1, `wrap ${Z() ?? ""} ${l() ?? ""}`, "svelte-2b1o8r", O, {
      "no-click": w() && L(),
      hide: e.get(u),
      translucent: Z() === "center" && (t.status === "pending" || t.status === "error") || c() || l() === "minimal" || w(),
      generating: t.status === "generating" && l() === "full",
      border: M()
    }), I = e.set_style(k, "", I, {
      position: p() ? "absolute" : "static",
      padding: p() ? "0" : "var(--size-8) 0"
    });
  }), e.append(m, k), e.pop();
}
e.from_html('<div class="toast-item svelte-19jkoz4"><!></div>');
e.from_html('<div class="toast-wrap svelte-19jkoz4"></div>');
e.from_html('<div><svg viewBox="-1200 -1200 3000 3000" fill="none" xmlns="http://www.w3.org/2000/svg" class="svelte-1aqycx2"><g><path d="M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-1aqycx2"></path><path d="M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z" fill="#FF7C00" class="svelte-1aqycx2"></path><path d="M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-1aqycx2"></path><path d="M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z" fill="#FF7C00" class="svelte-1aqycx2"></path></g><g><path d="M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-1aqycx2"></path><path d="M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z" fill="#FF7C00" class="svelte-1aqycx2"></path><path d="M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z" fill="#FF7C00" fill-opacity="0.4" class="svelte-1aqycx2"></path><path d="M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z" fill="#FF7C00" class="svelte-1aqycx2"></path></g></svg></div>');
e.from_html('<div class="streaming-bar svelte-11ogyxo"></div>');
var r0 = e.from_html("<!> <!> <!>", 1), l0 = e.from_html("<!> <!> <!> <!>", 1);
function n0(m, t) {
  e.push(t, !0);
  const s = e.rest_props(t, ["$$slots", "$$events", "$$legacy"]), r = new ot(s);
  let i = e.state(e.proxy(r.props.value));
  e.user_effect(() => {
    e.get(i) != r.props.value && (e.set(i, r.props.value, !0), r.dispatch("change"));
  });
  let l = e.derived(() => r.props.combine_adjacent ? Ge(r.props.value || []) : r.props.value);
  var g = e.comment(), v = e.first_child(g);
  {
    var Z = (p) => {
      Ee(p, {
        variant: "solid",
        test_id: "highlighted-text",
        get visible() {
          return r.shared.visible;
        },
        get elem_id() {
          return r.shared.elem_id;
        },
        get elem_classes() {
          return r.shared.elem_classes;
        },
        padding: !1,
        get container() {
          return r.shared.container;
        },
        get scale() {
          return r.shared.scale;
        },
        get min_width() {
          return r.shared.min_width;
        },
        get rtl() {
          return r.props.rtl;
        },
        children: (c, M) => {
          var w = r0(), L = e.first_child(w);
          Ie(L, e.spread_props(
            {
              get autoscroll() {
                return r.shared.autoscroll;
              },
              get i18n() {
                return r.i18n;
              }
            },
            () => r.shared.loading_status,
            {
              on_clear_status: () => r.dispatch("clear_status", r.shared.loading_status)
            }
          ));
          var Y = e.sibling(L, 2);
          {
            var N = (a) => {
              {
                let q = e.derived(() => r.shared.label || r.i18n("highlighted_text.highlighted_text")), y = e.derived(() => r.shared.container === !1);
                Re(a, {
                  get Icon() {
                    return ye;
                  },
                  get label() {
                    return e.get(q);
                  },
                  float: !1,
                  get disable() {
                    return e.get(y);
                  },
                  get show_label() {
                    return r.shared.show_label;
                  },
                  get rtl() {
                    return r.props.rtl;
                  }
                });
              }
            };
            e.if(Y, (a) => {
              r.shared.label && r.shared.show_label && a(N);
            });
          }
          var X = e.sibling(Y, 2);
          {
            var W = (a) => {
              _t(a, {
                selectable: !1,
                get value() {
                  return e.get(l);
                },
                get show_legend() {
                  return r.props.show_legend;
                },
                get show_inline_category() {
                  return r.props.show_inline_category;
                },
                get color_map() {
                  return r.props.color_map;
                },
                $$events: { select: ({ detail: q }) => r.dispatch("select", q) }
              });
            }, B = (a) => {
              Oe(a, {
                children: (q, y) => {
                  ye(q);
                },
                $$slots: { default: !0 }
              });
            };
            e.if(X, (a) => {
              e.get(l) ? a(W) : a(B, !1);
            });
          }
          e.append(c, w);
        },
        $$slots: { default: !0 }
      });
    }, d = (p) => {
      {
        let c = e.derived(() => r.shared.interactive ? "dashed" : "solid");
        Ee(p, {
          get variant() {
            return e.get(c);
          },
          test_id: "highlighted-text",
          get visible() {
            return r.shared.visible;
          },
          get elem_id() {
            return r.shared.elem_id;
          },
          get elem_classes() {
            return r.shared.elem_classes;
          },
          padding: !1,
          get container() {
            return r.shared.container;
          },
          get scale() {
            return r.shared.scale;
          },
          get min_width() {
            return r.shared.min_width;
          },
          children: (M, w) => {
            var L = l0(), Y = e.first_child(L);
            Ie(Y, e.spread_props(
              {
                get autoscroll() {
                  return r.shared.autoscroll;
                }
              },
              () => r.shared.loading_status,
              {
                get i18n() {
                  return r.i18n;
                },
                on_clear_status: () => r.dispatch("clear_status", r.shared.loading_status)
              }
            ));
            var N = e.sibling(Y, 2);
            {
              var X = (u) => {
                Yt(u, {
                  get buttons() {
                    return r.props.buttons;
                  },
                  on_custom_button_click: (F) => {
                    r.dispatch("custom_button_click", { id: F });
                  }
                });
              };
              e.if(N, (u) => {
                r.shared.label && r.shared.show_label && r.props.buttons && r.props.buttons.length > 0 && u(X);
              });
            }
            var W = e.sibling(N, 2);
            {
              var B = (u) => {
                {
                  let F = e.derived(() => r.shared.container === !1);
                  Re(u, {
                    get Icon() {
                      return ye;
                    },
                    get label() {
                      return r.shared.label;
                    },
                    float: !1,
                    get disable() {
                      return e.get(F);
                    },
                    get show_label() {
                      return r.shared.show_label;
                    },
                    get rtl() {
                      return r.props.rtl;
                    }
                  });
                }
              };
              e.if(W, (u) => {
                r.shared.label && r.shared.show_label && u(B);
              });
            }
            var a = e.sibling(W, 2);
            {
              var q = (u) => {
                jt(u, {
                  selectable: !1,
                  get show_legend() {
                    return r.props.show_legend;
                  },
                  get color_map() {
                    return r.props.color_map;
                  },
                  get value() {
                    return e.get(l);
                  },
                  set value(F) {
                    e.set(l, F);
                  },
                  $$events: {
                    change: () => {
                      r.props.value = e.get(l), r.dispatch("change");
                    }
                  }
                });
              }, y = (u) => {
                Oe(u, {
                  size: "small",
                  unpadded_box: !0,
                  children: (F, S) => {
                    ye(F);
                  },
                  $$slots: { default: !0 }
                });
              };
              e.if(a, (u) => {
                e.get(l) ? u(q) : u(y, !1);
              });
            }
            e.append(M, L);
          },
          $$slots: { default: !0 }
        });
      }
    };
    e.if(v, (p) => {
      r.shared.interactive ? p(d, !1) : p(Z);
    });
  }
  e.append(m, g), e.pop();
}
export {
  jt as BaseInteractiveHighlightedText,
  _t as BaseStaticHighlightedText,
  n0 as default
};
