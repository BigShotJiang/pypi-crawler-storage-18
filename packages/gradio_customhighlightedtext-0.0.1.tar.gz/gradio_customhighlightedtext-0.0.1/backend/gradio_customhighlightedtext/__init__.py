
from .customhighlightedtext import CustomHighlightedText

__all__ = ['CustomHighlightedText']
