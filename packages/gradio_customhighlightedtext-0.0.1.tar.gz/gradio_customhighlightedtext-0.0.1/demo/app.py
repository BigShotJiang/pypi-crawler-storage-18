
import gradio as gr
from gradio_customhighlightedtext import CustomHighlightedText


example = CustomHighlightedText().example_value()

with gr.Blocks() as demo:
    with gr.Row():
        CustomHighlightedText(label="Blank"),  # blank component
        CustomHighlightedText(value=example, label="Populated"),  # populated component


if __name__ == "__main__":
    demo.launch()
