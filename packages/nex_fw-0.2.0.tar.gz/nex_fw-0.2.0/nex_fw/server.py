"""
NexFramework Console Server - 控制台管理服务器
"""
import subprocess
import sys
import os
import getpass
from .framework import NexFramework


class NexServer:
    def __init__(self, work_dir: str = "."):
        self.work_dir = os.path.abspath(work_dir)
        self.nex = NexFramework(self.work_dir)
        # 使用系统用户名作为默认用户
        self.current_user = getpass.getuser()
        self.api_process = None
        self.api_running = False

    def start_api(self, host="0.0.0.0", port=8000):
        if self.api_running:
            print("[Server] WebServer 已在运行中")
            return
        try:
            self.api_process = subprocess.Popen(
                [sys.executable, "-m", "uvicorn", "nex_fw.webserver:app", "--host", host, "--port", str(port)],
                cwd=self.work_dir,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
            self.api_running = True
            print(f"[Server] WebServer 已启动 http://{host}:{port}")
        except Exception as e:
            print(f"[Server] 启动失败: {e}")

    def stop_api(self):
        if not self.api_running or not self.api_process:
            print("[Server] WebServer 未运行")
            return
        try:
            self.api_process.terminate()
            self.api_process.wait(timeout=5)
            self.api_running = False
            print("[Server] WebServer 已停止")
        except Exception as e:
            print(f"[Server] 停止失败: {e}")

    def show_status(self):
        print("\n" + "=" * 50)
        print("  NexFramework 状态")
        print("=" * 50)
        print(f"  工作目录: {self.work_dir}")
        print(f"  WebServer: {'🟢 运行中' if self.api_running else '🔴 已停止'}")
        model = self.nex.get_current_model()
        print(f"  当前模型: {model['name']} ({model['model']})")
        print(f"  当前用户: {self.current_user}")
        session = self.nex.get_current_session()
        if session:
            print(f"  当前会话: #{session['id']} {session['name']} ({session['message_count']}条消息)")
        else:
            print(f"  当前会话: 无")
        print(f"  会话总数: {len(self.nex.get_sessions())}")
        print("=" * 50 + "\n")

    def show_models(self):
        current = self.nex.get_current_model()
        print("\n[Models] 可用模型:")
        for m in self.nex.get_models():
            marker = " *" if m['key'] == current['key'] else ""
            print(f"  {m['key']}: {m['name']} ({m['model']}){marker}")
        print()

    def show_sessions(self, limit: int = 10):
        """显示会话列表"""
        sessions = self.nex.get_sessions(limit=limit)
        current = self.nex.get_current_session()
        current_id = current['id'] if current else None
        
        if not sessions:
            print("[Sessions] 暂无会话")
            return
        
        print(f"\n[Sessions] 会话列表 (共 {len(sessions)} 个):")
        for s in sessions:
            marker = " *" if s['id'] == current_id else ""
            print(f"  #{s['id']}: {s['name']} [{s['user']}] ({s['message_count']}条){marker}")
        print()

    def on_tool_call(self, event, data):
        if event == "tool_start":
            print(f"\n[Tool] 调用 {data['name']}")
            if data['name'] == 'execute_shell':
                print(f"       命令: {data['args'].get('command', '')}")
            elif data['name'] == 'http_request':
                print(f"       URL: {data['args'].get('url', '')}")
        elif event == "tool_end":
            result = data['result'][:150] + "..." if len(data['result']) > 150 else data['result']
            print(f"       结果: {result}\n")

    def chat(self, message):
        print("[Nex] ", end="", flush=True)
        for chunk in self.nex.chat_stream(self.current_user, message, on_tool_call=self.on_tool_call):
            print(chunk, end="", flush=True)
        print()

    def show_help(self):
        print("""
╔══════════════════════════════════════════════════════╗
║            NexFramework Console 命令                 ║
╠══════════════════════════════════════════════════════╣
║  /start [port]     启动 WebServer (默认 8000)        ║
║  /stop             停止 WebServer                    ║
║  /status           查看服务状态                      ║
║  /models           查看可用模型                      ║
║  /use <key>        切换模型                          ║
║  /user <name>      切换用户                          ║
║  /whoami           显示当前用户                      ║
╠══════════════════════════════════════════════════════╣
║  /sessions         查看会话列表                      ║
║  /new [name]       创建新会话                        ║
║  /switch <id>      切换到指定会话                    ║
║  /rename <name>    重命名当前会话                    ║
║  /delete [id]      删除会话                          ║
║  /messages [n]     查看当前会话消息                  ║
║  /clear            清空当前会话消息                  ║
╠══════════════════════════════════════════════════════╣
║  /help             显示此帮助                        ║
║  /quit             退出程序                          ║
║  直接输入文字即可与 AI 对话                          ║
╚══════════════════════════════════════════════════════╝
""")


def main(work_dir: str = "."):
    work_dir = os.path.abspath(work_dir)
    server = NexServer(work_dir)
    print("\n" + "=" * 50)
    print("     🚀 NexFramework Console")
    print("=" * 50)
    print(f"  📁 工作目录: {work_dir}")
    print("  输入 /help 查看命令, /start 启动WebServer")
    print("=" * 50 + "\n")

    while True:
        try:
            # 显示当前会话信息
            session = server.nex.get_current_session()
            session_info = f"#{session['id']}" if session else "无会话"
            user_input = input(f"[{server.current_user}|{session_info}] > ").strip()
            if not user_input:
                continue

            parts = user_input.split(maxsplit=1)
            cmd, arg = parts[0].lower(), parts[1] if len(parts) > 1 else None

            if cmd == "/start":
                server.start_api(port=int(arg) if arg else 8000)
            elif cmd == "/stop":
                server.stop_api()
            elif cmd == "/status":
                server.show_status()
            elif cmd == "/models":
                server.show_models()
            elif cmd == "/use" and arg:
                if server.nex.switch_model(arg):
                    print(f"[Server] 已切换到: {server.nex.get_current_model()['name']}")
                else:
                    print(f"[Server] 模型 '{arg}' 不存在")
            elif cmd == "/user" and arg:
                server.current_user = arg
                print(f"[Server] 已切换用户: {arg}")
            elif cmd == "/whoami":
                print(f"[Server] 当前用户: {server.current_user}")
            # 会话管理命令
            elif cmd == "/sessions":
                server.show_sessions(int(arg) if arg else 10)
            elif cmd == "/new":
                name = arg or "新会话"
                session_id = server.nex.create_session(name, server.current_user)
                print(f"[Server] 已创建会话 #{session_id}: {name}")
            elif cmd == "/switch" and arg:
                try:
                    sid = int(arg)
                    if server.nex.switch_session(sid):
                        s = server.nex.get_session(sid)
                        print(f"[Server] 已切换到会话 #{sid}: {s['name']}")
                    else:
                        print(f"[Server] 会话 #{sid} 不存在")
                except ValueError:
                    print("[Server] 请输入有效的会话ID")
            elif cmd == "/rename" and arg:
                session = server.nex.get_current_session()
                if session:
                    server.nex.update_session(session['id'], arg)
                    print(f"[Server] 会话已重命名为: {arg}")
                else:
                    print("[Server] 当前没有活动会话")
            elif cmd == "/delete":
                if arg:
                    try:
                        sid = int(arg)
                        if server.nex.delete_session(sid):
                            print(f"[Server] 已删除会话 #{sid}")
                        else:
                            print(f"[Server] 会话 #{sid} 不存在")
                    except ValueError:
                        print("[Server] 请输入有效的会话ID")
                else:
                    session = server.nex.get_current_session()
                    if session:
                        server.nex.delete_session(session['id'])
                        print(f"[Server] 已删除当前会话")
                    else:
                        print("[Server] 当前没有活动会话")
            elif cmd == "/messages":
                session = server.nex.get_current_session()
                if not session:
                    print("[Server] 当前没有活动会话")
                else:
                    limit = int(arg) if arg else 10
                    messages = server.nex.get_session_messages(session['id'], limit)
                    if not messages:
                        print("[Server] 暂无消息")
                    else:
                        print(f"\n[Messages] 会话 #{session['id']} 最近 {len(messages)} 条:")
                        for m in messages:
                            content = m['content'][:50] + "..." if len(m['content']) > 50 else m['content']
                            role_icon = "👤" if m['role'] == 'user' else "🤖"
                            print(f"  {role_icon} #{m['id']} {content}")
                        print()
            elif cmd == "/clear":
                session = server.nex.get_current_session()
                if session:
                    count = server.nex.clear_session_messages(session['id'])
                    print(f"[Server] 已清空 {count} 条消息")
                else:
                    print("[Server] 当前没有活动会话")
            elif cmd == "/help":
                server.show_help()
            elif cmd == "/quit":
                server.stop_api()
                print("[Server] 再见! 👋")
                break
            elif cmd.startswith("/"):
                print("[Server] 未知命令，输入 /help 查看帮助")
            else:
                server.chat(user_input)
        except KeyboardInterrupt:
            print("\n[Server] 正在退出...")
            server.stop_api()
            print("[Server] 再见! 👋")
            break
        except Exception as e:
            print(f"[Server] 错误: {e}")


if __name__ == "__main__":
    main()
