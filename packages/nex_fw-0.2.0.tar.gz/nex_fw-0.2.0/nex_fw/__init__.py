"""
NexFramework - AI 对话框架
支持多模型切换、工具调用、流式输出、多会话管理
"""
from .framework import NexFramework
from .database import Database
from .webserver import app as webserver_app

__version__ = "0.2.0"
__author__ = "3w4e"
__all__ = ['NexFramework', 'Database', 'webserver_app']
