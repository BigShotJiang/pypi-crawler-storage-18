"""
NexFramework 数据库模块 - SQLite存储
"""
import sqlite3
import os
from datetime import datetime
from typing import Optional, List, Dict
from contextlib import contextmanager


class Database:
    """SQLite数据库管理"""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()
    
    @contextmanager
    def get_conn(self):
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()
    
    def _init_db(self):
        """初始化数据库表"""
        with self.get_conn() as conn:
            conn.executescript('''
                CREATE TABLE IF NOT EXISTS sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    user TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    is_active INTEGER DEFAULT 1
                );
                
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT,
                    user TEXT,
                    extra TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
                );
                
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                );
                
                CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id);
                CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user);
            ''')
            # 检查并添加 extra 列（兼容旧数据库）
            try:
                conn.execute('SELECT extra FROM messages LIMIT 1')
            except sqlite3.OperationalError:
                conn.execute('ALTER TABLE messages ADD COLUMN extra TEXT')
    
    # ========== 会话管理 ==========
    def create_session(self, name: str, user: str) -> int:
        """创建新会话"""
        now = datetime.now().isoformat()
        with self.get_conn() as conn:
            cursor = conn.execute(
                'INSERT INTO sessions (name, user, created_at, updated_at) VALUES (?, ?, ?, ?)',
                (name, user, now, now)
            )
            return cursor.lastrowid
    
    def get_sessions(self, user: str = None, limit: int = None) -> List[Dict]:
        """获取会话列表"""
        with self.get_conn() as conn:
            sql = 'SELECT * FROM sessions WHERE is_active = 1'
            params = []
            if user:
                sql += ' AND user = ?'
                params.append(user)
            sql += ' ORDER BY updated_at DESC'
            if limit:
                sql += ' LIMIT ?'
                params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            return [dict(row) for row in rows]
    
    def get_session(self, session_id: int) -> Optional[Dict]:
        """获取单个会话"""
        with self.get_conn() as conn:
            row = conn.execute(
                'SELECT * FROM sessions WHERE id = ? AND is_active = 1', (session_id,)
            ).fetchone()
            return dict(row) if row else None

    def update_session(self, session_id: int, name: str = None) -> bool:
        """更新会话"""
        with self.get_conn() as conn:
            updates = ['updated_at = ?']
            params = [datetime.now().isoformat()]
            if name:
                updates.append('name = ?')
                params.append(name)
            params.append(session_id)
            result = conn.execute(
                f'UPDATE sessions SET {", ".join(updates)} WHERE id = ? AND is_active = 1',
                params
            )
            return result.rowcount > 0
    
    def delete_session(self, session_id: int) -> bool:
        """删除会话（软删除）"""
        with self.get_conn() as conn:
            result = conn.execute(
                'UPDATE sessions SET is_active = 0 WHERE id = ?', (session_id,)
            )
            return result.rowcount > 0
    
    def delete_all_sessions(self, user: str = None) -> int:
        """删除所有会话"""
        with self.get_conn() as conn:
            if user:
                result = conn.execute(
                    'UPDATE sessions SET is_active = 0 WHERE user = ?', (user,)
                )
            else:
                result = conn.execute('UPDATE sessions SET is_active = 0')
            return result.rowcount
    
    # ========== 消息管理 ==========
    def add_message(self, session_id: int, role: str, content: str, user: str = None, extra: dict = None) -> int:
        """添加消息
        
        Args:
            session_id: 会话ID
            role: 角色 (user/assistant/tool)
            content: 消息内容
            user: 用户名（仅user角色）
            extra: 额外数据（如工具调用信息）
        """
        import json
        now = datetime.now().isoformat()
        extra_json = json.dumps(extra, ensure_ascii=False) if extra else None
        with self.get_conn() as conn:
            cursor = conn.execute(
                'INSERT INTO messages (session_id, role, content, user, extra, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                (session_id, role, content, user, extra_json, now)
            )
            # 更新会话时间
            conn.execute(
                'UPDATE sessions SET updated_at = ? WHERE id = ?', (now, session_id)
            )
            return cursor.lastrowid
    
    def get_messages(self, session_id: int, limit: int = None) -> List[Dict]:
        """获取会话消息"""
        import json
        with self.get_conn() as conn:
            sql = 'SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC'
            params = [session_id]
            if limit:
                sql = f'SELECT * FROM (SELECT * FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id ASC'
                params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            result = []
            for row in rows:
                msg = dict(row)
                # 解析 extra JSON
                if msg.get('extra'):
                    try:
                        msg['extra'] = json.loads(msg['extra'])
                    except:
                        pass
                result.append(msg)
            return result
    
    def delete_message(self, message_id: int) -> bool:
        """删除单条消息"""
        with self.get_conn() as conn:
            result = conn.execute('DELETE FROM messages WHERE id = ?', (message_id,))
            return result.rowcount > 0
    
    def delete_session_messages(self, session_id: int) -> int:
        """清空会话消息"""
        with self.get_conn() as conn:
            result = conn.execute('DELETE FROM messages WHERE session_id = ?', (session_id,))
            return result.rowcount
    
    def get_message_count(self, session_id: int) -> int:
        """获取会话消息数量"""
        with self.get_conn() as conn:
            row = conn.execute(
                'SELECT COUNT(*) as count FROM messages WHERE session_id = ?', (session_id,)
            ).fetchone()
            return row['count']
    
    # ========== 设置管理 ==========
    def get_setting(self, key: str, default: str = None) -> Optional[str]:
        """获取设置"""
        with self.get_conn() as conn:
            row = conn.execute('SELECT value FROM settings WHERE key = ?', (key,)).fetchone()
            return row['value'] if row else default
    
    def set_setting(self, key: str, value: str) -> None:
        """保存设置"""
        with self.get_conn() as conn:
            conn.execute(
                'INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value)
            )
    
    # ========== 兼容旧API ==========
    def get_history(self, limit: int = None) -> List[Dict]:
        """获取历史记录（兼容旧API）"""
        with self.get_conn() as conn:
            sql = '''
                SELECT m.id, m.content as message, m.user, m.created_at as time,
                       (SELECT content FROM messages WHERE session_id = m.session_id AND id = m.id + 1 AND role = 'assistant') as response
                FROM messages m
                WHERE m.role = 'user'
                ORDER BY m.id DESC
            '''
            if limit:
                sql += f' LIMIT {limit}'
            rows = conn.execute(sql).fetchall()
            result = []
            for row in rows:
                if row['response']:
                    result.append({
                        'id': row['id'],
                        'user': row['user'],
                        'message': row['message'],
                        'response': row['response'],
                        'time': row['time']
                    })
            return list(reversed(result))
