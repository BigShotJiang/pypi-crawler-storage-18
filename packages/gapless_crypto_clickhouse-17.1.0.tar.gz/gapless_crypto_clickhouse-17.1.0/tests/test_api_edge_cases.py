"""Test edge cases and error handling in api.py for improved coverage.

Targets uncovered lines in parameter validation, error handling, and
deprecated parameter paths to reach 85%+ coverage.

NOTE (ADR-0049): index_type deprecation tests removed per v3.0.0 deprecation plan (ADR-0023).
Tests for valid index_type values (datetime, range, auto) were deleted since the parameter
is deprecated. Only test_index_type_validation_none and test_index_type_validation_invalid
remain to test boundary conditions.
"""

import tempfile
from pathlib import Path

import pandas as pd
import pytest

import gapless_crypto_clickhouse as gcch
from gapless_crypto_clickhouse.api import (
    _validate_index_type_parameter,
    _validate_timeframe_parameters,
)


class TestParameterValidation:
    """Test parameter validation edge cases."""

    def test_timeframe_validation_both_none(self):
        """Test error when neither timeframe nor interval specified."""
        with pytest.raises(
            ValueError,
            match="Must specify 'timeframe' parameter",
        ):
            _validate_timeframe_parameters(None, None)

    def test_timeframe_validation_both_specified(self):
        """Test error when both timeframe and interval specified."""
        with pytest.raises(
            ValueError,
            match="Cannot specify both 'timeframe' and 'interval'",
        ):
            _validate_timeframe_parameters("1h", "1h")

    def test_timeframe_validation_timeframe_only(self):
        """Test valid timeframe parameter."""
        result = _validate_timeframe_parameters("1h", None)
        assert result == "1h"

    def test_timeframe_validation_interval_only(self):
        """Test valid interval parameter (legacy)."""
        result = _validate_timeframe_parameters(None, "4h")
        assert result == "4h"

    def test_index_type_validation_none(self):
        """Test index_type validation with None (no warning)."""
        # Should not raise
        _validate_index_type_parameter(None)

    # NOTE: test_index_type_validation_valid_datetime, _valid_range, _valid_auto DELETED per ADR-0049
    # index_type parameter deprecated per ADR-0023, removed in v3.0.0

    def test_index_type_validation_invalid(self):
        """Test index_type validation with invalid value."""
        with pytest.warns(DeprecationWarning):
            with pytest.raises(ValueError, match="Invalid index_type"):
                _validate_index_type_parameter("invalid")


class TestDownloadFunction:
    """Test download() function edge cases."""

    def test_download_default_timeframe(self):
        """Test download with no timeframe defaults to 1h."""
        # Create a mock to avoid network calls
        with tempfile.TemporaryDirectory() as tmpdir:
            # This will fail network call but we can test parameter handling
            try:
                df = gcch.download(
                    "BTCUSDT",
                    start="2024-01-01",
                    end="2024-01-02",
                    output_dir=tmpdir,
                )
                # If it succeeds (unlikely without network), check it's a DataFrame
                assert isinstance(df, pd.DataFrame)
            except Exception:
                # Expected to fail without network, but parameter validation passed
                pass


class TestSaveParquet:
    """Test save_parquet edge cases."""

    def test_save_parquet_empty_dataframe(self):
        """Test save_parquet with empty DataFrame raises ValueError."""
        df = pd.DataFrame()
        with pytest.raises(ValueError, match="Cannot save empty DataFrame"):
            gcch.save_parquet(df, "test.parquet")

    def test_save_parquet_none_dataframe(self):
        """Test save_parquet with None raises ValueError."""
        with pytest.raises(ValueError, match="Cannot save empty DataFrame"):
            gcch.save_parquet(None, "test.parquet")

    def test_save_parquet_valid_dataframe(self):
        """Test save_parquet with valid DataFrame."""
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
            try:
                gcch.save_parquet(df, tmp.name)
                # Verify file was created
                assert Path(tmp.name).exists()
                # Verify we can load it back
                loaded = gcch.load_parquet(tmp.name)
                assert len(loaded) == 3
                assert list(loaded.columns) == ["a", "b"]
            finally:
                Path(tmp.name).unlink(missing_ok=True)


class TestFillGaps:
    """Test fill_gaps function edge cases."""

    def test_fill_gaps_empty_directory(self):
        """Test fill_gaps with directory containing no CSV files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            results = gcch.fill_gaps(tmpdir)
            assert results["files_processed"] == 0
            assert results["gaps_detected"] == 0
            assert results["gaps_filled"] == 0
            assert results["success_rate"] == 100.0

    def test_fill_gaps_with_symbol_filter(self):
        """Test fill_gaps with symbol filter."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a dummy CSV file
            csv_file = Path(tmpdir) / "BTCUSDT-1h_2024-01-01.csv"
            df = pd.DataFrame(
                {
                    "timestamp": ["2024-01-01 00:00:00", "2024-01-01 01:00:00"],
                    "open": [100.0, 101.0],
                    "high": [102.0, 103.0],
                    "low": [99.0, 100.0],
                    "close": [101.0, 102.0],
                    "volume": [1000.0, 1100.0],
                    "close_time": ["2024-01-01 00:59:59", "2024-01-01 01:59:59"],
                    "quote_asset_volume": [100000.0, 110000.0],
                    "number_of_trades": [100, 110],
                    "taker_buy_base_asset_volume": [500.0, 550.0],
                    "taker_buy_quote_asset_volume": [50000.0, 55000.0],
                }
            )
            df.to_csv(csv_file, index=False)

            # Test with symbol filter
            results = gcch.fill_gaps(tmpdir, symbols=["BTCUSDT"])
            assert results["files_processed"] == 1


class TestGetSupportedIntervals:
    """Test get_supported_intervals deprecated function."""

    def test_get_supported_intervals_deprecation(self):
        """Test that get_supported_intervals raises deprecation warning."""
        with pytest.warns(DeprecationWarning, match="get_supported_intervals.*deprecated"):
            intervals = gcch.get_supported_intervals()
            assert isinstance(intervals, list)
            assert len(intervals) > 0


class TestGetInfo:
    """Test get_info function."""

    def test_get_info_structure(self):
        """Test get_info returns expected structure."""
        info = gcch.get_info()
        # Version should be a semantic version string (don't hardcode to avoid breaking on release)
        assert isinstance(info["version"], str)
        assert len(info["version"].split(".")) >= 2, "Version should be semver format"
        assert info["name"] == "gapless-crypto-clickhouse"  # ADR-0029: package name alignment
        assert "description" in info
        assert "supported_symbols" in info
        assert "supported_timeframes" in info
        assert "market_type" in info
        assert "data_source" in info
        assert "features" in info
        assert isinstance(info["features"], list)
        assert len(info["features"]) > 0
