class PhotoObjectsError(Exception):
    pass
