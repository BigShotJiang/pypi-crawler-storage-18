NAME = "binance-sdk-spot"
