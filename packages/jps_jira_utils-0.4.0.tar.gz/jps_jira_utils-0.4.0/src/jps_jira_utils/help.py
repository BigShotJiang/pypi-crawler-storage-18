#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Unified help command for the jps-jira-utils package.

This script provides a friendly overview of all available CLI tools in the
jps-jira-utils suite — ideal for onboarding, documentation, and daily use.

Usage:
    jps-jira-utils-help
"""

import textwrap

# ANSI colour codes (works in most terminals)
GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
RESET = "\033[0m"


def main() -> None:
    """Print a beautifully formatted help overview of all jps-jira-utils commands."""
    help_text = textwrap.dedent(
        f"""
        {CYAN}jps-jira-utils — Modern Jira Power Tools for Engineers{YELLOW}
        {'=' * 62}{RESET}

        A clean, fast, and maintainable collection of CLI utilities for
        interacting with Jira Cloud — built with Typer, proper logging,
        full test coverage, and zero tolerance for technical debt.

        {GREEN}Available Commands{RESET}

        {GREEN}jps-jira-utils-add-comment{RESET}
            Add a rich comment to a Jira issue with optional file attachment.
            • Interactive multiline input (ends on two blank lines)
            • Load comment from file via --comment-file
            • Attach any file with smart pre-canned notes (STDOUT, STDERR, log, README)
            • Final confirmation table before posting
            • Secure credentials via ~/.jira.env (never in CLI)
            • Full structured logging to /tmp/<user>/add_comment.py/<timestamp>/

            {YELLOW}Example:{RESET}
                jps-jira-utils-add-comment JPS-1234
                jps-jira-utils-add-comment JPS-1234 --comment-file results.txt --attach-file run.log

        {GREEN}jps-jira-utils-help{RESET}
            Show this beautiful help overview (you are here)

        ------------------------------------------------------------
        {CYAN}More tools coming soon:{RESET}
            • jps-jira-create-workspace
            • jps-jira-create-branch
            • jps-jira-transition-issue
            • jps-jira-upload-screenshots

        {YELLOW}Tip:{RESET} Run any command with `--help` for detailed options and examples.

        {CYAN}Project:{RESET} https://github.com/jai-python3/jps-jira-utils
        {CYAN}Built with care by Jaideep Sundaram{RESET}
        """
    )

    print(help_text)


if __name__ == "__main__":
    main()
