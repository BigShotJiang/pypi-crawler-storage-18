"""Unit tests for prompt_helper.py."""

from jps_jira_utils.prompt_helper import read_multiline_input


def test_read_multiline_input_stops_on_two_blank_lines(monkeypatch) -> None:
    """Test that input stops after two consecutive blank lines.

    Args:
        monkeypatch: To mock user input.
    """
    inputs = ["First line", "Second line", "", "", "not captured"]  # blank  # second blank → stop

    monkeypatch.setattr("builtins.input", lambda: inputs.pop(0))

    result = read_multiline_input("Enter text:")
    assert result == "First line\nSecond line"


def test_read_multiline_input_preserves_trailing_newline_if_present(monkeypatch) -> None:
    """Test that trailing newline is preserved if part of input.

    Args:
        monkeypatch: To simulate input.
    """
    inputs = ["Hello", "World", "", ""]  # Add extra blank to avoid IndexError

    monkeypatch.setattr("builtins.input", lambda: inputs.pop(0))

    result = read_multiline_input(">> ")
    assert result == "Hello\nWorld"
