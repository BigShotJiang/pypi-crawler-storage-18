"""Unit tests for logging_helper.py."""

from pathlib import Path

from jps_jira_utils.logging_helper import setup_logging


def test_setup_logging_creates_file_and_configures_handlers(tmp_path: Path) -> None:
    """Test that logging is configured and writes to file correctly.

    Args:
        tmp_path: Temporary directory for log file.
    """
    log_file = tmp_path / "test.log"
    logger = setup_logging(log_file)

    logger.info("This is a test log message")
    logger.warning("This is a warning")

    content = log_file.read_text(encoding="utf-8")
    assert "This is a test log message" in content
    assert "This is a warning" in content
    assert "INFO" in content
    assert "WARNING" in content


def test_setup_logging_clears_previous_handlers(tmp_path: Path) -> None:
    """Test that setup_logging clears existing handlers to prevent duplicates.

    Args:
        tmp_path: Temporary path for log file.
    """
    log_file = tmp_path / "test.log"
    logger = setup_logging(log_file)
    initial_handlers = len(logger.handlers)

    # Call again — should clear and re-add
    logger2 = setup_logging(log_file)
    assert len(logger2.handlers) == initial_handlers
    assert logger2 is logger  # Same logger instance
