from adam.config import Config

def local_tmp_dir():
    return Config().get('local-tmp-dir', '/tmp/qing-db')