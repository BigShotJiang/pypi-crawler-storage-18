# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UploadLogRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'log_bucket': 'str'
    }

    attribute_map = {
        'log_bucket': 'log_bucket'
    }

    def __init__(self, log_bucket=None):
        r"""UploadLogRequestBody

        The model defined in huaweicloud sdk

        :param log_bucket: 指定桶名称
        :type log_bucket: str
        """
        
        

        self._log_bucket = None
        self.discriminator = None

        self.log_bucket = log_bucket

    @property
    def log_bucket(self):
        r"""Gets the log_bucket of this UploadLogRequestBody.

        指定桶名称

        :return: The log_bucket of this UploadLogRequestBody.
        :rtype: str
        """
        return self._log_bucket

    @log_bucket.setter
    def log_bucket(self, log_bucket):
        r"""Sets the log_bucket of this UploadLogRequestBody.

        指定桶名称

        :param log_bucket: The log_bucket of this UploadLogRequestBody.
        :type log_bucket: str
        """
        self._log_bucket = log_bucket

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UploadLogRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
