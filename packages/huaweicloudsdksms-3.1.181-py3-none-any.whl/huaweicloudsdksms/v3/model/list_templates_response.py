# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListTemplatesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'count': 'int',
        'templates': 'list[TemplateResponseBody]'
    }

    attribute_map = {
        'count': 'count',
        'templates': 'templates'
    }

    def __init__(self, count=None, templates=None):
        r"""ListTemplatesResponse

        The model defined in huaweicloud sdk

        :param count: 模板个数
        :type count: int
        :param templates: 模板信息
        :type templates: list[:class:`huaweicloudsdksms.v3.TemplateResponseBody`]
        """
        
        super().__init__()

        self._count = None
        self._templates = None
        self.discriminator = None

        if count is not None:
            self.count = count
        if templates is not None:
            self.templates = templates

    @property
    def count(self):
        r"""Gets the count of this ListTemplatesResponse.

        模板个数

        :return: The count of this ListTemplatesResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ListTemplatesResponse.

        模板个数

        :param count: The count of this ListTemplatesResponse.
        :type count: int
        """
        self._count = count

    @property
    def templates(self):
        r"""Gets the templates of this ListTemplatesResponse.

        模板信息

        :return: The templates of this ListTemplatesResponse.
        :rtype: list[:class:`huaweicloudsdksms.v3.TemplateResponseBody`]
        """
        return self._templates

    @templates.setter
    def templates(self, templates):
        r"""Sets the templates of this ListTemplatesResponse.

        模板信息

        :param templates: The templates of this ListTemplatesResponse.
        :type templates: list[:class:`huaweicloudsdksms.v3.TemplateResponseBody`]
        """
        self._templates = templates

    def to_dict(self):
        import warnings
        warnings.warn("ListTemplatesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListTemplatesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
