"""Installation verification for OpenDraft."""

import sys
import os
import subprocess
from pathlib import Path


def check_python_version():
    """Check if Python version is compatible."""
    version = sys.version_info
    required = (3, 9)

    print(f"🐍 Python version: {version.major}.{version.minor}.{version.micro}")

    if version >= required:
        print(f"   ✅ Compatible (>= {required[0]}.{required[1]})")
        return True
    else:
        print(f"   ❌ Too old (need >= {required[0]}.{required[1]})")
        return False


def check_dependencies():
    """Check if all required dependencies are installed."""
    required_packages = [
        "anthropic",
        "openai",
        "google.generativeai",
        "pybtex",
        "citeproc",
        "yaml",
        "markdown",
        "docx",
        "requests",
        "bs4",
        "lxml",
        "dotenv",
        "rich",
    ]

    # WeasyPrint needs special handling - check if installed without importing
    # (importing can fail due to missing system libs like pango/gobject)
    optional_packages = ["weasyprint"]

    print("\n📦 Dependencies:")
    all_installed = True

    for package in required_packages:
        try:
            __import__(package.replace("-", "_"))
            print(f"   ✅ {package}")
        except ImportError:
            print(f"   ❌ {package} (missing)")
            all_installed = False
        except Exception as e:
            print(f"   ⚠️  {package} (import error: {e})")
            all_installed = False

    # Check optional packages (won't fail overall if missing)
    for package in optional_packages:
        try:
            result = subprocess.run(
                [sys.executable, "-c", f"import {package}"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                print(f"   ✅ {package}")
            else:
                if "OSError" in result.stderr or "cannot load library" in result.stderr:
                    print(f"   ⚠️  {package} (missing system libs - run: brew install pango gdk-pixbuf)")
                else:
                    print(f"   ❌ {package} (missing)")
        except Exception:
            print(f"   ⚠️  {package} (could not verify)")

    return all_installed


def check_api_keys():
    """Check if API keys are configured."""
    print("\n🔑 API Keys (from environment):")

    keys = {
        "GOOGLE_API_KEY": "Google Gemini (primary)",
        "GEMINI_API_KEY": "Google Gemini (alias)",
        "ANTHROPIC_API_KEY": "Anthropic Claude",
        "OPENAI_API_KEY": "OpenAI GPT",
    }

    env_file = Path(".env")
    if env_file.exists():
        print(f"   ℹ️  Found .env file: {env_file.absolute()}")
        from dotenv import load_dotenv
        load_dotenv()
    else:
        print(f"   ⚠️  No .env file found (using system environment)")

    found_any = False
    for key, name in keys.items():
        value = os.getenv(key)
        if value:
            # Mask the key for security
            masked = value[:8] + "..." + value[-4:] if len(value) > 12 else "***"
            print(f"   ✅ {name}: {masked}")
            found_any = True
        else:
            print(f"   ⚠️  {name}: Not set")

    if not found_any:
        print("\n   ⚠️  WARNING: No API keys configured!")
        print("   You need at least one LLM API key to generate theses.")
        print("   See: https://github.com/federicodeponte/opendraft#setup")

    return found_any


def check_pdf_engines():
    """Check if PDF generation engines are available."""
    print("\n📄 PDF Engines:")

    engines = [
        ("weasyprint", "WeasyPrint (recommended)"),
        ("pandoc", "Pandoc"),
        ("libreoffice", "LibreOffice"),
    ]

    available_count = 0

    for cmd, name in engines:
        try:
            result = subprocess.run(
                [cmd, "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                version = result.stdout.split("\n")[0][:50]
                print(f"   ✅ {name}: {version}")
                available_count += 1
            else:
                print(f"   ❌ {name}: Not available")
        except (FileNotFoundError, subprocess.TimeoutExpired):
            print(f"   ❌ {name}: Not available")

    if available_count == 0:
        print("\n   ⚠️  WARNING: No PDF engines found!")
        print("   You need at least one PDF engine to export theses.")
        print("   Install WeasyPrint: pip install weasyprint")

    return available_count > 0


def check_latex():
    """Check if LaTeX is properly installed with required packages."""
    print("\n📝 LaTeX (required for Pandoc PDF export):")

    # Check for pdflatex
    try:
        result = subprocess.run(
            ["pdflatex", "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            version = result.stdout.split("\n")[0][:60]
            print(f"   ✅ pdflatex: {version}")
            # pdflatex found, now check for required packages
            return _check_latex_packages()
        else:
            print(f"   ❌ pdflatex: Not available")
            _print_latex_install_instructions()
            return False
    except (FileNotFoundError, subprocess.TimeoutExpired):
        print(f"   ❌ pdflatex: Not available")
        _print_latex_install_instructions()
        return False


def _print_latex_install_instructions():
    """Print LaTeX installation instructions."""
    print()
    print("      Install LaTeX (choose one):")
    print()
    print("      TinyTeX (recommended, ~150MB):")
    print('        curl -sL "https://yihui.org/tinytex/install-bin-unix.sh" | sh')
    print("        # Restart terminal, then: tlmgr install relsize setspace")
    print()
    print("      MacTeX (full, ~4GB):")
    print("        brew install --cask mactex")
    print("        # Restart terminal, then: sudo tlmgr install relsize setspace")
    print()
    print("      Ubuntu/Debian:")
    print("        sudo apt install texlive-full")


def _check_latex_packages():
    """Check for required LaTeX packages by trying to compile a test document."""
    required_packages = ["relsize", "setspace", "geometry", "fancyhdr"]
    missing_packages = []

    import tempfile
    for pkg in required_packages:
        test_doc = f"\\documentclass{{article}}\n\\usepackage{{{pkg}}}\n\\begin{{document}}test\\end{{document}}"
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.tex', delete=False) as f:
                f.write(test_doc)
                tex_file = f.name

            result = subprocess.run(
                ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex_file],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=tempfile.gettempdir()
            )

            # Clean up
            for ext in ['.tex', '.pdf', '.aux', '.log']:
                try:
                    Path(tex_file.replace('.tex', ext)).unlink(missing_ok=True)
                except:
                    pass

            if result.returncode != 0 or f"File `{pkg}.sty' not found" in result.stdout:
                missing_packages.append(pkg)
                print(f"   ❌ {pkg}.sty: Missing")
            else:
                print(f"   ✅ {pkg}.sty: Available")

        except Exception as e:
            missing_packages.append(pkg)
            print(f"   ⚠️  {pkg}.sty: Could not verify ({e})")

    if missing_packages:
        print(f"\n   ⚠️  Missing LaTeX packages: {', '.join(missing_packages)}")
        print("      Install: sudo tlmgr install " + " ".join(missing_packages))
        return False

    return True


def check_file_structure():
    """Check if project structure is intact."""
    print("\n📁 Project Structure:")

    required_dirs = [
        "utils",
        "concurrency",
        "prompts",
        "examples",
    ]

    all_exist = True

    for dir_name in required_dirs:
        dir_path = Path(dir_name)
        if dir_path.exists() and dir_path.is_dir():
            file_count = len(list(dir_path.glob("**/*.py")))
            print(f"   ✅ {dir_name}/ ({file_count} Python files)")
        else:
            print(f"   ❌ {dir_name}/ (missing)")
            all_exist = False

    return all_exist


def verify_installation():
    """Main verification function."""
    print("=" * 60)
    print("  OpenDraft - Installation Verification")
    print("=" * 60)

    results = {}

    results["python"] = check_python_version()
    results["dependencies"] = check_dependencies()
    results["api_keys"] = check_api_keys()
    results["pdf_engines"] = check_pdf_engines()
    results["latex"] = check_latex()
    results["structure"] = check_file_structure()

    print("\n" + "=" * 60)
    print("  SUMMARY")
    print("=" * 60)

    all_passed = all(results.values())

    for check, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status:10} {check.replace('_', ' ').title()}")

    print("=" * 60)

    if all_passed:
        print("\n✅ Installation verified successfully!")
        print("   You're ready to generate academic theses.")
        print("\nNext steps:")
        print("  1. Review QUICKSTART.md for usage examples")
        print("  2. Run: python tests/scripts/test_ai_pricing_draft.py")
        print("  3. Check examples/ for sample theses")
        return 0
    else:
        print("\n⚠️  Installation has issues (see above)")
        print("\nTroubleshooting:")
        print("  - Install missing dependencies: pip install -e .")
        print("  - Configure API keys in .env file")
        print("  - See: https://github.com/federicodeponte/opendraft#troubleshooting")
        return 1


if __name__ == "__main__":
    sys.exit(verify_installation())
