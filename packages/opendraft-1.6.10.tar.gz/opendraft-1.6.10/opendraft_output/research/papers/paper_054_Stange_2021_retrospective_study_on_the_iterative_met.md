# RETROSPECTIVE STUDY ON THE ITERATIVE METHODS OF ARCHITECTURAL VISUALIZATION FROM THE NEOLITHIC TO THE DIGITAL BUILDING INFORMATION MODEL

**Authors:** Stange, HafenCity
**Year:** 2021
**DOI:** **URL**: https://www.semanticscholar.org/paper/073047c6095ae8fcd9dd4b5ccc3d0e058c5b10e5
**URL:** https://www.semanticscholar.org/paper/073047c6095ae8fcd9dd4b5ccc3d0e058c5b10e5

## Abstract

No abstract available in source

## Citation Details

RETROSPECTIVE STUDY ON THE ITERATIVE METHODS OF ARCHITECTURAL VISUALIZATION FROM THE NEOLITHIC TO THE DIGITAL BUILDING INFORMATION MODEL
**Authors**: Stange, HafenCity
**Year**: 2021
**DOI**: 
**URL**: https://www.semanticscholar.org/paper/073047c6095ae8fcd9dd4b5ccc3d0e058c5b10e5  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
