# Development of a Concept for Inner-City Delivery &amp; Supply Utilising Electromobility

**Authors:** Schaumann
**Year:** 2013
**DOI:** 10.1007/978-3-642-32838-1_14
**URL:** https://doi.org/10.1007/978-3-642-32838-1_14

## Abstract

No abstract available in source

## Citation Details

Development of a Concept for Inner-City Delivery &amp; Supply Utilising Electromobility
**Authors**: Schaumann
**Year**: 2013
**DOI**: 10.1007/978-3-642-32838-1_14
**URL**: https://doi.org/10.1007/978-3-642-32838-1_14  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
