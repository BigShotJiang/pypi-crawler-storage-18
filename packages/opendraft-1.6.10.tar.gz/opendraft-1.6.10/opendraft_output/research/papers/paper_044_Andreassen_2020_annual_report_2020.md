# Annual Report 2020

**Authors:** Andreassen
**Year:** 2020
**DOI:** 10.30875/4a0b4159-en
**URL:** https://doi.org/10.30875/4a0b4159-en

## Abstract

<jats:p xml:lang="fr" />

## Citation Details

Annual Report 2020
**Authors**: Andreassen
**Year**: 2020
**DOI**: 10.30875/4a0b4159-en
**URL**: https://doi.org/10.30875/4a0b4159-en

**Abstract**: <jats:p xml:lang="fr" />  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
