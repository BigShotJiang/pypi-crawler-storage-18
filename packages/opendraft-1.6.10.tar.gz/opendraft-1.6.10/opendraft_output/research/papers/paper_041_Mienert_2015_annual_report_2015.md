# Annual report 2015

**Authors:** Mienert
**Year:** 2015
**DOI:** 10.1007/s12402-016-0192-7
**URL:** https://doi.org/10.1007/s12402-016-0192-7

## Abstract

No abstract available in source

## Citation Details

Annual report 2015
**Authors**: Mienert
**Year**: 2015
**DOI**: 10.1007/s12402-016-0192-7
**URL**: https://doi.org/10.1007/s12402-016-0192-7  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
