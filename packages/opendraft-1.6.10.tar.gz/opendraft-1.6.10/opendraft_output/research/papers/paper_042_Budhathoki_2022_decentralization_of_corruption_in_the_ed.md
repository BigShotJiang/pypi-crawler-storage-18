# Decentralization of Corruption in the Education Sector: An Analysis of Anti- Graft Reports

**Authors:** Budhathoki
**Year:** 2022
**DOI:** 10.3126/mef.v12i01.45938
**URL:** https://doi.org/10.3126/mef.v12i01.45938

## Abstract

The Commission for the Investigation of Abuse of Authority (CIAA) annual report points out that complaints related to the education sector for financial misuses occupy the largest share consistently in the past few years. In this context, the paper aims to draw on types and patterns of educational corruption in Nepal in the context of education decentralization since 2000. Further, it interprets how it takes place and its associated factors. Undertaking the qualitative content analysis of annual reports of CIAA and Office of the Auditor General (OAG) of Nepal between 2010 and 2015, this article portrays financial irregularities taking place consistently under construction work, teacher salary, and student-related grants - showing or allocating more funds, releasing additional teacher salary and inflating student numbers. The existing literature on education decentralization and corruption entails various factors for financial mismanagement - lack of local capacity, elite capture of public funds, etc. Using education decentralization as a theoretical lens (Mc Ginn & Welsh, 1999), this paper argues that poor monitoring and lack of policy implementation are major factors for the misuse of education finance in Nepal, coupled with complex procedural aspects of the public fund flow system. Thus, an adequate support system, especially during the early phase, can facilitate the decentralization of education and combat corruption.

## Citation Details

Decentralization of Corruption in the Education Sector: An Analysis of Anti- Graft Reports
**Authors**: Budhathoki
**Year**: 2022
**DOI**: 10.3126/mef.v12i01.45938
**URL**: https://doi.org/10.3126/mef.v12i01.45938

**Abstract**: The Commission for the Investigation of Abuse of Authority (CIAA) annual report points out that complaints related to the education sector for financial misuses occupy the largest share consistently in the past few years. In this context, the paper aims to draw on types and patterns of educational corruption in Nepal in the context of education decentralization since 2000. Further, it interprets how it takes place and its associated factors. Undertaking the qualitative content analysis of annual reports of CIAA and Office of the Auditor General (OAG) of Nepal between 2010 and 2015, this article portrays financial irregularities taking place consistently under construction work, teacher salary, and student-related grants - showing or allocating more funds, releasing additional teacher salary and inflating student numbers. The existing literature on education decentralization and corruption entails various factors for financial mismanagement - lack of local capacity, elite capture of public funds, etc. Using education decentralization as a theoretical lens (Mc Ginn & Welsh, 1999), this paper argues that poor monitoring and lack of policy implementation are major factors for the misuse of education finance in Nepal, coupled with complex procedural aspects of the public fund flow system. Thus, an adequate support system, especially during the early phase, can facilitate the decentralization of education and combat corruption.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
