# THE SIXTEENTH CENTURY

**Authors:** Kottmann, Grabner-Haider, Davidowicz, Prenner, Müller, Müller
**Year:** 2016
**DOI:** 10.2307/j.ctv1rmj8d.10
**URL:** https://doi.org/10.2307/j.ctv1rmj8d.10

## Abstract

No abstract available in source

## Citation Details

THE SIXTEENTH CENTURY
**Authors**: Kottmann, Grabner-Haider, Davidowicz, Prenner, Müller, Müller
**Year**: 2016
**DOI**: 10.2307/j.ctv1rmj8d.10
**URL**: https://doi.org/10.2307/j.ctv1rmj8d.10  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
