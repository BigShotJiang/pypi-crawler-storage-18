# Extending and understanding: an application of machine learning to the World Bank's logistics performance index

**Authors:** Shepherd, Sriklay
**Year:** 2023
**DOI:** 10.1108/ijpdlm-06-2022-0180
**URL:** https://doi.org/10.1108/ijpdlm-06-2022-0180

## Abstract

PurposeThe authors extend the World Bank's Logistics Performance Index (LPI) for 30 additional countries and 13 additional years. The authors develop an inexpensive method for extending survey data when frequent, universal surveys are unavailable. The authors identify groups of country characteristics that influence LPI scores.Design/methodology/approachUsing data from the World Development Indicators—the broadest global dataset of country socioeconomic features—the authors test machine learning algorithms for their ability to predict the LPI. The authors examine importance scores to identify factors that influence LPI scores.FindingsThe best performing algorithm produces predictions on unseen data that account for nearly 90% of observed variation, and are accurate to within 6%. It performs twice as well as an OLS model with per capita income as the only predictor. Explanatory factors are business environment, economic structure, finance, environment, human development, and institutional quality.Practical implicationsMachine learning offers a simple, inexpensive way of extending the coverage of survey data. This dataset provides a richer picture of logistics performance around the world. The factors the authors identify as predicting higher LPI scores can help policymakers and practitioners target interventions.Originality/valueThis paper is one of the first applications of machine learning to extend coverage of an index based on an international survey. The authors use the new data to provide the most wide-ranging analysis of logistics performance across countries and over time. The output is an important resource for policymakers tracking performance, and researchers particularly in smaller and lower income countries. The authors also examine a wider range of explanatory factors for LPI scores than previous work.

## Citation Details

Extending and understanding: an application of machine learning to the World Bank's logistics performance index
**Authors**: Shepherd, Sriklay
**Year**: 2023
**DOI**: 10.1108/ijpdlm-06-2022-0180
**URL**: https://doi.org/10.1108/ijpdlm-06-2022-0180

**Abstract**: PurposeThe authors extend the World Bank's Logistics Performance Index (LPI) for 30 additional countries and 13 additional years. The authors develop an inexpensive method for extending survey data when frequent, universal surveys are unavailable. The authors identify groups of country characteristics that influence LPI scores.Design/methodology/approachUsing data from the World Development Indicators—the broadest global dataset of country socioeconomic features—the authors test machine learning algorithms for their ability to predict the LPI. The authors examine importance scores to identify factors that influence LPI scores.FindingsThe best performing algorithm produces predictions on unseen data that account for nearly 90% of observed variation, and are accurate to within 6%. It performs twice as well as an OLS model with per capita income as the only predictor. Explanatory factors are business environment, economic structure, finance, environment, human development, and institutional quality.Practical implicationsMachine learning offers a simple, inexpensive way of extending the coverage of survey data. This dataset provides a richer picture of logistics performance around the world. The factors the authors identify as predicting higher LPI scores can help policymakers and practitioners target interventions.Originality/valueThis paper is one of the first applications of machine learning to extend coverage of an index based on an international survey. The authors use the new data to provide the most wide-ranging analysis of logistics performance across countries and over time. The output is an important resource for policymakers tracking performance, and researchers particularly in smaller and lower incom  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
