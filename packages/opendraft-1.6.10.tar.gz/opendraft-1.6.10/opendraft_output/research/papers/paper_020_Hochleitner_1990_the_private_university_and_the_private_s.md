# The Private University and the Private Sector in Higher Education: A Spanish Perspective

**Authors:** Hochleitner
**Year:** 1990
**DOI:** 10.1057/hep.1990.24
**URL:** https://doi.org/10.1057/hep.1990.24

## Abstract

No abstract available in source

## Citation Details

The Private University and the Private Sector in Higher Education: A Spanish Perspective
**Authors**: Hochleitner
**Year**: 1990
**DOI**: 10.1057/hep.1990.24
**URL**: https://doi.org/10.1057/hep.1990.24  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
