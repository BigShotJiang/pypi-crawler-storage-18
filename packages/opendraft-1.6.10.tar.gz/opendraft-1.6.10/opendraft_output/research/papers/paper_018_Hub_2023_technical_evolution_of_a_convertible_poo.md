# Technical evolution of a convertible pool roof on three expedition cruise ships for the shipping company Hapag Lloyd

**Authors:** Hub, Rein
**Year:** 2023
**DOI:** 10.23967/c.membranes.2023.055
**URL:** https://doi.org/10.23967/c.membranes.2023.055

## Abstract

No abstract available in source

## Citation Details

Technical evolution of a convertible pool roof on three expedition cruise ships for the shipping company Hapag Lloyd
**Authors**: Hub, Rein
**Year**: 2023
**DOI**: 10.23967/c.membranes.2023.055
**URL**: https://doi.org/10.23967/c.membranes.2023.055  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
