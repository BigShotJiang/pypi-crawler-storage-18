# AfDB Group Annual Report 2011

**Authors:** AfDB
**Year:** 2011
**DOI:** **URL**: https://www.semanticscholar.org/paper/5e09fa28704f006066b948f90f187e1d285885e1
**URL:** https://www.semanticscholar.org/paper/5e09fa28704f006066b948f90f187e1d285885e1

## Abstract

No abstract available in source

## Citation Details

AfDB Group Annual Report 2011
**Authors**: AfDB
**Year**: 2011
**DOI**: 
**URL**: https://www.semanticscholar.org/paper/5e09fa28704f006066b948f90f187e1d285885e1  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
