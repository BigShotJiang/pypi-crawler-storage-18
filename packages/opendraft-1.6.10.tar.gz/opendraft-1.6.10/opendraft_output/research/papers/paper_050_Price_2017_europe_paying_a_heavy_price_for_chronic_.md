# Europe paying a heavy price for chronic diseases, finds new OECD-European Commission report

**Authors:** Price
**Year:** 2017
**DOI:** 10.1136/EJHPHARM-2017-001227
**URL:** https://doi.org/10.1136/EJHPHARM-2017-001227

## Abstract

No abstract available in source

## Citation Details

Europe paying a heavy price for chronic diseases, finds new OECD-European Commission report
**Authors**: Price
**Year**: 2017
**DOI**: 10.1136/EJHPHARM-2017-001227
**URL**: https://doi.org/10.1136/EJHPHARM-2017-001227  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
