# Understanding issues of ‘justice’ in ‘free higher education’: policy, legislation, and implications in the Philippines

**Authors:** Lomer, Lim
**Year:** 2021
**DOI:** 10.1080/23322969.2021.2012242
**URL:** https://doi.org/10.1080/23322969.2021.2012242

## Abstract

ABSTRACT In the context of global debates regarding the purpose of higher education, many national governments have adopted ‘cost-sharing’ mechanisms. Yet in 2017 the Philippines introduced legislation to provide ‘Universal Access’ to higher education by subsidizing tuition fees for all Filipino students in public institutions, partial fee subsidies students in private institutions, and further means-tested support. This article uses a conceptual framework integrating multiple models of social justice to examine 73 legislative texts: 59 individual House of Representative bills, 11 individual Senate bills, the cumulative House and Senate bill, and the final Republic Act. We develop an innovative methodology for analysing legislation that incorporates both structured content and reflexive thematic analysis. The findings show a striking consensus on representing access to HE as a social justice issue, but concepts of procedural fairness varied. Economic rationales intersected with justice narratives, positioning universal tuition as ensuring equal access to income, fostering ‘inclusive growth’ for national development that includes the private sector. The Philippines offers an instructive case for other liberal democracies where ‘who pays’ for higher education remains politically divisive. Our analysis suggests that legislators achieved consensus w by situating social justice as compatible with marketised, neo-liberal paradigms of higher education.

## Citation Details

Understanding issues of ‘justice’ in ‘free higher education’: policy, legislation, and implications in the Philippines
**Authors**: Lomer, Lim
**Year**: 2021
**DOI**: 10.1080/23322969.2021.2012242
**URL**: https://doi.org/10.1080/23322969.2021.2012242

**Abstract**: ABSTRACT In the context of global debates regarding the purpose of higher education, many national governments have adopted ‘cost-sharing’ mechanisms. Yet in 2017 the Philippines introduced legislation to provide ‘Universal Access’ to higher education by subsidizing tuition fees for all Filipino students in public institutions, partial fee subsidies students in private institutions, and further means-tested support. This article uses a conceptual framework integrating multiple models of social justice to examine 73 legislative texts: 59 individual House of Representative bills, 11 individual Senate bills, the cumulative House and Senate bill, and the final Republic Act. We develop an innovative methodology for analysing legislation that incorporates both structured content and reflexive thematic analysis. The findings show a striking consensus on representing access to HE as a social justice issue, but concepts of procedural fairness varied. Economic rationales intersected with justice narratives, positioning universal tuition as ensuring equal access to income, fostering ‘inclusive growth’ for national development that includes the private sector. The Philippines offers an instructive case for other liberal democracies where ‘who pays’ for higher education remains politically divisive. Our analysis suggests that legislators achieved consensus w by situating social justice as compatible with marketised, neo-liberal paradigms of higher education.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
