# EVOLUTION OF AN INTEGRATED, PROJECT-BASED LOGISTICS ENGINEERING CURRICULUM

**Authors:** Pasek, Pawlewski
**Year:** 2019
**DOI:** 10.24908/pceea.vi0.13790
**URL:** https://doi.org/10.24908/pceea.vi0.13790

## Abstract

This paper describes the evolution of content and teaching practices of an innovative undergraduate curriculum developed for a new Logistics Engineering degree program. Originally proposed and implemented in 2010, the bi-level curriculum follows European directives and complies with the Bologna Process. Over the years the content and teaching practices were continuously reviewed and modified to stay in sync with teaching practices of design and entrepreneurship, progress simulation technologies, and student responses.&#x0D;
Since the initial introduction of the curriculum many advances in various relevant areas have taken place and consequently the content of the curriculum had to be updated. For example, Lean Startup Method using Business Model Canvas has replaced business plans in teaching entrepreneurship. Similarly, as general softwarebased simulation tools have grown in complexity, teaching them requires more time and becomes time-impractical. A simpler approach based on limited-instruction tools tailored for product assembly, but built on these general simulation platforms, offers a more effective practical solution.&#x0D;

## Citation Details

EVOLUTION OF AN INTEGRATED, PROJECT-BASED LOGISTICS ENGINEERING CURRICULUM
**Authors**: Pasek, Pawlewski
**Year**: 2019
**DOI**: 10.24908/pceea.vi0.13790
**URL**: https://doi.org/10.24908/pceea.vi0.13790

**Abstract**: This paper describes the evolution of content and teaching practices of an innovative undergraduate curriculum developed for a new Logistics Engineering degree program. Originally proposed and implemented in 2010, the bi-level curriculum follows European directives and complies with the Bologna Process. Over the years the content and teaching practices were continuously reviewed and modified to stay in sync with teaching practices of design and entrepreneurship, progress simulation technologies, and student responses.&#x0D;
Since the initial introduction of the curriculum many advances in various relevant areas have taken place and consequently the content of the curriculum had to be updated. For example, Lean Startup Method using Business Model Canvas has replaced business plans in teaching entrepreneurship. Similarly, as general softwarebased simulation tools have grown in complexity, teaching them requires more time and becomes time-impractical. A simpler approach based on limited-instruction tools tailored for product assembly, but built on these general simulation platforms, offers a more effective practical solution.&#x0D;  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
