# Germany

**Authors:** Kehm
**Year:** 2017
**DOI:** 10.4324/9781315537412-7
**URL:** https://doi.org/10.4324/9781315537412-7

## Abstract

No abstract available in source

## Citation Details

Germany
**Authors**: Kehm
**Year**: 2017
**DOI**: 10.4324/9781315537412-7
**URL**: https://doi.org/10.4324/9781315537412-7  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
