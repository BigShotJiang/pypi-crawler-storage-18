# Optimal Sensor Placement with Minimal Predicted Posterior Variance

**Authors:** Mendler, Marsili, Kessler, Grosse
**Year:** 2024
**DOI:** 10.58286/29612
**URL:** https://doi.org/10.58286/29612

## Abstract

The performance of each monitoring system critically depends on the sensor layout and typical optimization criteria are based on the accessibility to the structure on site, experience with similar structures, and an optimal signal-to-noise ratio. More advanced criteria aim to optimize the feature extraction process, and this paper aims to develop a sensor placement strategy for optimal damage diagnosis. The approach is based on Bayesian updating and the optimization goal is to find a sensor layout that is the most sensitive to small changes in the examined system parameters. It is shown that such layouts manifest themselves through a minimum variance in the posterior distribution. Using Kalman filters, the posterior variance can be “predicted” based on the measurement error and numerical models, so no data from and no simulations in the damaged state are required. By employing a polynomial chaos expansion (PCE)-based Kalman filter, the method becomes applicable for structures with many measurement channels, multiple examined system parameters, and for a large number of sensor combinations. Gaussian distributions are assumed for both system inputs and outputs. For proof of concept, the sensor placement is optimized on a numerical cantilever beam, demonstrating that the method can efficiently find the optimal sensor layout. Moreover, arbitrary measurement quantities (inclinations, vibrations, etc.) or damage-sensitive features (statistical values, modal parameters, etc.) can be used as observations, and multiple system parameters can be considered at the same time. Among other factors, an optimal sensor layout leads to large measurement responses, a small measurement error, and more advanced statistical quantities that will be elaborated on in detail.

## Citation Details

Optimal Sensor Placement with Minimal Predicted Posterior Variance
**Authors**: Mendler, Marsili, Kessler, Grosse
**Year**: 2024
**DOI**: 10.58286/29612
**URL**: https://doi.org/10.58286/29612

**Abstract**: The performance of each monitoring system critically depends on the sensor layout and typical optimization criteria are based on the accessibility to the structure on site, experience with similar structures, and an optimal signal-to-noise ratio. More advanced criteria aim to optimize the feature extraction process, and this paper aims to develop a sensor placement strategy for optimal damage diagnosis. The approach is based on Bayesian updating and the optimization goal is to find a sensor layout that is the most sensitive to small changes in the examined system parameters. It is shown that such layouts manifest themselves through a minimum variance in the posterior distribution. Using Kalman filters, the posterior variance can be “predicted” based on the measurement error and numerical models, so no data from and no simulations in the damaged state are required. By employing a polynomial chaos expansion (PCE)-based Kalman filter, the method becomes applicable for structures with many measurement channels, multiple examined system parameters, and for a large number of sensor combinations. Gaussian distributions are assumed for both system inputs and outputs. For proof of concept, the sensor placement is optimized on a numerical cantilever beam, demonstrating that the method can efficiently find the optimal sensor layout. Moreover, arbitrary measurement quantities (inclinations, vibrations, etc.) or damage-sensitive features (statistical values, modal parameters, etc.) can be used as observations, and multiple system parameters can be considered at the same time. Among other factors, an optimal sensor layout leads to large measurement responses, a small measurement error, and more advanced statistical quantities that will be elaborated on in detail.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
