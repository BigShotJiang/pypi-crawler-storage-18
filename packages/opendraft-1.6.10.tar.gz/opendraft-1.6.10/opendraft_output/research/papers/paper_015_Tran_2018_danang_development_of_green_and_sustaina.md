# Danang – Development Of Green And Sustainable Logistics Center

**Authors:** Tran, Nguyen
**Year:** 2018
**DOI:** 10.18411/lj-07-2018-41
**URL:** https://doi.org/10.18411/lj-07-2018-41

## Abstract

No abstract available in source

## Citation Details

Danang – Development Of Green And Sustainable Logistics Center
**Authors**: Tran, Nguyen
**Year**: 2018
**DOI**: 10.18411/lj-07-2018-41
**URL**: https://doi.org/10.18411/lj-07-2018-41  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
