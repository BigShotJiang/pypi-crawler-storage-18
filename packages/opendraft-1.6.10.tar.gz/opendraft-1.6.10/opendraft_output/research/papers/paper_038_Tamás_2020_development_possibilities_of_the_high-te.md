# Development Possibilities of the High-tech Logistics Laboratory Established at the Institute of Logistics of the University of Miskolc

**Authors:** Tamás, Bányai, Illés, Tollár, Veres, Cservenák, Hardai, Skapinyecz
**Year:** 2020
**DOI:** 10.9734/jerr/2020/v13i317127
**URL:** https://doi.org/10.9734/jerr/2020/v13i317127

## Abstract

The Institute of Logistics of the University of Miskolc started training logistics in Hungarian higher education for the first time in the early 1990s. In recent decades, the training structure and laboratory infrastructure of the institute have changed significantly, relying on the relevant educational and research connections in Germany. The publication presents one of the institute's laboratories, the High-tech Integrated Logistics Laboratory, which contains a number of material handling equipment (pallet handling cell, AGV, automated warehousing system, etc.), which provides an opportunity for fulfillment of high-quality teaching and research tasks. In addition to a brief presentation of the laboratory, the researchers present their future ideas about the laboratory in different areas of development, which can also serve as a useful guide for other professionals involved in logistics education and research. Review Article Tamás et al.; JERR, 13(3): 60-68, 2020; Article no.JERR.58102 61

## Citation Details

Development Possibilities of the High-tech Logistics Laboratory Established at the Institute of Logistics of the University of Miskolc
**Authors**: Tamás, Bányai, Illés, Tollár, Veres, Cservenák, Hardai, Skapinyecz
**Year**: 2020
**DOI**: 10.9734/jerr/2020/v13i317127
**URL**: https://doi.org/10.9734/jerr/2020/v13i317127

**Abstract**: The Institute of Logistics of the University of Miskolc started training logistics in Hungarian higher education for the first time in the early 1990s. In recent decades, the training structure and laboratory infrastructure of the institute have changed significantly, relying on the relevant educational and research connections in Germany. The publication presents one of the institute's laboratories, the High-tech Integrated Logistics Laboratory, which contains a number of material handling equipment (pallet handling cell, AGV, automated warehousing system, etc.), which provides an opportunity for fulfillment of high-quality teaching and research tasks. In addition to a brief presentation of the laboratory, the researchers present their future ideas about the laboratory in different areas of development, which can also serve as a useful guide for other professionals involved in logistics education and research. Review Article Tamás et al.; JERR, 13(3): 60-68, 2020; Article no.JERR.58102 61  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
