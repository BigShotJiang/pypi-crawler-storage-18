# The Operation and Service Performance of Global Logistics Center in Tawan

**Authors:** CHIU Rong-her
**Year:** 2008
**DOI:** 10.37059/tjosal.2008..57.177
**URL:** https://doi.org/10.37059/tjosal.2008..57.177

## Abstract

No abstract available in source

## Citation Details

The Operation and Service Performance of Global Logistics Center in Tawan
**Authors**: CHIU Rong-her
**Year**: 2008
**DOI**: 10.37059/tjosal.2008..57.177
**URL**: https://doi.org/10.37059/tjosal.2008..57.177  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
