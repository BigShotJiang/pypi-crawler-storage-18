# Blockchain Driven Supply Chain Management

**Authors:** Kayιkcι
**Year:** 2020
**DOI:** 10.1201/9780429327636-16
**URL:** https://doi.org/10.1201/9780429327636-16

## Abstract

No abstract available in source

## Citation Details

Blockchain Driven Supply Chain Management
**Authors**: Kayιkcι
**Year**: 2020
**DOI**: 10.1201/9780429327636-16
**URL**: https://doi.org/10.1201/9780429327636-16

### From Semantic Scholar (25 citations)  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
