# Seeing Between the Pixels

**Authors:** Strothotte, Strothotte
**Year:** 1997
**DOI:** 10.1007/978-3-642-60361-7
**URL:** https://doi.org/10.1007/978-3-642-60361-7

## Abstract

No abstract available in source

## Citation Details

Seeing Between the Pixels
**Authors**: Strothotte, Strothotte
**Year**: 1997
**DOI**: 10.1007/978-3-642-60361-7
**URL**: https://doi.org/10.1007/978-3-642-60361-7  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
