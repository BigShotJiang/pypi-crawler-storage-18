# HAMBURG: Palaeontological Collections of the Center of Natural History, Universität Hamburg

**Authors:** Kotthoff, Schlüter
**Year:** 2018
**DOI:** 10.1007/978-3-319-77401-5_27
**URL:** https://doi.org/10.1007/978-3-319-77401-5_27

## Abstract

No abstract available in source

## Citation Details

HAMBURG: Palaeontological Collections of the Center of Natural History, Universität Hamburg
**Authors**: Kotthoff, Schlüter
**Year**: 2018
**DOI**: 10.1007/978-3-319-77401-5_27
**URL**: https://doi.org/10.1007/978-3-319-77401-5_27  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
