# Strategische Vereinsentwicklung am Beispiel der Bundesvereinigung Logistik

**Authors:** Klinkner, Wimmer
**Year:** 2010
**DOI:** 10.1007/978-3-8349-6515-8_38
**URL:** https://doi.org/10.1007/978-3-8349-6515-8_38

## Abstract

No abstract available in source

## Citation Details

Strategische Vereinsentwicklung am Beispiel der Bundesvereinigung Logistik
**Authors**: Klinkner, Wimmer
**Year**: 2010
**DOI**: 10.1007/978-3-8349-6515-8_38
**URL**: https://doi.org/10.1007/978-3-8349-6515-8_38  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
