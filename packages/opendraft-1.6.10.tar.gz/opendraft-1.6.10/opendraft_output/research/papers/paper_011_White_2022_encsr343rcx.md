# ENCSR343RCX

**Authors:** White
**Year:** 2022
**DOI:** 10.17989/encsr343rcx
**URL:** https://doi.org/10.17989/encsr343rcx

## Abstract

No abstract available in source

## Citation Details

ENCSR343RCX
**Authors**: White
**Year**: 2022
**DOI**: 10.17989/encsr343rcx
**URL**: https://doi.org/10.17989/encsr343rcx  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
