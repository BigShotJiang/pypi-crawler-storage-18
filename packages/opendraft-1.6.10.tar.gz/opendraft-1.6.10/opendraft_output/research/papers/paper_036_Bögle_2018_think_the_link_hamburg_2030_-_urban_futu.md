# Think the link. Hamburg 2030 - Urban Futures. Reflections on urban regeneration processes and documentation of the second Baltic International Summer School 2016 at HafenCity University Hamburg

**Authors:** Bögle, Gieron, Kasting, Seggern, Peselyte-schneider, Popova
**Year:** 2018
**DOI:** **URL**: https://www.semanticscholar.org/paper/6f8fe91987f973acb2ed5c8515e23e6b9bd7727f
**URL:** https://www.semanticscholar.org/paper/6f8fe91987f973acb2ed5c8515e23e6b9bd7727f

## Abstract

No abstract available in source

## Citation Details

Think the link. Hamburg 2030 - Urban Futures. Reflections on urban regeneration processes and documentation of the second Baltic International Summer School 2016 at HafenCity University Hamburg
**Authors**: Bögle, Gieron, Kasting, Seggern, Peselyte-schneider, Popova
**Year**: 2018
**DOI**: 
**URL**: https://www.semanticscholar.org/paper/6f8fe91987f973acb2ed5c8515e23e6b9bd7727f  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
