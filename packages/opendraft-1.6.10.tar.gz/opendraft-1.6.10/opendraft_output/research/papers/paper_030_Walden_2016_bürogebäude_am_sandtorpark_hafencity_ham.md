# Bürogebäude am Sandtorpark, HafenCity, Hamburg, Deutschland / Sandtorpark Office Building, HafenCity, Hamburg, Germany

**Authors:** Walden
**Year:** 2016
**DOI:** 10.1515/9783990431344-021
**URL:** https://doi.org/10.1515/9783990431344-021

## Abstract

No abstract available in source

## Citation Details

Bürogebäude am Sandtorpark, HafenCity, Hamburg, Deutschland / Sandtorpark Office Building, HafenCity, Hamburg, Germany
**Authors**: Walden
**Year**: 2016
**DOI**: 10.1515/9783990431344-021
**URL**: https://doi.org/10.1515/9783990431344-021  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
