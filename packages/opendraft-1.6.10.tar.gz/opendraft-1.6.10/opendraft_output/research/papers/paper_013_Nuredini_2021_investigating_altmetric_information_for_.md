# INVESTIGATING ALTMETRIC INFORMATION FOR THE TOP 1000 JOURNALS FROM HANDELSBLATT RANKING IN ECONOMIC AND BUSINESS STUDIES

**Authors:** Nuredini
**Year:** 2021
**DOI:** 10.1111/joes.12414
**URL:** https://doi.org/10.1111/joes.12414

## Abstract

AbstractIn this study, the top 1000 journals from Handelsblatt ranking (often used in German‐speaking countries) in Economics (E) and Business Studies (BS) as an extension of the two previous studies from Nuredini and Peters are explored. Moderate shares of articles from E and BS journals for publication years 2011–2018 are found in Mendeley (47%) and Altmetric.com (around 44%). This study shows that altmetric information is significantly higher in coverage for articles published between 2016 and 2017. The top 5 most used altmetric sources for E and BS journals are Twitter, News, Facebook, Blogs, and Policy documents. Top highly ranked journals (with classes A+ and A) in E from Handelsblatt ranking are highly mentioned in Altmetric.com, making them also popular in social media platforms (i.e., attention sources). Mendeley counts are positively correlated with citations both at the article and journal level.

## Citation Details

INVESTIGATING ALTMETRIC INFORMATION FOR THE TOP 1000 JOURNALS FROM HANDELSBLATT RANKING IN ECONOMIC AND BUSINESS STUDIES
**Authors**: Nuredini
**Year**: 2021
**DOI**: 10.1111/joes.12414
**URL**: https://doi.org/10.1111/joes.12414

**Abstract**: AbstractIn this study, the top 1000 journals from Handelsblatt ranking (often used in German‐speaking countries) in Economics (E) and Business Studies (BS) as an extension of the two previous studies from Nuredini and Peters are explored. Moderate shares of articles from E and BS journals for publication years 2011–2018 are found in Mendeley (47%) and Altmetric.com (around 44%). This study shows that altmetric information is significantly higher in coverage for articles published between 2016 and 2017. The top 5 most used altmetric sources for E and BS journals are Twitter, News, Facebook, Blogs, and Policy documents. Top highly ranked journals (with classes A+ and A) in E from Handelsblatt ranking are highly mentioned in Altmetric.com, making them also popular in social media platforms (i.e., attention sources). Mendeley counts are positively correlated with citations both at the article and journal level.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
