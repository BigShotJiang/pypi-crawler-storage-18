# Werkstoff Glas

**Authors:** Kühne
**Year:** 1976
**DOI:** 10.1515/9783112540961
**URL:** https://doi.org/10.1515/9783112540961

## Abstract

No abstract available in source

## Citation Details

Werkstoff Glas
**Authors**: Kühne
**Year**: 1976
**DOI**: 10.1515/9783112540961
**URL**: https://doi.org/10.1515/9783112540961  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
