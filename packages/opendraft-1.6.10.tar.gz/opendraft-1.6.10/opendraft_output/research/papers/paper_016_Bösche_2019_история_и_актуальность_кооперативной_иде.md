# ИСТОРИЯ И АКТУАЛЬНОСТЬ КООПЕРАТИВНОЙ ИДЕИ В ГАМБУРГЕ

**Authors:** Bösche, Tikhonovich, Tikhonovich
**Year:** 2019
**DOI:** 10.21295/2223-5639-2019-3-285-303
**URL:** https://doi.org/10.21295/2223-5639-2019-3-285-303

## Abstract

No abstract available in source

## Citation Details

ИСТОРИЯ И АКТУАЛЬНОСТЬ КООПЕРАТИВНОЙ ИДЕИ В ГАМБУРГЕ
**Authors**: Bösche, Tikhonovich, Tikhonovich
**Year**: 2019
**DOI**: 10.21295/2223-5639-2019-3-285-303
**URL**: https://doi.org/10.21295/2223-5639-2019-3-285-303  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
