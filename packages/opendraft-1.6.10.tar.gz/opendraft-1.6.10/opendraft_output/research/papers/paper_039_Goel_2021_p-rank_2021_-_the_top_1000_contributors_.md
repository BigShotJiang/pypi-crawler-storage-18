# P-Rank 2021 - The top 1000 contributors, the top 1000 collaborators, and the top 250 individuals in business research

**Authors:** Goel
**Year:** 2021
**DOI:** 10.2139/ssrn.3758801
**URL:** https://doi.org/10.2139/ssrn.3758801

## Abstract

This document presents various rankings of publication output of scholars in the field of business studies. The rankings are based on the ABDC Journal Quality List, the CABS Academic Journal Guide, the ERIM Journal List, the list of the Handelsblatt BWL Ranking, the Hceres liste des revues, Scimago Journal Ranks, and the VHB Jourqual 3 list. Different metrics are used to account for different ways to assess co-authored publications.

## Citation Details

P-Rank 2021 - The top 1000 contributors, the top 1000 collaborators, and the top 250 individuals in business research
**Authors**: Goel
**Year**: 2021
**DOI**: 10.2139/ssrn.3758801
**URL**: https://doi.org/10.2139/ssrn.3758801

**Abstract**: This document presents various rankings of publication output of scholars in the field of business studies. The rankings are based on the ABDC Journal Quality List, the CABS Academic Journal Guide, the ERIM Journal List, the list of the Handelsblatt BWL Ranking, the Hceres liste des revues, Scimago Journal Ranks, and the VHB Jourqual 3 list. Different metrics are used to account for different ways to assess co-authored publications.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
