# Integrating Digital Twins in Supply Chain Management Education

**Authors:** Eletter, Elrefae, Qasim, Houhamdi
**Year:** 2024
**DOI:** 10.1109/SDS64317.2024.10883925
**URL:** https://doi.org/10.1109/SDS64317.2024.10883925

## Abstract

Higher education is undergoing a considerable transformation due to the rapid progress of technological advancements. However, higher education in business is currently experiencing a notable deficiency of experimental laboratories that would enable the practical application of the student's theoretical knowledge. Specifically, typical teaching approaches in supply chain management (SCM) are insufficient to provide students with the skills to navigate the complicated dynamics of modern supply networks. Conversely, experiential learning allows students to gain knowledge through active participation, thought, and interpretation of real-world experiences. Digital twins (DT) are a vital new tool in mixed-reality immersive learning that helps with hands-on learning. This study aims to provide a new pedagogical paradigm for teaching SCM using experiential learning. It connects classroom teaching with real-world business and societal issues, emerging trends, and best practices. The study emphasizes the interplay between knowledge and ideation. Therefore, it explores using experiential learning theory to teach the SCM course using digital twins. The study advances experiential learning by illustrating its relevance for teaching complex, data-driven decision-making inside a virtual business-oriented framework. It demonstrates how technology may improve learning in higher education.

## Citation Details

Integrating Digital Twins in Supply Chain Management Education
**Authors**: Eletter, Elrefae, Qasim, Houhamdi
**Year**: 2024
**DOI**: 10.1109/SDS64317.2024.10883925
**URL**: https://doi.org/10.1109/SDS64317.2024.10883925

**Abstract**: Higher education is undergoing a considerable transformation due to the rapid progress of technological advancements. However, higher education in business is currently experiencing a notable deficiency of experimental laboratories that would enable the practical application of the student's theoretical knowledge. Specifically, typical teaching approaches in supply chain management (SCM) are insufficient to provide students with the skills to navigate the complicated dynamics of modern supply networks. Conversely, experiential learning allows students to gain knowledge through active participation, thought, and interpretation of real-world experiences. Digital twins (DT) are a vital new tool in mixed-reality immersive learning that helps with hands-on learning. This study aims to provide a new pedagogical paradigm for teaching SCM using experiential learning. It connects classroom teaching with real-world business and societal issues, emerging trends, and best practices. The study emphasizes the interplay between knowledge and ideation. Therefore, it explores using experiential learning theory to teach the SCM course using digital twins. The study advances experiential learning by illustrating its relevance for teaching complex, data-driven decision-making inside a virtual business-oriented framework. It demonstrates how technology may improve learning in higher education.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
