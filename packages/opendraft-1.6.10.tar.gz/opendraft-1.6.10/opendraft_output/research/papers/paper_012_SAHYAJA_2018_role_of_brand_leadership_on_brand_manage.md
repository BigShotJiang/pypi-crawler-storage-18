# ROLE OF BRAND LEADERSHIP ON BRAND MANAGEMENT

**Authors:** SAHYAJA, K. S. SEKHARA
**Year:** 2018
**DOI:** 10.26634/jmgt.13.2.14447
**URL:** https://doi.org/10.26634/jmgt.13.2.14447

## Abstract

No abstract available in source

## Citation Details

ROLE OF BRAND LEADERSHIP ON BRAND MANAGEMENT
      PRACTICES - A STUDY ON HERO MOTOCORP
**Authors**: SAHYAJA, K. S. SEKHARA
**Year**: 2018
**DOI**: 10.26634/jmgt.13.2.14447
**URL**: https://doi.org/10.26634/jmgt.13.2.14447  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
