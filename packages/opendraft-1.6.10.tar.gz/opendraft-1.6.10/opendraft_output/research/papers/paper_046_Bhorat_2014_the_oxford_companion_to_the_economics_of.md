# The Oxford companion to the economics of South Africa

**Authors:** Bhorat, Hirsch, Kanbur, Ncube
**Year:** 2014
**DOI:** 10.1093/ACPROF:OSO/9780199689248.001.0001
**URL:** https://doi.org/10.1093/ACPROF:OSO/9780199689248.001.0001

## Abstract

No abstract available in source

## Citation Details

The Oxford companion to the economics of South Africa
**Authors**: Bhorat, Hirsch, Kanbur, Ncube
**Year**: 2014
**DOI**: 10.1093/ACPROF:OSO/9780199689248.001.0001
**URL**: https://doi.org/10.1093/ACPROF:OSO/9780199689248.001.0001  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
