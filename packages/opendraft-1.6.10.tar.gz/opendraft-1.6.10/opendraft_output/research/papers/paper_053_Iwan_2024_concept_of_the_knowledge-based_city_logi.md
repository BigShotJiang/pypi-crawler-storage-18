# Concept of the knowledge-based city logistics: Problems and solutions

**Authors:** Iwan, Wagner, Kijewska, Jensen
**Year:** 2024
**DOI:** 10.1371/journal.pone.0305563
**URL:** https://doi.org/10.1371/journal.pone.0305563

## Abstract

Efficient city logistics is essential to build smart sustainable cities where inhabitants’ well-being is a priority. Meanwhile, despite the great importance of city logistics processes, their improvement is problematic for many cities. Although solutions from the field of emerging technologies are more and more often used, the question is whether implementing technological tools and filling cities with sensors is a sufficient solution that can solve the problems of intensely growing urban freight transport. The aim of the paper is to examine the role of knowledge management in city logistics and identify barriers to the implementation of knowledge-based city logistics. A key element of the research procedure was an expert survey, to which 31 international experts specialising in city logistics issues were invited, characterised by extensive experience working on research projects in the area of interest. Four knowledge management processes have been transferred to the city logistics area. The results of the study show that the difficulties are observed mainly in the processes of data gathering and knowledge acquisition. The main reason for difficulties in that area is the reluctance of city users, retailers, transport and logistics operators to share information. Identifying these processes as the most problematic is a valuable hint for logistics managers, municipalities and academics. To improve knowledge-based city logistics, it is therefore necessary to focus on these processes and look for the best solutions and new forms of organisational and business support. The solution to the problems identified in the study is the proposal to create a city logistics collaborative knowledge base which is a combination of an IT tool ‐ the CL knowledge management platform, and the Freight Quality Partnership.

## Citation Details

Concept of the knowledge-based city logistics: Problems and solutions
**Authors**: Iwan, Wagner, Kijewska, Jensen
**Year**: 2024
**DOI**: 10.1371/journal.pone.0305563
**URL**: https://doi.org/10.1371/journal.pone.0305563

**Abstract**: Efficient city logistics is essential to build smart sustainable cities where inhabitants’ well-being is a priority. Meanwhile, despite the great importance of city logistics processes, their improvement is problematic for many cities. Although solutions from the field of emerging technologies are more and more often used, the question is whether implementing technological tools and filling cities with sensors is a sufficient solution that can solve the problems of intensely growing urban freight transport. The aim of the paper is to examine the role of knowledge management in city logistics and identify barriers to the implementation of knowledge-based city logistics. A key element of the research procedure was an expert survey, to which 31 international experts specialising in city logistics issues were invited, characterised by extensive experience working on research projects in the area of interest. Four knowledge management processes have been transferred to the city logistics area. The results of the study show that the difficulties are observed mainly in the processes of data gathering and knowledge acquisition. The main reason for difficulties in that area is the reluctance of city users, retailers, transport and logistics operators to share information. Identifying these processes as the most problematic is a valuable hint for logistics managers, municipalities and academics. To improve knowledge-based city logistics, it is therefore necessary to focus on these processes and look for the best solutions and new forms of organisational and business support. The solution to the problems identified in the study is the proposal to create a city logistics collaborative knowledge base which is a combination of an IT tool ‐ the CL k  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
