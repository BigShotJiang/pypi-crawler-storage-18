# Walter Georg Kühne (1911-1991) and the discovery of the first semi-articulated titanosaurian sauropod from Europe

**Authors:** Vila
**Year:** 2022
**DOI:** 10.1080/08912963.2022.2100771
**URL:** https://doi.org/10.1080/08912963.2022.2100771

## Abstract

ABSTRACT In 1954 Walter Georg Kühne (1911–1991), the renowned discoverer of Mesozoic mammals, explored the south-Pyrenean basins of Catalonia with the aim of finding Cretaceous mammal-bearing sites. As a result, the German palaeontologist discovered one of the most important dinosaur fossils in the history of dinosaur research in Spain. In the Tremp Basin, near Orcau village, he found the remains of a large sauropod dinosaur, but a series of incomprehensible vicissitudes made the find forgotten and its extraction incomplete for over 60 years. Unprecedented research into the history of this discovery, including unpublished documents, images, and field notes, has revealed details on the costs of the campaigns, the daily logistics, the field techniques, and the fossils unearthed in the 1954 and 1955 excavations. More importantly, this new research ascertains that Kühne had already determined that the dinosaur skeleton was articulated from the pelvic girdle onwards. Even without being published, that was a historically significant achievement as, back then, the new specimen became the first and semi-articulated titanosaurian sauropod found in Europe. Currently, the sauropod fossils found by Kühne in Orcau, together with additional appendicular and axial bones, are the holotype of Abditosaurus kuehnei.

## Citation Details

Walter Georg Kühne (1911-1991) and the discovery of the first semi-articulated titanosaurian sauropod from Europe
**Authors**: Vila
**Year**: 2022
**DOI**: 10.1080/08912963.2022.2100771
**URL**: https://doi.org/10.1080/08912963.2022.2100771

**Abstract**: ABSTRACT In 1954 Walter Georg Kühne (1911–1991), the renowned discoverer of Mesozoic mammals, explored the south-Pyrenean basins of Catalonia with the aim of finding Cretaceous mammal-bearing sites. As a result, the German palaeontologist discovered one of the most important dinosaur fossils in the history of dinosaur research in Spain. In the Tremp Basin, near Orcau village, he found the remains of a large sauropod dinosaur, but a series of incomprehensible vicissitudes made the find forgotten and its extraction incomplete for over 60 years. Unprecedented research into the history of this discovery, including unpublished documents, images, and field notes, has revealed details on the costs of the campaigns, the daily logistics, the field techniques, and the fossils unearthed in the 1954 and 1955 excavations. More importantly, this new research ascertains that Kühne had already determined that the dinosaur skeleton was articulated from the pelvic girdle onwards. Even without being published, that was a historically significant achievement as, back then, the new specimen became the first and semi-articulated titanosaurian sauropod found in Europe. Currently, the sauropod fossils found by Kühne in Orcau, together with additional appendicular and axial bones, are the holotype of Abditosaurus kuehnei.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
