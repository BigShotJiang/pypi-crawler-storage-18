# Planning and control in agri-food supply chains

**Authors:** Cramer, Transchel
**Year:** 2024
**DOI:** 10.19103/as.2023.0122.11
**URL:** https://doi.org/10.19103/as.2023.0122.11

## Abstract

In contrast to durable good supply chains, planning and control of agri-food supply chains are more challenging, e.g. due to perishable nature of the sensitivity of agri-food products. To provide managers with adequate decision-making support, it is crucial to understand the underlying planning processes along the entire supply chain. Recent events have shown that supply chain managers face various problems, from facilitating a transition to more sustainable food systems to securing food security by strengthening resilience. At the same time, an ever-growing population further exacerbates existing problems. This chapter explores the importance and complexity of planning processes in agri-food supply chains by briefly highlighting relevant building blocks for designing planning tools and by providing a comprehensive review on key planning elements, e.g. forecasting, production, and inventory planning. The primary focus is on planning and control activities based on techniques from operations management and quantitative methods from operations research and management science.

## Citation Details

Planning and control in agri-food supply chains
**Authors**: Cramer, Transchel
**Year**: 2024
**DOI**: 10.19103/as.2023.0122.11
**URL**: https://doi.org/10.19103/as.2023.0122.11

**Abstract**: In contrast to durable good supply chains, planning and control of agri-food supply chains are more challenging, e.g. due to perishable nature of the sensitivity of agri-food products. To provide managers with adequate decision-making support, it is crucial to understand the underlying planning processes along the entire supply chain. Recent events have shown that supply chain managers face various problems, from facilitating a transition to more sustainable food systems to securing food security by strengthening resilience. At the same time, an ever-growing population further exacerbates existing problems. This chapter explores the importance and complexity of planning processes in agri-food supply chains by briefly highlighting relevant building blocks for designing planning tools and by providing a comprehensive review on key planning elements, e.g. forecasting, production, and inventory planning. The primary focus is on planning and control activities based on techniques from operations management and quantitative methods from operations research and management science.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
