# German private medical school to reform in face of criticism

**Authors:** Tuffs
**Year:** 2005
**DOI:** 10.1136/BMJ.331.7511.254-D
**URL:** https://doi.org/10.1136/BMJ.331.7511.254-D

## Abstract

No abstract available in source

## Citation Details

German private medical school to reform in face of criticism
**Authors**: Tuffs
**Year**: 2005
**DOI**: 10.1136/BMJ.331.7511.254-D
**URL**: https://doi.org/10.1136/BMJ.331.7511.254-D  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
