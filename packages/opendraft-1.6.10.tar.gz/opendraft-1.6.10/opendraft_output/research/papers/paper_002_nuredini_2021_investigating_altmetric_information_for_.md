## Paper 2: Investigating Altmetric Information for the Top 1000 Journals from Handelsblatt Ranking in Economic and Business Studies
**Authors:** Nuredini, K.
**Year:** 2021
**Venue:** *Journal of Economic Surveys (implied by DOI prefix or context)*
**DOI:** [10.1111/joes.12414](https://doi.org/10.1111/joes.12414)
**Citations:** N/A

### Research Question
To what extent do social media and alternative metrics (Altmetrics) cover top-ranked journals in Economics and Business Studies, and how do these metrics correlate with traditional citations?

### Methodology
- **Design:** Bibliometric/Scientometric Analysis.
- **Data:** Top 1000 journals from the *Handelsblatt* ranking (Economics and Business Studies).
- **Timeframe:** Articles published between 2011–2018.
- **Variables:** Coverage in Mendeley and Altmetric.com; correlation with citation counts.

### Key Findings
1. **Coverage Rates:** The study found "moderate shares of articles" present in Mendeley (47%) and Altmetric.com (around 44%).
2. **Temporal Trends:** Altmetric information coverage was "significantly higher... for articles published between 2016 and 2017," indicating growing social media engagement with academic texts.
3. **Source Distribution:** The top 5 altmetric sources for these fields are "Twitter, News, Facebook, Blogs, and Policy documents."
4. **Correlation:** "Mendeley counts are positively correlated with citations both at the article and journal level," suggesting Mendeley readership is a valid early indicator of academic impact.

### Implications
For researchers in business and economics, this suggests that social media visibility (specifically Twitter and News) is increasingly linked to journal prestige (A+ and A journals). It validates the use of Mendeley readerships as a proxy for future citation impact.

### Limitations
- **Geographic Bias:** The study relies on the *Handelsblatt* ranking, which is "often used in German‐speaking countries," potentially biasing the journal selection toward European preferences.
- **Platform Volatility:** Reliance on Twitter (now X) data from 2011-2018 may not reflect current algorithmic landscapes.

### Relevance to Your Research
**Score:** ⭐⭐⭐ (3/5)
**Why:** While methodologically rigorous, this is a meta-research paper (research about research). It is useful for understanding *where* to publish or find high-impact business papers, but does not provide direct supply chain insights.

---