# Registries, research, and regrets: is the FDA’s post-marketing REMS process not adequately protecting patients?

**Authors:** Kachuck
**Year:** 2011
**DOI:** 10.1177/1756285611424461
**URL:** https://doi.org/10.1177/1756285611424461

## Abstract

No abstract available in source

## Citation Details

Registries, research, and regrets: is the FDA’s post-marketing REMS process not adequately protecting patients?
**Authors**: Kachuck
**Year**: 2011
**DOI**: 10.1177/1756285611424461
**URL**: https://doi.org/10.1177/1756285611424461  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
