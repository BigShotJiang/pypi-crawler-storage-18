# Robotic Process Automation to Increase Teaching Efficiency in Higher Education

**Authors:** Grunwald, Kawasaki, Hanke
**Year:** 2024
**DOI:** 10.52783/jes.2481
**URL:** https://doi.org/10.52783/jes.2481

## Abstract

Digitalization is advancing and changing our world, and with it the whole economy. Universities must meet this changing demand with new training offers. The AUFLADEN (Charging) project, funded by the Stiftung Innovation in der Hochschullehre, is developing new training formats for students involved in construction planning, predominantly students of architecture and civil engineering. One of the questions of the research project and the subject of this article is whether and how Robotic Process Automation (RPA) can be integrated into teaching as a learning tool to support students specifically and individually in learning software applications through automation. For this purpose, so-called self-learning knowledge Nuggets were developed. RPA makes it possible to have operating steps carried out computer-aided, a technology that is becoming popular to simplify recurring work processes. By slowing down this automation process, the user can study and imitate necessary steps. In a case study it is determined whether better learning results can be achieved by this training method. The results are that the learning speed increases and the teaching effort decreases. This encourages the use of automation technology to free teaching from method teaching and to use the precious teaching time for higher learning targets.

## Citation Details

Robotic Process Automation to Increase Teaching Efficiency in Higher Education
**Authors**: Grunwald, Kawasaki, Hanke
**Year**: 2024
**DOI**: 10.52783/jes.2481
**URL**: https://doi.org/10.52783/jes.2481

**Abstract**: Digitalization is advancing and changing our world, and with it the whole economy. Universities must meet this changing demand with new training offers. The AUFLADEN (Charging) project, funded by the Stiftung Innovation in der Hochschullehre, is developing new training formats for students involved in construction planning, predominantly students of architecture and civil engineering. One of the questions of the research project and the subject of this article is whether and how Robotic Process Automation (RPA) can be integrated into teaching as a learning tool to support students specifically and individually in learning software applications through automation. For this purpose, so-called self-learning knowledge Nuggets were developed. RPA makes it possible to have operating steps carried out computer-aided, a technology that is becoming popular to simplify recurring work processes. By slowing down this automation process, the user can study and imitate necessary steps. In a case study it is determined whether better learning results can be achieved by this training method. The results are that the learning speed increases and the teaching effort decreases. This encourages the use of automation technology to free teaching from method teaching and to use the precious teaching time for higher learning targets.  # Truncate if very long

---
*Extracted from citation research database - all 51 citations available*
