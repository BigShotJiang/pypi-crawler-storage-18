# Scout Output - Academic Citation Discovery

## Summary

**Total Valid Citations**: 51
**Success Rate**: 51.5%
**Failed Topics**: 3

### Sources Breakdown

- **Crossref**: 26 (51.0%)
- **Semantic Scholar**: 25 (49.0%)
- **Gemini Grounded**: 0 (0.0%)
- **Gemini LLM**: 0 (0.0%)

---

## Citations Found

### From Crossref (26 citations)

#### 1. Planning and control in agri-food supply chains
**Authors**: Cramer, Transchel
**Year**: 2024
**DOI**: 10.19103/as.2023.0122.11
**URL**: https://doi.org/10.19103/as.2023.0122.11

**Abstract**: In contrast to durable good supply chains, planning and control of agri-food supply chains are more challenging, e.g. due to perishable nature of the sensitivity of agri-food products. To provide managers with adequate decision-making support, it is crucial to understand the underlying planning processes along the entire supply chain. Recent events have shown that supply chain managers face various problems, from facilitating a transition to more sustainable food systems to securing food security by strengthening resilience. At the same time, an ever-growing population further exacerbates existing problems. This chapter explores the importance and complexity of planning processes in agri-food supply chains by briefly highlighting relevant building blocks for designing planning tools and by providing a comprehensive review on key planning elements, e.g. forecasting, production, and inventory planning. The primary focus is on planning and control activities based on techniques from operations management and quantitative methods from operations research and management science.

#### 2. Werkstoff Glas
**Authors**: Kühne
**Year**: 1976
**DOI**: 10.1515/9783112540961
**URL**: https://doi.org/10.1515/9783112540961

#### 3. Planning and control in agri-food supply chains
**Authors**: Cramer, Transchel
**Year**: 2024
**DOI**: 10.19103/as.2023.0122.11
**URL**: https://doi.org/10.19103/as.2023.0122.11

**Abstract**: In contrast to durable good supply chains, planning and control of agri-food supply chains are more challenging, e.g. due to perishable nature of the sensitivity of agri-food products. To provide managers with adequate decision-making support, it is crucial to understand the underlying planning processes along the entire supply chain. Recent events have shown that supply chain managers face various problems, from facilitating a transition to more sustainable food systems to securing food security by strengthening resilience. At the same time, an ever-growing population further exacerbates existing problems. This chapter explores the importance and complexity of planning processes in agri-food supply chains by briefly highlighting relevant building blocks for designing planning tools and by providing a comprehensive review on key planning elements, e.g. forecasting, production, and inventory planning. The primary focus is on planning and control activities based on techniques from operations management and quantitative methods from operations research and management science.

#### 4. HAMBURG: Palaeontological Collections of the Center of Natural History, Universität Hamburg
**Authors**: Kotthoff, Schlüter
**Year**: 2018
**DOI**: 10.1007/978-3-319-77401-5_27
**URL**: https://doi.org/10.1007/978-3-319-77401-5_27

#### 5. Childish Citizenship
**Authors**: O’Donnell
**Year**: 2019
**DOI**: 10.1007/978-3-319-97502-3_19
**URL**: https://doi.org/10.1007/978-3-319-97502-3_19

#### 6. ENCSR343RCX
**Authors**: White
**Year**: 2022
**DOI**: 10.17989/encsr343rcx
**URL**: https://doi.org/10.17989/encsr343rcx

#### 7. ROLE OF BRAND LEADERSHIP ON BRAND MANAGEMENT
      PRACTICES - A STUDY ON HERO MOTOCORP
**Authors**: SAHYAJA, K. S. SEKHARA
**Year**: 2018
**DOI**: 10.26634/jmgt.13.2.14447
**URL**: https://doi.org/10.26634/jmgt.13.2.14447

#### 8. INVESTIGATING ALTMETRIC INFORMATION FOR THE TOP 1000 JOURNALS FROM HANDELSBLATT RANKING IN ECONOMIC AND BUSINESS STUDIES
**Authors**: Nuredini
**Year**: 2021
**DOI**: 10.1111/joes.12414
**URL**: https://doi.org/10.1111/joes.12414

**Abstract**: AbstractIn this study, the top 1000 journals from Handelsblatt ranking (often used in German‐speaking countries) in Economics (E) and Business Studies (BS) as an extension of the two previous studies from Nuredini and Peters are explored. Moderate shares of articles from E and BS journals for publication years 2011–2018 are found in Mendeley (47%) and Altmetric.com (around 44%). This study shows that altmetric information is significantly higher in coverage for articles published between 2016 and 2017. The top 5 most used altmetric sources for E and BS journals are Twitter, News, Facebook, Blogs, and Policy documents. Top highly ranked journals (with classes A+ and A) in E from Handelsblatt ranking are highly mentioned in Altmetric.com, making them also popular in social media platforms (i.e., attention sources). Mendeley counts are positively correlated with citations both at the article and journal level.

#### 9. Planning and control in agri-food supply chains
**Authors**: Cramer, Transchel
**Year**: 2024
**DOI**: 10.19103/as.2023.0122.11
**URL**: https://doi.org/10.19103/as.2023.0122.11

**Abstract**: In contrast to durable good supply chains, planning and control of agri-food supply chains are more challenging, e.g. due to perishable nature of the sensitivity of agri-food products. To provide managers with adequate decision-making support, it is crucial to understand the underlying planning processes along the entire supply chain. Recent events have shown that supply chain managers face various problems, from facilitating a transition to more sustainable food systems to securing food security by strengthening resilience. At the same time, an ever-growing population further exacerbates existing problems. This chapter explores the importance and complexity of planning processes in agri-food supply chains by briefly highlighting relevant building blocks for designing planning tools and by providing a comprehensive review on key planning elements, e.g. forecasting, production, and inventory planning. The primary focus is on planning and control activities based on techniques from operations management and quantitative methods from operations research and management science.

#### 10. Danang – Development Of Green And Sustainable Logistics Center
**Authors**: Tran, Nguyen
**Year**: 2018
**DOI**: 10.18411/lj-07-2018-41
**URL**: https://doi.org/10.18411/lj-07-2018-41

#### 11. ИСТОРИЯ И АКТУАЛЬНОСТЬ КООПЕРАТИВНОЙ ИДЕИ В ГАМБУРГЕ
**Authors**: Bösche, Tikhonovich, Tikhonovich
**Year**: 2019
**DOI**: 10.21295/2223-5639-2019-3-285-303
**URL**: https://doi.org/10.21295/2223-5639-2019-3-285-303

#### 12. Optimal Sensor Placement with Minimal Predicted Posterior Variance
**Authors**: Mendler, Marsili, Kessler, Grosse
**Year**: 2024
**DOI**: 10.58286/29612
**URL**: https://doi.org/10.58286/29612

**Abstract**: The performance of each monitoring system critically depends on the sensor layout and typical optimization criteria are based on the accessibility to the structure on site, experience with similar structures, and an optimal signal-to-noise ratio. More advanced criteria aim to optimize the feature extraction process, and this paper aims to develop a sensor placement strategy for optimal damage diagnosis. The approach is based on Bayesian updating and the optimization goal is to find a sensor layout that is the most sensitive to small changes in the examined system parameters. It is shown that such layouts manifest themselves through a minimum variance in the posterior distribution. Using Kalman filters, the posterior variance can be “predicted” based on the measurement error and numerical models, so no data from and no simulations in the damaged state are required. By employing a polynomial chaos expansion (PCE)-based Kalman filter, the method becomes applicable for structures with many measurement channels, multiple examined system parameters, and for a large number of sensor combinations. Gaussian distributions are assumed for both system inputs and outputs. For proof of concept, the sensor placement is optimized on a numerical cantilever beam, demonstrating that the method can efficiently find the optimal sensor layout. Moreover, arbitrary measurement quantities (inclinations, vibrations, etc.) or damage-sensitive features (statistical values, modal parameters, etc.) can be used as observations, and multiple system parameters can be considered at the same time. Among other factors, an optimal sensor layout leads to large measurement responses, a small measurement error, and more advanced statistical quantities that will be elaborated on in detail.

#### 13. Technical evolution of a convertible pool roof on three expedition cruise ships for the shipping company Hapag Lloyd
**Authors**: Hub, Rein
**Year**: 2023
**DOI**: 10.23967/c.membranes.2023.055
**URL**: https://doi.org/10.23967/c.membranes.2023.055

#### 14. The Operation and Service Performance of Global Logistics Center in Tawan
**Authors**: CHIU Rong-her
**Year**: 2008
**DOI**: 10.37059/tjosal.2008..57.177
**URL**: https://doi.org/10.37059/tjosal.2008..57.177

#### 15. The Private University and the Private Sector in Higher Education: A Spanish Perspective
**Authors**: Hochleitner
**Year**: 1990
**DOI**: 10.1057/hep.1990.24
**URL**: https://doi.org/10.1057/hep.1990.24

#### 16. ENCSR343RCX
**Authors**: White
**Year**: 2022
**DOI**: 10.17989/encsr343rcx
**URL**: https://doi.org/10.17989/encsr343rcx

#### 17. ENCSR343RCX
**Authors**: White
**Year**: 2022
**DOI**: 10.17989/encsr343rcx
**URL**: https://doi.org/10.17989/encsr343rcx

#### 18. Seeing Between the Pixels
**Authors**: Strothotte, Strothotte
**Year**: 1997
**DOI**: 10.1007/978-3-642-60361-7
**URL**: https://doi.org/10.1007/978-3-642-60361-7

#### 19. ENCSR343RCX
**Authors**: White
**Year**: 2022
**DOI**: 10.17989/encsr343rcx
**URL**: https://doi.org/10.17989/encsr343rcx

#### 20. Germany
**Authors**: Kehm
**Year**: 2017
**DOI**: 10.4324/9781315537412-7
**URL**: https://doi.org/10.4324/9781315537412-7

#### 21. ENCSR343RCX
**Authors**: White
**Year**: 2022
**DOI**: 10.17989/encsr343rcx
**URL**: https://doi.org/10.17989/encsr343rcx

#### 22. Strategische Vereinsentwicklung am Beispiel der Bundesvereinigung Logistik
**Authors**: Klinkner, Wimmer
**Year**: 2010
**DOI**: 10.1007/978-3-8349-6515-8_38
**URL**: https://doi.org/10.1007/978-3-8349-6515-8_38

#### 23. Development of a Concept for Inner-City Delivery &amp; Supply Utilising Electromobility
**Authors**: Schaumann
**Year**: 2013
**DOI**: 10.1007/978-3-642-32838-1_14
**URL**: https://doi.org/10.1007/978-3-642-32838-1_14

#### 24. EVOLUTION OF AN INTEGRATED, PROJECT-BASED LOGISTICS ENGINEERING CURRICULUM
**Authors**: Pasek, Pawlewski
**Year**: 2019
**DOI**: 10.24908/pceea.vi0.13790
**URL**: https://doi.org/10.24908/pceea.vi0.13790

**Abstract**: This paper describes the evolution of content and teaching practices of an innovative undergraduate curriculum developed for a new Logistics Engineering degree program. Originally proposed and implemented in 2010, the bi-level curriculum follows European directives and complies with the Bologna Process. Over the years the content and teaching practices were continuously reviewed and modified to stay in sync with teaching practices of design and entrepreneurship, progress simulation technologies, and student responses.&#x0D;
Since the initial introduction of the curriculum many advances in various relevant areas have taken place and consequently the content of the curriculum had to be updated. For example, Lean Startup Method using Business Model Canvas has replaced business plans in teaching entrepreneurship. Similarly, as general softwarebased simulation tools have grown in complexity, teaching them requires more time and becomes time-impractical. A simpler approach based on limited-instruction tools tailored for product assembly, but built on these general simulation platforms, offers a more effective practical solution.&#x0D;

#### 25. Bürogebäude am Sandtorpark, HafenCity, Hamburg, Deutschland / Sandtorpark Office Building, HafenCity, Hamburg, Germany
**Authors**: Walden
**Year**: 2016
**DOI**: 10.1515/9783990431344-021
**URL**: https://doi.org/10.1515/9783990431344-021

#### 26. Blockchain Driven Supply Chain Management
**Authors**: Kayιkcι
**Year**: 2020
**DOI**: 10.1201/9780429327636-16
**URL**: https://doi.org/10.1201/9780429327636-16

### From Semantic Scholar (25 citations)

#### 1. Walter Georg Kühne (1911-1991) and the discovery of the first semi-articulated titanosaurian sauropod from Europe
**Authors**: Vila
**Year**: 2022
**DOI**: 10.1080/08912963.2022.2100771
**URL**: https://doi.org/10.1080/08912963.2022.2100771

**Abstract**: ABSTRACT In 1954 Walter Georg Kühne (1911–1991), the renowned discoverer of Mesozoic mammals, explored the south-Pyrenean basins of Catalonia with the aim of finding Cretaceous mammal-bearing sites. As a result, the German palaeontologist discovered one of the most important dinosaur fossils in the history of dinosaur research in Spain. In the Tremp Basin, near Orcau village, he found the remains of a large sauropod dinosaur, but a series of incomprehensible vicissitudes made the find forgotten and its extraction incomplete for over 60 years. Unprecedented research into the history of this discovery, including unpublished documents, images, and field notes, has revealed details on the costs of the campaigns, the daily logistics, the field techniques, and the fossils unearthed in the 1954 and 1955 excavations. More importantly, this new research ascertains that Kühne had already determined that the dinosaur skeleton was articulated from the pelvic girdle onwards. Even without being published, that was a historically significant achievement as, back then, the new specimen became the first and semi-articulated titanosaurian sauropod found in Europe. Currently, the sauropod fossils found by Kühne in Orcau, together with additional appendicular and axial bones, are the holotype of Abditosaurus kuehnei.

#### 2. Robotic Process Automation to Increase Teaching Efficiency in Higher Education
**Authors**: Grunwald, Kawasaki, Hanke
**Year**: 2024
**DOI**: 10.52783/jes.2481
**URL**: https://doi.org/10.52783/jes.2481

**Abstract**: Digitalization is advancing and changing our world, and with it the whole economy. Universities must meet this changing demand with new training offers. The AUFLADEN (Charging) project, funded by the Stiftung Innovation in der Hochschullehre, is developing new training formats for students involved in construction planning, predominantly students of architecture and civil engineering. One of the questions of the research project and the subject of this article is whether and how Robotic Process Automation (RPA) can be integrated into teaching as a learning tool to support students specifically and individually in learning software applications through automation. For this purpose, so-called self-learning knowledge Nuggets were developed. RPA makes it possible to have operating steps carried out computer-aided, a technology that is becoming popular to simplify recurring work processes. By slowing down this automation process, the user can study and imitate necessary steps. In a case study it is determined whether better learning results can be achieved by this training method. The results are that the learning speed increases and the teaching effort decreases. This encourages the use of automation technology to free teaching from method teaching and to use the precious teaching time for higher learning targets.

#### 3. German private medical school to reform in face of criticism
**Authors**: Tuffs
**Year**: 2005
**DOI**: 10.1136/BMJ.331.7511.254-D
**URL**: https://doi.org/10.1136/BMJ.331.7511.254-D

#### 4. THE SIXTEENTH CENTURY
**Authors**: Kottmann, Grabner-Haider, Davidowicz, Prenner, Müller, Müller
**Year**: 2016
**DOI**: 10.2307/j.ctv1rmj8d.10
**URL**: https://doi.org/10.2307/j.ctv1rmj8d.10

#### 5. Think the link. Hamburg 2030 - Urban Futures. Reflections on urban regeneration processes and documentation of the second Baltic International Summer School 2016 at HafenCity University Hamburg
**Authors**: Bögle, Gieron, Kasting, Seggern, Peselyte-schneider, Popova
**Year**: 2018
**DOI**: 
**URL**: https://www.semanticscholar.org/paper/6f8fe91987f973acb2ed5c8515e23e6b9bd7727f

#### 6. The influence of publication ranking specifications on publication strategy and academic careers in business administration
**Authors**: Reichmann, Schlögl, Sommersguter-Reichmann
**Year**: 2025
**DOI**: 10.1371/journal.pone.0336492
**URL**: https://doi.org/10.1371/journal.pone.0336492

**Abstract**: This study examines the impact of methodological variations in publication-based rankings on the evaluation of individual research performance in business administration. Drawing on a unique dataset comprising complete personal publication lists of 233 professors from Austrian public universities (2009–2018), we apply ten distinct ranking variants that differ in their treatment of data sources, co-authorship, publication languages, article lengths, and journal qualities. These variants are categorized into purely quantity-focused and predominantly quality-focused rankings. Our results demonstrate that researcher rankings are susceptible to specification choices. While quantity-focused rankings produce relatively small performance differentials and high variability, quality-focused variants consistently identify a stable group of leading researchers. These scholars publish more frequently in English, in journals indexed by Web of Science (WoS), and in top-tier outlets according to the JOURQUAL ranking. Notably, leading researchers publish over twice as many articles in high-ranking journals as their peers. The findings underscore the significant implications of ranking design for career advancement and research strategy. For early-career researchers, aligning publication efforts with the logic of quality-focused rankings—favoring English-language publications in highly ranked, peer-reviewed journals—is crucial for enhancing academic visibility and competitiveness. Moreover, our study offers a methodological stress test for ranking systems, revealing the extent to which technical design influences outcomes. By leveraging comprehensive and multilingual publication data and systematically comparing multiple ranking methodologies, this study contributes to both the academic evaluation literature and practical guidance for researchers navigating the demands of a metric-driven academic environment.

#### 7. Development Possibilities of the High-tech Logistics Laboratory Established at the Institute of Logistics of the University of Miskolc
**Authors**: Tamás, Bányai, Illés, Tollár, Veres, Cservenák, Hardai, Skapinyecz
**Year**: 2020
**DOI**: 10.9734/jerr/2020/v13i317127
**URL**: https://doi.org/10.9734/jerr/2020/v13i317127

**Abstract**: The Institute of Logistics of the University of Miskolc started training logistics in Hungarian higher education for the first time in the early 1990s. In recent decades, the training structure and laboratory infrastructure of the institute have changed significantly, relying on the relevant educational and research connections in Germany. The publication presents one of the institute's laboratories, the High-tech Integrated Logistics Laboratory, which contains a number of material handling equipment (pallet handling cell, AGV, automated warehousing system, etc.), which provides an opportunity for fulfillment of high-quality teaching and research tasks. In addition to a brief presentation of the laboratory, the researchers present their future ideas about the laboratory in different areas of development, which can also serve as a useful guide for other professionals involved in logistics education and research. Review Article Tamás et al.; JERR, 13(3): 60-68, 2020; Article no.JERR.58102 61

#### 8. P-Rank 2021 - The top 1000 contributors, the top 1000 collaborators, and the top 250 individuals in business research
**Authors**: Goel
**Year**: 2021
**DOI**: 10.2139/ssrn.3758801
**URL**: https://doi.org/10.2139/ssrn.3758801

**Abstract**: This document presents various rankings of publication output of scholars in the field of business studies. The rankings are based on the ABDC Journal Quality List, the CABS Academic Journal Guide, the ERIM Journal List, the list of the Handelsblatt BWL Ranking, the Hceres liste des revues, Scimago Journal Ranks, and the VHB Jourqual 3 list. Different metrics are used to account for different ways to assess co-authored publications.

#### 9. Main topic : “ ASSESSING FUNCTION IN GLAUCOMA ” Glaucoma
**Authors**: Bowd
**Year**: 2018
**DOI**: 
**URL**: https://www.semanticscholar.org/paper/1e0cb7626842937bdd99c8a08884743387a1d325

#### 10. Annual report 2015
**Authors**: Mienert
**Year**: 2015
**DOI**: 10.1007/s12402-016-0192-7
**URL**: https://doi.org/10.1007/s12402-016-0192-7

#### 11. Decentralization of Corruption in the Education Sector: An Analysis of Anti- Graft Reports
**Authors**: Budhathoki
**Year**: 2022
**DOI**: 10.3126/mef.v12i01.45938
**URL**: https://doi.org/10.3126/mef.v12i01.45938

**Abstract**: The Commission for the Investigation of Abuse of Authority (CIAA) annual report points out that complaints related to the education sector for financial misuses occupy the largest share consistently in the past few years. In this context, the paper aims to draw on types and patterns of educational corruption in Nepal in the context of education decentralization since 2000. Further, it interprets how it takes place and its associated factors. Undertaking the qualitative content analysis of annual reports of CIAA and Office of the Auditor General (OAG) of Nepal between 2010 and 2015, this article portrays financial irregularities taking place consistently under construction work, teacher salary, and student-related grants - showing or allocating more funds, releasing additional teacher salary and inflating student numbers. The existing literature on education decentralization and corruption entails various factors for financial mismanagement - lack of local capacity, elite capture of public funds, etc. Using education decentralization as a theoretical lens (Mc Ginn & Welsh, 1999), this paper argues that poor monitoring and lack of policy implementation are major factors for the misuse of education finance in Nepal, coupled with complex procedural aspects of the public fund flow system. Thus, an adequate support system, especially during the early phase, can facilitate the decentralization of education and combat corruption.

#### 12. AfDB Group Annual Report 2011
**Authors**: AfDB
**Year**: 2011
**DOI**: 
**URL**: https://www.semanticscholar.org/paper/5e09fa28704f006066b948f90f187e1d285885e1

#### 13. Annual Report 2020
**Authors**: Andreassen
**Year**: 2020
**DOI**: 10.30875/4a0b4159-en
**URL**: https://doi.org/10.30875/4a0b4159-en

**Abstract**: <jats:p xml:lang="fr" />

#### 14. Understanding issues of ‘justice’ in ‘free higher education’: policy, legislation, and implications in the Philippines
**Authors**: Lomer, Lim
**Year**: 2021
**DOI**: 10.1080/23322969.2021.2012242
**URL**: https://doi.org/10.1080/23322969.2021.2012242

**Abstract**: ABSTRACT In the context of global debates regarding the purpose of higher education, many national governments have adopted ‘cost-sharing’ mechanisms. Yet in 2017 the Philippines introduced legislation to provide ‘Universal Access’ to higher education by subsidizing tuition fees for all Filipino students in public institutions, partial fee subsidies students in private institutions, and further means-tested support. This article uses a conceptual framework integrating multiple models of social justice to examine 73 legislative texts: 59 individual House of Representative bills, 11 individual Senate bills, the cumulative House and Senate bill, and the final Republic Act. We develop an innovative methodology for analysing legislation that incorporates both structured content and reflexive thematic analysis. The findings show a striking consensus on representing access to HE as a social justice issue, but concepts of procedural fairness varied. Economic rationales intersected with justice narratives, positioning universal tuition as ensuring equal access to income, fostering ‘inclusive growth’ for national development that includes the private sector. The Philippines offers an instructive case for other liberal democracies where ‘who pays’ for higher education remains politically divisive. Our analysis suggests that legislators achieved consensus w by situating social justice as compatible with marketised, neo-liberal paradigms of higher education.

#### 15. The Oxford companion to the economics of South Africa
**Authors**: Bhorat, Hirsch, Kanbur, Ncube
**Year**: 2014
**DOI**: 10.1093/ACPROF:OSO/9780199689248.001.0001
**URL**: https://doi.org/10.1093/ACPROF:OSO/9780199689248.001.0001

#### 16. 8th IAS Conference on HIV Pathogenesis, Treatment & Prevention 19–22 July 2015, Vancouver, Canada
**Authors**: Pate, Pohlmeyer, Walker-Sperling, Foote, Najarro, Cryer, Salgado, Gama, Engle, Shirk, Queen, Chioma, Vermillion, Bullock, Li, Lyons, Adams, Zink, Clements, Mankowski, Blankson, Micci, Ryan, Fromentin, Benne, Chomont, Lifson, Paiardini, Lee, Chomont, Fromentin, Silicano, Silicano, Richman, O’Doherty, Palmer, Burbelo, Deeks, Ghneim, Ahlers, Fourati, Shive, Cameron, Mukerjee, Ghannoum, Rodriguez, Lederman, Sékaly, Frange, Faye, Avettand-Fenoel, Bellaton, Deschamps, Angin, Caillat-Zucman, Peytavin, Chenadec, Warszawski, Rouzioux, Sáez-Cirión, Chang, Cameron, Elliott, Perelson, Roche, Dantanarayana, Solomon, Naranbhai, Tenakoon, Hoh, McMahon, Sikaris, Hartogensis, Bacchetti, Hecht, Lifson, Deeks, Lewin, Byrareddy, Arthos, Cicala, Reimann, Parslow, Santangelo, Villinger, Fauci, Ansari, George, Weiser, Burger, Lewy, Anastos, Asmuth, Somsouk, Hunt, Ma, Miller, Li, Hinkle, Shaw, Weaver, Klein, Viljoen, Wendoh, Karaoz, Brodie, Mulder, Botha, Kidzeru, Butcher, Gray, Rosenthal, Abimiku, Cameron, Stintzi, Jaspan, Schafer, Evans, Li, Reeves, Kroon, Dunning, Hsiao, Myer, Crowell, Maiga, Sylla, Taiwo, Koné, Murphy, Marcelin, Traore, Fofana, Chadwick, Ásbjörnsdóttir, Slyker, Wamalwa, Rosa, Hughes, Rowhani-Rahbar, Chohan, Benki-Nugent, Tapia, John-Stewart, Kizito, Gaur, Prasitsuebsai, Rakhmanina, Chokephaibulkit, Fourie, Bekker, Shao, Bennett, Quirk, Prasitsuebsai, Teeraananchai, Truong, Ananworanich, Do, Nguyen, Kosalaraksa, Kurniati, Sudjaritruk, Chokephaibulkit, Singtoroj, Kerr, Sohn, Lombaard, Bunupuradah, Flynn, Ramapuram, Ssali, Crauwels, Hoogstoel, Eygen, Stevens, Boven, Jao, Myer, Phillips, Petro, Zerbe, Abrams, Hanrahan, Martinson, Link‐Barnes, Msandiwa, Chaisson, Golub, Evans, Schnippel, Budgell, Shearer, Berhanu, Long, Rosen, Schultze, Efsen, Post, Panteleev, Furrer, Miller, Losso, Toibaro, Skrahin, Miro, Caylà, Girardi, Bruyand, Obel, Podlekareva, Lundgren, Mocroft, Kirk, Baddeley, Doherty, Kanchar, Matteelli, Timimi, Getahun, Hosseinipour, Bisson, Miyahara, Sun, Moses, Riviere, Kirui, Badal-Faesen, Lagat, Nyirenda, Naidoo, Hakim, Mugyenyi, Henostroza, Leger, Lama, Mohapi, Alave, Mave, Veloso, Pillay, Kumarasamy, Bao, Hogg, Jones, Zolopa, Kumwenda, Gupta, Cohen, Chen, McCauley, Gamble, Hosseinipour, Kumarasamy, Hakim, Kumwenda, Brum, Grinsztejn, Godbole, Chariyalertsak, Santos, Mayer, Hoffman, Eshleman, Piwowar-Manning, Ou, Cottle, Makhema, Mills, Panchia, Badal-Faesen, Eron, Gallant, Havlir, Swindells, Elharrar, Burns, Taha, Nielsen, Celentano, Essex, Fleming, Jean, Puren, Cutler, Singh, Bouscaillou, Rain-Taljaard, Taljjard, Lissouba, Peytavin, Auvert, Jenkins, Nordio, Vasarhelyi, Núñez, Barrios, Rutherford, Iwuji, Dray-Spira, Calmy, Larmarange, Orne-Gliemann, Dabis, Pillay, Porter, Barnabas, Rooyen, Tumwesigye, Brantley, Baeten, Heerden, Turyamureeba, Joseph, Krows, Hughes, Celum, Eshleman, Hudelson, Ou, Redd, Swanstrom, Porcella, Chen, McCauley, Gamble, Sievers, Martens, Bruno, Ping, Dukhovlinova, Quinn, Kumwenda, Maliwichi, Nhando, Akelo, Moyo, Panchia, Kumarasamy, Chotirosniramit, Rocha, Bustorff, Grinsztejn, Mayer, Hughes, Cohen, Haas, Tenthani, Msukwa, Jahn, Midiani, Mhango, Gadabu, Tal, Spörri, Egger, Chimbwandira, Oosterhout, Keiser, Rosenberg, Mtande, Saidi, Stanley, Jere, Mwangomba, Kumwenda, Mofolo, Mwale, Chauma, Miller, Hoffman, Hosseinipour, Buzdugan, McCoy, Watadzaushe, Dufour, Petersen, Dirawo, Mushavi, Mujuru, Mahomva, Engelsmann, Hakobyan, Mugurungi, Cowan, Padian, Lallemant, Amzal, Urien, Sripan, Cressey, Ngo-Giang-Huong, Rawangban, Sabsanong, Siriwachirachai, Jarupanich, Kanjanavikai, Wanasiri, Koetsawang, Jourdain, Cœur, Ochoa‐Moreno, Mangenah, Buzdugan, Padian, McCoy, Cowan, Bautista-Arredondo, Wambura, Hayes, Grund, Kapiga, Mahler, Mshana, Kuringe, Plotkin, Bock, Larke, Changalucha, Weiss, Thirumurthy, Akello, Murray, Masters, Maman, Omanga, Agot, Duwve, Hoover, Conrad, Galang, Hillman, Hoots, Patel, Peters, Pontones, Roseberry, Shields, Waterhouse, Weidle, Galang, Gentry, Peters, Blosser, Chapman, Duwve, Ganova-Raeva, Heneine, Jia, Liu, Luo, Lovchik, Masciotra, Owen, Perez, Peyrani, Ramachandran, Roseberry, Sandoval, Shankar, Thai, Xia, Khudyakov, Switzer, Mannheimer, Hirsch-Moverman, Loquere, Franks, Hughes, Amico, Hendrix, Dye, Piwowar-Manning, Marzinke, Elharrar, Stirratt, Grant, Holtz, Chitwarakorn, Curlin, Anderson, Eshleman, Grant, Doherty, Beusenberg, Asamoah-odei, Lule, Pendse, Ghidinelli, Lo, Reidner, Donoghoe, Vitoria, Hirnschall, Levi, Raymond, Pozniak, Vernazza, Kohler, Ford
**Year**: 2015
**DOI**: 10.7448/IAS.18.5.20479
**URL**: https://doi.org/10.7448/IAS.18.5.20479

**Abstract**: Sensitive assays are needed for detection of residual HIV in patients with undetectable plasma viral loads to determine if eradication strategies are effective. The gold standard quantitative viral outgrowth assay (QVOA) underestimates the magnitude of the viral reservoir, while sensitive PCR‐based assays lack the ability to distinguish replication competent from defective virus. We sought to determine whether xenograft of leukocytes from HIV‐1 infected patients with undetectable plasma viral loads into severely immunocompromised mice would result in viral amplification and measurable viral loads within the aberrant murine host.

#### 17. COMPARATIVE ANALYSIS OF FUNDING OF UNIVERSITY EDUCATION IN EU COUNTRIES
**Authors**: Greben, Parashchenko, Salii
**Year**: 2024
**DOI**: 10.36690/2674-5216-2024-1-28
**URL**: https://doi.org/10.36690/2674-5216-2024-1-28

**Abstract**: This paper conducts a comparative analysis of the funding models for university education in the European Union (EU), focusing on government, private, and alternative funding sources. Purpose of the study is to analyze and compare the different funding models for university education in the EU and evaluate their efficacy. The basis of the study was the scientific works of researchers from different countries of the world and the OECD report, which presents the features of public, private and alternative financing of higher education. The main methods used in the article are methods of analysis and synthesis, comparative analysis and generalization. The analysis examines how these funding models impact accessibility, quality, and sustainability of higher education across different EU member states, including Germany, Sweden, the United Kingdom (pre-Brexit), and Italy. Through a review of existing literature and an evaluation of different funding mechanisms, the study identifies key trends and outcomes associated with each funding type. The paper also explores how European integration and policies influence these funding mechanisms. By comparing models across various countries, this analysis aims to highlight best practices and recommend policy enhancements to harmonize educational opportunities and meet future economic and social demands. The study recommends that EU countries consider a balanced approach to funding that combines the strengths of government support, private investment, and innovative funding mechanisms. This approach should aim to ensure equitable access to high-quality education while fostering financial sustainability and adaptability to changing economic conditions. Further, the paper suggests that ongoing evaluation and adaptation of funding models are essential to address the evolving needs of students and the broader socio-economic landscape. These findings and recommendations contribute to a deeper understanding of the complexities and dynamics of funding university education in the EU, providing a foundation for policymakers to enhance the effectiveness and fairness of higher education systems across Europe.

#### 18. From Geographic Advantage to Strategic Hub: Georgia’s Role in International Logistics
**Authors**: Kontselidze
**Year**: 2025
**DOI**: 10.26881/jpgs.2025.4.01
**URL**: https://doi.org/10.26881/jpgs.2025.4.01

**Abstract**: Thepurpose of the presented study is to analyze the strategic advantages of Georgia’s geographical location and the transport and logistics potential of the country, which can become one of the main drivers of the country’s economic growth. The scientific novelty of the work lies in the fact that it considers Georgia as one of the important links between Europe and Asia in the context of the modern Silk Road, which is based on both geographical factors and the political and economic environment. The emphasis is on the prospects for the country’s development as an intermodal logistics hub and on the opportunities that may become tangible through the implementation of the right infrastructural, educational and strategic policies. In addition, the work draws attention to the contradictions associated with monopoly structures, technological backwardness and institutional failures. The study revealed that Georgia’s geographical location, access to Black Sea ports, and stable relations with neighboring countries create a solid foundation for the country to use its transit potential and develop into a regional logistics hub. To do this, it is necessary to systematically upgrade transport infrastructure, attract investments, strengthen logistics education, and introduce technological systems. Effective logistics will not only promote economic growth and competitiveness but also significantly reduce trade costs and increase the country’s investment attractiveness. As a result of strategically planned reforms, Georgia can occupy a central place in the Eurasian trade space, which will significantly strengthen its economic and political position in the region in the long term.

#### 19. Europe paying a heavy price for chronic diseases, finds new OECD-European Commission report
**Authors**: Price
**Year**: 2017
**DOI**: 10.1136/EJHPHARM-2017-001227
**URL**: https://doi.org/10.1136/EJHPHARM-2017-001227

#### 20. Extending and understanding: an application of machine learning to the World Bank's logistics performance index
**Authors**: Shepherd, Sriklay
**Year**: 2023
**DOI**: 10.1108/ijpdlm-06-2022-0180
**URL**: https://doi.org/10.1108/ijpdlm-06-2022-0180

**Abstract**: PurposeThe authors extend the World Bank's Logistics Performance Index (LPI) for 30 additional countries and 13 additional years. The authors develop an inexpensive method for extending survey data when frequent, universal surveys are unavailable. The authors identify groups of country characteristics that influence LPI scores.Design/methodology/approachUsing data from the World Development Indicators—the broadest global dataset of country socioeconomic features—the authors test machine learning algorithms for their ability to predict the LPI. The authors examine importance scores to identify factors that influence LPI scores.FindingsThe best performing algorithm produces predictions on unseen data that account for nearly 90% of observed variation, and are accurate to within 6%. It performs twice as well as an OLS model with per capita income as the only predictor. Explanatory factors are business environment, economic structure, finance, environment, human development, and institutional quality.Practical implicationsMachine learning offers a simple, inexpensive way of extending the coverage of survey data. This dataset provides a richer picture of logistics performance around the world. The factors the authors identify as predicting higher LPI scores can help policymakers and practitioners target interventions.Originality/valueThis paper is one of the first applications of machine learning to extend coverage of an index based on an international survey. The authors use the new data to provide the most wide-ranging analysis of logistics performance across countries and over time. The output is an important resource for policymakers tracking performance, and researchers particularly in smaller and lower income countries. The authors also examine a wider range of explanatory factors for LPI scores than previous work.

#### 21. Registries, research, and regrets: is the FDA’s post-marketing REMS process not adequately protecting patients?
**Authors**: Kachuck
**Year**: 2011
**DOI**: 10.1177/1756285611424461
**URL**: https://doi.org/10.1177/1756285611424461

#### 22. Concept of the knowledge-based city logistics: Problems and solutions
**Authors**: Iwan, Wagner, Kijewska, Jensen
**Year**: 2024
**DOI**: 10.1371/journal.pone.0305563
**URL**: https://doi.org/10.1371/journal.pone.0305563

**Abstract**: Efficient city logistics is essential to build smart sustainable cities where inhabitants’ well-being is a priority. Meanwhile, despite the great importance of city logistics processes, their improvement is problematic for many cities. Although solutions from the field of emerging technologies are more and more often used, the question is whether implementing technological tools and filling cities with sensors is a sufficient solution that can solve the problems of intensely growing urban freight transport. The aim of the paper is to examine the role of knowledge management in city logistics and identify barriers to the implementation of knowledge-based city logistics. A key element of the research procedure was an expert survey, to which 31 international experts specialising in city logistics issues were invited, characterised by extensive experience working on research projects in the area of interest. Four knowledge management processes have been transferred to the city logistics area. The results of the study show that the difficulties are observed mainly in the processes of data gathering and knowledge acquisition. The main reason for difficulties in that area is the reluctance of city users, retailers, transport and logistics operators to share information. Identifying these processes as the most problematic is a valuable hint for logistics managers, municipalities and academics. To improve knowledge-based city logistics, it is therefore necessary to focus on these processes and look for the best solutions and new forms of organisational and business support. The solution to the problems identified in the study is the proposal to create a city logistics collaborative knowledge base which is a combination of an IT tool ‐ the CL knowledge management platform, and the Freight Quality Partnership.

#### 23. RETROSPECTIVE STUDY ON THE ITERATIVE METHODS OF ARCHITECTURAL VISUALIZATION FROM THE NEOLITHIC TO THE DIGITAL BUILDING INFORMATION MODEL
**Authors**: Stange, HafenCity
**Year**: 2021
**DOI**: 
**URL**: https://www.semanticscholar.org/paper/073047c6095ae8fcd9dd4b5ccc3d0e058c5b10e5

#### 24. Outlier-Robust Long-Term Robotic Mapping Leveraging Ground Segmentation
**Authors**: Lim
**Year**: 2024
**DOI**: 10.48550/arXiv.2405.11176
**URL**: https://doi.org/10.48550/arXiv.2405.11176

**Abstract**: Despite the remarkable advancements in deep learning-based perception technologies and simultaneous localization and mapping (SLAM), one can face the failure of these approaches when robots encounter scenarios outside their modeled experiences (here, the term modeling encompasses both conventional pattern finding and data-driven approaches). In particular, because learning-based methods are prone to catastrophic failure when operated in untrained scenes, there is still a demand for conventional yet robust approaches that work out of the box in diverse scenarios, such as real-world robotic services and SLAM competitions. In addition, the dynamic nature of real-world environments, characterized by changing surroundings over time and the presence of moving objects, leads to undesirable data points that hinder a robot from localization and path planning. Consequently, methodologies that enable long-term map management, such as multi-session SLAM and static map building, become essential. Therefore, to achieve a robust long-term robotic mapping system that can work out of the box, first, I propose (i) fast and robust ground segmentation to reject the ground points, which are featureless and thus not helpful for localization and mapping. Then, by employing the concept of graduated non-convexity (GNC), I propose (ii) outlier-robust registration with ground segmentation that overcomes the presence of gross outliers within the feature matching results, and (iii) hierarchical multi-session SLAM that not only uses our proposed GNC-based registration but also employs a GNC solver to be robust against outlier loop candidates. Finally, I propose (iv) instance-aware static map building that can handle the presence of moving objects in the environment based on the observation that most moving objects in urban environments are inevitably in contact with the ground.

#### 25. Integrating Digital Twins in Supply Chain Management Education
**Authors**: Eletter, Elrefae, Qasim, Houhamdi
**Year**: 2024
**DOI**: 10.1109/SDS64317.2024.10883925
**URL**: https://doi.org/10.1109/SDS64317.2024.10883925

**Abstract**: Higher education is undergoing a considerable transformation due to the rapid progress of technological advancements. However, higher education in business is currently experiencing a notable deficiency of experimental laboratories that would enable the practical application of the student's theoretical knowledge. Specifically, typical teaching approaches in supply chain management (SCM) are insufficient to provide students with the skills to navigate the complicated dynamics of modern supply networks. Conversely, experiential learning allows students to gain knowledge through active participation, thought, and interpretation of real-world experiences. Digital twins (DT) are a vital new tool in mixed-reality immersive learning that helps with hands-on learning. This study aims to provide a new pedagogical paradigm for teaching SCM using experiential learning. It connects classroom teaching with real-world business and societal issues, emerging trends, and best practices. The study emphasizes the interplay between knowledge and ideation. Therefore, it explores using experiential learning theory to teach the SCM course using digital twins. The study advances experiential learning by illustrating its relevance for teaching complex, data-driven decision-making inside a virtual business-oriented framework. It demonstrates how technology may improve learning in higher education.

---

## Failed Topics

The following topics did not return valid citations:

- Wissenschaftsrat concept examination private universities
- KLU Hamburg inauguration 2010
- history of HLA Die Logistik Akademie