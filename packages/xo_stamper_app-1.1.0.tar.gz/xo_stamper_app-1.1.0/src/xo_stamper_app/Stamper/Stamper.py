#!/usr/bin/env python


# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025, Maciej Barć <xgqt@xgqt.org>


import json
import platform
import socket

from datetime import datetime

from .StamperConfig import StamperConfig
from .StamperEnvironment import StamperEnvironment
from .StamperMetadata import StamperMetadata


class Stamper:

    def __init__(self, stamper_config: StamperConfig):
        self._stamper_config: StamperConfig = stamper_config

    def write_stamp(self, file_path_str: str) -> None:
        now: str = datetime.now().isoformat()
        host: str = socket.gethostname()

        stampper_metadata = StamperMetadata(
            include_git_commit=self._stamper_config.metadata_include_git_commit,
            include_project_version=self._stamper_config.metadata_include_project_version,
        )

        json_data: dict = {
            "datetime": now,
            "metadata": stampper_metadata.get_data(),
            "system": {
                "host": host,
                "arch": platform.machine(),
                "os": platform.system().lower(),
            },
            "environment": StamperEnvironment.get_environment(
                env_variables=self._stamper_config.env_variables
            ),
        }

        json_string: str = json.dumps(obj=json_data, separators=(",", ":"))

        with open(file_path_str, mode="w") as opened_file:
            opened_file.write(json_string)
