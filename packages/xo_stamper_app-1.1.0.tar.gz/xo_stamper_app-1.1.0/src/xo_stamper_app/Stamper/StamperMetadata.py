#!/usr/bin/env python


# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025, Maciej Barć <xgqt@xgqt.org>


import os
import platform

from ..System.LocateDominatingFile import LocateDominatingFile


class StamperMetadata:

    def __init__(
        self,
        include_git_commit: bool,
        include_project_version: bool,
    ):
        self._include_git_commit = include_git_commit
        self._include_project_version = include_project_version

    def get_data(self) -> dict[str, str]:
        metadata: dict[str, str] = {}

        if self._include_project_version:
            project_version: None | str = self._get_project_version()

            if project_version:
                metadata["version"] = project_version

        if self._include_git_commit:
            git_commit: None | str = self._get_git_commit()

            if git_commit:
                metadata["commit"] = git_commit

        # Keep this last.
        metadata["python"] = platform.python_version()

        return metadata

    def _get_git_commit(self) -> None | str:
        cwd: str = os.getcwd()
        git_dir: None | str = LocateDominatingFile.get_file(".git", cwd)

        # If we do not find any git dir.
        if not git_dir:
            return None

        git_head_path: str = os.path.join(git_dir, "HEAD")

        # Guard if HEAD file is missing.
        if not os.path.exists(git_head_path):
            return None

        with open(git_head_path) as opened_file:
            git_head_pointer_name: str = opened_file.read().strip()

        # Guard if HEAD file was broken.
        if not git_head_pointer_name.startswith("ref: "):
            return None

        git_ref_path: str = os.path.join(git_dir, git_head_pointer_name[5:])

        # Guard if the ref path is missing.
        if not os.path.exists(git_ref_path):
            return None

        with open(git_ref_path) as opened_file:
            return opened_file.read().strip()

    def _get_project_version(self) -> None | str:
        cwd: str = os.getcwd()
        file: None | str = LocateDominatingFile.get_file("VERSION", cwd)

        if not file:
            return None

        with open(file) as opened_file:
            return opened_file.read().strip()
