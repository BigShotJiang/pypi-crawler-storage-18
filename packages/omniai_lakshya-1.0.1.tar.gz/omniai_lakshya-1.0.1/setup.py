﻿from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="omniai-lakshya",
    version="1.0.1",  # Start with 1.0.1 since 1.0.0 is already on PyPI
    author="Lakshya Gupta",
    author_email="YOUREMAIL@gmail.com",  # ← CHANGE TO YOUR EMAIL
    description="OmniAI: Automated Machine Learning Pipeline - Christmas 2025 Edition by Lakshya Gupta",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/lakshya-7/omniai",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Free for non-commercial use",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[
        "pandas>=1.0",
        "numpy>=1.19",
    ],
)
