"""
███████╗███╗   ███╗███╗   ██╗ ██╗ █████╗ 
██╔════╝████╗ ████║████╗  ██║███║██╔══██╗
█████╗  ██╔████╔██║██╔██╗ ██║╚██║╚█████╔╝
██╔══╝  ██║╚██╔╝██║██║╚██╗██║ ██║██╔══██╗
███████╗██║ ╚═╝ ██║██║ ╚████║ ██║╚█████╔╝
╚══════╝╚═╝     ╚═╝╚═╝  ╚═══╝ ╚═╝ ╚════╝ 

O M N I   A I
Christmas Edition 2025
Created by: Lakshya Gupta
Date: 25 December 2025

FREE for everyone to use forever.
But this is MY work - please don't remove my name.
"""

# Your existing code continues here...
import pandas as pd
import os
import json

class DataDetector:
    """Intelligent data type and domain detector"""
    
    def analyze(self, file_path):
        """Analyze any data file"""
        
        # Get file info
        file_size = os.path.getsize(file_path) / (1024 * 1024)  # MB
        
        # Read first 1000 rows for analysis
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path, nrows=1000)
        elif file_path.endswith('.xlsx'):
            df = pd.read_excel(file_path, nrows=1000)
        elif file_path.endswith('.json'):
            df = pd.read_json(file_path)
        else:
            raise ValueError(f"Unsupported file type: {file_path}")
        
        # Detect data type
        data_type = self._detect_data_type(df)
        
        # Detect domain
        domain = self._detect_domain(df)
        
        # Detect task (classification/regression)
        task = self._detect_task(df)
        
        return {
            "type": data_type,
            "domain": domain,
            "task": task,
            "shape": f"{len(df)} rows × {len(df.columns)} columns",
            "size_mb": round(file_size, 2),
            "columns": list(df.columns),
            "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
            "sample": df.head(3).to_dict()
        }
    
    def _detect_data_type(self, df):
        """Detect if data is tabular, time series, text, etc."""
        # Check for date/time columns
        date_cols = [col for col in df.columns 
                    if any(term in str(col).lower() 
                          for term in ['date', 'time', 'timestamp'])]
        
        if len(date_cols) > 0:
            return "time_series"
        
        # Check for text columns (long strings)
        text_cols = [col for col in df.columns 
                    if df[col].dtype == 'object' and 
                    df[col].str.len().mean() > 50]
        
        if len(text_cols) > 0:
            return "text"
        
        return "tabular"
    
    def _detect_domain(self, df):
        """Detect data domain using intelligent rules"""
        columns_str = ' '.join([str(col).lower() for col in df.columns])
        sample_str = ' '.join([str(df[col].iloc[0]).lower() 
                              for col in df.columns[:3]])
        
        # Medical detection
        medical_keywords = [
            'patient', 'diagnosis', 'icd', 'cpt', 'loinc',
            'blood', 'pressure', 'heart', 'rate', 'bp', 'hr',
            'glucose', 'cholesterol', 'medication', 'dose',
            'hospital', 'clinic', 'doctor', 'nurse'
        ]
        
        medical_score = sum(1 for word in medical_keywords 
                           if word in columns_str or word in sample_str)
        
        if medical_score >= 3:
            return "medical"
        
        # Financial detection
        financial_keywords = [
            'price', 'cost', 'revenue', 'profit', 'loss',
            'stock', 'market', 'investment', 'portfolio',
            'credit', 'loan', 'interest', 'bank'
        ]
        
        financial_score = sum(1 for word in financial_keywords 
                             if word in columns_str)
        
        if financial_score >= 3:
            return "financial"
        
        # Retail detection
        retail_keywords = [
            'customer', 'product', 'order', 'sales', 'quantity',
            'category', 'sku', 'inventory', 'shipping'
        ]
        
        retail_score = sum(1 for word in retail_keywords 
                          if word in columns_str)
        
        if retail_score >= 3:
            return "retail"
        
        return "generic"
    
    def _detect_task(self, df):
        """Detect if classification or regression"""
        # Simple heuristic: Check if last column looks like a target
        last_col = df.columns[-1]
        
        # If last column has few unique values, likely classification
        if df[last_col].nunique() < 20:
            return "classification"
        else:
            return "regression"