"""
███████╗███╗   ███╗███╗   ██╗ ██╗ █████╗ 
██╔════╝████╗ ████║████╗  ██║███║██╔══██╗
█████╗  ██╔████╔██║██╔██╗ ██║╚██║╚█████╔╝
██╔══╝  ██║╚██╔╝██║██║╚██╗██║ ██║██╔══██╗
███████╗██║ ╚═╝ ██║██║ ╚████║ ██║╚█████╔╝
╚══════╝╚═╝     ╚═╝╚═╝  ╚═══╝ ╚═╝ ╚════╝ 

O M N I   A I
Christmas Edition 2025
Created by: Lakshya Gupta
Date: 25 December 2025

FREE for everyone to use forever.
But this is MY work - please don't remove my name.
"""

# Your existing code continues here...
# omniai/core/__init__.py
from .advisor import AlgorithmAdvisor

__all__ = ["AlgorithmAdvisor"]