"""Tests for cwl-upgrader."""
