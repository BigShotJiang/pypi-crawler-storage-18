"""Nanomon - Track LLM costs and usage across DSPy program runs.

Example usage:
    import dspy
    from nanomon import RunLogger
    from nanomon.sinks import ApiSink
    from nanomon.pricing import JsonPricing

    pricing = JsonPricing("pricing.json")
    sink = ApiSink("http://localhost:8000/api/v1")

    logger = RunLogger(pricing=pricing, sink=sink, default_tags=["local"])

    lm = dspy.LM(model="gpt-4o-mini")
    dspy.settings.configure(lm=logger.instrument_lm(lm))

    program = ...  # DSPy module

    with logger.run(tags=["exp-12"], metadata={"dataset": "qa-set-1"}):
        program("Explain X")
"""

from nanomon.callback import NanomonCallback
from nanomon.decorators import configure_tool_tracking, create_tool_tracker, track_tool
from nanomon.errors import (
    NanomonError,
    ExtractorError,
    PricingError,
    RunPayloadValidationError,
    SinkWriteError,
)
from nanomon.instrumentation import ActiveContext, InstrumentedLM
from nanomon.logger import RunLogger
from nanomon.pricing import (
    CallablePricing,
    DictPricing,
    JsonPricing,
    PricingSource,
    calculate_cost,
)
from nanomon.sinks import ApiSink, MultiSink, Sink, SqliteSink
from nanomon.types import ModelPrice, ModelStats, RunState, RunStatus
from nanomon.usage_extractors import (
    DefaultUsageExtractor,
    ExtractorChain,
    UsageExtractor,
)
from nanomon.utils import Clock, SystemClock

__version__ = "0.1.0"

__all__ = [
    # Main class
    "RunLogger",
    # Decorators
    "configure_tool_tracking",
    "create_tool_tracker",
    "track_tool",
    # Instrumentation
    "ActiveContext",
    "InstrumentedLM",
    "NanomonCallback",
    # Pricing
    "PricingSource",
    "DictPricing",
    "JsonPricing",
    "CallablePricing",
    "calculate_cost",
    # Sinks
    "Sink",
    "ApiSink",
    "SqliteSink",
    "MultiSink",
    # Types
    "RunState",
    "RunStatus",
    "ModelStats",
    "ModelPrice",
    # Extractors
    "UsageExtractor",
    "DefaultUsageExtractor",
    "ExtractorChain",
    # Utils
    "Clock",
    "SystemClock",
    # Errors
    "NanomonError",
    "SinkWriteError",
    "RunPayloadValidationError",
    "PricingError",
    "ExtractorError",
]
