# Nanomon

Track LLM costs and usage across DSPy program runs.

## Installation

```bash
pip install nanomon
```

## Quick Start

```python
import dspy
from nanomon import RunLogger, track_tool
from nanomon.sinks import ApiSink
from nanomon.pricing import JsonPricing

# Setup pricing and sink
pricing = JsonPricing("pricing.json")
sink = ApiSink("http://localhost:8000/api/v1")

# Create logger
logger = RunLogger(pricing=pricing, sink=sink, default_tags=["production"])

# Instrument your LM
lm = dspy.LM(model="gpt-4o-mini")
dspy.settings.configure(lm=logger.instrument_lm(lm))

# Track runs
with logger.run(tags=["experiment-1"], metadata={"dataset": "qa"}):
    result = await logger.react(my_module, question="What is 2+2?")
```

## Features

- Track LLM token usage and costs
- Support for multiple sinks (API, SQLite, Multi)
- Tool call tracking with `@track_tool` decorator
- DSPy module integration (ReAct, Predict, ChainOfThought)

## License

MIT
