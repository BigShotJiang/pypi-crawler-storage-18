"""Decorator factories for nanomon."""

from __future__ import annotations

import asyncio
import inspect
import logging
from functools import wraps
from typing import TYPE_CHECKING, Any, Callable, TypeVar

from nanomon.instrumentation import get_active_context
from nanomon.utils import Clock, SystemClock

if TYPE_CHECKING:
    from nanomon.sinks import Sink

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


def _serialize_value(value: Any) -> Any:
    """Serialize a value to JSON-compatible format."""
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    if isinstance(value, (list, tuple)):
        return [_serialize_value(v) for v in value]
    if isinstance(value, dict):
        return {k: _serialize_value(v) for k, v in value.items()}
    return str(value)  # Fallback to string representation


def _capture_tool_input(func: Callable[..., Any], args: tuple[Any, ...], kwargs: dict[str, Any]) -> dict[str, Any] | None:
    """Capture function arguments as a dictionary for tool input tracking."""
    input_data: dict[str, Any] = {}

    # Get parameter names from function signature
    try:
        sig = inspect.signature(func)
        params = list(sig.parameters.keys())

        # Map positional args to parameter names
        for i, arg in enumerate(args):
            if i < len(params):
                input_data[params[i]] = _serialize_value(arg)
            else:
                input_data[f"arg_{i}"] = _serialize_value(arg)

        # Add keyword arguments
        for key, value in kwargs.items():
            input_data[key] = _serialize_value(value)

    except (ValueError, TypeError):
        # Fallback if signature inspection fails
        for i, arg in enumerate(args):
            input_data[f"arg_{i}"] = _serialize_value(arg)
        for key, value in kwargs.items():
            input_data[key] = _serialize_value(value)

    return input_data if input_data else None

# Module-level sink/clock for standalone track_tool decorator
_default_sink: Sink | None = None
_default_clock: Clock = SystemClock()


def configure_tool_tracking(sink: Sink, clock: Clock | None = None) -> None:
    """Configure the default sink and clock for standalone track_tool decorator.

    Call this after creating your sink to enable tool tracking with the
    standalone @track_tool decorator.

    Args:
        sink: The sink to write tool calls to
        clock: Optional clock for timing (defaults to SystemClock)

    Example:
        from nanomon import ApiSink
        from nanomon.decorators import configure_tool_tracking

        sink = ApiSink("http://localhost:8000/api/v1")
        configure_tool_tracking(sink)

        # Now @track_tool decorators will work
    """
    global _default_sink, _default_clock
    _default_sink = sink
    _default_clock = clock or SystemClock()


def create_tool_tracker(sink: Sink, clock: Clock) -> Callable[..., Callable[[F], F]]:
    """Factory that creates the track_tool decorator with sink/clock access.

    Args:
        sink: The sink to write tool calls to
        clock: The clock for timing

    Returns:
        A track_tool decorator function
    """

    def track_tool(
        name: str | None = None,
        method: str | None = None,
    ) -> Callable[[F], F]:
        """Decorator to track tool calls within a run context.

        Args:
            name: Optional name override for the tool (defaults to function name)
            method: Optional method name for additional categorization

        Returns:
            A decorator that tracks the tool call
        """

        def decorator(func: F) -> F:
            tool_name = name or func.__name__

            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                ctx = get_active_context()
                if ctx is None or ctx.current_run_id is None:
                    # No active run, just call the function
                    return func(*args, **kwargs)

                run_id = ctx.current_run_id
                started_at = clock.now_utc()
                status = "success"
                error_msg: str | None = None
                tool_input = _capture_tool_input(func, args, kwargs)

                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    status = "error"
                    error_msg = str(e)
                    raise
                finally:
                    ended_at = clock.now_utc()
                    payload = {
                        "name": tool_name,
                        "method": method,
                        "startedAt": started_at.isoformat().replace("+00:00", "Z"),
                        "endedAt": ended_at.isoformat().replace("+00:00", "Z"),
                        "status": status,
                        "error": error_msg,
                        "input": tool_input,
                    }
                    try:
                        sink.write_tool_call(run_id, payload)
                        logger.debug(f"Tracked tool call: {tool_name}")
                    except Exception as e:
                        logger.warning(f"Failed to write tool call {tool_name}: {e}")

            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                ctx = get_active_context()
                if ctx is None or ctx.current_run_id is None:
                    # No active run, just call the function
                    return await func(*args, **kwargs)

                run_id = ctx.current_run_id
                started_at = clock.now_utc()
                status = "success"
                error_msg: str | None = None
                tool_input = _capture_tool_input(func, args, kwargs)

                try:
                    return await func(*args, **kwargs)
                except Exception as e:
                    status = "error"
                    error_msg = str(e)
                    raise
                finally:
                    ended_at = clock.now_utc()
                    payload = {
                        "name": tool_name,
                        "method": method,
                        "startedAt": started_at.isoformat().replace("+00:00", "Z"),
                        "endedAt": ended_at.isoformat().replace("+00:00", "Z"),
                        "status": status,
                        "error": error_msg,
                        "input": tool_input,
                    }
                    try:
                        sink.write_tool_call(run_id, payload)
                        logger.debug(f"Tracked tool call: {tool_name}")
                    except Exception as e:
                        logger.warning(f"Failed to write tool call {tool_name}: {e}")

            # Return the appropriate wrapper based on function type
            if asyncio.iscoroutinefunction(func):
                return async_wrapper  # type: ignore[return-value]
            return sync_wrapper  # type: ignore[return-value]

        return decorator

    return track_tool


def track_tool(
    name: str | None = None,
    method: str | None = None,
) -> Callable[[F], F]:
    """Standalone decorator to track tool calls within a run context.

    This decorator can be used at module definition time, before a RunLogger
    is created. Call configure_tool_tracking() with your sink before running
    the decorated functions.

    If no sink is configured or no run is active, the function executes
    normally without tracking.

    Args:
        name: Optional name override for the tool (defaults to function name)
        method: Optional method name for additional categorization

    Returns:
        A decorator that tracks the tool call

    Example:
        from nanomon.decorators import track_tool, configure_tool_tracking

        @track_tool(name="web_search")
        def search_web(query: str) -> str:
            return results

        # Later, when setting up the logger:
        configure_tool_tracking(sink)

        with cost_logger.run():
            search_web("query")  # Now tracked
    """

    def decorator(func: F) -> F:
        tool_name = name or func.__name__

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            ctx = get_active_context()
            if ctx is None or ctx.current_run_id is None or _default_sink is None:
                # No active run or no sink configured, just call the function
                return func(*args, **kwargs)

            run_id = ctx.current_run_id
            started_at = _default_clock.now_utc()
            status = "success"
            error_msg: str | None = None
            tool_input = _capture_tool_input(func, args, kwargs)

            try:
                return func(*args, **kwargs)
            except Exception as e:
                status = "error"
                error_msg = str(e)
                raise
            finally:
                ended_at = _default_clock.now_utc()
                payload = {
                    "name": tool_name,
                    "method": method,
                    "startedAt": started_at.isoformat().replace("+00:00", "Z"),
                    "endedAt": ended_at.isoformat().replace("+00:00", "Z"),
                    "status": status,
                    "error": error_msg,
                    "input": tool_input,
                }
                try:
                    _default_sink.write_tool_call(run_id, payload)
                    logger.debug(f"Tracked tool call: {tool_name}")
                except Exception as e:
                    logger.warning(f"Failed to write tool call {tool_name}: {e}")

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            ctx = get_active_context()
            if ctx is None or ctx.current_run_id is None or _default_sink is None:
                # No active run or no sink configured, just call the function
                return await func(*args, **kwargs)

            run_id = ctx.current_run_id
            started_at = _default_clock.now_utc()
            status = "success"
            error_msg: str | None = None
            tool_input = _capture_tool_input(func, args, kwargs)

            try:
                return await func(*args, **kwargs)
            except Exception as e:
                status = "error"
                error_msg = str(e)
                raise
            finally:
                ended_at = _default_clock.now_utc()
                payload = {
                    "name": tool_name,
                    "method": method,
                    "startedAt": started_at.isoformat().replace("+00:00", "Z"),
                    "endedAt": ended_at.isoformat().replace("+00:00", "Z"),
                    "status": status,
                    "error": error_msg,
                    "input": tool_input,
                }
                try:
                    _default_sink.write_tool_call(run_id, payload)
                    logger.debug(f"Tracked tool call: {tool_name}")
                except Exception as e:
                    logger.warning(f"Failed to write tool call {tool_name}: {e}")

        # Return the appropriate wrapper based on function type
        if asyncio.iscoroutinefunction(func):
            return async_wrapper  # type: ignore[return-value]
        return sync_wrapper  # type: ignore[return-value]

    return decorator
