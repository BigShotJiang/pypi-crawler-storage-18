"""
Shell completion generation for ContextDigger CLI.

Provides rich autocomplete similar to Salesforce CLI (sf/sfdx):
- Command completion with descriptions
- Dynamic area/bookmark/context completion
- Context-aware suggestions
"""

from pathlib import Path
from typing import List, Dict
import json


def get_areas() -> List[str]:
    """Get list of available area names for completion."""
    cdg_dir = Path.cwd() / ".cdg"
    if not cdg_dir.exists():
        return []

    areas_dir = cdg_dir / "areas"
    if not areas_dir.exists():
        return []

    areas = []
    for area_file in areas_dir.glob("*.json"):
        try:
            with open(area_file) as f:
                data = json.load(f)
                areas.append(data.get("name", area_file.stem))
        except Exception:
            continue

    return sorted(areas)


def get_bookmarks() -> List[str]:
    """Get list of bookmark names for completion."""
    cdg_dir = Path.cwd() / ".cdg"
    bookmarks_file = cdg_dir / "bookmarks.json"

    if not bookmarks_file.exists():
        return []

    try:
        with open(bookmarks_file) as f:
            data = json.load(f)
            return [b["name"] for b in data.get("bookmarks", [])]
    except Exception:
        return []


def get_contexts() -> List[str]:
    """Get list of context snapshot names for completion."""
    cdg_dir = Path.cwd() / ".cdg"
    contexts_dir = cdg_dir / "contexts"

    if not contexts_dir.exists():
        return []

    contexts = []
    for ctx_file in contexts_dir.glob("*.json"):
        contexts.append(ctx_file.stem)

    return sorted(contexts)


def get_all_commands() -> Dict[str, str]:
    """Get all commands with descriptions."""
    return {
        # Core Navigation
        "init": "Initialize ContextDigger in current directory",
        "dig": "Focus on a specific code area",
        "redig": "Interactively switch focus areas",
        "status": "Show current focus and session info",
        "back": "Navigate to previous area",
        "forward": "Navigate to next area",
        "history": "Show navigation history",
        "list": "List all discovered code areas",

        # Bookmarks
        "mark-spot": "Create bookmark at current area",
        "goto-spot": "Jump to bookmarked area",
        "list-spots": "List all bookmarks",
        "delete-spot": "Delete a bookmark",

        # Context Snapshots
        "save-context": "Save current context as snapshot",
        "load-context": "Load a context snapshot",
        "list-contexts": "List all context snapshots",
        "delete-context": "Delete a context snapshot",

        # Notes & Documentation
        "note": "Add note to current area",
        "notes": "View notes for current area",
        "wiki": "Generate wiki documentation",

        # Analysis & Intelligence
        "suggest": "Get AI suggestions for areas to explore",
        "deps": "Show dependencies for current area",
        "impact": "Analyze impact of changes",
        "map": "Generate codebase map",
        "hotspots": "Find code hotspots (frequently changed)",
        "gaps": "Find coverage gaps",
        "perf": "Performance analysis",
        "benchmark": "Run performance benchmarks",
        "trends": "Analyze historical trends",
        "predictions": "Generate predictive insights",
        "remediate": "Get automated remediation suggestions",

        # Search & Query
        "search": "Search across all areas",
        "query": "Custom query on codebase data",

        # Automation
        "auto": "Get automation suggestions",
        "rules": "View automation rules",

        # Reports & Export
        "analytics": "View work analytics",
        "report": "Generate comprehensive report",
        "export": "Export context in various formats",
        "backup": "Create backup of .cdg directory",
        "provenance": "Show file provenance info",

        # Dashboard & Monitoring
        "dashboard": "Show comprehensive dashboard",
        "health": "Run health check",
        "stats": "Show statistics",

        # Sub-Area Management
        "split": "Split area using strategies",
        "create-subarea": "Manually create sub-area",
        "merge-subareas": "Merge sub-areas back",
        "list-subareas": "List sub-areas of an area",

        # Budget Management
        "budget": "Show budget status",
        "policy": "Manage budget policies",

        # Session Management
        "continue": "Resume last session",
        "contracts": "List all work sessions",
        "pause": "Pause current session",

        # Team
        "team": "Show team activity",
        "tests": "Show test coverage",

        # LLM Integration
        "llm": "Manage LLM integration",

        # Focus Management
        "focus": "Switch focus area",
        "refocus": "Interactive focus switcher",
        "focus-status": "Show current focus state",
        "goto": "Navigate to bookmark",

        # Help
        "help": "Show help message",
        "--version": "Show version",
        "-h": "Show help message",
    }


# Bash completion script template
BASH_COMPLETION = """
# ContextDigger bash completion
# Source this file or add to ~/.bashrc:
#   source <(contextdigger completion bash)

_contextdigger_complete() {
    local cur prev words cword
    _init_completion || return

    # First argument (command)
    if [[ $cword -eq 1 ]]; then
        COMPREPLY=( $(compgen -W "$(contextdigger --complete-commands)" -- "$cur") )
        return
    fi

    # Context-aware completion for specific commands
    case "${words[1]}" in
        dig|redig|split|create-subarea|list-subareas|merge-subareas)
            # Complete area names
            COMPREPLY=( $(compgen -W "$(contextdigger --complete-areas)" -- "$cur") )
            ;;
        goto-spot|delete-spot)
            # Complete bookmark names
            COMPREPLY=( $(compgen -W "$(contextdigger --complete-bookmarks)" -- "$cur") )
            ;;
        load-context|delete-context)
            # Complete context names
            COMPREPLY=( $(compgen -W "$(contextdigger --complete-contexts)" -- "$cur") )
            ;;
        export)
            # Complete export formats
            COMPREPLY=( $(compgen -W "markdown json xml ai claude cursor" -- "$cur") )
            ;;
        llm)
            # Complete LLM subcommands
            COMPREPLY=( $(compgen -W "status enable disable" -- "$cur") )
            ;;
        *)
            # Complete flags
            COMPREPLY=( $(compgen -W "--json --help" -- "$cur") )
            ;;
    esac
}

complete -F _contextdigger_complete contextdigger
complete -F _contextdigger_complete cdg
"""

# Zsh completion script template
ZSH_COMPLETION = """
#compdef contextdigger cdg

# ContextDigger zsh completion
# Add to ~/.zshrc:
#   source <(contextdigger completion zsh)

_contextdigger() {
    local -a commands areas bookmarks contexts

    # Get commands
    commands=(${(f)"$(contextdigger --complete-commands-with-desc)"})

    # First argument - command selection
    if (( CURRENT == 2 )); then
        _describe 'command' commands
        return
    fi

    # Context-aware completion
    case $words[2] in
        dig|redig|split|create-subarea|list-subareas|merge-subareas)
            areas=(${(f)"$(contextdigger --complete-areas)"})
            _describe 'area' areas
            ;;
        goto-spot|delete-spot)
            bookmarks=(${(f)"$(contextdigger --complete-bookmarks)"})
            _describe 'bookmark' bookmarks
            ;;
        load-context|delete-context)
            contexts=(${(f)"$(contextdigger --complete-contexts)"})
            _describe 'context' contexts
            ;;
        export)
            _values 'format' \\
                'markdown[Markdown documentation]' \\
                'json[JSON format]' \\
                'xml[XML format]' \\
                'ai[AI-optimized format]' \\
                'claude[Claude Code format]' \\
                'cursor[Cursor IDE format]'
            ;;
        llm)
            _values 'subcommand' \\
                'status[Show LLM status]' \\
                'enable[Enable LLM integration]' \\
                'disable[Disable LLM integration]'
            ;;
        *)
            _arguments \\
                '--json[Output as JSON]' \\
                '--help[Show help]'
            ;;
    esac
}

_contextdigger "$@"
"""


def generate_bash_completion() -> str:
    """Generate bash completion script."""
    return BASH_COMPLETION.strip()


def generate_zsh_completion() -> str:
    """Generate zsh completion script."""
    return ZSH_COMPLETION.strip()


def print_commands():
    """Print commands for bash completion."""
    commands = get_all_commands()
    print(" ".join(commands.keys()))


def print_commands_with_desc():
    """Print commands with descriptions for zsh completion."""
    commands = get_all_commands()
    for cmd, desc in commands.items():
        print(f"{cmd}:{desc}")


def print_areas():
    """Print area names for completion."""
    areas = get_areas()
    print(" ".join(areas))


def print_bookmarks():
    """Print bookmark names for completion."""
    bookmarks = get_bookmarks()
    print(" ".join(bookmarks))


def print_contexts():
    """Print context names for completion."""
    contexts = get_contexts()
    print(" ".join(contexts))


def install_completion():
    """Auto-install shell completion for the user's shell."""
    import os
    import subprocess

    # Detect shell
    shell = os.environ.get("SHELL", "")

    if "bash" in shell:
        shell_type = "bash"
        rc_file = os.path.expanduser("~/.bashrc")
        # Check for .bash_profile on macOS
        if not os.path.exists(rc_file):
            bash_profile = os.path.expanduser("~/.bash_profile")
            if os.path.exists(bash_profile):
                rc_file = bash_profile
    elif "zsh" in shell:
        shell_type = "zsh"
        rc_file = os.path.expanduser("~/.zshrc")
    else:
        print(f"❌ Unknown shell: {shell}")
        print("Supported shells: bash, zsh")
        print("\nManual installation:")
        print("  source <(contextdigger completion bash)   # for bash")
        print("  source <(contextdigger completion zsh)    # for zsh")
        return False

    completion_line = f'source <(contextdigger completion {shell_type})'

    # Check if already installed
    if os.path.exists(rc_file):
        with open(rc_file, 'r') as f:
            content = f.read()
            if completion_line in content or "contextdigger completion" in content:
                print(f"✅ Completion already installed in {rc_file}")
                print(f"\nReload your shell to activate:")
                print(f"  source {rc_file}")
                return True

    # Add completion line
    print(f"📝 Installing {shell_type} completion to {rc_file}...")

    try:
        with open(rc_file, 'a') as f:
            f.write(f"\n# ContextDigger autocomplete\n")
            f.write(f"{completion_line}\n")

        print(f"✅ Completion installed successfully!")
        print(f"\n📋 Next step: Reload your shell")
        print(f"  source {rc_file}")
        print(f"\nOr open a new terminal window.")
        print(f"\n🎉 Then try: contextdigger <TAB>")
        return True

    except Exception as e:
        print(f"❌ Error installing completion: {e}")
        print(f"\nManual installation:")
        print(f"  echo '{completion_line}' >> {rc_file}")
        print(f"  source {rc_file}")
        return False


def uninstall_completion():
    """Remove shell completion from user's config."""
    import os

    shell = os.environ.get("SHELL", "")

    if "bash" in shell:
        rc_file = os.path.expanduser("~/.bashrc")
        if not os.path.exists(rc_file):
            rc_file = os.path.expanduser("~/.bash_profile")
    elif "zsh" in shell:
        rc_file = os.path.expanduser("~/.zshrc")
    else:
        print("❌ Unable to detect shell config file")
        return False

    if not os.path.exists(rc_file):
        print(f"✅ No completion installed in {rc_file}")
        return True

    try:
        with open(rc_file, 'r') as f:
            lines = f.readlines()

        # Remove completion lines
        new_lines = []
        skip_next = False
        for line in lines:
            if "ContextDigger autocomplete" in line:
                skip_next = True
                continue
            if skip_next and "contextdigger completion" in line:
                skip_next = False
                continue
            new_lines.append(line)

        with open(rc_file, 'w') as f:
            f.writelines(new_lines)

        print(f"✅ Completion removed from {rc_file}")
        print(f"\nReload your shell:")
        print(f"  source {rc_file}")
        return True

    except Exception as e:
        print(f"❌ Error removing completion: {e}")
        return False
