"""Tests for graphqlite.connection module."""

import os
import sqlite3
from pathlib import Path

import pytest

import graphqlite
from graphqlite import Connection, connect, wrap


def get_extension_path():
    """Get path to the built extension."""
    test_dir = Path(__file__).parent
    build_dir = test_dir.parent.parent.parent / "build"

    if (build_dir / "graphqlite.dylib").exists():
        return str(build_dir / "graphqlite.dylib")
    elif (build_dir / "graphqlite.so").exists():
        return str(build_dir / "graphqlite.so")

    env_path = os.environ.get("GRAPHQLITE_EXTENSION_PATH")
    if env_path and Path(env_path).exists():
        return env_path

    pytest.skip("GraphQLite extension not found. Build with 'make extension'")


@pytest.fixture
def db():
    """Create an in-memory GraphQLite database."""
    ext_path = get_extension_path()
    conn = connect(":memory:", extension_path=ext_path)
    yield conn
    conn.close()


# =============================================================================
# Connection Management
# =============================================================================

def test_connect_memory():
    ext_path = get_extension_path()
    db = connect(":memory:", extension_path=ext_path)
    assert db is not None
    db.close()


def test_connect_file(tmp_path):
    ext_path = get_extension_path()
    db_path = tmp_path / "test.db"
    db = connect(str(db_path), extension_path=ext_path)
    assert db is not None
    assert db_path.exists()
    db.close()


def test_connect_context_manager():
    ext_path = get_extension_path()
    with connect(":memory:", extension_path=ext_path) as db:
        results = db.cypher("RETURN 1 as n")
        assert len(results) == 1


def test_wrap_existing_connection():
    ext_path = get_extension_path()
    sqlite_conn = sqlite3.connect(":memory:")
    db = wrap(sqlite_conn, extension_path=ext_path)
    results = db.cypher("RETURN 'hello' as msg")
    assert results[0]["msg"] == "hello"
    db.close()


def test_sqlite_connection_property(db):
    assert db.sqlite_connection is not None
    assert isinstance(db.sqlite_connection, sqlite3.Connection)


# =============================================================================
# Cypher Queries
# =============================================================================

def test_create_node(db):
    db.cypher("CREATE (n:Person {name: 'Alice', age: 30})")
    results = db.cypher("MATCH (n:Person) RETURN n.name, n.age")
    assert len(results) == 1
    assert results[0]["n.name"] == "Alice"
    assert results[0]["n.age"] == 30


def test_create_relationship(db):
    db.cypher("CREATE (a:Person {name: 'Alice'})")
    db.cypher("CREATE (b:Person {name: 'Bob'})")
    db.cypher("""
        MATCH (a:Person {name: 'Alice'}), (b:Person {name: 'Bob'})
        CREATE (a)-[:KNOWS]->(b)
    """)
    results = db.cypher("MATCH (a)-[:KNOWS]->(b) RETURN a.name, b.name")
    assert len(results) == 1
    assert results[0]["a.name"] == "Alice"
    assert results[0]["b.name"] == "Bob"


def test_return_scalar(db):
    results = db.cypher("RETURN 42 as num, 'hello' as str")
    assert len(results) == 1
    assert results[0]["num"] == 42
    assert results[0]["str"] == "hello"


def test_return_multiple_rows(db):
    db.cypher("CREATE (n:Num {val: 1})")
    db.cypher("CREATE (n:Num {val: 2})")
    db.cypher("CREATE (n:Num {val: 3})")
    results = db.cypher("MATCH (n:Num) RETURN n.val ORDER BY n.val")
    assert len(results) == 3
    assert [r["n.val"] for r in results] == [1, 2, 3]


def test_aggregation(db):
    db.cypher("CREATE (n:Num {val: 10})")
    db.cypher("CREATE (n:Num {val: 20})")
    db.cypher("CREATE (n:Num {val: 30})")
    results = db.cypher("MATCH (n:Num) RETURN count(n) as cnt, sum(n.val) as total")
    assert int(results[0]["cnt"]) == 3
    assert int(results[0]["total"]) == 60


def test_empty_result(db):
    results = db.cypher("MATCH (n:NonExistent) RETURN n")
    assert len(results) <= 1


# =============================================================================
# CypherResult
# =============================================================================

def test_result_iteration(db):
    db.cypher("CREATE (n:N {v: 1})")
    db.cypher("CREATE (n:N {v: 2})")
    results = db.cypher("MATCH (n:N) RETURN n.v ORDER BY n.v")
    values = [row["n.v"] for row in results]
    assert values == [1, 2]


def test_result_indexing(db):
    db.cypher("CREATE (n:N {v: 'first'})")
    db.cypher("CREATE (n:N {v: 'second'})")
    results = db.cypher("MATCH (n:N) RETURN n.v ORDER BY n.v")
    assert results[0]["n.v"] == "first"
    assert results[1]["n.v"] == "second"


def test_result_columns(db):
    results = db.cypher("RETURN 1 as a, 2 as b, 3 as c")
    assert results.columns == ["a", "b", "c"]


def test_result_to_list(db):
    db.cypher("CREATE (n:N {v: 1})")
    results = db.cypher("MATCH (n:N) RETURN n.v")
    data = results.to_list()
    assert isinstance(data, list)
    assert len(data) == 1


def test_result_len(db):
    db.cypher("CREATE (n:N {v: 1})")
    db.cypher("CREATE (n:N {v: 2})")
    results = db.cypher("MATCH (n:N) RETURN n.v")
    assert len(results) == 2


# =============================================================================
# Graph Algorithms (via Connection.cypher)
# =============================================================================

def test_pagerank_function(db):
    db.cypher("CREATE (a:Page {name: 'A'})")
    db.cypher("CREATE (b:Page {name: 'B'})")
    db.cypher("CREATE (c:Page {name: 'C'})")
    db.cypher("""
        MATCH (a:Page {name: 'A'}), (b:Page {name: 'B'}), (c:Page {name: 'C'})
        CREATE (a)-[:LINKS]->(b), (a)-[:LINKS]->(c), (b)-[:LINKS]->(c)
    """)
    results = db.cypher("RETURN pageRank(0.85, 10)")
    assert len(results) > 0


def test_label_propagation_function(db):
    db.cypher("CREATE (a:Node {name: 'A'})")
    db.cypher("CREATE (b:Node {name: 'B'})")
    db.cypher("""
        MATCH (a:Node {name: 'A'}), (b:Node {name: 'B'})
        CREATE (a)-[:CONNECTED]->(b)
    """)
    results = db.cypher("RETURN labelPropagation(5)")
    assert len(results) > 0


# =============================================================================
# Module Exports
# =============================================================================

def test_version_exists():
    assert hasattr(graphqlite, "__version__")
    assert isinstance(graphqlite.__version__, str)


def test_exports():
    assert hasattr(graphqlite, "Connection")
    assert hasattr(graphqlite, "connect")
    assert hasattr(graphqlite, "wrap")
    assert hasattr(graphqlite, "load")
    assert hasattr(graphqlite, "loadable_path")


# =============================================================================
# Parameterized Queries
# =============================================================================

def test_parameterized_string(db):
    """Test parameterized query with string parameter."""
    db.cypher("CREATE (n:Person {name: 'Alice', age: 30})")
    db.cypher("CREATE (n:Person {name: 'Bob', age: 25})")

    results = db.cypher(
        "MATCH (n:Person) WHERE n.name = $name RETURN n.name, n.age",
        {"name": "Alice"}
    )
    assert len(results) == 1
    assert results[0]["n.name"] == "Alice"
    assert results[0]["n.age"] == 30


def test_parameterized_integer(db):
    """Test parameterized query with integer parameter."""
    db.cypher("CREATE (n:Person {name: 'Alice', age: 30})")
    db.cypher("CREATE (n:Person {name: 'Bob', age: 25})")
    db.cypher("CREATE (n:Person {name: 'Charlie', age: 35})")

    results = db.cypher(
        "MATCH (n:Person) WHERE n.age > $min_age RETURN n.name ORDER BY n.age",
        {"min_age": 28}
    )
    assert len(results) == 2
    assert results[0]["n.name"] == "Alice"
    assert results[1]["n.name"] == "Charlie"


def test_parameterized_multiple(db):
    """Test parameterized query with multiple parameters."""
    db.cypher("CREATE (n:Person {name: 'Alice', age: 30})")
    db.cypher("CREATE (n:Person {name: 'Bob', age: 25})")
    db.cypher("CREATE (n:Person {name: 'Charlie', age: 35})")

    results = db.cypher(
        "MATCH (n:Person) WHERE n.age >= $min AND n.age <= $max RETURN n.name ORDER BY n.age",
        {"min": 25, "max": 32}
    )
    assert len(results) == 2
    assert results[0]["n.name"] == "Bob"
    assert results[1]["n.name"] == "Alice"


def test_parameterized_no_match(db):
    """Test parameterized query that matches nothing."""
    db.cypher("CREATE (n:Person {name: 'Alice'})")

    results = db.cypher(
        "MATCH (n:Person) WHERE n.name = $name RETURN n.name",
        {"name": "Nobody"}
    )
    # When no rows match, result may be empty or contain success message
    # The key is that it doesn't return Alice
    for row in results:
        if "n.name" in row:
            assert row["n.name"] != "Alice"


def test_parameterized_sql_injection_safe(db):
    """Test that parameters prevent SQL injection."""
    db.cypher("CREATE (n:Person {name: 'Alice'})")
    db.cypher("CREATE (n:Person {name: 'Bob'})")

    # This malicious string should be treated as a literal value
    results = db.cypher(
        "MATCH (n:Person) WHERE n.name = $name RETURN n.name",
        {"name": "'; DROP TABLE nodes; --"}
    )

    # Should not match anything (no one named with SQL injection string)
    matched_names = [row.get("n.name") for row in results if "n.name" in row]
    assert "Alice" not in matched_names
    assert "Bob" not in matched_names

    # Verify data is still intact
    all_results = db.cypher("MATCH (n:Person) RETURN n.name ORDER BY n.name")
    names = [row["n.name"] for row in all_results]
    assert "Alice" in names
    assert "Bob" in names
