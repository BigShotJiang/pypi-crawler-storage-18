# 🚀 BugPilot CLI v1.4.0

**AI-Powered Autonomous Penetration Testing Tool**

Developer: LAKSHMIKANTHAN K (letchupkt)

---

## ⚡ Quick Start

```bash
# Run BugPilot
bugpilot

# Try it
You: hey, test http://testphp.vulnweb.com/login.php
```

---

## ✨ Features

- 🤖 **Autonomous AI** - Runs until task complete (no iteration limits)
- 🧠 **Expert Intelligence** - WordPress→wpscan, Login→sqlmap
- 💬 **Chatbot Interface** - Natural conversation
- 💣 **Auto Exploits** - Generates PoC files in `./pocs/`
- 🎯 **Smart Stopping** - Knows when task is done
- 📊 **Real-time Status** - Context, tokens, progress tracking

---

## 💡 Examples

**Natural Conversation:**
```
You: what's SQL injection?
AI: [Detailed explanation]
```

**Autonomous Pentesting:**
```
You: pentest example.com

AI: [Detects WordPress]
    → Uses wpscan automatically
    → Finds vulnerabilities
    → Generates exploits
    → Stops when done
```

**Settings (Interactive):**
```
You: /settings
[Rich table with all settings]

You: /settings set autopilot_enabled true
✓ Updated
```

---

## 🛠️ Key Commands

```bash
# Natural chat (no command needed)
Just type what you want!

# Settings
/settings              # Show all
/settings edit         # Interactive
/config               # Alias for /settings

# Help
/help                 # All commands
/exit                 # Exit
```

---

## 🎯 What Makes v1.4.0 Special

| Feature | Details |
|---------|---------|
| **Truly Autonomous** | Runs until objective achieved, not iteration-limited |
| **Expert Decisions** | Detects tech stack and uses appropriate tools |
| **No Repetition** | Never runs the same command twice |
| **Auto Exploits** | Generates working PoC files automatically |
| **Intelligent Stopping** | Knows when task is complete |

---

## 📂 Generated Files

```
./pocs/              # Auto-generated exploits
├── poc_sqli_1.py
├── poc_xss_2.html
└── poc_report.txt

./sessions/          # Saved sessions
./reports/           # Exported reports
```

---

## 🚀 Version 1.4.0

**Intelligence Upgrade Release**

- Expert-level AI reasoning
- Smart tool selection
- Autonomous operation
- Exploit generation
- Status tracking

---

## 📦 Installation

```bash
pip install bugpilot-cli
```

**Or from source:**
```bash
cd "d:/project(software)/BugPilot CLI"
pip install -e .
```

---

## 🧪 Testing

```bash
bugpilot
> pentest testphp.vulnweb.com
[Watch AI work autonomously]
```

---

**Happy Pentesting! 🎯🔥**
