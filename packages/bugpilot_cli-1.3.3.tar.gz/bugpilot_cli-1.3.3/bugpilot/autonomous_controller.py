"""
Autonomous Controller - Intelligent stopping and progress tracking
Part of BugPilot v1.4.0 - Truly Autonomous AI
"""

from typing import List, Dict, Optional
from enum import Enum


class ProgressState(Enum):
    """Current state of autonomous testing"""
    INITIALIZING = "initializing"
    RECONNAISSANCE = "reconnaissance"
    SCANNING = "scanning"
    TESTING = "testing"
    EXPLOITING = "exploiting"
    COMPLETE = "complete"
    STUCK = "stuck"


class AutonomousController:
    """
    Controls autonomous AI behavior
    Decides when to stop, when to continue, and tracks progress
    """
    
    def __init__(self):
        self.state = ProgressState.INITIALIZING
        self.iterations_without_progress = 0
        self.total_findings = 0
        self.critical_findings = 0
        self.action_history = []
        self.phase_changes = 0
        
    def should_continue(self, context: Dict) -> tuple[bool, Optional[str]]:
        """
        Intelligently decide if AI should continue or stop
        
        Returns:
            (should_continue: bool, reason: Optional[str])
        """
        iteration = context.get('iteration', 0)
        findings = context.get('findings', [])
        recent_actions = context.get('recent_actions', [])
        thought = context.get('thought', '')
        
        # Check 1: Has AI explicitly stated completion?
        if any(word in thought.lower() for word in ['complete', 'finished', 'done', 'accomplished']):
            if 'no more' in thought.lower() or 'cannot proceed' in thought.lower():
                return False, "AI determined task complete"
        
        # Check 2: Found critical vulnerability and exploited?
        if len(findings) > 0:
            for finding in findings:
                if any(word in str(finding).lower() for word in ['exploited', 'dumped', 'pwned', 'shell']):
                    # Give a few more iterations to document/verify
                    if iteration > context.get('last_critical_finding', 0) + 3:
                        return False, "Critical vulnerability found and exploited"
        
        # Check 3: Stuck in loop (same action repeated)?
        if len(recent_actions) >= 3:
            last_three = recent_actions[-3:]
            # Check if all three are similar
            if len(set(last_three)) == 1:  # Exact same action 3 times
                self.iterations_without_progress += 1
                if self.iterations_without_progress >= 3:
                    return False, "AI stuck in repetitive loop"
        else:
            self.iterations_without_progress = 0
        
        # Check 4: No new findings in many iterations?
        current_findings_count = len(findings)
        if current_findings_count == self.total_findings:
            self.iterations_without_progress += 1
            if self.iterations_without_progress >= 5:
                return False, "No progress after 5 iterations"
        else:
            self.total_findings = current_findings_count
            self.iterations_without_progress = 0
        
        # Check 5: Reasonable iteration limit for safety
        if iteration >= 100:
            return False, "Safety limit reached (100 iterations)"
        
        # Continue testing
        return True, None
    
    def update_state(self, findings: List, actions: List):
        """Update current state based on findings and actions"""
        # Determine current phase based on actions
        recent_actions_str = ' '.join(str(a).lower() for a in actions[-3:])
        
        if any(word in recent_actions_str for word in ['nmap', 'dig', 'whois', 'whatweb']):
            new_state = ProgressState.RECONNAISSANCE
        elif any(word in recent_actions_str for word in ['nikto', 'nuclei', 'wpscan']):
            new_state = ProgressState.SCANNING
        elif any(word in recent_actions_str for word in ['sqlmap', 'xss', 'ffuf']):
            new_state = ProgressState.TESTING
        elif any(word in recent_actions_str for word in ['exploit', 'dump', 'shell']):
            new_state = ProgressState.EXPLOITING
        else:
            new_state = self.state
        
        # Track phase changes (good sign of progress)
        if new_state != self.state:
            self.phase_changes += 1
            self.state = new_state
    
    def get_progress_summary(self) -> str:
        """Get human-readable progress summary"""
        return f"""
Phase: {self.state.value.upper()}
Findings: {self.total_findings}
Phase Changes: {self.phase_changes}
Progress Quality: {"GOOD" if self.iterations_without_progress < 2 else "SLOW"}
"""
    
    def reset(self):
        """Reset controller for new task"""
        self.state = ProgressState.INITIALIZING
        self.iterations_without_progress = 0
        self.total_findings = 0
        self.critical_findings = 0
        self.action_history = []
        self.phase_changes = 0
