"""
Session Management for BugPilot CLI
Save and load pentesting sessions like professional CLI tools
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional


class SessionManager:
    """Manages pentesting sessions - save, load, export results"""
    
    def __init__(self):
        self.sessions_dir = Path.home() / ".bugpilot" / "sessions"
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
        self.current_session = None
        
    def create_session(self, objective: str) -> Dict[str, Any]:
        """Create a new session"""
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        session = {
            "id": session_id,
            "objective": objective,
            "created_at": datetime.now().isoformat(),
            "iterations": [],
            "findings": [],
            "commands_run": [],
            "status": "active"
        }
        self.current_session = session
        return session
    
    def add_iteration(self, thought: str, action: Dict, observation: Dict, analysis: str):
        """Add an iteration to current session"""
        if not self.current_session:
            return
            
        iteration = {
            "iteration_num": len(self.current_session["iterations"]) + 1,
            "timestamp": datetime.now().isoformat(),
            "thought": thought,
            "action": action,
            "observation": observation,
            "analysis": analysis
        }
        
        self.current_session["iterations"].append(iteration)
        self.current_session["commands_run"].append({
            "command": action.get("command"),
            "success": observation.get("success"),
            "timestamp": iteration["timestamp"]
        })
        
    def add_finding(self, finding: Dict):
        """Add a security finding"""
        if not self.current_session:
            return
        self.current_session["findings"].append({
            **finding,
            "discovered_at": datetime.now().isoformat()
        })
    
    def save_session(self) -> str:
        """Save current session to file"""
        if not self.current_session:
            return None
            
        session_file = self.sessions_dir / f"session_{self.current_session['id']}.json"
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(self.current_session, f, indent=2, ensure_ascii=False)
        
        return str(session_file)
    
    def export_results(self, filepath: str, format: str = "txt") -> bool:
        """Export results to file (txt, json, md)"""
        if not self.current_session:
            return False
            
        try:
            if format == "json":
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(self.current_session, f, indent=2)
                    
            elif format == "md":
                content = self._generate_markdown_report()
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                    
            else:  # txt
                content = self._generate_text_report()
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
            
            return True
        except Exception as e:
            print(f"Export error: {e}")
            return False
    
    def _generate_text_report(self) -> str:
        """Generate plain text report"""
        session = self.current_session
        lines = []
        lines.append("=" * 80)
        lines.append("BUGPILOT PENETRATION TESTING SESSION REPORT")
        lines.append("=" * 80)
        lines.append(f"\nSession ID: {session['id']}")
        lines.append(f"Objective: {session['objective']}")
        lines.append(f"Created: {session['created_at']}")
        lines.append(f"Total Iterations: {len(session['iterations'])}")
        lines.append(f"Commands Executed: {len(session['commands_run'])}")
        lines.append(f"Findings: {len(session['findings'])}")
        
        lines.append("\n" + "=" * 80)
        lines.append("EXECUTED COMMANDS")
        lines.append("=" * 80)
        for i, cmd in enumerate(session['commands_run'], 1):
            status = "[+]" if cmd['success'] else "[-]"
            lines.append(f"\n{i}. {status} {cmd['command']}")
            lines.append(f"   Time: {cmd['timestamp']}")
        
        if session['findings']:
            lines.append("\n" + "=" * 80)
            lines.append("SECURITY FINDINGS")
            lines.append("=" * 80)
            for i, finding in enumerate(session['findings'], 1):
                lines.append(f"\n{i}. {finding.get('title', 'Finding')}")
                lines.append(f"   Severity: {finding.get('severity', 'Unknown')}")
                lines.append(f"   Description: {finding.get('description', 'N/A')}")
        
        lines.append("\n" + "=" * 80)
        lines.append("END OF REPORT")
        lines.append("=" * 80)
        
        return "\n".join(lines)
    
    def _generate_markdown_report(self) -> str:
        """Generate markdown report"""
        session = self.current_session
        lines = []
        lines.append(f"# BugPilot Penetration Testing Report")
        lines.append(f"\n**Session ID:** `{session['id']}`")
        lines.append(f"**Objective:** {session['objective']}")
        lines.append(f"**Created:** {session['created_at']}")
        lines.append(f"\n## Session Statistics")
        lines.append(f"- **Total Iterations:** {len(session['iterations'])}")
        lines.append(f"- **Commands Executed:** {len(session['commands_run'])}")
        lines.append(f"- **Findings:** {len(session['findings'])}")
        
        lines.append(f"\n## Executed Commands")
        for i, cmd in enumerate(session['commands_run'], 1):
            status = "✓" if cmd['success'] else "✗"
            lines.append(f"\n{i}. **{status}** `{cmd['command']}`")
            lines.append(f"   - Time: {cmd['timestamp']}")
        
        if session['findings']:
            lines.append(f"\n## Security Findings")
            for i, finding in enumerate(session['findings'], 1):
                lines.append(f"\n### {i}. {finding.get('title', 'Finding')}")
                lines.append(f"**Severity:** {finding.get('severity', 'Unknown')}")
                lines.append(f"\n{finding.get('description', 'N/A')}")
        
        return "\n".join(lines)
    
    def list_sessions(self) -> List[Dict]:
        """List all saved sessions"""
        sessions = []
        for file in self.sessions_dir.glob("session_*.json"):
            try:
                with open(file, 'r', encoding='utf-8') as f:
                    session = json.load(f)
                    sessions.append({
                        "id": session['id'],
                        "objective": session['objective'],
                        "created_at": session['created_at'],
                        "iterations": len(session.get('iterations', []))
                    })
            except:
                pass
        return sessions
    
    def load_session(self, session_id: str) -> Optional[Dict]:
        """Load a saved session"""
        session_file = self.sessions_dir / f"session_{session_id}.json"
        if session_file.exists():
            with open(session_file, 'r', encoding='utf-8') as f:
                self.current_session = json.load(f)
                return self.current_session
        return None
