"""
Advanced ReAct Agent System for BugPilot
Implements Reasoning + Acting pattern with multi-agent architecture
"""

import json
import re
import platform
from typing import List, Dict, Tuple, Optional, Any
from enum import Enum

# v1.4.0 Intelligence Modules
try:
    from .exploit_generator import ExploitGenerator
    from .advanced_tools import AdvancedToolSelector
    from .autonomous_controller import AutonomousController
    from .knowledge_base import KnowledgeBase
    from .dynamic_context import DynamicContext
    from .logic_engine import LogicEngine
    from .status_bar import StatusBar, estimate_tokens, estimate_context_size
    INTELLIGENCE_MODULES_AVAILABLE = True
except ImportError:
    INTELLIGENCE_MODULES_AVAILABLE = False


class AgentRole(Enum):
    """Agent roles in the system"""
    PLANNER = "planner"
    EXECUTOR = "executor"
    ANALYST = "analyst"
    CRITIC = "critic"


class ThoughtType(Enum):
    """Types of thoughts in ReAct loop"""
    OBSERVATION = "observation"
    THOUGHT = "thought"
    ACTION = "action"
    REFLECTION = "reflection"


class AdvancedAgenticEngine:
    """
    Advanced Multi-Agent System using ReAct Pattern
    
    Architecture:
    - Planner Agent: Creates strategic plans
    - Executor Agent: Runs commands
    - Analyst Agent: Interprets results
    - Critic Agent: Evaluates success
    
    Uses ReAct Loop: Thought → Action → Observation → Reflection
    """
    
    def __init__(self, model, ui, task_objective: str):
        self.model = model
        self.ui = ui
        self.task_objective = task_objective
        
        # Import session management
        from .session_manager import SessionManager
        from .file_exporter import FileExporter
        
        self.session_manager = SessionManager()
        self.file_exporter = FileExporter()
        
        # v1.4.0 Intelligence Components
        if INTELLIGENCE_MODULES_AVAILABLE:
            self.exploit_generator = ExploitGenerator()
            self.tool_selector = AdvancedToolSelector()
            self.autonomous_controller = AutonomousController()
            self.knowledge_base = KnowledgeBase()
            self.context_engine = DynamicContext()
            self.logic_engine = LogicEngine()
            self.status_bar = StatusBar(ui.console) if hasattr(ui, 'console') else None
        else:
            self.exploit_generator = None
            self.tool_selector = None
            self.autonomous_controller = None
            self.status_bar = None
        
        # Start new session
        self.session = self.session_manager.create_session(task_objective)
        
        # Agent memory system
        self.working_memory = []  # Short-term memory (current task)
        self.long_term_memory = []  # Long-term memory (learned patterns)
        self.episodic_memory = []  # Episode memory (past actions)
        
        # Task state
        self.current_plan = []
        self.executed_actions = []
        self.findings = {}
        self.iteration = 0
        self.max_iterations = 100  # v1.4.0: Autonomous until task complete
        
        # Success criteria
        self.success_indicators = [
            "scan complete", "enumeration done", "vulnerabilities found",
            "testing complete", "assessment finished"
        ]
        
    def reset(self, objective: str):
        """Reset agent state for new task"""
        self.task_objective = objective
        self.working_memory = []
        self.executed_actions = []
        self.findings = {}
        self.iteration = 0
        
    def run_autonomous_session(self) -> Dict[str, Any]:
        """
        Run complete autonomous ReAct session
        
        Returns comprehensive session results
        """
        if not self.task_objective:
            return {"error": "No task objective set"}
            
        # === PHASE 1: PLANNING ===
        plan = self._planner_agent(self.task_objective)
        self.current_plan = plan
        
        self.ui.print_panel(
            self._format_plan(plan),
            title="[*] Planner Agent - Strategic Plan",
            style="primary"
        )
        
        # === PHASE 2: REACT LOOP ===
        while self.iteration < self.max_iterations:
            self.iteration += 1
            
            # Show progress
            self.ui.print_message(f"\n[*] Iteration {self.iteration}/{self.max_iterations}", style="cyan")
            
            # THOUGHT: Reason about current state
            thought = self._generate_thought()
            self.ui.print_panel(
                thought,
                title=f"[>>] Thought #{self.iteration}",
                style="info"
            )
            
            # ACTION: Decide next action
            action = self._decide_action(thought)
            
            if action is None:
                # Agent decided task is complete
                break
            
            self.ui.print_panel(
                action['command'],
                title=f"[!] Action #{self.iteration}",
                style="warning"
            )
            
            # EXECUTE: Run the action
            observation = self._executor_agent(action)
            self.ui.print_panel(
                observation['summary'],
                title=f"[+] Observation #{self.iteration}" if observation['success'] else f"[-] Observation #{self.iteration}",
                style="success" if observation['success'] else "error"
            )
            
            # ANALYSIS: Analyze results
            analysis = self._analyst_agent(observation)
            self.ui.print_panel(
                analysis,
                title=f"[*] Analysis #{self.iteration}",
                style="primary"
            )
            
            # REFLECTION: Self-critique
            reflection = self._critic_agent(analysis, observation)
            
            if reflection['should_stop']:
                self.ui.print_panel(
                    reflection['reason'],
                    title="[COMPLETE] Critic Agent - Task Complete",
                    style="success"
                )
                break
            
            # Update memory
            self._update_memory(thought, action, observation, analysis, reflection)
        
        # === PHASE 3: FINAL REPORT ===
        report = self._generate_final_report()
        
        return report
    
    def _planner_agent(self, objective: str) -> List[Dict]:
        """
        Planner Agent: Creates strategic multi-step plan
        Uses Chain of Thought reasoning
        """
        prompt = f"""You are a master penetration testing strategist.

**OBJECTIVE:** {objective}

**YOUR TASK:** Create a comprehensive, step-by-step strategic plan.

Think through this methodically:

1. **RECONNAISSANCE:** What information do we need first?
2. **SCANNING:** What tools should we use?
3. **ENUMERATION:** What services to enumerate?
4. **EXPLOITATION:** What vulnerabilities to test?
5. **POST-EXPLOITATION:** What to do if successful?

Respond in this EXACT format:

```json
{{
  "methodology": "Brief explanation of approach",
  "steps": [
    {{
      "phase": "Reconnaissance",
      "goal": "Discover target information",
      "actions": ["action 1", "action 2"],
      "expected_findings": "What we expect to find"
    }},
    {{
      "phase": "Scanning",
      "goal": "Identify open ports and services",
      "actions": ["nmap scan", "service detection"],
      "expected_findings": "Open ports, service versions"
    }}
  ],
  "success_criteria": "How we know when we're done"
}}
```

Think like an elite pentester. Be thorough but efficient."""

        response = self.model.generate(prompt)
        plan = self._parse_json_response(response)
        
        return plan.get('steps', [])
    
    def _generate_thought(self) -> str:
        """
        Generate reasoning using Dynamic Context + AI Intelligence
        """
        from .prompts import INTELLIGENT_DECISION_PROMPT, ADVANCED_TOOL_KNOWLEDGE
        
        # 1. Get Dynamic Context (Environment + Target Parse)
        target_url = self.task_objective if "http" in self.task_objective else ""
        dynamic_context = self.context_engine.parse_target(target_url)
        available_tools = self.context_engine.get_tool_arsenal()
        
        previous_findings = "\n".join([f"- {f}" for f in self.findings.values()]) or "None"
        recent_actions = "\n".join([f"- {a.get('command', '')}" for a in self.executed_actions[-5:]]) or "Starting"
        
        prompt = f"""{ADVANCED_TOOL_KNOWLEDGE}

{INTELLIGENT_DECISION_PROMPT}

**DYNAMIC ENVIRONMENT:**
- TOOLS AVAILABLE: {available_tools}
- TARGET ANALYSIS:
{dynamic_context}

**TASK:** {self.task_objective}
**FINDINGS:** {previous_findings}
**RECENT ACTIONS:** {recent_actions}

Think like an elite hacker. Use the available tools and target analysis to decide the smartest next step.
"""
        
        try:
            return self.model.generate(prompt)
        except Exception as e:
             return f"Error thinking: {e}"
    
    
    def _decide_action(self, thought: str) -> Optional[Dict]:
        """
        Decide next action - NOW OS-AWARE
        """
        import platform
        os_type = platform.system()
        
        # Get failed commands to avoid
        failed_commands = [action['command'] for action in self.executed_actions[-5:] 
                          if not action.get('success', False)]
        
        prompt = f"""Based on this reasoning: "{thought}"

**OBJECTIVE:** {self.task_objective}
**OPERATING SYSTEM:** {os_type}
**FAILED COMMANDS (DO NOT REPEAT):** {', '.join(failed_commands) if failed_commands else 'None'}

**OS-APPROPRIATE COMMANDS:**

Windows:
  DNS Lookup: nslookup domain.com, Resolve-DnsName domain.com
  IP Info: ping domain.com
  Network: ipconfig, netstat -an
  Web Requests: curl url, Invoke-WebRequest url

Internal Tools (ALWAYS AVAILABLE):
  install_tool <tool_name>
  check_cve <product> <version>
  owasp_check <category>

Linux/macOS:
  DNS Lookup: dig +short domain.com, host domain.com, nslookup domain.com
  Port Scan: nmap -p- domain.com
  Network: ifconfig, netstat -tuln
  Web Requests: curl url, wget url

**CRITICAL INSTRUCTIONS:**
1. Use ONLY commands that work on {os_type}
2. DO NOT repeat any failed commands
3. If "dig" failed, use "nslookup" (works on all OS)
4. Be specific and executable

Generate the exact command to run next.

Respond in JSON format:
{{
  "action_type": "dns|scan|enumerate|exploit|custom|complete",
  "command": "exact command here",  
  "tool": "tool name",
  "reasoning": "why this command",
If task is complete, set is_complete: true and command: null"""

        response = self.model.generate(prompt)
        action = self._parse_json_response(response)
        
        if action.get('is_complete') or not action.get('command'):
            return None
        
        return action
    
    def _executor_agent(self, action: Dict) -> Dict:
        """
        Executor Agent: Direct subprocess execution without restrictions
        """
        import subprocess
        import os
        
        command = action['command']
        
        
        # Knowledge Base Internal Tools
        if action['command'].startswith('check_cve'):
            parts = action['command'].split()
            if len(parts) >= 2:
                product = parts[1]
                version = parts[2] if len(parts) > 2 else ""
                msg = f"[i] Consulting Knowledge Base for {product} {version}..."
                if hasattr(self.ui, 'print_message'):
                    self.ui.print_message(msg, style="cyan")
                else:
                    self.ui.print(msg)
                    
                output = self.knowledge_base.search_cve(product, version)
                return {
                    "success": True, 
                    "output": output,
                    "command": action['command'],
                    "summary": f"CVE Search: Found info for {product}"
                }
        
        if action['command'].startswith('owasp_check'):
            parts = action['command'].split()
            category = parts[1] if len(parts) > 1 else ""
            msg = f"[i] Retrieving OWASP guidelines for {category}..."
            if hasattr(self.ui, 'print_message'):
                self.ui.print_message(msg, style="cyan")
            else:
                self.ui.print(msg)
                
            output = self.knowledge_base.get_owasp_info(category)
            return {
                "success": True, 
                "output": output,
                "command": action['command'],
                "summary": f"OWASP Guide: Retrieved for {category}"
            }
            
        
        if action['command'].startswith('install_tool'):
            parts = action['command'].split()
            tool_name = parts[1] if len(parts) > 1 else ""
            if not tool_name:
                return {"success": False, "output": "No tool name provided for installation."}

            msg = f"[i] Autonomously installing tool: {tool_name}..."
            if hasattr(self.ui, 'print_message'):
                self.ui.print_message(msg, style="cyan")
            else:
                self.ui.print(msg)
                
            output = self.tool_manager.install_tool(tool_name)
            success = "Successfully" in output
            
            return {
                "success": success, 
                "output": output,
                "command": action['command'],
                "summary": f"Tool Installation: {tool_name} -> {success}"
            }

        # Determine shell based on OS
        if os.name == 'nt':  # Windows
            shell_cmd = ['powershell', '-Command', command]
        else:  # Linux/Termux/Mac
            shell_cmd = ['bash', '-c', command]
        
        # Execute command directly
        try:
            result = subprocess.run(
                shell_cmd,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minutes max
                cwd=os.getcwd()
            )
            
            output = result.stdout + result.stderr
            returncode = result.returncode
            
            # Save to episodic memory
            self.executed_actions.append({
                'iteration': self.iteration,
                'command': command,
                'tool': action.get('tool', 'unknown'),
                'output': output[:1000],  # Truncate
                'success': returncode == 0
            })
            
            return {
                'success': returncode == 0,
                'command': command,
                'output': output,
                'returncode': returncode,
                'summary': self._summarize_output(output, returncode)
            }
        except subprocess.TimeoutExpired:
            return {
                'success': False,
                'command': command,
                'output': 'Command timed out after 5 minutes',
                'returncode': -1,
                'summary': 'TIMEOUT: Command exceeded 5 minute limit'
            }
        except Exception as e:
            return {
                'success': False,
                'command': command,
                'output': str(e),
                'returncode': -1,
                'summary': f'ERROR: {str(e)}'
            }
    
    def _analyst_agent(self, observation: Dict) -> str:
        """
        Analyst Agent: Interprets command results
        Extracts key findings
        """
        prompt = f"""You are analyzing penetration testing results.

**COMMAND EXECUTED:** {observation['command']}
**SUCCESS:** {observation['success']}
**OUTPUT:**
{observation['output'][:2000]}

**ANALYZE:**

1. **Key Findings:** What important information did we discover?
2. **Vulnerabilities:** Any security issues found?
3. **Next Implications:** What does this mean for next steps?
4. **Data Extraction:** IPs, ports, versions, technologies?

Respond in this format:

```json
{{
  "key_findings": ["finding 1", "finding 2"],
  "vulnerabilities": ["vuln 1", "vuln 2"],
  "extracted_data": {{
    "ips": [],
    "ports": [],
    "services": [],
    "technologies": []
  }},
  "severity": "low|medium|high|critical",
  "next_implications": "What this means for next steps"
}}
```"""

        response = self.model.generate(prompt)
        analysis_data = self._parse_json_response(response)
        
        # Update findings
        if analysis_data.get('key_findings'):
            self.findings[f"iteration_{self.iteration}"] = analysis_data
        
        # Format for display
        formatted = f"""**Key Findings:**
{self._format_list(analysis_data.get('key_findings', []))}

**Vulnerabilities:**
{self._format_list(analysis_data.get('vulnerabilities', ['None detected']))}

**Severity:** {analysis_data.get('severity', 'unknown').upper()}

**Next Implications:**
{analysis_data.get('next_implications', 'Analyzing...')}"""
        
        return formatted
    
    def _critic_agent(self, analysis: str, observation: Dict) -> Dict:
        """
        Critic Agent: Evaluates if task is complete
        Provides self-reflection
        """
        prompt = f"""You are evaluating if the penetration testing objective is met.

**OBJECTIVE:** {self.task_objective}

**ITERATIONS:** {self.iteration}/{self.max_iterations}

**LATEST ANALYSIS:**
{analysis}

**TOTAL FINDINGS:** {len(self.findings)}

**EVALUATE:**

1. Have we met the objective?
2. Is more testing needed?
3. Should we stop or continue?

Respond in this format:

```json
{{
  "objective_met": true/false,
  "confidence": 0.0-1.0,
  "should_stop": true/false,
  "reason": "Why we should stop or continue",
  "missing_steps": ["what's left to do"]
}}
```"""

        response = self.model.generate(prompt)
        critique = self._parse_json_response(response)
        
        return critique
    
    def _update_memory(self, thought, action, observation, analysis, reflection):
        """Update agent memory systems"""
        # Working memory (last 5 items)
        self.working_memory.append({
            'iteration': self.iteration,
            'thought': thought,
            'action': action,
            'observation': observation['summary'],
            'analysis': analysis
        })
        
        if len(self.working_memory) > 5:
            self.working_memory.pop(0)
    
    def _generate_final_report(self) -> Dict:
        """Generate comprehensive final report"""
        return {
            'objective': self.task_objective,
            'iterations': self.iteration,
            'actions_taken': len(self.executed_actions),
            'findings': self.findings,
            'executed_actions': self.executed_actions,
            'success': len(self.findings) > 0
        }
    
    def _parse_json_response(self, response: str) -> Dict:
        """Parse JSON from AI response"""
        try:
            # Extract JSON from markdown code blocks
            json_match = re.search(r'```json\s*(.*?)\s*```', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(1))
            
            # Try direct parsing
            return json.loads(response)
        except:
            return {}
    
    def _summarize_output(self, output: str, returncode: int) -> str:
        """Summarize command output"""
        if returncode != 0:
            return f"Command failed (code {returncode})"
        
        lines = output.strip().split('\n')
        if len(lines) <= 10:
            return output
        
        return '\n'.join(lines[:10]) + f"\n... ({len(lines)-10} more lines)"
    
    def _build_context(self) -> str:
        """Build context from memory"""
        if not self.working_memory:
            return "No previous actions"
        
        return "\n".join([
            f"Iteration {m['iteration']}: {m['action'].get('command', 'N/A')}"
            for m in self.working_memory[-3:]
        ])
    
    def _format_memory(self, limit: int = 3) -> str:
        """Format recent memory for display"""
        if not self.working_memory:
            return "No previous actions"
        
        recent = self.working_memory[-limit:]
        formatted = []
        
        for mem in recent:
            formatted.append(
                f"• Iteration {mem['iteration']}: {mem['action'].get('reasoning', 'Action taken')}"
            )
        
        return '\n'.join(formatted)
    
    def _format_plan(self, plan: List[Dict]) -> str:
        """Format plan for display"""
        if not plan:
            return "No plan generated"
        
        formatted = []
        for i, step in enumerate(plan, 1):
            formatted.append(f"""**Phase {i}: {step.get('phase', 'Unknown')}**
Goal: {step.get('goal', 'N/A')}
Actions: {', '.join(step.get('actions', []))}
Expected: {step.get('expected_findings', 'N/A')}
""")
        
        return '\n'.join(formatted)
    
    def _format_list(self, items: List[str]) -> str:
        """Format list for display"""
        if not items:
            return "• None"
        return '\n'.join([f"• {item}" for item in items])


        