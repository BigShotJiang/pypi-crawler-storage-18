"""
Tool Manager - BugPilot v1.6.0
Autonomously manages tool installation and dependencies.
"""

import shutil
import platform
import subprocess
import sys

class ToolManager:
    """
    Handles autonomous installation of hacking tools.
    Detects OS and uses the correct package manager.
    """
    
    def __init__(self):
        self.os_type = platform.system().lower()
        self.pkg_manager = self._detect_package_manager()
        
    def _detect_package_manager(self) -> str:
        """Detect available package manager"""
        if self.os_type == "linux":
            if shutil.which("apt"): return "apt"
            if shutil.which("pkg"): return "pkg" # Termux
            if shutil.which("pacman"): return "pacman"
            if shutil.which("yum"): return "yum"
        elif self.os_type == "darwin": # MacOS
            if shutil.which("brew"): return "brew"
        elif self.os_type == "windows":
            if shutil.which("choco"): return "choco"
            if shutil.which("winget"): return "winget"
            # Pip is universal fallback for python tools
        return "pip" 

    def install_tool(self, tool_name: str) -> str:
        """
        Attempts to install a tool autonomously.
        """
        # 1. Specialized Python Tools (Best installed via pip)
        python_tools = ["sqlmap", "xsstrike", "dirsearch", "commix", "wapiti"]
        if tool_name.lower() in python_tools or tool_name.startswith("py-"):
            return self._install_pip(tool_name.replace("py-", ""))
            
        # 2. System Tools
        if self.pkg_manager == "apt":
            return self._install_apt(tool_name)
        elif self.pkg_manager == "pkg":
            return self._install_pkg(tool_name)
        elif self.pkg_manager == "brew":
            return self._install_brew(tool_name)
        elif self.pkg_manager == "choco":
            return self._install_choco(tool_name)
        elif self.pkg_manager == "pip":
            # Fallback to pip if allowed
            return self._install_pip(tool_name)
            
        return f"Could not determine how to install '{tool_name}' on {self.os_type}."

    def _install_pip(self, tool_name: str) -> str:
        try:
            print(f"[*] Installing {tool_name} via pip...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", tool_name])
            return f"✓ Successfully installed {tool_name} via pip."
        except Exception as e:
            return f"✗ Failed to install {tool_name} via pip: {e}"

    def _install_apt(self, tool_name: str) -> str:
        try:
            print(f"[*] Installing {tool_name} via apt...")
            # Run non-interactive
            cmd = ["sudo", "apt", "install", "-y", tool_name]
            subprocess.check_call(cmd)
            return f"✓ Successfully installed {tool_name} via apt."
        except Exception as e:
            return f"✗ Failed to install {tool_name} via apt. (Do you have sudo?): {e}"

    def _install_pkg(self, tool_name: str) -> str:
        try:
            print(f"[*] Installing {tool_name} via pkg...")
            subprocess.check_call(["pkg", "install", "-y", tool_name])
            return f"✓ Successfully installed {tool_name} via pkg."
        except Exception as e:
            return f"✗ Failed to install {tool_name} via pkg: {e}"

    def _install_choco(self, tool_name: str) -> str:
        try:
            print(f"[*] Installing {tool_name} via choco...")
            subprocess.check_call(["choco", "install", tool_name, "-y"])
            return f"✓ Successfully installed {tool_name} via choco."
        except Exception as e:
            return f"✗ Failed to install {tool_name} via choco: {e}"
