"""
Autopilot Mode for BugPilot CLI
Autonomous vulnerability discovery with self-iteration
Like advanced AI assistants with full autonomy
"""

from typing import Dict, List, Optional
import re
from pathlib import Path


class AutopilotEngine:
    """Autonomous pentesting with self-iteration and decision making"""
    
    def __init__(self, model, ui, context_manager, file_exporter):
        self.model = model
        self.ui = ui
        self.context = context_manager
        self.exporter = file_exporter
        self.max_iterations = 50  # Can iterate up to 50 times
        self.current_iteration = 0
        self.findings = []
        self.pocs_written = []
        self.autonomous_mode = False
    
    def activate_autopilot(self, objective: str, target_folder: Optional[str] = None):
        """Activate full autopilot mode"""
        self.autonomous_mode = True
        self.ui.print_panel(
            f"**AUTOPILOT ACTIVATED**\n\nObjective: {objective}\n"
            f"Max Iterations: {self.max_iterations}\n"
            f"Target: {target_folder or 'Current context'}",
            title="[AUTOPILOT] Autonomous Mode",
            style="warning"
        )
        
        # Add folder to context if provided
        if target_folder:
            self.context.add_folder_reference(target_folder, "vulnerability_scan")
        
        return self._run_autopilot(objective)
    
    def _run_autopilot(self, objective: str) -> Dict:
        """Run autonomous iteration loop"""
        while self.current_iteration < self.max_iterations:
            self.current_iteration += 1
            
            self.ui.print_message(
                f"\n[AUTOPILOT] Iteration {self.current_iteration}/{self.max_iterations}",
                style="cyan"
            )
            
            # Make autonomous decision
            decision = self._make_decision(objective)
            
            if decision.get('complete'):
                self.ui.print_panel(
                    decision.get('reason', 'Objective complete'),
                    title="[AUTOPILOT] Mission Complete",
                    style="success"
                )
                break
            
            # Execute decision
            result = self._execute_decision(decision)
            
            # Analyze result
            analysis = self._analyze_result(result)
            
            # Check for vulnerabilities
            vulnerability = self._check_vulnerability(analysis)
            
            if vulnerability:
                self.findings.append(vulnerability)
                self.context.add_finding(vulnerability)
                
                # Write PoC if needed
                if decision.get('write_poc'):
                    poc_path = self._write_poc(vulnerability)
                    if poc_path:
                        self.pocs_written.append(poc_path)
                        self.ui.print_success(f"PoC written: {poc_path}")
        
        return self._generate_autopilot_report()
    
    def _make_decision(self, objective: str) -> Dict:
        """Make autonomous decision about next action"""
        context = self.context.get_relevant_context(objective)
        
        prompt = f"""You are in AUTOPILOT MODE - fully autonomous pentesting.

**OBJECTIVE:** {objective}
**ITERATION:** {self.current_iteration}/{self.max_iterations}
**FINDINGS SO FAR:** {len(self.findings)} vulnerabilities found

**YOUR CAPABILITIES:**
1. Analyze source code files
2. Run security scans
3. Identify vulnerabilities
4. Write Proof-of-Concept exploits
5. Make autonomous decisions
6. Iterate and adapt

**CONTEXT:**
{self._format_context(context)}

**DECISION FRAMEWORK:**
- If analyzing code: Look for SQL injection, XSS, auth issues, etc.
- If found vulnerability: Classify severity, write PoC
- If need more info: Request file analysis or run scan
- If objective complete: Return complete=true

**AUTONOMOUS DECISION:**
What should you do next? Consider:
1. What files to analyze?
2. What vulnerabilities to test for?
3. Should you write a PoC?
4. Are you done or should you iterate more?

Respond in JSON:
{{
  "action": "analyze_file|run_scan|write_poc|complete",
  "target": "file/folder path or command",
  "reason": "why this action",
  "write_poc": true/false,
  "expected_finding": "what vulnerability you expect",
  "complete": false
}}

If done: {{"complete": true, "reason": "why complete"}}

MAKE YOUR AUTONOMOUS DECISION:"""

        response = self.model.generate(prompt, context)
        return self._parse_json_response(response)
    
    def _execute_decision(self, decision: Dict) -> Dict:
        """Execute the autonomous decision"""
        action = decision.get('action')
        target = decision.get('target', '')
        
        if action == 'analyze_file':
            return self._analyze_file(target)
        
        elif action == 'run_scan':
            return self._run_scan(target)
        
        elif action == 'write_poc':
            return self._write_poc_from_decision(decision)
        
        return {"success": False, "error": "Unknown action"}
    
    def _analyze_file(self, filepath: str) -> Dict:
        """Analyze a source code file for vulnerabilities"""
        # Add file to context
        if self.context.add_file_reference(filepath, "vulnerability_analysis"):
            file_ref = self.context.file_references[filepath]
            
            prompt = f"""Analyze this source code for security vulnerabilities:

**FILE:** {filepath}
**SIZE:** {file_ref['size']} bytes

**CODE:**
```
{file_ref['content']}
```

**FIND:**
1. SQL Injection points
2. XSS vulnerabilities
3. Authentication bypasses
4. Authorization issues
5. Path traversal
6. Command injection
7. Any other security issues

Respond with JSON:
{{
  "vulnerabilities": [
    {{
      "type": "SQL Injection",
      "severity": "critical|high|medium|low",
      "line": 42,
      "code": "vulnerable code snippet",
      "description": "explanation",
      "poc_idea": "how to exploit"
    }}
  ]
}}"""

            response = self.model.generate(prompt, [])
            return self._parse_json_response(response)
        
        return {"error": "File not found"}
    
    def _run_scan(self, command: str) -> Dict:
        """Run a security scan command"""
        import subprocess
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
                "error": result.stderr
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _analyze_result(self, result: Dict) -> str:
        """Analyze execution result"""
        if result.get('vulnerabilities'):
            return f"Found {len(result['vulnerabilities'])} potential vulnerabilities"
        elif result.get('output'):
            return f"Scan output: {result['output'][:500]}"
        return "No clear vulnerabilities detected"
    
    def _check_vulnerability(self, analysis: str) -> Optional[Dict]:
        """Check if analysis reveals a vulnerability"""
        # This would be enhanced with actual vulnerability detection
        if 'vulnerability' in analysis.lower() or 'vulnerable' in analysis.lower():
            return {
                "title": "Potential Vulnerability Detected",
                "severity": "medium",
                "description": analysis,
                "iteration": self.current_iteration
            }
        return None
    
    def _write_poc(self, vulnerability: Dict) -> Optional[str]:
        """Write Proof-of-Concept exploit to file"""
        prompt = f"""Write a Proof-of-Concept exploit for this vulnerability:

**VULNERABILITY:**
{vulnerability}

**PoC REQUIREMENTS:**
1. Clear, working code
2. Comments explaining each step
3. Safe to run (no actual damage)
4. Demonstrates the vulnerability

Write the complete PoC code:"""

        poc_code = self.model.generate(prompt, [])
        
        # Save PoC to file
        poc_filename = f"poc_{vulnerability.get('type', 'vuln').replace(' ', '_').lower()}_{self.current_iteration}.py"
        poc_path = Path.cwd() / "pocs" / poc_filename
        poc_path.parent.mkdir(exist_ok=True)
        
        with open(poc_path, 'w', encoding='utf-8') as f:
            f.write(f"# Proof-of-Concept for {vulnerability.get('title', 'Vulnerability')}\n")
            f.write(f"# Severity: {vulnerability.get('severity', 'unknown')}\n")
            f.write(f"# Generated by BugPilot Autopilot\n\n")
            f.write(poc_code)
        
        return str(poc_path)
    
    def _write_poc_from_decision(self, decision: Dict) -> Dict:
        """Write PoC based on decision"""
        # Implementation for writing PoC
        return {"success": True, "message": "PoC written"}
    
    def _format_context(self, context: List[Dict]) -> str:
        """Format context for prompt"""
        formatted = ""
        for msg in context[-3:]:  # Last 3 messages
            formatted += f"{msg.get('role', 'user')}: {msg.get('content', '')[:200]}...\n"
        return formatted
    
    def _parse_json_response(self, response: str) -> Dict:
        """Parse JSON from AI response"""
        try:
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                import json
                return json.loads(json_match.group())
        except:
            pass
        return {}
    
    def _generate_autopilot_report(self) -> Dict:
        """Generate final autopilot report"""
        report = {
            "objective": "Autopilot mission",
            "iterations": self.current_iteration,
            "findings": len(self.findings),
            "pocs_written": len(self.pocs_written),
            "vulnerabilities": self.findings,
            "poc_files": self.pocs_written
        }
        
        # Write report to file
        report_path = self.exporter.save_custom(
            json.dumps(report, indent=2),
            "autopilot_report.json"
        )
        
        return report
