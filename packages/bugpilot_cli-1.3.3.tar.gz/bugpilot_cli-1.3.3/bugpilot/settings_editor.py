"""
Interactive Settings Editor for BugPilot CLI
User-friendly interface to customize all settings
"""

from typing import Dict, Any, Optional
from pathlib import Path
import json


class SettingsEditor:
    """Interactive settings editor with visual interface"""
    
    def __init__(self, config_manager, ui):
        self.config = config_manager
        self.ui = ui
        self.settings_categories = self._define_settings()
    
    def _define_settings(self) -> Dict[str, Dict]:
        """Define all available settings with metadata"""
        return {
            "AI Model": {
                "provider": {
                    "value": self.config.config.model.provider,
                    "type": "choice",
                    "options": ["gemini", "groq", "anthropic", "ollama"],
                    "description": "AI provider to use"
                },
                "model_name": {
                    "value": self.config.config.model.model_name,
                    "type": "text",
                    "description": "Specific model name (e.g., gemini-2.0-flash-exp)"
                },
                "temperature": {
                    "value": self.config.config.model.temperature,
                    "type": "float",
                    "min": 0.0,
                    "max": 2.0,
                    "description": "Model creativity (0.0-2.0, default: 0.7)"
                },
                "max_tokens": {
                    "value": self.config.config.model.max_tokens,
                    "type": "int",
                    "min": 1,
                    "max": 100000,
                    "description": "Maximum tokens per response"
                }
            },
            
            "Autopilot": {
                "autopilot_enabled": {
                    "value": self.config.config.autopilot_enabled,
                    "type": "bool",
                    "description": "Enable autonomous mode (runs without confirmation)"
                },
                "autopilot_max_iterations": {
                    "value": self.config.config.autopilot_max_iterations,
                    "type": "int",
                    "min": 1,
                    "max": 100,
                    "description": "Maximum autonomous iterations"
                }
            },
            
            "Session & Context": {
                "auto_save_sessions": {
                    "value": self.config.config.auto_save_sessions,
                    "type": "bool",
                    "description": "Automatically save sessions after each iteration"
                },
                "context_optimization": {
                    "value": self.config.config.context_optimization,
                    "type": "bool",
                    "description": "Optimize context to reduce token usage"
                },
                "max_context_tokens": {
                    "value": self.config.config.max_context_tokens,
                    "type": "int",
                    "min": 1000,
                    "max": 100000,
                    "description": "Maximum tokens to keep in context"
                },
                "context_history_size": {
                    "value": self.config.config.context_history_size,
                    "type": "int",
                    "min": 1,
                    "max": 100,
                    "description": "Number of messages to keep in history"
                }
            },
            
            "Behavior": {
                "mode": {
                    "value": self.config.config.mode,
                    "type": "choice",
                    "options": ["normal", "hacker"],
                    "description": "Operational mode"
                },
                "auto_execute_commands": {
                    "value": self.config.config.auto_execute_commands,
                    "type": "bool",
                    "description": "Auto-execute pentesting commands without asking"
                },
                "auto_update_check": {
                    "value": self.config.config.auto_update_check,
                    "type": "bool",
                    "description": "Check for updates on startup"
                }
            },
            
            "Interface": {
                "terminal_theme": {
                    "value": self.config.config.terminal_theme,
                    "type": "choice",
                    "options": ["ocean", "sunset", "neon", "forest", "midnight"],
                    "description": "Terminal color theme"
                },
                "mcp_enabled": {
                    "value": self.config.config.mcp_enabled,
                    "type": "bool",
                    "description": "Enable Model Context Protocol"
                }
            }
        }
    
    def show_settings(self):
        """Display all current settings with rich formatting"""
        try:
            from rich.table import Table
            from rich.panel import Panel
            from rich import box
            
            # Create main table
            table = Table(
                title="⚙️  BugPilot CLI Settings", 
                box=box.ROUNDED, 
                show_header=True,
                header_style="bold cyan"
            )
            table.add_column("Category", style="bold cyan", width=15)
            table.add_column("Setting", style="yellow", width=20)
            table.add_column("Value", style="green", width=25)
            table.add_column("Description", style="white", width=35)
            
            for category, settings in self.settings_categories.items():
                first_in_category = True
                
                for key, meta in settings.items():
                    value = meta['value']
                    desc = meta['description']
                    
                    # Format value display
                    if meta['type'] == 'bool':
                        value_str = "[green]✓ ON[/]" if value else "[red]✗ OFF[/]"
                    else:
                        value_str = str(value)
                    
                    # Show category name only on first row
                    cat_name = f"[bold]{category}[/]" if first_in_category else ""
                    first_in_category = False
                    
                    table.add_row(cat_name, key, value_str, desc)
                
                #Add blank row between categories
                if list(self.settings_categories.keys())[-1] != category:
                    table.add_row("", "", "", "")
            
            # Print table
            self.ui.console.print("\n")
            self.ui.console.print(table)
            
            # Commands help
            help_text = (
                "[bold cyan]Available Commands:[/]\n\n"
                "  [yellow]/settings edit[/]           - Interactive editor\n"
                "  [yellow]/settings set <key> <val>[/] - Set value directly\n"
                "  [yellow]/settings toggle <key>[/]   - Quick ON/OFF toggle\n"
                "  [yellow]/settings export <file>[/]  - Backup settings\n"
                "  [yellow]/settings import <file>[/]  - Restore settings\n"
                "  [yellow]/settings reset[/]          - Reset to defaults\n\n"
                "[dim]Note: /config works the same as /settings[/]"
            )
            panel = Panel(help_text, title="💡 Commands", border_style="cyan")
            self.ui.console.print("\n")
            self.ui.console.print(panel)
            
        except Exception as e:
            # Fallback to simple display
            self.ui.print_error(f"Display error: {e}")
            self._show_settings_simple()
    
    def set_value(self, key: str, value: str) -> bool:
        """Set a value directly by key"""
        # Find the setting
        for category, settings in self.settings_categories.items():
            if key in settings:
                meta = settings[key]
                
                # Convert value based on type
                try:
                    if meta['type'] == 'bool':
                        new_val = value.lower() in ['true', 'yes', 'y', '1', 'on']
                    elif meta['type'] == 'int':
                        new_val = int(value)
                    elif meta['type'] == 'float':
                        new_val = float(value)
                    else:
                        new_val = value
                    
                    # Validate range for int/float
                    if meta['type'] in ['int', 'float']:
                        min_val = meta.get('min', float('-inf'))
                        max_val = meta.get('max', float('inf'))
                        if not (min_val <= new_val <= max_val):
                            self.ui.print_error(f"Value must be between {min_val} and {max_val}")
                            return False
                    
                    # Validate choices
                    if meta['type'] == 'choice' and new_val not in meta['options']:
                        self.ui.print_error(f"Value must be one of: {', '.join(meta['options'])}")
                        return False
                    
                    self._update_setting(key, new_val)
                    self.config.save_config()
                    self.ui.print_success(f"✓ {key} = {new_val}")
                    return True
                    
                except ValueError:
                    self.ui.print_error(f"Invalid value type for {key}")
                    return False
        
        self.ui.print_error(f"Setting '{key}' not found")
        return False
    
    def edit_settings_interactive(self):
        """Interactive settings editor with progress"""
        from rich.progress import Progress, SpinnerColumn, TextColumn
        
        self.ui.print_panel(
            "[bold]Interactive Settings Editor[/]\n\n"
            "[cyan]→[/] Navigate through all settings\n"
            "[cyan]→[/] Press Enter to keep current value\n"
            "[cyan]→[/] Changes saved automatically",
            title="⚙️  Edit Mode",
            style="info"
        )
        
        changes_made = False
        total_settings = sum(len(s) for s in self.settings_categories.values())
        current = 0
        
        for category, settings in self.settings_categories.items():
            self.ui.console.print(f"\n[bold cyan]📁 {category}[/] ({len(settings)} settings)")
            
            for key, meta in settings.items():
                current += 1
                current_val = meta['value']
                desc = meta['description']
                
                # Show progress and current value
                progress_text = f"[dim]({current}/{total_settings})[/]"
                self.ui.console.print(
                    f"\n{progress_text} [yellow]{key}[/]: [green]{current_val}[/]"
                )
                self.ui.console.print(f"  [dim]{desc}[/]")
                
                # Get new value
                new_value = self._prompt_for_value(key, meta)
                
                if new_value is not None and new_value != current_val:
                    self._update_setting(key, new_value)
                    changes_made = True
                    self.ui.print_success(f"  Updated: {key} = {new_value}")
        
        if changes_made:
            self.config.save_config()
            self.ui.print_success("\n✓ Settings saved!")
        else:
            self.ui.print_info("\nNo changes made.")
    
    def _prompt_for_value(self, key: str, meta: Dict) -> Any:
        """Prompt user for new value based on type"""
        setting_type = meta['type']
        current = meta['value']
        
        if setting_type == 'bool':
            prompt = f"  New value (y/n, Enter to keep [{current}]): "
            response = input(prompt).strip().lower()
            
            if response == '':
                return None
            elif response in ['y', 'yes', 'true', '1']:
                return True
            elif response in ['n', 'no', 'false', '0']:
                return False
            else:
                return None
        
        elif setting_type == 'choice':
            options = meta['options']
            prompt = f"  Options: {', '.join(options)}\n  New value (Enter to keep [{current}]): "
            response = input(prompt).strip()
            
            if response == '':
                return None
            elif response in options:
                return response
            else:
                self.ui.print_error(f"  Invalid option. Must be one of: {', '.join(options)}")
                return None
        
        elif setting_type == 'int':
            min_val = meta.get('min', 0)
            max_val = meta.get('max', 999999)
            prompt = f"  New value ({min_val}-{max_val}, Enter to keep [{current}]): "
            response = input(prompt).strip()
            
            if response == '':
                return None
            try:
                value = int(response)
                if min_val <= value <= max_val:
                    return value
                else:
                    self.ui.print_error(f"  Value must be between {min_val} and {max_val}")
                    return None
            except ValueError:
                self.ui.print_error("  Invalid integer")
                return None
        
        elif setting_type == 'float':
            min_val = meta.get('min', 0.0)
            max_val = meta.get('max', 999999.0)
            prompt = f"  New value ({min_val}-{max_val}, Enter to keep [{current}]): "
            response = input(prompt).strip()
            
            if response == '':
                return None
            try:
                value = float(response)
                if min_val <= value <= max_val:
                    return value
                else:
                    self.ui.print_error(f"  Value must be between {min_val} and {max_val}")
                    return None
            except ValueError:
                self.ui.print_error("  Invalid number")
                return None
        
        elif setting_type == 'text':
            prompt = f"  New value (Enter to keep [{current}]): "
            response = input(prompt).strip()
            
            if response == '':
                return None
            else:
                return response
        
        return None
    
    def _update_setting(self, key: str, value: Any):
        """Update a specific setting"""
        # Map to config object
        if hasattr(self.config.config, key):
            setattr(self.config.config, key, value)
        elif hasattr(self.config.config.model, key):
            setattr(self.config.config.model, key, value)
    
    def reset_settings(self):
        """Reset all settings to defaults"""
        if self.ui.confirm("Reset ALL settings to defaults?"):
            from bugpilot.config import BugPilotConfig
            self.config.config = BugPilotConfig()
            self.config.save_config()
            self.ui.print_success("✓ Settings reset to defaults")
    
    def export_settings(self, filepath: str = "bugpilot_settings.json"):
        """Export settings to JSON file"""
        try:
            settings_dict = self.config.config.model_dump()
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(settings_dict, f, indent=2)
            
            self.ui.print_success(f"✓ Settings exported to: {filepath}")
        except Exception as e:
            self.ui.print_error(f"Export failed: {e}")
    
    def import_settings(self, filepath: str):
        """Import settings from JSON file"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                settings_dict = json.load(f)
            
            from bugpilot.config import BugPilotConfig
            self.config.config = BugPilotConfig(**settings_dict)
            self.config.save_config()
            
            self.ui.print_success(f"✓ Settings imported from: {filepath}")
        except Exception as e:
            self.ui.print_error(f"Import failed: {e}")
    
    def quick_toggle(self, setting: str):
        """Quick toggle for boolean settings"""
        # Find the setting
        for category, settings in self.settings_categories.items():
            if setting in settings:
                meta = settings[setting]
                if meta['type'] == 'bool':
                    current = meta['value']
                    new_value = not current
                    self._update_setting(setting, new_value)
                    self.config.save_config()
                    status = "ON" if new_value else "OFF"
                    self.ui.print_success(f"✓ {setting}: {status}")
                    return True
        
        self.ui.print_error(f"Setting '{setting}' not found or not a toggle")
        return False
