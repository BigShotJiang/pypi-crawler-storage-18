"""
File Export Handler for BugPilot CLI
Professional file saving like Claude CLI and Gemini CLI
"""

import os
from pathlib import Path
from typing import Optional
from datetime import datetime


class FileExporter:
    """Handle file exports for scan results, reports, and outputs"""
    
    def __init__(self):
        self.default_output_dir = Path.cwd() / "bugpilot_results"
        self.default_output_dir.mkdir(exist_ok=True)
    
    def save_scan_output(self, content: str, tool_name: str, target: str) -> str:
        """Save scan output to file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{tool_name}_{self._sanitize_filename(target)}_{timestamp}.txt"
        filepath = self.default_output_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return str(filepath)
    
    def save_custom(self, content: str, filepath: str) -> bool:
        """Save content to custom filepath"""
        try:
            filepath = Path(filepath)
            filepath.parent.mkdir(parents=True, exist_ok=True)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            print(f"Save error: {e}")
            return False
    
    def append_to_file(self, content: str, filepath: str) -> bool:
        """Append content to existing file"""
        try:
            with open(filepath, 'a', encoding='utf-8') as f:
                f.write(f"\n{content}\n")
            return True
        except Exception as e:
            print(f"Append error: {e}")
            return False
    
    def _sanitize_filename(self, name: str) -> str:
        """Sanitize filename"""
        # Remove/replace invalid characters
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            name = name.replace(char, '_')
        return name[:50]  # Limit length
    
    def get_output_dir(self) -> str:
        """Get current output directory"""
        return str(self.default_output_dir)
    
    def set_output_dir(self, path: str):
        """Set custom output directory"""
        self.default_output_dir = Path(path)
        self.default_output_dir.mkdir(parents=True, exist_ok=True)
