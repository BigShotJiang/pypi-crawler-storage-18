"""
Status Bar Component - Shows context, tokens, and progress
Part of BugPilot v1.4.0 UI Enhancement
"""

from rich.console import Console
from rich.panel import Panel
from rich.layout import Layout
from typing import Optional


class StatusBar:
    """Status bar showing real-time AI metrics"""
    
    def __init__(self, console: Console):
        self.console = console
        self.context_used = 0
        self.context_limit = 8000
        self.tokens_used = 0
        self.tokens_limit = 8192
        self.current_iteration = 0
        self.total_findings = 0
        self.current_phase = "Initializing"
        
    def update(self, **kwargs):
        """Update status bar metrics"""
        self.context_used = kwargs.get('context_used', self.context_used)
        self.tokens_used = kwargs.get('tokens_used', self.tokens_used)
        self.current_iteration = kwargs.get('iteration', self.current_iteration)
        self.total_findings = kwargs.get('findings', self.total_findings)
        self.current_phase = kwargs.get('phase', self.current_phase)
        
    def render(self) -> str:
        """Render status bar as string"""
        # Calculate percentages
        context_pct = int((self.context_used / self.context_limit) * 100) if self.context_limit else 0
        tokens_pct = int((self.tokens_used / self.tokens_limit) * 100) if self.tokens_limit else 0
        
        # Color coding
        context_color = "green" if context_pct < 70 else "yellow" if context_pct < 90 else "red"
        tokens_color = "green" if tokens_pct < 70 else "yellow" if tokens_pct < 90 else "red"
        
        # Build status string
        status = (
            f"[cyan]Phase:[/] [{self.current_phase}] | "
            f"[cyan]Iteration:[/] {self.current_iteration} | "
            f"[cyan]Findings:[/] {self.total_findings} | "
            f"[{context_color}]Context:[/] {self.context_used}/{self.context_limit} ({context_pct}%) | "
            f"[{tokens_color}]Tokens:[/] {self.tokens_used}/{self.tokens_limit} ({tokens_pct}%)"
        )
        
        return status
    
    def display(self):
        """Display status bar"""
        status_text = self.render()
        # Print at bottom right (simplified version)
        self.console.print(f"\n{status_text}\n", style="dim")
    
    def format_compact(self) -> str:
        """Compact format for inline display"""
        return f"[{self.current_iteration}I | {self.total_findings}F | {self.context_used}C | {self.tokens_used}T]"


class ProgressIndicator:
    """Live progress indicator for operations"""
    
    def __init__(self, console: Console):
        self.console = console
        
    def show_scanning(self, target: str, progress: int = 0):
        """Show scanning progress"""
        bar = self._make_bar(progress)
        self.console.print(
            f"\n[cyan][SCANNING][/] {bar} {progress}% | Target: {target}",
            end="\r"
        )
    
    def show_testing(self, vuln_type: str, progress: int = 0):
        """Show testing progress"""
        bar = self._make_bar(progress)
        self.console.print(
            f"\n[yellow][TESTING][/] {bar} {progress}% | {vuln_type}",
            end="\r"
        )
    
    def show_exploiting(self, target: str):
        """Show exploitation in progress"""
        self.console.print(
            f"\n[red][EXPLOITING][/] {target}...",
            style="bold"
        )
    
    def show_complete(self, message: str):
        """Show completion"""
        self.console.print(
            f"\n[green bold]✓ {message}[/]"
        )
    
    def _make_bar(self, progress: int, width: int = 20) -> str:
        """Create a simple progress bar"""
        filled = int((progress / 100) * width)
        bar = "█" * filled + "░" * (width - filled)
        return bar


def estimate_tokens(text: str) -> int:
    """Rough token estimation (1 token ≈ 4 characters)"""
    return len(text) // 4


def estimate_context_size(history: list) -> int:
    """Estimate context size from history"""
    total = 0
    for item in history:
        if isinstance(item, dict):
            total += estimate_tokens(str(item))
        else:
            total += estimate_tokens(str(item))
    return total
