import json
import os

try:
    from groq import Groq
except ImportError:
    raise ImportError(
        "The 'groq' library is required. Please install it using 'pip install groq'."
    )

from selfmemory.llms.base import LLMBase
from selfmemory.llms.configs import BaseLlmConfig
from selfmemory.memory.utils import extract_json


class GroqLLM(LLMBase):
    def __init__(self, config: BaseLlmConfig | None = None):
        super().__init__(config)

        if not self.config.model:
            self.config.model = "llama3-70b-8192"

        api_key = self.config.api_key or os.getenv("GROQ_API_KEY")
        self.client = Groq(api_key=api_key)

    def _parse_response(self, response, tools):
        """
        Process the response based on whether tools are used or not.

        Args:
            response: The raw response from API.
            tools: The list of tools provided in the request.

        Returns:
            str or dict: The processed response.
        """
        if tools:
            processed_response = {
                "content": response.choices[0].message.content,
                "tool_calls": [],
            }

            if response.choices[0].message.tool_calls:
                for tool_call in response.choices[0].message.tool_calls:
                    processed_response["tool_calls"].append(
                        {
                            "name": tool_call.function.name,
                            "arguments": json.loads(
                                extract_json(tool_call.function.arguments)
                            ),
                        }
                    )

            return processed_response
        return response.choices[0].message.content

    def generate_response(
        self,
        messages: list[dict[str, str]],
        response_format=None,
        tools: list[dict] | None = None,
        tool_choice: str = "auto",
    ):
        """
        Generate a response based on the given messages using Groq.

        Args:
            messages (list): List of message dicts containing 'role' and 'content'.
            response_format (str or object, optional): Format of the response. Defaults to "text".
            tools (list, optional): List of tools that the model can call. Defaults to None.
            tool_choice (str, optional): Tool choice method. Defaults to "auto".

        Returns:
            str: The generated response.
        """
        params = {
            "model": self.config.model,
            "messages": messages,
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "top_p": self.config.top_p,
        }
        if response_format:
            params["response_format"] = response_format
        if tools:
            params["tools"] = tools
            params["tool_choice"] = tool_choice

        response = self.client.chat.completions.create(**params)
        return self._parse_response(response, tools)
