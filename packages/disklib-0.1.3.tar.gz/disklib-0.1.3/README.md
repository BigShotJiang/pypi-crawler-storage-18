# disklib

Dies ist die Dokumentation für die `disklib`-Bibliothek, die Funktionen zum Abrufen und Anzeigen von Festplattennutzungsinformationen bereitstellt.

## Installation

Um die `disklib`-Bibliothek zu installieren, verwenden Sie pip:

```bash
pip install disklib
```

## Verwendung

Hier ist ein einfaches Beispiel, wie Sie die `disklib`-Bibliothek verwenden können

```python
from disklib import DiskUsage
disk = DiskUsage("C:/", "GB")
disk.free_on()
disk.usage_on()
disk.total_on()
print(disk)
```

## Klassen und Methoden

### DiskUsage

Die `DiskUsage`-Klasse ermöglicht das Abrufen von Festplattennutzungsinformationen.

#### Initialisierung

```python
disk = DiskUsage(pfad: str, einheit: str = "GB")
```

- `pfad`: Der Pfad des Laufwerks oder Verzeichnisses, für das die Festplattennutzung abgerufen werden soll.
- `einheit`: Die Einheit für die Anzeige der Festplattennutzung (Standard ist "GB"). Mögliche Werte sind "B", "KB", "MB", "GB", "TB".

#### Methoden

- `free_on()`: Ruft den freien Speicherplatz ab.
- `usage_on()`: Ruft den verwendeten Speicherplatz ab.
- `total_on()`: Ruft den gesamten Speicherplatz ab.
- `free_print(sprache: str = "DE") -> str`: Gibt den freien Speicherplatz als formatierte Zeichenkette zurück.
- `usage_print(sprache: str = "DE") -> str`: Gibt den verwendeten Speicherplatz als formatierte Zeichenkette zurück.
- `total_print(sprache: str = "DE") -> str`: Gibt den gesamten Speicherplatz als formatierte Zeichenkette zurück.
- `get_einheit_auto(update: bool = False) -> str`: Bestimmt automatisch die geeignete Einheit basierend auf dem gesamten Speicherplatz.

## Fehlerbehandlung

Die `disklib`-Bibliothek definiert benutzerdefinierte Ausnahmen für die Fehlerbehandlung:

- `NotValidPfadError`: Wird ausgelöst, wenn der angegebene Pfad ungültig ist.

- `NotValidEinheitError`: Wird ausgelöst, wenn die angegebene Einheit ungültig ist.

## Lizenz

Die `disklib`-Bibliothek ist unter der MIT-Lizenz lizenziert. Weitere Informationen finden Sie in der LICENSE-Datei.
