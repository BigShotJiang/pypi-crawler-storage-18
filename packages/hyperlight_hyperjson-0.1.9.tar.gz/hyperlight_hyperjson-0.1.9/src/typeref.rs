// SPDX-License-Identifier: (Apache-2.0 OR MIT)
// Copyright ijl (2018-2025), Aviram Hassan (2020-2021), Nazar Kostetskyi (2022), Ben Sully (2021)

use core::ffi::CStr;
use core::ptr::{NonNull, null_mut};
use once_cell::race::OnceBox;

use crate::ffi::{
    Py_False, Py_None, Py_True, Py_XDECREF, PyBool_Type, PyByteArray_Type, PyBytes_Type,
    PyDict_Type, PyErr_Clear, PyFloat_Type, PyImport_ImportModule, PyList_Type, PyLong_Type,
    PyMapping_GetItemString, PyMemoryView_Type, PyObject, PyObject_GenericGetDict, PyTuple_Type,
    PyTypeObject, PyUnicode_Type,
};

// ============================================================================
// DIRECT CPython GLOBALS - Zero overhead, no indirection
// These are CPython global symbols that are the same across ALL interpreters
// Using these directly in hot paths eliminates pointer indirection overhead
// ============================================================================

/// Get the str type directly from CPython global - fastest path
#[inline(always)]
pub(crate) fn str_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyUnicode_Type }
}

/// Get the int type directly from CPython global
#[inline(always)]
pub(crate) fn int_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyLong_Type }
}

/// Get the bool type directly from CPython global
#[inline(always)]
pub(crate) fn bool_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyBool_Type }
}

/// Get the float type directly from CPython global
#[inline(always)]
pub(crate) fn float_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyFloat_Type }
}

/// Get the list type directly from CPython global
#[inline(always)]
pub(crate) fn list_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyList_Type }
}

/// Get the dict type directly from CPython global
#[inline(always)]
pub(crate) fn dict_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyDict_Type }
}

/// Get the tuple type directly from CPython global
#[inline(always)]
pub(crate) fn tuple_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyTuple_Type }
}

/// Get the bytes type directly from CPython global
#[inline(always)]
pub(crate) fn bytes_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyBytes_Type }
}

/// Get the bytearray type directly from CPython global
#[inline(always)]
pub(crate) fn bytearray_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyByteArray_Type }
}

/// Get the memoryview type directly from CPython global
#[inline(always)]
pub(crate) fn memoryview_type_ptr() -> *mut PyTypeObject {
    unsafe { &raw mut PyMemoryView_Type }
}

/// Get None singleton directly from CPython
#[inline(always)]
pub(crate) fn none_ptr() -> *mut PyObject {
    unsafe { Py_None() }
}

/// Get True singleton directly from CPython
#[inline(always)]
pub(crate) fn true_ptr() -> *mut PyObject {
    unsafe { Py_True() }
}

/// Get False singleton directly from CPython
#[inline(always)]
pub(crate) fn false_ptr() -> *mut PyObject {
    unsafe { Py_False() }
}

/// Get NoneType directly (derived from None singleton)
#[inline(always)]
pub(crate) fn none_type_ptr() -> *mut PyTypeObject {
    unsafe { (*Py_None()).ob_type }
}

// ============================================================================
// LEGACY ACCESSORS - Use direct *_ptr() functions in hot paths instead
// ============================================================================

// Accessor macros that use interpreter state instead of static variables
// These provide a drop-in replacement for the old static variables

#[macro_export]
macro_rules! get_state {
    () => {
        // Inline the state access for better optimization
        unsafe {
            let state_ptr = crate::interpreter_state::get_current_state();
            debug_assert!(!state_ptr.is_null());
            &*state_ptr
        }
    };
}

use crate::interpreter_state::InterpreterState;

// Accessor functions for per-interpreter values (use direct *_ptr() for built-in types in hot paths)
#[inline(always)]
pub(crate) fn get_default() -> *mut PyObject {
    unsafe { get_state!().default }
}

#[inline(always)]
pub(crate) fn get_option() -> *mut PyObject {
    unsafe { get_state!().option }
}

/// Get None singleton - use `none_ptr()` directly in hot paths
#[inline(always)]
pub(crate) fn get_none() -> *mut PyObject {
    none_ptr()
}

/// Get True singleton - use `true_ptr()` directly in hot paths
#[inline(always)]
pub(crate) fn get_true() -> *mut PyObject {
    true_ptr()
}

#[inline(always)]
pub(crate) fn get_empty_unicode() -> *mut PyObject {
    unsafe { get_state!().empty_unicode }
}

#[inline(always)]
pub(crate) fn get_empty_unicode_from_state(state: *const InterpreterState) -> *mut PyObject {
    unsafe { (*state).empty_unicode }
}

#[inline(always)]
pub(crate) fn get_fragment_type() -> *mut PyTypeObject {
    unsafe { get_state!().fragment_type }
}

#[inline(always)]
pub(crate) fn get_json_encode_error() -> *mut PyObject {
    unsafe { get_state!().json_encode_error }
}

#[inline(always)]
pub(crate) fn get_json_decode_error() -> *mut PyObject {
    unsafe { get_state!().json_decode_error }
}

// State-aware accessor functions for per-interpreter data
// Built-in types now use direct CPython globals (*_ptr() functions) - no state needed
// These remain for per-interpreter types that require module lookups

#[inline(always)]
pub(crate) fn get_datetime_type_from_state(state: *const InterpreterState) -> *mut PyTypeObject {
    unsafe { (*state).datetime_type }
}

#[inline(always)]
pub(crate) fn get_date_type_from_state(state: *const InterpreterState) -> *mut PyTypeObject {
    unsafe { (*state).date_type }
}

#[inline(always)]
pub(crate) fn get_time_type_from_state(state: *const InterpreterState) -> *mut PyTypeObject {
    unsafe { (*state).time_type }
}

#[inline(always)]
pub(crate) fn get_uuid_type_from_state(state: *const InterpreterState) -> *mut PyTypeObject {
    unsafe { (*state).uuid_type }
}

#[inline(always)]
pub(crate) fn get_fragment_type_from_state(state: *const InterpreterState) -> *mut PyTypeObject {
    unsafe { (*state).fragment_type }
}

#[inline(always)]
pub(crate) fn get_enum_type_from_state(state: *const InterpreterState) -> *mut PyTypeObject {
    unsafe { (*state).enum_type }
}

#[inline(always)]
pub(crate) fn get_dataclass_fields_str_from_state(state: *const InterpreterState) -> *mut PyObject {
    unsafe { (*state).dataclass_fields_str }
}

#[inline(always)]
pub(crate) fn get_dict_str_from_state(state: *const InterpreterState) -> *mut PyObject {
    unsafe { (*state).dict_str }
}

#[inline(always)]
pub(crate) fn get_slots_str_from_state(state: *const InterpreterState) -> *mut PyObject {
    unsafe { (*state).slots_str }
}

// Additional accessors for string constants
#[inline(always)]
pub(crate) fn get_value_str() -> *mut PyObject {
    unsafe { get_state!().value_str }
}

#[inline(always)]
pub(crate) fn get_int_attr_str() -> *mut PyObject {
    unsafe { get_state!().int_attr_str }
}

// Per-interpreter type accessors - require state lookup

#[inline(always)]
pub(crate) fn get_field_type() -> *mut PyTypeObject {
    unsafe { get_state!().field_type }
}

#[inline(always)]
pub(crate) fn get_zoneinfo_type() -> *mut PyTypeObject {
    unsafe { get_state!().zoneinfo_type }
}

// String constant accessors
#[inline(always)]
pub(crate) fn get_utcoffset_method_str() -> *mut PyObject {
    unsafe { get_state!().utcoffset_method_str }
}

#[inline(always)]
pub(crate) fn get_normalize_method_str() -> *mut PyObject {
    unsafe { get_state!().normalize_method_str }
}

#[inline(always)]
pub(crate) fn get_convert_method_str() -> *mut PyObject {
    unsafe { get_state!().convert_method_str }
}

#[inline(always)]
pub(crate) fn get_dst_str() -> *mut PyObject {
    unsafe { get_state!().dst_str }
}

#[inline(always)]
pub(crate) fn get_field_type_str() -> *mut PyObject {
    unsafe { get_state!().field_type_str }
}

#[inline(always)]
pub(crate) fn get_array_struct_str() -> *mut PyObject {
    unsafe { get_state!().array_struct_str }
}

#[inline(always)]
pub(crate) fn get_dtype_str() -> *mut PyObject {
    unsafe { get_state!().dtype_str }
}

#[inline(always)]
pub(crate) fn get_descr_str() -> *mut PyObject {
    unsafe { get_state!().descr_str }
}

pub(crate) struct NumpyTypes {
    pub array: *mut PyTypeObject,
    pub float64: *mut PyTypeObject,
    pub float32: *mut PyTypeObject,
    pub float16: *mut PyTypeObject,
    pub int64: *mut PyTypeObject,
    pub int32: *mut PyTypeObject,
    pub int16: *mut PyTypeObject,
    pub int8: *mut PyTypeObject,
    pub uint64: *mut PyTypeObject,
    pub uint32: *mut PyTypeObject,
    pub uint16: *mut PyTypeObject,
    pub uint8: *mut PyTypeObject,
    pub bool_: *mut PyTypeObject,
    pub datetime64: *mut PyTypeObject,
}

pub(crate) static mut NUMPY_TYPES: OnceBox<Option<NonNull<NumpyTypes>>> = OnceBox::new();

unsafe fn look_up_numpy_type(
    numpy_module_dict: *mut PyObject,
    np_type: &CStr,
) -> *mut PyTypeObject {
    unsafe {
        let ptr = PyMapping_GetItemString(numpy_module_dict, np_type.as_ptr());
        Py_XDECREF(ptr);
        ptr.cast::<PyTypeObject>()
    }
}

#[cold]
#[cfg_attr(feature = "optimize", optimize(size))]
pub(crate) fn load_numpy_types() -> Box<Option<NonNull<NumpyTypes>>> {
    unsafe {
        let numpy = PyImport_ImportModule(c"numpy".as_ptr());
        if numpy.is_null() {
            PyErr_Clear();
            return Box::new(None);
        }
        let numpy_module_dict = PyObject_GenericGetDict(numpy, null_mut());
        let types = Box::new(NumpyTypes {
            array: look_up_numpy_type(numpy_module_dict, c"ndarray"),
            float16: look_up_numpy_type(numpy_module_dict, c"half"),
            float32: look_up_numpy_type(numpy_module_dict, c"float32"),
            float64: look_up_numpy_type(numpy_module_dict, c"float64"),
            int8: look_up_numpy_type(numpy_module_dict, c"int8"),
            int16: look_up_numpy_type(numpy_module_dict, c"int16"),
            int32: look_up_numpy_type(numpy_module_dict, c"int32"),
            int64: look_up_numpy_type(numpy_module_dict, c"int64"),
            uint16: look_up_numpy_type(numpy_module_dict, c"uint16"),
            uint32: look_up_numpy_type(numpy_module_dict, c"uint32"),
            uint64: look_up_numpy_type(numpy_module_dict, c"uint64"),
            uint8: look_up_numpy_type(numpy_module_dict, c"uint8"),
            bool_: look_up_numpy_type(numpy_module_dict, c"bool_"),
            datetime64: look_up_numpy_type(numpy_module_dict, c"datetime64"),
        });
        Py_XDECREF(numpy_module_dict);
        Py_XDECREF(numpy);
        Box::new(Some(nonnull!(Box::<NumpyTypes>::into_raw(types))))
    }
}
