# tree-sitter-rust-orchard

[![crates][crates]](https://crates.io/crates/tree-sitter-rust-orchard)
[![pypi][pypi]](https://pypi.org/project/tree-sitter-rust-orchard)

This is a fork of the [tree-sitter-rust](https://github.com/tree-sitter/tree-sitter-rust) grammar.
It focuses on:
- faithfulness of the produced trees with the semantics of Rust
- ability to parse Rust files with recent syntactic constructs
- proactive reviewing of contributions and onboarding of their authors into the project, via the [governance model](https://codeberg.org/grammar-orchard/.profile/src/branch/main/GOVERNANCE.md)

Note that unlike upstream, generated files are not checked into git, so you need to run `tree-sitter generate` after cloning this repository.

Contributions are welcome, so are co-maintainers.

[crates]: https://img.shields.io/crates/v/tree-sitter-rust-orchard?logo=rust
[pypi]: https://img.shields.io/pypi/v/tree-sitter-rust-orchard?logo=pypi&logoColor=ffd242
