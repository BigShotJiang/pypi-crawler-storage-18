# Secure Run (sr)

Encrypt Python files and run them securely
Plugins run with full privileges (be careful of what plugins you install)

## Install
```bash
pip install secure-run