"""Tests for depswiz."""
