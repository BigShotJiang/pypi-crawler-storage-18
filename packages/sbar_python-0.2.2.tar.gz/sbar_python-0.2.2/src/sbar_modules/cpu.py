from __future__ import annotations

import ctypes
from dataclasses import dataclass


_CPU_STATE_USER = 0
_CPU_STATE_SYSTEM = 1
_CPU_STATE_IDLE = 2
_CPU_STATE_NICE = 3
_CPU_STATE_MAX = 4

_HOST_CPU_LOAD_INFO = 3
_HOST_CPU_LOAD_INFO_COUNT = _CPU_STATE_MAX


class _HostCPULoadInfo(ctypes.Structure):
    _fields_ = [
        ("cpu_ticks", ctypes.c_uint32 * _CPU_STATE_MAX),
    ]


_libsystem = ctypes.CDLL("/usr/lib/libSystem.B.dylib")

_mach_host_self = _libsystem.mach_host_self
_mach_host_self.argtypes = []
_mach_host_self.restype = ctypes.c_uint32

_host_statistics = _libsystem.host_statistics
_host_statistics.argtypes = [
    ctypes.c_uint32,
    ctypes.c_int,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_uint32),
]
_host_statistics.restype = ctypes.c_int


@dataclass(frozen=True, slots=True)
class CpuLoadSample:
    user_load: int
    sys_load: int
    total_load: int


class CpuLoadMonitor:
    def __init__(self) -> None:
        self._host = _mach_host_self()
        self._prev: _HostCPULoadInfo | None = None

    def sample(self) -> CpuLoadSample | None:
        info = _HostCPULoadInfo()
        count = ctypes.c_uint32(_HOST_CPU_LOAD_INFO_COUNT)
        rc = _host_statistics(self._host, _HOST_CPU_LOAD_INFO, ctypes.byref(info), ctypes.byref(count))
        if rc != 0:
            return None

        prev = self._prev
        self._prev = info
        if prev is None:
            return None

        delta_user = int(info.cpu_ticks[_CPU_STATE_USER] - prev.cpu_ticks[_CPU_STATE_USER])
        delta_sys = int(info.cpu_ticks[_CPU_STATE_SYSTEM] - prev.cpu_ticks[_CPU_STATE_SYSTEM])
        delta_idle = int(info.cpu_ticks[_CPU_STATE_IDLE] - prev.cpu_ticks[_CPU_STATE_IDLE])
        delta_nice = int(info.cpu_ticks[_CPU_STATE_NICE] - prev.cpu_ticks[_CPU_STATE_NICE])

        total = delta_user + delta_sys + delta_idle + delta_nice
        if total <= 0:
            return None

        user = int((delta_user / total) * 100.0)
        sys_ = int((delta_sys / total) * 100.0)
        return CpuLoadSample(user_load=user, sys_load=sys_, total_load=user + sys_)


__all__ = [
    "CpuLoadMonitor",
    "CpuLoadSample",
]
