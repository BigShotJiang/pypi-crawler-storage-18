from __future__ import annotations

import struct

import CoreAudio


def _get_property_data(object_id: int, address: CoreAudio.AudioObjectPropertyAddress) -> bytes | None:
    try:
        status, size = CoreAudio.AudioObjectGetPropertyDataSize(object_id, address, 0, b"", None)
    except Exception:
        return None
    if int(status) != 0 or int(size) <= 0:
        return None

    try:
        status, _size, data = CoreAudio.AudioObjectGetPropertyData(object_id, address, 0, b"", int(size), None)
    except Exception:
        return None
    if int(status) != 0:
        return None

    try:
        return bytes(data)
    except Exception:
        return None


def _set_property_data(object_id: int, address: CoreAudio.AudioObjectPropertyAddress, payload: bytes) -> bool:
    try:
        status = CoreAudio.AudioObjectSetPropertyData(object_id, address, 0, b"", len(payload), payload)
    except Exception:
        return False
    return int(status) == 0


def default_output_device_id() -> int | None:
    address = CoreAudio.AudioObjectPropertyAddress(
        mSelector=CoreAudio.kAudioHardwarePropertyDefaultOutputDevice,
        mScope=CoreAudio.kAudioObjectPropertyScopeGlobal,
        mElement=CoreAudio.kAudioObjectPropertyElementMain,
    )
    raw = _get_property_data(int(CoreAudio.kAudioObjectSystemObject), address)
    if raw is None or len(raw) < 4:
        return None
    return int(struct.unpack("I", raw[:4])[0])


def _volume_addresses(device_id: int) -> list[CoreAudio.AudioObjectPropertyAddress]:
    candidates = [0, 1, 2]
    out: list[CoreAudio.AudioObjectPropertyAddress] = []
    for element in candidates:
        address = CoreAudio.AudioObjectPropertyAddress(
            mSelector=CoreAudio.kAudioDevicePropertyVolumeScalar,
            mScope=CoreAudio.kAudioDevicePropertyScopeOutput,
            mElement=element,
        )
        try:
            has = bool(CoreAudio.AudioObjectHasProperty(device_id, address))
        except Exception:
            continue
        if has:
            out.append(address)
    return out


def get_output_volume_scalar() -> float | None:
    device_id = default_output_device_id()
    if device_id is None:
        return None

    addresses = _volume_addresses(device_id)
    if not addresses:
        return None

    values: list[float] = []
    for address in addresses:
        raw = _get_property_data(device_id, address)
        if raw is None or len(raw) < 4:
            continue
        try:
            value = float(struct.unpack("f", raw[:4])[0])
        except Exception:
            continue
        values.append(value)

    if not values:
        return None

    value = sum(values) / float(len(values))
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value


def set_output_volume_scalar(value: float) -> bool:
    if value < 0.0:
        value = 0.0
    if value > 1.0:
        value = 1.0

    device_id = default_output_device_id()
    if device_id is None:
        return False

    addresses = _volume_addresses(device_id)
    if not addresses:
        return False

    payload = struct.pack("f", float(value))
    ok = False
    for address in addresses:
        ok = _set_property_data(device_id, address, payload) or ok
    return ok


def get_output_volume_percent() -> int | None:
    scalar = get_output_volume_scalar()
    if scalar is None:
        return None
    return int(round(scalar * 100.0))


def set_output_volume_percent(percent: float) -> bool:
    if percent < 0.0:
        percent = 0.0
    if percent > 100.0:
        percent = 100.0
    return set_output_volume_scalar(float(percent) / 100.0)


def change_output_volume_percent(delta: float) -> int | None:
    scalar = get_output_volume_scalar()
    if scalar is None:
        return None
    next_scalar = scalar + (float(delta) / 100.0)
    if next_scalar < 0.0:
        next_scalar = 0.0
    if next_scalar > 1.0:
        next_scalar = 1.0
    if not set_output_volume_scalar(next_scalar):
        return None
    return int(round(next_scalar * 100.0))


__all__ = [
    "change_output_volume_percent",
    "default_output_device_id",
    "get_output_volume_percent",
    "get_output_volume_scalar",
    "set_output_volume_percent",
    "set_output_volume_scalar",
]

