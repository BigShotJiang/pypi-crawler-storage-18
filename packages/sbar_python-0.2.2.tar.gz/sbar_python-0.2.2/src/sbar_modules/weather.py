from __future__ import annotations

import json
import os
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Generic, TypeVar

from .keychain import get_generic_password


T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class CacheFile(Generic[T]):
    path: Path

    def read_text(self) -> str | None:
        try:
            return self.path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None

    def write_text(self, text: str) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(text, encoding="utf-8")

    def read_json(self) -> Any | None:
        raw = self.read_text()
        if raw is None or not raw.strip():
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None

    def write_json(self, value: Any) -> None:
        self.write_text(json.dumps(value, ensure_ascii=False))

    def is_fresh(self, *, ttl_seconds: int) -> bool:
        try:
            mtime = self.path.stat().st_mtime
        except FileNotFoundError:
            return False
        return (time.time() - mtime) < float(ttl_seconds)


def owm_icon_for(weather_id: int, *, is_day: bool) -> str:
    if 200 <= weather_id < 300:
        return "⛈️"
    if 300 <= weather_id < 400:
        return "🌦️"
    if 500 <= weather_id < 600:
        return "🌧️"
    if 600 <= weather_id < 700:
        return "❄️"
    if 700 <= weather_id < 800:
        return "🌫️"
    if weather_id == 800:
        return "☀️" if is_day else "🌙"
    if weather_id == 801:
        return "🌤"
    if weather_id in {802, 803}:
        return "⛅"
    return "☁️"


@dataclass(frozen=True, slots=True)
class OpenWeatherCurrent:
    temp_c: float
    feels_like_c: float
    weather_id: int
    description: str
    sunrise: int
    sunset: int
    timezone: str
    wind_speed_mps: float
    humidity_percent: int
    pressure_hpa: int
    lat: float
    lon: float

    def is_day(self, *, now: int | None = None) -> bool:
        t = int(time.time()) if now is None else int(now)
        return t >= int(self.sunrise) and t < int(self.sunset)

    def icon(self, *, now: int | None = None) -> str:
        return owm_icon_for(int(self.weather_id), is_day=self.is_day(now=now))


@dataclass(frozen=True, slots=True)
class _CacheEntry:
    ts: int
    lat: float
    lon: float
    payload: dict[str, Any]


class OpenWeatherProvider:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        cache_path: Path | None = None,
        ttl_seconds: int = 300,
        lang: str = "zh_cn",
        units: str = "metric",
    ) -> None:
        self._api_key = api_key
        self.cache_path = cache_path
        self.cache_file = CacheFile[dict](cache_path) if cache_path is not None else None
        self._mem: _CacheEntry | None = None
        self.ttl_seconds = ttl_seconds
        self.lang = lang
        self.units = units

    def api_key(self) -> str | None:
        if self._api_key:
            return self._api_key
        env = (os.environ.get("OPENWEATHERMAP_API_KEY") or "").strip()
        if env:
            return env
        return get_generic_password(service="OPENWEATHERMAP_API_KEY")

    def _url(self, *, lat: float, lon: float, api_key: str) -> str:
        query = urllib.parse.urlencode(
            {
                "lat": str(lat),
                "lon": str(lon),
                "exclude": "minutely,hourly,daily,alerts",
                "units": self.units,
                "lang": self.lang,
                "appid": api_key,
            }
        )
        return f"https://api.openweathermap.org/data/3.0/onecall?{query}"

    def url(self, *, lat: float, lon: float, api_key: str) -> str:
        return self._url(lat=lat, lon=lon, api_key=api_key)

    def _parse(self, raw: dict, *, lat: float, lon: float) -> OpenWeatherCurrent | None:
        current = raw.get("current") if isinstance(raw, dict) else None
        if not isinstance(current, dict):
            return None
        weather = current.get("weather")
        w0 = weather[0] if isinstance(weather, list) and weather and isinstance(weather[0], dict) else {}

        try:
            temp = float(current.get("temp", 0.0))
            feels = float(current.get("feels_like", 0.0))
            wid = int(w0.get("id", 800))
            desc = str(w0.get("description", "") or "")
            sunrise = int(current.get("sunrise", 0))
            sunset = int(current.get("sunset", 0))
            tz = str(raw.get("timezone", "") or "")
            wind = float(current.get("wind_speed", 0.0))
            humidity = int(current.get("humidity", 0))
            pressure = int(current.get("pressure", 0))
        except (TypeError, ValueError):
            return None

        return OpenWeatherCurrent(
            temp_c=temp,
            feels_like_c=feels,
            weather_id=wid,
            description=desc,
            sunrise=sunrise,
            sunset=sunset,
            timezone=tz,
            wind_speed_mps=wind,
            humidity_percent=humidity,
            pressure_hpa=pressure,
            lat=lat,
            lon=lon,
        )

    def parse(self, payload: dict, *, lat: float, lon: float) -> OpenWeatherCurrent | None:
        return self._parse(payload, lat=lat, lon=lon)

    def cache_write(self, *, lat: float, lon: float, payload: dict) -> None:
        ts = int(time.time())
        entry = _CacheEntry(ts=ts, lat=lat, lon=lon, payload=dict(payload))
        self._mem = entry
        if self.cache_file is not None:
            self.cache_file.write_json({"ts": ts, "lat": lat, "lon": lon, "payload": payload})

    def clear_cache(self) -> None:
        self._mem = None
        if self.cache_file is None:
            return
        try:
            self.cache_file.path.unlink(missing_ok=True)
        except Exception:
            return

    def cached_entry(self) -> _CacheEntry | None:
        now = int(time.time())
        mem = self._mem
        if mem is not None and (now - int(mem.ts)) < int(self.ttl_seconds):
            return mem

        if self.cache_file is None or not self.cache_file.is_fresh(ttl_seconds=self.ttl_seconds):
            return None

        obj = self.cache_file.read_json()
        if not isinstance(obj, dict):
            return None
        payload = obj.get("payload")
        lat = obj.get("lat")
        lon = obj.get("lon")
        if not isinstance(payload, dict):
            return None
        try:
            lat_f = float(lat)
            lon_f = float(lon)
            ts = int(float(obj.get("ts", now)))
        except (TypeError, ValueError):
            return None
        entry = _CacheEntry(ts=ts, lat=lat_f, lon=lon_f, payload=payload)
        self._mem = entry
        return entry

    def cached(self) -> OpenWeatherCurrent | None:
        entry = self.cached_entry()
        if entry is None:
            return None
        return self._parse(entry.payload, lat=entry.lat, lon=entry.lon)

    def fetch(self, *, lat: float, lon: float, force: bool = False) -> OpenWeatherCurrent | None:
        if not force:
            cached = self.cached()
            if cached is not None and abs(cached.lat - lat) < 1e-3 and abs(cached.lon - lon) < 1e-3:
                return cached

        key = self.api_key()
        if not key:
            return None

        req = urllib.request.Request(self._url(lat=lat, lon=lon, api_key=key), headers={"User-Agent": "sbar-python"})
        try:
            with urllib.request.urlopen(req, timeout=6.0) as resp:
                raw = json.loads(resp.read().decode("utf-8", errors="ignore"))
        except Exception:
            return None

        if isinstance(raw, dict):
            self.cache_write(lat=lat, lon=lon, payload=raw)
        return self._parse(raw, lat=lat, lon=lon)


__all__ = [
    "OpenWeatherCurrent",
    "OpenWeatherProvider",
    "owm_icon_for",
]
