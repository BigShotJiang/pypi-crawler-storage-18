from __future__ import annotations

import Quartz


def snapshot_on_screen_apps() -> dict[str, int]:
    """获取当前 Space（屏幕上可见窗口）中各应用的窗口数量。"""
    info_list = Quartz.CGWindowListCopyWindowInfo(Quartz.kCGWindowListOptionOnScreenOnly, Quartz.kCGNullWindowID)
    if not info_list:
        return {}

    counts: dict[str, int] = {}
    for info in info_list:
        try:
            layer = int(info.get(Quartz.kCGWindowLayer, 0))
        except Exception:
            layer = 0
        if layer != 0:
            continue

        owner = info.get(Quartz.kCGWindowOwnerName)
        if not owner:
            continue

        name = str(owner)
        counts[name] = counts.get(name, 0) + 1

    return counts


def encode_space_snapshot_apps(app_counts: dict[str, int]) -> str:
    """编码为 SketchyBar env 字符串：`App:count|App2:count`。"""
    if not app_counts:
        return ""
    parts: list[str] = []
    for app, count in app_counts.items():
        safe_app = str(app).replace("\n", " ").replace("\r", " ").replace("'", " ").replace('"', " ").strip()
        parts.append(f"{safe_app}:{int(count)}")
    return "|".join(parts)


__all__ = [
    "encode_space_snapshot_apps",
    "snapshot_on_screen_apps",
]
