from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Literal, Protocol


NowPlayingState = Literal["playing", "paused", "stopped"]


@dataclass(frozen=True, slots=True)
class NowPlayingInfo:
    app: str
    state: NowPlayingState
    title: str = ""
    artist: str = ""
    album: str = ""
    elapsed: float | None = None
    duration: float | None = None


class NowPlayingProvider(Protocol):
    def current(self) -> NowPlayingInfo | None: ...

    def playpause(self) -> bool: ...

    def next_track(self) -> bool: ...

    def previous_track(self) -> bool: ...


def _safe_int(value: object) -> int | None:
    try:
        return int(value)  # type: ignore[arg-type]
    except Exception:
        return None


def _safe_str(value: object) -> str:
    try:
        s = str(value or "")
    except Exception:
        return ""
    return s.replace("\n", " ").replace("\r", " ").strip()


def _safe_float(value: object) -> float | None:
    try:
        return float(value)
    except Exception:
        return None


def _call0(obj: object, name: str) -> object | None:
    try:
        fn = getattr(obj, name)
    except Exception:
        return None
    try:
        return fn()
    except Exception:
        return None


def _normalize_state(raw: object) -> NowPlayingState:
    s = _safe_str(raw).lower()
    if "play" in s:
        return "playing"
    if "pause" in s:
        return "paused"
    if s:
        return "stopped"
    return "stopped"


@lru_cache(maxsize=8)
def _sb_app(bundle_id: str) -> object | None:
    try:
        from ScriptingBridge import SBApplication  # type: ignore[import-not-found]
    except Exception:
        return None
    try:
        return SBApplication.applicationWithBundleIdentifier_(bundle_id)
    except Exception:
        return None


class AppleMusicNowPlaying:
    bundle_id = "com.apple.Music"

    def _app(self) -> object | None:
        return _sb_app(self.bundle_id)

    def current(self) -> NowPlayingInfo | None:
        app = self._app()
        if app is None:
            return None

        running = _call0(app, "isRunning")
        if running is not None and not bool(running):
            return None

        # Music scripting: playerState(), currentTrack(), playerPosition()
        state = _normalize_state(_call0(app, "playerState"))
        track = _call0(app, "currentTrack")
        if track is None and state != "playing":
            return None

        title = _safe_str(_call0(track, "name")) if track is not None else ""
        artist = _safe_str(_call0(track, "artist")) if track is not None else ""
        album = _safe_str(_call0(track, "album")) if track is not None else ""
        duration = _safe_float(_call0(track, "duration")) if track is not None else None
        elapsed = _safe_float(_call0(app, "playerPosition"))

        return NowPlayingInfo(
            app="Music",
            state=state if state != "stopped" else "paused",
            title=title,
            artist=artist,
            album=album,
            elapsed=elapsed,
            duration=duration,
        )

    def playpause(self) -> bool:
        app = self._app()
        if app is None:
            return False
        return _call0(app, "playpause") is not None

    def next_track(self) -> bool:
        app = self._app()
        if app is None:
            return False
        return (
            _call0(app, "nextTrack") is not None
            or _call0(app, "nextTrack_") is not None
            or _call0(app, "next") is not None
        )

    def previous_track(self) -> bool:
        app = self._app()
        if app is None:
            return False
        return (
            _call0(app, "previousTrack") is not None
            or _call0(app, "previousTrack_") is not None
            or _call0(app, "previous") is not None
        )


class SpotifyNowPlaying:
    bundle_id = "com.spotify.client"

    def _app(self) -> object | None:
        return _sb_app(self.bundle_id)

    def current(self) -> NowPlayingInfo | None:
        app = self._app()
        if app is None:
            return None

        running = _call0(app, "isRunning")
        if running is not None and not bool(running):
            return None

        state = _normalize_state(_call0(app, "playerState"))
        track = _call0(app, "currentTrack")
        if track is None and state != "playing":
            return None

        title = _safe_str(_call0(track, "name")) if track is not None else ""
        artist = _safe_str(_call0(track, "artist")) if track is not None else ""
        album = _safe_str(_call0(track, "album")) if track is not None else ""
        duration_ms = _safe_float(_call0(track, "duration")) if track is not None else None
        duration = (duration_ms / 1000.0) if duration_ms else None
        elapsed = _safe_float(_call0(app, "playerPosition"))

        return NowPlayingInfo(
            app="Spotify",
            state=state if state != "stopped" else "paused",
            title=title,
            artist=artist,
            album=album,
            elapsed=elapsed,
            duration=duration,
        )

    def playpause(self) -> bool:
        app = self._app()
        if app is None:
            return False
        return _call0(app, "playpause") is not None

    def next_track(self) -> bool:
        app = self._app()
        if app is None:
            return False
        return _call0(app, "nextTrack") is not None or _call0(app, "next") is not None

    def previous_track(self) -> bool:
        app = self._app()
        if app is None:
            return False
        return _call0(app, "previousTrack") is not None or _call0(app, "previous") is not None


@dataclass(frozen=True, slots=True)
class BrowserBridgeNowPlayingState:
    ts: int
    info: NowPlayingInfo
    source: str = "browser_bridge"


def default_browser_bridge_state_path() -> Path:
    env = _safe_str(os.environ.get("SBAR_NOW_PLAYING_BRIDGE_PATH") or "").strip()
    if env:
        try:
            return Path(env).expanduser()
        except Exception:
            return Path(env)

    cache_home = _safe_str(os.environ.get("XDG_CACHE_HOME") or "").strip()
    if cache_home:
        return Path(cache_home).expanduser() / "sbar-python" / "now_playing.json"
    return Path.home() / ".cache" / "sbar-python" / "now_playing.json"


def _read_json(path: Path) -> object | None:
    try:
        raw = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        return None
    except Exception:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


def parse_browser_bridge_state(obj: object) -> BrowserBridgeNowPlayingState | None:
    if not isinstance(obj, dict):
        return None

    ts = _safe_int(obj.get("ts")) or _safe_int(obj.get("timestamp")) or int(time.time())
    app = _safe_str(obj.get("app") or obj.get("application") or "Browser")
    state = _normalize_state(obj.get("state") or obj.get("playback") or "")
    title = _safe_str(obj.get("title") or "")
    artist = _safe_str(obj.get("artist") or "")
    album = _safe_str(obj.get("album") or "")

    elapsed = _safe_float(obj.get("elapsed"))
    duration = _safe_float(obj.get("duration"))

    return BrowserBridgeNowPlayingState(
        ts=int(ts),
        info=NowPlayingInfo(
            app=app or "Browser",
            state=state,
            title=title,
            artist=artist,
            album=album,
            elapsed=elapsed,
            duration=duration,
        ),
        source=_safe_str(obj.get("source") or "browser_bridge"),
    )


class BrowserBridgeNowPlaying:
    def __init__(self, *, state_path: Path | None = None, ttl_seconds: int = 30) -> None:
        self.state_path = state_path or default_browser_bridge_state_path()
        self.ttl_seconds = int(ttl_seconds)

    def current(self) -> NowPlayingInfo | None:
        obj = _read_json(self.state_path)
        state = parse_browser_bridge_state(obj)
        if state is None:
            return None
        if self.ttl_seconds > 0 and (int(time.time()) - int(state.ts)) > int(self.ttl_seconds):
            return None
        if not state.info.title and not state.info.artist and not state.info.album:
            return None
        return state.info

    def playpause(self) -> bool:
        return False

    def next_track(self) -> bool:
        return False

    def previous_track(self) -> bool:
        return False


class BestEffortNowPlaying:
    def __init__(
        self,
        providers: list[NowPlayingProvider] | None = None,
        *,
        browser_bridge_path: Path | None = None,
        browser_bridge_ttl_seconds: int = 30,
    ) -> None:
        if providers is not None:
            self.providers = providers
            return

        base: list[NowPlayingProvider] = [SpotifyNowPlaying(), AppleMusicNowPlaying()]
        if browser_bridge_path is not None:
            base.insert(0, BrowserBridgeNowPlaying(state_path=browser_bridge_path, ttl_seconds=browser_bridge_ttl_seconds))
        self.providers = base

    def current(self) -> NowPlayingInfo | None:
        best: NowPlayingInfo | None = None
        for provider in self.providers:
            info = provider.current()
            if info is None:
                continue
            if info.state == "playing":
                return info
            best = best or info
        return best

    def playpause(self) -> bool:
        for provider in self.providers:
            if provider.playpause():
                return True
        return False

    def next_track(self) -> bool:
        for provider in self.providers:
            if provider.next_track():
                return True
        return False

    def previous_track(self) -> bool:
        for provider in self.providers:
            if provider.previous_track():
                return True
        return False


__all__ = [
    "AppleMusicNowPlaying",
    "BrowserBridgeNowPlaying",
    "BrowserBridgeNowPlayingState",
    "BestEffortNowPlaying",
    "NowPlayingInfo",
    "NowPlayingProvider",
    "NowPlayingState",
    "SpotifyNowPlaying",
    "default_browser_bridge_state_path",
    "parse_browser_bridge_state",
]
