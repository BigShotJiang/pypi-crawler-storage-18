from __future__ import annotations

from enum import IntFlag

from Quartz import (
    CGEventCreateKeyboardEvent,
    CGEventPost,
    CGEventSetFlags,
    kCGEventFlagMaskAlternate,
    kCGEventFlagMaskCommand,
    kCGEventFlagMaskControl,
    kCGEventFlagMaskShift,
    kCGHIDEventTap,
)


class KeyModifier(IntFlag):
    SHIFT = 1 << 0
    CONTROL = 1 << 1
    OPTION = 1 << 2
    COMMAND = 1 << 3


def _cg_flags(modifiers: KeyModifier) -> int:
    flags = 0
    if modifiers & KeyModifier.SHIFT:
        flags |= int(kCGEventFlagMaskShift)
    if modifiers & KeyModifier.CONTROL:
        flags |= int(kCGEventFlagMaskControl)
    if modifiers & KeyModifier.OPTION:
        flags |= int(kCGEventFlagMaskAlternate)
    if modifiers & KeyModifier.COMMAND:
        flags |= int(kCGEventFlagMaskCommand)
    return flags


def send_keycode(keycode: int, *, key_down: bool, modifiers: KeyModifier = KeyModifier(0)) -> None:
    try:
        event = CGEventCreateKeyboardEvent(None, int(keycode), bool(key_down))
        if event is None:
            return
        CGEventSetFlags(event, _cg_flags(modifiers))
        CGEventPost(kCGHIDEventTap, event)
    except Exception:
        return


def send_key_combo(keycode: int, *, modifiers: KeyModifier = KeyModifier(0)) -> None:
    send_keycode(keycode, key_down=True, modifiers=modifiers)
    send_keycode(keycode, key_down=False, modifiers=modifiers)


__all__ = ["KeyModifier", "send_key_combo", "send_keycode"]

