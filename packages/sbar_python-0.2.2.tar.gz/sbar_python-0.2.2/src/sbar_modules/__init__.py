from __future__ import annotations

from importlib import import_module
from typing import TYPE_CHECKING, Any


__all__ = [
    "clipboard",
    "cpu",
    "github",
    "ipinfo",
    "keychain",
    "keys",
    "location",
    "lyrics",
    "menus",
    "network",
    "now_playing",
    "spaces",
    "time_machine",
    "volume",
    "weather",
    "wifi",
    # clipboard
    "copy",
    # keychain
    "get_generic_password",
    # keys
    "KeyModifier",
    "send_key_combo",
    "send_keycode",
    # volume
    "change_output_volume_percent",
    "default_output_device_id",
    "get_output_volume_percent",
    "get_output_volume_scalar",
    "set_output_volume_percent",
    "set_output_volume_scalar",
    # cpu
    "CpuLoadMonitor",
    "CpuLoadSample",
    # github
    "GitHubProvider",
    "GitHubSearchResult",
    # ipinfo
    "IpInfo",
    "IpInfoProvider",
    "IpInfoSource",
    "parse_ipinfo",
    # location
    "BestEffortLocationProvider",
    "CoreLocationProvider",
    "IpApiLocationProvider",
    "Location",
    "LocationProvider",
    "StaticLocationProvider",
    "resolve_location",
    "reverse_geocode_label",
    # lyrics
    "LyricLine",
    "Lyrics",
    "LyricsSource",
    "LrclibLyricsProvider",
    "best_effort_lines",
    "parse_lrc",
    # network
    "NetworkInterfaceBytes",
    "NetworkThroughput",
    "NetworkThroughputMonitor",
    "format_bps",
    # menus
    "MenuBarItem",
    "is_accessibility_trusted",
    "list_menu_items",
    "list_menus",
    "list_extra_menus",
    "select_extra_menu",
    "select_menu",
    # now_playing
    "AppleMusicNowPlaying",
    "BestEffortNowPlaying",
    "NowPlayingInfo",
    "NowPlayingProvider",
    "NowPlayingState",
    "SpotifyNowPlaying",
    "BrowserBridgeNowPlaying",
    "BrowserBridgeNowPlayingState",
    "default_browser_bridge_state_path",
    "parse_browser_bridge_state",
    # spaces
    "encode_space_snapshot_apps",
    "snapshot_on_screen_apps",
    # time_machine
    "TimeMachineDestination",
    "TimeMachinePhase",
    "TimeMachineStatus",
    "get_time_machine_status",
    # weather
    "CacheFile",
    "OpenWeatherCurrent",
    "OpenWeatherProvider",
    "owm_icon_for",
    # wifi
    "WifiDetails",
    "WifiProvider",
]

_SUBMODULES: frozenset[str] = frozenset(
    {
        "clipboard",
        "cpu",
        "github",
        "ipinfo",
        "keychain",
        "keys",
        "location",
        "lyrics",
        "menus",
        "network",
        "now_playing",
        "spaces",
        "time_machine",
        "volume",
        "weather",
        "wifi",
    }
)

_EXPORT_TO_MODULE: dict[str, str] = {
    # clipboard
    "copy": "clipboard",
    # keychain
    "get_generic_password": "keychain",
    # keys
    "KeyModifier": "keys",
    "send_key_combo": "keys",
    "send_keycode": "keys",
    # volume
    "change_output_volume_percent": "volume",
    "default_output_device_id": "volume",
    "get_output_volume_percent": "volume",
    "get_output_volume_scalar": "volume",
    "set_output_volume_percent": "volume",
    "set_output_volume_scalar": "volume",
    # cpu
    "CpuLoadMonitor": "cpu",
    "CpuLoadSample": "cpu",
    # github
    "GitHubProvider": "github",
    "GitHubSearchResult": "github",
    # ipinfo
    "IpInfo": "ipinfo",
    "IpInfoProvider": "ipinfo",
    "IpInfoSource": "ipinfo",
    "parse_ipinfo": "ipinfo",
    # location
    "BestEffortLocationProvider": "location",
    "CoreLocationProvider": "location",
    "IpApiLocationProvider": "location",
    "Location": "location",
    "LocationProvider": "location",
    "StaticLocationProvider": "location",
    "resolve_location": "location",
    "reverse_geocode_label": "location",
    # lyrics
    "LyricLine": "lyrics",
    "Lyrics": "lyrics",
    "LyricsSource": "lyrics",
    "LrclibLyricsProvider": "lyrics",
    "best_effort_lines": "lyrics",
    "parse_lrc": "lyrics",
    # network
    "NetworkInterfaceBytes": "network",
    "NetworkThroughput": "network",
    "NetworkThroughputMonitor": "network",
    "format_bps": "network",
    # menus
    "MenuBarItem": "menus",
    "is_accessibility_trusted": "menus",
    "list_menu_items": "menus",
    "list_menus": "menus",
    "list_extra_menus": "menus",
    "select_extra_menu": "menus",
    "select_menu": "menus",
    # now_playing
    "AppleMusicNowPlaying": "now_playing",
    "BestEffortNowPlaying": "now_playing",
    "NowPlayingInfo": "now_playing",
    "NowPlayingProvider": "now_playing",
    "NowPlayingState": "now_playing",
    "SpotifyNowPlaying": "now_playing",
    "BrowserBridgeNowPlaying": "now_playing",
    "BrowserBridgeNowPlayingState": "now_playing",
    "default_browser_bridge_state_path": "now_playing",
    "parse_browser_bridge_state": "now_playing",
    # spaces
    "encode_space_snapshot_apps": "spaces",
    "snapshot_on_screen_apps": "spaces",
    # time_machine
    "TimeMachineDestination": "time_machine",
    "TimeMachinePhase": "time_machine",
    "TimeMachineStatus": "time_machine",
    "get_time_machine_status": "time_machine",
    # weather
    "CacheFile": "weather",
    "OpenWeatherCurrent": "weather",
    "OpenWeatherProvider": "weather",
    "owm_icon_for": "weather",
    # wifi
    "WifiDetails": "wifi",
    "WifiProvider": "wifi",
}


def __getattr__(name: str) -> Any:
    if name in _SUBMODULES:
        return import_module(f"{__name__}.{name}")

    mod_name = _EXPORT_TO_MODULE.get(name)
    if mod_name:
        mod = import_module(f"{__name__}.{mod_name}")
        return getattr(mod, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


if TYPE_CHECKING:
    from . import (
        clipboard,
        cpu,
        github,
        ipinfo,
        keychain,
        keys,
        location,
        lyrics,
        menus,
        network,
        now_playing,
        spaces,
        time_machine,
        volume,
        weather,
        wifi,
    )
    from .clipboard import copy
    from .cpu import CpuLoadMonitor, CpuLoadSample
    from .github import GitHubProvider, GitHubSearchResult
    from .ipinfo import IpInfo, IpInfoProvider, IpInfoSource, parse_ipinfo
    from .keychain import get_generic_password
    from .keys import KeyModifier, send_key_combo, send_keycode
    from .location import (
        BestEffortLocationProvider,
        CoreLocationProvider,
        IpApiLocationProvider,
        Location,
        LocationProvider,
        StaticLocationProvider,
        resolve_location,
        reverse_geocode_label,
    )
    from .lyrics import LyricLine, Lyrics, LyricsSource, LrclibLyricsProvider, best_effort_lines, parse_lrc
    from .network import (
        NetworkInterfaceBytes,
        NetworkThroughput,
        NetworkThroughputMonitor,
        format_bps,
    )
    from .menus import (
        MenuBarItem,
        is_accessibility_trusted,
        list_extra_menus,
        list_menu_items,
        list_menus,
        select_extra_menu,
        select_menu,
    )
    from .now_playing import (
        AppleMusicNowPlaying,
        BestEffortNowPlaying,
        BrowserBridgeNowPlaying,
        BrowserBridgeNowPlayingState,
        NowPlayingInfo,
        NowPlayingProvider,
        NowPlayingState,
        SpotifyNowPlaying,
        default_browser_bridge_state_path,
        parse_browser_bridge_state,
    )
    from .spaces import encode_space_snapshot_apps, snapshot_on_screen_apps
    from .time_machine import TimeMachineDestination, TimeMachinePhase, TimeMachineStatus, get_time_machine_status
    from .volume import (
        change_output_volume_percent,
        default_output_device_id,
        get_output_volume_percent,
        get_output_volume_scalar,
        set_output_volume_percent,
        set_output_volume_scalar,
    )
    from .weather import (
        CacheFile,
        OpenWeatherCurrent,
        OpenWeatherProvider,
        owm_icon_for,
    )
    from .wifi import WifiDetails, WifiProvider
