from __future__ import annotations

import json
import threading
import time
import urllib.request
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Protocol


_CORELOCATION_INIT_LOCK = threading.Lock()
_CORELOCATION: object | None = None
_OBJC: object | None = None
_ONE_SHOT_LOCATOR_CLASS: object | None = None


@dataclass(frozen=True, slots=True)
class Location:
    lat: float
    lon: float
    label: str | None = None


class LocationProvider(Protocol):
    def resolve(self) -> Location | None: ...


def _request_corelocation(
    *,
    timeout_seconds: float = 15.0,
    desired_accuracy: float | None = None,
) -> tuple[float, float] | None:
    try:
        import CoreLocation  # type: ignore[import-not-found]
        import objc  # type: ignore[import-not-found]
        from Foundation import NSDate, NSObject, NSRunLoop  # type: ignore[import-not-found]
    except Exception:
        return None

    try:
        if not bool(CoreLocation.CLLocationManager.locationServicesEnabled()):
            return None
    except Exception:
        return None

    desired = (
        float(CoreLocation.kCLLocationAccuracyHundredMeters)
        if desired_accuracy is None
        else float(desired_accuracy)
    )

    global _CORELOCATION, _OBJC, _ONE_SHOT_LOCATOR_CLASS
    _CORELOCATION = CoreLocation
    _OBJC = objc

    if _ONE_SHOT_LOCATOR_CLASS is None:
        with _CORELOCATION_INIT_LOCK:
            if _ONE_SHOT_LOCATOR_CLASS is None:
                class _OneShotLocator(NSObject):
                    def init(self) -> _OneShotLocator | None:  # type: ignore[override]
                        self = _OBJC.super(_OneShotLocator, self).init()
                        if self is None:
                            return None

                        self.manager = _CORELOCATION.CLLocationManager.alloc().init()
                        self.manager.setDelegate_(self)
                        self.has_started_requests = False

                        self._done = threading.Event()
                        self._coord: tuple[float, float] | None = None
                        self._status: int = 3  # 0=ok, 1=error, 2=denied, 3=timeout
                        return self

                    def _authorization_status(self) -> int:
                        try:
                            return int(self.manager.authorizationStatus())
                        except Exception:
                            try:
                                return int(_CORELOCATION.CLLocationManager.authorizationStatus())
                            except Exception:
                                return 0

                    def _start_requests_if_authorized(self) -> None:
                        if self.has_started_requests:
                            return

                        status = self._authorization_status()
                        denied = int(getattr(_CORELOCATION, "kCLAuthorizationStatusDenied", 2))
                        restricted = int(getattr(_CORELOCATION, "kCLAuthorizationStatusRestricted", 1))
                        if status in {denied, restricted}:
                            self._status = 2
                            self._done.set()
                            return

                        authorized_values: set[int] = set()
                        for name in (
                            "kCLAuthorizationStatusAuthorizedAlways",
                            "kCLAuthorizationStatusAuthorizedWhenInUse",
                            "kCLAuthorizationStatusAuthorized",
                        ):
                            v = getattr(_CORELOCATION, name, None)
                            if v is not None:
                                authorized_values.add(int(v))
                        if authorized_values and status not in authorized_values:
                            return

                        self.has_started_requests = True
                        if hasattr(self.manager, "requestLocation"):
                            try:
                                self.manager.requestLocation()
                            except Exception:
                                pass
                        try:
                            self.manager.startUpdatingLocation()
                        except Exception:
                            self._status = 1
                            self._done.set()

                    def locationManagerDidChangeAuthorization_(self, _manager: object) -> None:
                        self._start_requests_if_authorized()

                    def locationManager_didChangeAuthorizationStatus_(self, _manager: object, _status: int) -> None:
                        self._start_requests_if_authorized()

                    def locationManager_didUpdateLocations_(self, _manager: object, locations: object) -> None:
                        loc = None
                        try:
                            loc = locations.lastObject()
                        except Exception:
                            try:
                                loc = locations[-1]
                            except Exception:
                                loc = None
                        if loc is None:
                            return
                        try:
                            coord = loc.coordinate()
                            lat = float(coord.latitude)
                            lon = float(coord.longitude)
                        except Exception:
                            return
                        self._coord = (lat, lon)
                        self._status = 0
                        self._done.set()

                    def locationManager_didFailWithError_(self, _manager: object, error: object) -> None:
                        domain = ""
                        code = -1
                        try:
                            domain = str(error.domain())
                        except Exception:
                            domain = ""
                        try:
                            code = int(error.code())
                        except Exception:
                            code = -1

                        kcle_domain = str(getattr(_CORELOCATION, "kCLErrorDomain", "kCLErrorDomain"))
                        denied_code = int(getattr(_CORELOCATION, "kCLErrorDenied", 1))
                        if domain == kcle_domain and code == denied_code:
                            self._status = 2
                        else:
                            self._status = 1
                        self._done.set()

                _ONE_SHOT_LOCATOR_CLASS = _OneShotLocator

    locator = _ONE_SHOT_LOCATOR_CLASS.alloc().init()
    if locator is None:
        return None

    try:
        locator.manager.setDesiredAccuracy_(desired)
    except Exception:
        pass

    if hasattr(locator.manager, "requestWhenInUseAuthorization"):
        try:
            locator.manager.requestWhenInUseAuthorization()
        except Exception:
            pass
    locator._start_requests_if_authorized()

    run_loop = NSRunLoop.currentRunLoop()
    deadline = time.monotonic() + float(timeout_seconds)
    while not locator._done.is_set() and time.monotonic() < deadline:
        run_loop.runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.1))

    try:
        locator.manager.stopUpdatingLocation()
    except Exception:
        pass

    if locator._status != 0 or locator._coord is None:
        return None
    return locator._coord


def _read_location_txt(path: Path) -> tuple[int, Location] | None:
    try:
        raw = path.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return None

    parts = raw.split("|")
    if len(parts) < 3:
        return None

    try:
        ts = int(float(parts[0]))
        lat = float(parts[1])
        lon = float(parts[2])
    except ValueError:
        return None

    label = parts[3] if len(parts) >= 4 else ""
    label = label.strip()
    return ts, Location(lat=lat, lon=lon, label=label or None)


def _write_location_txt(path: Path, location: Location) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    label = location.label or ""
    path.write_text(f"{int(time.time())}|{location.lat}|{location.lon}|{label}", encoding="utf-8")


def reverse_geocode_label(lat: float, lon: float, *, timeout_seconds: float = 4.0) -> str | None:
    url = (
        "https://nominatim.openstreetmap.org/reverse"
        f"?format=jsonv2&lat={lat}&lon={lon}&zoom=12&addressdetails=1"
    )
    req = urllib.request.Request(url, headers={"User-Agent": "sbar-python"})
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
    except Exception:
        return None

    address = data.get("address") or {}
    for key in (
        "neighbourhood",
        "suburb",
        "quarter",
        "residential",
        "hamlet",
        "village",
        "town",
        "city_district",
        "district",
        "city",
        "county",
        "state",
        "country",
    ):
        value = address.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    name = data.get("name")
    if isinstance(name, str) and name.strip():
        return name.strip()

    display = data.get("display_name")
    if isinstance(display, str) and display.strip():
        first = display.split(",", 1)[0].strip()
        return first or None

    return None


@dataclass(frozen=True, slots=True)
class StaticLocationProvider:
    location: Location

    def resolve(self) -> Location:
        return self.location


class CoreLocationProvider:
    def __init__(
        self,
        *,
        cache_path: Path | None = None,
        ttl_seconds: int = 1800,
        timeout_seconds: float = 15.0,
        desired_accuracy: float | None = None,
    ) -> None:
        self.cache_path = cache_path
        self.ttl_seconds = ttl_seconds
        self.timeout_seconds = timeout_seconds
        self.desired_accuracy = desired_accuracy
        self._mem_ts: float | None = None
        self._mem_location: Location | None = None

    def resolve(self) -> Location | None:
        if self.ttl_seconds > 0 and self._mem_location is not None and self._mem_ts is not None:
            if (time.time() - self._mem_ts) < float(self.ttl_seconds):
                return self._mem_location

        if self.cache_path is not None:
            cached = _read_location_txt(self.cache_path)
            if cached is not None:
                ts, location = cached
                if int(time.time()) - ts < self.ttl_seconds:
                    self._mem_location = location
                    self._mem_ts = float(ts)
                    return location

        coord = _request_corelocation(
            timeout_seconds=self.timeout_seconds,
            desired_accuracy=self.desired_accuracy,
        )
        if coord is None:
            return None
        lat, lon = coord
        location = Location(lat=lat, lon=lon)
        self._mem_location = location
        self._mem_ts = time.time()
        if self.cache_path is not None:
            _write_location_txt(self.cache_path, location)
        return location


class BestEffortLocationProvider:
    def __init__(
        self,
        *,
        cache_path: Path | None = None,
        ttl_seconds: int = 1800,
        timeout_seconds: float = 15.0,
        desired_accuracy: float | None = None,
        ip_fallback: bool = True,
        reverse_geocode: bool = True,
    ) -> None:
        self.cache_path = cache_path
        self.ttl_seconds = ttl_seconds
        self.timeout_seconds = timeout_seconds
        self.desired_accuracy = desired_accuracy
        self.ip_fallback = ip_fallback
        self.reverse_geocode = reverse_geocode
        self._mem_ts: float | None = None
        self._mem_location: Location | None = None

    def resolve(self) -> Location | None:
        if self.ttl_seconds > 0 and self._mem_location is not None and self._mem_ts is not None:
            if (time.time() - self._mem_ts) < float(self.ttl_seconds):
                return self._mem_location

        if self.cache_path is not None:
            cached = _read_location_txt(self.cache_path)
            if cached is not None:
                ts, location = cached
                if int(time.time()) - ts < self.ttl_seconds:
                    self._mem_location = location
                    self._mem_ts = float(ts)
                    return location

        coord = _request_corelocation(
            timeout_seconds=self.timeout_seconds,
            desired_accuracy=self.desired_accuracy,
        )
        if coord is not None:
            lat, lon = coord
            label = reverse_geocode_label(lat, lon) if self.reverse_geocode else None
            location = Location(lat=lat, lon=lon, label=label)
            self._mem_location = location
            self._mem_ts = time.time()
            if self.cache_path is not None:
                _write_location_txt(self.cache_path, location)
            return location

        if not self.ip_fallback:
            return None

        location = IpApiLocationProvider(ttl_seconds=self.ttl_seconds, cache_path=self.cache_path).resolve()
        if location is None:
            return None

        if self.reverse_geocode and location.label is None:
            label = reverse_geocode_label(location.lat, location.lon)
            if label:
                location = Location(lat=location.lat, lon=location.lon, label=label)
                if self.cache_path is not None:
                    _write_location_txt(self.cache_path, location)

        self._mem_location = location
        self._mem_ts = time.time()
        return location


@lru_cache(maxsize=32)
def _cached_best_effort_provider(
    *,
    cache_path: Path | None,
    ttl_seconds: int,
    timeout_seconds: float,
    desired_accuracy: float | None,
    ip_fallback: bool,
    reverse_geocode: bool,
) -> BestEffortLocationProvider:
    return BestEffortLocationProvider(
        cache_path=cache_path,
        ttl_seconds=ttl_seconds,
        timeout_seconds=timeout_seconds,
        desired_accuracy=desired_accuracy,
        ip_fallback=ip_fallback,
        reverse_geocode=reverse_geocode,
    )


def resolve_location(
    *,
    cache_path: Path | None = None,
    ttl_seconds: int = 1800,
    timeout_seconds: float = 15.0,
    desired_accuracy: float | None = None,
    ip_fallback: bool = True,
    reverse_geocode: bool = True,
) -> Location | None:
    return _cached_best_effort_provider(
        cache_path=cache_path,
        ttl_seconds=ttl_seconds,
        timeout_seconds=timeout_seconds,
        desired_accuracy=desired_accuracy,
        ip_fallback=ip_fallback,
        reverse_geocode=reverse_geocode,
    ).resolve()


class IpApiLocationProvider:
    def __init__(self, *, ttl_seconds: int = 1800, cache_path: Path | None = None) -> None:
        self.ttl_seconds = ttl_seconds
        self.cache_path = cache_path

    def resolve(self) -> Location | None:
        if self.cache_path is not None:
            cached = _read_location_txt(self.cache_path)
            if cached is not None:
                ts, location = cached
                if int(time.time()) - ts < self.ttl_seconds:
                    return location

        req = urllib.request.Request("https://ipapi.co/json/", headers={"User-Agent": "sbar-python"})
        try:
            with urllib.request.urlopen(req, timeout=4.0) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        except Exception:
            return None

        try:
            lat = float(data.get("latitude"))
            lon = float(data.get("longitude"))
        except (TypeError, ValueError):
            return None

        city = data.get("city") or ""
        region = data.get("region") or ""
        label = str(city or region or "").strip() or None

        location = Location(lat=lat, lon=lon, label=label)
        if self.cache_path is not None:
            _write_location_txt(self.cache_path, location)
        return location


__all__ = [
    "BestEffortLocationProvider",
    "CoreLocationProvider",
    "IpApiLocationProvider",
    "Location",
    "LocationProvider",
    "StaticLocationProvider",
    "resolve_location",
    "reverse_geocode_label",
]
