from __future__ import annotations

from dataclasses import dataclass

import ApplicationServices as AS
import Quartz


def is_accessibility_trusted(*, prompt: bool = False) -> bool:
    """检查当前进程是否拥有辅助功能（Accessibility）权限。"""
    opts = {AS.kAXTrustedCheckOptionPrompt: bool(prompt)}
    return bool(AS.AXIsProcessTrustedWithOptions(opts))


def _safe_str(value: object) -> str:
    try:
        s = str(value or "")
    except Exception:
        return ""
    return s.replace("\n", " ").replace("\r", " ").strip()


def _ax_copy(element: object, attr: object) -> object | None:
    err, value = AS.AXUIElementCopyAttributeValue(element, attr, None)
    if err != 0:
        return None
    return value


def _ax_children(element: object, attr: object) -> list[object]:
    value = _ax_copy(element, attr)
    if value is None:
        return []
    try:
        return list(value)
    except Exception:
        return []


def _ax_point(element: object, attr: object) -> Quartz.CGPoint | None:
    value = _ax_copy(element, attr)
    if value is None:
        return None
    try:
        ok, point = AS.AXValueGetValue(value, AS.kAXValueCGPointType, None)
    except Exception:
        return None
    return point if ok else None


def _frontmost_app_pid() -> int | None:
    try:
        from AppKit import NSWorkspace  # type: ignore[import-not-found]
    except Exception:
        return None
    try:
        app = NSWorkspace.sharedWorkspace().frontmostApplication()
        if app is None:
            return None
        return int(app.processIdentifier())
    except Exception:
        return None


def _frontmost_app_ax(*, prompt: bool) -> object | None:
    if not is_accessibility_trusted(prompt=prompt):
        return None
    pid = _frontmost_app_pid()
    if pid is None:
        return None
    try:
        return AS.AXUIElementCreateApplication(pid)
    except Exception:
        return None


def _menu_bar_items(*, prompt: bool) -> list[object]:
    if not is_accessibility_trusted(prompt=prompt):
        return []

    app = _frontmost_app_ax(prompt=prompt)
    if app is None:
        return []

    menubar = _ax_copy(app, AS.kAXMenuBarAttribute)
    if menubar is None:
        return []

    return _ax_children(menubar, AS.kAXVisibleChildrenAttribute)


@dataclass(frozen=True, slots=True)
class MenuBarItem:
    index: int
    title: str


def list_menus(*, prompt: bool = False) -> list[str]:
    """列出当前菜单栏的顶层菜单标题。"""
    items = _menu_bar_items(prompt=prompt)
    out: list[str] = []
    for item in items:
        title = _ax_copy(item, AS.kAXTitleAttribute)
        if title is None:
            title = _ax_copy(item, AS.kAXDescriptionAttribute)
        out.append(_safe_str(title))
    return out


def list_menu_items(*, prompt: bool = False) -> list[MenuBarItem]:
    """列出当前菜单栏顶层菜单（包含 index）。"""
    titles = list_menus(prompt=prompt)
    return [MenuBarItem(index=i, title=t) for i, t in enumerate(titles)]


def select_menu(index: int, *, prompt: bool = True) -> bool:
    """按下菜单栏中的某个顶层菜单（0 表示 Apple 菜单）。"""
    items = _menu_bar_items(prompt=prompt)
    if index < 0 or index >= len(items):
        return False
    err = AS.AXUIElementPerformAction(items[index], AS.kAXPressAction)
    return err == 0


@dataclass(frozen=True, slots=True)
class ExtraMenuWindow:
    """通过 CoreGraphics 扫描到的状态栏/extra menu 窗口快照。"""

    alias: str
    owner: str
    name: str
    pid: int
    x: float


def _extra_menu_windows() -> list[ExtraMenuWindow]:
    info_list = Quartz.CGWindowListCopyWindowInfo(Quartz.kCGWindowListOptionAll, Quartz.kCGNullWindowID)
    if not info_list:
        return []

    out: list[ExtraMenuWindow] = []
    for info in info_list:
        try:
            layer = int(info.get(Quartz.kCGWindowLayer, 0))
        except Exception:
            layer = 0
        if layer != 0x19:
            continue

        owner = info.get(Quartz.kCGWindowOwnerName)
        name = info.get(Quartz.kCGWindowName)
        pid = info.get(Quartz.kCGWindowOwnerPID)
        bounds = info.get(Quartz.kCGWindowBounds)
        if not owner or not name or not pid or not bounds:
            continue

        try:
            x = float(bounds.get("X"))
        except Exception:
            continue

        owner_s = str(owner)
        name_s = str(name)
        alias = f"{owner_s},{name_s}"
        try:
            pid_i = int(pid)
        except Exception:
            continue

        out.append(ExtraMenuWindow(alias=alias, owner=owner_s, name=name_s, pid=pid_i, x=x))
    return out


def list_extra_menus() -> list[str]:
    """列出可识别的右侧状态栏/extra menu alias（用于 `select_extra_menu`）。"""
    return [w.alias for w in _extra_menu_windows()]


def _best_match_extra_window(alias: str) -> ExtraMenuWindow | None:
    alias = alias.strip()
    if not alias:
        return None

    windows = _extra_menu_windows()
    if not windows:
        return None

    if "," in alias:
        for w in windows:
            if w.alias == alias:
                return w
        return None

    lowered = alias.lower()
    for w in windows:
        if w.owner.lower() == lowered or w.name.lower() == lowered:
            return w
    for w in windows:
        if lowered in w.alias.lower():
            return w
    return None


def select_extra_menu(alias: str, *, prompt: bool = True, tolerance_px: float = 10.0) -> bool:
    """
    best-effort：点击右侧状态栏/extra menu。

    - 无私有 SkyLight：无法强制显示自动隐藏的菜单栏，因此在“自动隐藏菜单栏”的场景可能失败。
    - `alias` 推荐使用 `list_extra_menus()` 返回的完整值（格式：`Owner,WindowName`）。
    """
    if not is_accessibility_trusted(prompt=prompt):
        return False

    win = _best_match_extra_window(alias)
    if win is None:
        return False

    app = AS.AXUIElementCreateApplication(win.pid)
    extras = _ax_copy(app, AS.kAXExtrasMenuBarAttribute)
    if extras is None:
        return False

    items = _ax_children(extras, AS.kAXVisibleChildrenAttribute)
    if not items:
        return False

    best: object | None = None
    best_dx = float("inf")
    for item in items:
        pos = _ax_point(item, AS.kAXPositionAttribute)
        if pos is None:
            continue
        dx = abs(float(pos.x) - win.x)
        if dx < best_dx:
            best_dx = dx
            best = item

    if best is None or best_dx > float(tolerance_px):
        return False

    try:
        AS.AXUIElementPerformAction(best, AS.kAXCancelAction)
    except Exception:
        pass
    try:
        import time

        time.sleep(0.15)
    except Exception:
        pass

    err = AS.AXUIElementPerformAction(best, AS.kAXPressAction)
    return err == 0


__all__ = [
    "ExtraMenuWindow",
    "MenuBarItem",
    "is_accessibility_trusted",
    "list_extra_menus",
    "list_menu_items",
    "list_menus",
    "select_extra_menu",
    "select_menu",
]
