from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Literal


LyricsSource = Literal["lrclib.net"]


@dataclass(frozen=True, slots=True)
class LyricLine:
    at: float
    text: str


@dataclass(frozen=True, slots=True)
class Lyrics:
    source: LyricsSource
    title: str
    artist: str
    plain: str = ""
    synced: tuple[LyricLine, ...] = ()

    def is_empty(self) -> bool:
        return not self.plain.strip() and not self.synced


def _safe_str(value: object) -> str:
    try:
        s = str(value or "")
    except Exception:
        return ""
    return s.replace("\r", "").strip()


_LRC_TIME_RE = re.compile(r"\[(\d+):(\d+(?:\.\d+)?)\]")


def parse_lrc(text: str) -> tuple[LyricLine, ...]:
    out: list[LyricLine] = []
    for raw_line in (text or "").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        times = list(_LRC_TIME_RE.finditer(line))
        if not times:
            continue
        lyric_text = _LRC_TIME_RE.sub("", line).strip()
        for m in times:
            mm = int(m.group(1))
            ss = float(m.group(2))
            out.append(LyricLine(at=(mm * 60.0 + ss), text=lyric_text))
    out.sort(key=lambda x: x.at)
    return tuple(out)


def _lines_around(synced: tuple[LyricLine, ...], *, at: float, radius: int = 2) -> list[str]:
    if not synced:
        return []
    i = 0
    # last index with at<=t
    for j, line in enumerate(synced):
        if line.at <= at + 1e-6:
            i = j
        else:
            break
    start = max(0, i - radius)
    end = min(len(synced), i + radius + 1)
    return [synced[k].text for k in range(start, end)]


def best_effort_lines(lyrics: Lyrics, *, elapsed: float | None, max_lines: int = 6) -> list[str]:
    if lyrics.synced and elapsed is not None:
        lines = _lines_around(lyrics.synced, at=float(elapsed), radius=max(1, (max_lines - 1) // 2))
        return lines[:max_lines]

    plain = [ln.strip() for ln in lyrics.plain.splitlines() if ln.strip()]
    return plain[:max_lines]


@dataclass(frozen=True, slots=True)
class _CacheEntry:
    ts: int
    lyrics: Lyrics


class LrclibLyricsProvider:
    def __init__(self, *, ttl_seconds: int = 6 * 3600, timeout_seconds: float = 4.0) -> None:
        self.ttl_seconds = ttl_seconds
        self.timeout_seconds = timeout_seconds
        self._mem: dict[tuple[str, str], _CacheEntry] = {}

    def _key(self, title: str, artist: str) -> tuple[str, str]:
        return (_safe_str(title).lower(), _safe_str(artist).lower())

    def cached(self, *, title: str, artist: str) -> Lyrics | None:
        key = self._key(title, artist)
        entry = self._mem.get(key)
        if entry is None:
            return None
        if (int(time.time()) - int(entry.ts)) >= int(self.ttl_seconds):
            return None
        return entry.lyrics

    def _url(self, *, title: str, artist: str) -> str:
        query = urllib.parse.urlencode({"track_name": title, "artist_name": artist})
        return f"https://lrclib.net/api/get?{query}"

    def fetch(self, *, title: str, artist: str, force: bool = False) -> Lyrics | None:
        title_s = _safe_str(title)
        artist_s = _safe_str(artist)
        if not title_s or not artist_s:
            return None

        if not force:
            cached = self.cached(title=title_s, artist=artist_s)
            if cached is not None:
                return cached

        req = urllib.request.Request(self._url(title=title_s, artist=artist_s), headers={"User-Agent": "sbar-python"})
        try:
            with urllib.request.urlopen(req, timeout=float(self.timeout_seconds)) as resp:
                raw = json.loads(resp.read().decode("utf-8", errors="ignore"))
        except Exception:
            return None

        if not isinstance(raw, dict):
            return None

        plain = _safe_str(raw.get("plainLyrics"))
        synced_raw = _safe_str(raw.get("syncedLyrics"))
        synced = parse_lrc(synced_raw) if synced_raw else ()
        lyrics = Lyrics(source="lrclib.net", title=title_s, artist=artist_s, plain=plain, synced=synced)
        self._mem[self._key(title_s, artist_s)] = _CacheEntry(ts=int(time.time()), lyrics=lyrics)
        return lyrics

    def fetch_async(self, callback: Any, *, title: str, artist: str, force: bool = False) -> None:
        """
        异步获取（后台线程 + 回调），避免阻塞 sbar 的事件回调。

        callback: `(lyrics: Lyrics | None) -> None`
        """
        import threading

        def run() -> None:
            lyrics = self.fetch(title=title, artist=artist, force=force)
            try:
                callback(lyrics)
            except Exception:
                return

        threading.Thread(target=run, daemon=True).start()


__all__ = [
    "LyricLine",
    "Lyrics",
    "LyricsSource",
    "LrclibLyricsProvider",
    "best_effort_lines",
    "parse_lrc",
]
