from __future__ import annotations

import json
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Literal


IpInfoSource = Literal["ipinfo.io"]


@dataclass(frozen=True, slots=True)
class IpInfo:
    source: IpInfoSource
    ip: str = ""
    city: str = ""
    region: str = ""
    country: str = ""
    org: str = ""
    lat: float | None = None
    lon: float | None = None

    def location_label(self) -> str:
        parts = [p for p in (self.city, self.region, self.country) if p]
        return ", ".join(parts)


def _safe_str(value: object) -> str:
    try:
        s = str(value or "")
    except Exception:
        return ""
    return s.replace("\n", " ").replace("\r", " ").strip()


def _parse_loc(value: object) -> tuple[float | None, float | None]:
    s = _safe_str(value)
    if not s or "," not in s:
        return None, None
    a, b = s.split(",", 1)
    try:
        return float(a), float(b)
    except Exception:
        return None, None


def parse_ipinfo(payload: dict[str, Any]) -> IpInfo:
    lat, lon = _parse_loc(payload.get("loc"))
    return IpInfo(
        source="ipinfo.io",
        ip=_safe_str(payload.get("ip")),
        city=_safe_str(payload.get("city")),
        region=_safe_str(payload.get("region")),
        country=_safe_str(payload.get("country")),
        org=_safe_str(payload.get("org")),
        lat=lat,
        lon=lon,
    )


@dataclass(frozen=True, slots=True)
class _CacheEntry:
    ts: int
    info: IpInfo


class IpInfoProvider:
    def __init__(self, *, ttl_seconds: int = 300, timeout_seconds: float = 2.0) -> None:
        self.ttl_seconds = ttl_seconds
        self.timeout_seconds = timeout_seconds
        self._mem: _CacheEntry | None = None

    def cached(self) -> IpInfo | None:
        now = int(time.time())
        mem = self._mem
        if mem is None:
            return None
        if (now - int(mem.ts)) >= int(self.ttl_seconds):
            return None
        return mem.info

    def fetch(self, *, force: bool = False) -> IpInfo | None:
        if not force:
            cached = self.cached()
            if cached is not None:
                return cached

        req = urllib.request.Request(
            "https://ipinfo.io/json",
            headers={"User-Agent": "sbar-python"},
        )
        try:
            with urllib.request.urlopen(req, timeout=float(self.timeout_seconds)) as resp:
                raw = json.loads(resp.read().decode("utf-8", errors="ignore"))
        except Exception:
            return None

        if not isinstance(raw, dict):
            return None
        info = parse_ipinfo(raw)
        self._mem = _CacheEntry(ts=int(time.time()), info=info)
        return info

    def fetch_async(self, callback: Any, *, force: bool = False) -> None:
        """
        异步获取（后台线程 + 回调），避免阻塞 sbar 的事件回调。

        callback: `(info: IpInfo | None) -> None`
        """
        import threading

        def run() -> None:
            info = self.fetch(force=force)
            try:
                callback(info)
            except Exception:
                return

        threading.Thread(target=run, daemon=True).start()


__all__ = [
    "IpInfo",
    "IpInfoProvider",
    "IpInfoSource",
    "parse_ipinfo",
]
