from __future__ import annotations

from AppKit import NSPasteboard, NSPasteboardTypeString


def copy(text: str) -> None:
    try:
        pasteboard = NSPasteboard.generalPasteboard()
        pasteboard.clearContents()
        pasteboard.setString_forType_(text, NSPasteboardTypeString)
    except Exception:
        return


__all__ = ["copy"]

