from __future__ import annotations

import os

import Security


def get_generic_password(*, service: str, account: str | None = None) -> str | None:
    user = account or os.environ.get("USER") or ""
    if not user:
        return None

    query = {
        Security.kSecClass: Security.kSecClassGenericPassword,
        Security.kSecAttrService: service,
        Security.kSecAttrAccount: user,
        Security.kSecMatchLimit: Security.kSecMatchLimitOne,
        Security.kSecReturnData: True,
    }

    try:
        out = Security.SecItemCopyMatching(query, None)
    except Exception:
        return None

    status: int
    data: object | None
    if isinstance(out, tuple) and len(out) == 2:
        status, data = out
    else:
        status, data = 0, out

    if int(status) != 0 or data is None:
        return None

    try:
        raw = bytes(data)
    except Exception:
        return None

    value = raw.decode("utf-8", errors="ignore").strip()
    return value or None


__all__ = ["get_generic_password"]

