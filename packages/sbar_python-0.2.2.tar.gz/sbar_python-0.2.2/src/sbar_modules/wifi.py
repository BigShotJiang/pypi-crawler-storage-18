from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Final


def _first_str(value: object) -> str | None:
    try:
        it = iter(value)  # type: ignore[arg-type]
    except Exception:
        return None
    for item in it:
        if isinstance(item, str) and item.strip():
            return item.strip()
    return None


@lru_cache(maxsize=1)
def _dynamic_store() -> object:
    import SystemConfiguration  # type: ignore[import-not-found]

    return SystemConfiguration.SCDynamicStoreCreate(None, "sbar-python", None, None)


def _ipv4_details(interface: str) -> tuple[str | None, str | None, str | None]:
    import SystemConfiguration  # type: ignore[import-not-found]

    store = _dynamic_store()

    ip: str | None = None
    mask: str | None = None
    router: str | None = None

    try:
        iface_v4 = SystemConfiguration.SCDynamicStoreCopyValue(store, f"State:/Network/Interface/{interface}/IPv4")
    except Exception:
        iface_v4 = None

    if iface_v4 is not None:
        try:
            ip = _first_str(iface_v4.get("Addresses"))  # type: ignore[no-any-return]
            mask = _first_str(iface_v4.get("SubnetMasks"))  # type: ignore[no-any-return]
        except Exception:
            ip, mask = None, None

    try:
        global_v4 = SystemConfiguration.SCDynamicStoreCopyValue(store, "State:/Network/Global/IPv4")
    except Exception:
        global_v4 = None

    if global_v4 is not None:
        try:
            primary = global_v4.get("PrimaryInterface")
            if str(primary or "") == interface:
                router_value = global_v4.get("Router")
                router = str(router_value).strip() if router_value else None
        except Exception:
            router = None

    return ip, mask, router


def _ipv6_connected(interface: str) -> bool:
    import SystemConfiguration  # type: ignore[import-not-found]

    store = _dynamic_store()
    try:
        iface_v6 = SystemConfiguration.SCDynamicStoreCopyValue(store, f"State:/Network/Interface/{interface}/IPv6")
    except Exception:
        return False
    if iface_v6 is None:
        return False

    try:
        addresses = iface_v6.get("Addresses")
    except Exception:
        return False
    try:
        return any(isinstance(a, str) and a.strip() for a in addresses)
    except Exception:
        return False


def _wifi_interface(interface: str) -> object | None:
    import CoreWLAN  # type: ignore[import-not-found]

    client = CoreWLAN.CWWiFiClient.sharedWiFiClient()
    if hasattr(client, "interfaceWithName_"):
        try:
            return client.interfaceWithName_(interface)
        except Exception:
            return None
    if hasattr(client, "interface"):
        try:
            iface = client.interface()
        except Exception:
            return None
        try:
            name = iface.interfaceName()
        except Exception:
            return iface
        return iface if str(name or "") == interface else None
    return None


def _phy_mode_name(mode: int) -> str | None:
    return {
        1: "802.11a",
        2: "802.11b",
        3: "802.11g",
        4: "802.11n",
        5: "802.11ac",
        6: "802.11ax",
    }.get(int(mode))


_SECURITY_NAMES: Final[dict[int, str]] = {
    0: "Open",
    1: "WEP",
    2: "WPA Personal",
    3: "WPA/WPA2 Personal",
    4: "WPA2 Personal",
    5: "Personal",
    6: "Dynamic WEP",
    7: "WPA Enterprise",
    8: "WPA/WPA2 Enterprise",
    9: "WPA2 Enterprise",
    10: "Enterprise",
    11: "WPA3 Personal",
    12: "WPA3 Enterprise",
    13: "WPA3 Transition",
    14: "OWE",
    15: "OWE Transition",
}


def _security_name(security: int) -> str | None:
    return _SECURITY_NAMES.get(int(security))


def _format_channel(channel: object) -> str | None:
    import CoreWLAN  # type: ignore[import-not-found]

    if channel is None:
        return None

    try:
        number = int(channel.channelNumber())
    except Exception:
        return None

    parts: list[str] = [str(number)]

    try:
        band = int(channel.channelBand())
    except Exception:
        band = 0
    band_name = {int(CoreWLAN.kCWChannelBand2GHz): "2.4GHz", int(CoreWLAN.kCWChannelBand5GHz): "5GHz", int(CoreWLAN.kCWChannelBand6GHz): "6GHz"}.get(band)
    if band_name:
        parts.append(band_name)

    try:
        width = int(channel.channelWidth())
    except Exception:
        width = 0
    width_name = {
        int(CoreWLAN.kCWChannelWidth20MHz): "20MHz",
        int(CoreWLAN.kCWChannelWidth40MHz): "40MHz",
        int(CoreWLAN.kCWChannelWidth80MHz): "80MHz",
        int(CoreWLAN.kCWChannelWidth160MHz): "160MHz",
    }.get(width)
    if width_name:
        parts.append(width_name)

    if len(parts) == 1:
        return parts[0]
    return f"{parts[0]} ({', '.join(parts[1:])})"


@dataclass(frozen=True, slots=True)
class WifiDetails:
    interface: str
    connected: bool
    ssid: str | None = None
    bssid: str | None = None
    ip: str | None = None
    hostname: str | None = None
    subnet_mask: str | None = None
    router: str | None = None
    phy_mode: str | None = None
    channel: str | None = None
    security: str | None = None
    signal_noise: str | None = None
    tx_rate: str | None = None
    mcs_index: str | None = None
    country_code: str | None = None
    adapter_mac: str | None = None


class WifiProvider:
    def __init__(self, *, interface: str = "en0") -> None:
        self.interface = interface

    def details(self) -> WifiDetails:
        from Foundation import NSHost  # type: ignore[import-not-found]

        hostname = None
        try:
            hostname = str(NSHost.currentHost().localizedName() or "").strip() or None
        except Exception:
            hostname = None

        ip, mask, router = _ipv4_details(self.interface)

        iface = _wifi_interface(self.interface)
        ssid: str | None = None
        bssid: str | None = None
        phy_mode: str | None = None
        channel: str | None = None
        security: str | None = None
        signal_noise: str | None = None
        tx_rate: str | None = None
        mcs_index: str | None = None
        country_code: str | None = None
        adapter_mac: str | None = None

        if iface is not None:
            try:
                ssid = iface.ssid()
            except Exception:
                ssid = None
            try:
                bssid = iface.bssid()
            except Exception:
                bssid = None
            try:
                adapter_mac = iface.hardwareAddress()
            except Exception:
                adapter_mac = None

            try:
                phy_mode = _phy_mode_name(int(iface.activePHYMode()))
            except Exception:
                phy_mode = None

            try:
                channel = _format_channel(iface.wlanChannel())
            except Exception:
                channel = None

            try:
                security = _security_name(int(iface.security()))
            except Exception:
                security = None

            rssi: int | None = None
            noise: int | None = None
            try:
                rssi = int(iface.rssiValue())
            except Exception:
                rssi = None
            try:
                noise = int(iface.noiseMeasurement())
            except Exception:
                noise = None
            if rssi is not None and noise is not None:
                signal_noise = f"{rssi} dBm / {noise} dBm"
            elif rssi is not None:
                signal_noise = f"{rssi} dBm"

            try:
                rate = float(iface.transmitRate())
            except Exception:
                rate = 0.0
            if rate > 0:
                tx_rate = f"{rate:g} Mbps"

            try:
                country_code = iface.countryCode()
            except Exception:
                country_code = None

        connected = bool(ssid) or bool(ip) or _ipv6_connected(self.interface)
        return WifiDetails(
            interface=self.interface,
            connected=connected,
            ssid=ssid,
            bssid=bssid,
            ip=ip,
            hostname=hostname,
            subnet_mask=mask,
            router=router,
            phy_mode=phy_mode,
            channel=channel,
            security=security,
            signal_noise=signal_noise,
            tx_rate=tx_rate,
            mcs_index=mcs_index,
            country_code=country_code,
            adapter_mac=adapter_mac,
        )


__all__ = [
    "WifiDetails",
    "WifiProvider",
]
