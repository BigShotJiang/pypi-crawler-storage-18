from __future__ import annotations

import json
import os
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

from .keychain import get_generic_password


def _safe_str(value: object) -> str:
    try:
        s = str(value or "")
    except Exception:
        return ""
    return s.replace("\n", " ").replace("\r", " ").strip()


def _utc_iso(ts: int) -> str:
    return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_utc_iso(value: object) -> int | None:
    s = _safe_str(value)
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def _parse_http_date(value: object) -> int | None:
    s = _safe_str(value)
    if not s:
        return None
    try:
        dt = parsedate_to_datetime(s)
    except Exception:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def _parse_repo(repo: str) -> str | None:
    repo = _safe_str(repo)
    if not repo or "/" not in repo:
        return None
    owner, name = repo.split("/", 1)
    owner = _safe_str(owner)
    name = _safe_str(name)
    if not owner or not name or " " in owner or " " in name:
        return None
    return f"{owner}/{name}"


@dataclass(frozen=True, slots=True)
class GitHubSearchResult:
    total_count: int
    incomplete_results: bool
    newest_created_at: int | None
    server_now: int | None


def _atomic_write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(path)


class GitHubProvider:
    def __init__(
        self,
        *,
        token: str | None = None,
        base_url: str = "https://api.github.com",
        api_version: str = "2022-11-28",
        timeout_seconds: float = 3.0,
        state_path: Path | None = None,
    ) -> None:
        import threading

        self._token = token
        self.base_url = _safe_str(base_url).rstrip("/") or "https://api.github.com"
        self.api_version = _safe_str(api_version) or "2022-11-28"
        self.timeout_seconds = float(timeout_seconds)
        self.state_path = state_path
        self._lock = threading.Lock()
        self._state: dict[str, Any] = {"version": 1, "repos": {}}
        self._load_state()

    def token(self) -> str | None:
        if self._token:
            return self._token
        env = (_safe_str(os.environ.get("GITHUB_TOKEN")) or "").strip()
        if env:
            return env
        return get_generic_password(service="GITHUB_TOKEN")

    def _headers(self) -> dict[str, str]:
        headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "sbar-python",
            "X-GitHub-Api-Version": self.api_version,
        }
        token = (self.token() or "").strip()
        if token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    def _url(self, path: str, *, query: dict[str, str] | None = None) -> str:
        path = "/" + path.lstrip("/")
        url = f"{self.base_url}{path}"
        if not query:
            return url
        return f"{url}?{urllib.parse.urlencode(query)}"

    def _request_json(self, path: str, *, query: dict[str, str] | None = None) -> tuple[dict[str, Any], int | None] | None:
        url = self._url(path, query=query)
        req = urllib.request.Request(url, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
                date_header = resp.headers.get("Date")
                server_now = _parse_http_date(date_header)
                raw = json.loads(resp.read().decode("utf-8", errors="ignore"))
        except Exception:
            return None

        if not isinstance(raw, dict):
            return None
        return raw, server_now

    def _load_state(self) -> None:
        if self.state_path is None:
            return
        with self._lock:
            try:
                raw = self.state_path.read_text(encoding="utf-8")
            except FileNotFoundError:
                return
            except Exception:
                return
            if not raw.strip():
                return
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError:
                return
            if not isinstance(parsed, dict):
                return
            repos = parsed.get("repos")
            if isinstance(repos, dict):
                self._state = {"version": 1, "repos": dict(repos)}

    def _save_state(self) -> None:
        if self.state_path is None:
            return
        with self._lock:
            try:
                _atomic_write_text(self.state_path, json.dumps(self._state, ensure_ascii=False))
            except Exception:
                return

    def _repo_state(self, repo: str) -> dict[str, Any]:
        repos = self._state.setdefault("repos", {})
        if not isinstance(repos, dict):
            repos = {}
            self._state["repos"] = repos
        entry = repos.get(repo)
        if not isinstance(entry, dict):
            entry = {}
            repos[repo] = entry
        return entry

    def _get_last_seen(self, repo: str, *, key: str) -> int | None:
        with self._lock:
            entry = self._repo_state(repo)
            value = entry.get(key)
            try:
                return int(value)
            except Exception:
                return None

    def _set_last_seen(self, repo: str, *, key: str, ts: int) -> None:
        with self._lock:
            entry = self._repo_state(repo)
            entry[key] = int(ts)
        self._save_state()

    def repo_new_issues_count_since_last_seen_async(
        self,
        repo: str,
        callback: Any,
        *,
        bootstrap_seconds: int = 0,
        state_key: str = "issues_last_seen",
    ) -> None:
        """
        Runs `repo_new_issues_count_since_last_seen` in a background thread.

        callback: `(count: int | None) -> None`
        """
        import threading

        def run() -> None:
            count = self.repo_new_issues_count_since_last_seen(
                repo,
                bootstrap_seconds=bootstrap_seconds,
                state_key=state_key,
            )
            try:
                callback(count)
            except Exception:
                return

        threading.Thread(target=run, daemon=True).start()

    def search_issues(self, query: str, *, per_page: int = 1, sort: str | None = None, order: str | None = None) -> GitHubSearchResult | None:
        query = _safe_str(query)
        if not query:
            return None

        q: dict[str, str] = {"q": query, "per_page": str(int(per_page))}
        if sort:
            q["sort"] = _safe_str(sort)
        if order:
            q["order"] = _safe_str(order)

        resp = self._request_json("/search/issues", query=q)
        if resp is None:
            return None
        raw, server_now = resp

        total = raw.get("total_count")
        incomplete = raw.get("incomplete_results")
        items = raw.get("items")

        try:
            total_count = int(total)
        except Exception:
            return None

        newest_created_at: int | None = None
        if isinstance(items, list) and items and isinstance(items[0], dict):
            newest_created_at = _parse_utc_iso(items[0].get("created_at"))

        return GitHubSearchResult(
            total_count=total_count,
            incomplete_results=bool(incomplete),
            newest_created_at=newest_created_at,
            server_now=server_now,
        )

    def repo_open_issues_count(self, repo: str) -> int | None:
        repo = _parse_repo(repo) or ""
        if not repo:
            return None
        r = self.search_issues(f"repo:{repo} is:issue is:open", per_page=1)
        return None if r is None else int(r.total_count)

    def repo_open_prs_count(self, repo: str) -> int | None:
        repo = _parse_repo(repo) or ""
        if not repo:
            return None
        r = self.search_issues(f"repo:{repo} is:pr is:open", per_page=1)
        return None if r is None else int(r.total_count)

    def repo_new_issues_count_since_last_seen(
        self,
        repo: str,
        *,
        bootstrap_seconds: int = 0,
        state_key: str = "issues_last_seen",
    ) -> int | None:
        repo = _parse_repo(repo) or ""
        if not repo:
            return None

        now = int(time.time())
        last_seen = self._get_last_seen(repo, key=state_key)
        if last_seen is None:
            if int(bootstrap_seconds) <= 0:
                self._set_last_seen(repo, key=state_key, ts=now)
                return 0
            last_seen = now - int(bootstrap_seconds)

        since = _utc_iso(last_seen)
        query = f"repo:{repo} is:issue created:>{since}"
        r = self.search_issues(query, per_page=1, sort="created", order="desc")
        if r is None:
            return None

        new_last_seen = r.newest_created_at or r.server_now or now
        self._set_last_seen(repo, key=state_key, ts=max(int(last_seen), int(new_last_seen)))
        return int(r.total_count)

    def repo_new_prs_count_since_last_seen(
        self,
        repo: str,
        *,
        bootstrap_seconds: int = 0,
        state_key: str = "prs_last_seen",
    ) -> int | None:
        repo = _parse_repo(repo) or ""
        if not repo:
            return None

        now = int(time.time())
        last_seen = self._get_last_seen(repo, key=state_key)
        if last_seen is None:
            if int(bootstrap_seconds) <= 0:
                self._set_last_seen(repo, key=state_key, ts=now)
                return 0
            last_seen = now - int(bootstrap_seconds)

        since = _utc_iso(last_seen)
        query = f"repo:{repo} is:pr created:>{since}"
        r = self.search_issues(query, per_page=1, sort="created", order="desc")
        if r is None:
            return None

        new_last_seen = r.newest_created_at or r.server_now or now
        self._set_last_seen(repo, key=state_key, ts=max(int(last_seen), int(new_last_seen)))
        return int(r.total_count)


__all__ = [
    "GitHubProvider",
    "GitHubSearchResult",
]
