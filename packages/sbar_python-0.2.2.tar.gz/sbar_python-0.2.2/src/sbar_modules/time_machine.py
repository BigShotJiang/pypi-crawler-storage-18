from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Literal


TimeMachinePhase = Literal["idle", "running", "unknown"]


@dataclass(frozen=True, slots=True)
class TimeMachineDestination:
    network_url: str = ""
    volume_name: str = ""
    bytes_used: int | None = None
    bytes_available: int | None = None


@dataclass(frozen=True, slots=True)
class TimeMachineStatus:
    phase: TimeMachinePhase
    auto_backup: bool | None
    last_backup: datetime | None
    last_backup_activity: str = ""
    destinations: tuple[TimeMachineDestination, ...] = ()

_DOMAIN = "com.apple.TimeMachine"


def _to_int(value: object) -> int | None:
    try:
        return int(value)  # type: ignore[arg-type]
    except Exception:
        return None


def _to_str(value: object) -> str:
    try:
        return str(value or "")
    except Exception:
        return ""


def _to_datetime(value: object) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        from Foundation import NSDate  # type: ignore[import-not-found]
    except Exception:
        NSDate = None  # type: ignore[assignment]

    if NSDate is not None and isinstance(value, NSDate):  # type: ignore[arg-type]
        try:
            return datetime.fromtimestamp(float(value.timeIntervalSince1970()), tz=timezone.utc)
        except Exception:
            return None
    try:
        return datetime.fromtimestamp(float(value), tz=timezone.utc)
    except Exception:
        return None


def _parse_last_backup_activity(s: str) -> datetime | None:
    s2 = s.strip()
    if not s2:
        return None
    try:
        dt = datetime.strptime(s2, "%Y-%m-%d-%H%M%S")
        return dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _read_preferences() -> dict[str, Any] | None:
    try:
        import CoreFoundation as CF  # type: ignore[import-not-found]
    except Exception:
        return None

    combos = [
        (CF.kCFPreferencesAnyUser, CF.kCFPreferencesCurrentHost),
        (CF.kCFPreferencesAnyUser, CF.kCFPreferencesAnyHost),
        (CF.kCFPreferencesCurrentUser, CF.kCFPreferencesCurrentHost),
    ]
    for user, host in combos:
        try:
            d = CF.CFPreferencesCopyMultiple(None, _DOMAIN, user, host)
        except Exception:
            continue
        if d:
            try:
                return dict(d)
            except Exception:
                continue
    return None


def status() -> TimeMachineStatus | None:
    """
    获取 Time Machine 状态（best-effort，不调用 tmutil）。

    数据源：`com.apple.TimeMachine` 的系统级偏好（通过 CoreFoundation CFPreferences 读取）。
    """
    obj = _read_preferences()
    if not isinstance(obj, dict):
        return None

    auto_backup = obj.get("AutoBackup")
    auto_backup_bool: bool | None
    if auto_backup is None:
        auto_backup_bool = None
    else:
        auto_backup_bool = bool(_to_int(auto_backup) or 0)

    last_activity = _to_str(obj.get("LastBackupActivity"))
    last_backup = _parse_last_backup_activity(last_activity)

    destinations: list[TimeMachineDestination] = []
    raw_dests = obj.get("Destinations")
    if isinstance(raw_dests, (list, tuple)):
        for d in raw_dests:
            if not isinstance(d, dict):
                continue
            destinations.append(
                TimeMachineDestination(
                    network_url=_to_str(d.get("NetworkURL")),
                    volume_name=_to_str(d.get("LastKnownVolumeName")),
                    bytes_used=_to_int(d.get("BytesUsed")),
                    bytes_available=_to_int(d.get("BytesAvailable")),
                )
            )

            snaps = d.get("SnapshotDates")
            if last_backup is None and isinstance(snaps, (list, tuple)) and snaps:
                last_backup = _to_datetime(snaps[-1])

    # Without private APIs we cannot reliably detect the active backup phase,
    # but the plist sometimes includes transient keys while running.
    phase: TimeMachinePhase = "idle"
    if any(k in obj for k in ("BackupPhase", "BackupProgress", "Running")):
        phase = "unknown"

    return TimeMachineStatus(
        phase=phase,
        auto_backup=auto_backup_bool,
        last_backup=last_backup,
        last_backup_activity=last_activity,
        destinations=tuple(destinations),
    )


__all__ = [
    "TimeMachineDestination",
    "TimeMachinePhase",
    "TimeMachineStatus",
    "get_time_machine_status",
]


def get_time_machine_status() -> TimeMachineStatus | None:
    return status()
