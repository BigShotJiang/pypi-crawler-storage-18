from __future__ import annotations

import ctypes
import time
from dataclasses import dataclass
from typing import Final


def format_bps(bytes_per_second: float) -> str:
    if bytes_per_second < 0:
        bytes_per_second = 0.0

    if bytes_per_second < 1_000:
        return f"{int(bytes_per_second):03d} Bps"
    if bytes_per_second < 1_000_000:
        return f"{int(bytes_per_second / 1_000):03d}KBps"
    return f"{int(bytes_per_second / 1_000_000):03d}MBps"


_CTL_NET: Final[int] = 4
_PF_LINK: Final[int] = 18
_NETLINK_GENERIC: Final[int] = 0

_IFMIB_SYSTEM: Final[int] = 1
_IFMIB_IFCOUNT: Final[int] = 1
_IFMIB_IFDATA: Final[int] = 2
_IFDATA_GENERAL: Final[int] = 1

_IFNAMSIZ: Final[int] = 16


class _Timeval32(ctypes.Structure):
    _fields_ = [
        ("tv_sec", ctypes.c_int32),
        ("tv_usec", ctypes.c_int32),
    ]


class _IfData64(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ("ifi_type", ctypes.c_ubyte),
        ("ifi_typelen", ctypes.c_ubyte),
        ("ifi_physical", ctypes.c_ubyte),
        ("ifi_addrlen", ctypes.c_ubyte),
        ("ifi_hdrlen", ctypes.c_ubyte),
        ("ifi_recvquota", ctypes.c_ubyte),
        ("ifi_xmitquota", ctypes.c_ubyte),
        ("ifi_unused1", ctypes.c_ubyte),
        ("ifi_mtu", ctypes.c_uint32),
        ("ifi_metric", ctypes.c_uint32),
        ("ifi_baudrate", ctypes.c_uint64),
        ("ifi_ipackets", ctypes.c_uint64),
        ("ifi_ierrors", ctypes.c_uint64),
        ("ifi_opackets", ctypes.c_uint64),
        ("ifi_oerrors", ctypes.c_uint64),
        ("ifi_collisions", ctypes.c_uint64),
        ("ifi_ibytes", ctypes.c_uint64),
        ("ifi_obytes", ctypes.c_uint64),
        ("ifi_imcasts", ctypes.c_uint64),
        ("ifi_omcasts", ctypes.c_uint64),
        ("ifi_iqdrops", ctypes.c_uint64),
        ("ifi_noproto", ctypes.c_uint64),
        ("ifi_recvtiming", ctypes.c_uint32),
        ("ifi_xmittiming", ctypes.c_uint32),
        ("ifi_lastchange", _Timeval32),
    ]


class _Ifmibdata(ctypes.Structure):
    _fields_ = [
        ("ifmd_name", ctypes.c_char * _IFNAMSIZ),
        ("ifmd_pcount", ctypes.c_uint),
        ("ifmd_flags", ctypes.c_uint),
        ("ifmd_snd_len", ctypes.c_uint),
        ("ifmd_snd_maxlen", ctypes.c_uint),
        ("ifmd_snd_drops", ctypes.c_uint),
        ("ifmd_filler", ctypes.c_uint * 4),
        ("ifmd_data", _IfData64),
    ]


_libc = ctypes.CDLL("/usr/lib/libc.dylib")
_sysctl = _libc.sysctl
_sysctl.argtypes = [
    ctypes.POINTER(ctypes.c_int),
    ctypes.c_uint,
    ctypes.c_void_p,
    ctypes.POINTER(ctypes.c_size_t),
    ctypes.c_void_p,
    ctypes.c_size_t,
]
_sysctl.restype = ctypes.c_int


def _sysctl_read(mib: list[int], out: object) -> bool:
    name = (ctypes.c_int * len(mib))(*mib)
    size = ctypes.c_size_t(ctypes.sizeof(out))
    rc = _sysctl(name, ctypes.c_uint(len(mib)), ctypes.byref(out), ctypes.byref(size), None, 0)
    return rc == 0


def _interface_row(ifname: str) -> int | None:
    count = ctypes.c_uint32()
    if not _sysctl_read(
        [_CTL_NET, _PF_LINK, _NETLINK_GENERIC, _IFMIB_SYSTEM, _IFMIB_IFCOUNT],
        count,
    ):
        return None

    interface_count = int(count.value)
    if interface_count <= 0:
        return None

    data = _Ifmibdata()
    for row in range(interface_count):
        mib = [_CTL_NET, _PF_LINK, _NETLINK_GENERIC, _IFMIB_IFDATA, int(row), _IFDATA_GENERAL]
        if not _sysctl_read(mib, data):
            continue
        name = bytes(data.ifmd_name).split(b"\0", 1)[0].decode("utf-8", errors="ignore")
        if name == ifname:
            return row
    return None


@dataclass(frozen=True, slots=True)
class NetworkInterfaceBytes:
    interface: str
    ibytes: int
    obytes: int
    timestamp: float


@dataclass(frozen=True, slots=True)
class NetworkThroughput:
    interface: str
    upload_bps: float
    download_bps: float
    upload: str
    download: str


class NetworkThroughputMonitor:
    def __init__(self, interface: str = "en0") -> None:
        self.interface = interface
        self._row: int | None = None
        self._last: NetworkInterfaceBytes | None = None

    def snapshot(self) -> NetworkInterfaceBytes | None:
        if self._row is None:
            self._row = _interface_row(self.interface)
            if self._row is None:
                return None

        data = _Ifmibdata()
        mib = [_CTL_NET, _PF_LINK, _NETLINK_GENERIC, _IFMIB_IFDATA, int(self._row), _IFDATA_GENERAL]
        if not _sysctl_read(mib, data):
            self._row = None
            return None

        now = time.monotonic()
        return NetworkInterfaceBytes(
            interface=self.interface,
            ibytes=int(data.ifmd_data.ifi_ibytes),
            obytes=int(data.ifmd_data.ifi_obytes),
            timestamp=now,
        )

    def sample(self) -> NetworkThroughput | None:
        cur = self.snapshot()
        if cur is None:
            return None
        prev = self._last
        self._last = cur
        if prev is None:
            return None

        dt = cur.timestamp - prev.timestamp
        if dt <= 1e-6 or dt > 120.0:
            return None

        down = (cur.ibytes - prev.ibytes) / dt
        up = (cur.obytes - prev.obytes) / dt
        if down < 0:
            down = 0.0
        if up < 0:
            up = 0.0

        return NetworkThroughput(
            interface=self.interface,
            upload_bps=up,
            download_bps=down,
            upload=format_bps(up),
            download=format_bps(down),
        )


__all__ = [
    "NetworkInterfaceBytes",
    "NetworkThroughput",
    "NetworkThroughputMonitor",
    "format_bps",
]
