#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include <CoreFoundation/CoreFoundation.h>
#include <bootstrap.h>
#include <errno.h>
#include <mach/mach.h>
#include <mach/message.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#define BAR "--bar"
#define SET "--set"
#define ADD "--add"
#define ANIMATE "--animate"
#define DEFAULT "--default"
#define SUBSCRIBE "--subscribe"
#define UPDATE "--update"
#define QUERY "--query"
#define HOTLOAD "--hotload"
#define TRIGGER "--trigger"
#define PUSH "--push"
#define REMOVE "--remove"

typedef void (*mach_handler)(char *message, size_t size);

struct mach_message {
  mach_msg_header_t header;
  mach_msg_size_t msgh_descriptor_count;
  mach_msg_ool_descriptor_t descriptor;
};

struct mach_buffer {
  struct mach_message message;
  mach_msg_trailer_t trailer;
};

struct mach_server {
  mach_port_name_t task;
  mach_port_t port;
  mach_port_t bs_port;
  mach_handler handler;
};

struct stack {
  char **value;
  uint32_t num_values;
};

struct callback_entry {
  char *name;
  char *event;
  PyObject *callable; // Strong ref.
};

struct callbacks {
  struct callback_entry *entries;
  uint32_t count;
};

enum async_kind {
  ASYNC_EXEC = 1,
  ASYNC_DELAY = 2,
};

struct async_entry {
  int id;
  enum async_kind kind;
  PyObject *callable; // Strong ref.
};

struct async_callbacks {
  struct async_entry *entries;
  uint32_t count;
  int next_id;
};

static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

static struct mach_server g_mach_server = {0};
static char g_bootstrap_name[64] = {0};

static mach_port_t g_port = 0;
static char g_bs_lookup[256] = "git.felix.sketchybar";

static char *g_cmd = NULL;
static uint32_t g_cmd_len = 0;

static struct callbacks g_callbacks = {0};
static struct async_callbacks g_async = {.entries = NULL, .count = 0, .next_id = 1};

static void stack_init(struct stack *stack) {
  memset(stack, 0, sizeof(*stack));
}

static void stack_push_owned(struct stack *stack, char *value) {
  stack->value = realloc(stack->value, sizeof(char *) * (stack->num_values + 1));
  stack->value[stack->num_values] = value;
  stack->num_values += 1;
}

static void stack_push_clone(struct stack *stack, const char *value) {
  size_t len = strlen(value) + 1;
  char *copy = malloc(len);
  memcpy(copy, value, len);
  stack_push_owned(stack, copy);
}

static void stack_destroy(struct stack *stack) {
  if (!stack) {
    return;
  }
  for (uint32_t i = 0; i < stack->num_values; i++) {
    free(stack->value[i]);
  }
  free(stack->value);
  stack_init(stack);
}

static char *stack_flatten_ttb(struct stack *stack, uint32_t *length) {
  if (!stack || stack->num_values == 0) {
    return NULL;
  }
  uint32_t total = 0;
  for (int i = (int)stack->num_values - 1; i >= 0; i--) {
    total += (uint32_t)strlen(stack->value[i]) + 1;
  }

  char *out = malloc(total);
  uint32_t caret = 0;
  for (int i = (int)stack->num_values - 1; i >= 0; i--) {
    uint32_t entry_size = (uint32_t)strlen(stack->value[i]) + 1;
    memcpy(out + caret, stack->value[i], entry_size);
    caret += entry_size;
  }

  *length = total;
  return out;
}

static mach_port_t mach_get_bs_port(const char *name) {
  mach_port_name_t task = mach_task_self();

  mach_port_t bs_port = 0;
  if (task_get_special_port(task, TASK_BOOTSTRAP_PORT, &bs_port) != KERN_SUCCESS) {
    return 0;
  }

  mach_port_t port = 0;
  if (bootstrap_look_up(bs_port, (char *)name, &port) != KERN_SUCCESS) {
    return 0;
  }

  return port;
}

static void mach_receive_message(mach_port_t port, struct mach_buffer *buffer, bool timeout) {
  *buffer = (struct mach_buffer){0};
  mach_msg_return_t msg_return = MACH_MSG_SUCCESS;
  if (timeout) {
    msg_return =
        mach_msg(&buffer->message.header, MACH_RCV_MSG | MACH_RCV_TIMEOUT, 0, sizeof(*buffer), port, 1000, MACH_PORT_NULL);
  } else {
    msg_return = mach_msg(&buffer->message.header, MACH_RCV_MSG, 0, sizeof(*buffer), port, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
  }

  if (msg_return != MACH_MSG_SUCCESS) {
    buffer->message.descriptor.address = NULL;
  }
}

static char *mach_send_message(mach_port_t port, char *message, uint32_t len, bool response) {
  if (!message || !port) {
    return NULL;
  }

  mach_port_t response_port = 0;
  mach_port_name_t task = 0;
  if (response) {
    task = mach_task_self();
    if (mach_port_allocate(task, MACH_PORT_RIGHT_RECEIVE, &response_port) != KERN_SUCCESS) {
      return NULL;
    }
    if (mach_port_insert_right(task, response_port, response_port, MACH_MSG_TYPE_MAKE_SEND) != KERN_SUCCESS) {
      return NULL;
    }
  }

  struct mach_message msg = {0};
  msg.header.msgh_remote_port = port;
  if (response) {
    msg.header.msgh_local_port = response_port;
    msg.header.msgh_id = response_port;
  }
  msg.header.msgh_bits =
      MACH_MSGH_BITS_SET(MACH_MSG_TYPE_COPY_SEND, MACH_MSG_TYPE_MAKE_SEND, 0, MACH_MSGH_BITS_COMPLEX);

  msg.header.msgh_size = sizeof(struct mach_message);
  msg.msgh_descriptor_count = 1;
  msg.descriptor.address = message;
  msg.descriptor.size = len * sizeof(char);
  msg.descriptor.copy = MACH_MSG_VIRTUAL_COPY;
  msg.descriptor.deallocate = false;
  msg.descriptor.type = MACH_MSG_OOL_DESCRIPTOR;

  mach_msg_return_t ret =
      mach_msg(&msg.header, MACH_SEND_MSG, sizeof(struct mach_message), 0, MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);

  if (ret != KERN_SUCCESS) {
    return NULL;
  }

  char *rsp = NULL;
  if (response) {
    struct mach_buffer buffer = {0};
    mach_receive_message(response_port, &buffer, true);

    if (buffer.message.descriptor.address) {
      const char *addr = buffer.message.descriptor.address;
      rsp = malloc(strlen(addr) + 1);
      memcpy(rsp, addr, strlen(addr) + 1);
    } else {
      rsp = malloc(1);
      *rsp = '\0';
    }

    mach_msg_destroy(&buffer.message.header);
    mach_port_mod_refs(task, response_port, MACH_PORT_RIGHT_RECEIVE, -1);
    mach_port_deallocate(task, response_port);
  }

  return rsp;
}

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"

static bool mach_server_register(struct mach_server *mach_server, const char *bootstrap_name) {
  mach_server->task = mach_task_self();

  if (mach_port_allocate(mach_server->task, MACH_PORT_RIGHT_RECEIVE, &mach_server->port) != KERN_SUCCESS) {
    return false;
  }

  struct mach_port_limits limits = {0};
  limits.mpl_qlimit = MACH_PORT_QLIMIT_LARGE;

  if (mach_port_set_attributes(mach_server->task,
                               mach_server->port,
                               MACH_PORT_LIMITS_INFO,
                               (mach_port_info_t)&limits,
                               MACH_PORT_LIMITS_INFO_COUNT) != KERN_SUCCESS) {
    return false;
  }

  if (mach_port_insert_right(mach_server->task, mach_server->port, mach_server->port, MACH_MSG_TYPE_MAKE_SEND) != KERN_SUCCESS) {
    return false;
  }

  if (task_get_special_port(mach_server->task, TASK_BOOTSTRAP_PORT, &mach_server->bs_port) != KERN_SUCCESS) {
    return false;
  }

  if (bootstrap_register(mach_server->bs_port, (char *)bootstrap_name, mach_server->port) != KERN_SUCCESS) {
    return false;
  }

  return true;
}

static void mach_message_callback(CFMachPortRef port, void *message, CFIndex size, void *context) {
  (void)port;
  (void)size;

  struct mach_server *mach_server = context;
  struct mach_buffer buffer = {0};
  buffer.message = *(struct mach_message *)message;

  if (!buffer.message.descriptor.address) {
    return;
  }

  mach_server->handler(buffer.message.descriptor.address, buffer.message.descriptor.size);

  mach_msg_destroy(&buffer.message.header);
}

static bool mach_server_begin(struct mach_server *mach_server, mach_handler handler) {
  mach_server->handler = handler;

  CFMachPortContext context = {0, (void *)mach_server};
  CFMachPortRef cf_mach_port = CFMachPortCreateWithPort(NULL, mach_server->port, mach_message_callback, &context, false);

  CFRunLoopSourceRef source = CFMachPortCreateRunLoopSource(NULL, cf_mach_port, 0);
  CFRunLoopAddSource(CFRunLoopGetMain(), source, kCFRunLoopDefaultMode);

  CFRelease(source);
  CFRelease(cf_mach_port);
  return true;
}

#pragma clang diagnostic pop

static void transaction_begin(void) {
  pthread_mutex_lock(&g_lock);
  if (!g_cmd) {
    g_cmd = malloc(1);
    g_cmd_len = 0;
    *g_cmd = '\0';
  }
  pthread_mutex_unlock(&g_lock);
}

static void log_sketchybar_response_and_free(char *response) {
  if (!response) {
    return;
  }
  if (strlen(response) > 0) {
    printf("[i] sketchybar: %s\n", response);
  }
  free(response);
}

static char *sketchybar_send_bytes(const char *message, uint32_t length, bool response) {
  if (!message || length == 0) {
    return NULL;
  }

  pthread_mutex_lock(&g_lock);
  mach_port_t port = g_port;
  if (!port) {
    port = mach_get_bs_port(g_bs_lookup);
    g_port = port;
  }
  pthread_mutex_unlock(&g_lock);

  if (!port) {
    return NULL;
  }

  // SketchyBar expects a NUL-terminated buffer; sending an additional NUL keeps parity with SbarLua.
  char *msg = malloc((size_t)length + 1);
  memcpy(msg, message, length);
  msg[length] = '\0';
  uint32_t send_len = length + 1;

  char *rsp = mach_send_message(port, msg, send_len, response);
  if (!rsp) {
    pthread_mutex_lock(&g_lock);
    g_port = 0;
    port = mach_get_bs_port(g_bs_lookup);
    g_port = port;
    pthread_mutex_unlock(&g_lock);
    rsp = mach_send_message(port, msg, send_len, response);
  }

  free(msg);
  return rsp;
}

static char *sketchybar_send_stack(struct stack *stack, bool response) {
  uint32_t length = 0;
  char *message = stack_flatten_ttb(stack, &length);
  if (!message) {
    return NULL;
  }

  pthread_mutex_lock(&g_lock);
  if (g_cmd) {
    g_cmd = realloc(g_cmd, (size_t)g_cmd_len + length);
    memcpy(g_cmd + g_cmd_len, message, length);
    g_cmd_len += length;
    pthread_mutex_unlock(&g_lock);
    free(message);
    return NULL;
  }
  pthread_mutex_unlock(&g_lock);

  char *rsp = sketchybar_send_bytes(message, length, response);
  free(message);
  return rsp;
}

static void transaction_commit(void) {
  pthread_mutex_lock(&g_lock);
  char *buffer = g_cmd;
  uint32_t length = g_cmd_len;
  g_cmd = NULL;
  g_cmd_len = 0;
  pthread_mutex_unlock(&g_lock);

  if (!buffer) {
    return;
  }

  char *rsp = sketchybar_send_bytes(buffer, length, true);
  free(buffer);
  log_sketchybar_response_and_free(rsp);
}

static int async_register(enum async_kind kind, PyObject *callable) {
  pthread_mutex_lock(&g_lock);
  int id = g_async.next_id++;
  g_async.entries = realloc(g_async.entries, sizeof(struct async_entry) * (g_async.count + 1));
  g_async.entries[g_async.count] = (struct async_entry){
      .id = id,
      .kind = kind,
      .callable = callable,
  };
  Py_INCREF(callable);
  g_async.count += 1;
  pthread_mutex_unlock(&g_lock);
  return id;
}

static PyObject *async_pop(int id, enum async_kind kind) {
  PyObject *callable = NULL;
  pthread_mutex_lock(&g_lock);
  for (uint32_t i = 0; i < g_async.count; i++) {
    if (g_async.entries[i].id == id && g_async.entries[i].kind == kind) {
      callable = g_async.entries[i].callable;
      // Remove by swap-with-last.
      g_async.entries[i] = g_async.entries[g_async.count - 1];
      g_async.count -= 1;
      if (g_async.count == 0) {
        free(g_async.entries);
        g_async.entries = NULL;
      } else {
        g_async.entries = realloc(g_async.entries, sizeof(struct async_entry) * g_async.count);
      }
      break;
    }
  }
  pthread_mutex_unlock(&g_lock);
  return callable;
}

static int parse_kv_table(PyObject *mapping, const char *prefix, struct stack *stack) {
  PyObject *items = PyMapping_Items(mapping);
  if (!items) {
    return -1;
  }

  Py_ssize_t n = PyList_Size(items);
  for (Py_ssize_t i = 0; i < n; i++) {
    PyObject *pair = PyList_GetItem(items, i); // Borrowed.
    if (!pair || !PyTuple_Check(pair) || PyTuple_Size(pair) != 2) {
      continue;
    }

    PyObject *key_obj = PyTuple_GetItem(pair, 0);   // Borrowed.
    PyObject *value_obj = PyTuple_GetItem(pair, 1); // Borrowed.

    if (!PyUnicode_Check(key_obj)) {
      PyErr_SetString(PyExc_TypeError, "Sbar properties require string keys");
      Py_DECREF(items);
      return -1;
    }

    const char *key = PyUnicode_AsUTF8(key_obj);
    if (!key) {
      Py_DECREF(items);
      return -1;
    }

    if (value_obj && PyMapping_Check(value_obj) && !PyUnicode_Check(value_obj) && !PyBytes_Check(value_obj)) {
      size_t new_prefix_len = (prefix ? strlen(prefix) + 1 : 0) + strlen(key) + 1;
      char *new_prefix = malloc(new_prefix_len);
      if (prefix) {
        snprintf(new_prefix, new_prefix_len, "%s.%s", prefix, key);
      } else {
        snprintf(new_prefix, new_prefix_len, "%s", key);
      }

      int rc = parse_kv_table(value_obj, new_prefix, stack);
      free(new_prefix);
      if (rc != 0) {
        Py_DECREF(items);
        return -1;
      }
      continue;
    }

    const char *value_cstr = NULL;
    char value_buf[64] = {0};
    PyObject *value_str_obj = NULL;

    if (value_obj == Py_True || value_obj == Py_False) {
      value_cstr = (value_obj == Py_True) ? "on" : "off";
    } else if ((strcmp(key, "color") == 0 || strcmp(key, "border_color") == 0) && PyLong_Check(value_obj)) {
      unsigned long long number = PyLong_AsUnsignedLongLong(value_obj);
      if (PyErr_Occurred()) {
        PyErr_Clear();
        value_str_obj = PyObject_Str(value_obj);
        if (!value_str_obj) {
          Py_DECREF(items);
          return -1;
        }
        value_cstr = PyUnicode_AsUTF8(value_str_obj);
      } else {
        snprintf(value_buf, sizeof(value_buf), "0x%llx", number);
        value_cstr = value_buf;
      }
    } else {
      value_str_obj = PyObject_Str(value_obj);
      if (!value_str_obj) {
        Py_DECREF(items);
        return -1;
      }
      value_cstr = PyUnicode_AsUTF8(value_str_obj);
    }

    if (!value_cstr) {
      Py_XDECREF(value_str_obj);
      Py_DECREF(items);
      return -1;
    }

    size_t kv_len = (prefix ? strlen(prefix) + 1 : 0) + strlen(key) + 1 + strlen(value_cstr) + 1;
    char *kv = malloc(kv_len);
    if (prefix) {
      snprintf(kv, kv_len, "%s.%s=%s", prefix, key, value_cstr);
    } else {
      snprintf(kv, kv_len, "%s=%s", key, value_cstr);
    }
    stack_push_owned(stack, kv);

    Py_XDECREF(value_str_obj);
  }

  Py_DECREF(items);
  return 0;
}

static int parse_sequence_values(PyObject *seq_obj, struct stack *stack) {
  PyObject *seq = PySequence_Fast(seq_obj, "expected a sequence");
  if (!seq) {
    return -1;
  }

  Py_ssize_t n = PySequence_Fast_GET_SIZE(seq);
  PyObject **items = PySequence_Fast_ITEMS(seq);
  for (Py_ssize_t i = 0; i < n; i++) {
    PyObject *obj = items[i];
    PyObject *s = PyObject_Str(obj);
    if (!s) {
      Py_DECREF(seq);
      return -1;
    }
    const char *c = PyUnicode_AsUTF8(s);
    if (!c) {
      Py_DECREF(s);
      Py_DECREF(seq);
      return -1;
    }
    stack_push_clone(stack, c);
    Py_DECREF(s);
  }

  Py_DECREF(seq);
  return 0;
}

static PyObject *py_begin_config(PyObject *self, PyObject *args) {
  (void)self;
  (void)args;
  transaction_begin();
  Py_RETURN_NONE;
}

static PyObject *py_end_config(PyObject *self, PyObject *args) {
  (void)self;
  (void)args;
  transaction_commit();
  Py_RETURN_NONE;
}

static PyObject *py_in_transaction(PyObject *self, PyObject *args) {
  (void)self;
  (void)args;
  pthread_mutex_lock(&g_lock);
  bool in_tx = (g_cmd != NULL);
  pthread_mutex_unlock(&g_lock);
  if (in_tx) {
    Py_RETURN_TRUE;
  }
  Py_RETURN_FALSE;
}

static PyObject *py_set_bar_name(PyObject *self, PyObject *args) {
  (void)self;
  const char *name = NULL;
  if (!PyArg_ParseTuple(args, "s:set_bar_name", &name)) {
    return NULL;
  }
  pthread_mutex_lock(&g_lock);
  g_port = 0;
  snprintf(g_bs_lookup, sizeof(g_bs_lookup), "git.felix.%s", name);
  pthread_mutex_unlock(&g_lock);
  Py_RETURN_NONE;
}

static PyObject *py_hotload(PyObject *self, PyObject *args) {
  (void)self;
  int on = 0;
  if (!PyArg_ParseTuple(args, "p:hotload", &on)) {
    return NULL;
  }
  struct stack stack;
  stack_init(&stack);
  stack_push_clone(&stack, on ? "on" : "off");
  stack_push_clone(&stack, HOTLOAD);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
  Py_RETURN_NONE;
}

static PyObject *py_bar(PyObject *self, PyObject *args) {
  (void)self;
  PyObject *props = NULL;
  if (!PyArg_ParseTuple(args, "O!:bar", &PyDict_Type, &props)) {
    return NULL;
  }
  struct stack stack;
  stack_init(&stack);
  if (parse_kv_table(props, NULL, &stack) != 0) {
    stack_destroy(&stack);
    return NULL;
  }
  stack_push_clone(&stack, BAR);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
  Py_RETURN_NONE;
}

static PyObject *py_default(PyObject *self, PyObject *args) {
  (void)self;
  PyObject *props = NULL;
  if (!PyArg_ParseTuple(args, "O!:default", &PyDict_Type, &props)) {
    return NULL;
  }
  struct stack stack;
  stack_init(&stack);
  if (parse_kv_table(props, NULL, &stack) != 0) {
    stack_destroy(&stack);
    return NULL;
  }
  stack_push_clone(&stack, DEFAULT);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
  Py_RETURN_NONE;
}

static PyObject *py_set(PyObject *self, PyObject *args) {
  (void)self;
  const char *name = NULL;
  PyObject *props = NULL;
  if (!PyArg_ParseTuple(args, "sO!:set", &name, &PyDict_Type, &props)) {
    return NULL;
  }
  struct stack stack;
  stack_init(&stack);
  if (parse_kv_table(props, NULL, &stack) != 0) {
    stack_destroy(&stack);
    return NULL;
  }
  stack_push_clone(&stack, name);
  stack_push_clone(&stack, SET);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
  Py_RETURN_NONE;
}

static PyObject *py_trigger(PyObject *self, PyObject *args) {
  (void)self;
  const char *event = NULL;
  PyObject *env = Py_None;
  if (!PyArg_ParseTuple(args, "s|O!:trigger", &event, &PyDict_Type, &env)) {
    // Optional env dict; allow missing.
    PyErr_Clear();
    if (!PyArg_ParseTuple(args, "s|O:trigger", &event, &env)) {
      return NULL;
    }
  }

  struct stack stack;
  stack_init(&stack);
  if (env != Py_None) {
    if (!PyDict_Check(env)) {
      PyErr_SetString(PyExc_TypeError, "env must be a dict or None");
      stack_destroy(&stack);
      return NULL;
    }
    if (parse_kv_table(env, NULL, &stack) != 0) {
      stack_destroy(&stack);
      return NULL;
    }
  }
  stack_push_clone(&stack, event);
  stack_push_clone(&stack, TRIGGER);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
  Py_RETURN_NONE;
}

static PyObject *py_remove(PyObject *self, PyObject *args) {
  (void)self;
  const char *name = NULL;
  if (!PyArg_ParseTuple(args, "s:remove", &name)) {
    return NULL;
  }
  struct stack stack;
  stack_init(&stack);
  stack_push_clone(&stack, name);
  stack_push_clone(&stack, REMOVE);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
  Py_RETURN_NONE;
}

static PyObject *py_push(PyObject *self, PyObject *args) {
  (void)self;
  const char *name = NULL;
  PyObject *values = NULL;
  if (!PyArg_ParseTuple(args, "sO:push", &name, &values)) {
    return NULL;
  }
  struct stack stack;
  stack_init(&stack);
  if (parse_sequence_values(values, &stack) != 0) {
    stack_destroy(&stack);
    return NULL;
  }
  stack_push_clone(&stack, name);
  stack_push_clone(&stack, PUSH);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
  Py_RETURN_NONE;
}

static PyObject *py_query(PyObject *self, PyObject *args) {
  (void)self;
  const char *name = NULL;
  if (!PyArg_ParseTuple(args, "s:query", &name)) {
    return NULL;
  }

  pthread_mutex_lock(&g_lock);
  bool interrupted = (g_cmd != NULL);
  pthread_mutex_unlock(&g_lock);

  if (interrupted) {
    transaction_commit();
  }

  struct stack stack;
  stack_init(&stack);
  stack_push_clone(&stack, name);
  stack_push_clone(&stack, QUERY);
  char *rsp = sketchybar_send_stack(&stack, true);
  stack_destroy(&stack);

  if (interrupted) {
    transaction_begin();
  }

  if (!rsp) {
    Py_RETURN_NONE;
  }

  PyObject *out = PyUnicode_FromString(rsp);
  free(rsp);
  return out;
}

static void subscribe_register_event(const char *name, const char *event, PyObject *callable) {
  struct stack stack;
  stack_init(&stack);

  char mach_helper[128] = {0};
  snprintf(mach_helper, sizeof(mach_helper), "mach_helper=%s", g_bootstrap_name);

  stack_push_clone(&stack, mach_helper);
  stack_push_clone(&stack, "script=");
  stack_push_clone(&stack, name);
  stack_push_clone(&stack, SET);
  stack_push_clone(&stack, event);
  stack_push_clone(&stack, "event");
  stack_push_clone(&stack, ADD);

  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);

  pthread_mutex_lock(&g_lock);
  int found = -1;
  for (uint32_t i = 0; i < g_callbacks.count; i++) {
    if (strcmp(g_callbacks.entries[i].name, name) == 0 && strcmp(g_callbacks.entries[i].event, event) == 0) {
      found = (int)i;
      break;
    }
  }
  if (found >= 0) {
    Py_DECREF(g_callbacks.entries[found].callable);
    g_callbacks.entries[found].callable = callable;
    Py_INCREF(callable);
  } else {
    g_callbacks.entries = realloc(g_callbacks.entries, sizeof(struct callback_entry) * (g_callbacks.count + 1));
    struct callback_entry *entry = &g_callbacks.entries[g_callbacks.count];
    entry->name = strdup(name);
    entry->event = strdup(event);
    entry->callable = callable;
    Py_INCREF(callable);
    g_callbacks.count += 1;
  }
  pthread_mutex_unlock(&g_lock);

  stack_init(&stack);
  stack_push_clone(&stack, event);
  stack_push_clone(&stack, name);
  stack_push_clone(&stack, SUBSCRIBE);
  rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);
}

static PyObject *py_subscribe(PyObject *self, PyObject *args) {
  (void)self;
  const char *name = NULL;
  PyObject *events = NULL;
  PyObject *callable = NULL;
  if (!PyArg_ParseTuple(args, "sOO:subscribe", &name, &events, &callable)) {
    return NULL;
  }

  if (!PyCallable_Check(callable)) {
    PyErr_SetString(PyExc_TypeError, "callback must be callable");
    return NULL;
  }

  if (PyUnicode_Check(events)) {
    const char *event = PyUnicode_AsUTF8(events);
    if (!event) {
      return NULL;
    }
    subscribe_register_event(name, event, callable);
    Py_RETURN_NONE;
  }

  PyObject *seq = PySequence_Fast(events, "events must be a string or sequence of strings");
  if (!seq) {
    return NULL;
  }
  Py_ssize_t n = PySequence_Fast_GET_SIZE(seq);
  PyObject **items = PySequence_Fast_ITEMS(seq);
  for (Py_ssize_t i = 0; i < n; i++) {
    PyObject *ev = items[i];
    if (!PyUnicode_Check(ev)) {
      Py_DECREF(seq);
      PyErr_SetString(PyExc_TypeError, "events must be strings");
      return NULL;
    }
    const char *event = PyUnicode_AsUTF8(ev);
    if (!event) {
      Py_DECREF(seq);
      return NULL;
    }
    subscribe_register_event(name, event, callable);
  }
  Py_DECREF(seq);
  Py_RETURN_NONE;
}

static PyObject *env_to_dict(const char *message, size_t len, const char **out_name, const char **out_sender) {
  PyObject *dict = PyDict_New();
  if (!dict) {
    return NULL;
  }

  size_t i = 0;
  const char *name_val = NULL;
  const char *sender_val = NULL;
  while (i < len) {
    const char *key = message + i;
    size_t key_len = strnlen(key, len - i);
    if (key_len == 0) {
      break;
    }
    i += key_len + 1;
    if (i >= len) {
      break;
    }
    const char *value = message + i;
    size_t val_len = strnlen(value, len - i);
    i += val_len + 1;

    if (strcmp(key, "NAME") == 0) {
      name_val = value;
    } else if (strcmp(key, "SENDER") == 0) {
      sender_val = value;
    }

    PyObject *py_key = PyUnicode_FromString(key);
    if (!py_key) {
      Py_DECREF(dict);
      return NULL;
    }
    PyObject *py_val = PyUnicode_DecodeUTF8(value, (Py_ssize_t)val_len, "replace");
    if (!py_val) {
      Py_DECREF(py_key);
      Py_DECREF(dict);
      return NULL;
    }
    PyDict_SetItem(dict, py_key, py_val);
    Py_DECREF(py_key);
    Py_DECREF(py_val);
  }

  *out_name = name_val;
  *out_sender = sender_val;
  return dict;
}

static void call_python_callback_with_transaction(PyObject *callable, PyObject *args_tuple) {
  transaction_begin();

  PyObject *ret = PyObject_CallObject(callable, args_tuple);
  if (!ret) {
    PyErr_Print();
  } else {
    Py_DECREF(ret);
  }

  transaction_commit();
}

static void callback_function(char *message, size_t len) {
  if (!message || len == 0) {
    return;
  }

  // Internal async callback: [0x07][int id][int exit_code][bytes...]
  if (len >= 1 + 2 * sizeof(int) && (unsigned char)message[0] == 0x07) {
    int callback_id = 0;
    int exit_code = 0;
    memcpy(&callback_id, message + 1, sizeof(int));
    memcpy(&exit_code, message + 1 + sizeof(int), sizeof(int));

    const char *payload = message + 1 + 2 * sizeof(int);
    size_t payload_len = len - (1 + 2 * sizeof(int));

    PyGILState_STATE gil = PyGILState_Ensure();
    PyObject *callable = async_pop(callback_id, ASYNC_EXEC);
    if (callable) {
      PyObject *output = PyUnicode_DecodeUTF8(payload, (Py_ssize_t)payload_len, "replace");
      if (output) {
        PyObject *exit_code_obj = PyLong_FromLong(exit_code);
        PyObject *args = exit_code_obj ? PyTuple_Pack(2, output, exit_code_obj) : NULL;
        Py_XDECREF(exit_code_obj);
        if (args) {
          call_python_callback_with_transaction(callable, args);
          Py_DECREF(args);
        }
        Py_DECREF(output);
      } else {
        PyErr_Print();
      }
      Py_DECREF(callable);
    }
    PyGILState_Release(gil);
    return;
  }

  PyGILState_STATE gil = PyGILState_Ensure();
  const char *name = NULL;
  const char *sender = NULL;
  PyObject *env = env_to_dict(message, len, &name, &sender);
  if (!env) {
    PyErr_Print();
    PyGILState_Release(gil);
    return;
  }

  PyObject *callable = NULL;
  if (name && sender) {
    pthread_mutex_lock(&g_lock);
    for (uint32_t i = 0; i < g_callbacks.count; i++) {
      if (strcmp(g_callbacks.entries[i].name, name) == 0 && strcmp(g_callbacks.entries[i].event, sender) == 0) {
        callable = g_callbacks.entries[i].callable;
        Py_INCREF(callable);
        break;
      }
    }
    pthread_mutex_unlock(&g_lock);
  }

  if (callable) {
    PyObject *args = PyTuple_Pack(1, env);
    if (args) {
      call_python_callback_with_transaction(callable, args);
      Py_DECREF(args);
    } else {
      PyErr_Print();
    }
    Py_DECREF(callable);
  }

  Py_DECREF(env);
  PyGILState_Release(gil);
}

static void orphan_check(CFRunLoopTimerRef timer, void *info) {
  (void)timer;
  (void)info;
  if (getppid() == 1) {
    exit(0);
  }
}

static PyObject *py_event_loop(PyObject *self, PyObject *args) {
  (void)self;
  (void)args;

  struct stack stack;
  stack_init(&stack);
  stack_push_clone(&stack, UPDATE);
  char *rsp = sketchybar_send_stack(&stack, true);
  log_sketchybar_response_and_free(rsp);
  stack_destroy(&stack);

  mach_server_begin(&g_mach_server, callback_function);

  CFRunLoopTimerRef orphan_timer =
      CFRunLoopTimerCreate(kCFAllocatorDefault, CFAbsoluteTimeGetCurrent() + 1.0, 1.0, 0, 0, orphan_check, NULL);
  CFRunLoopAddTimer(CFRunLoopGetMain(), orphan_timer, kCFRunLoopDefaultMode);
  CFRelease(orphan_timer);

  Py_BEGIN_ALLOW_THREADS
  CFRunLoopRun();
  Py_END_ALLOW_THREADS

  Py_RETURN_NONE;
}

static PyObject *py_exec(PyObject *self, PyObject *args) {
  (void)self;
  const char *command = NULL;
  PyObject *callback = Py_None;
  if (!PyArg_ParseTuple(args, "s|O:exec", &command, &callback)) {
    return NULL;
  }

  int callback_id = 0;
  if (callback != Py_None) {
    if (!PyCallable_Check(callback)) {
      PyErr_SetString(PyExc_TypeError, "callback must be callable");
      return NULL;
    }
    callback_id = async_register(ASYNC_EXEC, callback);
  }

  int pid = fork();
  if (pid != 0) {
    Py_RETURN_NONE;
  }

  alarm(60);
  if (callback_id == 0) {
    char *execv[] = {"/usr/bin/env", "sh", "-c", (char *)command, NULL};
    _exit(execvp(execv[0], execv));
  }

  FILE *file = popen(command, "r");
  if (!file) {
    _exit(127);
  }

  char *result = malloc(1024);
  size_t read_bytes = 0;
  size_t total_bytes = 0;
  while ((read_bytes = fread(result + total_bytes, 1, 1024, file)) > 0) {
    total_bytes += read_bytes;
    result = realloc(result, total_bytes + 1024);
  }
  int close_ret = pclose(file);
  int exit_code = WEXITSTATUS(close_ret);

  size_t message_size = total_bytes + 2 * sizeof(int) + sizeof(char);
  char *message = malloc(message_size);
  message[0] = 0x07;
  memcpy(message + 1, &callback_id, sizeof(int));
  memcpy(message + 1 + sizeof(int), &exit_code, sizeof(int));
  memcpy(message + 1 + 2 * sizeof(int), result, total_bytes);

  mach_send_message(mach_get_bs_port(g_bootstrap_name), message, (uint32_t)message_size, false);

  free(message);
  free(result);
  _exit(close_ret);
}

static void delay_callback(CFRunLoopTimerRef timer, void *context) {
  (void)timer;
  int callback_id = (int)(intptr_t)context;

  PyGILState_STATE gil = PyGILState_Ensure();
  PyObject *callable = async_pop(callback_id, ASYNC_DELAY);
  if (callable) {
    PyObject *args = PyTuple_New(0);
    if (args) {
      call_python_callback_with_transaction(callable, args);
      Py_DECREF(args);
    } else {
      PyErr_Print();
    }
    Py_DECREF(callable);
  }
  PyGILState_Release(gil);
}

static PyObject *py_delay(PyObject *self, PyObject *args) {
  (void)self;
  double seconds = 0.0;
  PyObject *callback = NULL;
  if (!PyArg_ParseTuple(args, "dO:delay", &seconds, &callback)) {
    return NULL;
  }
  if (!PyCallable_Check(callback)) {
    PyErr_SetString(PyExc_TypeError, "callback must be callable");
    return NULL;
  }

  int callback_id = async_register(ASYNC_DELAY, callback);

  CFRunLoopTimerContext context = {0};
  context.info = (void *)(intptr_t)callback_id;
  CFRunLoopTimerRef timer =
      CFRunLoopTimerCreate(kCFAllocatorDefault, CFAbsoluteTimeGetCurrent() + seconds, 0, 0, 0, delay_callback, &context);

  CFRunLoopAddTimer(CFRunLoopGetMain(), timer, kCFRunLoopDefaultMode);
  CFRelease(timer);

  Py_RETURN_NONE;
}

static PyObject *py_send(PyObject *self, PyObject *args, PyObject *kwargs) {
  (void)self;
  PyObject *seq_obj = NULL;
  int response = 1;
  static char *kwlist[] = {"args", "response", NULL};
  if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O|p:send", kwlist, &seq_obj, &response)) {
    return NULL;
  }

  PyObject *seq = PySequence_Fast(seq_obj, "args must be a sequence of strings");
  if (!seq) {
    return NULL;
  }

  struct stack stack;
  stack_init(&stack);
  Py_ssize_t n = PySequence_Fast_GET_SIZE(seq);
  PyObject **items = PySequence_Fast_ITEMS(seq);
  for (Py_ssize_t i = n - 1; i >= 0; i--) {
    PyObject *obj = items[i];
    if (!PyUnicode_Check(obj)) {
      Py_DECREF(seq);
      stack_destroy(&stack);
      PyErr_SetString(PyExc_TypeError, "args must be strings");
      return NULL;
    }
    const char *s = PyUnicode_AsUTF8(obj);
    if (!s) {
      Py_DECREF(seq);
      stack_destroy(&stack);
      return NULL;
    }
    stack_push_clone(&stack, s);
  }

  Py_DECREF(seq);
  char *rsp = sketchybar_send_stack(&stack, response ? true : false);
  stack_destroy(&stack);

  if (!rsp) {
    Py_RETURN_NONE;
  }
  PyObject *out = PyUnicode_FromString(rsp);
  free(rsp);
  return out;
}

static PyMethodDef methods[] = {
    {"begin_config", py_begin_config, METH_NOARGS, NULL},
    {"end_config", py_end_config, METH_NOARGS, NULL},
    {"in_transaction", py_in_transaction, METH_NOARGS, NULL},
    {"send", (PyCFunction)py_send, METH_VARARGS | METH_KEYWORDS, NULL},
    {"set_bar_name", py_set_bar_name, METH_VARARGS, NULL},
    {"hotload", py_hotload, METH_VARARGS, NULL},
    {"bar", py_bar, METH_VARARGS, NULL},
    {"default", py_default, METH_VARARGS, NULL},
    {"set", py_set, METH_VARARGS, NULL},
    {"trigger", py_trigger, METH_VARARGS, NULL},
    {"remove", py_remove, METH_VARARGS, NULL},
    {"push", py_push, METH_VARARGS, NULL},
    {"query", py_query, METH_VARARGS, NULL},
    {"subscribe", py_subscribe, METH_VARARGS, NULL},
    {"event_loop", py_event_loop, METH_NOARGS, NULL},
    {"exec", py_exec, METH_VARARGS, NULL},
    {"delay", py_delay, METH_VARARGS, NULL},
    {NULL, NULL, 0, NULL},
};

static int module_exec(PyObject *module) {
  (void)module;
  snprintf(g_bootstrap_name, sizeof(g_bootstrap_name), "git.py.sketchybar%d", (int)getpid());

  signal(SIGCHLD, SIG_IGN);
  signal(SIGPIPE, SIG_IGN);

  if (!mach_server_register(&g_mach_server, g_bootstrap_name)) {
    PyErr_SetString(PyExc_RuntimeError, "failed to register mach server");
    return -1;
  }

  return 0;
}

static PyModuleDef_Slot slots[] = {
    {Py_mod_exec, module_exec},
    {Py_mod_gil, Py_MOD_GIL_NOT_USED},
    {0, NULL},
};

static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,
    .m_name = "sbar_python._native",
    .m_doc = NULL,
    .m_size = 0,
    .m_methods = methods,
    .m_slots = slots,
};

PyMODINIT_FUNC PyInit__native(void) {
  return PyModuleDef_Init(&moduledef);
}
