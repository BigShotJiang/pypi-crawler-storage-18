from __future__ import annotations

import inspect
import json
from contextlib import contextmanager
from collections.abc import Callable, Mapping, Sequence
from typing import Any, Literal, overload

try:
    from . import _native
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "Failed to import `sbar_python._native` (C extension). Please ensure you run `uv pip install -e .` on macOS to complete the build."
    ) from exc
from ._dsl import SbarSection


def _is_mapping(value: Any) -> bool:
    return isinstance(value, Mapping)


def _merge_dict(dst: dict[str, Any], src: Mapping[str, Any]) -> dict[str, Any]:
    for key, value in src.items():
        if key in dst and isinstance(dst[key], dict) and isinstance(value, Mapping):
            _merge_dict(dst[key], value)
        else:
            dst[key] = value
    return dst


def _section_to_pair(section: SbarSection) -> tuple[str, Mapping[str, Any]]:
    return section.key, section.to_sbar()


def _normalize_parts(*parts: Any, **kwargs: Any) -> dict[str, Any]:
    out: dict[str, Any] = {}

    def merge_part(part: Any) -> None:
        if part is None:
            return
        if _is_mapping(part):
            _merge_dict(out, part)
            return

        to_sbar = getattr(part, "to_sbar", None)
        if callable(to_sbar):
            value = to_sbar()
            if not isinstance(value, Mapping):
                raise TypeError(f"to_sbar() must return a mapping, got {type(value)!r}")
            key = getattr(part, "key", None)
            if isinstance(key, str):
                existing = out.get(key)
                if isinstance(existing, dict):
                    _merge_dict(existing, dict(value))
                else:
                    out[key] = dict(value)
            else:
                _merge_dict(out, value)
            return

        raise TypeError(f"Unsupported part type: {type(part)!r}")

    for part in parts:
        merge_part(part)

    for key, value in kwargs.items():
        if key == "padding":
            left, right = value
            out.setdefault("padding_left", left)
            out.setdefault("padding_right", right)
            continue
        to_sbar = getattr(value, "to_sbar", None)
        if callable(to_sbar) and isinstance(getattr(value, "key", None), str):
            section_key, section_value = _section_to_pair(value)  # type: ignore[arg-type]
            out[section_key] = dict(section_value)
        else:
            out[key] = value

    return out


def _maybe_parse_json_object_or_array(text: str) -> Any:
    stripped = text.strip()
    if not stripped:
        return text
    if stripped[0] not in "{[":
        return text
    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError:
        return text
    if isinstance(parsed, (dict, list)):
        return parsed
    return text


def _adapt_callback_arity(fn: Callable[..., Any], *, max_args: int) -> Callable[..., Any]:
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return fn

    positional = [
        p
        for p in sig.parameters.values()
        if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
    ]
    has_varargs = any(p.kind == p.VAR_POSITIONAL for p in sig.parameters.values())

    if has_varargs:
        return fn

    wants = len(positional)

    def wrapper(*args: Any) -> Any:
        return fn(*args[: min(wants, max_args)])

    return wrapper


def _wrap_env_callback(fn: Callable[..., Any]) -> Callable[[dict[str, str]], Any]:
    fn2 = _adapt_callback_arity(fn, max_args=1)

    def wrapper(env: dict[str, str]) -> Any:
        parsed_env: dict[str, Any] = {}
        for k, v in env.items():
            parsed_env[k] = _maybe_parse_json_object_or_array(v)
        return fn2(parsed_env)

    return wrapper


def _wrap_exec_callback(fn: Callable[..., Any]) -> Callable[[str, int], Any]:
    fn2 = _adapt_callback_arity(fn, max_args=2)

    def wrapper(output: str, exit_code: int) -> Any:
        parsed = _maybe_parse_json_object_or_array(output)
        return fn2(parsed, exit_code)

    return wrapper


class Item:
    def __init__(self, name: str) -> None:
        self.name = name

    def set(self, *parts: Any, **kwargs: Any) -> None:
        set(self.name, *parts, **kwargs)

    def subscribe(self, events: str | Sequence[str], callback: Callable[..., Any]) -> None:
        subscribe(self.name, events, callback)

    def query(self) -> Any:
        return query(self.name)

    def push(self, values: Sequence[float]) -> None:
        push(self.name, values)

    def remove(self) -> None:
        remove(self.name)


class Sbar:
    def bar(self, *parts: Any, **kwargs: Any) -> None:
        props = _normalize_parts(*parts, **kwargs)
        _native.bar(props)

    def default(self, *parts: Any, **kwargs: Any) -> None:
        props = _normalize_parts(*parts, **kwargs)
        _native.default(props)

    def set(self, target: str | Item, *parts: Any, **kwargs: Any) -> None:
        name = target.name if isinstance(target, Item) else target
        props = _normalize_parts(*parts, **kwargs)
        _native.set(name, props)

    @overload
    def add(self, kind: Literal["item", "space", "alias"], name: str | None = None, props: Mapping[str, Any] | None = None) -> Item: ...

    @overload
    def add(self, kind: Literal["bracket"], name: str | None, members: Sequence[str | Item], props: Mapping[str, Any] | None = None) -> Item: ...

    @overload
    def add(self, kind: Literal["bracket"], members: Sequence[str | Item], props: Mapping[str, Any] | None = None) -> Item: ...

    @overload
    def add(self, kind: Literal["slider", "graph"], name: str | None, width: int, props: Mapping[str, Any] | None = None) -> Item: ...

    @overload
    def add(self, kind: Literal["slider", "graph"], width: int, props: Mapping[str, Any] | None = None) -> Item: ...

    @overload
    def add(self, kind: Literal["event"], name: str, notification: str | None = None) -> Item: ...

    def add(self, kind: str, *args: Any, **kwargs: Any) -> Item:
        name_kw = kwargs.pop("name", None)
        props_kw = kwargs.pop("props", None)
        members_kw = kwargs.pop("members", None)
        width_kw = kwargs.pop("width", None)
        notification_kw = kwargs.pop("notification", None)
        if kwargs:
            raise TypeError(f"Unexpected keyword arguments: {', '.join(sorted(kwargs.keys()))}")

        name: str | None = None
        props: Mapping[str, Any] | None = None

        def _new_uid() -> str:
            _uid_counter[0] += 1
            return f"item_{_uid_counter[0]}"

        if kind in {"item", "space", "alias"}:
            if args and isinstance(args[0], str):
                name = args[0]
                props = args[1] if len(args) > 1 else None
            else:
                props = args[0] if args else None

            if name is None:
                name = str(name_kw) if name_kw is not None else _new_uid()
            if props is None and props_kw is not None:
                props = props_kw

            _native_send(["--add", kind, name, "left"])
            if props is not None:
                _native.set(name, dict(props))
            return Item(name)

        if kind == "event":
            if args and isinstance(args[0], str):
                name = args[0]
                notification = args[1] if len(args) > 1 else None
            else:
                name = str(name_kw) if name_kw is not None else None
                notification = notification_kw
            if name is None:
                raise TypeError("add('event', name, notification=None) requires a name")
            argv = ["--add", "event", name]
            if notification is not None:
                argv.append(str(notification))
            _native_send(argv)
            return Item(name)

        if kind in {"slider", "graph"}:
            width: Any = None
            if args:
                if isinstance(args[0], str):
                    name = args[0]
                    width = args[1] if len(args) > 1 else None
                    props = args[2] if len(args) > 2 else None
                else:
                    width = args[0]
                    props = args[1] if len(args) > 1 else None
            else:
                width = width_kw
                props = props_kw

            if width is None:
                raise TypeError("add('slider'|'graph', width, props=None) missing width")
            if name is None:
                name = str(name_kw) if name_kw is not None else _new_uid()
            if props is None and props_kw is not None:
                props = props_kw

            argv = ["--add", kind, name, "left", str(int(width))]
            _native_send(argv)
            if props is not None:
                _native.set(name, dict(props))
            return Item(name)

        if kind == "bracket":
            members: Sequence[str | Item]
            if args and isinstance(args[0], str):
                name = args[0]
                members = args[1]
                props = args[2] if len(args) > 2 else None
            else:
                members = args[0] if args else members_kw
                props = args[1] if len(args) > 1 else None

            if members is None:
                raise TypeError("add('bracket', members, props=None) missing members")
            if name is None:
                name = str(name_kw) if name_kw is not None else _new_uid()
            if props is None and props_kw is not None:
                props = props_kw

            member_names = [m.name if isinstance(m, Item) else str(m) for m in members]
            argv = ["--add", "bracket", name, *member_names]
            _native_send(argv)
            if props is not None:
                _native.set(name, dict(props))
            return Item(name)

        raise ValueError(f"Unsupported add kind: {kind!r}")

    def add_item(self, name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
        props = _normalize_parts(*parts, **kwargs)
        return self.add("item", props) if name is None else self.add("item", name, props)

    def add_space(self, name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
        props = _normalize_parts(*parts, **kwargs)
        return self.add("space", props) if name is None else self.add("space", name, props)

    def add_alias(self, name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
        props = _normalize_parts(*parts, **kwargs)
        return self.add("alias", props) if name is None else self.add("alias", name, props)

    def add_slider(self, width: int, name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
        props = _normalize_parts(*parts, **kwargs)
        return self.add("slider", width, props) if name is None else self.add("slider", name, width, props)

    def add_graph(self, width: int, name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
        props = _normalize_parts(*parts, **kwargs)
        return self.add("graph", width, props) if name is None else self.add("graph", name, width, props)

    def add_bracket(
        self, members: Sequence[str | Item], name: str | None = None, /, *parts: Any, **kwargs: Any
    ) -> Item:
        props = _normalize_parts(*parts, **kwargs)
        return self.add("bracket", members, props) if name is None else self.add("bracket", name, members, props)

    def add_event(self, name: str, notification: str | None = None) -> Item:
        return self.add("event", name, notification)

    def subscribe(self, target: str | Item, events: str | Sequence[str], callback: Callable[..., Any]) -> None:
        name = target.name if isinstance(target, Item) else target
        _native.subscribe(name, events, _wrap_env_callback(callback))

    def trigger(self, event: str, env: Mapping[str, Any] | None = None) -> None:
        _native.trigger(event, None if env is None else dict(env))

    def query(self, target: str | Item) -> Any:
        name = target.name if isinstance(target, Item) else target
        rsp = _native.query(name)
        if not rsp:
            return None
        return json.loads(rsp)

    def push(self, target: str | Item, values: Sequence[float]) -> None:
        name = target.name if isinstance(target, Item) else target
        _native.push(name, values)

    def remove(self, target: str | Item) -> None:
        name = target.name if isinstance(target, Item) else target
        _native.remove(name)

    def animate(self, curve: str, duration: float, fn: Callable[[], Any]) -> None:
        begin_config()
        try:
            _native_send(["--animate", curve, str(int(duration))])
            fn()
        finally:
            end_config()

    def exec(self, command: str, callback: Callable[..., Any] | None = None) -> None:
        cb = _wrap_exec_callback(callback) if callback is not None else None
        _native.exec(command, cb)

    def delay(self, seconds: float, callback: Callable[[], Any]) -> None:
        _native.delay(seconds, callback)

    def hotload(self, on: bool) -> None:
        _native.hotload(on)

    def set_bar_name(self, name: str) -> None:
        _native.set_bar_name(name)

    def begin_config(self) -> None:
        _native.begin_config()

    def end_config(self) -> None:
        _native.end_config()

    def event_loop(self) -> None:
        _native.event_loop()

    def update(self) -> None:
        self.event_loop()


def _native_send(args: Sequence[str]) -> None:
    _native.send(list(args), response=True)


_uid_counter = [0]
sbar = Sbar()


def bar(*parts: Any, **kwargs: Any) -> None:
    sbar.bar(*parts, **kwargs)


def default(*parts: Any, **kwargs: Any) -> None:
    sbar.default(*parts, **kwargs)


def set(target: str | Item, *parts: Any, **kwargs: Any) -> None:
    sbar.set(target, *parts, **kwargs)


def add(kind: str, *args: Any, **kwargs: Any) -> Item:
    return sbar.add(kind, *args, **kwargs)


def add_item(name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
    return sbar.add_item(name, *parts, **kwargs)


def add_space(name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
    return sbar.add_space(name, *parts, **kwargs)


def add_alias(name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
    return sbar.add_alias(name, *parts, **kwargs)


def add_slider(width: int, name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
    return sbar.add_slider(width, name, *parts, **kwargs)


def add_graph(width: int, name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
    return sbar.add_graph(width, name, *parts, **kwargs)


def add_bracket(members: Sequence[str | Item], name: str | None = None, /, *parts: Any, **kwargs: Any) -> Item:
    return sbar.add_bracket(members, name, *parts, **kwargs)


def add_event(name: str, notification: str | None = None) -> Item:
    return sbar.add_event(name, notification)


def subscribe(target: str | Item, events: str | Sequence[str], callback: Callable[..., Any]) -> None:
    sbar.subscribe(target, events, callback)


def trigger(event: str, env: Mapping[str, Any] | None = None) -> None:
    sbar.trigger(event, env)


def query(target: str | Item) -> Any:
    return sbar.query(target)


def push(target: str | Item, values: Sequence[float]) -> None:
    sbar.push(target, values)


def remove(target: str | Item) -> None:
    sbar.remove(target)


def animate(curve: str, duration: float, fn: Callable[[], Any]) -> None:
    sbar.animate(curve, duration, fn)


def exec(command: str, callback: Callable[..., Any] | None = None) -> None:
    sbar.exec(command, callback)


def delay(seconds: float, callback: Callable[[], Any]) -> None:
    sbar.delay(seconds, callback)


def hotload(on: bool) -> None:
    sbar.hotload(on)


def set_bar_name(name: str) -> None:
    sbar.set_bar_name(name)


def begin_config() -> None:
    sbar.begin_config()


def end_config() -> None:
    sbar.end_config()


def event_loop() -> None:
    sbar.event_loop()


def update() -> None:
    sbar.update()


@contextmanager
def config() -> Any:
    begin_config()
    try:
        yield
    finally:
        end_config()
