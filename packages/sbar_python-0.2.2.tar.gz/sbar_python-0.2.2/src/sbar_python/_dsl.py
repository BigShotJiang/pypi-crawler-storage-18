from __future__ import annotations

from dataclasses import dataclass
from typing import Any, ClassVar, Mapping, Protocol, Self


class SbarSection(Protocol):
    key: ClassVar[str]

    def to_sbar(self) -> Mapping[str, Any]: ...


def _to_plain(value: Any) -> Any:
    if value is None:
        return None
    to_sbar = getattr(value, "to_sbar", None)
    if callable(to_sbar):
        return {k: _to_plain(v) for k, v in dict(to_sbar()).items()}
    if isinstance(value, Mapping):
        return {k: _to_plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return type(value)(_to_plain(v) for v in value)
    return value


def _drop_none(d: Mapping[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in d.items() if v is not None}


def _padding_to_lr(padding: tuple[int, int] | None) -> dict[str, int]:
    if padding is None:
        return {}
    left, right = padding
    return {"padding_left": left, "padding_right": right}


@dataclass(frozen=True, slots=True)
class Font:
    family: str
    style: str
    size: float

    def to_sbar(self) -> Mapping[str, Any]:
        return {"family": self.family, "style": self.style, "size": self.size}


@dataclass(frozen=True, slots=True, init=False)
class Icon:
    key: ClassVar[str] = "icon"

    font: Font | str | None
    color: int | str | None
    string: str | None
    padding: tuple[int, int] | None
    props: Mapping[str, Any]

    def __init__(
        self,
        font: Font | str | None = None,
        color: int | str | None = None,
        string: str | None = None,
        padding: tuple[int, int] | None = None,
        **props: Any,
    ) -> None:
        object.__setattr__(self, "font", font)
        object.__setattr__(self, "color", color)
        object.__setattr__(self, "string", string)
        object.__setattr__(self, "padding", padding)
        object.__setattr__(self, "props", props)

    def to_sbar(self) -> Mapping[str, Any]:
        base: dict[str, Any] = {}
        if self.font is not None:
            base["font"] = _to_plain(self.font)
        if self.color is not None:
            base["color"] = self.color
        if self.string is not None:
            base["string"] = self.string
        base.update(_padding_to_lr(self.padding))
        base.update({k: _to_plain(v) for k, v in self.props.items()})
        return _drop_none(_to_plain(base))

    def with_props(self, **props: Any) -> Self:
        return type(self)(
            font=self.font,
            color=self.color,
            string=self.string,
            padding=self.padding,
            **{**dict(self.props), **props},
        )


@dataclass(frozen=True, slots=True, init=False)
class Label:
    key: ClassVar[str] = "label"

    font: Font | str | None
    color: int | str | None
    string: str | None
    padding: tuple[int, int] | None
    props: Mapping[str, Any]

    def __init__(
        self,
        font: Font | str | None = None,
        color: int | str | None = None,
        string: str | None = None,
        padding: tuple[int, int] | None = None,
        **props: Any,
    ) -> None:
        object.__setattr__(self, "font", font)
        object.__setattr__(self, "color", color)
        object.__setattr__(self, "string", string)
        object.__setattr__(self, "padding", padding)
        object.__setattr__(self, "props", props)

    def to_sbar(self) -> Mapping[str, Any]:
        base: dict[str, Any] = {}
        if self.font is not None:
            base["font"] = _to_plain(self.font)
        if self.color is not None:
            base["color"] = self.color
        if self.string is not None:
            base["string"] = self.string
        base.update(_padding_to_lr(self.padding))
        base.update({k: _to_plain(v) for k, v in self.props.items()})
        return _drop_none(_to_plain(base))

    def with_props(self, **props: Any) -> Self:
        return type(self)(
            font=self.font,
            color=self.color,
            string=self.string,
            padding=self.padding,
            **{**dict(self.props), **props},
        )


@dataclass(frozen=True, slots=True, init=False)
class Background:
    key: ClassVar[str] = "background"

    props: Mapping[str, Any]

    def __init__(self, **props: Any) -> None:
        object.__setattr__(self, "props", props)

    def to_sbar(self) -> Mapping[str, Any]:
        return _to_plain(dict(self.props))


@dataclass(frozen=True, slots=True, init=False)
class Popup:
    key: ClassVar[str] = "popup"

    props: Mapping[str, Any]

    def __init__(self, **props: Any) -> None:
        object.__setattr__(self, "props", props)

    def to_sbar(self) -> Mapping[str, Any]:
        return _to_plain(dict(self.props))


@dataclass(frozen=True, slots=True, init=False)
class Default:
    props: Mapping[str, Any]

    def __init__(self, **props: Any) -> None:
        object.__setattr__(self, "props", props)

    def to_sbar(self) -> Mapping[str, Any]:
        return _to_plain(dict(self.props))


@dataclass(frozen=True, slots=True, init=False)
class Bar:
    props: Mapping[str, Any]

    def __init__(self, **props: Any) -> None:
        object.__setattr__(self, "props", props)

    def to_sbar(self) -> Mapping[str, Any]:
        return _to_plain(dict(self.props))
