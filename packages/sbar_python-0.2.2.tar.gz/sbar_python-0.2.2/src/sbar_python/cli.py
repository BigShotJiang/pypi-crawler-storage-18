from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path
from typing import Any

import fire


def _safe_str(value: object) -> str:
    try:
        s = str(value or "")
    except Exception:
        return ""
    return s.replace("\n", " ").replace("\r", " ").strip()


def _resolve_dir(path: str) -> Path:
    p = Path(path).expanduser()
    try:
        return p.resolve()
    except Exception:
        return p


def run(*, module: str = "sbar.sketchybarrc", config_dir: str = ".", chdir: bool = True) -> None:
    """
    Run a SketchyBar Python config module.

    Example:
      sbar-python run --config_dir ~/.config/sketchybar --module sbar.sketchybarrc
    """
    module = _safe_str(module)
    if not module:
        raise SystemExit("Missing --module")

    root = _resolve_dir(config_dir)
    sys.path.insert(0, str(root))
    if chdir:
        try:
            os.chdir(root)
        except Exception:
            pass

    mod = importlib.import_module(module)
    main_fn = getattr(mod, "main", None)
    if callable(main_fn):
        main_fn()
        return

    raise SystemExit(f"Module {module!r} has no callable main()")


def main(argv: list[str] | None = None) -> Any:
    return fire.Fire(
        {
            "run": run,
        },
        command=argv,
    )


__all__ = ["main", "run"]
