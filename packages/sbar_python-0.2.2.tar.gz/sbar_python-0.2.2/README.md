# sbar-python

Config SketchyBar in Python. This project mirrors/extends [SbarLua](https://github.com/FelixKratz/SbarLua) (Mach IPC + in-process event loop) while offering a more Pythonic, typed API.

## Quickstart

- Requirements: macOS, SketchyBar, Python 3.14+, `uv`.
- Install (PyPI): `uv pip install sbar-python`
- Run a config module: `sbar-python run --config_dir ~/.config/sketchybar --module sbar.sketchybarrc`
- From source: `uv venv && uv sync && uv pip install -e .`

## Pythonic Example

```python
import sbar_python as sbar
from sbar_python import Font, Icon, Label

sbar.default(
    Icon(font=Font("SF Pro", "Bold", 14.0), color=0xFFCAD3F5),
    Label(font=Font("SF Pro", "Semibold", 13.0), color=0xFFCAD3F5),
    padding=(5, 5),
)
```

## Acknowledgements

- https://github.com/FelixKratz/SketchyBar
- https://github.com/FelixKratz/SbarLua
- https://mikebian.co/scripting-macos-with-javascript-automation/
- https://github.com/ronaldoussoren/pyobjc
