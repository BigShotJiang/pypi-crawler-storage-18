# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

LAIDA CLI is a methodology-driven CLI that transforms project requirements into production-ready software through structured AI collaboration. It implements a 5-phase (0-4), 20-step methodology where each phase generates YAML design artifacts, culminating in Phase 4 which generates actual Python code.

**Key Principle**: Generate atomic YAML files, not prose documents. Reference by ID (R-XXX, QAS-XXX, F-XXX), never duplicate content.

## Development Commands

```bash
# Setup
pip install -e ".[all]"          # Install with all dependencies (dev + tui)
pip install -e ".[dev]"          # Install dev dependencies only

# Quality checks
pytest tests/ -v                 # Run all tests
pytest tests/unit/ -v            # Run unit tests only
pytest tests/unit/domain/ -v     # Run specific test directory
pytest -k "test_phase"           # Run tests matching pattern
ruff check src/                  # Lint code
ruff check src/ --fix            # Lint and auto-fix
mypy src/laida_cli/              # Type check

# CLI usage
laida --help                     # Show available commands
laida init                       # Initialize project structure
laida status                     # Check project progress
laida run 0 0                    # Execute Phase 0 Step 0
laida run 0 0 --dry-run          # Preview without executing
laida validate                   # Validate artifacts
laida tui                        # Launch Mission Control dashboard
```

## Architecture

### Hexagonal Architecture (Ports & Adapters)

```
src/laida_cli/
├── domain/           # Pure value objects, no external dependencies
│   ├── phase_number.py       # PhaseNumber(0-4) value object
│   ├── step_number.py        # StepNumber(0-3) value object
│   ├── execution_status.py   # ExecutionStatus enum
│   ├── execution_result.py   # ExecutionResult value object
│   ├── project_path.py       # ProjectPath value object
│   └── validation_result.py  # ValidationResult value object
│
├── ports/            # Abstract interfaces (Protocol classes)
│   ├── file_system_port.py   # FileSystemPort protocol
│   └── yaml_port.py          # YamlPort protocol
│
├── adapters/         # Concrete implementations
│   ├── file_system_adapter.py
│   ├── yaml_adapter.py
│   └── schema_adapter.py
│
├── services/         # Business logic orchestration
│   ├── detect_state.py       # DetectStateService - scans outputs/
│   ├── manage_context.py     # ManageContextService
│   ├── context_validator.py  # ContextValidatorService
│   └── schema_validator.py   # SchemaValidatorService
│
├── commands/         # Click CLI commands
│   ├── init.py, login.py, run.py, status.py, validate.py
│
├── main.py           # CLI entry point (Click group)
└── tui_main.py       # TUI entry point (Textual app)
```

### Data Flow

1. **User Input** → `inputs/project_context.yaml` (13 sections describing the project)
2. **Phase 0 Step 0** → Calculates scale (small/medium/large), selects tech stack
3. **Each Step** → Reads `_index.yaml` from previous steps, generates new artifacts
4. **Phase 4** → Generates actual Python code in `src/`, tests, CI/CD configs

### Step Execution Flow

```
DetectStateService.detect() → ProjectState
    ↓
Reads .laida/prompts/phase{N}/step{M}_*.yaml
    ↓
Claude Code executes prompt with project_context.yaml
    ↓
Outputs to outputs/phase{N}/step{M}_{name}/_index.yaml
```

## Key Files Reference

| File | Purpose |
|------|---------|
| `.laida/config.yaml` | Phase/step definitions, ID patterns, scale thresholds |
| `.laida/prompts/base_prompt.yaml` | Shared system prompt (enables cache hits) |
| `.laida/prompts/phase{N}/step{M}_*.yaml` | Step-specific prompts |
| `.laida/templates/*.yaml` | Output schemas (risk, qas, function, adr, tdr, etc.) |
| `.laida/rules/scale_calculation.yaml` | Scale algorithm and factor weights |
| `.laida/matrices/tech_selection.yaml` | Tech scoring and constraints |
| `inputs/project_context.yaml` | User's project description (entry point) |

## ID Patterns

All artifacts use sequential IDs for traceability:
- `R-001, R-002` → Risks
- `QAS-001, QAS-002` → Quality Attribute Scenarios
- `F-001, F-002` → Functions
- `M-001, M-002` → Directives (Mandates)
- `ADR-001` → Architecture Decision Records
- `TDR-001` → Tech Decision Records
- `BC-001` → Bounded Contexts

## Testing Patterns

```python
# Domain tests use frozen dataclasses
def test_phase_number_invariant():
    with pytest.raises(ValueError):
        PhaseNumber(value=5)  # Must be 0-4

# CLI tests use Click's CliRunner
def test_status_command(tmp_path):
    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--path", str(tmp_path)])
    assert result.exit_code == 0
```

## Methodology Phases

| Phase | Name | Key Outputs |
|-------|------|-------------|
| 0 | Strategic Foundation | project_scale.yaml, stack_summary.yaml, R-*.yaml, QAS-*.yaml, BC-*.yaml, ADR-*.yaml |
| 1 | Module Design | rtm.yaml (traceability matrix), module specs |
| 2 | Physical Design | File structure, CoT architecture |
| 3 | Contract Definition | API contracts, dependency analysis |
| 4 | Implementation | **Real Python code** in `src/`, tests, CI/CD |

## Scale-Adaptive Behavior

The methodology adapts limits based on calculated project scale:

| Scale | Max Risks | Max QAS | Max Functions |
|-------|-----------|---------|---------------|
| small | 5 | 5 | 15 |
| medium | 10 | 10 | 40 |
| large | unlimited | unlimited | unlimited |

## Constraints

- Every QAS must link to at least one Risk
- Every Function must link to at least one QAS
- No placeholder content (TBD, TODO) in outputs
- All metrics must be quantifiable
- Phase 4 generates real Python files to disk, not just YAML specs
