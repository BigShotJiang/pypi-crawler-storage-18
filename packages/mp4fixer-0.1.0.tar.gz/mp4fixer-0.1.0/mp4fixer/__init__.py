import subprocess
import sys
import os

def fix(input_file=None, output_file=None, preset="ultrafast"):
    try:
        if not input_file:
            return "input file is not given"
            sys.exit(1)
        # Default output
        if not output_file:
            output_file = f"fixed_{os.path.basename(input_file)}"
            output_file = f"{os.path.dirname(input_file)}/{output_file}"

        # Preset validation
        vps = ["ultrafast","superfast","veryfast","faster","fast","medium","slow","slower","veryslow","placebo"]
        if preset not in vps:
            return f"ERR: Given preset is not valid. Valid presets: {vps}"
            sys.exit(1)
        # Check paths
        if not os.path.isfile(input_file):
            return "ERR: Input file does not exist"
            sys.exit(1)
        if not os.path.isdir(os.path.dirname(output_file)):
            return "ERR: Output folder does not exist"
            sys.exit(1)
        if not output_file.endswith(".mp4"):
            if not os.path.exists(output_file):
                if os.path.isfile(output_file):
                    return "ERR: Output folder does not exist"
                    sys.exit(1)
                return "ERR: Output folder does not exist"
                sys.exit(1)
            if not os.path.isfile(output_file):
                output_file = os.path.join(output_file,f"fixed_{os.path.basename(input_file)}")
        # Start ffmpeg process
        prc = subprocess.Popen([
            os.path.join(os.path.dirname(__file__),"mf"),
            "-hide_banner",         # hides copyright/info
            "-loglevel", "warning", # only warnings & errors
            "-stats",               # show progress line
            "-i", input_file,
            "-c:v", "libx264",
            "-preset", preset,
            "-crf", "23",
            "-c:a", "aac",
            "-b:a", "128k",
            "-movflags", "+faststart",
            "-y",
            output_file
            ], stdin=subprocess.PIPE)

        prc.wait()
        return "OK"

    except KeyboardInterrupt:
        prc.stdin.write(b"q\n")
        prc.stdin.flush()
        prc.wait()
        return "Re-Encoding stopped cleanly"
    except Exception as e:
        return f"ERR: {e}"
