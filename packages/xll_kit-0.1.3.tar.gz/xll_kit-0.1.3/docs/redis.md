## Redis

### 初始化

```python
from xll_kit.redis.manager import redis_manager

redis_manager.get_client("cache", url="redis://127.0.0.1:6379/1")
redis_manager.get_async_client("broker", url="redis://127.0.0.1:6379/2")
```

### Lock

```python
from xll_kit.redis.lock import RedisLock

lock = RedisLock(prefix="lock:", instance="cache")

with lock.lock("task1"):
    print("locked")
```

### PubSub

```python
from xll_kit.redis.pubsub import RedisPubSub

pubsub = RedisPubSub(prefix="chat:", instance="broker")

pubsub.publish("system", "hello")
listener = pubsub.subscribe("system")

```