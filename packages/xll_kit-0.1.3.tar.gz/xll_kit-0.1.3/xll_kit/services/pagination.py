from dataclasses import dataclass
from typing import List, Generic, TypeVar

T = TypeVar("T")

@dataclass
class PaginationResult(Generic[T]):
    items: List[T]
    total: int
    page: int
    limit: int

    def __str__(self) -> str:
        return f"PaginationResult(page={self.page}, size={self.limit}, total={self.total})"