from sqlalchemy.orm import Session

from .base import BaseService
from .pagination import PaginationResult

__all__ = [
    'BaseService',
    'PaginationResult'
]

# -------------------------
# 事务装饰器
# -------------------------
def transactional(fn):
    def wrapper(self, session: Session, *args, **kwargs):
        if session.in_transaction():
            return fn(self, session, *args, **kwargs)
        with session.begin():
            return fn(self, session, *args, **kwargs)

    return wrapper