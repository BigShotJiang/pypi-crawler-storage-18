from decimal import Decimal
from datetime import datetime, date
from enum import Enum
from uuid import UUID


def audit_serialize(value):
    """将 Python 对象安全转为 JSON 友好类型"""

    if value is None:
        return None

    if isinstance(value, Decimal):
        # 推荐：转字符串，避免精度丢失
        return str(value)

    if isinstance(value, (datetime, date)):
        return value.isoformat()

    if isinstance(value, Enum):
        return value.value

    if isinstance(value, UUID):
        return str(value)

    if isinstance(value, dict):
        return {k: audit_serialize(v) for k, v in value.items()}

    if isinstance(value, (list, tuple, set)):
        return [audit_serialize(v) for v in value]

    # int / float / str / bool
    return value
