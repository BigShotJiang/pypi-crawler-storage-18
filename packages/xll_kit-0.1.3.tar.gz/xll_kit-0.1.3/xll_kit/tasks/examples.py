"""
任务示例 - 演示如何定义各种类型的任务
"""
from sqlalchemy.orm import Session
from .base import IntervalTask, CronTask, SimpleTask
from .manager import task_manager


@task_manager.register
class DataSyncTask(IntervalTask):
    """数据同步任务 - 每5分钟执行一次"""

    SCHEDULE_INTERVAL = 5

    def execute_with_db(self, db: Session):
        """同步数据逻辑"""
        self.logger.info("开始同步数据...")
        # TODO: 实现数据同步逻辑
        return {"status": "success", "synced": 0}


@task_manager.register
class DailyReportTask(CronTask):
    """日报任务 - 每天凌晨1点执行"""

    SCHEDULE_CRON = "0 1 * * *"

    def execute_with_db(self, db: Session):
        """生成日报"""
        self.logger.info("生成每日报告...")
        # TODO: 实现报告生成逻辑
        return {"status": "success", "report_date": "today"}


@task_manager.register
class CleanupTask(CronTask):
    """清理任务 - 每周日凌晨3点执行"""

    SCHEDULE_CRON = "0 3 * * 0"

    def execute_with_db(self, db: Session):
        """清理过期数据"""
        self.logger.info("清理过期数据...")
        # TODO: 实现数据清理逻辑
        return {"status": "success", "deleted": 0}


@task_manager.register
class HealthCheckTask(SimpleTask):
    """健康检查任务 - 每1分钟执行（不需要数据库）"""

    SCHEDULE_INTERVAL = 1

    def execute(self):
        """检查系统健康状态"""
        self.logger.debug("执行健康检查...")
        # TODO: 实现健康检查逻辑
        return {"status": "healthy"}


@task_manager.register
class ManualTask(IntervalTask):
    """手动任务 - 不自动调度，只能手动触发"""

    SCHEDULE_ENABLED = False

    def execute_with_db(self, db: Session):
        """手动执行的任务"""
        self.logger.info("执行手动任务...")
        # TODO: 实现手动任务逻辑
        return {"status": "success"}