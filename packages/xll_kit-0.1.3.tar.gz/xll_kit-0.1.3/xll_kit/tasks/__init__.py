"""
任务模块 - 统一导出
"""
from .base import BaseTask, DatabaseTask, IntervalTask, CronTask, SimpleTask
from .manager import task_manager

# 自动导入所有任务（会触发装饰器注册）
# try:
#     from . import examples
# except ImportError:
#     pass

__all__ = [
    'BaseTask',
    'DatabaseTask',
    'IntervalTask',
    'CronTask',
    'SimpleTask',
    'task_manager',
]


def start_scheduler():
    """启动任务调度器"""
    task_manager.start()


def shutdown_scheduler():
    """关闭任务调度器"""
    task_manager.shutdown()