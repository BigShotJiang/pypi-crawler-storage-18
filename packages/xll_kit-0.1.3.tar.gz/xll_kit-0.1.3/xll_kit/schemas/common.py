from typing import Generic, TypeVar, List
from pydantic import BaseModel, ConfigDict

T = TypeVar("T")

class ListData(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    limit: int

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        from_attributes=True
    )