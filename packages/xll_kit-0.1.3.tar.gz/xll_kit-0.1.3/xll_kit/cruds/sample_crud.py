from xll_kit.cruds.base import CRUDBase
from xll_kit.cruds.mixins.keyword_search_mixin import KeywordSearchMixin


class Sample:
    ''''''

class SampleCrud(CRUDBase[Sample], KeywordSearchMixin):
    def apply_user_scope(self, stmt, user):
        if user.is_admin:
            return stmt
        return stmt.where(self.model.owner_id == user.id)

    def _keyword_fields(self):
        return ["name", "sku", "barcode"]