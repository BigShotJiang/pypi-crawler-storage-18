from typing import Dict, Any


class OrderByMixin:
    def _sortable_fields(self) -> Dict[str, Any]:
        """声明可排序字段
        return {
            "created_at": self.model.created_at,
            "title": self.model.title,
            "user_name": User.name,          # join 后字段
            "amount": func.coalesce(self.model.amount, 0),
        }
        """
        return {}

    def default_order_by(self):
        """默认排序表达式"""
        return []

    def build_order_clauses(self, sort_keys: list[tuple[str, bool]]):
        """给定 [(field_name, is_desc)], 返回 SQLAlchemy order_by 列表"""
        clauses = []
        sortable = self._sortable_fields()
        for field, is_desc in sort_keys:
            col = sortable.get(field)
            if not col:
                continue
            clauses.append(col.desc() if is_desc else col.asc())
        if not clauses:
            clauses = self.default_order_by()
        return clauses
