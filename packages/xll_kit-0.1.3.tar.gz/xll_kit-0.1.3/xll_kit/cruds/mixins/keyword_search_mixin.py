from typing import List

from sqlalchemy import or_


class KeywordSearchMixin:
    def _keyword_fields(self) -> List[str]:
        return []

    def apply_keyword(self, stmt, keyword: str):
        if not keyword:
            return stmt

        conditions = []
        for field in self._keyword_fields():
            col = getattr(self.model, field, None)
            if col is not None:
                conditions.append(col.like(f"%{keyword}%"))

        if conditions:
            stmt = stmt.where(or_(*conditions))

        return stmt