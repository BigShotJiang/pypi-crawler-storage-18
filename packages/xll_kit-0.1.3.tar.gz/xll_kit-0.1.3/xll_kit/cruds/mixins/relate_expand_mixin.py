# xll_kit/cruds/mixins/expand_mixin.py
from typing import Dict, Any, List
from sqlalchemy.orm import selectinload

class RelateExpandMixin:
    """
    CRUD 层扩展支持：提供 expand_map，返回 dict:name->load option
    """
    def _get_expand_map(self) -> Dict[str, Any]:
        """
        定义可扩展的关联关系映射
        子类应重写此方法
        返回格式: {"关联名": 加载选项}

        示例:
        return {
            "user": joinedload(self.model.user),
            "products": selectinload(self.model.products),
            "comments": subqueryload(self.model.comments),
            "details": joinedload(self.model.details),
            "author": selectinload(Post.author),
            "tags": selectinload(Post.tags),
        }
        """
        return {}

    def apply_expands(self, stmt, expands: List[str] = None):
        if not expands:
            return stmt
        expand_map = self._get_expand_map()
        for e in expands:
            opt = expand_map.get(e)
            if opt is not None:
                stmt = stmt.options(opt)
        return stmt