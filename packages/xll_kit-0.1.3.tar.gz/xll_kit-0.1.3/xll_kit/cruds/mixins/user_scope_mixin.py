class UserScopeMixin:
    def apply_user_scope(self, stmt, user):
        return stmt