"""UI element tests."""
