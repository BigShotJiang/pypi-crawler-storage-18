"""FormSlider component - A styled range slider input."""

import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, Optional

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def form_slider(
    label: str,
    value: float,
    min_val: float,
    max_val: float,
    step: float = 1,
    unit: str = "",
    color: str = "blue",
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    key: Optional[str] = None,
) -> float:
    """
    Display a styled range slider input.

    Args:
        label: Label text for the slider
        value: Current value
        min_val: Minimum value
        max_val: Maximum value
        step: Step increment (default 1)
        unit: Unit suffix to display (e.g., "%", "hrs")
        color: Accent color: "blue", "green", "red", "yellow", "purple"
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        key: Unique key for the component

    Returns:
        The current slider value

    Example:
        threshold = form_slider(
            label="Upper Threshold",
            value=90,
            min_val=75,
            max_val=100,
            unit="%",
            color="red"
        )
    """
    result = _component(
        component="form_slider",
        label=label,
        value=value,
        minVal=min_val,
        maxVal=max_val,
        step=step,
        unit=unit,
        color=color,
        style=style,
        className=class_name,
        key=key,
        default=value,
    )
    return float(result) if result is not None else value
