"""SectionHeader component - A styled section title with optional actions."""

import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, List, Optional

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def section_header(
    title: str,
    icon: str = "",
    actions: Optional[List[Dict[str, Any]]] = None,
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    key: Optional[str] = None,
) -> Optional[str]:
    """
    Display a section header with optional action buttons.

    Args:
        title: The header title text
        icon: Optional emoji or icon to display before the title
        actions: List of action button configs, each with:
                 - id: Unique identifier for the action
                 - label: Button text (optional)
                 - icon: Button icon (optional)
                 - color: Button color: "blue", "green", "red", "yellow" (optional)
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        key: Unique key for the component

    Returns:
        The ID of the clicked action button, or None if no click

    Example:
        clicked = section_header(
            title="Dashboard",
            icon="📊",
            actions=[{"id": "refresh", "label": "Refresh", "color": "blue"}]
        )
        if clicked == "refresh":
            st.rerun()
    """
    return _component(
        component="section_header",
        title=title,
        icon=icon,
        actions=actions or [],
        style=style,
        className=class_name,
        key=key,
        default=None,
    )
