"""ButtonGroup component - A group of action buttons."""

import streamlit.components.v1 as components
from pathlib import Path
from typing import Dict, Any, List, Optional

_FRONTEND_DIR = Path(__file__).parent.parent / "_frontend"

_component = components.declare_component(
    "streamlit_react_components",
    path=str(_FRONTEND_DIR),
)


def button_group(
    buttons: List[Dict[str, Any]],
    style: Optional[Dict[str, Any]] = None,
    class_name: str = "",
    key: Optional[str] = None,
) -> Optional[str]:
    """
    Display a group of action buttons.

    Args:
        buttons: List of button configs, each with:
                 - id: Unique identifier
                 - label: Button text (optional)
                 - icon: Button icon/emoji (optional)
                 - color: Button color: "blue", "green", "red", "yellow" (optional)
                 - disabled: Whether button is disabled (optional)
        style: Inline CSS styles as a dictionary
        class_name: Tailwind CSS classes
        key: Unique key for the component

    Returns:
        The ID of the clicked button, or None if no click

    Example:
        clicked = button_group(
            buttons=[
                {"id": "view", "icon": "👁️"},
                {"id": "edit", "icon": "✏️"},
                {"id": "approve", "icon": "✓", "color": "green"},
                {"id": "reject", "icon": "✕", "color": "red"}
            ]
        )
        if clicked == "approve":
            approve_item()
    """
    return _component(
        component="button_group",
        buttons=buttons,
        style=style,
        className=class_name,
        key=key,
        default=None,
    )
