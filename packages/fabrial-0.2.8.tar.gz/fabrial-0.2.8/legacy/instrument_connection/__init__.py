from .widgets import InstrumentConnectionWidget
