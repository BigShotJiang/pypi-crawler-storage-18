"""Task type tests."""
