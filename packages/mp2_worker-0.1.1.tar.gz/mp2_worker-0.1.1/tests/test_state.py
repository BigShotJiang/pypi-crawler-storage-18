"""测试原子操作（按 v2 设计文档 STATE.md）"""
import pytest
import json
import time


class TestAtomicBind:
    """测试 bind 原子操作"""
    
    def _create_node(self, r, project_id, node_id):
        key = f'hfs:node:{project_id}:{node_id}'
        r.set(key, json.dumps({
            'id': node_id, 'project': project_id, 'status': 'idle',
            'space': None, 'updated_at': int(time.time())
        }))
    
    def _create_space(self, r, space_id, project_id):
        key = f'hfs:space:{space_id}'
        r.set(key, json.dumps({
            'id': space_id, 'project': project_id, 'status': 'idle',
            'node': None, 'instance_id': None, 'updated_at': int(time.time())
        }))
    
    def test_bind_success(self, r):
        """正常绑定：返回 bound"""
        from hfs.state import atomic_bind
        project_id, node_id, space_id = 'test:p1', 'n1', 'test:s1'
        self._create_node(r, project_id, node_id)
        self._create_space(r, space_id, project_id)
        
        ok, msg = atomic_bind(r, project_id, node_id, space_id, 'inst-001')
        
        assert ok and msg == 'bound'
        node = json.loads(r.get(f'hfs:node:{project_id}:{node_id}'))
        space = json.loads(r.get(f'hfs:space:{space_id}'))
        assert node['space'] == space_id and node['status'] == 'pending'
        assert space['node'] == node_id and space['status'] == 'starting'
        assert space['instance_id'] == 'inst-001'
    
    def test_bind_already_bound(self, r):
        """重复绑定同一 instance：返回 already_bound"""
        from hfs.state import atomic_bind
        project_id, node_id, space_id = 'test:p1', 'n1', 'test:s1'
        self._create_node(r, project_id, node_id)
        self._create_space(r, space_id, project_id)
        
        atomic_bind(r, project_id, node_id, space_id, 'inst-001')
        ok, msg = atomic_bind(r, project_id, node_id, space_id, 'inst-001')
        
        assert ok and msg == 'already_bound'
    
    def test_bind_instance_updated(self, r):
        """新实例绑定已绑定的 pair：返回 instance_updated"""
        from hfs.state import atomic_bind
        project_id, node_id, space_id = 'test:p1', 'n1', 'test:s1'
        self._create_node(r, project_id, node_id)
        self._create_space(r, space_id, project_id)
        
        atomic_bind(r, project_id, node_id, space_id, 'inst-001')
        ok, msg = atomic_bind(r, project_id, node_id, space_id, 'inst-002')
        
        assert ok and msg == 'instance_updated'
        space = json.loads(r.get(f'hfs:space:{space_id}'))
        assert space['instance_id'] == 'inst-002'
    
    def test_bind_space_conflict(self, r):
        """Space 已绑定其他 Node：返回 space_bound_to_other"""
        from hfs.state import atomic_bind
        project_id, space_id = 'test:p1', 'test:s1'
        self._create_node(r, project_id, 'n1')
        self._create_node(r, project_id, 'n2')
        self._create_space(r, space_id, project_id)
        
        atomic_bind(r, project_id, 'n1', space_id, 'inst-001')
        ok, msg = atomic_bind(r, project_id, 'n2', space_id, 'inst-002')
        
        assert not ok and msg == 'space_bound_to_other'
    
    def test_bind_node_takeover(self, r):
        """新 Space 抢占已绑定的 Node（轮换场景）"""
        from hfs.state import atomic_bind
        project_id, node_id = 'test:p1', 'n1'
        self._create_node(r, project_id, node_id)
        self._create_space(r, 'test:s1', project_id)
        self._create_space(r, 'test:s2', project_id)
        
        atomic_bind(r, project_id, node_id, 'test:s1', 'inst-001')
        ok, msg = atomic_bind(r, project_id, node_id, 'test:s2', 'inst-002')
        
        assert ok  # 新 Space 成功抢占
        node = json.loads(r.get(f'hfs:node:{project_id}:{node_id}'))
        assert node['space'] == 'test:s2'


class TestHeartbeat:
    """测试 heartbeat 原子操作"""
    
    def _setup_space(self, r, space_id, instance_id, status='starting'):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': status, 'node': 'n1',
            'instance_id': instance_id, 'last_heartbeat': 0
        }))
    
    def test_heartbeat_success(self, r):
        """正常心跳：更新时间，返回当前状态"""
        from hfs.state import atomic_heartbeat
        self._setup_space(r, 'test:s1', 'inst-001', 'running')
        
        ok, status = atomic_heartbeat(r, 'test:s1', 'inst-001')
        
        assert ok and status == 'running'
        space = json.loads(r.get('hfs:space:test:s1'))
        assert space['last_heartbeat'] > 0
    
    def test_heartbeat_starting_to_running(self, r):
        """starting 状态心跳：自动转为 running"""
        from hfs.state import atomic_heartbeat
        self._setup_space(r, 'test:s1', 'inst-001', 'starting')
        
        ok, status = atomic_heartbeat(r, 'test:s1', 'inst-001')
        
        assert ok and status == 'running'
        space = json.loads(r.get('hfs:space:test:s1'))
        assert space['status'] == 'running'
    
    def test_heartbeat_instance_mismatch(self, r):
        """instance_id 不匹配：返回 instance_mismatch"""
        from hfs.state import atomic_heartbeat
        self._setup_space(r, 'test:s1', 'inst-002', 'running')
        
        ok, msg = atomic_heartbeat(r, 'test:s1', 'inst-001')
        
        assert not ok and msg == 'instance_mismatch'


class TestTransition:
    """测试 transition 原子操作"""
    
    def _setup_space(self, r, space_id, status):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': status, 'updated_at': int(time.time())
        }))
    
    def test_transition_success(self, r):
        """正常转换：running → draining"""
        from hfs.state import atomic_transition
        self._setup_space(r, 'test:s1', 'running')
        
        ok, msg = atomic_transition(r, 'test:s1', 'running', 'draining')
        
        assert ok and msg == 'ok'
        space = json.loads(r.get('hfs:space:test:s1'))
        assert space['status'] == 'draining'
    
    def test_transition_status_mismatch(self, r):
        """状态不匹配：返回 status_mismatch"""
        from hfs.state import atomic_transition
        self._setup_space(r, 'test:s1', 'running')
        
        ok, msg = atomic_transition(r, 'test:s1', 'starting', 'running')
        
        assert not ok and msg == 'status_mismatch'


class TestUnbind:
    """测试 unbind 原子操作"""
    
    def _setup_bound(self, r, project_id, node_id, space_id):
        r.set(f'hfs:node:{project_id}:{node_id}', json.dumps({
            'id': node_id, 'status': 'running', 'space': space_id
        }))
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'running', 'node': node_id
        }))
    
    def test_unbind_success(self, r):
        """正常解绑"""
        from hfs.state import atomic_unbind
        self._setup_bound(r, 'test:p1', 'n1', 'test:s1')
        
        ok, msg = atomic_unbind(r, 'test:p1', 'n1', 'test:s1')
        
        assert ok and msg == 'unbound'
        node = json.loads(r.get('hfs:node:test:p1:n1'))
        space = json.loads(r.get('hfs:space:test:s1'))
        assert node['space'] is None and node['status'] == 'idle'
        assert space['node'] is None
    
    def test_unbind_idempotent(self, r):
        """重复解绑：幂等"""
        from hfs.state import atomic_unbind
        self._setup_bound(r, 'test:p1', 'n1', 'test:s1')
        
        atomic_unbind(r, 'test:p1', 'n1', 'test:s1')
        ok, msg = atomic_unbind(r, 'test:p1', 'n1', 'test:s1')
        
        assert ok  # 幂等，不报错
