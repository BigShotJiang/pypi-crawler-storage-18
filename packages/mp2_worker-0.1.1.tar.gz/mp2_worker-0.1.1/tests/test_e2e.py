"""端到端集成测试"""
import pytest
import json
import time


class TestEndToEnd:
    """端到端测试（使用真实 HF API）"""
    
    def _setup_project_and_node(self, r):
        """初始化 Project 和 Node"""
        project_id = 'test:e2e'
        
        # 创建 Project
        r.set(f'hfs:project:{project_id}', json.dumps({
            'id': project_id,
            'min_nodes': 1,
            'max_nodes': 3,
            'scene': 'default',
            'created_at': int(time.time())
        }))
        
        # 创建 Node
        r.set(f'hfs:node:{project_id}:n1', json.dumps({
            'id': 'n1',
            'project': project_id,
            'status': 'idle',
            'space': '',
            'created_at': 0,
            'updated_at': 0
        }))
        
        return project_id, 'n1'
    
    def _setup_accounts(self, r):
        """初始化账号"""
        accounts = [
            {'username': 'Vivan223', 'token': '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', 
             'status': 'active', 'score': 100, 'last_used': 0},
        ]
        for acc in accounts:
            r.set(f"hfs:account:{acc['username']}", json.dumps(acc))
    
    @pytest.mark.skip(reason="需要真实创建 Space，手动运行")
    def test_full_lifecycle(self, r):
        """完整生命周期：创建 Space → 绑定 → 心跳 → 删除"""
        from hfs.scheduler import Scheduler
        from hfs.hf import delete_space
        
        project_id, node_id = self._setup_project_and_node(r)
        self._setup_accounts(r)
        
        scheduler = Scheduler(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6"
        )
        
        # 1. 创建并绑定 Space
        space_id, instance_id = scheduler.create_and_bind_space(project_id, node_id)
        
        assert space_id is not None
        assert instance_id is not None
        
        print(f"✅ Created and bound: {space_id}")
        
        # 2. 验证绑定
        node = json.loads(r.get(f'hfs:node:{project_id}:{node_id}'))
        assert node['space'] == space_id
        assert node['status'] == 'pending'
        
        space = json.loads(r.get(f'hfs:space:{space_id}'))
        assert space['node'] == node_id
        assert space['status'] == 'starting'
        
        # 3. 清理：删除 Space
        token = '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'
        if delete_space(space_id, token):
            print(f"✅ Deleted: {space_id}")
        else:
            print(f"⚠️ Failed to delete: {space_id}")
