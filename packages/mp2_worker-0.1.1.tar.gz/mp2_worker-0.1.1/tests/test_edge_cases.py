"""边缘异常测试"""
import pytest
import json
import time


class TestInstanceMismatch:
    """测试实例不匹配"""
    
    def _create_space(self, r, space_id, instance_id):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'running',
            'instance_id': instance_id, 'last_heartbeat': int(time.time()),
            'project': 'test:p1', 'node': 'n1',
            'created_at': 0, 'updated_at': 0
        }))
    
    def test_old_worker_detects_replacement(self, r):
        """旧 Worker 检测到被替换"""
        from hfs.worker import Worker
        
        space_id = 'test:edge:s1'
        self._create_space(r, space_id, 'new-instance')  # 新实例
        
        worker = Worker(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6",
            space_id=space_id
        )
        worker.instance_id = 'old-instance'  # 旧实例
        
        ok, msg = worker.send_heartbeat()
        
        assert ok is False
        assert msg == 'instance_mismatch'


class TestHeartbeatTimeout:
    """测试心跳超时"""
    
    def _create_stale_space(self, r, space_id, stale_seconds):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'running',
            'instance_id': 'inst-001',
            'last_heartbeat': int(time.time()) - stale_seconds,
            'project': 'test:p1', 'node': 'n1',
            'created_at': 0, 'updated_at': 0
        }))
    
    def test_detect_stale_space(self, r):
        """检测心跳超时的 Space"""
        from hfs.health import detect_crashed_spaces
        
        self._create_stale_space(r, 'test:edge:stale', 120)  # 2分钟前
        
        crashed = detect_crashed_spaces(r, 'test:p1', heartbeat_timeout=60)
        
        assert len(crashed) >= 1
        assert any(c['space_id'] == 'test:edge:stale' for c in crashed)


class TestConcurrentRotation:
    """测试并发轮换"""
    
    def _setup_node(self, r, project_id, node_id, space_id):
        r.set(f'hfs:node:{project_id}:{node_id}', json.dumps({
            'id': node_id, 'project': project_id,
            'status': 'running', 'space': space_id,
            'created_at': 0, 'updated_at': 0
        }))
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'running',
            'instance_id': 'inst-001', 'node': node_id,
            'last_heartbeat': int(time.time()),
            'project': project_id, 'created_at': 0, 'updated_at': 0
        }))
    
    def test_atomic_bind_prevents_conflict(self, r):
        """原子绑定防止冲突"""
        from hfs.state import atomic_bind
        
        project_id, node_id = 'test:p1', 'n1'
        self._setup_node(r, project_id, node_id, 'test:edge:old')
        
        # 两个 Space 同时尝试绑定同一 Node
        ok1, msg1 = atomic_bind(r, project_id, node_id, 'test:edge:new1', 'inst-new1')
        ok2, msg2 = atomic_bind(r, project_id, node_id, 'test:edge:new2', 'inst-new2')
        
        # 第一个成功，第二个应该失败（Space 已绑定其他 Node）
        assert ok1 is True
        # 第二个可能成功（抢占）或失败（冲突）
        # 关键是不会出现数据不一致


class TestOrphanResources:
    """测试孤儿资源"""
    
    def test_space_without_node(self, r):
        """Space 没有对应的 Node"""
        from hfs.health import validate_consistency
        
        # 创建孤儿 Space
        r.set('hfs:space:test:edge:orphan', json.dumps({
            'id': 'test:edge:orphan', 'status': 'running',
            'instance_id': 'inst-001', 'node': 'non-existent',
            'last_heartbeat': int(time.time()),
            'project': 'test:p1', 'created_at': 0, 'updated_at': 0
        }))
        
        issues = validate_consistency(r, 'test:p1')
        
        # 应该检测到孤儿 Space
        assert len(issues) >= 1


class TestAccountCooldown:
    """测试账号 cooldown"""
    
    def _setup_accounts(self, r):
        # 一个 active，一个 cooldown
        r.set('hfs:account:active_user', json.dumps({
            'username': 'active_user', 'token': 'xxx',
            'status': 'active', 'score': 100, 'last_used': 0
        }))
        r.set('hfs:account:cooldown_user', json.dumps({
            'username': 'cooldown_user', 'token': 'xxx',
            'status': 'cooldown', 'score': 100, 'last_used': 0,
            'cooldown_until': int(time.time()) + 3600
        }))
    
    def test_skip_cooldown_account(self, r):
        """跳过 cooldown 账号"""
        from hfs.account import select_account
        
        self._setup_accounts(r)
        
        account = select_account(r)
        
        assert account is not None
        assert account['username'] == 'active_user'


class TestSpaceStartupTimeout:
    """测试 Space 启动超时"""
    
    def _create_starting_space(self, r, space_id, started_seconds_ago):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'starting',
            'instance_id': 'inst-001', 'node': 'n1',
            'last_heartbeat': int(time.time()) - started_seconds_ago,
            'project': 'test:p1', 'created_at': int(time.time()) - started_seconds_ago,
            'updated_at': int(time.time()) - started_seconds_ago
        }))
    
    def test_detect_startup_timeout(self, r):
        """检测启动超时"""
        from hfs.health import detect_crashed_spaces
        
        # 创建启动超时的 Space（5分钟前开始启动）
        self._create_starting_space(r, 'test:edge:timeout', 300)
        
        crashed = detect_crashed_spaces(r, 'test:p1', startup_timeout=180)
        
        assert len(crashed) >= 1
        assert any(c['space_id'] == 'test:edge:timeout' for c in crashed)
