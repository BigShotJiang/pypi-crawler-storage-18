"""测试 HuggingFace API"""
import pytest


class TestHFSpaceCreation:
    """测试 Space 创建"""
    
    def test_create_space(self):
        """创建 Space（使用真实 API）"""
        from hfs.hf import create_space
        
        space_id = 'test-space-001'
        token = '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'
        
        # 注意：这会创建真实 Space，测试后需要手动删除
        result = create_space(space_id, token, template='fastapi_dummy')
        
        assert result is not None
        assert 'url' in result or 'id' in result


class TestHFSpaceStatus:
    """测试 Space 状态查询"""
    
    def test_get_space_status(self):
        """查询 Space 状态"""
        from hfs.hf import get_space_status
        
        # 使用一个已存在的公开 Space 测试
        status = get_space_status('Vivan223/test-space-001')
        
        # 如果 Space 不存在会返回 None
        assert status is None or isinstance(status, dict)
