"""测试账号管理"""
import pytest
import json
import time


class TestAccountSelection:
    """测试账号选择"""
    
    def _create_accounts(self, r):
        accounts = [
            {'username': 'Vivan223', 'token': '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', 
             'status': 'active', 'score': 100, 'last_used': 0},
            {'username': 'Toni2391', 'token': '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',
             'status': 'active', 'score': 100, 'last_used': 0},
            {'username': 'Joseph2456', 'token': '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',
             'status': 'active', 'score': 100, 'last_used': 0}
        ]
        for acc in accounts:
            r.set(f"hfs:account:{acc['username']}", json.dumps(acc))
    
    def test_select_best_account(self, r):
        """选择最佳账号（最高分且未使用）"""
        from hfs.account import select_account
        
        self._create_accounts(r)
        
        account = select_account(r)
        
        assert account is not None
        assert account['username'] in ['Vivan223', 'Toni2391', 'Joseph2456']
        assert account['status'] == 'active'
    
    def test_select_skip_cooldown(self, r):
        """跳过 cooldown 账号"""
        from hfs.account import select_account
        
        self._create_accounts(r)
        
        # 设置一个账号为 cooldown
        acc = json.loads(r.get('hfs:account:Vivan223'))
        acc['status'] = 'cooldown'
        acc['cooldown_until'] = int(time.time()) + 3600
        r.set('hfs:account:Vivan223', json.dumps(acc))
        
        account = select_account(r)
        
        assert account['username'] != 'Vivan223'


class TestAccountCooldown:
    """测试账号 cooldown"""
    
    def test_mark_cooldown(self, r):
        """标记账号为 cooldown"""
        from hfs.account import mark_cooldown
        
        r.set('hfs:account:test_user', json.dumps({
            'username': 'test_user', 'status': 'active', 'score': 100
        }))
        
        mark_cooldown(r, 'test_user', duration=3600)
        
        acc = json.loads(r.get('hfs:account:test_user'))
        assert acc['status'] == 'cooldown'
        assert acc['cooldown_until'] > time.time()
