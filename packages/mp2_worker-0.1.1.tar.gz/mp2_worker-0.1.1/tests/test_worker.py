"""测试 Worker 核心逻辑"""
import pytest
import json
import time


class TestWorkerRegister:
    """测试 Worker 注册"""
    
    def _create_node(self, r, project_id, node_id):
        r.set(f'hfs:node:{project_id}:{node_id}', json.dumps({
            'id': node_id, 'project': project_id,
            'status': 'idle', 'space': '',
            'created_at': 0, 'updated_at': 0
        }))
    
    def test_register_and_bind(self, r):
        """Worker 注册并绑定 Node"""
        from hfs.worker import Worker
        
        project_id, node_id, space_id = 'test:p1', 'n1', 'test:s1'
        self._create_node(r, project_id, node_id)
        
        # 验证 Node 已创建
        node_key = f'hfs:node:{project_id}:{node_id}'
        print(f'Node key: {node_key}')
        print(f'Node data: {r.get(node_key)}')
        
        worker = Worker(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6",
            space_id=space_id,
            project_id=project_id,
            node_id=node_id
        )
        
        ok = worker.register()
        
        assert ok is True
        # 验证 Space 已创建并绑定
        space = json.loads(r.get(f'hfs:space:{space_id}'))
        assert space['node'] == node_id
        assert space['instance_id'] == worker.instance_id


class TestWorkerHeartbeat:
    """测试 Worker 心跳"""
    
    def _setup_worker_space(self, r, space_id, instance_id):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'starting',
            'instance_id': instance_id, 'last_heartbeat': 0,
            'project': '', 'node': '',
            'created_at': 0, 'updated_at': 0
        }))
    
    def test_heartbeat_updates_time(self, r):
        """心跳更新时间"""
        from hfs.worker import Worker
        
        space_id, instance_id = 'test:s1', 'inst-001'
        self._setup_worker_space(r, space_id, instance_id)
        
        worker = Worker(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6",
            space_id=space_id
        )
        worker.instance_id = instance_id
        
        ok, status = worker.send_heartbeat()
        
        assert ok is True
        space = json.loads(r.get(f'hfs:space:{space_id}'))
        assert space['last_heartbeat'] > 0
    
    def test_heartbeat_detects_replacement(self, r):
        """心跳检测到被替换（instance_mismatch）"""
        from hfs.worker import Worker
        
        space_id = 'test:s1'
        self._setup_worker_space(r, space_id, 'inst-002')  # 新实例
        
        worker = Worker(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6",
            space_id=space_id
        )
        worker.instance_id = 'inst-001'  # 旧实例
        
        ok, msg = worker.send_heartbeat()
        
        assert ok is False
        assert msg == 'instance_mismatch'


class TestWorkerDraining:
    """测试 Worker draining 检测"""
    
    def _setup_draining_space(self, r, space_id, instance_id):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'draining',
            'instance_id': instance_id, 'last_heartbeat': int(time.time()),
            'project': '', 'node': '',
            'created_at': 0, 'updated_at': 0
        }))
    
    def test_detect_draining(self, r):
        """检测到 draining 状态"""
        from hfs.worker import Worker
        
        space_id, instance_id = 'test:s1', 'inst-001'
        self._setup_draining_space(r, space_id, instance_id)
        
        worker = Worker(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6",
            space_id=space_id
        )
        worker.instance_id = instance_id
        
        ok, status = worker.send_heartbeat()
        
        assert ok is True
        assert status == 'draining'
        assert worker.should_exit() is True
