"""测试策略配置"""
import pytest


class TestSceneConfig:
    """测试场景配置"""
    
    def test_get_scene_config(self):
        """获取场景配置"""
        from hfs.policy import get_scene_config
        
        config = get_scene_config('dev_test')
        
        assert config['run_timeout'] == 300
        assert config['heartbeat_interval'] == 10
        assert config['heartbeat_timeout'] == 30
    
    def test_default_scene(self):
        """默认场景 long_task"""
        from hfs.policy import get_scene_config
        
        config = get_scene_config('nonexistent')
        
        assert config['run_timeout'] == 3600  # long_task 默认值
    
    def test_merge_project_config(self):
        """项目配置覆盖场景配置"""
        from hfs.policy import get_project_config
        
        project = {
            'scene': 'dev_test',
            'config': {'run_timeout': 600}
        }
        
        config = get_project_config(project)
        
        assert config['run_timeout'] == 600  # 覆盖
        assert config['heartbeat_interval'] == 10  # 继承场景


class TestSpaceNaming:
    """测试 Space 命名"""
    
    def test_generate_space_name(self):
        """生成自然的 Space 名称"""
        from hfs.policy import generate_space_name
        
        name = generate_space_name()
        
        assert '-' in name
        assert len(name) < 30
        # 不应该有系统前缀
        assert not name.startswith('hfs-')
    
    def test_name_uniqueness(self):
        """生成的名称应该有随机性"""
        from hfs.policy import generate_space_name
        
        names = [generate_space_name() for _ in range(10)]
        
        # 至少有一些不同
        assert len(set(names)) > 5
