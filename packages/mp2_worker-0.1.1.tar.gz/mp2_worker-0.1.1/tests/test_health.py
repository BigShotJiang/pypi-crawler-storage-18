"""测试健康检查（按 v2 设计文档 HEALTH.md）"""
import pytest
import json
import time


class TestDetectCrashed:
    """测试 crashed 检测"""
    
    def _create_space(self, r, space_id, project_id, status, last_hb, node='n1'):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'project': project_id, 'status': status,
            'node': node, 'last_heartbeat': last_hb, 'started_at': last_hb
        }))
    
    def test_detect_running_timeout(self, r):
        """running 状态心跳超时"""
        from hfs.health import detect_crashed_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'running', now - 120)  # 2分钟前
        
        crashed = detect_crashed_spaces(r, 'test:p1', heartbeat_timeout=60)
        
        assert len(crashed) == 1
        assert crashed[0]['space_id'] == 'test:s1'
        assert crashed[0]['reason'] == 'heartbeat_timeout'
    
    def test_detect_starting_timeout(self, r):
        """starting 状态启动超时"""
        from hfs.health import detect_crashed_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'starting', now - 400)  # 6分钟前
        
        crashed = detect_crashed_spaces(r, 'test:p1', startup_timeout=300)
        
        assert len(crashed) == 1
        assert crashed[0]['reason'] == 'heartbeat_timeout'
    
    def test_detect_draining_timeout(self, r):
        """draining 状态超时"""
        from hfs.health import detect_crashed_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'draining', now - 400)
        
        crashed = detect_crashed_spaces(r, 'test:p1', draining_timeout=300)
        
        assert len(crashed) == 1
    
    def test_no_crash_healthy(self, r):
        """健康的 Space 不应被检测"""
        from hfs.health import detect_crashed_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'running', now - 10)  # 10秒前
        
        crashed = detect_crashed_spaces(r, 'test:p1', heartbeat_timeout=60)
        
        assert len(crashed) == 0
    
    def test_skip_exited_failed(self, r):
        """exited/failed 状态不检测"""
        from hfs.health import detect_crashed_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'exited', now - 1000)
        self._create_space(r, 'test:s2', 'test:p1', 'failed', now - 1000)
        
        crashed = detect_crashed_spaces(r, 'test:p1')
        
        assert len(crashed) == 0


class TestValidateConsistency:
    """测试一致性验证"""
    
    def _create_node(self, r, project_id, node_id, space=None):
        r.set(f'hfs:node:{project_id}:{node_id}', json.dumps({
            'id': node_id, 'project': project_id,
            'status': 'running' if space else 'idle', 'space': space
        }))
    
    def _create_space(self, r, space_id, project_id, node=None):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'project': project_id,
            'status': 'running' if node else 'idle', 'node': node
        }))
    
    def test_space_orphan_node_not_found(self, r):
        """Space 指向不存在的 Node"""
        from hfs.health import validate_consistency
        self._create_space(r, 'test:s1', 'test:p1', node='nonexistent')
        
        issues = validate_consistency(r, 'test:p1')
        
        assert len(issues) == 1
        assert issues[0]['type'] == 'space_orphan'
        assert issues[0]['reason'] == 'node_not_found'
    
    def test_node_orphan_space_not_found(self, r):
        """Node 指向不存在的 Space"""
        from hfs.health import validate_consistency
        self._create_node(r, 'test:p1', 'n1', space='nonexistent')
        
        issues = validate_consistency(r, 'test:p1')
        
        assert len(issues) == 1
        assert issues[0]['type'] == 'node_orphan'
        assert issues[0]['reason'] == 'space_not_found'
    
    def test_binding_mismatch(self, r):
        """双向绑定不一致"""
        from hfs.health import validate_consistency
        self._create_node(r, 'test:p1', 'n1', space='test:s2')  # Node 指向 s2
        self._create_space(r, 'test:s1', 'test:p1', node='n1')  # Space 指向 n1
        self._create_space(r, 'test:s2', 'test:p1', node=None)
        
        issues = validate_consistency(r, 'test:p1')
        
        assert any(i['type'] == 'binding_mismatch' for i in issues)
    
    def test_consistent_ok(self, r):
        """一致的绑定无问题"""
        from hfs.health import validate_consistency
        self._create_node(r, 'test:p1', 'n1', space='test:s1')
        self._create_space(r, 'test:s1', 'test:p1', node='n1')
        
        issues = validate_consistency(r, 'test:p1')
        
        assert len(issues) == 0


class TestCleanupSpaces:
    """测试清理"""
    
    def _create_space(self, r, space_id, project_id, status, updated_at):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'project': project_id, 'status': status,
            'mode': 'managed', 'updated_at': updated_at
        }))
    
    def test_cleanup_old_exited(self, r):
        """清理过期的 exited Space"""
        from hfs.health import cleanup_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'exited', now - 7200)  # 2小时前
        
        cleaned = cleanup_spaces(r, 'test:p1', cleanup_age=3600)
        
        assert 'test:s1' in cleaned
        space = json.loads(r.get('hfs:space:test:s1'))
        assert space['status'] == 'unusable'
    
    def test_cleanup_old_failed(self, r):
        """清理过期的 failed Space"""
        from hfs.health import cleanup_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'failed', now - 7200)
        
        cleaned = cleanup_spaces(r, 'test:p1', cleanup_age=3600)
        
        assert 'test:s1' in cleaned
    
    def test_keep_recent(self, r):
        """保留未过期的 Space"""
        from hfs.health import cleanup_spaces
        now = int(time.time())
        self._create_space(r, 'test:s1', 'test:p1', 'exited', now - 100)  # 100秒前
        
        cleaned = cleanup_spaces(r, 'test:p1', cleanup_age=3600)
        
        assert len(cleaned) == 0
