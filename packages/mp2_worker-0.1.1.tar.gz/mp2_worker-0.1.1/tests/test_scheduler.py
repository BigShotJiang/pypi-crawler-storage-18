"""测试 Scheduler 核心逻辑"""
import pytest
import json
import time


class TestSchedulerAllocate:
    """测试 Scheduler 分配 Node"""
    
    def _create_project(self, r, project_id):
        r.set(f'hfs:project:{project_id}', json.dumps({
            'id': project_id, 'min_nodes': 1, 'max_nodes': 3,
            'scene': 'default', 'created_at': 0
        }))
    
    def _create_node(self, r, project_id, node_id, status='idle'):
        r.set(f'hfs:node:{project_id}:{node_id}', json.dumps({
            'id': node_id, 'project': project_id,
            'status': status, 'space': '',
            'created_at': 0, 'updated_at': 0
        }))
    
    def test_allocate_idle_node(self, r):
        """分配空闲 Node"""
        from hfs.scheduler import Scheduler
        
        project_id = 'test:p1'
        self._create_project(r, project_id)
        self._create_node(r, project_id, 'n1', 'idle')
        
        sched = Scheduler(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6"
        )
        
        node_id = sched.allocate_node(project_id)
        
        assert node_id == 'n1'
        node = json.loads(r.get(f'hfs:node:{project_id}:n1'))
        assert node['status'] == 'pending'
    
    def test_allocate_no_idle_node(self, r):
        """无空闲 Node"""
        from hfs.scheduler import Scheduler
        
        project_id = 'test:p1'
        self._create_project(r, project_id)
        self._create_node(r, project_id, 'n1', 'running')
        
        sched = Scheduler(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6"
        )
        
        node_id = sched.allocate_node(project_id)
        
        assert node_id is None


class TestSchedulerRotate:
    """测试 Scheduler 轮换 Node"""
    
    def _create_project(self, r, project_id):
        r.set(f'hfs:project:{project_id}', json.dumps({
            'id': project_id, 'min_nodes': 1, 'max_nodes': 3,
            'scene': 'default', 'created_at': 0
        }))
    
    def _create_node(self, r, project_id, node_id, space_id=''):
        r.set(f'hfs:node:{project_id}:{node_id}', json.dumps({
            'id': node_id, 'project': project_id,
            'status': 'running', 'space': space_id,
            'created_at': 0, 'updated_at': 0
        }))
    
    def _create_space(self, r, space_id, node_id, instance_id):
        r.set(f'hfs:space:{space_id}', json.dumps({
            'id': space_id, 'status': 'running',
            'node': node_id, 'instance_id': instance_id,
            'last_heartbeat': int(time.time()),
            'project': '', 'created_at': 0, 'updated_at': 0
        }))
    
    def test_rotate_node(self, r):
        """轮换 Node"""
        from hfs.scheduler import Scheduler
        
        project_id, node_id, old_space = 'test:p1', 'n1', 'test:s1'
        self._create_project(r, project_id)
        self._create_node(r, project_id, node_id, old_space)
        self._create_space(r, old_space, node_id, 'inst-001')
        
        sched = Scheduler(
            redis_url="redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6"
        )
        
        new_space = sched.rotate_node(project_id, node_id)
        
        assert new_space is not None
        assert new_space != old_space
        
        # 旧 Space 应该进入 draining
        old_space_data = json.loads(r.get(f'hfs:space:{old_space}'))
        assert old_space_data['status'] == 'draining'
