"""HFS Worker 命令行入口"""
import argparse
import os
import random

DEFAULT_REDIS_URL = 'redis://:AVNS_Ix8jMr-b59MU0Y18Hb4@redis-mbook3-macbook3pro.aivencloud.com:11866/6'


def main():
    parser = argparse.ArgumentParser(description='HFS Worker')
    parser.add_argument('--redis-url', default=DEFAULT_REDIS_URL, help='Redis URL')
    parser.add_argument('--space-id', required=True, help='Space ID')
    parser.add_argument('--project-id', help='Project ID (random if not specified for external)')
    parser.add_argument('--external', action='store_true', help='External node')
    parser.add_argument('--timeout', type=int, help='Run timeout in seconds (external only)')
    args = parser.parse_args()
    
    # 设置环境变量（兼容现有代码）
    os.environ['HFS_REDIS_URL'] = args.redis_url
    os.environ['HFS_SPACE_ID'] = args.space_id
    
    import json
    import redis as redis_lib
    from urllib.parse import urlparse
    from .worker import Worker
    
    p = urlparse(args.redis_url)
    db = int(p.path.lstrip('/')) if p.path else 0
    r = redis_lib.Redis(host=p.hostname, port=p.port or 6379, password=p.password, db=db, decode_responses=True)
    space_data = r.get(f'hfs:space:{args.space_id}')
    redis_project_id = json.loads(space_data).get('project_id') if space_data else None
    
    is_new_space = space_data is None
    
    # 新 Space 手动加入必须是 external
    if is_new_space and not args.external:
        print(f"Error: New Space must use --external to avoid disrupting scheduler")
        return
    
    # 确定 project_id
    if args.project_id:
        if redis_project_id and args.project_id != redis_project_id:
            print(f"Error: --project-id={args.project_id} conflicts with Redis ({redis_project_id})")
            return
        project_id = args.project_id
    elif redis_project_id:
        project_id = redis_project_id
    elif args.external:
        # 外部节点不指定项目则随机选一个
        projects = list(r.scan_iter('hfs:project:*'))
        if not projects:
            print("Error: No projects found")
            return
        proj_key = random.choice(projects)
        project_id = proj_key.split(':')[-1]
        print(f"[HFS] Random project: {project_id}")
    else:
        print("Error: --project-id required")
        return
    
    os.environ['HFS_PROJECT_ID'] = project_id
    
    worker = Worker(
        redis_url=args.redis_url,
        space_id=args.space_id,
        project_id=project_id,
        node_id=None,
        external=args.external,
        external_timeout=args.timeout,
    )
    worker.run()


if __name__ == '__main__':
    main()
