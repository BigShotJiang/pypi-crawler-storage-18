"""状态机 + 原子操作（按 v2 设计文档 STATE.md）"""
import time
import json

# Lua: bind - 原子绑定 Node-Space
# 逻辑：Node 可被抢占（轮换），Space 不可被抢占
BIND_SCRIPT = """
local node_key, space_key = KEYS[1], KEYS[2]
local node_id, space_id, instance_id, ts = ARGV[1], ARGV[2], ARGV[3], ARGV[4]

local node = redis.call('GET', node_key)
if not node then return {0, 'node_not_found'} end

local nd = cjson.decode(node)

-- Space 不存在则创建
local space = redis.call('GET', space_key)
local sd
if not space then
    sd = {
        id = space_id,
        status = 'idle',
        instance_id = '',
        project = nd.project or '',
        node = '',
        last_heartbeat = 0,
        created_at = tonumber(ts),
        updated_at = tonumber(ts)
    }
else
    sd = cjson.decode(space)
end

local function is_empty(v)
    return v == nil or v == cjson.null or v == ''
end

-- Space 已绑定其他 Node：拒绝
if not is_empty(sd.node) and sd.node ~= node_id then
    return {-1, 'space_bound_to_other'}
end

-- 已绑定到彼此
if nd.space == space_id and sd.node == node_id then
    if sd.instance_id == instance_id then
        return {1, 'already_bound'}
    else
        -- 新 instance 更新
        sd.instance_id = instance_id
        -- 如果是从 exited/idle/failed 状态复用，重置 started_at
        -- draining 不复用，因为 Worker 正在退出
        if sd.status == 'exited' or sd.status == 'idle' or sd.status == 'failed' then
            sd.started_at = tonumber(ts)
        end
        sd.status = 'starting'
        sd.updated_at = tonumber(ts)
        redis.call('SET', space_key, cjson.encode(sd))
        return {1, 'instance_updated'}
    end
end

-- Node 已绑定其他 Space：抢占（轮换场景）
-- 清空旧 Space 的 instance_id 和 node，使其心跳返回 instance_mismatch
local old_space_id = nd.space
if old_space_id and old_space_id ~= cjson.null and old_space_id ~= '' and old_space_id ~= space_id then
    local old_space_key = 'hfs:space:' .. old_space_id
    local old_space = redis.call('GET', old_space_key)
    if old_space then
        local old_sd = cjson.decode(old_space)
        old_sd.instance_id = ''
        old_sd.node = cjson.null
        old_sd.updated_at = tonumber(ts)
        redis.call('SET', old_space_key, cjson.encode(old_sd))
    end
end

-- 执行绑定
nd.space = space_id
nd.status = 'pending'
nd.updated_at = tonumber(ts)

-- 如果是从 exited/idle/failed 状态复用，重置 started_at
if sd.status == 'exited' or sd.status == 'idle' or sd.status == 'failed' then
    sd.started_at = tonumber(ts)
end

sd.node = node_id
sd.status = 'starting'
sd.instance_id = instance_id
sd.updated_at = tonumber(ts)

redis.call('SET', node_key, cjson.encode(nd))
redis.call('SET', space_key, cjson.encode(sd))
return {1, 'bound'}
"""

# Lua: heartbeat - 原子心跳
# starting 时自动转 running
HEARTBEAT_SCRIPT = """
local space_key = KEYS[1]
local instance_id, ts = ARGV[1], ARGV[2]

local space = redis.call('GET', space_key)
if not space then return {0, 'not_found'} end

local sd = cjson.decode(space)

if sd.instance_id ~= instance_id then
    return {-1, 'instance_mismatch'}
end

sd.last_heartbeat = tonumber(ts)
if sd.status == 'starting' then
    sd.status = 'running'
end

redis.call('SET', space_key, cjson.encode(sd))
return {1, sd.status}
"""

# Lua: transition - 原子状态转换
TRANSITION_SCRIPT = """
local space_key = KEYS[1]
local from_status, to_status, ts = ARGV[1], ARGV[2], ARGV[3]

local space = redis.call('GET', space_key)
if not space then return {0, 'not_found'} end

local sd = cjson.decode(space)

if sd.status ~= from_status then
    return {-1, 'status_mismatch'}
end

sd.status = to_status
sd.updated_at = tonumber(ts)

-- 转换到 exited/failed 时清理 node 绑定
if to_status == 'exited' or to_status == 'failed' then
    sd.node = cjson.null
end

redis.call('SET', space_key, cjson.encode(sd))
return {1, 'ok'}
"""

# Lua: unbind - 原子解绑
UNBIND_SCRIPT = """
local node_key, space_key = KEYS[1], KEYS[2]
local ts = ARGV[1]

local node = redis.call('GET', node_key)
local space = redis.call('GET', space_key)

if node then
    local nd = cjson.decode(node)
    nd.space = cjson.null
    nd.status = 'idle'
    nd.updated_at = tonumber(ts)
    redis.call('SET', node_key, cjson.encode(nd))
end

if space then
    local sd = cjson.decode(space)
    sd.node = cjson.null
    sd.updated_at = tonumber(ts)
    redis.call('SET', space_key, cjson.encode(sd))
end

return {1, 'unbound'}
"""


def atomic_bind(r, project_id, node_id, space_id, instance_id):
    """原子绑定 Node-Space"""
    from . import audit
    
    # 记录 bind 前状态
    old_space = r.get(f'hfs:space:{space_id}')
    old_instance = None
    if old_space:
        import json
        old_instance = json.loads(old_space).get('instance_id')
    
    script = r.register_script(BIND_SCRIPT)
    result = script(
        keys=[f'hfs:node:{project_id}:{node_id}', f'hfs:space:{space_id}'],
        args=[node_id, space_id, instance_id, int(time.time())]
    )
    
    # 审计日志
    audit.log(r, space_id, 'bind', f'worker/{instance_id}',
              node=node_id, old_instance=old_instance, 
              new_instance=instance_id, result=result[1])
    
    return result[0] > 0, result[1]


def atomic_heartbeat(r, space_id, instance_id):
    """原子心跳"""
    from . import audit
    
    script = r.register_script(HEARTBEAT_SCRIPT)
    result = script(
        keys=[f'hfs:space:{space_id}'],
        args=[instance_id, int(time.time())]
    )
    
    # 审计日志（只记录异常情况，避免日志过多）
    if result[0] <= 0 or result[1] in ('instance_mismatch', 'draining'):
        audit.log(r, space_id, 'heartbeat', f'worker/{instance_id}',
                  ok=result[0] > 0, result=result[1])
    
    return result[0] > 0, result[1]


def atomic_transition(r, space_id, from_status, to_status):
    """原子状态转换"""
    from . import audit
    
    script = r.register_script(TRANSITION_SCRIPT)
    result = script(
        keys=[f'hfs:space:{space_id}'],
        args=[from_status, to_status, int(time.time())]
    )
    
    # 审计日志
    audit.log(r, space_id, 'transition', 'scheduler',
              from_status=from_status, to_status=to_status, result=result[1])
    
    return result[0] > 0, result[1]


def atomic_unbind(r, project_id, node_id, space_id):
    """原子解绑"""
    from . import audit
    
    script = r.register_script(UNBIND_SCRIPT)
    result = script(
        keys=[f'hfs:node:{project_id}:{node_id}', f'hfs:space:{space_id}'],
        args=[int(time.time())]
    )
    
    # 审计日志
    audit.log(r, space_id, 'unbind', 'scheduler', node=node_id, result=result[1])
    
    return result[0] > 0, result[1]
