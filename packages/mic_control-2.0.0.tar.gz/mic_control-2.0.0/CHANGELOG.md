# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.0.0] - 2025-12-21

### Added

- **Global CLI Installation via pipx/pip**

  - Published to PyPI as `mic-control`
  - Package is now installable globally with `pipx install mic-control`

- **Rich Terminal Output with ChalkBox**

  - Startup banner panel showing all current settings
  - Animated spinner during call detection
  - Colored status messages (green for in-call, dim for idle)
  - Alert panels for volume adjustments and errors

- **New CLI Flags**

  - `--verbose` / `-v`: Enable debug output showing call detection timestamps
  - `--version`: Display current version

- **macOS Environment Validation**

  - Validates running on macOS (`sys.platform == "darwin"`) at startup
  - Checks `osascript` availability in PATH
  - Exits gracefully with clear error message if requirements not met

- **PEP 561 Typed Package**

  - Added `py.typed` marker for type checker support

### Changed

- **Package Renamed**: From `py-macos-mic-control` to `mic-control`

  - Shorter name matching the CLI command

- **Linting Toolchain**: Switched from black/isort/flake8 to Ruff

  - Single tool for linting and formatting
  - Configured for line length 120, Python 3.12 target

- **CI/CD Workflows**

  - Tests now run on `macos-latest` (required for sounddevice/PortAudio)
  - Linting remains on `ubuntu-latest` for speed
  - Added `mdformat` for Markdown file formatting
  - Separate test-release and production release workflows

- **Logging**: Integrated ChalkBox logging bridge

  - Verbose mode uses DEBUG level
  - Non-verbose mode uses ERROR level only

### Fixed

- **Shutdown Escape Sequence**

  - Fixed broken character appearing before final shutdown message
  - Added carriage return to clear partial spinner escape codes when interrupted

## [1.5.0] - 2025-08-23

### Changed

- Improve call detection performance
- Improve graceful shutdown of the app

### Fixed

- Timing issue with delay and interval calculation causing offsets
- Ungraceful shutdown when exiting while call detection is active

## [1.0.0] - 2024-10-24

### Added

- Automatic microphone volume control for macOS calls and meetings.

### Key Features

- Automatic call detection
- Takes and analyzes audio samples
- Monitors the mic from the background
- Native macOS integration
- Low resource usage
- Configurable via cli arguments

### Requirements

- macOS (tested on 10.15 and 15.6)
- Python 3.12+
- Poetry
