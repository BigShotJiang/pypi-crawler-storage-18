# mic-control

[![Python](https://img.shields.io/badge/Python-3.12%2B-blue?logo=python&logoColor=white)](https://www.python.org/)
[![PyPI version](https://badge.fury.io/py/mic-control.svg)](https://pypi.org/project/mic-control/)
[![Poetry](https://img.shields.io/badge/Poetry-Dependency%20Manager-60A5FA?logo=poetry&logoColor=white)](https://python-poetry.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Ruff](https://img.shields.io/badge/Code%20Style-Ruff-FCC21B?logo=ruff&logoColor=black)](https://github.com/astral-sh/ruff)
[![Type Checked](https://img.shields.io/badge/Type%20Checker-mypy-blue.svg)](https://mypy-lang.org/)
[![Tests](https://img.shields.io/badge/Tests-pytest-0A9EDC.svg)](https://pytest.org/)

Automatic microphone volume control for macOS calls and meetings.

## What It Does

- Monitors and maintains mic input level during calls
- Automatic call detection via audio sampling
- Rich terminal output with live status
- Low resource usage, runs in background
- Native macOS integration via osascript

## Quick Start

### Install mic-control

Install with `pipx` (recommended):

```bash
pipx install mic-control
```

Or with pip in a virtual environment:

```bash
pip install mic-control
```

> **Tip:** `pipx` is recommended for global CLI tools as it provides isolated environments.

Or with Poetry (for development):

```bash
git clone https://github.com/bulletinmybeard/mic-control.git
cd mic-control
poetry install
```

### Run mic-control

```bash
# Start with default settings
mic-control

# Custom target volume
mic-control --target-volume 70

# Verbose debug output
mic-control --verbose

# Run in background
mic-control &
```

## CLI Commands

| Command | Description |
| ---------------------------------- | ---------------------------------------- |
| `mic-control` | Start with default settings (80% volume) |
| `mic-control --target-volume 70` | Set custom target volume (0-100) |
| `mic-control --active-interval 5` | Seconds between checks during calls |
| `mic-control --idle-interval 15` | Seconds between checks when idle |
| `mic-control --call-interval 30` | Seconds between call detection |
| `mic-control --log-path PATH` | Custom log file location |
| `mic-control --verbose` | Enable debug output |
| `mic-control --version` | Show version |

## Example Output

```
╭──────────────────────────────────────────╮
│        mic-control v1.5.0                │
│                                          │
│  Target Volume: 80                       │
│  Active Interval: 5s                     │
│  Idle Interval: 15s                      │
│  Call Interval: 30s                      │
│  Log Path: mic_control.log               │
╰──────────────────────────────────────────╯

⠋ Detecting call activity...
-> Not in call (detection took 5.2s)

⠋ Detecting call activity...
-> In call (detection took 5.1s)
ℹ Adjusting volume: 50 -> 80

^C
Shutting down gracefully...
Microphone controller stopped
```

## Requirements

- macOS 10.0+
- Python 3.12+

## Troubleshooting

### If the script can't access your mic

- Check the mic permissions in your `System Preferences`
- Make sure no other app or script is exclusively using the mic

### If volume adjustments don't work

- Verify you have permission to run `osascript`

### For logging issues

- Ensure the log file location has the correct write permissions
- Check available disk space

## Links

- [Changelog](https://github.com/bulletinmybeard/py-macos-mic-control/blob/master/CHANGELOG.md)

## License

MIT License - see the [LICENSE](https://github.com/bulletinmybeard/py-macos-mic-control/blob/master/LICENSE) file for details.
