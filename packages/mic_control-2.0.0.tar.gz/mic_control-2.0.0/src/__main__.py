import argparse
import logging
import shutil
import signal
import subprocess  # nosec B404
import sys
import time
from importlib.metadata import version
from types import FrameType

import numpy as np
import sounddevice as sd  # type: ignore[import-untyped]
from chalkbox.components.alert import Alert
from chalkbox.components.spinner import Spinner
from chalkbox.core.console import get_console
from chalkbox.logging.bridge import get_logger, setup_logging
from rich.panel import Panel

from src.utils import get_default_log_path, validate_log_path

console = get_console()
logger = get_logger(__name__)
file_logger = logging.getLogger("mic_control")


def check_macos_requirements() -> None:
    """Verify running on macOS with osascript available."""
    if sys.platform != "darwin":
        console.print(Alert.error("This tool only runs on macOS"))
        sys.exit(1)

    if shutil.which("osascript") is None:
        console.print(Alert.error("osascript not found in PATH"))
        sys.exit(1)


def set_mic_volume(volume: int) -> bool:
    """Set the mic input volume (0-100)."""
    try:
        cmd = ["osascript", "-e", f"set volume input volume {volume}"]
        subprocess.run(cmd, check=True)  # nosec B603
        return True
    except subprocess.CalledProcessError as e:
        logger.error("Failed to set volume: %s", e)
        return False


def get_mic_volume() -> int | None:
    """Get current mic input volume."""
    try:
        cmd = ["osascript", "-e", "input volume of (get volume settings)"]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)  # nosec B603
        return int(result.stdout.strip())
    except subprocess.CalledProcessError as e:
        logger.error("Failed to get volume: %s", e)
        return None


def is_audio_active(threshold: float = 0.01, duration: float = 1.0) -> bool:
    """Check if there is audio activity."""
    try:
        device_info = sd.query_devices(kind="input")
        sample_rate = int(device_info["default_samplerate"])

        recording = sd.rec(
            int(duration * sample_rate),
            channels=1,
            dtype="float32",
            samplerate=sample_rate,
        )
        sd.wait()

        rms = np.sqrt(np.mean(recording**2))
        return bool(rms > threshold)

    except Exception as e:
        logger.error("Error detecting audio: %s", e)
        return False


def detect_call_activity(audio_check_duration: int = 5) -> bool:
    """Detect if we are likely in a call by monitoring audio activity over time."""
    audio_samples = []

    for _ in range(audio_check_duration):
        audio_samples.append(is_audio_active())
        time.sleep(1)

    # If we detect audio activity in at least 40% of samples, we are most likely in a call
    return bool(sum(audio_samples) / len(audio_samples) >= 0.4)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Automatic microphone volume control for macOS calls and meetings")
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {version('mic-control')}",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable verbose debug output",
    )
    parser.add_argument(
        "--target-volume",
        type=int,
        default=80,
        help="Target microphone volume level (0-100)",
        choices=range(0, 101),
        metavar="VOLUME",
    )
    parser.add_argument(
        "--active-interval",
        type=int,
        default=5,
        help="Seconds between checks during calls (default: 5)",
        metavar="SECONDS",
    )
    parser.add_argument(
        "--idle-interval",
        type=int,
        default=15,
        help="Seconds between checks when idle (default: 15)",
        metavar="SECONDS",
    )
    parser.add_argument(
        "--call-interval",
        type=int,
        default=30,
        help="Seconds between call detection checks (default: 30)",
        metavar="SECONDS",
    )
    parser.add_argument(
        "--log-path",
        type=str,
        default=None,
        help=f"Path to the log file (default: {get_default_log_path()})",
        metavar="PATH",
    )
    return parser.parse_args()


running = True


def signal_handler(signum: int, _: FrameType | None) -> None:
    """Handle shutdown signals gracefully."""
    global running
    console.print("\n[yellow]Received signal, shutting down gracefully...[/yellow]")
    running = False


def main() -> None:
    check_macos_requirements()

    global running  # noqa: F824

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    args = parse_args()

    level = "DEBUG" if args.verbose else "ERROR"
    setup_logging(
        level=level,
        show_time=False,
        show_path=False,
        show_level=False,
        rich_tracebacks=False,
    )

    log_path_str = args.log_path if args.log_path else str(get_default_log_path())
    try:
        log_path = validate_log_path(log_path_str)
    except SystemExit as e:
        console.print(Alert.error(str(e)))
        sys.exit(1)

    file_handler = logging.FileHandler(log_path)
    file_handler.setLevel(logging.DEBUG if args.verbose else logging.INFO)
    file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)

    file_logger.info("mic-control started with target volume %d", args.target_volume)

    settings_text = (
        f"[cyan]Target Volume:[/cyan] {args.target_volume}\n"
        f"[cyan]Active Interval:[/cyan] {args.active_interval}s\n"
        f"[cyan]Idle Interval:[/cyan] {args.idle_interval}s\n"
        f"[cyan]Call Interval:[/cyan] {args.call_interval}s\n"
        f"[cyan]Log Path:[/cyan] {log_path}"
    )
    console.print(
        Panel(
            settings_text,
            title=f"[bold cyan]mic-control v{version('mic-control')}[/bold cyan]",
            border_style="cyan",
        )
    )
    console.print()

    next_call_check = 0.0
    in_call = False

    try:
        while running:
            current_time = time.time()

            if current_time >= next_call_check:
                next_call_check = current_time + args.call_interval

                logger.debug("Starting call detection at %s", time.strftime("%H:%M:%S", time.localtime(current_time)))

                detection_start = time.time()
                with Spinner("Detecting call activity..."):
                    in_call = detect_call_activity()
                detection_duration = time.time() - detection_start

                if in_call:
                    console.print(f"[green]-> In call[/green] [dim](detection took {detection_duration:.1f}s)[/dim]")
                    file_logger.info("Call detected (detection took %.1fs)", detection_duration)
                else:
                    console.print(f"[dim]-> Not in call (detection took {detection_duration:.1f}s)[/dim]")
                    file_logger.info("No call detected (detection took %.1fs)", detection_duration)

            if in_call:
                current_volume = get_mic_volume()

                if current_volume is not None and current_volume != args.target_volume:
                    console.print(Alert.info(f"Adjusting volume: {current_volume} -> {args.target_volume}"))
                    file_logger.info("Adjusting volume: %d -> %d", current_volume, args.target_volume)
                    set_mic_volume(args.target_volume)

            time_until_next_check = next_call_check - time.time()

            if in_call:
                sleep_duration = min(args.active_interval, max(0.1, time_until_next_check))
            else:
                sleep_duration = min(args.idle_interval, max(0.1, time_until_next_check))

            if sleep_duration > 0:
                time.sleep(sleep_duration)

    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
    except Exception as e:
        console.print(Alert.error(f"Fatal error: {e}"))
        logger.exception("Fatal error: %s", e)
        sys.exit(1)
    finally:
        console.print("\r[dim]Microphone controller stopped[/dim]")


if __name__ == "__main__":
    main()
