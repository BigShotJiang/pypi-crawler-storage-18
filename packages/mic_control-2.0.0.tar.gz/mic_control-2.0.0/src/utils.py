import os
import sys
from pathlib import Path

from chalkbox.logging.bridge import get_logger

logger = get_logger(__name__)

DEFAULT_LOG_DIR = Path.home() / ".mic-control"
DEFAULT_LOG_FILE = "mic_control.log"


def get_default_log_path() -> Path:
    """Get the default log path in user's home directory."""
    return DEFAULT_LOG_DIR / DEFAULT_LOG_FILE


def validate_log_path(full_log_path: str) -> Path:
    """Validate the log file path."""
    try:
        log_path = Path(full_log_path).resolve()
        if not log_path.parent.exists():
            try:
                log_path.parent.mkdir(parents=True, exist_ok=True)
            except PermissionError:
                sys.exit(f"Error: No permission to create directory: {log_path.parent}")
            except OSError as e:
                sys.exit(f"Error: Could not create directory {log_path.parent}: {e}")

        if not log_path.parent.is_dir():
            sys.exit(f"Error: {log_path.parent} exists but is not a directory")

        if not os.access(log_path.parent, os.R_OK | os.W_OK | os.X_OK):
            sys.exit(f"Error: Insufficient permissions for directory: {log_path.parent}")

        if log_path.exists():
            if not log_path.is_file():
                sys.exit(f"Error: {log_path} exists but is not a regular file")
            if not os.access(log_path, os.W_OK):
                sys.exit(f"Error: No write permission for existing log file: {log_path}")
        else:
            try:
                with open(log_path, "a"):
                    pass
                log_path.unlink()
            except PermissionError:
                sys.exit(f"Error: No permission to create log file: {log_path}")
            except OSError as e:
                sys.exit(f"Error: Could not create log file {log_path}: {e}")

        return log_path

    except Exception as e:
        sys.exit(f"Error: Invalid log path {full_log_path}: {e}")
