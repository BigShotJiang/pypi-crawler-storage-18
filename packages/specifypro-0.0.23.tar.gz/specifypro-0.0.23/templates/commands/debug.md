---
description: Advanced debugging assistance with AI-powered error detection, log analysis, and performance profiling.
handoffs:
  - label: Run Tests
    agent: spp.test
    prompt: Run tests to verify the debugging suggestions
    send: true
  - label: Apply Fixes
    agent: spp.refactor
    prompt: Apply suggested code improvements
    send: true
scripts:
  sh: scripts/bash/debug-assist.sh --json "{ARGS}"
  ps: scripts/powershell/debug-assist.ps1 -Json "{ARGS}"
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

1. **Analyze current project state**: Identify the current debugging context, error messages, or problematic code sections.

2. **Scan for common issues**: Check for typical bugs, performance bottlenecks, memory leaks, and logical errors.

3. **Review logs and stack traces**: Parse and analyze any provided logs, error messages, or stack traces for insights.

4. **Suggest fixes**: Provide specific, actionable debugging suggestions with code examples.

5. **Performance profiling**: If applicable, identify performance bottlenecks and optimization opportunities.

6. **Generate debugging plan**: Create a structured debugging approach with steps to isolate and fix the issue.

## Detailed Steps

### Step 1: Error Analysis

- Parse error messages and stack traces
- Identify the type of error (syntax, runtime, logical, performance)
- Locate the problematic code sections
- Determine the scope of the issue

### Step 2: Context Gathering

- Analyze the surrounding code context
- Check variable values and data flow
- Identify potential root causes
- Review recent changes that might have introduced the issue

### Step 3: Intelligent Suggestions

- Provide specific code fixes with examples
- Suggest debugging tools or techniques to use
- Recommend testing strategies to validate fixes
- Offer preventive measures to avoid similar issues

### Step 4: Performance Analysis

- Identify performance bottlenecks if applicable
- Suggest optimization strategies
- Recommend profiling tools
- Provide code refactoring suggestions for better performance

### Step 5: Debugging Strategy

- Create a step-by-step debugging plan
- Suggest breakpoints and watch variables
- Recommend logging strategies
- Provide testing scenarios to validate fixes

## Debugging Categories

### Common Error Types

- Syntax errors
- Runtime errors
- Logical errors
- Performance issues
- Memory leaks
- Concurrency problems
- Integration issues

### Debugging Techniques

- Print debugging
- Interactive debugging
- Log analysis
- Performance profiling
- Memory analysis
- Network analysis
- Database query analysis

## Output Format

Provide debugging assistance in this structure:

1. **Issue Summary**: Clear description of the problem
2. **Root Cause Analysis**: Explanation of why the issue occurs
3. **Suggested Fixes**: Specific code changes with examples
4. **Debugging Steps**: Actionable steps to isolate and fix
5. **Prevention**: How to avoid similar issues in the future
6. **Tools**: Recommended debugging tools and techniques

## Guidelines

- Be specific with code examples and line numbers when possible
- Prioritize fixes based on impact and ease of implementation
- Consider the project's architecture and coding standards
- Provide both immediate fixes and long-term solutions
- Include relevant debugging tools and commands
- Suggest testing strategies to validate fixes
- Explain the reasoning behind each suggestion
