---
description: Generate or update README.md file based on project code, structure, and documentation.
handoffs:
  - label: Review Documentation
    agent: spp.checklist
    prompt: Review the generated README for completeness and accuracy
    send: true
scripts:
  sh: scripts/bash/generate-readme.sh --json "{ARGS}"
  ps: scripts/powershell/generate-readme.ps1 -Json "{ARGS}"
---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Outline

1. **Analyze project structure**: Identify the main directories, files, and their purposes in the current project.

2. **Scan source code**: Review the main source files to understand the project's functionality, dependencies, and architecture.

3. **Review existing documentation**: Check for any existing documentation, comments, or specifications that should be included.

4. **Generate README content**: Create a comprehensive README.md file that includes:
   - Project title and description
   - Table of contents (if applicable)
   - Features and functionality
   - Installation instructions
   - Usage examples
   - Project structure explanation
   - Technologies used
   - Contributing guidelines
   - License information
   - Additional notes or acknowledgments

5. **Create/update README.md**: Write the generated content to the README.md file in the project root, either creating a new one or updating an existing one while preserving important custom content.

6. **Validate structure**: Ensure the README follows proper markdown formatting and includes all necessary sections for a complete project documentation.

## Detailed Steps

### Step 1: Project Analysis

- List all top-level directories and their purposes
- Identify main source code files and their functions
- Note configuration files and their roles
- Document any special setup requirements

### Step 2: Code Review

- Analyze main entry points and core functionality
- Identify key dependencies and frameworks used
- Extract important configuration settings
- Note any special environment variables or setup steps

### Step 3: Content Generation

- Create a compelling title and description based on the project's purpose
- Generate installation instructions specific to the project type
- Provide usage examples based on the actual code functionality
- Document the project structure with explanations
- List technologies, frameworks, and tools used
- Include contribution guidelines appropriate for the project

### Step 4: README Structure

Follow this recommended structure:

```markdown
# Project Title

[Project description]

## Table of Contents
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Project Structure](#project-structure)
- [Technologies](#technologies)
- [Contributing](#contributing)
- [License](#license)

## Features
[Description of key features]

## Installation
[Installation instructions]

## Usage
[Usage examples and instructions]

## Project Structure
[Explanation of directory structure]

## Technologies
[List of technologies used]

## Contributing
[Contribution guidelines]

## License
[License information]
```

## Guidelines

- Make the README informative but concise
- Include practical examples that users can actually try
- Document any prerequisites or dependencies clearly
- Use proper markdown formatting and syntax
- Ensure all code examples are valid and well-formatted
- Consider the target audience when writing (developers, users, etc.)
- Preserve any custom sections if updating an existing README
- Include links to relevant documentation if available
