import numpy
from Cython.Build import cythonize
from setuptools import Extension, find_packages, setup

setup(
    name="cpdb-protein",
    version="0.2.1",
    license="MIT",
    license_files=["LICENSE"],
    author="Arian Jamasb",
    author_email="arian@jamasb.io",
    url="https://github.com/a-r-j/cpdb",
    ext_modules=cythonize(
        ["cpdb/parser.pyx"], compiler_directives={"language_level": "3"}
    ),
    include_dirs=[numpy.get_include()],
    setup_requires=["numpy", "cython"],
    install_requires=["numpy", "pandas", "cython"],
    packages=find_packages(),
)
