"""MusicXML to PNG converter library."""

__version__ = "0.1.0"

from musicxml_to_png.converter import convert_musicxml_to_png

__all__ = ["convert_musicxml_to_png"]

