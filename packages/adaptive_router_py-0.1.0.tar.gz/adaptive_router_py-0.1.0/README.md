# Adaptive Router Python SDK

OpenAI-compatible Python client for Adaptive with typed helpers for routing
and registry endpoints.

## Installation

```bash
uv add adaptive-router-py
```

```bash
poetry add adaptive-router-py
```

```bash
pip install adaptive-router-py
```

## Authentication

Set your API key in the environment:

```bash
export ADAPTIVE_API_KEY="your-api-key"
```

## Sync Usage

```python
from adaptive_router_py import (
    Adaptive,
    RegistryModelsQuery,
    RegistryProvidersQuery,
    SelectModelRequest,
)

adaptive = Adaptive()

response = adaptive.chat.completions.create(
    model="adaptive/auto",
    messages=[{"role": "user", "content": "Hello from Adaptive"}],
)

selection = adaptive.router.select_model(
    SelectModelRequest(prompt="Pick a model", cost_bias=0.4)
)

models = adaptive.registry.models(RegistryModelsQuery(endpoint_tag="chat_completions"))
providers = adaptive.registry.providers(RegistryProvidersQuery(tag="anthropic"))
```

## Async Usage

```python
import asyncio

from adaptive_router_py import AsyncAdaptive, SelectModelRequest


async def main() -> None:
    adaptive = AsyncAdaptive()
    response = await adaptive.chat.completions.create(
        model="adaptive/auto",
        messages=[{"role": "user", "content": "Hello from Adaptive"}],
    )
    selection = await adaptive.router.select_model(SelectModelRequest(prompt="Pick a model"))
    await adaptive.aclose()


asyncio.run(main())
```

## Development

Format:

```bash
uv run ruff format
```

Lint:

```bash
uv run ruff check .
```

Type check:

```bash
uv run ty check
```

Tests:

```bash
uv run pytest
```

## Versioning

Use `uv version` to bump versions:

```bash
uv version --bump patch
```
