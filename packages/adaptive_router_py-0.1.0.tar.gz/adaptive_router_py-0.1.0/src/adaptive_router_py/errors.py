class AdaptiveError(RuntimeError):
    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        payload: dict | list | str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload
