# secsummarize

[![PyPI version](https://badge.fury.io/py/secsummarize.svg)](https://pypi.org/project/secsummarize/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/personalized-badge/secsummarize?period=total&units=international_system&left_color=grey&right_color=orange&left_text=Downloads)](https://pepy.tech/project/secsummarize)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=flat&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/eugene-evstafev/)

A Python package for generating structured summaries of security-related topics from user-provided text.

## Features

- Extracts key insights, vulnerabilities, and recommendations from security-related text.
- Supports custom LLM instances for flexible integration.
- Uses ChatLLM7 by default (from [langchain_llm7](https://pypi.org/project/langchain-llm7/)).
- Free tier rate limits are sufficient for most use cases.

## Installation

```bash
pip install secsummarize
```

## Usage

### Basic Usage

```python
from secsummarize import secsummarize

user_input = "Your security-related text here."
response = secsummarize(user_input)
print(response)
```

### Using a Custom LLM

#### OpenAI

```python
from langchain_openai import ChatOpenAI
from secsummarize import secsummarize

llm = ChatOpenAI()
response = secsummarize(user_input, llm=llm)
print(response)
```

#### Anthropic

```python
from langchain_anthropic import ChatAnthropic
from secsummarize import secsummarize

llm = ChatAnthropic()
response = secsummarize(user_input, llm=llm)
print(response)
```

#### Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from secsummarize import secsummarize

llm = ChatGoogleGenerativeAI()
response = secsummarize(user_input, llm=llm)
print(response)
```

### Using an API Key

```python
from secsummarize import secsummarize

user_input = "Your security-related text here."
api_key = "your_api_key_here"
response = secsummarize(user_input, api_key=api_key)
print(response)
```

## Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default ChatLLM7 will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the environment variable `LLM7_API_KEY` will be used.

## Getting an API Key

You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/secsummarize/issues).

## Author

- **Eugene Evstafev** - [LinkedIn](https://www.linkedin.com/in/eugene-evstafev/)
- Email: hi@eugene.plus

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.