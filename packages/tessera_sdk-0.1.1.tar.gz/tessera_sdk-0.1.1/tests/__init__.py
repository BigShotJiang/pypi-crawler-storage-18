"""Tests for Tessera SDK."""
