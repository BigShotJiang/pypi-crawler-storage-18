# lifelogger‑ai
[![PyPI version](https://badge.fury.io/py/lifelogger-ai.svg)](https://badge.fury.io/py/lifelogger-ai)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/lifelogger-ai)](https://pepy.tech/project/lifelogger-ai)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


A lightweight Python package for turning raw life‑journal entries into structured summaries.  
**lifelogger‑ai** takes a block of text describing a moment, event or thought, sends it to an LLM, and extracts a concise summary that includes context, emotions, and key points. The output can be used for personal journaling, social‑media sharing or building collections of meaningful life moments.

---

## Installation

```bash
pip install lifelogger_ai
```

---

## Quick Start

```python
from lifelogger_ai import lifelogger_ai

# Text you want to process
user_input = """
I spent the afternoon hiking up Blue Ridge Mountain, feeling a mix of triumph and exhaustion.
The wind was blowing strong and the view from the summit was breathtaking. I took a photo of a golden sunrise over the valley.
"""

# Run the lifestream summarization
summary = lifelogger_ai(user_input)

print(summary)
# ['Summarised sentences here...']
```

The function returns a list of strings – one or more sentences that capture the essence of the input.

---

## Parameters

| Name      | Type                | Description                                                                                                                                   |
|-----------|---------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|
| `user_input` | `str` | The raw text describing a personal moment, event or thought.                                                                                 |
| `llm`      | `Optional[BaseChatModel]` | A LangChain language‑model instance to use for processing. If omitted, the default **ChatLLM7** from `langchain_llm7` is used.               |
| `api_key`  | `Optional[str]`    | The API key for LLM7. If omitted, the package first looks for the `LLM7_API_KEY` environment variable; otherwise a free‑tier key is used.     |

---

## Using Your Own LLM

`lifelogger-ai` is LLM‑agnostic. Pass any LangChain model that implements `BaseChatModel` to the function:

```python
# Example 1 – OpenAI
from langchain_openai import ChatOpenAI
from lifelogger_ai import lifelogger_ai

llm = ChatOpenAI(model="gpt-4o-mini")
response = lifelogger_ai("Your text here", llm=llm)
```

```python
# Example 2 – Anthropic
from langchain_anthropic import ChatAnthropic
from lifelogger_ai import lifelogger_ai

llm = ChatAnthropic()
response = lifelogger_ai("Your text here", llm=llm)
```

```python
# Example 3 – Google Gemini
from langchain_google_genai import ChatGoogleGenerativeAI
from lifelogger_ai import lifelogger_ai

llm = ChatGoogleGenerativeAI()
response = lifelogger_ai("Your text here", llm=llm)
```

---

## Rate Limits & API Key for LLM7

The free tier of LLM7 offers rate limits that generally suffice for typical usage.  
If you need higher limits:

* **Environment variable**: `export LLM7_API_KEY=your_key_here`
* **Explicit argument**: `lifelogger_ai(user_input, api_key="your_key_here")`

Get a free key at <https://token.llm7.io/>

---

## Contributing & Issues

Feel free to open issues or submit pull requests on GitHub: <https://github.com/chigwell/lifelogger-ai>

---

## Author

Eugene Evstafev  
Email: hi@euegne.plus  
GitHub: **chigwell**

---