#!/usr/bin/env python


# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025, Maciej Barć <xgqt@xgqt.org>


import json
import platform
import socket

from datetime import datetime


class Stamper:

    @staticmethod
    def write_stamp(file_path_str: str) -> None:
        now = datetime.now().isoformat()
        host = socket.gethostname()

        json_data = {
            "datetime": now,
            "host": host,
            "arch": platform.machine(),
            "os": platform.system().lower(),
            "python": platform.python_version(),
        }

        json_string = json.dumps(obj=json_data, separators=(",", ":"))

        with open(file_path_str, mode="w") as opened_file:
            opened_file.write(json_string)
