#!/usr/bin/env python


# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2025, Maciej Barć <xgqt@xgqt.org>


"""
App runner.
"""


from pathlib import Path

from ..Builder.CliBuilder import CliBuilder
from ..Stamper.Stamper import Stamper


class AppRunner:

    def __init__(self) -> None:
        self._args = CliBuilder().add_arguments().parse().get_args()

    def run(self) -> None:
        file_path = Path(self._args.output_stamp_file_path)
        file_path_str = str(file_path.absolute())

        file_path.parent.mkdir(parents=True, exist_ok=True)
        Stamper.write_stamp(file_path_str=file_path_str)
