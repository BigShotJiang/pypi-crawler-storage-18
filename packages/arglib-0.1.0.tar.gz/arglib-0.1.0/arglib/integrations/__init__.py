"""Integration adapters."""
