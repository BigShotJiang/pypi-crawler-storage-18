"""Data assets."""
