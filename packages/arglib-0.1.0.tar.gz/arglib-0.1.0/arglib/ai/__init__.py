"""AI-assisted mining tools."""
