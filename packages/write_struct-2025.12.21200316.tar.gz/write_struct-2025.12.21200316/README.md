# write_struct
[![PyPI version](https://badge.fury.io/py/write-struct.svg)](https://badge.fury.io/py/write-struct)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/badge/write-struct)](https://pepy.tech/project/write-struct)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-blue)](https://www.linkedin.com/in/eugene-evstafev-716669181/)


**Transform raw text into structured, formatted content for WriteFreely and beyond.**

`write_struct` is a Python package designed to enhance content creation by automatically converting user-submitted text into well-structured, formatted output. It leverages AI-powered pattern matching to ensure consistency, readability, and publication-ready quality for articles, blog posts, social media updates, and more.

---

## 🚀 Features
- **Automated text structuring** using AI-driven pattern matching.
- **Flexible LLM integration** – works with default `ChatLLM7` or any LangChain-compatible model.
- **Regex-based validation** to enforce output consistency.
- **Lightweight and efficient** for text-based content processing.
- **No multimedia handling** – focuses purely on text formatting.

---

## 📦 Installation

Install via pip:

```bash
pip install write_struct
```

---

## 🔧 Usage

### Basic Usage (Default LLM7)
```python
from write_struct import write_struct

user_input = "Your raw text here..."
response = write_struct(user_input)
print(response)
```

### Custom LLM Integration
You can replace the default `ChatLLM7` with any LangChain-compatible model (e.g., OpenAI, Anthropic, Google Generative AI):

#### Using OpenAI:
```python
from langchain_openai import ChatOpenAI
from write_struct import write_struct

llm = ChatOpenAI()
response = write_struct(user_input, llm=llm)
```

#### Using Anthropic:
```python
from langchain_anthropic import ChatAnthropic
from write_struct import write_struct

llm = ChatAnthropic()
response = write_struct(user_input, llm=llm)
```

#### Using Google Generative AI:
```python
from langchain_google_genai import ChatGoogleGenerativeAI
from write_struct import write_struct

llm = ChatGoogleGenerativeAI()
response = write_struct(user_input, llm=llm)
```

---

## 🔑 API Key Configuration
- **Default**: Uses `LLM7_API_KEY` from environment variables.
- **Manual Override**: Pass the API key directly:
  ```python
  response = write_struct(user_input, api_key="your_api_key_here")
  ```
- **Free API Key**: Register at [https://token.llm7.io/](https://token.llm7.io/) for LLM7.

---

## 📜 Input Parameters
| Parameter | Type       | Description                                                                 |
|-----------|------------|-----------------------------------------------------------------------------|
| `user_input` | `str`      | Raw text to be structured.                                                  |
| `api_key`   | `Optional[str]` | LLM7 API key (defaults to `LLM7_API_KEY` env var).                     |
| `llm`       | `Optional[BaseChatModel]` | Custom LangChain LLM (e.g., `ChatOpenAI`, `ChatAnthropic`). Defaults to `ChatLLM7`. |

---

## 📊 Rate Limits
- **LLM7 Free Tier**: Sufficient for most use cases.
- **Upgrade**: For higher limits, use a custom API key or switch to a paid plan.

---

## 📝 License
MIT License.

---

## 📢 Support & Issues
For bugs, feature requests, or support, open an issue on [GitHub](https://github.com/chigwell/write-struct/issues).

---

## 👤 Author
**Eugene Evstafev** ([@chigwell](https://github.com/chigwell))
📧 [hi@euegne.plus](mailto:hi@euegne.plus)

---