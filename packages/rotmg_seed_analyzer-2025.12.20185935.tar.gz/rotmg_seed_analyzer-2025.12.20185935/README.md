# RotMG Seed Analyzer

[![PyPI version](https://badge.fury.io/py/rotmg-seed-analyzer.svg)](https://pypi.org/project/rotmg-seed-analyzer/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Downloads](https://static.pepy.tech/personalized-badge/rotmg-seed-analyzer?period=total&units=international_system&left_color=grey&right_color=orange&left_text=Downloads)](https://pepy.tech/project/rotmg-seed-analyzer)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Eugene%20Evstafev-blue)](https://www.linkedin.com/in/eugene-evstafev/)

A specialized tool that accepts user-provided text descriptions or extracted data related to RotMG map seeds, and utilizes structured pattern matching to generate a detailed, standardized summary of the map configuration, seed details, or strategic insights.

## Installation

```bash
pip install rotmg-seed-analyzer
```

## Usage

### Basic Usage

```python
from rotmg-seed-analyzer import rotmg_seed_analyzer

response = rotmg_seed_analyzer(user_input="Your RotMG seed description here")
print(response)
```

### Using a Custom LLM

The package uses `ChatLLM7` from [langchain_llm7](https://pypi.org/project/langchain-llm7/) by default. However, you can safely pass your own LLM instance if you want to use another LLM.

#### Example with OpenAI

```python
from langchain_openai import ChatOpenAI
from rotmg-seed-analyzer import rotmg_seed_analyzer

llm = ChatOpenAI()
response = rotmg_seed_analyzer(user_input="Your RotMG seed description here", llm=llm)
print(response)
```

#### Example with Anthropic

```python
from langchain_anthropic import ChatAnthropic
from rotmg-seed-analyzer import rotmg_seed_analyzer

llm = ChatAnthropic()
response = rotmg_seed_analyzer(user_input="Your RotMG seed description here", llm=llm)
print(response)
```

#### Example with Google

```python
from langchain_google_genai import ChatGoogleGenerativeAI
from rotmg-seed-analyzer import rotmg_seed_analyzer

llm = ChatGoogleGenerativeAI()
response = rotmg_seed_analyzer(user_input="Your RotMG seed description here", llm=llm)
print(response)
```

### Using an API Key

The default rate limits for LLM7 free tier are sufficient for most use cases of this package. If you want higher rate limits for LLM7, you can pass your own API key via environment variable `LLM7_API_KEY` or via passing it directly.

#### Example with API Key

```python
from rotmg-seed-analyzer import rotmg_seed_analyzer

response = rotmg_seed_analyzer(user_input="Your RotMG seed description here", api_key="your_api_key")
print(response)
```

You can get a free API key by registering at [LLM7](https://token.llm7.io/).

## Parameters

- `user_input` (str): The user input text to process.
- `llm` (Optional[BaseChatModel]): The LangChain LLM instance to use. If not provided, the default `ChatLLM7` will be used.
- `api_key` (Optional[str]): The API key for LLM7. If not provided, the environment variable `LLM7_API_KEY` will be used.

## Issues

If you encounter any issues, please report them on the [GitHub issues page](https://github.com/chigwell/rotmg-seed-analyzer/issues).

## Author

**Eugene Evstafev**

- **Email**: hi@eugene.plus
- **GitHub**: [chigwell](https://github.com/chigwell)

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.