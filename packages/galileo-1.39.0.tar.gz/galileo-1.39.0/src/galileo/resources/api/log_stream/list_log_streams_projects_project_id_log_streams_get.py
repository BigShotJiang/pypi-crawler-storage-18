from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from galileo.utils.headers_data import get_sdk_header
from galileo_core.constants.request_method import RequestMethod
from galileo_core.helpers.api_client import ApiClient

from ... import errors
from ...models.http_validation_error import HTTPValidationError
from ...models.log_stream_response import LogStreamResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(project_id: str, *, include_counts: Union[Unset, bool] = False) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["include_counts"] = include_counts

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": RequestMethod.GET,
        "return_raw_response": True,
        "path": f"/projects/{project_id}/log_streams",
        "params": params,
    }

    headers["X-Galileo-SDK"] = get_sdk_header()

    _kwargs["content_headers"] = headers
    return _kwargs


def _parse_response(
    *, client: ApiClient, response: httpx.Response
) -> Optional[Union[HTTPValidationError, list["LogStreamResponse"]]]:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = LogStreamResponse.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        return HTTPValidationError.from_dict(response.json())

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(
    *, client: ApiClient, response: httpx.Response
) -> Response[Union[HTTPValidationError, list["LogStreamResponse"]]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    project_id: str, *, client: ApiClient, include_counts: Union[Unset, bool] = False
) -> Response[Union[HTTPValidationError, list["LogStreamResponse"]]]:
    """List Log Streams.

     Retrieve all log streams for a project.

    DEPRECATED in favor of `list_log_streams_paginated`.

    Args:
        project_id (str):
        include_counts (Union[Unset, bool]):  Default: False.

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Response[Union[HTTPValidationError, list['LogStreamResponse']]]
    """
    kwargs = _get_kwargs(project_id=project_id, include_counts=include_counts)

    response = client.request(**kwargs)

    return _build_response(client=client, response=response)


def sync(
    project_id: str, *, client: ApiClient, include_counts: Union[Unset, bool] = False
) -> Optional[Union[HTTPValidationError, list["LogStreamResponse"]]]:
    """List Log Streams.

     Retrieve all log streams for a project.

    DEPRECATED in favor of `list_log_streams_paginated`.

    Args:
        project_id (str):
        include_counts (Union[Unset, bool]):  Default: False.

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Union[HTTPValidationError, list['LogStreamResponse']]
    """
    return sync_detailed(project_id=project_id, client=client, include_counts=include_counts).parsed


async def asyncio_detailed(
    project_id: str, *, client: ApiClient, include_counts: Union[Unset, bool] = False
) -> Response[Union[HTTPValidationError, list["LogStreamResponse"]]]:
    """List Log Streams.

     Retrieve all log streams for a project.

    DEPRECATED in favor of `list_log_streams_paginated`.

    Args:
        project_id (str):
        include_counts (Union[Unset, bool]):  Default: False.

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Response[Union[HTTPValidationError, list['LogStreamResponse']]]
    """
    kwargs = _get_kwargs(project_id=project_id, include_counts=include_counts)

    response = await client.arequest(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    project_id: str, *, client: ApiClient, include_counts: Union[Unset, bool] = False
) -> Optional[Union[HTTPValidationError, list["LogStreamResponse"]]]:
    """List Log Streams.

     Retrieve all log streams for a project.

    DEPRECATED in favor of `list_log_streams_paginated`.

    Args:
        project_id (str):
        include_counts (Union[Unset, bool]):  Default: False.

    Raises
    ------
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns
    -------
        Union[HTTPValidationError, list['LogStreamResponse']]
    """
    return (await asyncio_detailed(project_id=project_id, client=client, include_counts=include_counts)).parsed
