"""OpenAPI extensions package"""
