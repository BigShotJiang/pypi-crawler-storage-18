# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["BroadcastChannel"]

BroadcastChannel: TypeAlias = Literal["smart", "sms", "whatsapp", "email"]
