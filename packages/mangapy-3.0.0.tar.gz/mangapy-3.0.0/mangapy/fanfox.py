import ast
import re
import requests
import threading
from mangapy import log
from mangapy.mangarepository import MangaRepository, Manga, Chapter, Page
from mangapy.capabilities import ProviderCapabilities
from mangapy.utils import unpack
from bs4 import BeautifulSoup
from typing import List


def can_convert_to_float(value):
    try:
        float(value)
        return True
    except ValueError:
        return False


def _normalize_title(value: str) -> str:
    return "".join(ch for ch in value.lower() if ch.isalnum())


def _slugify_title(value: str) -> str:
    return re.sub(r'[^A-Za-z0-9]+', '_', re.sub(r'^[^A-Za-z0-9]+|[^A-Za-z0-9]+$', '', value)).lower()


class FanFoxRepository(MangaRepository):
    name = "FanFox"
    base_url = "https://fanfox.net"
    proxies = None
    _session = None

    def __init__(self):
        self._session_local = threading.local()

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(max_parallel_chapters=1, max_parallel_pages=1, supports_batch_download=False)

    def image_request_headers(self) -> dict[str, str] | None:
        return {"Referer": f"{self.base_url}"}

    @property
    def session(self):
        return self._get_session()

    def _get_session(self):
        session = getattr(self._session_local, "session", None)
        if session is not None:
            return session

        session = requests.Session()
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=1.0,image/webp,image/apng,*/*;q=1.0',
            'Accept-Encoding': 'gzip, deflate',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/60.0.3112.101 Safari/537.36',
            'Accept-Language': 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': '{0}'.format(self.base_url),
            'Connection': 'keep-alive'
        }

        session.cookies['isAdult'] = '1'
        session.headers = headers
        session.proxies = self.proxies
        self._session_local.session = session
        return session

    def _get_chapters(self, list):
        manga_chapters = []
        if list is None:
            return manga_chapters
        list_detail = list.find('ul', {'class': 'detail-main-list'})
        if list_detail is None:
            return manga_chapters
        chapters = list_detail.find_all('a', href=True)
        chapters_url = map(lambda c: c['href'], reversed(chapters))
         
        for url in chapters_url:
            chapter_id = url.split("/")[-2][1:]  # relative url, TODO: regex
            absolute_url = "{0}{1}".format(self.base_url, url)

            # if number is not convertible than chapters can be properly ordered
            # by the search method
            # TODO: change the Chapter class to support different chapters with the same number but different content
            # Why the fix is not relevant at the moment?
            # - I've found only a case (Tower of God where there is chapter 87 but also 87.E and 87.Extra) and the
            # additional chapters are 404

            number = float(chapter_id) if can_convert_to_float(chapter_id) else None
            chapter = FanFoxChapter(absolute_url, chapter_id, number, self._get_session)
            manga_chapters.append(chapter)

        return manga_chapters

    def search(self, manga_name, options: dict | None = None) -> List[Manga]:
        manga_name_adjusted = _slugify_title(manga_name)
        manga_url = "{0}/manga/{1}/".format(self.base_url, manga_name_adjusted)
        manga = self._fetch_manga(manga_url, manga_name)
        if manga is not None:
            return manga

        match = self._search_manga(manga_name)
        if match is None:
            return None
        match_title, match_url = match
        return self._fetch_manga(match_url, match_title)

    def _fetch_manga(self, manga_url: str, fallback_title: str) -> Manga | None:
        response = self.session.get(url=manga_url)
        if response is None or response.status_code != 200:
            return None

        content = response.text
        soup = BeautifulSoup(content, features="html.parser")

        # list-2 contains all the chapters, list-1 only the last volume
        # in theory we should use list-1 and fallback to to list-2 if list-1 doesn't exist
        # but it seems that sometimes chapters are put in the wrong list
        # to solve this we merge both the lists
        list_two = soup.find('div', {'id': 'list-2'})
        list_one = soup.find('div', {'id': 'list-1'})

        if list_one is None and list_two is None:
            blocked = soup.find('p', {'class': 'detail-block-content'})
            if blocked:
                log.warning(blocked.getText())
            else:
                log.warning('No chapters found')
            return None

        list_one_chapters = self._get_chapters(list_one)
        list_two_chapters = self._get_chapters(list_two)
        chapters = list_one_chapters + list_two_chapters

        if not chapters:
            log.warning('No chapters list found')
            return None

        seen = set()
        unique_chapters = []
        for chapter in chapters:
            if chapter.chapter_id not in seen:
                unique_chapters.append(chapter)
                seen.add(chapter.chapter_id)

        sorted_chapters = sorted(unique_chapters, key=lambda chapter: chapter.sort_key, reverse=False)
        return Manga(fallback_title, sorted_chapters)

    def _search_manga(self, manga_name: str) -> tuple[str, str] | None:
        response = self.session.get(f"{self.base_url}/search", params={"title": manga_name})
        if response is None or response.status_code != 200:
            return None

        soup = BeautifulSoup(response.text, features="html.parser")
        results: list[tuple[str, str]] = []
        for item in soup.select("ul.manga-list-4-list li"):
            title_link = item.select_one("p.manga-list-4-item-title a")
            if not title_link:
                continue
            title = title_link.get_text(strip=True)
            href = title_link.get("href")
            if not title or not href:
                continue
            url = href if href.startswith("http") else f"{self.base_url}{href}"
            results.append((title, url))

        if not results:
            return None

        normalized_query = _normalize_title(manga_name)
        partial_matches = []
        for title, url in results:
            normalized_title = _normalize_title(title)
            if normalized_title == normalized_query:
                return title, url
            if normalized_query and normalized_query in normalized_title:
                partial_matches.append((title, url))

        if partial_matches:
            return partial_matches[0]

        return None


class FanFoxChapter(Chapter):
    def __init__(self, first_page_url, chapter_id, number, session_provider):
        super().__init__(first_page_url, chapter_id, number)
        self._session_provider = session_provider

    def _get_urls(self, content):
        unpacked = _unpack_packed_js(content)
        if unpacked is None:
            raise ValueError("Packed JS not found for URLs")
        return unpacked

    def _get_key(self, content):
        unpacked = _unpack_packed_js(content)
        if unpacked is None:
            raise ValueError("Packed JS not found for key")
        key_match = re.search(r'(?<=var guidkey=)(.*)(?=\';)', unpacked)
        key = key_match.group(1)
        key = key.replace('\'', '')
        key = key.replace('\\', '')
        key = key.replace('+', '')
        return key

    def _fetch_chapterfun_links(self, base_url, cid, imagecount, key):
        if not imagecount or imagecount <= 0:
            return []
        links = []
        for i in range(0, int(imagecount / 2 + .5)):
            data = self._one_link_helper((i * 2) + 1, base_url, cid, key)
            if not data:
                return None
            try:
                unpacked = self._get_urls(data)
            except ValueError:
                return None
            links += self._parse_links(unpacked)
        return links

    def _one_link_helper(self, page, base_url, cid, key):
        final_url = '{}/chapterfun.ashx?cid={}&page={}&key={}'.format(base_url, cid, page, key)
        session = self._session_provider()
        response = session.get(final_url)

        if response is None or response.status_code != 200:
            return None

        content = response.text
        return content

    def _parse_links(self, data):
        base_path = re.search(r'pix="(.+?)"', data).group(1)
        images = re.findall(r'"(/\w.+?)"', data)
        return [base_path + i for i in images]

    def pages(self) -> List[Page]:
        base_url = self.first_page_url[:self.first_page_url.rfind('/')]
        session = self._session_provider()
        response = session.get(self.first_page_url)

        if response is None or response.status_code != 200:
            return None

        content = response.text
        soup = BeautifulSoup(content, features="html.parser")
        page_numbers = soup.find_all("a", {"data-page": True})

        links = []
        pages = []

        cid_match = re.search(r'chapterid\s*=\s*(\d+)', content)
        imagecount_match = re.search(r'imagecount\s*=\s*(\d+)', content)
        if cid_match and imagecount_match:
            cid = cid_match.group(1)
            imagecount = int(imagecount_match.group(1))
            links = self._fetch_chapterfun_links(base_url, cid, imagecount, "")
            if links is None:
                try:
                    key = self._get_key(content)
                except ValueError:
                    key = ""
                links = self._fetch_chapterfun_links(base_url, cid, imagecount, key)
            if links:
                for i, link in enumerate(links):
                    pages.append(Page(i, link))
                return pages

        if not len(page_numbers):
            # sometimes all the images are loaded in the same html page
            scripts = soup.find_all("script", {"type": "text/javascript"})
            if not scripts:
                return []
            eval_script = next((script for script in scripts if script.text.startswith("eval")), None).text
            images_content = self._get_urls(eval_script)
            links = re.search(r'(?<=newImgs=\[)[^]]+(?=\])', images_content).group(0).split(',')
            for i, link in enumerate(links):
                formatted_link = link.replace("'", "")
                pages.append(Page(i, formatted_link))
        else:
            # standard flow
            page_numbers = map(lambda x: int(x['data-page']), page_numbers)
            last_page_number = max(page_numbers)
            cid_match = re.search(r'chapterid\s*=\s*(\d+)', content)
            if not cid_match:
                return []
            cid = cid_match.group(1)
            key = self._get_key(content)

            for i in range(0, int(last_page_number / 2 + .5)):
                data = self._one_link_helper((i * 2) + 1, base_url, cid, key)
                links += self._parse_links(self._get_urls(data))

            for i, link in enumerate(links):
                pages.append(Page(i, link))

        return pages


if __name__ == '__main__':
    repo = FanFoxRepository()
    manga = repo.search('naruto')
    assert manga is not None
PACKER_ARGS_RE = re.compile(
    r"\}\(\s*"
    r"(?P<p>('([^'\\]|\\.)*'|\"([^\"\\]|\\.)*\"))\s*,\s*"
    r"(?P<a>\d+)\s*,\s*"
    r"(?P<c>\d+)\s*,\s*"
    r"(?P<k>('([^'\\]|\\.)*'|\"([^\"\\]|\\.)*\"))"
    r"\.split\(\s*['\"]\|['\"]\s*\)"
)


def _js_string_unescape(quoted: str) -> str:
    try:
        return ast.literal_eval(quoted)
    except Exception:
        body = quoted[1:-1]
        try:
            return bytes(body, "utf-8").decode("unicode_escape")
        except Exception:
            return body


def _unpack_packed_js(content: str) -> str | None:
    match = PACKER_ARGS_RE.search(content)
    if not match:
        return None
    p_raw = match.group("p")
    a = int(match.group("a"))
    c = int(match.group("c"))
    k_raw = match.group("k")
    p = _js_string_unescape(p_raw)
    k = _js_string_unescape(k_raw).split("|")
    return unpack(p, a, c, k)
