# CarLib - Neural Media Codecs Serialization for ML Training

CarLib serializes neural encodings and file metadata into CAR archives. This structure minimizes storage and enables efficient random access, effectively removing preprocessing overhead during training loops.

## CarLib Workflow

```
┌─────────────────────┐    ┌─────────────────────┐
│   Media Files       │───►│  Neural Encoder     │
│ Audio/Video/Image   │    │ EnCodec/DAC/Cosmos  │
└─────────────────────┘    └─────────┬───────────┘
                                     │
                                     ▼
┌─────────────────────┐    ┌─────────────────────┐
│ Normalize & Process │◄───│ Encoded Features    │
└─────────┬───────────┘    │   Tokens/Codes      │
          │                └─────────────────────┘
          ▼
┌─────────────────────┐
│ Store in CAR Archive│
│     (.car files)    │
└─────────┬───────────┘
          │
          ├─────────────────────┐
          │                     │
          ▼                     ▼
┌─────────────────────┐ ┌─────────────────────┐
│  Training Pipeline  │ │ Evaluation Pipeline │
└─────────┬───────────┘ └─────────┬───────────┘
          │                       │
          ▼                       ▼
┌─────────────────────┐ ┌─────────────────────┐
│   Load from CAR     │ │   Load from CAR     │
│CARDataset/CARLoader │ │  Evaluation Mode    │
└─────────┬───────────┘ └─────────┬───────────┘
          │                       │
          ▼                       ▼
┌─────────────────────┐ ┌─────────────────────┐
│    ML Training      │ │  Decode to Media    │
│Direct token training│ │     CARDecoder      │
└─────────────────────┘ └─────────┬───────────┘
                                  │
                                  ▼
                        ┌─────────────────────┐
                        │ Reconstructed Media │
                        │  Quality evaluation │
                        └─────────────────────┘
```

The carfile workflow enables efficient neural media processing by:
1. **Encoding**: Converting raw media into compressed neural representations
2. **Storage**: Organizing encoded data in CAR archives for fast random access  
3. **Training**: Loading encoded tokens directly without preprocessing overhead
4. **Evaluation**: Decoding representations back to media for quality assessment

## Quick Start

### Installation

**For Users (Recommended):**
```bash
# Full installation with all features
pip install carlib
```

**For Developers:**
```bash
# Clone and install for development
git clone https://github.com/gcxrightsify/carlib.git
cd carlib
pip install -e .  # Editable install with all dependencies
```

**Using Docker:**
```bash
# Clone the repository
git clone https://github.com/gcxrightsify/carlib.git
cd carlib

# Build the Docker image
docker build -t carlib:latest .

# Run carlib commands
docker run --rm -v $(pwd)/data:/data carlib:latest carlib --help

# Convert datasets using Docker
docker run --rm -v $(pwd)/input:/input -v $(pwd)/output:/data carlib:latest \
  carlib convert /input --modality vanilla --target-modality audio -o /data

# Interactive development mode
docker run --rm -it -v $(pwd):/app carlib:latest bash
```

### Prerequisites

CarLib requires **ffmpeg** to be installed on your system for audio, video, and image processing.

**macOS:**
```bash
# Using Homebrew (recommended)
brew install ffmpeg

# Using MacPorts
sudo port install ffmpeg
```

**Ubuntu/Debian:**
```bash
# Using apt
sudo apt update
sudo apt install ffmpeg

# For older Ubuntu versions, you may need to add a PPA
sudo add-apt-repository ppa:jonathonf/ffmpeg-4
sudo apt update
sudo apt install ffmpeg
```

**CentOS/RHEL/Fedora:**
```bash
# CentOS/RHEL (enable EPEL repository first)
sudo yum install epel-release
sudo yum install ffmpeg

# Fedora
sudo dnf install ffmpeg

# For newer versions
sudo dnf install https://mirrors.rpmfusion.org/free/fedora/rpmfusion-free-release-$(rpm -E %fedora).noarch.rpm
sudo dnf install ffmpeg
```

**Windows:**
```bash
# Using Chocolatey
choco install ffmpeg

# Using Scoop
scoop install ffmpeg

# Manual installation:
# 1. Download from https://www.gyan.dev/ffmpeg/builds/
# 2. Extract to C:\ffmpeg
# 3. Add C:\ffmpeg\bin to your PATH environment variable
```

**Conda (cross-platform):**
```bash
conda install -c conda-forge ffmpeg
```

To verify ffmpeg installation:
```bash
ffmpeg -version
```

### Basic Usage

**For video/image datasets - Install additional components:**
```bash
# Install video and image processing support (one-time setup)
# This automatically downloads the required models
carlib install video-image
```

### Dataset Conversion
```python
from carlib import convert_dataset_to_car, load_config_from_yaml

# Basic conversion (CAR format always saved)
convert_dataset_to_car(
    input_path="/path/to/dataset",
    output_path="/path/to/output",
    modality="vanilla",
    target_modality="audio",
    parallel=True,  # Enable parallel processing (default)
    num_gpus=None   # Auto-detect GPUs (or specify: num_gpus=2)
)

# Save additional formats alongside CAR
convert_dataset_to_car(
    input_path="/path/to/dataset",
    output_path="/path/to/output",
    modality="vanilla",
    target_modality="audio",
    save_extras=["hdf5", "webdataset"],  # Save HDF5 and WebDataset formats
    parallel=True,
    num_gpus=None
)

# With custom configuration
config = load_config_from_yaml("my_config.yaml", "audio")
convert_dataset_to_car(
    input_path="/path/to/dataset", 
    output_path="/path/to/output",
    modality="vanilla",
    target_modality="audio",
    save_extras=["hdf5"],  # Save HDF5 format alongside CAR
    parallel=True,
    config_file="my_config.yaml"
)
```

**Loading CAR files for ML training:**

```python
import carlib
import torch
from torch.utils.data import DataLoader

# Step 1: Create CAR dataset
dataset = carlib.CARDataset("/path/to/car/files", modality="image")  # or "audio", "video"

# Step 2: Define robust collate function 
def collate_car_batch(batch):
    """Tested collate function that works with all CAR data types"""
    if not batch:
        return {}
    
    # Extract data keys from first item
    data_keys = set()
    for item in batch:
        if 'data' in item:
            data_keys.update(item['data'].keys())
    
    batched_data = {}
    for key in data_keys:
        values = [item['data'][key] for item in batch if 'data' in item and key in item['data']]
        
        if values:
            # Stack tensors if all have same shape, otherwise keep as list
            if all(isinstance(v, torch.Tensor) for v in values):
                try:
                    shapes = [v.shape for v in values]
                    if all(s == shapes[0] for s in shapes):
                        batched_data[key] = torch.stack(values)
                        continue
                except Exception:
                    pass
            # Non-tensor data or different shapes - keep as list
            batched_data[key] = values
    
    return {
        'data': batched_data,
        'metadata': [item['metadata'] for item in batch],
        'file_paths': [item['file_path'] for item in batch]
    }

# Step 3: Create DataLoader 
loader = DataLoader(
    dataset, 
    batch_size=32, 
    shuffle=True, 
    collate_fn=collate_car_batch,
    num_workers=4,  # Important: >0 for performance
    pin_memory=True
)

# Step 4: Training loop
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

for batch in loader:
    # Move tensors to GPU
    for key, value in batch['data'].items():
        if isinstance(value, torch.Tensor):
            batch['data'][key] = value.to(device)
    
    # Access encoded data (key depends on modality):
    if 'codes' in batch['data']:              # Audio files (EnCodec/DAC/SNAC)
        tokens = batch['data']['codes']        # Shape: [batch, seq_len]
    elif 'encoded_latents' in batch['data']:  # Image/Video files (Cosmos)
        tokens = batch['data']['encoded_latents']  # Shape: [batch, 16, h, w]
    
    # Train your model
    loss = model(tokens)
    loss.backward()

# JAX loader for JAX-based training
jax_loader = carlib.load_car_jax("/path/to/car/files", modality="audio")
for item in jax_loader:
    tokens = item['data']['tokens']  # JAX arrays for training

# High-performance Grain loader for enterprise-scale JAX training
grain_loader = carlib.load_car_grain(
    "/path/to/car/files",
    batch_size=64,
    shuffle=True,
    seed=42,
    modality="audio"
)
for batch in grain_loader:
    # True global shuffling, deterministic processing
    jax_arrays = batch['data']['codes']  # Ready for JAX training

# Load single CAR file
single_data = carlib.load_single_car("/path/to/file.car")
```

### Validation/Decoding

**Audio Decoding:**
```python
import carlib

# Initialize decoder
decoder = carlib.CARDecoder(device="cuda")

# Decode single audio CAR file
audio_result = decoder.decode_car(
    car_path="/path/to/audio_file.car",
    output_path="/output/decoded_audio.wav",
    save_decoded=True
)

print(f"Decoded audio shape: {audio_result['decoded_data'].shape}")  # [samples] or [channels, samples]
print(f"Audio saved to: {audio_result['output_path']}")

# Batch decode audio directory
audio_results = decoder.decode_directory(
    car_dir="/path/to/audio/cars",
    output_dir="/output/decoded_audio",
    modality="audio"
)

# Decode model-generated audio tokens
model_audio_output = model.generate(input_tokens)  # Your model's output
decoded_audio = decoder.decode_data(
    encoded_data=model_audio_output,
    target_modality="audio",
    output_path="/output/generated_audio.wav",
    save_decoded=True
)
```

**Image Decoding:**
```python
import carlib

# Initialize decoder  
decoder = carlib.CARDecoder(device="cuda")

# Decode single image CAR file
image_result = decoder.decode_car(
    car_path="/path/to/image_file.car",
    output_path="/output/decoded_image.png",
    save_decoded=True
)

print(f"Decoded image shape: {image_result['decoded_data'].shape}")  # [H, W, C] or [C, H, W]
print(f"Image saved to: {image_result['output_path']}")

# Batch decode image directory
image_results = decoder.decode_directory(
    car_dir="/path/to/image/cars", 
    output_dir="/output/decoded_images",
    modality="image"
)

# Decode model-generated image tokens
model_image_output = model.generate(input_tokens)  # Your model's output
decoded_image = decoder.decode_data(
    encoded_data=model_image_output,
    target_modality="image",
    output_path="/output/generated_image.png",
    save_decoded=True
)

# Advanced: Decode without saving (for processing)
result = decoder.decode_car("/path/to/image.car", save_decoded=False)
image_tensor = result['decoded_data']  # Use tensor directly
# Process image_tensor in your pipeline...
```

**Video Decoding:**
```python
import carlib

# Initialize decoder
decoder = carlib.CARDecoder(device="cuda")

# Decode single video CAR file
video_result = decoder.decode_car(
    car_path="/path/to/video_file.car",
    output_path="/output/decoded_video.mp4",
    save_decoded=True
)

print(f"Decoded video shape: {video_result['decoded_data'].shape}")  # [frames, H, W, C]
print(f"Video saved to: {video_result['output_path']}")

# Batch decode video directory  
video_results = decoder.decode_directory(
    car_dir="/path/to/video/cars",
    output_dir="/output/decoded_videos", 
    modality="video"
)

# Decode model-generated video tokens
model_video_output = model.generate(input_tokens)  # Your model's output
decoded_video = decoder.decode_data(
    encoded_data=model_video_output,
    target_modality="video",
    output_path="/output/generated_video.mp4",
    save_decoded=True
)

# Quality evaluation workflow
for result in video_results:
    if result['status'] == 'success':
        print(f"✅ {result['input_path']} → {result['output_path']}")
        # Run your quality metrics on the decoded video
        # quality_score = evaluate_video_quality(result['output_path'])
    else:
        print(f"❌ Failed: {result['input_path']} - {result['error']}")
```

### Custom Encoding Storage

Store your own pre-computed encodings (from custom tokenizers, embeddings, etc.) directly as CAR files:

```python
import torch
from carlib import store_encoding, load_encoding

# Your custom tokenizer/encoder outputs
tokens = torch.randint(0, 1000, (32, 100))         # Example: custom tokenizer output
embeddings = torch.randn(32, 100, 512)            # Example: encoder embeddings
features = torch.randn(32, 768)                   # Example: feature representations

# Store multiple tensors with metadata
result = store_encoding(
    data={
        'tokens': tokens,
        'embeddings': embeddings, 
        'features': features
    },
    output_path='./my_custom_encoding.car',
    metadata={
        'model': 'my_custom_tokenizer_v2',
        'vocab_size': 1000,
        'embedding_dim': 512,
        'description': 'Custom encoding for music generation'
    },
    optimize_dtypes=True,    # Optimize storage efficiency
    compress=True            # Enable compression
)

print(f"Saved to: {result}")
# Output: ./my_custom_encoding.car

# Load back your tensors
data, metadata = load_encoding('./my_custom_encoding.car')

# Access your tensors
loaded_tokens = data['tokens']        # torch.Size([32, 100])
loaded_embeddings = data['embeddings'] # torch.Size([32, 100, 512])
loaded_features = data['features']    # torch.Size([32, 768])

print(f"Model: {metadata['model']}")
print(f"Vocab size: {metadata['vocab_size']}")

# Use in your training pipeline
from torch.utils.data import DataLoader

class CustomEncodingDataset:
    def __init__(self, car_files):
        self.car_files = car_files
    
    def __len__(self):
        return len(self.car_files)
    
    def __getitem__(self, idx):
        data, metadata = load_encoding(self.car_files[idx])
        return {
            'tokens': data['tokens'],
            'embeddings': data['embeddings'], 
            'metadata': metadata
        }

# Create dataset from your CAR files
dataset = CustomEncodingDataset(['encoding1.car', 'encoding2.car', ...])
loader = DataLoader(dataset, batch_size=16, shuffle=True)

for batch in loader:
    tokens = batch['tokens']      # Ready for training
    embeddings = batch['embeddings'] 
    # Train your model...

# Batch storage for multiple encodings
from carlib import store_multiple_encodings

encodings = [
    ({'tokens': torch.randint(0, 100, (10, 20))}, {'model': 'v1'}, 'encoding_1'),
    ({'tokens': torch.randint(0, 100, (15, 25))}, {'model': 'v2'}, 'encoding_2'),
]

saved_paths = store_multiple_encodings(encodings, base_path='./batch_output/')
print(f"Batch saved: {saved_paths}")

# Utility functions
from carlib import get_encoding_info, verify_encoding

# Get metadata without loading tensors
info = get_encoding_info('./my_custom_encoding.car')
print(f"Created: {info['created_at']}")
print(f"Media type: {info['media_type']}")

# Verify file integrity
is_valid = verify_encoding('./my_custom_encoding.car')
print(f"File is valid: {is_valid}")
```

### ML Training with CAR Data
```python
import carlib
import torch
from torch.utils.data import DataLoader
from transformers import AutoImageProcessor, AutoModelForImageClassification
from peft import LoraConfig, get_peft_model, TaskType

# Fine-tuning image model with PEFT (LoRA) using CAR dataset
def finetune_image_with_peft():
    # Load CAR image dataset
    dataset = carlib.CARDataset(
        car_dir="/path/to/car/files",
        modality="image",
        cache_in_memory=True,
        use_mmap=True,
        max_cache_size=1000
    )
    
    # Load pre-trained vision model
    model_name = "google/vit-base-patch16-224"
    model = AutoModelForImageClassification.from_pretrained(
        model_name,
        num_labels=10  # Adjust for your classification task
    )
    
    # Configure LoRA for vision transformer
    lora_config = LoraConfig(
        task_type=TaskType.IMAGE_CLASSIFICATION,
        r=16,
        lora_alpha=32,
        lora_dropout=0.1,
        target_modules=["query", "value", "dense"]
    )
    
    # Apply PEFT
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    
    # Create DataLoader with CAR data
    dataloader = DataLoader(
        dataset,
        batch_size=16,
        shuffle=True,
        collate_fn=dataset._collate_fn
    )
    
    # Training loop
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5)
    model.train()
    
    for batch in dataloader:
        # Extract encoded image latents from CAR data
        encoded_latents = batch['data']['encoded_latents']  # Shape: [batch, 16, h, w]
        
        # Forward pass (you may need to adapt this based on your model architecture)
        outputs = model(pixel_values=encoded_latents)
        loss = outputs.loss
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    
    return model

# Training loop with PEFT - Music Generation (MusicGen)
from transformers import MusicgenForConditionalGeneration, AutoProcessor

# Load pre-trained MusicGen model
music_model = MusicgenForConditionalGeneration.from_pretrained("facebook/musicgen-small")
processor = AutoProcessor.from_pretrained("facebook/musicgen-small")

# Configure LoRA for music generation
music_lora_config = LoraConfig(
    task_type=TaskType.CAUSAL_LM,
    r=16,
    lora_alpha=32,
    lora_dropout=0.1,
    target_modules=["q_proj", "v_proj", "k_proj", "out_proj"]
)

# Apply PEFT to music model
music_model = get_peft_model(music_model, music_lora_config)
music_optimizer = torch.optim.AdamW(music_model.parameters(), lr=1e-4)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
music_model = music_model.to(device)

# Audio dataset for music generation
audio_dataset = carlib.CARDataset(
    car_dir="/path/to/audio/cars",
    modality="audio",
    cache_in_memory=True,
    use_mmap=True,
    max_cache_size=1000
)

# Robust collate function
def robust_collate_fn(batch):
    """Production-ready collate function for CAR data"""
    if not batch:
        return {}
    
    # Extract all data keys
    data_keys = set()
    for item in batch:
        if 'data' in item:
            data_keys.update(item['data'].keys())
    
    batched_data = {}
    for key in data_keys:
        values = [item['data'][key] for item in batch if 'data' in item and key in item['data']]
        
        if values:
            # Try to stack tensors with identical shapes
            if all(isinstance(v, torch.Tensor) for v in values):
                try:
                    shapes = [v.shape for v in values]
                    if all(s == shapes[0] for s in shapes):
                        batched_data[key] = torch.stack(values)
                        continue
                except Exception:
                    pass
            # Keep as list if stacking failed or non-tensor data
            batched_data[key] = values
    
    return {
        'data': batched_data,
        'metadata': [item['metadata'] for item in batch],
        'file_paths': [item['file_path'] for item in batch]
    }

audio_loader = DataLoader(
    audio_dataset,
    batch_size=8,  # Smaller batch size for music models
    shuffle=True,
    collate_fn=robust_collate_fn
)

# Music training loop
for epoch in range(num_epochs):
    for batch in audio_loader:
        # Move tensors to GPU efficiently
        for key, value in batch['data'].items():
            if isinstance(value, torch.Tensor):
                batch['data'][key] = value.to(device, non_blocking=True)
        
        # Access encoded audio codes from CAR data
        audio_codes = batch['data']['codes']  # Shape: [batch, seq_len] or [batch, n_q, seq_len]
        
        # Train on compressed audio representations
        outputs = music_model(input_ids=audio_codes)
        loss = outputs.loss
        
        music_optimizer.zero_grad()
        loss.backward()
        music_optimizer.step()
```

## Supported Formats

### Input Formats
- **vanilla**: Regular media files on filesystem
- **webdataset**: WebDataset tar archives (.tar, .tar.gz, etc.)
- **hdf5**: HDF5 data files (.hdf5, .h5, .hdf)

### Output Formats
- **CAR format**: Always saved (primary compressed format for ML training)
- **HDF5**: Optional additional format via `save_extras=["hdf5"]`
- **WebDataset**: Optional additional format via `save_extras=["webdataset"]`

### Target Modalities
- **audio**: Audio files (.wav, .mp3, .flac, .m4a, .ogg, .aac) - tokenized using advanced audio tokenizers
- **image**: Image files (.jpg, .png, .webp, .bmp, .tiff, .gif) - tokenized using advanced image tokenizers
- **video**: Video files (.mp4, .avi, .mov, .mkv, .webm, .wmv) - tokenized using advanced video tokenizers

## CLI Commands

### Convert Datasets
```bash
carlib convert INPUT_PATH --modality {vanilla,webdataset,hdf5} --target-modality {audio,image,video} -o OUTPUT_PATH
```

**Required Arguments:**
- `INPUT_PATH`: Path to input dataset directory or file
- `--modality, -m`: Input format type
- `--target-modality, -t`: Target media type  
- `--output, -o`: Output directory for CAR files

**Optional Arguments:**
- `--config, -c`: Custom YAML configuration file
- `--parallel`: Enable parallel processing (default: True)
- `--sequential`: Force sequential processing
- `--gpus, -g`: Number of GPUs to use (auto-detected if not specified)
- `--max-files`: Maximum files to process
- `--model-name`: Override tokenizer name
- `--model-type`: Override tokenizer type
- `--recursive/-r`: Search recursively (default: True)
- `--verbose, -v`: Verbose output

### Configuration Management
```bash
carlib config list                    # List available configurations
carlib config show audio             # Show audio configuration
carlib config create audio -o my.yaml # Create custom config template
carlib config validate config.yaml   # Validate configuration file
```

### System Information
```bash
carlib info                          # Show system info and dependencies
carlib validate file1.car file2.car # Validate CAR files
```


## Configuration

CarLib uses YAML files to configure processing parameters. Each target modality has default settings that can be customized.

### Default Configurations

**Audio Tokenizer** (`configs/audio_config.yaml`):
```yaml
tokenizer_type: "audio"
device: "cuda"
target_sample_rate: 32000
max_duration: null
quality_threshold: 0.0
output_format: "car"
```

**Image Tokenizer** (`configs/image_config.yaml`):
```yaml
tokenizer_type: "image"
image_size: [224, 224]
maintain_aspect_ratio: false
normalize_images: true
device: "cuda"
dtype: "bfloat16"
quality_threshold: 0.0
output_format: "car"
```

**Video Tokenizer** (`configs/video_config.yaml`):
```yaml
tokenizer_type: "video"
max_frames: null
frame_size: [224, 224]
frame_skip: 1
target_fps: null
normalize_frames: true
device: "cuda"
dtype: "bfloat16"
quality_threshold: 0.0
output_format: "car"
```

### Creating Custom Configurations

1. **Create a template:**
```bash
carlib config create audio -o my_audio_config.yaml
```

2. **Edit the configuration:**
```yaml
# High-quality audio processing
model_name: "facebook/encodec_48khz"
model_type: "encodec"
device: "cuda"
target_sample_rate: 48000
max_duration: 60.0  # Process max 60 seconds
quality_threshold: 0.7
output_format: "car"
```

3. **Use the custom config:**
```bash
carlib convert /audio/data --modality vanilla --target-modality audio --config my_audio_config.yaml -o /output
```

### Configuration Priority
Settings are applied in this order (highest to lowest priority):
1. Command-line arguments 
2. Custom config file (--config)
3. Default config files
4. Built-in fallbacks





### Advanced Dataset Usage

**Loading Different Modalities:**
```python
# Audio data loading
audio_dataset = carlib.CARDataset("/path/to/audio/cars", modality="audio")
for batch in DataLoader(audio_dataset, batch_size=32, collate_fn=collate_car_batch):
    audio_codes = batch['data']['codes']          # Shape: [batch, seq_len]
    # Train audio model...

# Image data loading  
image_dataset = carlib.CARDataset("/path/to/image/cars", modality="image")
for batch in DataLoader(image_dataset, batch_size=32, collate_fn=collate_car_batch):
    image_latents = batch['data']['encoded_latents']  # Shape: [batch, 16, h, w]
    # Train image model...

# Video data loading
video_dataset = carlib.CARDataset("/path/to/video/cars", modality="video") 
for batch in DataLoader(video_dataset, batch_size=16, collate_fn=collate_car_batch):
    video_latents = batch['data']['encoded_latents']  # Shape: [batch, frames, 16, h, w]
    # Train video model...
```

**Streaming dataset for large datasets:**
```python
streaming_dataset = carlib.CARIterableDataset(
    car_dir="/path/to/large/dataset", 
    shuffle=True,
    modality="image"
)

# Custom collate function for variable-length sequences
def custom_collate(batch):
    # Handle variable sequence lengths (for audio)
    sequences = [item['data']['codes'] for item in batch]
    padded = torch.nn.utils.rnn.pad_sequence(sequences, batch_first=True)
    
    return {
        'data': {'codes': padded},
        'metadata': [item['metadata'] for item in batch],
        'lengths': [len(seq) for seq in sequences]
    }

dataloader = DataLoader(dataset, collate_fn=custom_collate)
```

### JAX Training Support
```python
import carlib
import jax
import jax.numpy as jnp

# JAX loader for JAX-based models
jax_loader = carlib.JAXCARLoader("/path/to/car/files", modality="audio")

# Training with JAX
for batch_paths in batched_car_files:
    batch_data = jax_loader.load_batch(batch_paths)
    tokens = batch_data['data']['tokens']  # JAX arrays
    
    # JAX training step
    params, loss = train_step(params, tokens, targets)
```


## Dataset Benchmarking & Performance Analysis

### CLI Benchmarking Commands
```bash
# Benchmark dataset conversion performance
carlib benchmark /path/to/dataset --modality audio --output benchmark_results.json

# Compare different formats and analyze performance
carlib benchmark /path/to/webdataset --modality webdataset --webdataset-modality audio --gpus 4

# Benchmark HDF5 datasets  
carlib benchmark /path/to/data.hdf5 --modality hdf5 --hdf5-modality image --max-files 1000
```

### Python API Benchmarking
```python
from carlib import BenchmarkConfig, run_folder_benchmark, analyze_benchmark_results

# Create benchmark configuration
config = BenchmarkConfig(
    folder_path="/path/to/dataset",
    modality="audio",  # or 'image', 'video', 'webdataset', 'hdf5'
    output_file="benchmark_results.json",
    num_gpus=2,
    num_runs=3,  # Number of timing runs for averaging
    max_files=1000  # Limit files for testing
)

# Run comprehensive performance benchmark
results = run_folder_benchmark(config)

# Analyze results with enhanced CAR file analysis
analysis = analyze_benchmark_results(
    "benchmark_results.json", 
    output_dir="analysis_output"
)

print(f"Processed {analysis['total_files']} files")
print(f"CarLib enhanced analysis available: {analysis['carlib_available']}")
```

## Examples

### Audio Processing
```bash
# Convert MP3 collection to CAR (default - CAR format only)
carlib convert /music/collection --modality vanilla --target-modality audio -o /output/cars

# High-quality audio with custom settings and specific GPU count
carlib convert /audio/dataset --modality vanilla --target-modality audio \
  --model-name "facebook/encodec_48khz" --gpus 4 -o /output

# Sequential processing (single GPU/CPU)
carlib convert /audio/dataset --modality vanilla --target-modality audio \
  --model-name "facebook/encodec_48khz" --sequential -o /output

# Process WebDataset audio archives
carlib convert /datasets/audio.tar --modality webdataset --target-modality audio \
  --max-files 10000 -o /output
```

### Image Processing
```bash
# Convert image directory (CAR format only)
carlib convert /images/dataset --modality vanilla --target-modality image -o /output/cars

# High-resolution image processing with auto-detected GPUs
carlib convert /images --modality vanilla --target-modality image \
  --config high_res_config.yaml -o /output

# High-resolution with specific GPU count
carlib convert /images --modality vanilla --target-modality image \
  --config high_res_config.yaml --gpus 8 -o /output

# Process HDF5 image dataset
carlib convert /data/images.hdf5 --modality hdf5 --target-modality image -o /output
```

### Video Processing  
```bash
# Convert video files (CAR format only)
carlib convert /videos/dataset --modality vanilla --target-modality video -o /output

# Process with frame sampling
carlib convert /videos --modality vanilla --target-modality video \
  --config frame_sampling_config.yaml --max-files 500 -o /output

# Process WebDataset video archives with auto-detected GPUs  
carlib convert /data/videos.tar --modality webdataset --target-modality video -o /output

# Process with specific GPU count
carlib convert /data/videos.tar --modality webdataset --target-modality video \
  --gpus 4 -o /output
```

### Batch Processing
```python
# Process multiple datasets
import os
from carlib import convert_dataset_to_car

datasets = [
    ("/data/audio1", "audio"),
    ("/data/images1", "image"), 
    ("/data/videos1", "video")
]

for i, (dataset_path, target_modality) in enumerate(datasets):
    output_path = f"/output/batch_{i}"
    os.makedirs(output_path, exist_ok=True)
    
    convert_dataset_to_car(
        input_path=dataset_path,
        output_path=output_path,
        modality="vanilla", 
        target_modality=target_modality,
        save_extras=["hdf5"],  # Optional: save additional formats
        parallel=True,
        num_gpus=2,  # Or None for auto-detect
        max_files=1000
    )
```

## Tokenizer Options

### Available Tokenizers
- **Audio Tokenizer**: High-quality audio compression and tokenization (EnCodec, DAC, SNAC)
- **Image Tokenizer**: Efficient image representation learning (Cosmos tokenizers)
- **Video Tokenizer**: Advanced video sequence tokenization (Cosmos tokenizers)

Tokenizers are automatically selected based on your target modality and configured via YAML files for optimal performance. All output is saved in CAR format for efficient ML training, with optional additional formats available via the `save_extras` parameter.

## Performance Tips

### Multi-GPU Usage
```bash
# Auto-detect and use all available GPUs (default)
carlib convert /large/dataset --modality vanilla --target-modality audio -o /output

# Specify exact number of GPUs
carlib convert /large/dataset --modality vanilla --target-modality audio --gpus 8 -o /output

# Force sequential processing (single GPU/CPU)
carlib convert /large/dataset --modality vanilla --target-modality audio --sequential -o /output
```

### Memory Management
- Use `max_files` to limit memory usage for large datasets
- Adjust `batch_size` in config files for memory constraints
- Use `dtype: "float16"` for lower memory usage

### Processing Optimization
- Set `max_duration` for audio to skip very long files
- Use `frame_skip` for video to reduce processing time
- Enable `quality_threshold` to filter low-quality inputs

### Dataset Loading Performance

CarLib includes several optimizations for high-performance training:

**Dataset Optimization Options:**
- `cache_in_memory=True`: Smart LRU caching with automatic eviction
- `use_mmap=True`: Memory-mapped file access for large datasets
- `max_cache_size=N`: Limit cache size to most frequently accessed files

**DataLoader Optimizations:**
- `num_workers=4` (or higher): Enable prefetching to prevent GPU idle time
- `pin_memory=True`: Faster CPU-to-GPU transfers
- `persistent_workers=True`: Keep worker processes alive between epochs
- `prefetch_factor=2`: Prefetch 2 batches per worker for smooth data flow
- Use `loader.to_device()` for efficient batch-level GPU transfers

**Performance Benefits:**
- **3-5x faster data loading** with smart caching and memory mapping
- **Eliminates repeated file I/O** during training epochs  
- **60-80% reduction** in GPU memory management overhead
- **2-3x lower peak memory usage** with optimized video chunking
- **Prevents GPU idle time** with automatic prefetching
- **Faster file discovery** with optimized glob patterns
- **Reduced processing overhead** with batched multiprocessing
- **Cached spatial padding** calculations for repeated frame sizes
- **Automatic memory management** - no manual cache clearing needed

## Dependencies

### Required
- torch >= 1.9.0
- torchaudio >= 0.9.0
- transformers >= 4.20.0
- PyYAML >= 5.4.0
- tqdm >= 4.60.0

### Additional Features (included in main installation)
- webdataset >= 0.2.0 (WebDataset support)
- h5py >= 3.0.0 (HDF5 support)  
- matplotlib >= 3.0.0 (benchmarking and visualization)
- pandas >= 1.0.0 (data analysis)
- seaborn >= 0.11.0 (advanced plotting)

## Troubleshooting

### Common Issues

**"carlib command not found"**
```bash
# Ensure installation completed
pip install carlib
# Add to PATH if needed
export PATH=$PATH:$(python -m site --user-base)/bin
```

**"CUDA out of memory"**
- Reduce `--gpus` parameter
- Set `max_files` to process in smaller batches
- Use `dtype: "float16"` in config

**"Config file not found"**
```bash
# Check available configs
carlib config list
# Create custom config
carlib config create audio -o my_config.yaml
```

**"No files found"**
- Check input path exists
- Verify file extensions match target modality
- Use `--verbose` for detailed scanning info

### Getting Help
```bash
carlib --help                    # General help
carlib convert --help           # Conversion options
carlib config --help            # Configuration help
carlib benchmark --help         # Benchmarking options
carlib info                     # System information
```

## License

MIT License - see LICENSE file for details.