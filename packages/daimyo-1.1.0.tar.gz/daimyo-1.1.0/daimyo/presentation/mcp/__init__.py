"""MCP API using FastMCP."""
