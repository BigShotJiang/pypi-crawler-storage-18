import argparse
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

from ai_dev_kit import __version__


DEFAULT_ASSET_DIRS = (
    "agents",
    "commands",
    "skills",
    "protocols",
    "templates",
    "scripts",
    "dev-tools",
    "output-styles",
)


def _version_key(name: str) -> tuple:
    cleaned = name.lstrip("v")
    parts = cleaned.split(".")
    key = []
    for part in parts:
        try:
            key.append(int(part))
        except ValueError:
            key.append(-1)
    return tuple(key)


def resolve_source(explicit: str | None) -> Path | None:
    candidates: list[Path] = []
    if explicit:
        candidates.append(Path(explicit))

    env_source = os.getenv("AI_DEV_KIT_SOURCE")
    if env_source:
        candidates.append(Path(env_source))

    candidates.append(Path.cwd() / "plugins/ai-dev-kit")
    candidates.append(Path.home() / ".claude/plugins/ai-dev-kit")

    cache_root = Path.home() / ".claude/plugins/cache/ai-dev-kit/ai-dev-kit"
    if cache_root.is_dir():
        versions = sorted(
            (path for path in cache_root.iterdir() if path.is_dir()),
            key=lambda path: _version_key(path.name),
        )
        if versions:
            candidates.append(versions[-1])

    for candidate in candidates:
        if (candidate / ".claude-plugin/plugin.json").is_file():
            return candidate

    for candidate in candidates:
        if candidate.is_dir():
            return candidate

    return None


def read_plugin_version(source: Path) -> str | None:
    manifest_path = source / ".claude-plugin/plugin.json"
    if not manifest_path.is_file():
        return None
    try:
        data = json.loads(manifest_path.read_text())
    except json.JSONDecodeError:
        return None
    return data.get("version")


def write_manifest(target: Path, source: Path, source_version: str | None) -> None:
    manifest = {
        "synced_at": datetime.now(timezone.utc).isoformat(),
        "source_path": str(source),
        "source_version": source_version or "unknown",
        "cli_version": __version__,
    }
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


def sync_assets(source: Path, target: Path, verbose: bool) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for dir_name in DEFAULT_ASSET_DIRS:
        src_dir = source / dir_name
        if not src_dir.is_dir():
            if verbose:
                print(f"skip: {dir_name} (missing)")
            continue
        dest_dir = target / dir_name
        dest_dir.mkdir(parents=True, exist_ok=True)
        shutil.copytree(src_dir, dest_dir, dirs_exist_ok=True)
        if verbose:
            print(f"sync: {dir_name}")


def cmd_sync(args: argparse.Namespace) -> int:
    source = resolve_source(args.source)
    if not source:
        print("ai-dev-kit sync: unable to locate plugin assets.", file=sys.stderr)
        print("Install the plugin or set AI_DEV_KIT_SOURCE.", file=sys.stderr)
        return 2

    target = Path(args.target)
    if args.dry_run:
        print(f"source: {source}")
        print(f"target: {target}")
        print("dry-run: no files copied")
        return 0

    sync_assets(source, target, args.verbose)
    write_manifest(target, source, read_plugin_version(source))

    print(f"synced assets to {target}")
    return 0


def cmd_where(args: argparse.Namespace) -> int:
    source = resolve_source(args.source)
    if not source:
        print("ai-dev-kit where: no source found", file=sys.stderr)
        return 2
    print(source)
    return 0


def cmd_version(_: argparse.Namespace) -> int:
    print(__version__)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ai-dev-kit",
        description="AI Dev Kit helper CLI for syncing plugin assets.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    sync_parser = subparsers.add_parser("sync", help="Sync plugin assets locally.")
    sync_parser.add_argument(
        "--target",
        default=".claude/ai-dev-kit",
        help="Target directory for synced assets.",
    )
    sync_parser.add_argument(
        "--source",
        default=None,
        help="Explicit plugin source directory.",
    )
    sync_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print resolved paths without copying files.",
    )
    sync_parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print per-directory sync status.",
    )
    sync_parser.set_defaults(func=cmd_sync)

    where_parser = subparsers.add_parser("where", help="Print resolved asset source.")
    where_parser.add_argument(
        "--source",
        default=None,
        help="Explicit plugin source directory.",
    )
    where_parser.set_defaults(func=cmd_where)

    version_parser = subparsers.add_parser("version", help="Print CLI version.")
    version_parser.set_defaults(func=cmd_version)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
