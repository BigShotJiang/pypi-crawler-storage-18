"""
Contrib examples tests
"""
