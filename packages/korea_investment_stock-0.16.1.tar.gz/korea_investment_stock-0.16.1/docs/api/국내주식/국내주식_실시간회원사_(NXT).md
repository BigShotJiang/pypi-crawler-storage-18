# 국내주식 실시간회원사 (NXT)

> API 경로: `/tryitout/H0NXMBC0`

---

# WEBSOCKET국내주식 실시간회원사 (NXT)

**국내주식 실시간회원사 (NXT) 정보** **Method, URL, 실전 Domain, 모의 Domain, Format, Content-Type** Method | POST | URL | /tryitout/H0NXMBC0  
---|---|---|---  
실전 Domain  | ws://ops.koreainvestment.com:21000 | 모의 Domain | 모의투자 미지원  
실전 TR ID  | H0NXMBC0 | 모의 TR ID | 모의투자 미지원  
Format |  | Content-Type |   
  
## 개요

## 요청

### Header

**주식주문(현금[V1_국내주식-001]) 정보** **Element, 한글명, Type, Rquired, Length, Description** Element | 한글명 | Type | Required | Length | Description  
---|---|---|---|---|---  
approval_key | 웹소켓 접속키 | String | N | 286 | 실시간 (웹소켓) 접속키 발급 API(/oauth2/Approval)를 사용하여 발급받은 웹소켓 접속키  
custtype | 고객타입 | String | N | 1 | 'B : 법인  
P : 개인'  
tr_type | 거래타입 | String | N | 1 | '1 : 등록  
2 : 해제'  
content-type | 컨텐츠타입 | String | N | 1 | ' utf-8'  
  
### Body

**주식주문(현금[V1_국내주식-001]) 정보** **Element, 한글명, Type, Rquired, Length, Description** Element | 한글명 | Type | Required | Length | Description  
---|---|---|---|---|---  
tr_id | 거래ID | String | Y | 2 | H0NXMBC0 : 국내주식 주식종목회원사 (NXT)  
tr_key | 구분값 | String | Y | 12 | 종목코드 (ex 005930 삼성전자)  
  
## 응답

### Header

### Body

**주식주문(현금[V1_국내주식-001]) 정보** **Element, 한글명, Type, Rquired, Length, Description** Element | 한글명 | Type | Required | Length | Description  
---|---|---|---|---|---  
MKSC_SHRN_ISCD | 유가증권 단축 종목코드 | String | Y | 9 |   
SELN2_MBCR_NAME1 | 매도2 회원사명1 | String | Y | 16 |   
SELN2_MBCR_NAME2 | 매도2 회원사명2 | String | Y | 16 |   
SELN2_MBCR_NAME3 | 매도2 회원사명3 | String | Y | 16 |   
SELN2_MBCR_NAME4 | 매도2 회원사명4 | String | Y | 16 |   
SELN2_MBCR_NAME5 | 매도2 회원사명5 | String | Y | 16 |   
BYOV_MBCR_NAME1 | 매수 회원사명1 | String | Y | 16 |   
BYOV_MBCR_NAME2 | 매수 회원사명2 | String | Y | 16 |   
BYOV_MBCR_NAME3 | 매수 회원사명3 | String | Y | 16 |   
BYOV_MBCR_NAME4 | 매수 회원사명4 | String | Y | 16 |   
BYOV_MBCR_NAME5 | 매수 회원사명5 | String | Y | 16 |   
TOTAL_SELN_QTY1 | 총 매도 수량1 | String | Y | 8 |   
TOTAL_SELN_QTY2 | 총 매도 수량2 | String | Y | 8 |   
TOTAL_SELN_QTY3 | 총 매도 수량3 | String | Y | 8 |   
TOTAL_SELN_QTY4 | 총 매도 수량4 | String | Y | 8 |   
TOTAL_SELN_QTY5 | 총 매도 수량5 | String | Y | 8 |   
TOTAL_SHNU_QTY1 | 총 매수2 수량1 | String | Y | 8 |   
TOTAL_SHNU_QTY2 | 총 매수2 수량2 | String | Y | 8 |   
TOTAL_SHNU_QTY3 | 총 매수2 수량3 | String | Y | 8 |   
TOTAL_SHNU_QTY4 | 총 매수2 수량4 | String | Y | 8 |   
TOTAL_SHNU_QTY5 | 총 매수2 수량5 | String | Y | 8 |   
SELN_MBCR_GLOB_YN_1 | 매도거래원구분1 | String | Y | 1 |   
SELN_MBCR_GLOB_YN_2 | 매도거래원구분2 | String | Y | 1 |   
SELN_MBCR_GLOB_YN_3 | 매도거래원구분3 | String | Y | 1 |   
SELN_MBCR_GLOB_YN_4 | 매도거래원구분4 | String | Y | 1 |   
SELN_MBCR_GLOB_YN_5 | 매도거래원구분5 | String | Y | 1 |   
SHNU_MBCR_GLOB_YN_1 | 매수거래원구분1 | String | Y | 1 |   
SHNU_MBCR_GLOB_YN_2 | 매수거래원구분2 | String | Y | 1 |   
SHNU_MBCR_GLOB_YN_3 | 매수거래원구분3 | String | Y | 1 |   
SHNU_MBCR_GLOB_YN_4 | 매수거래원구분4 | String | Y | 1 |   
SHNU_MBCR_GLOB_YN_5 | 매수거래원구분5 | String | Y | 1 |   
SELN_MBCR_NO1 | 매도거래원코드1 | String | Y | 5 |   
SELN_MBCR_NO2 | 매도거래원코드2 | String | Y | 5 |   
SELN_MBCR_NO3 | 매도거래원코드3 | String | Y | 5 |   
SELN_MBCR_NO4 | 매도거래원코드4 | String | Y | 5 |   
SELN_MBCR_NO5 | 매도거래원코드5 | String | Y | 5 |   
SHNU_MBCR_NO1 | 매수거래원코드1 | String | Y | 5 |   
SHNU_MBCR_NO2 | 매수거래원코드2 | String | Y | 5 |   
SHNU_MBCR_NO3 | 매수거래원코드3 | String | Y | 5 |   
SHNU_MBCR_NO4 | 매수거래원코드4 | String | Y | 5 |   
SHNU_MBCR_NO5 | 매수거래원코드5 | String | Y | 5 |   
SELN_MBCR_RLIM1 | 매도 회원사 비중1 | String | Y | 8 |   
SELN_MBCR_RLIM2 | 매도 회원사 비중2 | String | Y | 8 |   
SELN_MBCR_RLIM3 | 매도 회원사 비중3 | String | Y | 8 |   
SELN_MBCR_RLIM4 | 매도 회원사 비중4 | String | Y | 8 |   
SELN_MBCR_RLIM5 | 매도 회원사 비중5 | String | Y | 8 |   
SHNU_MBCR_RLIM1 | 매수2 회원사 비중1 | String | Y | 8 |   
SHNU_MBCR_RLIM2 | 매수2 회원사 비중2 | String | Y | 8 |   
SHNU_MBCR_RLIM3 | 매수2 회원사 비중3 | String | Y | 8 |   
SHNU_MBCR_RLIM4 | 매수2 회원사 비중4 | String | Y | 8 |   
SHNU_MBCR_RLIM5 | 매수2 회원사 비중5 | String | Y | 8 |   
SELN_QTY_ICDC1 | 매도 수량 증감1 | String | Y | 4 |   
SELN_QTY_ICDC2 | 매도 수량 증감2 | String | Y | 4 |   
SELN_QTY_ICDC3 | 매도 수량 증감3 | String | Y | 4 |   
SELN_QTY_ICDC4 | 매도 수량 증감4 | String | Y | 4 |   
SELN_QTY_ICDC5 | 매도 수량 증감5 | String | Y | 4 |   
SHNU_QTY_ICDC1 | 매수2 수량 증감1 | String | Y | 4 |   
SHNU_QTY_ICDC2 | 매수2 수량 증감2 | String | Y | 4 |   
SHNU_QTY_ICDC3 | 매수2 수량 증감3 | String | Y | 4 |   
SHNU_QTY_ICDC4 | 매수2 수량 증감4 | String | Y | 4 |   
SHNU_QTY_ICDC5 | 매수2 수량 증감5 | String | Y | 4 |   
GLOB_TOTAL_SELN_QTY | 외국계 총 매도 수량 | String | Y | 8 |   
GLOB_TOTAL_SHNU_QTY | 외국계 총 매수2 수량 | String | Y | 8 |   
GLOB_TOTAL_SELN_QTY_ICDC | 외국계 총 매도 수량 증감 | String | Y | 4 |   
GLOB_TOTAL_SHNU_QTY_ICDC | 외국계 총 매수2 수량 증감 | String | Y | 4 |   
GLOB_NTBY_QTY | 외국계 순매수 수량 | String | Y | 8 |   
GLOB_SELN_RLIM | 외국계 매도 비중 | String | Y | 8 |   
GLOB_SHNU_RLIM | 외국계 매수2 비중 | String | Y | 8 |   
SELN2_MBCR_ENG_NAME1 | 매도2 영문회원사명1 | String | Y | 20 |   
SELN2_MBCR_ENG_NAME2 | 매도2 영문회원사명2 | String | Y | 20 |   
SELN2_MBCR_ENG_NAME3 | 매도2 영문회원사명3 | String | Y | 20 |   
SELN2_MBCR_ENG_NAME4 | 매도2 영문회원사명4 | String | Y | 20 |   
SELN2_MBCR_ENG_NAME5 | 매도2 영문회원사명5 | String | Y | 20 |   
BYOV_MBCR_ENG_NAME1 | 매수 영문회원사명1 | String | Y | 20 |   
BYOV_MBCR_ENG_NAME2 | 매수 영문회원사명2 | String | Y | 20 |   
BYOV_MBCR_ENG_NAME3 | 매수 영문회원사명3 | String | Y | 20 |   
BYOV_MBCR_ENG_NAME4 | 매수 영문회원사명4 | String | Y | 20 |   
BYOV_MBCR_ENG_NAME5 | 매수 영문회원사명5 | String | Y | 20 |   
  
## 예시

### Request

  * Data Class (Python)

### Data Class (Python)
    
    
    from dataclasses import dataclass
    
    @dataclass
    class RequestHeader:
        approval_key: Optional[str] = None    #웹소켓 접속키
        custtype: Optional[str] = None    #고객타입
        tr_type: Optional[str] = None    #거래타입
        content-type: Optional[str] = None    #컨텐츠타입
    
    @dataclass
    class RequestBody:
        tr_id: str    #거래ID
        tr_key: str    #구분값
    
    

복사하기

### Response

  * Data Class (Python)

### Data Class (Python)
    
    
    from dataclasses import dataclass
    from typing import List, Optional
    
    @dataclass
    class ResponseHeader:
    
    @dataclass
    class ResponseBody:
        MKSC_SHRN_ISCD: str    #유가증권 단축 종목코드
        SELN2_MBCR_NAME1: str    #매도2 회원사명1
        SELN2_MBCR_NAME2: str    #매도2 회원사명2
        SELN2_MBCR_NAME3: str    #매도2 회원사명3
        SELN2_MBCR_NAME4: str    #매도2 회원사명4
        SELN2_MBCR_NAME5: str    #매도2 회원사명5
        BYOV_MBCR_NAME1: str    #매수 회원사명1
        BYOV_MBCR_NAME2: str    #매수 회원사명2
        BYOV_MBCR_NAME3: str    #매수 회원사명3
        BYOV_MBCR_NAME4: str    #매수 회원사명4
        BYOV_MBCR_NAME5: str    #매수 회원사명5
        TOTAL_SELN_QTY1: str    #총 매도 수량1
        TOTAL_SELN_QTY2: str    #총 매도 수량2
        TOTAL_SELN_QTY3: str    #총 매도 수량3
        TOTAL_SELN_QTY4: str    #총 매도 수량4
        TOTAL_SELN_QTY5: str    #총 매도 수량5
        TOTAL_SHNU_QTY1: str    #총 매수2 수량1
        TOTAL_SHNU_QTY2: str    #총 매수2 수량2
        TOTAL_SHNU_QTY3: str    #총 매수2 수량3
        TOTAL_SHNU_QTY4: str    #총 매수2 수량4
        TOTAL_SHNU_QTY5: str    #총 매수2 수량5
        SELN_MBCR_GLOB_YN_1: str    #매도거래원구분1
        SELN_MBCR_GLOB_YN_2: str    #매도거래원구분2
        SELN_MBCR_GLOB_YN_3: str    #매도거래원구분3
        SELN_MBCR_GLOB_YN_4: str    #매도거래원구분4
        SELN_MBCR_GLOB_YN_5: str    #매도거래원구분5
        SHNU_MBCR_GLOB_YN_1: str    #매수거래원구분1
        SHNU_MBCR_GLOB_YN_2: str    #매수거래원구분2
        SHNU_MBCR_GLOB_YN_3: str    #매수거래원구분3
        SHNU_MBCR_GLOB_YN_4: str    #매수거래원구분4
        SHNU_MBCR_GLOB_YN_5: str    #매수거래원구분5
        SELN_MBCR_NO1: str    #매도거래원코드1
        SELN_MBCR_NO2: str    #매도거래원코드2
        SELN_MBCR_NO3: str    #매도거래원코드3
        SELN_MBCR_NO4: str    #매도거래원코드4
        SELN_MBCR_NO5: str    #매도거래원코드5
        SHNU_MBCR_NO1: str    #매수거래원코드1
        SHNU_MBCR_NO2: str    #매수거래원코드2
        SHNU_MBCR_NO3: str    #매수거래원코드3
        SHNU_MBCR_NO4: str    #매수거래원코드4
        SHNU_MBCR_NO5: str    #매수거래원코드5
        SELN_MBCR_RLIM1: str    #매도 회원사 비중1
        SELN_MBCR_RLIM2: str    #매도 회원사 비중2
        SELN_MBCR_RLIM3: str    #매도 회원사 비중3
        SELN_MBCR_RLIM4: str    #매도 회원사 비중4
        SELN_MBCR_RLIM5: str    #매도 회원사 비중5
        SHNU_MBCR_RLIM1: str    #매수2 회원사 비중1
        SHNU_MBCR_RLIM2: str    #매수2 회원사 비중2
        SHNU_MBCR_RLIM3: str    #매수2 회원사 비중3
        SHNU_MBCR_RLIM4: str    #매수2 회원사 비중4
        SHNU_MBCR_RLIM5: str    #매수2 회원사 비중5
        SELN_QTY_ICDC1: str    #매도 수량 증감1
        SELN_QTY_ICDC2: str    #매도 수량 증감2
        SELN_QTY_ICDC3: str    #매도 수량 증감3
        SELN_QTY_ICDC4: str    #매도 수량 증감4
        SELN_QTY_ICDC5: str    #매도 수량 증감5
        SHNU_QTY_ICDC1: str    #매수2 수량 증감1
        SHNU_QTY_ICDC2: str    #매수2 수량 증감2
        SHNU_QTY_ICDC3: str    #매수2 수량 증감3
        SHNU_QTY_ICDC4: str    #매수2 수량 증감4
        SHNU_QTY_ICDC5: str    #매수2 수량 증감5
        GLOB_TOTAL_SELN_QTY: str    #외국계 총 매도 수량
        GLOB_TOTAL_SHNU_QTY: str    #외국계 총 매수2 수량
        GLOB_TOTAL_SELN_QTY_ICDC: str    #외국계 총 매도 수량 증감
        GLOB_TOTAL_SHNU_QTY_ICDC: str    #외국계 총 매수2 수량 증감
        GLOB_NTBY_QTY: str    #외국계 순매수 수량
        GLOB_SELN_RLIM: str    #외국계 매도 비중
        GLOB_SHNU_RLIM: str    #외국계 매수2 비중
        SELN2_MBCR_ENG_NAME1: str    #매도2 영문회원사명1
        SELN2_MBCR_ENG_NAME2: str    #매도2 영문회원사명2
        SELN2_MBCR_ENG_NAME3: str    #매도2 영문회원사명3
        SELN2_MBCR_ENG_NAME4: str    #매도2 영문회원사명4
        SELN2_MBCR_ENG_NAME5: str    #매도2 영문회원사명5
        BYOV_MBCR_ENG_NAME1: str    #매수 영문회원사명1
        BYOV_MBCR_ENG_NAME2: str    #매수 영문회원사명2
        BYOV_MBCR_ENG_NAME3: str    #매수 영문회원사명3
        BYOV_MBCR_ENG_NAME4: str    #매수 영문회원사명4
        BYOV_MBCR_ENG_NAME5: str    #매수 영문회원사명5
    
    

복사하기