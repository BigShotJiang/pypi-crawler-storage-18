pipx install offlinepdf
