"""CLI commands for aiterm."""
