"""Terminal detection and integration."""
