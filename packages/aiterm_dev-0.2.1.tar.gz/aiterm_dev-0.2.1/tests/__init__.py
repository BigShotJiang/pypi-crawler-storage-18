"""Tests for aiterm."""
