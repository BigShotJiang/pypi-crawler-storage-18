#!/bin/bash
# Add Claude Code triggers to iTerm2 Default profile
# Run this once, then restart iTerm2

echo "=== Adding Claude Code Triggers to iTerm2 ==="
echo ""

# Note: This opens iTerm2 preferences for manual setup
# Triggers are complex to add via defaults command

cat << 'EOF'
📋 MANUAL SETUP (30 seconds):

1. Open iTerm2 → Preferences → Profiles → Default
2. Go to: Advanced tab → Triggers → Edit
3. Add these triggers (click + for each):

┌─────────────────────────────────────────────────────────────┐
│ TRIGGER 1: Show ⏳ when Claude waiting                      │
├─────────────────────────────────────────────────────────────┤
│ Regex:      ^> $                                            │
│ Action:     Set Badge                                       │
│ Parameters: ⏳                                               │
│ Instant:    ✓ (check this box)                              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ TRIGGER 2: Clear badge when Claude responds                 │
├─────────────────────────────────────────────────────────────┤
│ Regex:      ^╭─                                             │
│ Action:     Set Badge                                       │
│ Parameters: (leave empty)                                   │
│ Instant:    ✓ (check this box)                              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ TRIGGER 3: Notify on permission prompt                      │
├─────────────────────────────────────────────────────────────┤
│ Regex:      (Allow|Deny|Yes|No)\?                           │
│ Action:     Post Notification                               │
│ Parameters: Claude needs permission                         │
│ Instant:    ✓ (check this box)                              │
└─────────────────────────────────────────────────────────────┘

4. Click OK, close Preferences
5. Restart iTerm2

EOF

echo ""
echo "Opening iTerm2 Preferences..."
open "iterm2://prefs/profiles"

echo ""
echo "✅ Follow the instructions above to add triggers"
