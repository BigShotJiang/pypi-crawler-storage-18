# Context Detection Quick Reference

```
┌─────────────────────────────────────────────────────────────┐
│ AITERM - Context Detection Commands                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ DETECTION                                                   │
│ ──────────                                                  │
│ ait detect              Detect context (current dir)       │
│ ait detect <path>       Detect context for path            │
│ ait context detect      Same as above                      │
│ ait context show        Alias for detect                   │
│                                                             │
│ APPLICATION                                                 │
│ ────────────                                                │
│ ait switch              Detect + apply to terminal         │
│ ait switch <path>       Detect + apply for path            │
│ ait context apply       Same as above                      │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ DETECTED CONTEXT TYPES                                      │
│ ───────────────────────                                     │
│                                                             │
│ Type        │ Detected By           │ Profile              │
│ ────────────┼───────────────────────┼──────────────────────│
│ R Package   │ DESCRIPTION file      │ R-Dev                │
│ Python      │ pyproject.toml        │ Python-Dev           │
│ Node.js     │ package.json          │ Node-Dev             │
│ Quarto      │ _quarto.yml           │ R-Dev                │
│ MCP Server  │ mcp-server/ dir       │ AI-Session           │
│ Production  │ */production/* path   │ Production           │
│ AI Session  │ */claude-sessions/*   │ AI-Session           │
│ Dev Tools   │ .git + scripts/       │ Dev-Tools            │
│ Default     │ (fallback)            │ Default              │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ DETECTION PRIORITY                                          │
│ ───────────────────                                         │
│                                                             │
│ 1. Path-based (production, claude-sessions)                 │
│ 2. File-based (DESCRIPTION, pyproject.toml, etc.)           │
│ 3. Directory-based (mcp-server/, scripts/)                  │
│ 4. Default fallback                                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ OUTPUT FORMAT                                               │
│ ─────────────                                               │
│                                                             │
│ ┌────────────────────────────────────┐                      │
│ │ Context Detection                  │                      │
│ ├────────────────────────────────────┤                      │
│ │ Directory │ /path/to/project       │                      │
│ │ Type      │ 🐍 python              │                      │
│ │ Name      │ my-project             │                      │
│ │ Profile   │ Python-Dev             │                      │
│ │ Git Branch│ main *                 │ (* = dirty)          │
│ └────────────────────────────────────┘                      │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ CONTEXT ICONS                                               │
│ ──────────────                                              │
│                                                             │
│ 📦  R Package        🐍  Python                             │
│ 📗  Node.js          📊  Quarto                             │
│ 🔌  MCP Server       ⚠️   Production                        │
│ 🤖  AI Session       🛠️   Dev Tools                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ TERMINAL EFFECTS (iTerm2)                                   │
│ ─────────────────────────                                   │
│                                                             │
│ When `ait switch` runs:                                     │
│ 1. Profile switches (colors, fonts)                         │
│ 2. Tab title updates (project name + branch)                │
│ 3. Badge updates (context icon)                             │
│ 4. Status bar variables set                                 │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ COMMON WORKFLOWS                                            │
│ ────────────────                                            │
│                                                             │
│ Quick context check:                                        │
│   ait detect                                                │
│                                                             │
│ Enter project and switch:                                   │
│   cd ~/my-project && ait switch                             │
│                                                             │
│ Check without applying:                                     │
│   ait detect ~/some-project                                 │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ ADDING CUSTOM CONTEXTS                                      │
│ ───────────────────────                                     │
│                                                             │
│ Detection rules are in:                                     │
│   src/aiterm/context/detector.py                            │
│                                                             │
│ Add new type:                                               │
│   1. Add ContextType enum value                             │
│   2. Add detection logic in detect_context()                │
│   3. Map to profile in CONTEXT_PROFILES                     │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ SEE ALSO                                                    │
│ ─────────                                                   │
│ Main REFCARD:   docs/REFCARD.md                             │
│ Profiles:       docs/guide/profiles.md                      │
│ Triggers:       docs/guide/triggers.md                      │
└─────────────────────────────────────────────────────────────┘
```
