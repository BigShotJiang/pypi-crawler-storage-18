"""
Sync 模块 - 将 ~/.frago/ 整体作为 Git 仓库同步

将 ~/.frago/ 作为 Git 工作目录，同步到用户配置的远程仓库。
支持与 ~/.claude/ 之间的幂等性检查，确保资源不丢失。
"""

import filecmp
import os
import shutil
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

import click

# 系统级目录
FRAGO_HOME = Path.home() / ".frago"
CLAUDE_HOME = Path.home() / ".claude"

# ~/.frago/.claude/ 子目录（Git 追踪）
FRAGO_CLAUDE_DIR = FRAGO_HOME / ".claude"
FRAGO_SKILLS_DIR = FRAGO_CLAUDE_DIR / "skills"
FRAGO_RECIPES_DIR = FRAGO_HOME / "recipes"

# ~/.claude/ 运行时目录
CLAUDE_SKILLS_DIR = CLAUDE_HOME / "skills"


@dataclass
class FileChange:
    """文件变更信息"""

    type: str  # "命令", "Skill", "Recipe", "其他"
    name: str
    operation: str  # "修改", "新增", "删除"
    timestamp: Optional[datetime] = None


@dataclass
class SyncResult:
    """同步结果"""

    success: bool = False
    local_changes: list[FileChange] = field(default_factory=list)
    remote_updates: list[FileChange] = field(default_factory=list)
    pushed_to_remote: bool = False
    conflicts: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)  # 警告信息
    is_public_repo: bool = False  # 是否为 public 仓库


@dataclass
class FileConflict:
    """文件冲突信息"""

    file_path: str
    local_mtime: datetime
    remote_mtime: datetime


def _run_git(args: list[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess:
    """执行 git 命令"""
    return subprocess.run(
        ["git"] + args,
        cwd=str(cwd),
        capture_output=True,
        text=True,
        encoding='utf-8',
        check=check,
    )


def _is_git_repo(path: Path) -> bool:
    """检查目录是否是 Git 仓库"""
    return (path / ".git").exists()


def _has_uncommitted_changes(repo_dir: Path) -> bool:
    """检查是否有未提交的修改"""
    result = _run_git(["status", "--porcelain"], repo_dir, check=False)
    return bool(result.stdout.strip())


def _get_changed_files(repo_dir: Path) -> list[str]:
    """获取已修改的文件列表"""
    result = _run_git(["status", "--porcelain"], repo_dir, check=False)
    files = []
    for line in result.stdout.strip().split("\n"):
        if line:
            # 格式: XY filename 或 XY -> renamed
            parts = line[3:].split(" -> ")
            files.append(parts[-1])
    return files


def _ensure_gitignore(repo_dir: Path) -> None:
    """确保 .gitignore 文件存在且包含正确的排除规则"""
    gitignore_path = repo_dir / ".gitignore"
    gitignore_content = """# 运行时数据（不同步）
sessions/
chrome_profile/
current_run
projects/.tmp/

# Commands 目录（由 frago 自身管理，不同步）
.claude/commands/

# 配置文件（包含敏感信息）
config.json

# 环境变量文件（敏感信息）
.env
.env.*
.env.local
.env.*.local

# 系统文件
.DS_Store
__pycache__/
*.pyc
*.bak

# 视频文件
*.mp4
*.avi
*.mov
*.mkv
*.wmv
*.flv
*.webm

# 音频文件
*.wav
*.mp3
*.aac
*.flac
*.ogg
*.m4a

# 日志文件
logs/
*.log

# 压缩包和其他大文件
*.zip
*.tar
*.tar.gz
*.rar
*.7z
*.pdf
*.psd
*.ai
"""

    if not gitignore_path.exists():
        gitignore_path.write_text(gitignore_content)
    else:
        # 检查现有内容，如果缺少关键规则则追加
        existing = gitignore_path.read_text()
        needed_rules = [
            # 运行时数据
            "sessions/", "chrome_profile/", "current_run", "config.json", "projects/.tmp/", ".env",
            # Commands 目录（由 frago 自身管理）
            ".claude/commands/",
            # 系统文件
            ".DS_Store", "__pycache__/",
            # 大文件类型
            "*.mp4", "*.wav", "*.log", "logs/",
        ]
        missing = [rule for rule in needed_rules if rule not in existing]
        if missing:
            with open(gitignore_path, "a") as f:
                f.write("\n# Auto-added by frago sync\n")
                for rule in missing:
                    f.write(f"{rule}\n")

    # 自动取消对 .tmp 目录的追踪（如果已被追踪）
    _untrack_ignored_paths(repo_dir)


def _untrack_ignored_paths(repo_dir: Path) -> None:
    """取消对应被忽略但仍被追踪的路径

    解决已有设备上 .tmp、.claude/commands、.DS_Store 等已被追踪的问题。
    """
    # 需要取消追踪的路径模式
    paths_to_untrack = ["projects/.tmp/", ".claude/commands/", ".DS_Store", "**/.DS_Store"]

    for path_pattern in paths_to_untrack:
        # 检查是否有该路径被追踪
        result = _run_git(
            ["ls-files", "--", path_pattern],
            repo_dir,
            check=False
        )
        if result.returncode == 0 and result.stdout.strip():
            # 有文件被追踪，执行 git rm --cached
            _run_git(
                ["rm", "-r", "--cached", "--quiet", path_pattern],
                repo_dir,
                check=False
            )


def _parse_repo_owner_name(repo_url: str) -> tuple[Optional[str], Optional[str]]:
    """从仓库 URL 解析 owner 和 repo 名称

    支持格式:
    - git@github.com:owner/repo.git
    - https://github.com/owner/repo.git
    - https://github.com/owner/repo

    Returns:
        (owner, repo) 元组，解析失败返回 (None, None)
    """
    import re

    # SSH 格式: git@github.com:owner/repo.git
    ssh_match = re.match(r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$", repo_url)
    if ssh_match:
        return ssh_match.group(1), ssh_match.group(2)

    # HTTPS 格式: https://github.com/owner/repo.git
    https_match = re.match(r"https://github\.com/([^/]+)/([^/]+?)(?:\.git)?$", repo_url)
    if https_match:
        return https_match.group(1), https_match.group(2)

    return None, None


def _check_repo_visibility(repo_url: str) -> Optional[str]:
    """检查 GitHub 仓库的可见性

    Args:
        repo_url: 仓库 URL（SSH 或 HTTPS 格式）

    Returns:
        "public" / "private" / None（无法检测）
    """
    owner, repo = _parse_repo_owner_name(repo_url)
    if not owner or not repo:
        return None

    try:
        result = subprocess.run(
            ["gh", "api", f"repos/{owner}/{repo}", "--jq", ".visibility"],
            capture_output=True,
            text=True,
            encoding='utf-8',
            timeout=10,
        )
        if result.returncode == 0:
            visibility = result.stdout.strip().lower()
            if visibility in ("public", "private"):
                return visibility
    except (subprocess.TimeoutExpired, FileNotFoundError):
        # gh 命令超时或未安装
        pass

    return None


def _check_and_remove_tracked_env(repo_dir: Path) -> list[str]:
    """检查并移除已被 git 追踪的 .env 文件

    如果 .env 相关文件已被 git 追踪，执行 git rm --cached 移除但保留本地文件

    Args:
        repo_dir: Git 仓库目录

    Returns:
        被移除的文件列表
    """
    removed_files = []

    # 检查哪些 .env 文件被追踪
    result = _run_git(["ls-files", "--", ".env", ".env.*"], repo_dir, check=False)
    if result.returncode != 0 or not result.stdout.strip():
        return removed_files

    tracked_env_files = [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]

    for env_file in tracked_env_files:
        # 从 git 索引中移除但保留本地文件
        rm_result = _run_git(["rm", "--cached", env_file], repo_dir, check=False)
        if rm_result.returncode == 0:
            removed_files.append(env_file)

    return removed_files


def _classify_file(file_path: str) -> tuple[str, str]:
    """分类文件类型和名称

    Args:
        file_path: 相对于仓库根目录的文件路径

    Returns:
        (类型, 名称) 元组
    """
    path_obj = Path(file_path)

    if file_path.startswith(".claude/skills/"):
        # Skills 是目录：.claude/skills/frago-xxx/... -> frago-xxx
        parts = path_obj.parts
        if len(parts) >= 3:
            return ("Skill", parts[2])
        return ("Skill", path_obj.name)
    elif file_path.startswith("recipes/"):
        # Recipe：recipes/atomic/xxx.json -> xxx
        # 或：recipes/workflows/yyy/ -> yyy
        parts = path_obj.parts
        if len(parts) >= 3:
            # 提取文件名（不含扩展名）或目录名
            name = parts[2]
            if path_obj.suffix == ".json":
                name = path_obj.stem
            return ("Recipe", name)
        return ("Recipe", path_obj.name)

    return ("其他", path_obj.name)


def _get_file_change_info(repo_dir: Path, file_path: str) -> FileChange:
    """获取文件变更详细信息

    Args:
        repo_dir: Git 仓库目录
        file_path: 相对于仓库根目录的文件路径

    Returns:
        FileChange 对象
    """
    file_type, name = _classify_file(file_path)

    # 尝试从 Git 获取时间戳
    result = _run_git(["log", "--format=%aI", "-1", "--", file_path], repo_dir, check=False)
    timestamp = None

    if result.returncode == 0 and result.stdout.strip():
        try:
            # 去除时区标记 'Z' 或转换为 Python 支持的格式
            iso_time = result.stdout.strip()
            if iso_time.endswith('Z'):
                iso_time = iso_time[:-1] + '+00:00'
            timestamp = datetime.fromisoformat(iso_time)
        except ValueError:
            pass

    # 如果没有 Git 历史，使用文件系统时间
    if timestamp is None:
        full_path = repo_dir / file_path
        if full_path.exists():
            if full_path.is_file():
                mtime = os.path.getmtime(full_path)
                timestamp = datetime.fromtimestamp(mtime)
            elif full_path.is_dir():
                # 对于目录，使用目录本身的 mtime
                mtime = os.path.getmtime(full_path)
                timestamp = datetime.fromtimestamp(mtime)

    # 检测操作类型
    status_result = _run_git(["status", "--porcelain", "--", file_path], repo_dir, check=False)
    operation = "修改"
    if status_result.stdout:
        status_code = status_result.stdout[:2]
        if 'A' in status_code:
            operation = "新增"
        elif 'D' in status_code:
            operation = "删除"
        elif 'M' in status_code:
            operation = "修改"

    return FileChange(type=file_type, name=name, operation=operation, timestamp=timestamp)


def _format_table(changes: list[FileChange], title: str) -> str:
    """格式化变更表格

    Args:
        changes: 文件变更列表
        title: 表格标题

    Returns:
        格式化的表格字符串
    """
    if not changes:
        return ""

    lines = [f"\n{title}:"]
    lines.append(f"{'类型':<10} {'名称':<40} {'操作':<8} {'时间':<20}")
    lines.append("─" * 80)

    for change in changes:
        time_str = change.timestamp.strftime("%Y-%m-%d %H:%M") if change.timestamp else "—"
        lines.append(f"{change.type:<10} {change.name:<40} {change.operation:<8} {time_str:<20}")

    return "\n".join(lines)


def _init_git_repo(repo_dir: Path, remote_url: str) -> None:
    """初始化 Git 仓库"""
    repo_dir.mkdir(parents=True, exist_ok=True)

    # 初始化
    _run_git(["init"], repo_dir)

    # 添加远程
    _run_git(["remote", "add", "origin", remote_url], repo_dir, check=False)

    # 创建 .gitignore
    _ensure_gitignore(repo_dir)


def _safe_copy_tree(src: Path, dst: Path) -> None:
    """安全地复制目录树，跳过特殊文件（socket、symlink 等）"""
    dst.mkdir(parents=True, exist_ok=True)

    for item in src.iterdir():
        src_item = item
        dst_item = dst / item.name

        if src_item.is_symlink():
            # 跳过符号链接
            continue
        elif src_item.is_file():
            try:
                shutil.copy2(src_item, dst_item)
            except (OSError, IOError):
                # 跳过无法复制的文件（socket、特殊设备等）
                pass
        elif src_item.is_dir():
            _safe_copy_tree(src_item, dst_item)


def _clone_or_init_repo(repo_url: str) -> tuple[bool, str]:
    """
    克隆或初始化仓库

    如果远程仓库存在，则克隆到 ~/.frago/
    如果远程仓库为空或不存在，则初始化本地仓库

    Returns:
        (success, message)
    """
    if _is_git_repo(FRAGO_HOME):
        return True, "仓库已存在"

    # 尝试克隆到临时目录
    temp_dir = FRAGO_HOME.parent / ".frago_clone_temp"
    # 需要保留的运行时目录/文件（不包括 projects，因为它会被同步）
    runtime_items = ["sessions", "chrome_profile", "config.json", "current_run"]

    try:
        if temp_dir.exists():
            shutil.rmtree(temp_dir)

        result = subprocess.run(
            ["git", "clone", repo_url, str(temp_dir)],
            capture_output=True,
            text=True,
            encoding='utf-8',
        )

        if result.returncode == 0:
            # 克隆成功，移动内容到 ~/.frago/
            # 保留现有的运行时目录
            preserved = {}

            for item in runtime_items:
                src = FRAGO_HOME / item
                if src.exists():
                    preserved[item] = temp_dir.parent / f".frago_preserve_{item}"
                    if src.is_file():
                        shutil.copy2(src, preserved[item])
                    elif src.is_dir():
                        _safe_copy_tree(src, preserved[item])

            # 移动克隆内容
            if FRAGO_HOME.exists():
                shutil.rmtree(FRAGO_HOME)
            shutil.move(str(temp_dir), str(FRAGO_HOME))

            # 恢复运行时目录
            for item, preserved_path in preserved.items():
                target = FRAGO_HOME / item
                if preserved_path.exists():
                    if preserved_path.is_file():
                        shutil.copy2(preserved_path, target)
                        preserved_path.unlink()
                    elif preserved_path.is_dir():
                        if target.exists():
                            shutil.rmtree(target)
                        shutil.move(str(preserved_path), str(target))

            _ensure_gitignore(FRAGO_HOME)
            return True, "已从您的仓库获取资源"
        else:
            # 克隆失败，可能是空仓库，初始化本地
            _init_git_repo(FRAGO_HOME, repo_url)
            return True, "已初始化本地仓库（您的仓库为空或不存在）"

    except Exception as e:
        return False, f"初始化失败: {e}"
    finally:
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
        # 清理可能残留的 preserve 目录
        for item in runtime_items:
            preserve_path = FRAGO_HOME.parent / f".frago_preserve_{item}"
            if preserve_path.exists():
                if preserve_path.is_dir():
                    shutil.rmtree(preserve_path)
                else:
                    preserve_path.unlink()


def _files_are_identical(file1: Path, file2: Path) -> bool:
    """比较两个文件是否内容相同"""
    if not file1.exists() or not file2.exists():
        return False
    return filecmp.cmp(file1, file2, shallow=False)


def _dir_files_identical(dir1: Path, dir2: Path) -> bool:
    """比较两个目录的内容是否相同"""
    if not dir1.exists() or not dir2.exists():
        return dir1.exists() == dir2.exists()

    # 获取所有文件
    files1 = set(f.relative_to(dir1) for f in dir1.rglob("*") if f.is_file())
    files2 = set(f.relative_to(dir2) for f in dir2.rglob("*") if f.is_file())

    if files1 != files2:
        return False

    for rel_path in files1:
        if not _files_are_identical(dir1 / rel_path, dir2 / rel_path):
            return False

    return True


def _get_file_mtime(path: Path) -> float:
    """获取文件的修改时间"""
    if path.exists() and path.is_file():
        return os.path.getmtime(path)
    return 0.0


def _get_dir_latest_mtime(dir_path: Path) -> float:
    """获取目录中最新文件的修改时间"""
    if not dir_path.exists() or not dir_path.is_dir():
        return 0.0

    latest_mtime = 0.0
    for f in dir_path.rglob("*"):
        if f.is_file():
            mtime = os.path.getmtime(f)
            if mtime > latest_mtime:
                latest_mtime = mtime
    return latest_mtime


def _is_source_newer(src: Path, target: Path) -> bool:
    """检查源文件/目录是否比目标更新

    Args:
        src: 源路径
        target: 目标路径

    Returns:
        True 如果源比目标更新，或目标不存在
    """
    if not target.exists():
        return True

    if src.is_file():
        return _get_file_mtime(src) > _get_file_mtime(target)
    elif src.is_dir():
        return _get_dir_latest_mtime(src) > _get_dir_latest_mtime(target)

    return False


def _sync_claude_to_frago(result: SyncResult, dry_run: bool = False) -> None:
    """
    将 ~/.claude/ 中的修改同步到 ~/.frago/.claude/

    检查 ~/.claude/skills/frago-*
    只有当 ~/.claude/ 中的版本比 ~/.frago/.claude/ 更新时才复制
    """
    # 同步 skills
    if CLAUDE_SKILLS_DIR.exists():
        FRAGO_SKILLS_DIR.mkdir(parents=True, exist_ok=True)

        for skill_dir in CLAUDE_SKILLS_DIR.iterdir():
            if not skill_dir.is_dir():
                continue
            if not skill_dir.name.startswith("frago-"):
                continue

            target_skill_dir = FRAGO_SKILLS_DIR / skill_dir.name

            # 只有当内容不同且源目录更新时才复制
            if not _dir_files_identical(skill_dir, target_skill_dir) and _is_source_newer(skill_dir, target_skill_dir):
                if not dry_run:
                    if target_skill_dir.exists():
                        shutil.rmtree(target_skill_dir)
                    shutil.copytree(
                        skill_dir, target_skill_dir, ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
                    )
                # 收集变更信息
                file_path = f".claude/skills/{skill_dir.name}"
                change = _get_file_change_info(FRAGO_HOME, file_path)
                result.local_changes.append(change)

    # 立即显示表格
    if result.local_changes:
        click.echo(_format_table(result.local_changes, "本地修改"))


def _sync_frago_to_claude(result: SyncResult, dry_run: bool = False) -> None:
    """
    将 ~/.frago/.claude/ 的内容同步到 ~/.claude/

    从仓库获取更新后，将资源部署到 Claude Code 运行时目录
    """
    # 同步 skills
    if FRAGO_SKILLS_DIR.exists():
        CLAUDE_SKILLS_DIR.mkdir(parents=True, exist_ok=True)

        for skill_dir in FRAGO_SKILLS_DIR.iterdir():
            if not skill_dir.is_dir():
                continue
            if not skill_dir.name.startswith("frago-"):
                continue

            target_skill_dir = CLAUDE_SKILLS_DIR / skill_dir.name

            if not _dir_files_identical(skill_dir, target_skill_dir):
                if not dry_run:
                    if target_skill_dir.exists():
                        shutil.rmtree(target_skill_dir)
                    shutil.copytree(
                        skill_dir, target_skill_dir, ignore=shutil.ignore_patterns("__pycache__", "*.pyc")
                    )


def _save_local_changes(result: SyncResult, message: Optional[str], dry_run: bool = False) -> bool:
    """
    保存本地修改（git add + commit）

    Returns:
        是否有修改被保存
    """
    if not _has_uncommitted_changes(FRAGO_HOME):
        return False

    changed_files = _get_changed_files(FRAGO_HOME)

    if dry_run:
        return True

    # git add
    _run_git(["add", "."], FRAGO_HOME)

    # git commit
    commit_message = message or f"sync: 保存本地修改 ({len(changed_files)} 个文件)"
    _run_git(["commit", "-m", commit_message], FRAGO_HOME)

    return True


def _pull_remote_updates(result: SyncResult, dry_run: bool = False) -> bool:
    """
    拉取远程更新

    Returns:
        是否有冲突
    """
    if dry_run:
        return False

    # 检查是否有远程仓库
    remote_result = _run_git(["remote", "-v"], FRAGO_HOME, check=False)
    if not remote_result.stdout.strip():
        return False

    # fetch
    click.echo("正在从您的仓库获取最新资源...")
    fetch_result = _run_git(["fetch", "origin"], FRAGO_HOME, check=False)
    if fetch_result.returncode != 0:
        # 可能是新仓库，没有远程分支
        return False

    # 检查是否有远程分支
    branch_result = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], FRAGO_HOME, check=False)
    current_branch = branch_result.stdout.strip() or "main"

    # 检查远程分支是否存在
    remote_branch_result = _run_git(
        ["rev-parse", "--verify", f"origin/{current_branch}"], FRAGO_HOME, check=False
    )
    if remote_branch_result.returncode != 0:
        return False

    # 保存当前 HEAD，用于后续比较
    old_head_result = _run_git(["rev-parse", "HEAD"], FRAGO_HOME, check=False)
    old_head = old_head_result.stdout.strip() if old_head_result.returncode == 0 else None

    # 尝试 rebase
    rebase_result = _run_git(["rebase", f"origin/{current_branch}"], FRAGO_HOME, check=False)

    if rebase_result.returncode != 0:
        # 有冲突
        _run_git(["rebase", "--abort"], FRAGO_HOME, check=False)

        # 获取冲突文件
        result.conflicts = _get_changed_files(FRAGO_HOME)
        return True

    # 获取新的 HEAD
    new_head_result = _run_git(["rev-parse", "HEAD"], FRAGO_HOME, check=False)
    new_head = new_head_result.stdout.strip() if new_head_result.returncode == 0 else None

    # 只有当 HEAD 真的移动了（有新提交），才收集更新信息
    if old_head and new_head and old_head != new_head:
        # 使用 git diff --name-status 获取文件变更
        diff_result = _run_git(
            ["diff", "--name-status", f"{old_head}..{new_head}"],
            FRAGO_HOME,
            check=False
        )
        for line in diff_result.stdout.strip().split("\n"):
            if line:
                parts = line.split("\t")
                if len(parts) >= 2:
                    file_path = parts[1]
                    change = _get_file_change_info(FRAGO_HOME, file_path)
                    result.remote_updates.append(change)

        # 立即显示表格
        if result.remote_updates:
            click.echo(_format_table(result.remote_updates, "从您的仓库获取的更新"))
    else:
        click.echo("远程无新的变化")

    return False


def _push_to_remote(result: SyncResult, dry_run: bool = False) -> bool:
    """
    推送到远程

    Returns:
        是否成功
    """
    if dry_run:
        return True

    # 检查是否有远程仓库
    remote_result = _run_git(["remote", "-v"], FRAGO_HOME, check=False)
    if not remote_result.stdout.strip():
        return True

    # 检查是否有提交
    log_result = _run_git(["log", "--oneline", "-1"], FRAGO_HOME, check=False)
    if not log_result.stdout.strip():
        return True

    # 获取当前分支
    branch_result = _run_git(["rev-parse", "--abbrev-ref", "HEAD"], FRAGO_HOME, check=False)
    current_branch = branch_result.stdout.strip() or "main"

    # 推送
    click.echo("正在推送到您的仓库...")
    push_result = _run_git(["push", "-u", "origin", current_branch], FRAGO_HOME, check=False)

    if push_result.returncode == 0:
        result.pushed_to_remote = True
        return True
    else:
        result.errors.append(f"推送失败: {push_result.stderr}")
        return False


def sync(
    repo_url: Optional[str] = None,
    message: Optional[str] = None,
    dry_run: bool = False,
    no_push: bool = False,
) -> SyncResult:
    """
    主同步函数

    流程:
    1. 安全检查 - 保存本地修改，同步 ~/.claude/ 的修改
    2. 获取远程更新 - 拉取并处理冲突
    3. 更新本地 Claude Code - 同步到 ~/.claude/
    4. 推送到您的仓库 - 如果允许推送

    Args:
        repo_url: 远程仓库 URL（首次使用时需要）
        message: 自定义提交信息
        dry_run: 仅预览不执行
        no_push: 不推送到远程

    Returns:
        SyncResult 包含同步结果
    """
    result = SyncResult()

    try:
        # 0. 配置 gh credential helper（如果 gh 已安装）
        # 这允许 git 使用 gh 的 OAuth token 进行 HTTPS 认证
        if not dry_run:
            try:
                subprocess.run(
                    ["gh", "auth", "setup-git"],
                    capture_output=True,
                    timeout=10,
                )
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass  # gh 未安装或超时，忽略

        # 1. 确保仓库存在
        if not _is_git_repo(FRAGO_HOME):
            if not repo_url:
                result.errors.append("未配置同步仓库，请先使用 frago sync --set-repo <url> 配置")
                return result

            success, msg = _clone_or_init_repo(repo_url)
            if not success:
                result.errors.append(msg)
                return result
            click.echo(msg)

        # 确保 .gitignore 存在
        _ensure_gitignore(FRAGO_HOME)

        # 检查并移除已追踪的 .env 文件
        if not dry_run:
            removed_env_files = _check_and_remove_tracked_env(FRAGO_HOME)
            if removed_env_files:
                warning_msg = f"已从 git 追踪中移除敏感文件: {', '.join(removed_env_files)}（本地文件已保留）"
                result.warnings.append(warning_msg)
                click.echo(f"⚠️  {warning_msg}")

        # 检查仓库可见性
        actual_repo_url = repo_url
        if not actual_repo_url:
            # 从 git remote 获取 URL
            remote_result = _run_git(["remote", "get-url", "origin"], FRAGO_HOME, check=False)
            if remote_result.returncode == 0:
                actual_repo_url = remote_result.stdout.strip()

        # 自动将 SSH URL 转换为 HTTPS URL（配合 gh credential helper）
        if actual_repo_url and actual_repo_url.startswith("git@github.com:"):
            import re
            ssh_match = re.match(r'git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$', actual_repo_url)
            if ssh_match:
                owner, repo = ssh_match.group(1), ssh_match.group(2)
                https_url = f"https://github.com/{owner}/{repo}.git"
                if not dry_run:
                    # 更新 git remote URL
                    _run_git(["remote", "set-url", "origin", https_url], FRAGO_HOME, check=False)
                    click.echo(f"已将仓库 URL 从 SSH 转换为 HTTPS: {https_url}")
                actual_repo_url = https_url

        if actual_repo_url:
            visibility = _check_repo_visibility(actual_repo_url)
            if visibility == "public":
                result.is_public_repo = True
                warning_msg = "警告：当前同步仓库是 public 仓库，敏感信息可能被公开。建议使用 private 仓库。"
                result.warnings.append(warning_msg)
                click.echo(f"⚠️  {warning_msg}")

        # 1. 安全检查 - 同步 ~/.claude/ 的修改到 ~/.frago/.claude/
        click.echo("检查本地资源修改...")
        _sync_claude_to_frago(result, dry_run)

        # 1b. 保存本地修改
        if result.local_changes or _has_uncommitted_changes(FRAGO_HOME):
            click.echo("保存本地修改...")
            _save_local_changes(result, message, dry_run)

        # 2. 获取远程更新
        has_conflicts = _pull_remote_updates(result, dry_run)

        if has_conflicts:
            result.errors.append("检测到资源冲突，请手动解决后重新同步")
            # 返回但不标记失败，让用户看到冲突信息
            return result

        # 3. 更新本地 Claude Code
        click.echo("更新 Claude Code 资源...")
        _sync_frago_to_claude(result, dry_run)

        # 4. 推送到您的仓库
        if not no_push:
            _push_to_remote(result, dry_run)

        result.success = True

    except subprocess.CalledProcessError as e:
        result.errors.append(f"Git 操作失败: {e.stderr}")
    except PermissionError as e:
        result.errors.append(f"权限错误: {e}")
    except Exception as e:
        result.errors.append(f"同步失败: {e}")

    return result
