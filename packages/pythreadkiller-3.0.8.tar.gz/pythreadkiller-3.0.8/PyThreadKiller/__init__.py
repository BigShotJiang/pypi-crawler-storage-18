from .main import PyThreadKiller
