# lolbin

A command-line interface tool for managing pastes on [paste.lol](http://paste.lol), a service of omg.lol.

## Features

- **Create/Update Paste** - Allows you to create or update a paste with a specified title and content.
- **List Pastes** - Lists all your pastes along with their titles and the time they were last modified.
- **Show Paste** - Displays the content of a specific paste by its title.
- **Delete Paste** - Deletes a specific paste by its title.
- **Help Message** - Provides usage instructions for the tool.
- **Debug Mode** - Prints the action to be performed, the paste name, username, and bearer token (but does not actually perform the action).

# Installation

To install the tool, run the following command:

```
$ 
```

## Configuration

To configure the tool, create a file `~/.config/lolbin/config.toml` with the following content:

```toml
username = "your_username"
bearer_token = "your_bearer_token"
```

You can obtain a bearer token by logging in to the <omg.lol> website, in [you account](https://home.omg.lol/account), at the end of the page, section 'API Key'.

## Example of Use

1. To create/update a paste:
    ```
    $ echo "My awesome content" | lolbin --paste my_awesome_paste
    ```
    If you want to paste content from a file, use the `--file` flag:
    ```
    $ echo "My awesome content" > my_content.txt
    $ lolbin --paste --file my_content.txt my_awesome_paste
    ```

    The `--past` part is optional, as the lolbin can deduct the action from the input.

    ```
    $ cat my_content.txt | lolbin --paste my_awesome_paste

2. To list your pastes:
    ```
    $ lolbin --list
     - my_awesome_paste (10s ago)
    ```

3. To show the content of a specific paste:
    ```
    $ lolbin --show my_awesome_paste
    My awesome content
    ```

    As with the `--paste` command, the `--show` command can be used without the `--show` part, since the lolbin can deduct the action from the input.

    ```
    $ lolbin my_awesome_paste
    My awesome content
    ```

4. To delete a specific paste:
    ```
    $ lolbin --delete my_awesome_paste
    ```

5. To edit a specific paste:
    ```
    $ lolbin --edit my_awesome_paste
    ```

    The editor will be opened with the content of the paste. The content will be replaced with the edited content.
    The editor is determined by the `EDITOR` environment variable. If it is not set, the vim is used.

6. For help:
    ```
    $ lolbin --help
    ```

7. To run in debug mode, use the `--debug` flag with any command:
    ```
    $ lolbin --debug --list
    ```

## Requirements

- Python 3.10 or higher
- requests library
- tomli library
