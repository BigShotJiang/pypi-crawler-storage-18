from __future__ import annotations

import datetime
import json
import logging
import uuid
from contextlib import suppress
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Generic,
    Optional,
    TypeAlias,
    TypeGuard,
    TypeVar,
    Union,
)
from urllib.parse import urlencode, urlparse

from apscheduler.jobstores.base import JobLookupError
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from starlette.websockets import WebSocket

from pyview.async_stream_runner import AsyncStreamRunner
from pyview.events import InfoEvent
from pyview.meta import PyViewMeta
from pyview.template.render_diff import calc_diff
from pyview.uploads import UploadConfig, UploadConstraints, UploadManager
from pyview.vendor.flet.pubsub import PubSub, PubSubHub

logger = logging.getLogger(__name__)


if TYPE_CHECKING:
    from .instrumentation import InstrumentationProvider
    from .live_view import LiveView


pub_sub_hub = PubSubHub()

T = TypeVar("T")


def is_connected(socket: LiveViewSocket[T]) -> TypeGuard[ConnectedLiveViewSocket[T]]:
    return socket.connected


class UnconnectedSocket(Generic[T]):
    context: T
    live_title: Optional[str] = None
    connected: bool = False

    def allow_upload(
        self,
        upload_name: str,
        constraints: UploadConstraints,
        auto_upload: bool = False,
        progress: Optional[Callable] = None,
        external: Optional[Callable] = None,
        entry_complete: Optional[Callable] = None,
    ) -> UploadConfig:
        return UploadConfig(
            name=upload_name,
            constraints=constraints,
            autoUpload=auto_upload,
            progress_callback=progress,
            external_callback=external,
            entry_complete_callback=entry_complete,
        )


class ConnectedLiveViewSocket(Generic[T]):
    context: T
    live_title: Optional[str] = None
    pending_events: list[tuple[str, Any]]
    upload_manager: UploadManager
    prev_rendered: Optional[dict[str, Any]] = None

    def __init__(
        self,
        websocket: WebSocket,
        topic: str,
        liveview: LiveView,
        scheduler: AsyncIOScheduler,
        instrumentation: InstrumentationProvider,
    ):
        self.websocket = websocket
        self.topic = topic
        self.liveview = liveview
        self.instrumentation = instrumentation
        self.scheduled_jobs = set()
        self.connected = True
        self.pub_sub = PubSub(pub_sub_hub, topic)
        self.pending_events = []
        self.upload_manager = UploadManager()
        self.stream_runner = AsyncStreamRunner(self)
        self.scheduler = scheduler

    @property
    def meta(self) -> PyViewMeta:
        return PyViewMeta()

    async def subscribe(self, topic: str):
        await self.pub_sub.subscribe_topic_async(topic, self._topic_callback_internal)

    async def broadcast(self, topic: str, message: Any):
        await self.pub_sub.send_all_on_topic_async(topic, message)

    async def _topic_callback_internal(self, topic, message):
        await self.send_info(InfoEvent(topic, message))

    def schedule_info(self, event, seconds):
        id = f"{self.topic}:{event}"
        self.scheduler.add_job(
            self.send_info, args=[event], id=id, trigger="interval", seconds=seconds
        )
        self.scheduled_jobs.add(id)

    def schedule_info_once(self, event, seconds=None):
        job_id = f"{self.topic}:once:{uuid.uuid4().hex}"
        self.scheduler.add_job(
            self._send_info_once,
            args=[job_id, event],
            id=job_id,
            trigger="date",
            run_date=datetime.datetime.now() + datetime.timedelta(seconds=seconds or 0),
            misfire_grace_time=None,
        )
        self.scheduled_jobs.add(job_id)

    def diff(self, render: dict[str, Any]) -> dict[str, Any]:
        if self.prev_rendered:
            diff = calc_diff(self.prev_rendered, render)
        else:
            diff = render

        self.prev_rendered = render
        return diff

    async def _send_info_once(self, job_id: str, event: InfoEvent):
        """Wrapper for one-time info sends that cleans up the job ID after execution"""
        await self.send_info(event)
        self.scheduled_jobs.discard(job_id)

    async def send_info(self, event: InfoEvent):
        await self.liveview.handle_info(event, self)
        r = await self.liveview.render(self.context, self.meta)
        resp = [None, None, self.topic, "diff", self.diff(r.tree())]

        try:
            await self.websocket.send_text(json.dumps(resp))
        except Exception:
            for id in list(self.scheduled_jobs):
                logger.debug("Removing scheduled job %s", id)
                try:
                    self.scheduler.remove_job(id)
                except Exception:
                    logger.warning("Failed to remove scheduled job %s", id, exc_info=True)

    async def push_patch(self, path: str, params: Optional[dict[str, Any]] = None):
        if params is None:
            params = {}

        # or "replace"
        kind = "push"

        to = path
        if params:
            to = to + "?" + urlencode(params)

        message = [
            None,
            None,
            self.topic,
            "live_patch",  # or "live_redirect"
            {
                "kind": kind,
                "to": to,
            },
        ]

        # TODO another way to marshall this
        # Create a copy to avoid mutating the caller's dict
        params_for_handler = {k: [v] for k, v in params.items()}

        # Parse string to ParseResult for type consistency
        parsed_url = urlparse(to)
        await self.liveview.handle_params(parsed_url, params_for_handler, self)
        try:
            await self.websocket.send_text(json.dumps(message))
        except Exception:
            logger.warning("Error sending patch message", exc_info=True)

    async def push_navigate(self, path: str, params: Optional[dict[str, Any]] = None):
        """Navigate to a different LiveView without full page reload"""
        if params is None:
            params = {}
        await self._navigate(path, params, kind="push")

    async def replace_navigate(self, path: str, params: Optional[dict[str, Any]] = None):
        """Navigate to a different LiveView, replacing current history entry"""
        if params is None:
            params = {}
        await self._navigate(path, params, kind="replace")

    async def _navigate(self, path: str, params: dict[str, Any], kind: str):
        """Internal navigation helper"""
        to = path
        if params:
            to = to + "?" + urlencode(params)

        message = [
            None,
            None,
            self.topic,
            "live_redirect",
            {
                "kind": kind,
                "to": to,
            },
        ]

        try:
            await self.websocket.send_text(json.dumps(message))
        except Exception:
            logger.warning("Error sending navigation message", exc_info=True)

    async def redirect(self, path: str, params: Optional[dict[str, Any]] = None):
        """Redirect to a new location with full page reload"""
        if params is None:
            params = {}
        to = path
        if params:
            to = to + "?" + urlencode(params)

        message = [
            None,
            None,
            self.topic,
            "redirect",
            {"to": to},
        ]

        try:
            await self.websocket.send_text(json.dumps(message))
        except Exception:
            logger.warning("Error sending redirect message", exc_info=True)

    async def push_event(self, event: str, value: dict[str, Any]):
        self.pending_events.append((event, value))

    def allow_upload(
        self,
        upload_name: str,
        constraints: UploadConstraints,
        auto_upload: bool = False,
        progress: Optional[Callable] = None,
        external: Optional[Callable] = None,
        entry_complete: Optional[Callable] = None,
    ) -> UploadConfig:
        return self.upload_manager.allow_upload(
            upload_name, constraints, auto_upload, progress, external, entry_complete
        )

    async def close(self):
        self.connected = False
        for id in list(self.scheduled_jobs):
            with suppress(JobLookupError):
                self.scheduler.remove_job(id)
        await self.pub_sub.unsubscribe_all_async()

        with suppress(Exception):
            self.upload_manager.close()

        with suppress(Exception):
            await self.liveview.disconnect(self)


LiveViewSocket: TypeAlias = Union[ConnectedLiveViewSocket[T], UnconnectedSocket[T]]
