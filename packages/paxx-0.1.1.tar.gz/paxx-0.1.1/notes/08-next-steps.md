# Next Steps: Deployment-Ready Apps

## The Insight

Infrastructure services have different lifecycles than the app:

- **App**: Deploy on every release, ephemeral containers, easy rollback
- **Database**: Provision once, persistent, migrated carefully, never redeployed
- **Redis/Cache**: Provision once, may be ephemeral or persistent depending on use

Paxx should not try to orchestrate all of this. Cloud platforms (Fly, AWS, Railway) already handle provisioning databases better than a CLI tool ever could.

---

## Philosophy: Deployment-Ready, Not Deployment-Managing

> **Paxx scaffolds apps that are trivially deployable. The user picks their platform and provisions infrastructure there.**

The Dockerfile is the universal interface. Every platform knows how to run a container. Paxx generates one good Dockerfile and lets you take it anywhere.

---

## What Paxx Should Do

### 1. 12-Factor App Compliance

The generated app separates config from code via environment variables. This is the key thing that makes apps deployable *anywhere*.

- `DATABASE_URL`, `REDIS_URL`, `SECRET_KEY` all come from env
- No hardcoded hosts, ports, or credentials
- Settings validated at startup with Pydantic

### 2. Production Dockerfile

A well-crafted multi-stage Dockerfile that works on any container platform:

```dockerfile
# Build stage
FROM python:3.12-slim as builder
WORKDIR /app
COPY --from=ghcr.io/astral-sh/uv:latest /uv /usr/local/bin/uv

COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev

COPY . .

# Runtime stage
FROM python:3.12-slim
WORKDIR /app

COPY --from=builder /app/.venv /app/.venv
COPY --from=builder /app .

ENV PATH="/app/.venv/bin:$PATH"

EXPOSE 8000
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--workers", "4"]
```

This works on Fly, ECS, Cloud Run, Kubernetes, or any VPS with Docker.

### 3. Health Check Endpoint

Already wired up at `/health` for platform readiness/liveness probes:

```python
@app.get("/health")
async def health():
    return {"status": "ok"}
```

### 4. Graceful Shutdown

Proper signal handling so containers can be killed cleanly:

```python
@app.on_event("shutdown")
async def shutdown():
    # Close DB connections, finish in-flight requests
    await engine.dispose()
```

### 5. Migrations as a Separate Concern

Migrations should run *before* deploy, not during container startup:

```bash
# In CI/CD pipeline, before deploying new containers:
uv run alembic upgrade head

# Or as a one-off command on the platform:
fly ssh console -C "uv run alembic upgrade head"
```

Container startup should be fast and idempotent. Mixing migrations into startup creates race conditions with multiple replicas.

### 6. Documentation (DEPLOY.md)

A generated `DEPLOY.md` explaining concepts and common patterns:

- What environment variables are required
- How to run migrations
- Example commands for popular platforms (Fly, Railway, ECS)
- How to set up a database (links to platform docs, not automation)

---

## What Paxx Should NOT Do

- **Wrap platform CLIs** (`fly deploy`, `aws ecs`, etc.) - they're already good
- **Provision infrastructure** (databases, Redis, queues) - platforms do this better
- **Generate platform-specific configs** (fly.toml, task definitions) - these change frequently and are well-documented by the platforms themselves
- **Detect services and orchestrate them** - over-engineering for a scaffolder

---

## 12-Factor Analysis: Current State

| Factor | Name | Status | Notes |
|--------|------|--------|-------|
| I | Codebase | ✅ Done | Git-ready with .gitignore |
| II | Dependencies | ✅ Done | pyproject.toml + uv.lock, explicit and isolated |
| III | Config | ✅ Done | Pydantic Settings, all config from env vars |
| IV | Backing Services | ✅ Done | DATABASE_URL as attached resource |
| V | Build/Release/Run | ⚠️ Partial | Need production Dockerfile |
| VI | Processes | ✅ Done | Stateless request handling, no sticky sessions |
| VII | Port Binding | ✅ Done | Uvicorn self-contained, no external server needed |
| VIII | Concurrency | ⚠️ Docs | Works (uvicorn --workers), needs documentation |
| IX | Disposability | ⚠️ Partial | Shutdown exists, startup doesn't validate deps |
| X | Dev/Prod Parity | ⚠️ Partial | SQLite default, should be Postgres via Docker |
| XI | Logs | ❌ Missing | structlog in deps but not configured |
| XII | Admin Processes | ⚠️ Docs | `paxx shell` exists, needs documentation |

### Key Gaps

**Logs (Factor XI)** - Critical gap. structlog is a dependency but never configured. Need:
- `core/logging.py` with structlog setup
- JSON output to stdout (not files)
- `LOG_LEVEL` setting
- Request context (request_id) in all log entries

**Disposability (Factor IX)** - Health check returns "healthy" without verifying dependencies:
```python
# Current (bad)
@app.get("/health")
async def health():
    return {"status": "healthy"}  # Lies if DB is down

# Should be
@app.get("/health")
async def health(db: AsyncSession = Depends(get_db)):
    await db.execute(text("SELECT 1"))  # Actually check
    return {"status": "healthy"}
```

**Dev/Prod Parity (Factor X)** - SQLite for dev, Postgres for prod invites bugs. Docker-compose with Postgres closes this gap.

---

## Implementation Plan

### Already Done
- [x] Full project scaffolding (`paxx bootstrap`)
- [x] Feature system (`paxx feature create`, `paxx feature add`)
- [x] Dev server (`paxx start`)
- [x] Database migrations (`paxx db`)
- [x] Settings via environment variables (12-factor)

### To Do

#### Phase 1: Docker Templates
- [ ] Create `Dockerfile.jinja` (production multi-stage build)
- [ ] Create `Dockerfile.dev.jinja` (dev with hot-reload, mounted volumes)
- [ ] Create `docker-compose.yml.jinja` (local dev: app + Postgres)
- [ ] Create `.dockerignore.jinja`
- [ ] Make Docker the default, add `--minimal` flag to skip

#### Phase 2: 12-Factor Compliance
- [ ] Configure structured logging (structlog to stdout, JSON format)
- [ ] Add `log_level` and `log_format` to settings
- [ ] Improve `/health` endpoint (verify DB connectivity, return 503 if unhealthy)
- [ ] Add startup validation (fail fast if DB unreachable)
- [ ] Add graceful shutdown handler (already partially done)

#### Phase 3: Production Readiness
- [ ] Create `DEPLOY.md.jinja` with deployment guidance
- [ ] Document migration strategy (run before deploy, not in container startup)
- [ ] Document admin processes (`paxx shell`, one-off tasks)
- [ ] Document concurrency (`uvicorn --workers`)

#### Phase 4: Dev Experience Polish
- [ ] `paxx docker up` convenience command (thin wrapper around docker compose)
- [ ] Ensure hot-reload works in Docker dev container

---

## Design Decision: Default vs Minimal

Two modes, not a config wizard:

```bash
paxx bootstrap myproject           # Full: includes Docker, Postgres-ready
paxx bootstrap myproject --minimal # Minimal: SQLite, no Docker
```

**Default (full):**
- Docker dev environment
- PostgreSQL in docker-compose
- Production Dockerfile
- Health endpoint

**Minimal:**
- SQLite for simplicity
- No Docker files
- For learning, scripts, or "I'll add my own infra"

The generated code is *theirs* - they can delete the Dockerfile, swap Postgres for SQLite, or add their own platform configs. That's the escape hatch.

---

## Notes

**Why this approach:**
- Paxx stays focused on scaffolding, not deployment orchestration
- Users learn their platform instead of learning paxx's abstractions
- Less maintenance burden - no need to track every platform's API changes
- The Dockerfile is the universal interface that works everywhere
