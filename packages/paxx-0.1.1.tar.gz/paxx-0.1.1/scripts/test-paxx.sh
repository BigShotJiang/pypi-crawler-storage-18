cd tmp
rm -rf test-project
uv run paxx bootstrap test-project

cd test-project
uv sync --all-extras

# Use paxx from parent project's venv directly (runs in current directory context)
PAXX="../../.venv/bin/paxx"

$PAXX feature add example_products

$PAXX db status

$PAXX db migrate "add example_products"
$PAXX db upgrade

$PAXX db status

# migration down
$PAXX db downgrade

$PAXX db status

# migration up
$PAXX db upgrade

$PAXX db status

# remove and add feature again
rm -rf features/example_products

$PAXX feature add example_products

$PAXX feature create test_feature

open http://127.0.0.1:8000/docs

$PAXX start





