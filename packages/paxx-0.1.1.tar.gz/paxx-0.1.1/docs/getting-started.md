# Getting Started

## Prerequisites

- Python 3.12+
- [uv](https://docs.astral.sh/uv/) package manager (recommended) or pip

## Installation

=== "uv"

    ```bash
    uv add paxx
    ```

=== "pip"

    ```bash
    pip install paxx
    ```

## Create Your First Project

```bash
paxx bootstrap myproject
```

This creates a new directory `myproject/` with the complete project structure.

### Options

```bash
# With a description
paxx bootstrap myproject --description "My awesome API"

# In a specific directory
paxx bootstrap myproject --output-dir /path/to/projects

# With author name
paxx bootstrap myproject --author "Your Name"
```

## Set Up the Project

```bash
cd myproject
uv sync --all-extras
```

This installs all dependencies including:

- FastAPI
- SQLAlchemy (async)
- Pydantic Settings
- Alembic
- Uvicorn
- Development tools (pytest, ruff, mypy)

## Start the Development Server

```bash
uv run paxx start
```

Your API is now running at [http://127.0.0.1:8000](http://127.0.0.1:8000).

- **API Documentation**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) (Swagger UI)
- **Alternative docs**: [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc) (ReDoc)

## Create Your First Feature

Features are domain modules that contain your business logic. Create one with:

```bash
uv run paxx feature create users
```

This generates:

```
features/users/
├── __init__.py
├── config.py      # Router prefix and tags
├── models.py      # SQLAlchemy models
├── schemas.py     # Pydantic schemas
├── services.py    # Business logic
└── routes.py      # API endpoints
```

## Set Up the Database

After defining your models, create and apply migrations:

```bash
# Create a migration
uv run paxx db migrate "add users table"

# Apply the migration
uv run paxx db upgrade
```

## Next Steps

- Read the [CLI Reference](cli-reference.md) for all available commands
- Understand the [Project Structure](project-structure.md)
- Follow the [Tutorial](tutorial.md) to build a complete feature
