# paxx

**Python Async API** - a domain-oriented web framework scaffolding tool built on top of FastAPI.

paxx generates plain, readable code using well-known libraries (FastAPI, SQLAlchemy, Pydantic, Alembic) directly - no wrapper abstractions, just a solid starting point for domain-driven FastAPI applications.

## Why paxx?

- **No magic** - Generated code uses FastAPI, SQLAlchemy, and Pydantic directly
- **No lock-in** - After bootstrapping, your project has no dependency on paxx
- **Domain-driven** - Features organized by business capability, not technical layer
- **Convention over configuration** - Sensible defaults, but everything is customizable

## Quick Start

```bash
# Install paxx
pip install paxx

# Create a new project
paxx bootstrap myproject

# Start developing
cd myproject
uv sync --all-extras
uv run paxx start
```

Visit [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs) to see your API documentation.

## What's Generated?

When you run `paxx bootstrap`, you get a fully configured FastAPI project with:

- **Application factory pattern** with proper startup/shutdown handling
- **Pydantic settings** for configuration management
- **SQLAlchemy async** setup with session management
- **Alembic** migrations pre-configured
- **Domain-driven structure** with a `features/` directory for your business logic

## Next Steps

- [Getting Started](getting-started.md) - Installation and your first project
- [CLI Reference](cli-reference.md) - All available commands
- [Project Structure](project-structure.md) - Understanding the generated code
- [Tutorial](tutorial.md) - Build a complete feature step by step
