# examples/usage.py
"""
Run with: python -m examples.usage  (recommended) or python examples/usage.py after making examples a package
"""
import importlib

# явный импорт установленного пакета через importlib
pkg = importlib.import_module('graph_algorithms')

kruskal_mst = getattr(pkg, 'kruskal_mst')
prim_mst = getattr(pkg, 'prim_mst')
find_hamiltonian_cycle = getattr(pkg, 'find_hamiltonian_cycle')

def example_mst():
    edges = [(0,1,1.5), (0,2,1.0), (1,3,2.0), (2,3,1.0)]
    n = 4
    mst_k, w_k = kruskal_mst(n, edges)
    mst_p, w_p = prim_mst(n, edges)
    print("Kruskal MST edges:", mst_k, "weight:", w_k)
    print("Prim MST edges   :", mst_p, "weight:", w_p)

def example_hamilton():
    adj = {
        0: [1,2],
        1: [0,2,3],
        2: [0,1,3],
        3: [1,2]
    }
    cycle = find_hamiltonian_cycle(adj)
    print("Hamiltonian cycle (if any):", cycle)

if __name__ == "__main__":
    example_mst()
    example_hamilton()