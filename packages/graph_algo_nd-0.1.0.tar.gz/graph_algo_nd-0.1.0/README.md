```markdown
# graph-algo-nd

Лёгкая библиотека с реализациями алгоритмов работы с графами:
- MST: Kruskal и Prim
- Hamiltonian cycle: поиск одного гамильтонова цикла (бэктрекинг, только для маленьких графов)

Установка (локально, для разработки)
1. Создайте виртуальное окружение
   - python -m venv venv
   - source venv/bin/activate  (Linux/macOS) или venv\Scripts\activate (Windows)
2. Установите зависимости:
   - pip install -U pip build twine
   - pip install networkx matplotlib
3. Установите пакет в editable режиме (для разработки):
   - pip install -e .

Примеры использования
```python
from graph_algorithms import kruskal_mst, prim_mst, find_hamiltonian_cycle

# MST: список рёбер (u, v, weight), вершины предполагаются 0..n-1
edges = [(0,1,1.5), (0,2,1.0), (1,3,2.0), (2,3,1.0)]
n = 4

mst_edges_k, weight_k = kruskal_mst(n, edges)
mst_edges_p, weight_p = prim_mst(n, edges)
print("Kruskal weight:", weight_k)
print("Prim weight:", weight_p)

# Hamiltonian (не взвешенный граф): adjacency dict {v: [neighs]}
adj = {
    0: [1,2],
    1: [0,2,3],
    2: [0,1,3],
    3: [1,2]
}
cycle = find_hamiltonian_cycle(adj)
print("Hamiltonian cycle:", cycle)
```

Запуск тестов
1. Установите pytest и networkx (если ещё не установлены):
   - pip install pytest networkx
2. Запустите:
   - pytest -q

Сборка и публикация (Test PyPI, затем PyPI)
1. Установите инструменты сборки:
   - pip install build twine
2. Соберите дистрибутивы:
   - python -m build
3. Загрузите на Test PyPI (рекомендуется сначала протестировать там):
   - twine upload --repository testpypi dist/*
   (Потребуется аккаунт/testpypi token)
4. Установите из Test PyPI для проверки:
   - pip install -i https://test.pypi.org/simple/ graph-algo-nd
5. После проверки публикуйте на PyPI:
   - twine upload dist/*

Структура репозитория (основное)
- graph_algorithms/
  - mst/kruskal.py
  - mst/prim.py
  - hamilton/hamiltonian.py
  - __init__.py
- tests/
  - test_mst.py
  - test_hamilton.py
- examples/usage.py
- pyproject.toml, setup.cfg, MANIFEST.in, LICENSE, README.md
- .github/workflows/ci.yml

Лицензия: MIT
```