from typing import List, Tuple
import heapq
from collections import defaultdict

def prim_mst(n: int, edges: List[Tuple[int, int, float]]):
    """
    Prim's algorithm (using a min-heap).
    Args:
        n: number of vertices (0..n-1)
        edges: list of (u, v, weight)
    Returns:
        mst_edges: list of edges in MST
        total_weight: sum of weights
    """
    if n == 0:
        return [], 0.0

    # build adjacency list
    adj = defaultdict(list)
    for u, v, w in edges:
        adj[u].append((w, v))
        adj[v].append((w, u))

    visited = [False] * n
    mst = []
    total = 0.0
    # start from vertex 0
    visited[0] = True
    heap = []
    for w, v in adj[0]:
        heapq.heappush(heap, (w, 0, v))
    while heap and len(mst) < n - 1:
        w, u, v = heapq.heappop(heap)
        if visited[v]:
            continue
        visited[v] = True
        mst.append((u, v, w))
        total += w
        for nw, to in adj[v]:
            if not visited[to]:
                heapq.heappush(heap, (nw, v, to))

    # If graph is disconnected, we may not have n-1 edges
    return mst, total