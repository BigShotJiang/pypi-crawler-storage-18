from typing import List, Tuple

class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n

    def find(self, x: int) -> int:
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]

    def union(self, x: int, y: int) -> bool:
        rx = self.find(x)
        ry = self.find(y)
        if rx == ry:
            return False
        if self.rank[rx] < self.rank[ry]:
            self.parent[rx] = ry
        else:
            self.parent[ry] = rx
            if self.rank[rx] == self.rank[ry]:
                self.rank[rx] += 1
        return True

def kruskal_mst(n: int, edges: List[Tuple[int, int, float]]):
    """
    Kruskal's algorithm.

    Args:
        n: number of vertices (vertices are assumed 0..n-1)
        edges: list of (u, v, weight)

    Returns:
        mst_edges: list of edges in MST [(u,v,w), ...]
        total_weight: sum of weights
    """
    # sort edges by weight
    edges_sorted = sorted(edges, key=lambda e: e[2])
    uf = UnionFind(n)
    mst = []
    total = 0.0
    for u, v, w in edges_sorted:
        if uf.union(u, v):
            mst.append((u, v, w))
            total += w
        if len(mst) == n - 1:
            break
    return mst, total