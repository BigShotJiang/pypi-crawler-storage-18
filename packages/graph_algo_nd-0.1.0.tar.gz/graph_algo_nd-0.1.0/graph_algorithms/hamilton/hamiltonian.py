from typing import Dict, List, Optional

def find_hamiltonian_cycle(adj: Dict[int, List[int]]) -> Optional[List[int]]:
    """
    Simple backtracking search for a Hamiltonian cycle.
    Works only for small graphs (n up to ~10-12 depending on structure).

    Args:
        adj: adjacency dict mapping vertex -> list of neighbors (undirected)

    Returns:
        A list of vertices in cycle order (e.g. [0,1,2,0]) if found, otherwise None.
    """
    if not adj:
        return None
    n = len(adj)
    start = next(iter(adj))
    path = [start]
    visited = set([start])

    def backtrack(current):
        if len(path) == n:
            # check closing edge
            if start in adj[current]:
                return True
            return False
        for nei in adj.get(current, []):
            if nei not in visited:
                visited.add(nei)
                path.append(nei)
                if backtrack(nei):
                    return True
                path.pop()
                visited.remove(nei)
        return False

    if backtrack(start):
        # close cycle by appending start at end (optional)
        return path + [start]
    return None