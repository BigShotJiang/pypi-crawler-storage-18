from graph_algorithms import find_hamiltonian_cycle

def test_hamiltonian_found():
    adj = {
        0: [1,2],
        1: [0,2,3],
        2: [0,1,3],
        3: [1,2]
    }
    cycle = find_hamiltonian_cycle(adj)
    assert cycle is not None
    # check all vertices used exactly once (except start repeated at end)
    used = cycle[:-1]
    assert set(used) == set(adj.keys())
    assert len(used) == len(adj)

def test_hamiltonian_not_found():
    # star graph with center 0 and leaves 1,2,3 - no Hamiltonian cycle
    adj = {
        0: [1,2,3],
        1: [0],
        2: [0],
        3: [0]
    }
    cycle = find_hamiltonian_cycle(adj)
    assert cycle is None