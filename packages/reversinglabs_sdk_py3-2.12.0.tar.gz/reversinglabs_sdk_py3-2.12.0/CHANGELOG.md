ReversingLabs SDK Change Log
=========

v1.2.2 (2022-10-19)
-------------------

#### Deprecations

- **a1000** module:
  - Deprecated the `get_results`, `upload_sample_and_get_results`, `get_classification`, `reanalyze_samples`, `get_extracted_files`, `advanced_search` and `advanced_search_aggregated` methods.
- Dropped support for Python 2.7
  - From this version on, the Python 2 version of the SDK (https://pypi.org/project/reversinglabs-sdk-py2/) will no longer be maintained.

#### Improvements

- **a1000** module:
  - Added the `get_summary_report_v2`, `upload_sample_and_get_summary_report_v2`, `get_detailed_report_v2`, `get_classification_v3`, `reanalyze_samples_v2`, `list_extracted_files_v2`, `list_extracted_files_v2_aggregated`, `check_sample_removal_status_v2`, `advanced_search_v2` and `advanced_search_v2_aggregated` methods.
  - The added methods correspond to the new v2 and v3 versions of A1000 API-s.

#### Bugfixes

- **helper** module:
  - Catching the `binascii.Error` in the `validate_hashes` function.


  
v1.3.0 (2022-11-16)
-------------------

#### Improvements

- **ticloud** module:
  - Added the `DeleteFile`, `ReanalyzeFile`, `CertificateIndex`, `CertificateThumbprintSearch`, `NewMalwareFilesFeed`, `MWPChangeEventsFeed` and `NewMalwareURIFeed` classes.
  - Several feed classes now extend the new `ContinuousFeed` parent class.
- **a1000** module:
  - Added the `upload_sample_from_url`, `check_submitted_url_status`, `get_submitted_url_report`, `upload_sample_from_url_and_get_report`, `get_summary_report_v2`, `get_user_tags_for_a_sample`, `post_user_tags`, `delete_user_tags`, `create_pdf_report`, `check_pdf_report_creation`, `download_pdf_report`, `get_titanium_core_report_for_a_sample_v2`, `create_dynamic_analysis_report`, `check_dynamic_analysis_report_status`, `download_dynamic_analysis_report, set_classification`, `delete_classification`, `get_yara_rulesets_on_the_appliance_v2`, `get_yara_ruleset_contents`, `get_yara_ruleset_matches_v2`, `create_or_update_yara_ruleset`, `delete_yara_ruleset`, `enable_or_disable_yara_ruleset`, `get_yara_ruleset_synchronization_time`, `update_yara_ruleset_synchronization_time`, `start_or_stop_yara_local_retro_scan`, `get_yara_local_retro_scan_status`, `start_or_stop_yara_cloud_retro_scan`, `get_yara_cloud_retro_scan_status` and `list_containers_for_hashes` methods.
  - Added the `archive_password` and `rl_cloud_sandbox_platform` parameters into the `upload_sample_from_path` and `upload_sample_from_file` methods.
- **helper** module:
  - Added the `BadGatewayError` exception class.
  - Adjusted the message of the `TooManyRequestsError` exception class to reflect quota limit breached situations.



v1.4.0 (2023-01-04)
-------------------

#### Improvements

- **ticloud** module:
  - Added the `ImpHashSimilarity`, `YARAHunting` and `YARARetroHunting` classes.
- **a1000** module:
  - Added the `network_url_report`, `network_domain_report`, `network_ip_addr_report`, `network_ip_to_domain`, `network_urls_from_ip` and `network_files_from_ip` methods.
  - Added the `ticloud` parameter into the `advanced_search_v2` and `advanced_search_v2_aggregated` methods.



v2.0.0 (2023-02-27)
-------------------

#### Improvements

- Added a new module for using the **ReversingLabs Cloud Deep Scan** service called **clouddeepscan**.
- **clouddeepscan** module:
  - Class `CloudDeepScan` methods: `upload_sample`, `fetch_submission`, `fetch_submission_history`, `download_report`



v2.1.0 (2023-03-31)
-------------------

#### Deprecations

- **ticloud** module:
  - Deprecated the `ranalyze_samples` method of the `ReanalyzeFile` class. **This method will be removed** from the SDK in the future **September 2023.** release. A new method called `reanalyze_samples` of the same `ReanalyzeFile` class should be used instead.

#### Improvements

- **ticloud** module:
  - Added the `FileReputationUserOverride`, `DomainThreatIntelligence` and `IPThreatIntelligence` classes.
  - Included an adjustable `results_per_page` parameter into several methods that perform paging automatically.
  - The `detonate_sample` method of the `DynamicAnalysis` class now also accepts `"macos11"` as the `platform` parameter.
  - The `detonate_sample` method of the `DynamicAnalysis` class now accepts the `internet_simulation` parameter.
- **a1000** module:
  - All sample submission methods now also accept `"macos_11"` as the `rl_cloud_sandbox_platform` parameter.
- **tiscale** module:
  - Added the `list_processing_tasks`, `get_processing_task_info`, `delete_processing_task`, `delete_multiple_tasks` and `get_yara_id` methods.
  - Added support for the `custom_token`, `user_data` and `custom_data` parameters in existing sample upload methods.

#### Bugfixes
- **a1000** module:
  - Leaving the `fields` parameter in the `get_titanium_core_report_v2` method as None now results in requesting all the available fields instead of throwing an exception.



v2.1.1 (2023-04-05)
-------------------

#### Improvements

- **ticloud** module:
  - Added the `FileAnalysisNonMalicious` and `DataChangeSubscription` classes.
  - The `FileUpload` class methods now also use `subscribe`, `archive_type` and `archive_passoword` parameters.

---



v2.1.2 (2023-05-15)
-------------------

#### Improvements

- **a1000** module:
  - Added paging parameters to the Network Threat Intelligence methods: `network_ip_to_domain`, `network_urls_from_ip` and `network_files_from_ip`
  - Added auto paging versions of the same methods: `network_ip_to_domain_aggregated`, `network_urls_from_ip_aggregated` and `network_files_from_ip_aggregated`

---



v2.2.0 (2023-06-23)
-------------------

#### Improvements

- **ticloud** module:
  - Added the `NewMalwarePlatformFiltered` class.

---



v2.3.0 (2023-09-29)
-------------------

#### Improvements

- **ticloud** module:
  - Added the `CustomerUsage`, `NetworkReputation`, `NetworkReputationUserOverride` and `TAXIIRansomwareFeed` classes.
  - The `DynamicAnalysis` class methods now also support `windows11` and `linux` as a platform.
  - The `DynamicAnalysis` class methods now also support detonating .zip file archives and fetching the analysis results for the same.
- **a1000** module:
  - Added the `advanced_search_v3` and `advanced_search_v3_aggregated` methods.

#### Deprecations

- **a1000** module:
  - Deprecated the `advanced_search_v2` and `advanced_search_v2_aggregated` methods.

#### Removals

- **ticloud** module:
  - Removed the `ReanalyzeFile.ranalyze_samples` method.
- **a1000** module:
  - Removed the `get_results`, `upload_sample_and_get_results`, `get_classification`, `reanalyze_samples`, `get_extracted_files`, `advanced_search` and `advanced_search_aggregated` methods.

---


v2.4.0 (2023-12-29) - [YANKED]
-------------------

**Note:** Contains breaking changes in the `ExpressionSearch` class. We recommend using **v2.4.2**

#### Improvements

- **ticloud** module:
  - Added the `NewFilesFirstScan`, `NewFilesFirstAndRescan`, `FilesWithDetectionChanges`, `CvesExploitedInTheWild`, `NewExploitOrCveSamplesFoundInWildHourly`, `NewExploitAndCveSamplesFoundInWildDaily`, `NewWhitelistedFiles`, `ChangesWhitelistedFiles`, `MalwareFamilyDetection`, `ExpressionSearch`, `VerticalFeedStatistics` and `VerticalFeedSearch` classes.
  - The following changes were made to the `DynamicAnalysis` class:
    - Added `windows11` and `linux` to available Dynamic Analysis platforms.
    - Added the `detonate_url` method.
    - The `get_dynamic_analysis_results` method now supports `url` analysis results.

- Added TitaniumCloud API codes to the README for better correspondence and orientation.
---


v2.4.1 (2024-01-11) - [YANKED]
-------------------

**Note:** Contains breaking changes in the `ExpressionSearch` class. We recommend using **v2.4.2**

#### Improvements

- **ticloud** module:
  - The `get_dynamic_analysis_results` method of the `DynamicAnalysis` class now also supports using a URL-s SHA-1 hash for fetching the URL dynamic analysis results. 

- Error handling: Custom error classes now also carry the original response object. Users can now reach the original status code, error message and all other response properties using the caught error's `response_object` property. 
---


v2.4.2 (2024-01-22)
-------------------

All changes are calculated against **v2.3.0**

#### Improvements
- **ticloud** module:
  - Added the `NewFilesFirstScan`, `NewFilesFirstAndRescan`, `FilesWithDetectionChanges`, `CvesExploitedInTheWild`, `NewExploitOrCveSamplesFoundInWildHourly`, `NewExploitAndCveSamplesFoundInWildDaily`, `NewWhitelistedFiles`, `ChangesWhitelistedFiles`, `MalwareFamilyDetection`, `ExpressionSearch`, `VerticalFeedStatistics` and `VerticalFeedSearch` classes.
  - The following changes were made to the `DynamicAnalysis` class:
    - Added `windows11` and `linux` to available Dynamic Analysis platforms.
    - Added the `detonate_url` method.
    - The `get_dynamic_analysis_results` method now supports fetching the URL dynamic analysis results using the URL string or its SHA-1 hash as a parameter.

- Added TitaniumCloud API codes to the README for better correspondence and orientation.
- Error handling: Custom error classes now also carry the original response object. Users can now reach the original status code, error message and all other response properties using the caught error's `response_object` property. 


v2.4.3 (2024-02-07)
-------------------

#### Improvements
- Python package dependencies are now set to the following values:
  - `requests>=2.28.2`
  - `urllib3>=1.26.14`


v2.5.0 (2024-03-30)
-------------------

#### Removals
- **a1000** module:
  - Removed the `a1000.A1000.advanced_search_v2` method.

#### Improvements
- Added unit tests.
- Added CI/CD (Actions) workflows for running unit tests and publishing the package to PyPI.
- **ticloud** module:
  - `md5` and `sha256` can now be used in `DynamicAnalysis.get_dynamic_analysis_results` for fetching sample analysis results.


v2.5.1 (2024-04-02)
-------------------

#### Improvements
- Updated the README with an example of error handling.


v2.5.2 (2024-04-30)
-------------------

#### Improvements
- **a1000** module:
  - The function for checking file analysis status is now public. It is called `file_analysis_status`.


v2.5.3 (2024-05-08)
-------------------

#### Bugfixes
- **ticloud** module:
  - The classification override parameter in the `override_classification` method of the `FileReputationUserOverride` now works as expected due to a payload fix.

#### Removals
- **clouddeepscan** module:
  - Dropped support for the clouddeepscan module. As of this version, the module is removed from the SDK.


v2.5.4 (2024-05-09)
-------------------

#### Improvements
- Updated the Python package dependencies to:
  - `requests>=2.31.0`
  - `urllib3>=2.0.7`


v2.5.5 (2024-05-15)
-------------------

#### Bugfixes
- **a1000** module:
  - Changed the `risk_score` parameter's type hint from `str` to `int` in `set_classification` method's docstring.


v2.5.6 (2024-05-23)
-------------------

#### Improvements
- **a1000** module:
  - Reintroduced the `a1000.A1000.advanced_search_v2` method. This method will remain in the DEPRECATED state until its permanent removal from the SDK. The permanent removal date will be announced in the CHANGELOG's "Scheduled removals" section. In the meantime, the use of `a1000.A1000.advanced_search_v3` is highly advised.


v2.6.0 (2024-06-28)
-------------------

#### Improvements
- **ticloud** module:
  - Added the following text to the docstrings for the `ticloud.URLThreatIntelligence.get_url_analysis_feed_from_date` and `ticloud.URLThreatIntelligence.get_url_analysis_feed_from_date_aggregated` methods: "It is possible to list analyses up to 90 days into the past."
  - Added the `get_objects_aggregated` method to the `TAXIIRansomwareFeed` class.
  - The `ticloud.DynamicAnalysis.detonate_sample` method now has a `sample_hash` parameter that accepts SHA-1, SHA-256 and MD5 hashes. See the Deprecations section for more info.
  - The `ticloud.DynamicAnalysis.detonate_sample` method now has a `sample_name` parameter that enable the user to define a custom sample name.
  - Added the option to fetch all results in auto paging (aggregating) methods. From now on, in such methods, setting the `max_results` parameter to None returns all results.

- **a1000** module:
  - The `get_yara_ruleset_matches_v2` method now also accepts a list u of multiple ruleset names as the `ruleset_name` parameter.
  - Added the `upload_sample_and_get_detailed_report_v2` method.
  - Added the option to fetch all results in auto paging (aggregating) methods. From now on, in such methods, setting the `max_results` parameter to None returns all results.

#### Deprecations
- **ticloud** module:
  - The `sample_sha1` parameter of the `ticloud.DynamicAnalysis.detonate_sample` method is deprecated and will be removed in 6 months. Use the `sample_hash` parameter instead.


v2.6.1 (2024-07-03)
-------------------

#### Improvements
- Added more unit tests for all currently available modules.


v2.6.2 (2024-07-10)
-------------------

#### Improvements
- Added more unit tests for all currently available modules.


v2.6.3 (2024-07-17)
-------------------

#### Bugfixes
- **a1000** module:
  - Changed the `upload_sample_from_url` method's name to `submit_url_for_analysis`.


v2.6.4 (2024-07-24)
-------------------

#### Bugfixes
- **ticloud** module:
  - Implemented the default user agent string in embedded `FileAnalysis` calls.


v2.7.0 (2024-09-25)
-------------------

#### Improvements
- **ticloud** module:
  - `rha1_type` is now an optional parameter in the `RHA1FunctionalSimilarity` and `RHA1Analitics` class methods. The user can decide if it should be passed in manually or calculated automatically.
  - `detonate_url` and `detonate_sample` methods of the `DynamicAnalysis` class now accept optional parameters through `**optional_parameters`. Optional parameters should be passed in as key-value pairs (kwargs). Named parameters `internet_simulation` and `sample_name` are now deprecated and should be used through `**optional_parameters`.
  - Added the `AdvancedActions` class containing the `enriched_file_analysis` method which returns a File Analysis report enriched with Dynamic Analysis.

#### Deprecations
- **ticloud** module:
  - Parameters `internet_simulation` and `sample_name` of the `DynamicAnalysis.detonate_sample` method are now deprecated. Use `**optional_parameters` instead.


v2.7.1 (2024-10-09)
-------------------

#### Improvements
- **fie** module:
  - Introduced a new module called **fie** which corresponds to the ReversingLabs **File Investigation Engine (FIE)** service. 
  - The module currently has one class with four methods for sending files to FIE for analysis and fetching the short classification or more detailed analysis reports.


v2.7.2 (2024-12-06)
-------------------

#### Improvements
- **ticloud** module:
  - Corrected a typo in the docstrings and the README.


v2.8.0 (2024-12-24)
-------------------

#### Removals
- **ticloud** module:
  - Removed the deprecated `sample_sha1` parameter from the `ticloud.DynamicAnalysis.detonate_sample` method.

#### Improvements
- **ticloud** module:
  - Parameters `internet_simulation` and `sample_name` from the `ticloud.DynamicAnalysis.detonate_sample` method are now used through the `**optiona_parameters` key-value parameter instead of as individual named parameters.


v2.8.1 (2025-02-17) - [YANKED]
-------------------

#### Improvements
- Defined the latest version (2.32.3) of the requests library as a dependency. urllib3 was removed as an explicit dependency for this project.
- Python 3.9 is now defined as the oldest version of Python supported by this project.

v2.8.2 (2025-02-17)
-------------------

#### Improvements
- Defined the latest version (2.32.3) of the requests library as a dependency. urllib3 was removed as an explicit dependency for this project.
- Python 3.9 is now defined as the oldest version of Python supported by this project.

v2.8.3 (2025-02-21)
-------------------

#### Improvements
- Added the Spectra Assure badge to the Readme file.


### ReversingLabs SDK Cookbook changes
#### Improvements
- **Scenarios and Workflows** notebooks:
  - Added the `download_advanced_search_matches_a1000.ipynb`, `download_advanced_search_matches_titaniumcloud.ipynb`, `download_yara_retro_matches_a1000.ipynb` and `download_yara_retro_matches_titaniumcloud.ipynb` notebooks.

- **Command line tools and scripts**:
  - Added the `cyber_defense_alliance.py` command line tool.


v2.9.0 (2025-03-31)
-------------------

#### Improvements
- **ticloud** module:
  - Added the `TAXIIFeed` class which will replace the `TAXIIRansomwareFeed` class in all its use cases in the future.

- **advanced** module:
  - Created a new module called `advanced`. This module will hold various actions and scenarios that include multiple platforms and APIs.
  - The `AdvancedActions` class was moved from the `ticloud` module into `advanced`.
  - The `SpectraAssureScenarios` and `SpectraAssureClient` enable the user to perform actions that combine the **ReversingLabs Spectra Assure** platform with TitaniumCloud and A1000.

- The user agent string now also carries the class and method name.

### ReversingLabs SDK Cookbook changes
#### Improvements
- **TitaniumCloud** notebooks:
  - The `taxii_ransomware_feed.ipynb` notebook was replaced with `taxii_feed.ipynb`.

- **Scenarios and Workflows** notebooks:
  - Added the `advanced_search_using_network_indicators.ipynb` notebook.



v2.10.0 (2025-06-24)
-------------------

#### Improvements
- **a1000** module:
  - Added the `submit_file_from_handle`, `submit_file_from_path`, `submit_file_and_get_summary_report`, `submit_file_and_get_detailed_report`, `submit_url` and `submit_url_and_get_report` methods.

- **ticloud** module:
  - Added additional result filtering options to the `TAXIIFeed.get_objects_aggregated` method.

#### Deprecations
- **a1000** module:
  - Deprecated the `upload_sample_from_path`, `upload_sample_from_file`, `submit_url_for_analysis`, `submit_url_for_analysis_and_get_report`, `upload_sample_and_get_summary_report_v2` and `upload_sample_and_get_detailed_report_v2` methods.

- **ticloud** module:
  - Deprecated the `TAXIIRansomwareFeed` class.


### ReversingLabs SDK Cookbook changes
### Improvements
- **Scenarios and Workflows** notebooks:
  - Added the `TAXII_data_filtering` notebook.



v2.11.0 (2025-10-01)
-------------------

#### Improvements
- **a1000** module:
  - Android12 is now supported ass a dynamic analysis platform.
  - Added `get_yara_repositories`, `get_yara_repositories_aggregated`, `create_yara_repository`, `update_yara_repository`, `delete_yara_repository`, `publish_all_yara_rulesets`, `publish_single_yara_ruleset`,  `set_yara_update_interval`, `reset_yara_update_interval` and `run_yara_update` functions.
 
- **ticloud** module:
  - Added bulk report support for `URLThreatIntelligence`, `DomainThreatIntelligence` and `IPThreatIntelligence`.
  - Added archive passwords support for `FileUpload`.
  - Added the `IocDataRetrieval` class.

- **advanced** module:
  - Added the `download_yara_matches` method in the `AdvancedActions` class.


### ReversingLabs SDK Cookbook changes
### Improvements
- **Scenarios and Workflows** notebooks:
  - Fixed minor issues in the `advanced_search_using_network_indicators.ipynb` notebook.


v2.11.4 (2025-10-21)
-------------------
#### Improvements
- **tiscale** module:
  - Added the `large_file` argument to upload methods. If this argument is set to `True`, the method will use the `MultipartEncoder` from `requests-toolbelt` to upload a large file to Spectra Detect in order not to run out of memory.

- `requests-toolbelt` added as an optional dependency under the `large_files` key.


v2.12.0 (2025-12-24)
-------------------
#### Improvements
- **ticloud** module:
  - Added the `SupplyChainIoCFeed` class.
  - Added the `get_hash_index` method to the `ImpHashSimilarity` class.
  - Added the `get_company_information`, `create_user`, `list_users`, `retrieve_user`, `update_user`, `reset_password`, `list_licenses`, `create_limit`, `read_license_limits`, `read_user_limits`, `update_limit`, `delete_limit`, `list_email_alerts` and `create_or_update_alert` methods to the `CustomerUsage` class.

#### Removals
- **ticloud** module:
  - Removed the `TAXIIRansomwareFeed` and `ExpressionSearch` classes.
    - Use `TAXIIFeed` instead of `TAXIIRansomwareFeed`.
- **a1000** module:
  - Removed the `upload_sample_from_path`, `upload_sample_from_file`, `submit_url_for_analysis`, `submit_url_for_analysis_and_get_report`, `upload_sample_and_get_summary_report_v2`, `upload_sample_and_get_detailed_report_v2`, `advanced_search_v2` and `advanced_search_v2_aggregated` methods.


### ReversingLabs SDK Cookbook changes
### Improvements
- **Spectra Intelligence** notebooks:
  - Added the `indicators_of_compromise.ipynb` notebook.
  - Added the `supply_chain_ioc_feed.ipynb` notebook.

- **Scenarios and Workflows** notebooks:
  - Added the `yara_extended_threat_hunting.ipynb` notebook.

### Removals
- **Spectra Intelligence** notebooks:
  - Removed The `ExpressionSearch` example from the `search.ipynb` notebook.


-------------------



Starting with ReversingLabs SDK version 2.8.0, the [ReversingLabs SDK Cookbook](https://github.com/reversinglabs/reversinglabs-sdk-cookbook) project's release cycle and versioning are closely tied to this project.  
This changelog will also be keeping track of changes made to the ReversingLabs SDK Cookbook project.

