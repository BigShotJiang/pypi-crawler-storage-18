# Copyright 2024 ScriptChat contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tempfile
import unittest
from pathlib import Path

from prompt_toolkit.document import Document

from scriptchat.core.commands import AppState
from scriptchat.core.config import Config, ModelConfig, ProviderConfig
from scriptchat.core.conversations import Conversation, Message
from scriptchat.ui.app import AnsiLexer, ScriptChatUI


def make_state():
    provider = ProviderConfig(
        id="ollama",
        type="ollama",
        api_url="http://localhost:11434/api",
        api_key="",
        models=[ModelConfig(name="llama3", context=1000)],
        streaming=True,
        headers={},
        default_model="llama3",
    )
    cfg = Config(
        api_url="http://localhost:11434/api",
        api_key="",
        conversations_dir=Path("."),
        exports_dir=None,
        enable_streaming=False,
        system_prompt=None,
        default_provider="ollama",
        default_model="llama3",
        default_temperature=0.7,
        timeout=5,
        file_confirm_threshold_bytes=40_000,
        log_level="INFO",
        log_file=None,
        providers=[provider],
    )
    convo = Conversation(
        id="202401010101_llama3_chat",
        provider_id="ollama",
        model_name="llama3",
        temperature=0.7,
        system_prompt=None,
        messages=[
            Message(role="system", content="sys"),
            Message(role="user", content="hi"),
            Message(role="assistant", content="hello"),
            Message(role="echo", content="note"),
        ],
        tokens_in=10,
        tokens_out=5,
        context_length_configured=1000,
        context_length_used=100,
    )
    return AppState(config=cfg, current_conversation=convo, client=None, conversations_root=Path("."), file_registry={}, folder_registry={})


class AppHelperTests(unittest.TestCase):
    def test_status_bar_and_prompt_prefix(self):
        state = make_state()
        ui = object.__new__(ScriptChatUI)
        ui.state = state
        ui.thinking = True
        ui.thinking_dots = 1
        ui.prompt_message = "Enter"

        status = ui._get_status_bar()
        # Status bar returns list of (style, text) tuples
        full_text = ''.join(text for _, text in status)
        self.assertIn("ollama/llama3", full_text)
        self.assertIn("Thinking", full_text)
        self.assertEqual(ui._get_prompt_prefix(), "Enter ")

    def test_build_conversation_text_and_lexer(self):
        state = make_state()
        ui = object.__new__(ScriptChatUI)
        ui.state = state

        text = ui._build_conversation_text()
        self.assertIn("[user]", text)
        self.assertIn("[assistant]", text)
        self.assertIn("note", text)

        lexer = AnsiLexer()
        doc = Document(text)
        line_fn = lexer.lex_document(doc)
        # ensure at least first line returns formatted text list
        self.assertTrue(line_fn(0))

    def test_history_navigation_and_apply(self):
        ui = object.__new__(ScriptChatUI)
        ui.input_history = []
        ui.input_history_index = None

        class FakeBuffer:
            def __init__(self):
                self.document = None

            def set_document(self, document):
                self.document = document

        ui.input_buffer = FakeBuffer()

        ui._append_history("first")
        ui._append_history("second")
        self.assertEqual(ui.input_history, ["first", "second"])

        ui._history_previous()
        self.assertEqual(ui.input_history_index, 1)
        self.assertEqual(ui.input_buffer.document.text, "second")

        ui._history_previous()
        self.assertEqual(ui.input_buffer.document.text, "first")

        ui._history_next()
        self.assertEqual(ui.input_buffer.document.text, "second")

    def test_conversation_arrow_scroll_bindings_exist(self):
        # Ensure key bindings are registered and filter is set to conversation buffer focus
        state = make_state()
        ui = ScriptChatUI(state)
        keys = [binding.keys for binding in ui.kb.bindings]
        flat_keys = [k for sub in keys for k in sub]
        self.assertIn("up", flat_keys)
        self.assertIn("down", flat_keys)

    def test_scriptchat_ui_initialization_and_cleanup(self):
        state = make_state()

        class DummyClient:
            def cleanup(self):
                self.cleaned = True

        state.client = DummyClient()

        # Instantiate full UI to exercise layout/key setup
        ui = ScriptChatUI(state)
        ui.add_system_message("note")
        self.assertIn("note", ui.conversation_buffer.text)

        ui._cleanup()
        self.assertTrue(hasattr(state.client, "cleaned"))

    def test_input_history_persistence(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            conv_dir = root / "conversations"
            conv_dir.mkdir(parents=True, exist_ok=True)
            state = make_state()
            state.config.conversations_dir = conv_dir
            ui = ScriptChatUI(state)
            ui._append_history("first")
            ui._append_history("second")

            # Reload UI and ensure history was persisted
            ui2 = ScriptChatUI(state)
            self.assertEqual(ui2.input_history, ["first", "second"])

    def test_multiline_history_persistence(self):
        """Multi-line messages should be preserved as single entries in history."""
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            conv_dir = root / "conversations"
            conv_dir.mkdir(parents=True, exist_ok=True)
            state = make_state()
            state.config.conversations_dir = conv_dir
            ui = ScriptChatUI(state)

            # Add a multi-line entry
            multiline_entry = "line one\nline two\nline three"
            ui._append_history(multiline_entry)
            ui._append_history("single line")

            # Reload UI and ensure multi-line entry was preserved as one entry
            ui2 = ScriptChatUI(state)
            self.assertEqual(len(ui2.input_history), 2)
            self.assertEqual(ui2.input_history[0], multiline_entry)
            self.assertEqual(ui2.input_history[1], "single line")

    def test_history_json_format(self):
        """History file should be stored in JSON format."""
        import json
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            conv_dir = root / "conversations"
            conv_dir.mkdir(parents=True, exist_ok=True)
            state = make_state()
            state.config.conversations_dir = conv_dir
            ui = ScriptChatUI(state)

            ui._append_history("entry one")
            ui._append_history("entry\nwith\nnewlines")

            # Verify file is valid JSON
            history_path = root / "history.json"
            self.assertTrue(history_path.exists())
            content = history_path.read_text(encoding="utf-8")
            entries = json.loads(content)
            self.assertEqual(entries, ["entry one", "entry\nwith\nnewlines"])

    def test_markdown_to_ansi_conversion(self):
        state = make_state()
        ui = object.__new__(ScriptChatUI)
        ui.state = state

        # Test bold conversion
        result = ui._markdown_to_ansi("This is **bold** text")
        self.assertIn("\033[1m", result)  # ANSI bold
        self.assertIn("bold", result)
        self.assertNotIn("**", result)

        # Test code conversion
        result = ui._markdown_to_ansi("Use `code` here")
        self.assertIn("\033[96m", result)  # ANSI cyan
        self.assertIn("code", result)
        self.assertNotIn("`", result)

        # Test header conversion
        result = ui._markdown_to_ansi("## My Header")
        self.assertIn("\033[1m", result)  # ANSI bold
        self.assertIn("My Header", result)
        self.assertNotIn("##", result)

        # Test multiple header levels
        result = ui._markdown_to_ansi("# H1\n## H2\n### H3")
        self.assertEqual(result.count("\033[1m"), 3)
        self.assertNotIn("#", result)

        # Test mixed formatting
        result = ui._markdown_to_ansi("**bold** and `code`")
        self.assertIn("\033[1m", result)
        self.assertIn("\033[96m", result)

        # Test no conversion for plain text
        result = ui._markdown_to_ansi("plain text")
        self.assertEqual(result, "plain text")


if __name__ == "__main__":
    unittest.main()
