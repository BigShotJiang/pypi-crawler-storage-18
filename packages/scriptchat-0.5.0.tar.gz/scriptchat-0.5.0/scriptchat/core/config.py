# Copyright 2024 ScriptChat contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Configuration loading and management for ScriptChat."""

import logging
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import toml


# Alias must be alphanumeric with underscore, dash, or dot. No slashes allowed.
ALIAS_PATTERN = re.compile(r'^[a-zA-Z0-9_.\-]+$')


@dataclass
class ModelConfig:
    """Configuration for a single model."""
    name: str
    context: int | None = None  # Optional; context window size in tokens
    max_tokens: int | None = None  # Optional; max output tokens (important for thinking models)
    reasoning_levels: list[str] | None = None  # Optional; available reasoning levels for this model
    reasoning_default: str | None = None  # Optional; default reasoning level for this model
    alias: str | None = None  # Optional; short alias for /model command (alphanumeric, underscore, dash, dot only)
    skip_prompt_cache_param: bool = False  # Set true if model doesn't support prompt_cache_max_len parameter


@dataclass
class ProviderConfig:
    """Configuration for a model provider."""
    id: str
    type: str  # e.g., "ollama", "openai-compatible"
    api_url: str
    api_key: str = ""
    models: list[ModelConfig] = None
    streaming: bool = True
    headers: dict = None
    default_model: Optional[str] = None
    api_format: Optional[str] = None  # "responses" or "chat" (default: "responses" for openai, "chat" otherwise)
    auth_format: str = "bearer"  # "bearer" (default) or "api-key" (for Baseten)
    prompt_cache: bool = True  # Set to false to disable prompt caching (adds prompt_cache_max_len=0)


@dataclass
class Config:
    """Application configuration."""
    api_url: str
    api_key: str
    conversations_dir: Path
    exports_dir: Optional[Path]
    enable_streaming: bool
    system_prompt: Optional[str]
    default_provider: str  # Derived from default_model (provider/model format)
    default_model: str  # Model name only (without provider prefix)
    default_temperature: float
    timeout: Optional[int]  # API request timeout in seconds (None = no timeout)
    log_level: str = "INFO"  # Logging level: DEBUG, INFO, WARNING, ERROR
    log_file: Optional[Path] = None  # Path to log file (None = stderr)
    providers: list[ProviderConfig] = field(default_factory=list)
    file_confirm_threshold_bytes: int = 40_000  # Require explicit confirmation above this size
    env_expand_from_environment: bool = True  # Allow ${VAR} to fall back to env vars
    env_var_blocklist: list[str] = field(default_factory=list)  # Additional patterns to block
    include_thinking_in_history: bool = False  # Include thinking content in messages sent to API

    def get_provider(self, provider_id: str) -> ProviderConfig:
        """Get provider configuration by id."""
        for p in self.providers:
            if p.id == provider_id:
                return p
        raise ValueError(f"Provider '{provider_id}' not found in configuration")

    def get_model(self, provider_id: str, name: str) -> ModelConfig:
        """Get model configuration by provider and name.

        Args:
            provider_id: Provider id
            name: Model name to look up

        Returns:
            ModelConfig for the specified model

        Raises:
            ValueError: If model is not found
        """
        provider = self.get_provider(provider_id)
        if provider.models:
            for model in provider.models:
                if model.name == name:
                    return model
        # If models not specified, allow dynamic model names
        return ModelConfig(name=name, context=None, max_tokens=None, reasoning_levels=None)

    def list_models(self, provider_id: str) -> list[ModelConfig]:
        provider = self.get_provider(provider_id)
        return provider.models or []

    def resolve_alias(self, alias: str) -> tuple[str, str] | None:
        """Resolve a model alias to (provider_id, model_name).

        Args:
            alias: The alias to resolve

        Returns:
            Tuple of (provider_id, model_name) if found, None otherwise
        """
        for provider in self.providers:
            for model in provider.models or []:
                if model.alias == alias:
                    return (provider.id, model.name)
        return None


def _setup_logging(config: Config) -> None:
    """Configure logging based on config settings.

    Args:
        config: Configuration object with logging settings
    """
    # Convert log level string to logging constant
    numeric_level = getattr(logging, config.log_level, logging.INFO)

    # Create formatter with timestamp, level, and message
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)

    # Remove any existing handlers
    root_logger.handlers.clear()

    # Add appropriate handler based on config
    if config.log_file:
        # Ensure log directory exists
        config.log_file.parent.mkdir(parents=True, exist_ok=True)
        handler = logging.FileHandler(config.log_file)
    else:
        handler = logging.StreamHandler()

    handler.setLevel(numeric_level)
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)

    # Log the configuration
    logging.info(f"Logging initialized: level={config.log_level}, file={config.log_file}")


def infer_reasoning_levels(model_name: str) -> list[str]:
    """Best-effort inference of reasoning levels for known models."""
    name = model_name.lower()
    if "gpt-5.1" in name or "gpt5.1" in name:
        return ["none", "low", "medium", "high"]
    if "gpt-5" in name:
        return ["minimal", "medium", "high"]
    return []


def reasoning_levels_for_model(config: Config, provider_id: str, model_name: str) -> list[str]:
    """Return supported reasoning levels for a provider/model combination."""
    try:
        model_cfg = config.get_model(provider_id, model_name)
    except ValueError:
        return []

    if model_cfg.reasoning_levels:
        return [lvl.lower() for lvl in model_cfg.reasoning_levels]

    try:
        provider = config.get_provider(provider_id)
    except ValueError:
        provider = None

    if provider and provider.type.startswith("openai"):
        return infer_reasoning_levels(model_name)

    return []


def reasoning_default_for_model(config: Config, provider_id: str, model_name: str) -> str | None:
    """Return configured default reasoning level for a model, if any."""
    try:
        model_cfg = config.get_model(provider_id, model_name)
    except ValueError:
        return None

    if model_cfg.reasoning_default:
        return model_cfg.reasoning_default.lower()
    return None


def load_config(config_path: Path | str | None = None) -> Config:
    """Load configuration from a TOML file.

    Args:
        config_path: Path to config file. If None, uses ~/.scriptchat/config.toml

    Returns:
        Config object with loaded or default values

    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If configuration is invalid
    """
    if config_path is None:
        config_path = Path.home() / ".scriptchat" / "config.toml"
    else:
        config_path = Path(config_path).expanduser().resolve()

    if not config_path.exists():
        raise FileNotFoundError(
            f"Configuration file not found at {config_path}\n"
            "Please create a config.toml with your settings."
        )

    # Base directory for resolving relative paths in config
    config_dir = config_path.parent

    # Load TOML file
    with open(config_path, 'r') as f:
        data = toml.load(f)

    # Extract sections
    general_section = data.get('general', {})
    ollama_section = data.get('ollama', {})

    # Parse providers
    providers_config = data.get('providers', [])
    models_data_legacy = data.get('models', [])

    # Get general configuration values
    log_level = general_section.get('log_level', 'INFO').upper()
    log_file_str = general_section.get('log_file')
    if log_file_str:
        log_file = Path(log_file_str).expanduser()
        if not log_file.is_absolute():
            log_file = config_dir / log_file
    else:
        log_file = None

    exports_dir_str = general_section.get('exports_dir')
    if exports_dir_str:
        exports_dir = Path(exports_dir_str).expanduser()
        if not exports_dir.is_absolute():
            exports_dir = config_dir / exports_dir
    else:
        exports_dir = None
    if exports_dir:
        exports_dir.mkdir(parents=True, exist_ok=True)

    # Get Ollama configuration values with defaults
    api_url = ollama_section.get('api_url', 'http://localhost:11434/api')
    api_key = ollama_section.get('api_key', '')

    conversations_dir_str = general_section.get('conversations_dir')
    if conversations_dir_str:
        conversations_dir = Path(conversations_dir_str).expanduser()
        if not conversations_dir.is_absolute():
            conversations_dir = config_dir / conversations_dir
    else:
        # Default to ~/.scriptchat/conversations (always absolute)
        conversations_dir = Path.home() / '.scriptchat' / 'conversations'

    # Ensure conversations directory exists
    conversations_dir.mkdir(parents=True, exist_ok=True)

    enable_streaming = bool(general_section.get('enable_streaming', False))

    system_prompt = general_section.get('system_prompt', ollama_section.get('system_prompt'))
    default_model = general_section.get('default_model') or ollama_section.get('default_model')
    default_temperature = general_section.get('default_temperature', ollama_section.get('default_temperature', 0.7))
    timeout = general_section.get('timeout', ollama_section.get('timeout', 1200))  # Default: 20 minutes
    file_confirm_threshold_bytes = int(general_section.get('file_confirm_threshold_bytes', 40_000))

    # Environment variable expansion settings
    env_expand_from_environment = bool(general_section.get('env_expand_from_environment', True))
    env_var_blocklist_raw = general_section.get('env_var_blocklist', [])
    if isinstance(env_var_blocklist_raw, str):
        env_var_blocklist = [p.strip() for p in env_var_blocklist_raw.split(',') if p.strip()]
    elif isinstance(env_var_blocklist_raw, list):
        env_var_blocklist = [str(p).strip() for p in env_var_blocklist_raw if p]
    else:
        env_var_blocklist = []

    # Thinking content settings
    include_thinking_in_history = bool(general_section.get('include_thinking_in_history', False))

    providers: list[ProviderConfig] = []

    def parse_models_field(value) -> list[ModelConfig]:
        if value is None:
            return []
        if isinstance(value, str):
            names = [n.strip() for n in value.split(',') if n.strip()]
            return [ModelConfig(name=n, context=None, max_tokens=None, reasoning_levels=None, reasoning_default=None) for n in names]
        if isinstance(value, list):
            result = []
            for entry in value:
                if isinstance(entry, dict):
                    name = entry.get('name')
                    if not name:
                        continue
                    context = None
                    context_val = entry.get('context')
                    if context_val:
                        try:
                            context = int(context_val)
                        except (ValueError, TypeError):
                            context = None
                    reasoning_levels = None
                    levels_val = entry.get('reasoning_levels')
                    if levels_val:
                        if isinstance(levels_val, str):
                            reasoning_levels = [lvl.strip().lower() for lvl in levels_val.split(',') if lvl.strip()]
                        elif isinstance(levels_val, list):
                            reasoning_levels = [str(lvl).strip().lower() for lvl in levels_val if str(lvl).strip()]
                    reasoning_default = None
                    if entry.get('reasoning_default'):
                        reasoning_default = str(entry.get('reasoning_default')).strip().lower()
                    alias = None
                    if entry.get('alias'):
                        alias = str(entry.get('alias')).strip()
                    max_tokens = None
                    max_tokens_val = entry.get('max_tokens')
                    if max_tokens_val:
                        try:
                            max_tokens = int(max_tokens_val)
                        except (ValueError, TypeError):
                            max_tokens = None
                    # Model-level flag to skip prompt_cache_max_len param (for models that don't support it)
                    skip_prompt_cache_param = bool(entry.get('skip_prompt_cache_param', False))
                    result.append(ModelConfig(
                        name=name,
                        context=context,
                        max_tokens=max_tokens,
                        reasoning_levels=reasoning_levels,
                        reasoning_default=reasoning_default,
                        alias=alias,
                        skip_prompt_cache_param=skip_prompt_cache_param,
                    ))
                elif isinstance(entry, str):
                    result.append(ModelConfig(name=entry.strip(), context=None, max_tokens=None, reasoning_levels=None, reasoning_default=None))
            return result
        return []

    if providers_config:
        for entry in providers_config:
            pid = entry.get('id')
            ptype = entry.get('type')
            api_url = entry.get('api_url')
            if not pid or not ptype or not api_url:
                raise ValueError("Each provider must have id, type, and api_url")
            models = parse_models_field(entry.get('models'))
            providers.append(ProviderConfig(
                id=pid,
                type=ptype,
                api_url=api_url,
                api_key=entry.get('api_key', ''),
                models=models,
                streaming=entry.get('streaming', True),
                headers=entry.get('headers', {}),
                default_model=entry.get('default_model'),
                api_format=entry.get('api_format'),
                auth_format=entry.get('auth_format', 'bearer'),
                prompt_cache=entry.get('prompt_cache', True),
            ))
    else:
        # Legacy config: build a single ollama provider from [ollama] and [[models]]
        legacy_models = []
        for model_data in models_data_legacy:
            name = model_data.get('name')
            if not name:
                raise ValueError("Model missing 'name' field")

            context_val = model_data.get('context')
            if not context_val:
                raise ValueError(f"Model '{name}' missing 'context' field")

            try:
                context = int(context_val)
            except (ValueError, TypeError):
                raise ValueError(f"Invalid context format for model '{name}': {context_val}")

            legacy_models.append(ModelConfig(name=name, context=context, max_tokens=None))

        providers.append(ProviderConfig(
            id='ollama',
            type='ollama',
            api_url=api_url,
            api_key=api_key,
            models=legacy_models,
            streaming=True,
            headers={},
            default_model=default_model
        ))

    # Parse default_model which should be in "provider/model" format
    # For backwards compatibility, also support just "model" (uses first provider)
    provider_ids = [p.id for p in providers]
    default_provider = None

    if default_model and '/' in default_model:
        # New format: provider/model
        parts = default_model.split('/', 1)
        default_provider = parts[0]
        default_model = parts[1]
    elif default_model:
        # Legacy: just model name - find which provider has it
        for p in providers:
            model_names = [m.name for m in p.models or []]
            if default_model in model_names:
                default_provider = p.id
                break
        if not default_provider:
            # Fall back to first provider
            default_provider = providers[0].id if providers else None

    # If default_model not set, use first provider's first model
    if not default_model and providers:
        default_provider = providers[0].id
        p = providers[0]
        if p.default_model:
            default_model = p.default_model
        elif p.models:
            default_model = p.models[0].name

    # Validate default provider exists
    if default_provider and default_provider not in provider_ids:
        raise ValueError(f"default_model provider '{default_provider}' not found. Available: {provider_ids}")

    # Validate default model exists in provider
    if default_provider and default_model:
        try:
            default_provider_obj = next(p for p in providers if p.id == default_provider)
            model_names = [m.name for m in default_provider_obj.models or []]
            if model_names and default_model not in model_names:
                raise ValueError(
                    f"default_model '{default_model}' not found in provider '{default_provider}'. Options: {model_names}"
                )
        except StopIteration:
            pass

    # Validate model aliases: format and uniqueness
    seen_aliases: dict[str, str] = {}  # alias -> "provider/model" for error messages
    for provider in providers:
        for model in provider.models or []:
            if model.alias:
                # Validate format: alphanumeric, underscore, dash, dot only (no slashes)
                if not ALIAS_PATTERN.match(model.alias):
                    raise ValueError(
                        f"Invalid alias '{model.alias}' for model '{provider.id}/{model.name}'. "
                        "Aliases must contain only alphanumeric characters, underscores, dashes, or dots."
                    )
                # Validate uniqueness
                qualified_name = f"{provider.id}/{model.name}"
                if model.alias in seen_aliases:
                    raise ValueError(
                        f"Duplicate alias '{model.alias}': used by both '{seen_aliases[model.alias]}' and '{qualified_name}'"
                    )
                seen_aliases[model.alias] = qualified_name

    config = Config(
        api_url=api_url,
        api_key=api_key,
        conversations_dir=conversations_dir,
        exports_dir=exports_dir,
        enable_streaming=enable_streaming,
        system_prompt=system_prompt,
        default_provider=default_provider,
        default_model=default_model,
        default_temperature=default_temperature,
        timeout=timeout,
        file_confirm_threshold_bytes=file_confirm_threshold_bytes,
        log_level=log_level,
        log_file=log_file,
        providers=providers,
        env_expand_from_environment=env_expand_from_environment,
        env_var_blocklist=env_var_blocklist,
        include_thinking_in_history=include_thinking_in_history,
    )

    # Configure logging based on settings
    _setup_logging(config)

    return config
