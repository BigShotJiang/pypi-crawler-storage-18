#pragma once

void obtainlock();