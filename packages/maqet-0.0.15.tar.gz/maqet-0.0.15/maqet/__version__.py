"""Version information for MAQET."""

__version__ = "0.0.15"
