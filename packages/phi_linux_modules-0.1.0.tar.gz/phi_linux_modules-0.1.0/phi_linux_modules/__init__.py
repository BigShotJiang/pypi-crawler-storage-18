"""Φ-linux fallback modules.

These modules are embedded in PyPI as a fallback when the primary
n8n endpoint is unavailable. They may be slightly behind the live
versions but provide core functionality.

Usage:
    # Automatic (via py-sandbox)
    from py_sandbox import remote
    remote.load('heartbeat')  # Auto-fallback if n8n down
    
    # Direct import
    from phi_linux_modules import heartbeat
    heartbeat.main()
"""
__version__ = '0.1.0'
