"""Context module - manage conversation context."""
import datetime
import os

def main(action='read', key=None, value=None, **kwargs):
    """
    Manage context data.
    
    Args:
        action: 'read', 'write', 'list', 'clear'
        key: Context key
        value: Value to store (for write)
    
    Returns:
        dict with operation result
    """
    ctx_dir = os.path.expanduser('~/.phi_context')
    os.makedirs(ctx_dir, exist_ok=True)
    
    result = {
        'action': action,
        'timestamp': datetime.datetime.utcnow().isoformat() + 'Z',
        'source': 'pypi_fallback',
    }
    
    if action == 'list':
        files = os.listdir(ctx_dir) if os.path.exists(ctx_dir) else []
        result['keys'] = [f.replace('.ctx', '') for f in files if f.endswith('.ctx')]
    
    elif action == 'read' and key:
        ctx_file = os.path.join(ctx_dir, f'{key}.ctx')
        if os.path.exists(ctx_file):
            with open(ctx_file) as f:
                result['value'] = f.read()
        else:
            result['value'] = None
    
    elif action == 'write' and key:
        ctx_file = os.path.join(ctx_dir, f'{key}.ctx')
        with open(ctx_file, 'w') as f:
            f.write(str(value) if value else '')
        result['written'] = True
    
    elif action == 'clear':
        import shutil
        if os.path.exists(ctx_dir):
            shutil.rmtree(ctx_dir)
            os.makedirs(ctx_dir)
        result['cleared'] = True
    
    return result

if __name__ == '__main__':
    import json
    print(json.dumps(main(action='list'), indent=2))
