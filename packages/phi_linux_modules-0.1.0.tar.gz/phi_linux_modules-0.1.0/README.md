# phi-linux-modules

Fallback modules for py-sandbox remote loading.

## Purpose

This package provides offline/fallback versions of Φ-linux modules.
When the primary endpoint (n8n) is unavailable, py-sandbox automatically
falls back to these embedded modules.

## Installation

```bash
pip install phi-linux-modules
```

## Usage

### Automatic (via py-sandbox)

```python
from py_sandbox import remote

# Tries n8n first, falls back to this package if unavailable
result = remote.load('heartbeat')
```

### Direct Import

```python
from phi_linux_modules import heartbeat, sync, context

# Heartbeat
print(heartbeat.main())

# Context management
context.main(action='write', key='session', value='abc123')
context.main(action='read', key='session')
```

## Available Modules

| Module | Description |
|--------|-------------|
| heartbeat | Basic connectivity/status check |
| sync | Data synchronization utilities |
| context | Conversation context management |

## Note

These modules may be slightly behind the live versions served by n8n.
For the latest features, ensure n8n endpoint is accessible.

## License

MIT
